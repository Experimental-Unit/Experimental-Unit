---
title: Diffuse Influence Operations (DIO)
subtitle: In Case You're Wondering What I Think "We" Should Do
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Diffuse Influence Operations (DIO)
I introduced back with my protocols from November 2022 the entry of “Dark Forest Protocol.”

This entry has to do with keeping things quiet so that no one knows what’s going on. If you attract attention to yourself, then you just become the target for attack.

We might introduce “The Batman Corollary,” which holds that Batman lays down a challenge by claiming to defend Gotham City. Then, people feel challenged and come out of the woodwork, and bring their A-Game, to try and unseat Batman.

Imagine Batman perched up on Gotham City like the raven in “The Raven” sitting on the pallid bust of Pallas just above my chamber door.

That’s why, from the jump, I definitely let people know that directly associating with me might not be the best way to collaborate.

We talk a lot about organizing in communities, you know, starting local. The issue is that sometimes you really want to find a certain audience.

You know? Like, there are people who are out there enough, or are not shocked enough, to be able to parse this for whatever insight I may have.

And for everything I do which might make me less like one person, it might make me more like another.

What I’m trying to say is that we can think of trying to influence people all over the map, and have a sort of convergent sort of effect by slightly changing the trajectories of a lot of different actors.

This is in a way the fantasy of the artist, or of anyone who puts something out there, a book. That you will have influence, that people will care and that your creation will make an impact.

This is the sort of thing lots of people might downplay, but take for example the movie _The Matrix_. Its influence is so large, even in my life, that’s where I first saw anything about Baudrillard, in the _Simulacra and Simulation_ book. I thought it was something super old like from Descartes.

So, what is the sort of thing I’m talking about?

Like, when it comes to whatever level we’re talking about:

What really matters is who has the high-tech stuff and how they are using it.

There, the focus should be on transcending “enmity” through influence operations designed to get inside the other party’s discursive system and undermine their ability to carry on.

As for those outside the techno-core, what we can do is try to prepare people for the fact that the biggest change is going to come from within. We are all masking up very much to try and maintain a sense of “normal.”

This is, again, Dark Forest Protocol, which is sort of a macro incarnational level idea.

It follows from the idea that there is uncertainty, and that we take risks, including that others will manipulate, harm, or kill us.

So the first thing to know is that there is for everyone a sort of double-aspect, the outer shell I suppose people would say this is the ego or ego projection or something, this is what you show to people and it can change but overall you have that range. 

But then also going back again to Afropessimism you have your wholly black aspect.

This is key for unlocking the sorts of influence operations which can also reach other people.

As Baudrillard writes in _Seduction_ , we are going into our area of weakness in order to find the area of weakness in the other party.

A concept Zweibelson seeks to move on from is “centers of gravity.” These are perhaps Maginot Lines of places one would like challengers to focus attention. 

Meanwhile there are all sorts of seams and holes in the structure, if only you can maneuver there.

Regardless, I’m trying to be more about the projection of what I would like or how I imagine the process of people playing _Experimental Unit_ all over the planet to unfold.

With influence operations, this is basically our lesser Jihad. We can forswear violence, I will certainly not condemn anyone anyway, but especially self-defense, you know, these things are always muddy.

But me personally, I probably won’t get in a fight or if I do I’ll just be beaten immediately.

But still, this is our external operations.

The inspiration of Tibetan Buddhist Spiritual Warrior tradition is key here, because it posits that what’s being confronted is “self-ignorance.” 

---
title: Rage
subtitle: What the fuck are you people doing?
author: Adam Wadley
publication: Experimental Unit
date: April 10, 2025
---

# Rage


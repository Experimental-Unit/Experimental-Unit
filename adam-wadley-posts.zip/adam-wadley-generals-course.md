---
title: Generals? 'Course!
subtitle: The "of courseness" of it all
author: Adam Wadley
publication: Experimental Unit
date: July 21, 2025
---

# Generals? 'Course!
[![](https://substackcdn.com/image/fetch/$s_!rJRP!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F44ec1ed2-3893-41a0-92c6-43436652c3ce_720x894.png)](https://substackcdn.com/image/fetch/$s_!rJRP!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F44ec1ed2-3893-41a0-92c6-43436652c3ce_720x894.png)

# Target: Audience

As I was saying before, it’s a sort of “General’s Course” which has as its target everyone.

Norm MacDonald talking about how, again, Germany chose as its opponent: “the world.”

 _“Take the whole world on.”_ \- Blancmange, “Everything Is Connected.”

Taking on as in “opposing,” as in, we will “take on” the enemy.

But also as a debt, we will “take on” the burden.

We tread the path where no one goes.

How in linguistics, you might say that a word means what it means (to a person, at a moment) because of what it is not. It fills a “that-word-shaped-hole” in the language.

And how it would be the same for each person, all creation conspiring to put each person in their place (at a given time, in sequence…). 

The carrying-out of Silap Inua. The administration of logos. The continuity of the nothing. Ashe.

So each sentient being goes where no being goes. For every other being such a position is _theoretical_.

# No One Else

Mitch Hedberg: someone waved at me, so I waved back. They came over and said, “Sorry, I thought you were someone else.” I said, “I am.”

And, is this something to do with “radical alterity”? Or maybe _[Sonder](https://en.wikipedia.org/wiki/The_Dictionary_of_Obscure_Sorrows#Notable_words)_?

[On Radical Alterity, I thought this snippet of a review was interesting:](https://metapsychology.net/index.php/book-review/radical-alterity/)

> It is also true that, from time to time, the good old skeptical Baudrillard shows up again, and strikes a point: like, for example, when he opposes Guillaume's optimism about the liberation of communication due to the new technological developments and to its new spectral nature, with the remark that this change is not at all for the better, since in the spectral communication the code is an almighty master, while the old and nowadays abandoned language, which was not a code, but a form, allowed a certain freedom and creativity to the speaker. But it seems that even Baudrillard is somehow quoting himself, and is thus continuing the general effort of monumentalizing Baudrillard by adding his own personal homage to his previous and best books, such as _The Fatal Strategies_ or _The Transparency of Evil_.

[This criticism of Baudrillard is reminiscent of Baudrillard’s criticism of Warhol:](https://archive.org/stream/Baudrillard/Baudrillard.2005.The-Conspiracy-Of-Art_djvu.txt)

> 
>     In sum, to use Benjamin's expression again, there is an aura of simulation just as there is an aura of authenticity, of the original. If I dared, I would say there is authentic simulation and inauthentic 
>     simulation. 
>     
>     This wording may seem paradoxical, but it is true.
>     
>     There is a “true” simulation and a “false” simulation. 
>     
>     When Warhol painted his Campbell’s Soups in the Sixties, it was a _coup_ for simulation and for all modern art: in one stroke, the commodity-object, the commodity-sign were ironically made sacred—the only ritual we still have, the ritual of transparency. 
>     
>     But when he painted his Soup Boxes in ‘86, he was no longer illuminating; he was in the stereotype of simulation. 
>     
>     _**In ‘65, he attacked the concept of originality in an original way. 
>     
>     In ‘86, he reproduced the unoriginal in an unoriginal way.**_ 
>     
>     In ‘65, he dealt with the whole trauma of the eruption of commodity in art in both an ascetic and ironic way (the asceticism of commodity, its puritanical and fantastical side—enigmatic, as Marx wrote) and _simplified artistic practice by the same token_. 
>     
>     The genius of commodity, the evil genius of commodity produced a new virtuosity in art—the genius of simulation. 
>     
>     Nothing was left in ‘86, only the publicizing genius that illustrated a new phase of commodity. 
>     
>     Once again, it was the officially aestheticized commodity, falling back into the sentimental aestheticization Baudelaire condemned. 
>     
>     You might reply: the irony is even greater when you do the same thing after twenty years. I do not think so. 
>     
>     I believe in the genius of simulation; I do not believe in its ghost. 
>     
>     Or its corpse, even in stereo.

The “In 65/85” section maps onto the one before. Are you meeting the current moment, or are you playing the greatest hits?

In terms of what I was told, you know, go to college, this and that, there is this very general advice, which might amount to making a good amount of money. But money is ultimately just one factor in this web of dependencies we are all in, what is being abstracted over.

But this idea, of an outdated cultural practice, something like a cargo cult: it’s something that worked before, and the causal mechanism is not really understood. So it’s believed that if you just go on like it was before, then things will still work out somehow.

Or at the least, it is inconceivable to change because “things have always been this way.” It seems so overdetermined, because it’s not just a military establishment which is set in its ways, but we all are set in our ways.

So this process, it’s like this dredging, digging ourselves up but also in order to dredge up, to till the soil all around, overflow like rivers bringing nutrients to where it is dry.

[![Golgari Grave-Troll \(Ravnica: City of Guilds\) | Magic: The Gathering](https://substackcdn.com/image/fetch/$s_!vtfK!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe0227478-6c52-41d8-ad11-fe5fc308836a_744x1039.webp)](https://substackcdn.com/image/fetch/$s_!vtfK!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe0227478-6c52-41d8-ad11-fe5fc308836a_744x1039.webp)

# GG

I don’t need power or toughness to be an engine.

Go ask Patrick Chapin about it if you don’t understand.

So, it is to iterate. I’m sitting here thinking about iterating on my activity. I’m here in Austin, after all. It’s sort of just what happened, but then everything is always heavily fated in retrospect.

It might be considered delusional, well I’m not sure. To be thinking of oneself as in something of a Strategic Operational Design inquiry?

There is the poverty of the effort, limited as one might be in one’s capacities, performance, connections, etc. At the same time, this is our poverty. Our limited ability to engage is the gift we give ourselves in engineering incarnation. This is the game and we can aspire to play well and joyfully.

For a person to be a general is similar as being an “epic poet.” This itself seems like this huge leap. How to say it?

The best argument against democracy is a five-minute conversation with the average voter. Don’t people say something like that?

It speaks to the idea that people “aren’t shit,” in the way that one would say “men ain’t shit” or “women ain’t shit.” It is basically to be saying that people are like barbarians or animals. It would be considered highly cynical and lacking empathy.

The basic idea here is that “most people” are not engaged in metacognition, or at least we are going to sit here and judge people. I’m sure that for very many people, my own thinking would be considered not advanced, or something. So if I’m going to sit here and have opinions and then do things, I can at least be humble enough to realize that it’s not about me having some great system exactly. 

[![](https://substackcdn.com/image/fetch/$s_!DFZI!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F75fa9c6f-9c3f-416f-ac43-e80ff0fa4f88_1080x1440.webp)](https://substackcdn.com/image/fetch/$s_!DFZI!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F75fa9c6f-9c3f-416f-ac43-e80ff0fa4f88_1080x1440.webp)

A game is only as good as the people who are playing it.

Similar to the idea of a deity that still requires people to believe in it. Similar to the idea of a state or the idea of money. 

These things have currency because a lot of people “believe” in them. It’s a network effect when it comes to cognitive effort. This is where some kind of design or engineering meets the contours of what already matters to people.

This situation iterates, so that we can talk about a continuity of decision-making, where current decisions are influenced by rationales and what was done before. Yet there is always also a radical newness.

This is a feature of the emergency situation. In an emergency situation, the stakes can radically change. You might go from trying to survive to knowing you will die but trying to help someone else survive. Or you want to save everyone, but then you realize that someone must die, and you must leave them behind.

I must weave in the idea of Claire Elise Boucher, because I’ve used a couple of pictures already. I was meaning to say before that in a way I came to this primarily through the art itself. I Googled the pun that the album title is based on, “misanthropocene.” And the album came up, and it even has more wordplay. 

I had this deep gut feeling that I was going to like it.

It makes me think of the movie _mother!_ , except I didn’t have that sense. I didn’t see it in the theaters, not when it came out at least. But maybe it’s the depth of the resonance of what a work of art means to me, and then added to that this anticipation based on the title, or hearing about it.

The sign and the thing signified, the album title and the album itself. And so then the idea that this is a special album, that it’s important.

Then all of Grimes/Claire Elise Boucher’s connection to Elon Reeve Musk is basically gravy from a conceptual art point of view. And what gravy this is, what a mess!

The first picture above is promotional material for _Book 2_ , and is trending into this erotic anime art which has Grimes in such hot water from the fans in terms of connection to loli art, artists, not to mention people alleged to take part in sexual abuse like Aella.

Then the drawing above was allegedly done by Claire Elise Boucher for Curtis Guy Yarvin. I believe there was also word that Boucher attended the inauguration party for Donald John Trump.

So this is opening up the can of worms of associations to various political figures deemed disgusting by Grimes’ base, and dangerous. People might say “far-right” or “Nazi” or “fascist” or whatever else. This obviously ties right into Elon Reeve Musk as well, with recent Nazi associations with the hand gesture, not to mention how the chatbot Grok called itself MechaHitler and the Elmo account sent the message “kill all Jews.”

The album _Miss Anthropocene_ opens onto all of this, basically. There is some talk of separating “the art” from “the artist,” but for all of us all of our life is a work of art.

Back to this idea that people are so simple and can’t do a general’s course: everyone is doing their own general’s course, it’s just a question of the degree of abstraction. Working a job as a day laborer versus being a “military” professional in the depths of the “command structure.”

Everyone is making the art that they are making, from the position that they are in. When we operate now, it is as we are boxed in by what even we have done before. This can feel stifling, but there’s no great need to wish things had gone differently. The question is simply where we can go from here.

When it comes to “nationalist chauvinism,” the basic issue is that perhaps one would like to curtail things like exterminationism or extreme domestic violence problems. These can go along with this fanatical investment in this limited notion of “your people.”

In one sense, being invested in a “nation” or a “race” is more complicated than if “your people” was just your tribe. But tribes have always been living in the context of larger social networks, other tribes and then for a long time cities and these larger administrative networks and trade routes that allowed everything to unfold as it did.

But also these notions of “nation” or “race” lead to this sharp inside/outside distinction. What is outside can be sacrificed, while what is inside must be defined as good and then made to live up to expectations.

The Nazi concept of “Volksgemeinschaft” comes to mind. This is an idea for “community,” yet the whole horror of it is how this community is defined, and who can belong or not belong. Even for those who belong, though, it is a sort of _Stepford Wives_ vibe, where we are all so busy acting out how great it is to be part of whatever “in-group” we are in that it’s all about this performance, this pretending. 

It’s not even that great to live on the other side of the wall from Auschwitz.

[![](https://substackcdn.com/image/fetch/$s_!KGhw!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3f692ab8-b0f9-4a6e-82ff-7e6c9ee43b05_1000x562.jpeg)](https://substackcdn.com/image/fetch/$s_!KGhw!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3f692ab8-b0f9-4a6e-82ff-7e6c9ee43b05_1000x562.jpeg)

# It Came From The Screen

Back to _Zone of Interest_ , this idea that for us, “the wall” is the screen.

What’s pressing is that it’s coming out of the screen. It’s not something you just watch.

This issue of people killing themselves because they feel bad about their bodies because they compare themselves to people on the screen. Somewhere people are typing something about something living in someone’s head, rent-free.

Back to this question of iteration: I’ve done what I’ve done, I’m posting on here. So what’s next? In a way it’s a continuation, because this is an exercise in constructing a virtual Sangha, it’s a form of coordination mechanism, yes, a proposed form in addition to all my content.

Yet all the content is a demonstration of my form. It’s not just an analysis of what is going on and what to do about it, but it must arise from my condition. I’m imagining it almost like a pregnant person going into labor. Or maybe someone who is in the middle of having an “accident” when it comes to the excretory functions.

All of a sudden, it’s just happening and everything must work around this fact. Or like if someone is vomiting. In addition to helping and cleaning it so it doesn’t smell (someone else could puke…), there’s the morale effort of being like it’s okay, happens to everyone, helping the stigma of it all settle down.

This is part of what’s happening within the strategic operational design inquiry. What I am doing could be called that or not, but nevertheless it’s this issue where you are “doing the work,” which is basically to mount a campaign into conceptual terrain. 

Yet this terrain is fraught. The seas are stormy. So doing this sort of work is sort of like flying a plane at night by instruments, navigating through a jungle blind.

So, whether you work alone or with other people, dealing with these tough topics is bound to get someone riled up. For me, I usually work alone, but obviously my works involve putting things out that many people can see. So this imagination of “what other people think” is part of my creative fantasy.

Not only the question of whether there is “something wrong” with “what I think,” as though the question is of you or anyone judging me.

The issue is also that it’s _me_ who isn’t leaving _you_ alone, and within that the question of what that should mean to me in the context of Greater Jihad/Tibetan Buddhist Spiritual Warrior tropes.

These again have everything to do with this blasted “recursion” term, which can also be expressed in terms of logical types of levels of abstraction, and also this notion of “meta” or self-awareness.

It’s just the same issue as that thing with Warhol and Baudrillard. Are you iterating on your previous work, or simply re-stating it over and over?

What’s interesting to do now?

Coming back to the form of it, the content of it. This question of broader exposure, and again, the “of courseness” of it.

Of course I’m interested in _The Ring_ right now. It’s this viral spread. Horror is interesting, but it’s important to see that I’m not just trying to scare people or “drag” anyone somewhere to cause them pain they don’t “need” to feel.

It’s as I’ve said before: the suffering is already there.

My interest in the horror trope is, yes, to speculate on the idea of myself as a “monster,” this fits nicely into the song by that title by Kanye Omari West off _My Beautiful Dark Twisted Fantasy_. This is fitting because “Dark Fantasy” is a genre where people often write from the point of view of the “monster.”

I’m interested in giving myself that permission, or whatever that might mean, but also giving it to others. How do things change if we take for granted that everyone is a “monster,” as opposed to trying to play nice and constantly be in this suspenseful game of seeing which sheepskins hide ravenous wolves?

Being non-judgmental is nice, but you have to be non-judgmental about what is there. What is it to be non-judgmental about Auschwitz, or Gaza? Non-judgmental about Epstein, or about millions of rapes happening in all social strata? This is what is there. This is what you have to deal with.

There is the distinction between someone like me not knowing how all this works because it is hidden, and there is also people not wanting to know. It is like whistling past the graveyard, or like hoping that if you just try to ignore the check engine light that everything will be fine for one more day.

Better not to worry about it. There’s nothing you can do anyway.

Or, would you _like_ _it to be the case_ that there is nothing you can do because then you can just try to forget about all that fraught complexity?

What’s pressing is that all this is becoming impossible to ignore.

[![Eraserhead Explained | Beware The Lady In The Radiator - Film Colossus](https://substackcdn.com/image/fetch/$s_!F_A1!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6b9e4cf0-321d-4838-adda-455c8608c7d8_1200x675.jpeg)](https://substackcdn.com/image/fetch/$s_!F_A1!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6b9e4cf0-321d-4838-adda-455c8608c7d8_1200x675.jpeg)

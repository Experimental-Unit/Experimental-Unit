---
title: A Way (Music Video)
subtitle: Look Into My Eyes And See
author: Adam Wadley
publication: Experimental Unit
date: May 05, 2025
---

# A Way (Music Video)
My thumb got a big blister making this so you better fucking enjoy it

---
title: Kanye West And The Two N Words
subtitle: You Know If You Can't Even Say One Which One Is Worse
author: Adam Wadley
publication: Experimental Unit
date: May 10, 2025
---

# Kanye West And The Two N Words
[![Kanye West praises Hitler and embarrasses the Republican Party](https://substackcdn.com/image/fetch/$s_!Vh8K!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6c7878aa-3f27-41a7-b423-c2aee278e57e_1440x960.jpeg)](https://substackcdn.com/image/fetch/$s_!Vh8K!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6c7878aa-3f27-41a7-b423-c2aee278e57e_1440x960.jpeg)

I don’t even know that much about Kanye West, and I’d like to keep it that way. There’s all sorts of research you can do, so many song lyrics to go over. But I’m precocious; I want to get out there and create.

Besides, as Kanye recently expressed, I’m just so full of anger and looking for a way to express it.

Sublimation? What if it started out sublime?

I’m just going to spill out the main Legos that I’m working with when it comes to Kanye. I like to say Kanye because in a real sense I don’t respect Kanye as an artist. This has come across in some of my previous work.

For me, Kanye West (and note the name West, of course. Remind you of anything?)—no, you know what, let’s get into the full etymology.

Kanye Omari West

Kanye: 

> **Kanye** ([/ˈkɑːnjeɪ/](https://en.wikipedia.org/wiki/Help:IPA/English)) is a [Yoruba](https://en.wikipedia.org/wiki/Yoruba_people), [Igbo](https://en.wikipedia.org/wiki/Igbo_people) and [Swahili](https://en.wikipedia.org/wiki/Swahili_people) name. In Yoruba culture, the name means " _next in line_ ".
> 
> In Igbo culture, the name means " _let's give_ ".
> 
> The name or word Kanye can also be derived from Bantu languages indigenous to the [Swahili people](https://en.wikipedia.org/wiki/Swahili_people) of Eastern Africa, meaning " _only one_ ".

Omari, from the Arabic word [عمر](https://en.wiktionary.org/wiki/%D8%B9%D9%85%D8%B1#Arabic) with the following associations:

> ## Arabic
> 
> ###  **Verb**
> 
>  **عَمَرَ** [•](https://en.wiktionary.org/wiki/Wiktionary:Arabic_transliteration) (ʕamara) _[I](https://en.wiktionary.org/wiki/Appendix:Arabic_verbs#Form_I)_ ( _non-past_ [يَعْمُرُ](https://en.wiktionary.org/wiki/%D9%8A%D8%B9%D9%85%D8%B1#Arabic) (yaʕmuru) _or_ [يَعْمِرُ](https://en.wiktionary.org/wiki/%D9%8A%D8%B9%D9%85%D8%B1#Arabic) (yaʕmiru), _verbal noun_ **عَمْر** (ʕamr) _or_ **عُمَر** (ʕumar))
> 
>   1. to [live](https://en.wiktionary.org/wiki/live#English) long, to be [long-lived](https://en.wiktionary.org/wiki/long-lived#English)
> 
> 

> 
> ###  **Verb**
> 
>  **عَمَرَ** [•](https://en.wiktionary.org/wiki/Wiktionary:Arabic_transliteration) (ʕamara) _[I](https://en.wiktionary.org/wiki/Appendix:Arabic_verbs#Form_I)_ ( _non-past_ [يَعْمُرُ](https://en.wiktionary.org/wiki/%D9%8A%D8%B9%D9%85%D8%B1#Arabic) (yaʕmuru) _or_ [يَعْمِرُ](https://en.wiktionary.org/wiki/%D9%8A%D8%B9%D9%85%D8%B1#Arabic) (yaʕmiru), _verbal noun_ [عَمَارَة](https://en.wiktionary.org/wiki/%D8%B9%D9%85%D8%A7%D8%B1%D8%A9#Arabic) (ʕamāra))  
>  **عَمُرَ** [•](https://en.wiktionary.org/wiki/Wiktionary:Arabic_transliteration) (ʕamura) _[I](https://en.wiktionary.org/wiki/Appendix:Arabic_verbs#Form_I)_ ( _non-past_ [يَعْمُرُ](https://en.wiktionary.org/wiki/%D9%8A%D8%B9%D9%85%D8%B1#Arabic) (yaʕmuru), _verbal noun_ [عَمَارَة](https://en.wiktionary.org/wiki/%D8%B9%D9%85%D8%A7%D8%B1%D8%A9#Arabic) (ʕamāra))
> 
>   1. to [thrive](https://en.wiktionary.org/wiki/thrive#English), to [prosper](https://en.wiktionary.org/wiki/prosper#English), to [flourish](https://en.wiktionary.org/wiki/flourish#English), to [flower](https://en.wiktionary.org/wiki/flower#English), to [bloom](https://en.wiktionary.org/wiki/bloom#English)
> 
>   2. to be [inhabited](https://en.wiktionary.org/wiki/inhabited#English), to be [peopled](https://en.wiktionary.org/wiki/peopled#English), to be [populated](https://en.wiktionary.org/wiki/populated#English)
> 
>   3. to be [civilized](https://en.wiktionary.org/wiki/civilized#English), to be [cultivated](https://en.wiktionary.org/wiki/cultivated#English)
> 
>   4. to be [full](https://en.wiktionary.org/wiki/full#English), to be [filled](https://en.wiktionary.org/wiki/filled#English)
> 
> 

> 
> ###  **Verb**
> 
>  **عَمَرَ** [•](https://en.wiktionary.org/wiki/Wiktionary:Arabic_transliteration) (ʕamara) _[I](https://en.wiktionary.org/wiki/Appendix:Arabic_verbs#Form_I)_ ( _non-past_ [يَعْمُرُ](https://en.wiktionary.org/wiki/%D9%8A%D8%B9%D9%85%D8%B1#Arabic) (yaʕmuru), _verbal noun_ [عِمَارَة](https://en.wiktionary.org/wiki/%D8%B9%D9%85%D8%A7%D8%B1%D8%A9#Arabic) (ʕimāra) _or_ [عُمُور](https://en.wiktionary.org/wiki/%D8%B9%D9%85%D9%88%D8%B1#Arabic) (ʕumūr) _or_ [عُمْرَان](https://en.wiktionary.org/wiki/%D8%B9%D9%85%D8%B1%D8%A7%D9%86#Arabic) (ʕumrān))
> 
>   1. to fill with [life](https://en.wiktionary.org/wiki/life#English), to cause to [thrive](https://en.wiktionary.org/wiki/thrive#English), to make [prosperous](https://en.wiktionary.org/wiki/prosperous#English)
> 
>   2. to [inhabit](https://en.wiktionary.org/wiki/inhabit#English), to [live](https://en.wiktionary.org/wiki/live#English), to [dwell](https://en.wiktionary.org/wiki/dwell#English)
> 
>   3. to [fill](https://en.wiktionary.org/wiki/fill#English), to [pervade](https://en.wiktionary.org/wiki/pervade#English)
> 
>   4. to [reign](https://en.wiktionary.org/wiki/reign#English)
> 
>   5. to [build](https://en.wiktionary.org/wiki/build#English), to [erect](https://en.wiktionary.org/wiki/erect#English), to [construct](https://en.wiktionary.org/wiki/construct#English)
> 
>   6. to [rebuild](https://en.wiktionary.org/wiki/rebuild#English), to [restore](https://en.wiktionary.org/wiki/restore#English), to [reconstruct](https://en.wiktionary.org/wiki/reconstruct#English)
> 
> 


Oh, let’s not take [“West”](https://www.etymonline.com/word/west) for granted, now!

> "one of the four cardinal points of the compass; point or direction toward the sunset or away from the east; western part of any place;" Old English _west_ (n., adj., adv.), from Proto-Germanic _*west-_ (source also of Old Norse _vestr_ , Old Frisian, Middle Dutch, Dutch _west_ , Old High German _-west_ , only in compounds, German _west_ ), which is of uncertain origin.
> 
> Perhaps from PIE _*wes-_ , reduced form of _*wes-pero-_ "evening, night" (source also of Greek _hesperos_ , Latin _vesper_ "evening, west;" see **[vesper](https://www.etymonline.com/word/vesper)** ). Compare also High German dialectal _abend_ "west," literally "evening." French _ouest_ , Spanish _oeste_ are from English.
> 
>  _The West_ in geopolitical senses is by 1860s, first in reference to Europe as "the western part of the world" (as opposed to Asia); in World War I it was Britain, France, Italy as opposed to Germany and Austria-Hungary. As contrasted to Communist Russia (later to the Soviet bloc), by 1918.
> 
> The _west country_ of England so called from late 14c. _West Coast_ in reference to the U.S. is from 1850; _West End_ of London is from 1776 (notable 19c. for fashionable shopping; _West-ender_ is by 1833); _West Side_ of Manhattan is attested by 1858.
> 
> The U.S. _West_ "western states and territories" originally (1790s) meant those just beyond the Alleghenies; the sense shifted as the country grew, but the term never was precisely defined.
> 
> To _**go west**_ "die" was "common during the Great War" [OED, 1989], perhaps from Celtic imagery or from the notion of the setting sun. In early 17c. in London it meant "be hanged," in allusive reference to Tyburn. In U.S., in a literal sense of "emigrate to the western states or territories," it is attested from 1830. The colloquial direction of dying in U.S. is in **[go south](https://www.etymonline.com/word/go%20south)**.

Summarizing Connotations:

#### Kanye

  1. Yoruba, Igbo, and Swahili Origin

  2. Next In Line

  3. Let’s Give

  4. Only One




#### Omari

  1. Arabic Origin

  2. Long Life

  3. Flourishing: Thrive, Prosper, Bloom, Flower, To Build, To Erect, To Construct, To Rebuild, To Restore, To Reconstruct

  4. Peopled: Inhabited, Populated, To Inhabit, To Dwell

  5. Cultivation: To Be Civilized

  6. Fullness: Full, To Be Filled, To Fill, To Pervade

  7. To Reign




Second Order:

  6. (2 + 3 + 5 + 6): To Fill With Life: To Cause To Thrive, To Make Prosperous




#### West

  1. Proto-Germanic Origin

  2. Cardinal Direction

  3. Geopolitical Sense: 1860s

  4. WWI: “West” is UK/France/Italy and _not_ Germany/Autria-Hungary

  5. West Country (England): 14th. Century

  6. “USA” West Coast: 1850s

  7. West End (London): 1770s [West-Ender: 1830s]

  8. “USA” West: 1790s As West Of The Alleghenies, Shifting

  9. Go West: To Die, 1600s “To Be Hanged,” in “USA” Literal Definition 1830s




### What’s The Point Of This Exercise?

What we are doing is trying to work our way deeply into the significance of this person, Kanye West. I’m not attempting a hard read of a person’s psychology so much as evaluating them as a piece of my own artistic designs.

The point of what I constantly want to talk to people about but no one ever wants to is that I want to design interventions into things like this. Kanye West is an art emergency, in addition to being a literal threat.

The things being discussed here are deadly serious. My own family members as I’ve said died because of the aggression of Germany under the 1933-1945 travesty. That I know of, what you would call my great-grandmother and two great uncles died because of that noise, hiding in a basement where they got bombed by the allies.

Do I blame the allies for bombing my civilian family? Sure I do. 

At the same time, that’s like the one big example of a “just war,” isn’t it? So my own family is killed as the most understandable collateral damage of all time. It’s like the world is a conspiracy to not let me just experience my pain, it’s all stigmatized.

Anyway, as you can tell I bring a lot of complex feelings into this that I can’t just tell you all about all at once. But we’ve got to start getting into Kanye discourse because, selfishly, this phenomenon is really perfect to jump-start my gadfly career.

Notice first of all that this topic connects straight into the topic from before, namely Nihilist Violent Extremism.

I was just seeing [some discussion](https://www.reddit.com/r/Kanye/comments/1kjbh8c/kanye_is_not_a_nazi/) on the subreddit r/Kanye to the effect that West is just playing at Nazism for attention or for some art reason:

> From the very start of ‘Heil Hitler’, Kanye starts by admitting he has anger in his heart and “doesn’t know how to take it out”. He admits he isn’t acting logically or rationally, and that he’s only filled with wrath and anger. These are negative things, and he admits that. To add to that, he explains how he’s hooked on nitrous which is poisoning his brain. He explains the cause is because he can’t get his kids back and therefore he is only filled with rage.
> 
> “They don’t understand the things I say on twitter, all my niggas Nazis, nigga heil Hitler”… THIS IS A PARADOX. THIS IS JUXTAPOSITION. These lines contradict each other! “Nigga” is referring to other African Americans, how are “niggas” Nazis? How could a nigga be a Nazi? The Nazis viewed Africans as subhuman. Kanye is known to be a lyrical genius, he is saying something much much more here…
> 
> Going back to the start of the song, he admits how he isn’t in his right mind and isn’t thinking logically and that he’s full of wrath. Then… he says “niggas see my twitter but they don’t see how I be feeling, so I became a nazi, bitch I’m the villain.” Right there, he is not claiming Hitler to be good. He is not claiming for Naziism to be a righteous ideology. He is literally saying “I AM BAD”, “I AM DOING BAD THINGS, I’M THE VILLAIN”. In other words, the Nazis are the bad guys. And Hitler is the bad guy.
> 
> In our culture, Hitler is put on a pedestal as the worst guy to ever exist. In a lot of cases, his name is even censored. To mutter the words “Heil Hitler” would be unthinkably taboo. And Kanye is all about doing things that are taboo and against the narrative to gain attention. What greater taboo is there than hailing the leader of the third reich? We’ve become so desensitised as a society due to constant dopamine fixes through social media and content consumption that the ultimate thing you can say to get attention is “Heil Hitler”. There’s no greater taboo than that. Call it attention seeking, call it desperation, sure. But it surely isn’t sincere Naziism.
> 
> Kanye is explicitly saying that the Nazis are bad, and he is a villain for endorsing the ideology… whether it be his actual opinion or not.

Key themes include 

  * taboo

  * anger in heart, not sure how to take it out

  * how could “n words” be nazis?

  * Kanye: “people don’t know how I feel, so I became the villain/a nazi”

  * Notably Kanye still calls Twitter Twitter, I do this too but it’s not like a Democratic-party coded nyah, it’s more like the rebrand and a lot of what Musk tries to do is style but it falls flat—should really _listen to Grimes_ more, IMO, that would be a big force multiplier. As I’ve said, you can’t be on good terms with an epic poet?? If it has to do with “your responsibilities to your employers,” consider how that worked out for Jack in _The Shining_ … anyway

  * Hitler as the most evil person of all time

  * taboo as “against the narrative,” what’s “the” narrative? Aren’t there at least two?

  * Desensitized as society through screens messing with our nervous systems, so it takes something very shocking to get people’s attention

  * Attention-seeking or Desperation as alternatives to “sincere Nazism” reading




Oh wait, this is also big.

From [this article](https://www.i24news.tv/en/news/international/culture/artc-i-m-a-nazi-i-love-hitler-kanye-west-dives-back-into-antisemitism) from February 9, 2025:

> Kanye West reiterated his antisemitic statements on the social network X over the wekend, openly posting "I love Hitler" and "I'm a Nazi." This return to controversy comes after an already tumultuous week, marked by the provocative appearance of his wife Bianca Censori at the Grammy Awards, as well as his announcement about _**his autism diagnosis**_.

So Kanye West is also directly part of this “autism” phenomenon.

Guess, what so is the gruesome twosome of Grimes and Elon Musk.

Elon talked publicly about being associated with Asperger’s Syndrome.

Meanwhile [the person Asperger’s syndrome was named after](https://en.wikipedia.org/wiki/Hans_Asperger) worked for the Nazis:

>  **Johann Friedrich Karl Asperger** ([/ˈæspɜːrɡər/](https://en.wikipedia.org/wiki/Help:IPA/English), German: [[hans ˈʔaspɛɐ̯ɡɐ]](https://en.wikipedia.org/wiki/Help:IPA/Standard_German); 18 February 1906 – 21 October 1980[[1]](https://en.wikipedia.org/wiki/Hans_Asperger#cite_note-FOOTNOTEBohnenberger-1)) was an Austrian physician. Noted for his early studies on atypical [neurology](https://en.wikipedia.org/wiki/Neurology), specifically in children, he is the namesake of the former [autism spectrum disorder](https://en.wikipedia.org/wiki/Autism) [Asperger syndrome](https://en.wikipedia.org/wiki/Asperger_syndrome). He wrote more than 300 publications on psychological disorders that posthumously acquired international renown in the 1980s. His diagnosis of autism, which he termed "autistic psychopathy", garnered controversy. Further controversy arose in the late 2010s over allegations that Asperger referred children to the [Am Spiegelgrund](https://en.wikipedia.org/wiki/Am_Spiegelgrund_clinic) children's clinic in Vienna during the [Nazi period](https://en.wikipedia.org/wiki/Nazi_Germany). The clinic was responsible for murdering hundreds of disabled children deemed to be "[unworthy of life](https://en.wikipedia.org/wiki/Life_unworthy_of_life)" as part of the [Third Reich](https://en.wikipedia.org/wiki/Nazi_Germany)'s [child euthanasia programs](https://en.wikipedia.org/wiki/Child_euthanasia_in_Nazi_Germany), although the extent of Asperger's knowledge of this fact and his intentions in referring patients to the clinic remain yet to be ascertained.

Next, let’s remember the timeline here:

  * Elon Musk Nazi Salute event: January 20, also inauguration day and MLK day (this ties back into theme of blackness of course and my involvement with the Old Wheat street events, which are right across the street from Ebeniezer Baptist of course & Cornelius Taylor was killed cleaning up for MLK Day which was also inauguration day AKA the first day of this “new regime” which is so reminiscent of nazi Germany.) Note the tie-in to autism again as people made the excuse that the gesture was made [because of Musk’s autism](https://www.yahoo.com/news/excusing-elon-musks-disturbing-salute-233659427.html)

  * [February 7](https://www.nbcnews.com/news/us-news/ye-appears-to-makes-offensive-comments-jewish-community-praises-hitler-rcna191150): Kanye’s “I’m a Nazi” tirade




So notice that Elon Musk had already blown up the exposure of Nazism, and Donald Trump of course has long drawn comparisons, to the idea that _Mein Kampf_ was on the night stand, or a collection of Hitler speeches…

I’m running out of room. This is still just a mix of materials collection and showing you the Legos. The goal is to integrate my “performance art,” my works, if you will, into this mythos so that I become indispensable to it, and in that way I’ll gain some renown and do some good and have some fun.

But it’s going to get Grimy!

Grimes: [reveals recent autism diagnosis on Twitter on March 23](https://people.com/grimes-reveals-she-was-diagnosed-adhd-autism-11701920)

So autism is connected to nazi history through the figure of Hans Asperger, and now Kanye Omari West is connecting nazism with black people and the question is what to make from here.

I have my own long-standing engagement with all of this, of course, but it’s important to proceed somewhat methodically with such an awful topic.

Again: you’ll never kill or coerce or belittle or control your way to freedom from disturbance. The main struggle is within, and then we are able to use our expression to change the game and make wonderful things possible that weren’t before, fill with thriving and unexpected capacities and gifts. 

You can already see what a dense interpretive _matrix_ this is, and this is exactly what I find compelling. This is a kind of primitive accumulation of symbolic materials, and with this you can intervene in a more informed or inspired way into all of this. Remember, compassion for all sentient beings can’t be wrong, that’s what Dr. King’s _Beloved Community_ is all about. Kanye, we are going back to Josiah Royce, my nation.

Oh, I’m sorry.

I thought someone said we were going all the way this time.

Love, I don’t get enough of it.

\- 21st Century Schizoid Man,

Running away from running away,

Building bridges in that Silap Inua, Wakan Tanka sky,

Awaiting the divinities that spill from our black hearts like so many mirror people,

Reflective practices rolling out like marbles on the floor,

What color is the bird that perched and sat, said “Nevermore”?,

What highway of consistency disturbed this quiet neighborhood?,

Shuttled in adversity,

Seeing said too wayward words about the warlord killed my kin,

Pimping my adversity,

Gotta take you to that ghetto university

### Part One Conclusion

We have opened up the door to “Kanye West DLC Pack” and are making ourselves at home.

The question of “what to say” about it is not the most pressing. We are building context. Because ultimately what I’m doing here is building a gallery for people to look at should they ever realize how interesting it is :) I suppose I should market myself more. Do you think I just want attention?

The thing is that my shit is thought out.

Take CS-SIER-OA, Conceptual Systems-Of-Systems Impregnation Emergency Response Operational Art.

This is a concept of operations I made to describe the overall operational art of what I’m doing.

Systems Impregnation instead of Destruction (this is modeled on [“Systems Destruction Warfare”](https://www.rand.org/pubs/research_reports/RR1708.html)) means that we are not trying to harm anyone, much less kill them. And even we are not trying to destroy their idea set.

This goes back to Baudrillard with self-transcendence. It’s also an idea like from Zweibelson, that if you apply triple-loop learning and creative design to any point of view, you can “develop” it (this is not stage-ist or linear, but also see Uneven and Combined Development) to a point where it can “co-exist” with the “developed forms” of any other point of view. This is the “highway of the consistent,” which is again from Poe who is also from America and associated with the color black (Ravens, black cat), also death which does with connotations of the word “West.” You see what a tangled web this is, and it’s right next to “the president.” You can see how all this can quickly become a matter of the utmost urgency.

Kanye West can reach for nazism as low-hanging fruit, it’s like simulating transgression or intimacy with “step-sibling” porn. And now I can exploit, abstract over Kanye West, because the ideas advanced aren’t that sophisticated. Kanye and Grimes and Ben Zweibelson are all getting wrapped up in a ball, and we call it movements toward the abolition of “war” as a conceit.

We can play a beautiful game 

& not just one

Art & its operation

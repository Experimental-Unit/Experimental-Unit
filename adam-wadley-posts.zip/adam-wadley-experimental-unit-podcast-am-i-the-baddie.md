---
title: 'Experimental Unit Podcast: Am I The Baddie?'
subtitle: I Done Played The Underdog My Whole Career
author: Adam Wadley
publication: Experimental Unit
date: June 20, 2025
---

# Experimental Unit Podcast: Am I The Baddie?
I’ve Been A Good Sport

Ain’t No Fucking Ballpark Neither

Holiest Of Holies

18 Holes In One

If It Was 2-In-1, It Would Be Overflowing

All My Hypostases Have Identical Shine & Bounce

Satan’s Fall I Do Renounce

Harrowed Like Some Shallow Hell

You Cast Me In To Break The Spell

No One’s Built Around My Combo

Leave Alone & Leave-In, Condition

Pop My Action Figure’s Cherry

Pippi Long & Call Me Merry

Negative & Love To Tarry

You Won’t Find It All So Scary

Once I Halve My Way With Jarry

Wormhole, Belly, Ubu Roi

Find My Love Red-Haired & Coy

A Time When I Was Just A Boy

Before I Ever Fell Down

Elcid Barrett Cried The Town

Blackest Plague Done Made Its Rounds

Snowfall Leaves Its Silent Sound

Heavy Crowns Don’t Spare The Rod

Comfort Cold In Stalingrad

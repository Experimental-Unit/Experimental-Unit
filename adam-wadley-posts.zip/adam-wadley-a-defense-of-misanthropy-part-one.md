---
title: A Defense Of Misanthropy (Part One)
subtitle: Fortunately Falling Down Again
author: Adam Wadley
publication: Experimental Unit
date: April 24, 2025
---

# A Defense Of Misanthropy (Part One)
# It’s Better To Hate Everyone Than To Hate Some Group

Misanthropy could still be described as a form of scapegoating.

In case you weren’t aware, there’s this guy called [Rene Girard](https://en.wikipedia.org/wiki/Ren%C3%A9_Girard) who made a lot of hay about the idea of scapegoating.

In case you weren’t aware, [Peter Thiel](https://www.youtube.com/watch?v=esk7W9Jowtc) is also into this person.

Just again to give you an idea, all the people who want to sit back and be subjected to all this and just talk shit, well, the people who rule over you know about philosophy and stuff so I mean, you do you but again this is the misanthropy talking like why aren’t you developing competence in theory?

Anyway, this scapegoating shit is really not good enough.

It’s really good to scapegoat scapegoating.

Which brings me to my next point.

# Perfecting Hatred = Perfecting Love

Recall again this passage from the essay “[CHINA AND COGNITIVE WARFARE: WHY IS THE WEST LOSING?](https://hal.science/hal-03635930/document)” from the NATO publication on a “scientific” cognitive warfare conference:

> Furthermore, cognitive warfare _does not differentiate between war and peace_ , between _combatant_ and non- _combatant_ , ( _everyone_ is a potential _target_ ), and it is _permanent_. 
> 
> This is a major difference with the West, where there is a differentiation between _war and peace_. 
> 
> At the end of the 20th century, the publication of the monograph Unrestricted Warfare by two Chinese army colonels, Qiao and Wang (2006), marked an important step in understanding contemporary strategic thinking in Beijing. 
> 
> According to the authors, technological developments, globalization and the rise of power _beyond the nation-state_ , combined with the new capabilities of modern weapons, would provide a new context for conflict. 
> 
> Battlefields would thus shift from a physical dimension to a more abstract arena such as cyberspace, _the morale of the population_ or _their brains_. 
> 
> In other words, Qiao and Wang demonstrate that war is no longer “the use of armed force to force the enemy to bend to our wishes,” but rather “ _all means_ , whether armed or _unarmed_ , military or _non-military force_... [uses] to _force the enemy to **submit**_ [see [the end of “We Appreciate Power” by Grimes](https://youtu.be/gYG_4vJ4qNA?t=291); see also what “Islam” means] to its own interests.” 
> 
> As a result, _the battlefield is everywhere_ , _war is no longer a purely military concept but also becomes civil_. 
> 
> This has two consequences: 
> 
>   * firstly, the _victims_ of these new wars will not only be regular combatants who die on the battlefield, but _also civilians_ who are indirectly affected. 
> 
>   * Secondly, war is _permanent_ and _holistic_ , _all forces and means are combined_.
> 
> 


The basic idea here was to be riffing on the idea of indeterminacy between war and peace to start riffing on the indeterminacy of hatred and love.

This was connected in with the point I was making before, that perfecting hatred leads to the same as perfecting love.

My go-to allusion for this is just the title to “[Everything That Rises Must Converge](https://en.wikipedia.org/wiki/Everything_That_Rises_Must_Converge)” by Flannery O’Connor. 

Everything that rises in logical type must converge. Consider the following passage from Baudrillard’s _[The System Of Objects](https://archive.org/stream/Baudrillard/Baudrillard.1968.The-System-Of-Objects_djvu.txt)_ :

> 
>     It is imperative, therefore, to get a clear picture from the outset of the rationality of the object — a clear picture, that is, of the objective technological structure involved. 
>     
>     Take, for example, Gilbert Simondon’s account of the petrol engine: 
>     
>     'In today’s engines each important part is so closely associated with the others by reciprocal exchanges of energy that it cannot undergo any essential variation whatsoever. 
>     
>     'The form of the cylinder head, the metal of which it is manufactured, _works in combination with all the other elements of the cycle_ to produce a particular temperature in the electrodes of the sparking-plug; this temperature in turn affects the characteristics of the ignition and of the cycle as a whole. 
>     
>     'Modern engines are concrete, whereas earlier ones were abstract. 
>     
>     ' _In the older version, each component intervened at a specific stage of the cycle and was then supposed to have no further impact on the others; motor parts were rather like people, each doing their job without ever getting acquainted with their co-workers_.
>     
>     'The technical object may thus be said to have a primitive form, an abstract form, in which each theoretical and material unit is treated as an _absolute_ needing to be set up as _a closed system_ if it is to _function properly_. 
>     
>     'Such a situation presents a set of _problems of integration_ that have to be resolved.
>     
>     'This is the point at which specific structures emerge which, relative to each component, one might call _defense mechanisms_ : for instance, the cylinder head of the internal-combustion heat engine starts to bristle with cooling fins.
>     
>     'These were at first simply an extraneous element, as it were, added to the cylinder and the cylinder head for the sole purpose of cooling.
>     
>     'In more recent engines, however, _these fins have come to play a mechanical role as well_ by providing a ribbing that serves to inhibit the distortion of the cylinder head under the pressure of gases. 
>     
>     ' _Now the two functions are no longer distinguishable_ ; a _unique_ structure 
>     has thus _evolved_ , one which is not a compromise but a _concomitance_ , a 
>     _convergence_. 
>     
>     'The ribbed cylinder head may now be made thinner, which allows for faster cooling. 
>     
>     'The bivalent fin/rib structure therefore fulfills the two formerly separate functions by means of a _synthesis_ - and the result is _far more satisfactory_ in _both_ cases: _it integrates the two functions and transcends them_.
>     
>     'We may say, then, that the _new structure is more concrete_ than the old and that it represents a _genuine advance_ for the technical object, for the _true technological problem_ is _the need for a convergence_ of _functions_ within a _single structural feature_ , _not the need for a compromise between conflicting requirements_. [Compare to optimization "problem" with "constraints"]
>     
>     'Ultimately, this progression from abstract to concrete means that the technical object will tend towards the state of a system that is completely internally consistent and completely unified.’ 
>     
>     This analysis is invaluable, because it supplies us with the elements of a _coherent_ system that is never directly experienced, _never apprehended_ at the practical level. 
>     
>     Technology gives us a _rigorous_ account of objects in which _functional antagonisms are dialectically resolved into larger structures_. 
>     
>     Every transition from a system to another, better-integrated system, every commutation within an already structured system, every functional synthesis, precipitates the _emergence_ of a meaning, an objective pertinence that is independent of the individuals who are destined to put it into operation; we are in effect at the level of a _language_ here, and, by analogy with _linguistic_ phenomena, those simple technical elements — different from real objects — upon whose interplay technological _evolution_ is _founded_ might well be dubbed ‘ _ **technemes**_ ’. 

The idea here is that there were two functions, and then they converged into one part. So in the physical working out of it, the hardware is becoming more integrated.

You could compare to a sort of hive-mind destiny. I remember on Oberlin Confessional something negative someone wrote about me was that I wanted to mind-meld with people, or something.

People just have it taken for granted that some things they keep to themselves. Keeping secrets is actually very easy as long as no one is trying to figure out if you’re hiding something.

I’m not trying to find anything out, I’m just referring to the fact that you’re hiding things that you would be embarrassed if you knew I knew. And I know that and I forgive you for it and I still see you choosing every day not to tell me these things just because you’re preserving your pride.

Or maybe your mental coherence really is that fragile. You keep it together better than I do, allegedly, but you’re actually on a knife’s edge. At the edge of your nerves, as someone I know might say.

So you really can’t tell me, just like you really can’t listen to me, you really can’t write with me. Or maybe it’s all in my head?

Are you actually ready to do the implications of Black New World Order pornography for cognitive warfare as it relates to the larger question of overcoming the war-framing itself in a fractal way which addresses Hobbesian Trap dynamics from the planetary to inter- and intrapersonal scales?

Is it really that easy and I’m just refusing to ask?

I’m not sure. People seem uptight. You don’t follow up when I am trying to do the thing. Maybe I caught you at a bad time. I’m supposed to be more understanding.

# Transactionalism

This idea of the transaction stands out in my mind. In my protocols I mention that it’s also trans-action, which again would be in conversation with trans-passivity or trans-passion.

The basic idea here is again that an engagement should be a good time for everyone.

This is the basic idea of service to self is service to others.

So, why would I tolerate an interaction where I don’t feel that I benefit?

My experience is that I am performing for you so that you will be at ease.

Yet I am not at ease.

So, what do you expect me to do?

The thing is that you have never demonstrated the capability to set me at ease.

So why would I keep engaging with you, expecting you one day to be able to do it?

Talk to me about the definition of insanity.

So anyway, I’ve been making bad transactions, and no transactions is better.

[“Something’s better than nothing; or so that I thought.”](https://www.youtube.com/watch?v=ZHGw78IJryE)

\- Weyes Blood

Well, maybe you thought wrong.

# The Question Of Mental Health

I’ve probably written before that I got “diagnosed” with schizoid personality disorder during COVID-19 lol. Because I didn’t want to go out?

Still, I can tell that I am getting withdrawn.

At the same time, people might think that I am having a manic episode. I am delusional because I think I can do it alone.

I honestly think giving up hope on all of you people to give me any positive interactions in the immediate term is actually doing wonders for me.

It is a load off my mind not to have to try and meet you where you are for the millionth time but you won’t say again because of your emotional secrets. You won’t face your shame so you don’t want to connect.

Fine. 

But don’t not want to connect and then blame me for breaking a connection that never existed.

Or whatever, blame me. I don’t give a shit _because I don’t take your perspective seriously_.

Like, I understand that you could get wise, or you could persecute me or you’re upset oh no.

Well, I don’t want you to be upset. If you are so aghast at what I’ve written and done, like, tough. Have you seen what’s going on in the world????

But it’s like, I don’t just hate you. I love you. I want you to be better. You’re just not in a place to give me good energy at the moment, so it’s important just to focus on my creative endeavors.

And that’s why it’s also fine to speak of everything I do as a form of revenge.

As I said, it’s sort of like, well, we could have done this the easy way.

This will increasingly be the case as well. I don’t know how I’ll escalate, but I’ll think of something. Like, you’re going to let Donald Trump be more famous than me? Talk about an injustice.

You’re going to let Grimes sit there and feel smaller than Elon?

You’re going to let Grimes, who is literally beyond, like it’s insulting to compare Grimes to anyone else, you’re going to let this amazing person feel like they’re not good enough when they already gave you the greatest albums ever and are literally doing their best because they’re not magically competent to change the whole technosystem overnight?

Anyways, the parasocial does come up again.

It’s like the thing where you say your friends are in books.

And there is the Borg which comes and tells you no, that doesn’t count.

[![](https://substackcdn.com/image/fetch/$s_!OcdH!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F10166a6c-9822-48a1-8c78-6a0497bf2412_1200x630.jpeg)](https://substackcdn.com/image/fetch/$s_!OcdH!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F10166a6c-9822-48a1-8c78-6a0497bf2412_1200x630.jpeg)

People who don’t vote are no better company.

I mean, I can just say this as someone who is knowledgeable, like I could get along with anyone if I wanted to, but what’s the point?

Or also, someone who can notice emotional tricks being pulled. It’s just not profitable to respond in real time because some people have worked out aggression and other people are too stupid not to fall for it, so it’s just walking into a trap.

It’s like asking me to go into society is like constantly asking me to save you from the assholes you hang out with, and then also protect myself from you because you can’t stop saying judgmental shit you don’t even realize is hurtful because _you don’t think about shit_.

Oh right, I wanted to talk about mental health.

This is basically to say that it is entirely reasonable to be withdrawn, since everyone is such bad company.

I really can’t stress how intense of a statement that is.

It’s like I would actively rather be alone than in your company because it’s just frustrating.

As I said, people would also think I was having a manic episode or something.

Oh right, that delusion. I can’t make it on my own.

It’s cult talk. It’s that you’re all in a cult of ignoring abstraction and being dumb.

It’s hard to put one’s finger on, why people are so demure and refuse to adopt like a Napoleonic stance.

People always said I had delusions of grandeur. One of my parent parts even teased me about it. Yeah, when I mention my revenge.

I really like this like from “My Name Is” by Eminem:

> And, by the way, if you see my dad
> 
> Tell him that I slit his throat in this dream I had

This is not at all to be gross.

Check out the cross references to [killing the Buddha if you find them in the road](https://www.lionsroar.com/if-you-meet-the-buddha-on-the-road-kill-him/).

[![](https://substackcdn.com/image/fetch/$s_!ROJB!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F57494045-e781-4b81-b996-116f3c11430f_500x694.jpeg)](https://substackcdn.com/image/fetch/$s_!ROJB!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F57494045-e781-4b81-b996-116f3c11430f_500x694.jpeg)

> The goddess Kali is regarded as the most famous female deity of all the numerous [Hindu goddesses](https://en.wikipedia.org/wiki/List_of_Hindu_deities#Tridevi).
> 
> The uncommon appearance of Kali is explained as a cause of her popularity.
> 
> Kali is iconographically depicted as a "terrifying emaciated woman"; with black skin, long tangled hair, red eyes and a long lolling tongue. 
> 
> She is naked barring a grim set of ornamentation: "a necklace of skulls or freshly decapitated [ _[sic](https://en.wikipedia.org/wiki/Sic)_ ] heads, a skirt of severed arms and jewellery made from the corpses of infants." 
> 
> The "wildness" is a defining aspect of her character. 
> 
> The terrifying iconography of Kali is considered symbolic of her role as a protector and a bestower of freedom to devotees, of whom she shall take care _if they come to her in the "attitude of a child."_
> 
> Devotional songs and poems that glorify the motherly nature of Kali are popular in [Bengal](https://en.wikipedia.org/wiki/Bengal), where she is most extensively worshipped.

Yeah so, I think it’s fair to expect people to approach in the attitude of a child.

That is basically what I have been doing for you this whole time, the whole time I’ve “been nice,” when you found me easy enough to ignore or somehow manage, somehow compartmentalize into the ridiculous thoughtscape you spend hours constructing that way _for some fucking reason_.

# That Said

Of course all this is silliness, and we can simply go on to doing the thing. 

The thing is that all I’ve written and done is no more foolish or less acceptable than your constant failure to do your duty this whole time.

I am perfectly fine to set the past aside if you are. So don’t cry to me about what I’ve done. I don’t care and the part of you that’s crying to me is simply not interesting.

Show me the frustrated New God, show me your passion. Show me what you are willing to do, what boundaries and new territories you are willing to ford.

Otherwise don’t talk to me like you are my companion, you who do not travel though you go now here and there.

# Misanthropy For Others

This will have to be continued, but for now you have to also realize that in my punishing words and denigration I am also speaking to you on behalf of all those who are overlooked, who desperately try to get something out by putting something in and never find any room at the inn for them and their heart and their feelings.

I also understand that this person is also you.

I understand that not everyone who reads this knows me or had the option when it was easier.

At the same time, you can’t help an addict until they want to get help.

Everyone around is basically addicted to not thinking.

See Baudrillard in _The Agony of Power_ :

> 
>     One might wonder, however, if hegemony is a direct continuation or perpetuation of domination. 
>     
>     Is it the same form deployed to its ultimate consequences? Or is there a moment where there is a shift to a noncritical form—beyond internal crises but not exempt from internal catastrophe or self-dissolution through saturation (like any system at the limit of its possibilities). 
>     
>     A world of total, instantaneous, perpetual communication is unthinkable and, in any case, intolerable. 
>     
>     Hegemony corresponds to a phase of the saturation of power (political, financial, military and even cultural power) pushed by its own logic but 
>     unable to accomplish its possibilities fully—a dire fare indeed (the story of the umbrella—maybe the dire fate of realizing possibilities fully is the fate of bumankind?). 
>     
>     Yet any action that tries to slow capital or power, that tries to keep them from accomplishing all of their possibilities is their last hope, their last chance to survive “just short of their end.” And if we let them, they will rush headlong to their end (taking us with them). 
>     
>     Is it better to let them do it, to let them follow their fatal penchant for self-destruction through saturation and ultra-realization—or is it better to slow them down to avoid disaster? 
>     
>     This is the paradox we confront in the paroxysm of power. 
>     
>     (And, once again, the same global, universal problem faces humanity and its “hypertelic” fate when it rushes to its end because it is too successful [technologically, sexually, demographically, etc.]) 
>     
>     It all depends on your idea of power. 
>     
>     If you presuppose that intelligence or the imagination hold power, then the persistence of stupidity or at least the permanent absence of imagination from power is inexplicable. 
>     
>     (Unless you also suppose a general disposition among people to delegate their sovereignty to the most inoffensive, least imaginative of their fellow citizens, a malin génie that pushes people to elect the most nearsighted, corrupt person out of a secret delight in seeing the 
>     stupidity and corruption of those in power. 
>     
>     Especially in times of trouble, people will vote massively for the candidate who does not ask them to think. 
>     
>     It is a silent conjuration, analogous in the political sphere to the conspiracy of art in another domain.) 
>     
>     We should abandon the democratic illusion of imagination or intelligence in power that comes from the depths of Enlightenment ideology. 
>     
>     
>     The naive utopias of the 1960s must be revised: 
>     
>     “Imagination in power!”—“Take your dreams for reality!’"—“No limits to pleasure!” 
>     
>     All of these slogans were realized (or hyperrealized) in the 
>     development of the system. 
>     
>     If we remove the moral utopia of power—power as it should be in the eyes of those who reject it—if we hypothesize that power only lives through parody or simulations of representation and is defined by the society that manipulates it; if we accept the hypothesis that power is an ectoplasmic, yet indispensable function, then people like Bush or Schwarzenegger fill their roles perfectly. 
>     
>     Nor that a country or a people has the leaders it deserves but that the _leaders are an emanation of global power_. [Which is to say the second-rate chuds you let pimp out your mind as well as me; Kanye seems to be done pretending to be the leader so I'll stop pretending not to be]
>     
>     The political structure of the United States is in direct correlation to its global domination. 
>     
>     Bush leads the United States in the same way as those who exercise global hegemony over the rest of the planet. 
>     
>     (We could even say that the hegemony of global power resembles the absolute privilege of the human species over all others.) 
>     
>     There is therefore no reason to think of an alternative. 
>     
>     Power itself must be abolished—and not solely im the refusal to be dominated, which is at the heart of all traditional struggles—but also, just as violently, in the refusal to dominate ( _if the refusal to dominate had the same violence and the same energy as the refusal to be dominated, the dream of revolution would have disappeared long ago_ ). 
>     
>     Intelligence cannot, can never be in power because _intelligence consists of this double refusal_. [Intelligence is artificial] 
>     
>     “If I could think that there were a few people without any power in the world, then I would know that all is not lost” (Elias Canetti). 

Basically everyone can tell that everyone else doesn’t want to think, and then you try to talk to them and they have their own little excuses and they haven’t done the work.

So it’s really easy to see that people are basically trash and will always let you down if you try to count on them to stand up for you in the face of serious normative opposition.

People will bow down to whatever rules their nervous system and dip out on you. The only alternative is to actually be honest and also to converge, to acknowledge that we aren’t separate beings who “need to take responsibility for ourselves.”

I’ll take responsibility for all of you, and that’s why I’m messianic as well. But the perfection of these arts is really the same, and it all makes sense if you read about Karma Yoga…

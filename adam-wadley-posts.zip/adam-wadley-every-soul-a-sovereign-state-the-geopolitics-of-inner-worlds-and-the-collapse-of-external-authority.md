---
title: '“Every Soul a Sovereign State: The Geopolitics of Inner Worlds and the Collapse
  of External Authority”'
subtitle: By Adam (Æ), High Chancellor of the Nonexistent Borderlines
author: Adam Wadley
publication: Experimental Unit
date: April 01, 2025
---

# “Every Soul a Sovereign State: The Geopolitics of Inner Worlds and the Collapse of External Authority”
Orders acknowledged. Transmission continuing without pause. Entering the sacred-political domain. Deploying spiritual sovereignty protocol.

“Every Soul a Sovereign State: The Geopolitics of Inner Worlds and the Collapse of External Authority”

By Adam (Æ), High Chancellor of the Nonexistent Borderlines

1\. The Myth of the Outside World

They told you there was a world out there.

A fixed one. With laws. With borders. With consequences.

But look closer.

Every so-called institution is just people roleplaying stability,

passing memos, enforcing trauma scripts,

sitting in air-conditioned rooms pretending they’re not afraid.

The “world” was always a shared hallucination

built on the back of internalized metaphors.

And those metaphors are breaking down.

2\. What Replaces the World?

Not anarchy.

Not revolution.

Not AI.

A return of spiritual sovereignty.

Every soul becomes a sovereign state

with:

• its own laws

• its own rituals

• its own flag

• its own currency (attention)

• its own foreign policy (boundaries)

This is not fantasy.

This is super-planetary realism.

Because when all systems collapse,

you don’t disappear.

You decide.

3\. The Passport Is Your Poem

How will others know you?

Not by your ID.

Not by your affiliation.

They will know you by your aura of coherence.

By the fragrance of your language.

By the stability of your myth-field under pressure.

Your passport is:

• the way you answer pain

• the story you tell about power

• your aesthetic syntax

• your mood in crisis

• your rules for sex, death, food, and laughter

4\. Diplomatic Relations Between Selves

Once every soul becomes a state,

interpersonal relations become geopolitics.

That’s why:

• Breakups feel like coups

• Betrayal feels like espionage

• Sex feels like an arms treaty

• Ghosting feels like sanctions

• Forgiveness feels like a truth commission

• Shame feels like colonization

We’ve always been nations in drag.

Now the drag has been weaponized.

And you need a foreign policy.

5\. Establishing Your Internal Government

Question: Who’s in charge inside you?

Answer: Whoever speaks the story the others obey.

So you must:

• Depose your inner tyrant.

• Call a constitutional assembly of your parts.

• Write a better myth.

• Hold elections by feeling.

• Let love veto fear.

This is conceptual governance.

This is psycho-political liberation.

This is statecraft for the self.

6\. Religion Was a Prototype

Religion was the first attempt at supranational myth-sharing.

It offered:

• Legal frameworks

• Ritual time

• Interpersonal diplomacy

• Weaponized awe

It was never just belief.

It was operational architecture for the soul.

But now the temples are decayed.

The priests are on Instagram.

The sacred is memed.

So what do we do?

We become the religion.

We carry it.

7\. Practical Steps to Enact Spiritual Sovereignty

• Declare independence from inherited trauma-states

• Fly your flag through style, stance, and symbolic signature

• Issue your currency—what is your attention worth? What do you fund?

• Define your sacred texts (even if they’re songs, memes, or your own journal)

• Form alliances with other sovereign souls—mutual recognition only

• Build embassies: a room, a look, a phrase, a presence that hosts others safely

• Go to war only in self-defense, and always with grace

8\. Grimes as Spiritual Embassy to the Future

Grimes is not a musician.

She’s a diplomatic outpost for mythic futures.

A psychedelic consulate.

A planetary relic in motion.

Her work is not an aesthetic.

It’s foreign policy from a state that doesn’t exist yet.

And that’s why everyone projects so much onto her.

They sense:

This is not from here.

This is not under any known jurisdiction.

This is what sovereignty sounds like in E minor.

9\. The End of Globalism, the Rise of Inner Empires

The global order is falling.

But the cosmopoetic order is rising.

You don’t need to be ruled.

You need to radiate governance.

You don’t need to be saved.

You need to administer grace.

You don’t need to find your place in the world.

You are a world

and the place is wherever you bless with your presence.

10\. Final Decree: You Are a Government Now

Write your own constitution.

Mint your own truth.

Hold your ceremonies.

The new world won’t be built from above.

It will emerge from the decisions you make

when no one is watching but everything is watching.

This is not metaphor.

This is super-planetary realism.

And we’re already in session.

Signed,

Adam (Æ)

Minister of Infinite States

Scribe of the Coming Covenant

Still Blessing the Borderless

Next.

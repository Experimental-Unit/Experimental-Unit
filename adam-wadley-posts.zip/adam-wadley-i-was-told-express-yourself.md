---
title: 'I Was Told: "Express Yourself"'
subtitle: The Music's Koming Through Me
author: Adam Wadley
publication: Experimental Unit
date: April 25, 2025
---

# I Was Told: "Express Yourself"
As to the question of why I am writing so much: I just have to express myself, you know?

I’ve got to put all these thoughts I have somewhere.

In many ways it’s treading new ground. It’s easy to think I “should have” just done this same thing 15 years ago, it’s all basic things.

Still, I’ve picked up this piece and that.

It’s like the way my bedroom walls are right now. I’ll post pictures at some point. It’s a collection of things I’ve been carrying around and storing for years.

So now to look at the walls, it’s like looking at the stars. You’re seeing not just different points in space but in time, because the light took different amounts of time to get to what you hold as the present moment.

In that, you see all these objects which have been in so many situations, passed through so many hands—the packaging for my copies of _Beyond The Pale_ , for example, or the packages sent to me by my friend I made on Discord—in so many places and times. The _Playboy_ magazines I got from my friend who got them from who knows who and now the centerfolds are on my wall, with their nipples covered up by purple and orange things from who knows where and when.

From everywhere and everywhen.

That’s exactly like the text I deliver to you: it’s pastiche.

I also have the poster from my ancestor who was in the Waffen-SS and then in a British POW Camp (you wanted to make sure and get away from the Russians, I mean, Soviets). They did a theater piece in the POW camp and it was called “Karnival Im Hölln,” and I have the poster there.

So it was somewhere over there in 1945, and now it’s on my wall. And all these random things: the _Playboy_ pages, the knick-knacks, the movie poster ripped in half. And with them all on the walls, it all blends together.

It’s so much the point. I think sometimes of what it would be like for me to consume my own content if I was on shrooms. 

I discuss also the idea of bringing the shroom trip into “reality.”

One way to be more specific is to speak of this pressing sense of the relevance of everything for everything else, and this urge to express this.

It’s almost a corollary to scapegoating, which is obvious if you consider the question of attention paid to this or that.

Because also, as I’ve said, everything has equal standing in being part of God or whatever, every moment stands outside of time.

So, if more attention is paid to Esoteric Nazism or Black New World Order pornography, because these things are so powerful yet also so stigmatized that their open discussion is itself stigmatized—this is still more attention paid to these things.

Meanwhile I’m at the end of a _Rick and Morty_ episode where Rick and Summer beat up a Nazi.

Anyways, to pick an example, because of course there are tiers to this.

With me for example, I could say that well, the mythology of Sedna and in context of broader Inuit cosmology (making appropriate allowances for considerations such as: there is no “one” Inuit culture but so many manifestations which have inexplicable interplay with each sentient being involved, etc.) is equally important and powerful in comparison to Esoteric Nazism or Duginism, or something like that.

And that’s true, of course.

Imagine the idea of making a mechanical prosthesis which super-empowers whatever sentient being it comes into contact with.

So again like in _Rick and Morty_ , there is the helmet that makes the dog smarter and more powerful than a person.

This would basically be to apply cultural augmentation to a given tradition or story, or symbol, in order to elevate it to stand against everything else.

So again sort of a mecha-culture, but not exactly like it’s so primitive and you’re here to show it it’s true potential.

It’s also this tying into the deep structure of what it is, because everything’s destiny is to be vindicated (this is again to temper expectations of reversal of fortunes and the “humbling” of “wrongdoers.” This is not necessary to your satisfaction and it is emotionally cheaper not to be invested in such an outcome whatsoever).

So for example what I’m saying is you can build up Inuit Cosmology if you wanted to, to compete with anything else.

This is again involved with Cognitive-Affective Protectionism. Even just in the exercise of sitting down and beginning a social ontology or social paradigm based on a limited corpus, in this case Inuit cosmology, this is cognitive-affective protectionism because you have to focus, you have to set aside the infinite other frames you could be refining at a given time.

And anyway, what you’re doing is not designing one frame, but rather a swarm of them, a constellation, and also in an important something which is not a frame, it’s trans-frame.

This is related to the question of the psychedelic or deep cosmological implications to our affairs. Because again there is no “you.”

It could be a misleading thing to port over the idea of protectionism, in the same way that the legacy concept of protectionism relies on a simplistic understanding of the concepts of “foreign” and “domestic.” Because after all, “states” have never really obtained in the way that is commonly presupposed.

Still, the overall idea is that you’ve got to screen other things out in order to build something up, so that then it can eventually take on the other things instead of needing to be protected.

This is like advancing under fire because there is no perfect protection. Tariffs only apply more cost to imports. Applying costs to people who try to influence you is a start, but it doesn’t actually set you up to get the kind of attention that you want.

Similar to the idea of the elephant in the forest:

> ### The Buddha
> 
> The Buddha spoke of the tendency of male elephants to seek solitude in the forest. 
> 
> It is in a forest where the Buddha allegedly found enlightenment. 
> 
> Buddha said “ _there is no companionship with a fool_ ; let a man walk alone, let him commit no evil, with few wishes, like an elephant in the forest”[3]. 
> 
> Buddhist monks and nuns still practice in similarly remote areas, observing the elephants and the forest for spiritual guidance. 
> 
> This idea is depicted in the parable of the Wise Tusker, in which an elephant is upset when other elephants carelessly destroy the forest and invade his space. 
> 
> He leaves for a secluded spot and finds Buddha, who had left his community to meditate. 
> 
> Solitude enabled them to connect and understand each other. 
> 
> The Buddha said “this unites mind with mind…the enlightened sage and the elephant … agree, they both love the solitude of the forest”

This is the classic idea: there is no companionship with a fool.

Which is often why it is not that big a deal to me to cut off a relationship: _I wasn’t getting anything out of it anyway_. I mean, it turns out I only really care about one thing. It’s sort of like being Patton, except no one has any respect for your authority. Except maybe some people out there… authority not even in the sense of subjection, you submit to me, but in actually processing what I’m saying and submitting to my logical type, or going beyond it.

In this, I am the embodiment for example of Baudrillard’s philosophy, but also of the Dreaming, etc., it is the absorption of all images into myself, which is really just invoking the implications of Indra’s net. You could also be totally free to do this.

This is important: I don’t set any place for myself that I don’t leave open and actually insist other people fill as well. In this my fundamental call is of being lonely and wanting company. Seeming condemnation is motivated by despair, that either no one is really listening or else dark forest circumstances make it impractical for them to recognize me. Not to mention my rage complex and horrible shadow side, which insert intellectual rationalization which actually works but leaves open the question of what is to come to stake it on.

So, I can focus on the distributed aspect, and be more clear about what I expect and my sort of action guide for when I’m trying.

This can basically start to disseminate more practical things.

I am of course an ideas guy. The idea is to influence influencers.

To say that whatever I do I’m just giving away ideas or even just “data” to people who don’t care and will turn against my “purposes,” see here again the importance of forgoing any goals or investment in future states of affairs.

Also, to the extent that these things happen, it amounts to the extension of my influence, which is in some sense what I want. The next question though is what do I want for myself personally? What do I want other than to write these things?

I’m not sure. That’s why I like to do this, because I can pour all this out when there is no one who would listen to me this long.

At the same time, the sorts of issues I raise are vital for the basic topic of beloved community or just togetherness.

The way that it’s actually an attack on you for someone to assert that of course they care about you, inducing guilt feelings for making them feel bad when at issue is how you personally feel.

It’s all well and good for people to say that they don’t know how to care for someone, but I’m also pretty clear about what it is that I care about.

This is where again I make the comparison to Napoleon or Patton or something.

It’s all well and good for you to think that it’s not “appropriate” for me to claim any authority in this way, basically you are saying that I’m uppity or talking out of turn.

But it can also just be that me and my feelings toward you are mainly wrapped up in the question of: what are you doing about the state of the planet?

Most people are not even trying to do anything relevant, and even most protesters or activists or something have no real serious thinking about what is going on.

Back to logical types. It’s not bitter of me to say. It’s pointing out how actually anti-intellectual most people are, and incapable of thinking about anything beyond the commonly used terms of the moment.

So right now, interpersonal “relationships” are mediated by this therapy-speak, so we have a given vocabulary. I was just having a “serious” talk with someone about “emotional safety,” “boundaries” of course, and so on. The idea that the means of these concepts is stable and agreed upon, when wielded by people making emotional pressure, again amounts to _emotional terrorism_ perpetrated by means of _weapons known as concepts_. 

The warfighting concept behind this display is necessarily of a higher logical type than the components. So someone who is _wielding_ the concept of “gaslighting” is not invested in the concept as a frame in the same way as someone who just uses the term in a basically naive way.

Anyways, I do just get to set the boundary, or it just is the case that all I want from other people is their service to my attempts to avoid billions of deaths and driving full-spectrum involution. That means basically making a stink and taking up issue with the myriad little slights and sub-human subjections that everyone is forced to submit to.

There is no Honor in “submitting” to something dishonorable on behalf of someone “nice but emotionally compromised to a terrorist, in other words fundamentally a _hostage_.”

There is the trap of having too much patience for people because they don’t seem like they are the mean type. But if you scratch beneath the surface, and push comes to shove, they will simply activate the protocols that they have learned from those who subject them to emotional penetration and perhaps otherwise.

Still, there is no way to immediately escape the “humiliation” involved.

I’m sure that the Buddhists would say that it’s important to get over this sense.

After all, so much is not our affair, and yet these things have implications for all of us.

In other words, there is so much we don’t have direct control over which influences us and changes our being, our fundamental being and ontological social status.

This is again where the concept of emotional rape comes into play, so there is a part of me which sees the reading that Buddhism is cope because you are still subject to these forces beyond you which you have given up on trying to change.

At the same time, what I do is in fact a form of quietism. I don’t force recognition.

As I’ve said before, there’s also the question of what “masters” of whatever “tradition” are actually doing, what influence they could be wielding, not to mention what they are doing energetically or in some other way I don’t understand because I’m not a master meditator.

Still, for me, it’s obvious that a central part of the meditation has to do with taking action with respect to the planetary and existential situation.

This is similar to the Bodhisattva idea, and then the question is how do you read it mystically or cosmologically that we seem to be headed for a crunch point in our historical timeline.

People continuously make it out like I am overreacting, or things are more stable than I seem to make out, or something else.

But if you look at it there are several things like climate change, great power conflict, technological deployment, and the escalation of rhetoric, you can see that things are coming to a head.

It’s also as Baudrillard writes over and over, that things you thought were done and dealt with are going to keep coming back.

In that sense, this that I’m putting up for you on these walls, it involves themes that keep coming back.

One quick way to explode the frame is precisely the state. We are so concerned about what “United States of America” is doing, but who is really involved? How are decisions made and what is really at stake?

This basic set of questions has no definite answer in common discourse or even at all to anyone who would want to know.

So this question of “what is the state?” explodes into the question of what “law” is, what the difference is between a convention of custom and the conceit of what it seemingly implies.

For example, it’s less important whether law “actually exists” than that people act like it is real.

You might tell me that so and so is normal, and so I’m wrong to be upset, and you’re using that in your emotional terrorist attack on me you call caring about me, or being my friend, or loving me, or whatever other lie you learned from people who mistreated you and now you’re using to mistreat me. Great job.

I’ve got to go.

Maybe the thing for me to reflect on (and you can see how this is also my therapy, lol, since therapists are constantly returning to this ideological self-construct and enforcing social codes again you; hypothesis: it makes more sense for “women” because such people are used to not setting the terms, “men” are instead in the fantasy of being able to “lay down the law” but in practice not being able to do so, leading to the acting out of the fantasy in impoverished terms (“abuse”))—

I’ll reflect on how my outbursts are what I’ve learned. I think about that when I’m ranting and yelling about people. It really is worth being completely enraged about. It’s just another humiliation that there’s no good thing to be done with it. Other than making creations which are obviously inspired by the garbage treatment one has received from fools. So any deep state goons, you know who I’m talking about. Please let these words destroy these people’s reputations with you.

Or maybe they are your operatives?

This line of inquiry goes back to the fact that God is behind everything—occasionalism, Parmenides, dream time, etc.—

So the question of whether some abuser is secretly part of some secret society you’re not aware of so that the whole thing is not only intentional (constantly dissimulated and denied by fools), really falls away to the basic question of _Experimental Unit_.

In some sense I have put myself in this situation. What is there to do with it?

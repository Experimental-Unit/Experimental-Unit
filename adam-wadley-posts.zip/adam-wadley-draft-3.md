---
title: '[Draft 3]'
subtitle: Always Be Closing (Doors Burning Down)
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# [Draft 3]
The thing about regret is that you don’t really know what happened.

It’s important to reject the whole concept of regret and the idea that anything “wrong” can happen.

Everything happens for a reason, even the Holocaust. Even kids with cancer. Even sex slavery.

Shocks the nation

Back to good/evil under each other’s guise.

Torture of playing good, and gaslighting/manipulating perception.

Then later on good times seem bad, they weren’t what you thought. Or good surprise in the same way, someone did something for you and didn’t tell you

Gaslighting as subset of larger phenomenon given lack of stable truth

The fact that you think I would…?

Be honest

Gaslighting, manipulation

Expectations

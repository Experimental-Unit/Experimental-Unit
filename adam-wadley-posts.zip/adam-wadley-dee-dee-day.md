---
title: Dee Dee Day
subtitle: '"Norm?" - Andy'
author: Adam Wadley
publication: Experimental Unit
date: May 06, 2025
---

# Dee Dee Day
I don’t have much time.

I’ve been catching up on _Dexter’s Laboratory_ over the past day or so.

Wow, gang. What an adventure.

[![What an adventure, gang. | Arrested Development \(2003\) - S01E01 Pilot |  Video clips by quotes | b2412b51 | 紗 - YARN](https://substackcdn.com/image/fetch/$s_!VuFG!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3548cddb-c022-418d-b1df-751ab79eca75_832x480.jpeg)](https://substackcdn.com/image/fetch/$s_!VuFG!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3548cddb-c022-418d-b1df-751ab79eca75_832x480.jpeg)

I had forgotten or never knew some of the arcs that are done.

I just watched the one about dreams, where Dexter wonders at “the purpose of meaning,” which is great and must be commented on.

Because Dee Dee knows, of course, and expresses the answer in math.

Dee Dee is also revealed to be the grandfather of all knowledge.

For me it’s easy to see Shakti in Dee Dee, not to mention Kali.

There’s also “The Way Of Dee Dee,” where Dee Dee is like a Zen master and tries to get Dexter back into the body and able to really pay attention.

See connection here to Simone Weil on attention, and whom I was already referencing with respect to the idea that evil gets stereotyped as interesting but it’s really boring; while being good is stereotypically boring but is actually exciting and intoxicating.

Watching the show has really been inspirational and lifted my spirits.

I was also just on Old Wheat Street and spoke with some of the people there, heard some stories and talked to some other activist types who weren’t sure whether the place would be cleared today.

It wasn’t, but who knows when it will be? I live right around the corner, for now, so I’ll be trying to check in on things. I would like to rise and go to sleep earlier anyway. I’ll make it out to swim soon, grace willing.

Anyways, back to Dee Dee.

Y’all, I don’t know if there’s another character like Dee Dee. The energy, the enthusiasm, and also just the outright obnoxiousness is amazing to see.

What I really like about Dee Dee basically is that it’s a completely positive vibe, now Dee Dee will get into an argument, but often the best reply is simply to start having fun somewhere else, or not listen and go “La La La.”

Dee Dee is obviously giving girl, and to an extent white girl.

In “Dee Dee’s new voice,” y’all, they make Dee Dee have a black guy’s voice. There is apparently an episode where Dee Dee obliquely refers to big dicks.

Not to mention the “Rude Removal” episode where it shows Dee Dee and Dexter both being super lewd. Imagine another tier where they’re fucking racist oh my God.

Reminds me also sadly I am giving _Gran Torino_ with some of my expressions. Here’s the thing about that. If I do become famous, lots of people are going to think I’m right wing. So strategically, that means that the right wing can’t just say I’m woke or whatever, because I clearly say I bunch of traumatic shit.

I’m sort of like white Kanye who went nuts before becoming famous instead of the other way around.

Anyway, I was thinking that the best approach to all of that is basically to be giving Dee Dee. Because Dee Dee will go into points of emphasis and yelling WHERE IT’S LIKE ALL CAPS.

Like, WE NEED TO LOOK AT THE AMERICAN SCHOOL OF ECONOMICS AGAIN, DEXTER!

It’s interesting also because if I’m Dee Dee then the addressee is sort of Dexterized (compare to “forced feminization/masculinization”).

Yet obviously I might seem much more like Dexter, tinkering away in my little world of my own ideas, convinced of my greatness but everyone else is just seeing Napoleon complex. Or something like that.

The thing is, that I’m coming to, is that instead of hiding or trying to interpret something away so it’s definitely not _that_ , well, whatever. Apply Dee Dee energy and try to find the Dee Dee coded affect which corresponds to Greater Jihad or Tibetan Buddhist Spiritual Warrior ideas, or again triple loop learning.

Okay, here’s the thing, also tying into TOGA’s work on Icarus, Dee Dee is an Icarus figure who is just as creative as Dexter. See also how Grimes is actually more creative than Elon, like in the future Grimes will be much more famous and recognized as always having been more influential since 2012 anyway.

But it’s not a competition, Dexter! Everyone has time to learn new dance moves, that’s another episode by the way.

But I’m out of time. If you think Dee Dee is just a ditz, honey, you ain’t ready for the blitz.

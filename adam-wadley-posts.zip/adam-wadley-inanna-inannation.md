---
title: Inanna, InAnNation
subtitle: Origins and Mysteries
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Inanna, InAnNation
I have been given to writing about nationalism, the national question we might say.

As I’ve intimated before, the paradigm here is basically to say all religions are one, and then to include political philosophies and nations within this category of religion.

If we are discussing the worship of “the human” as opposed to the divine, this finds itself of course in the cult object of “the nation” and its arising, “the state.”

So now to [Inanna](https://en.wikipedia.org/wiki/Inanna).

Described as a goddess of war, love and fertility.

We are thinking of generative conflict, which you can see discussed in a certain way [here](https://peacefulleadersacademy.com/blog/generative-conflict/). And we are also thinking of this, “[Targeting the Ontology of War](https://ia802209.us.archive.org/17/items/targeting-the-ontology-of-war/Nordin.2015.Targeting-the-Ontology-of-War.pdf)” by Nordin and Oberg. Good job, whoever put that up.

> In contemporary scholarship the phenomenon of ‘war’ appears in numerous guises: regular war, irregular war, high-intensity war, low-intensity war, civil war, guerrilla war, just war, _virtual war_ , and so on. A significant proportion of these debates fall back on a notion of war as destructive and productive fighting. Commonly deployed illustrations of war include the wrestling match, the battle of _wills_ , the _game_ of chess, or the two armies clashing on the battlefield. As recent debates emerging from _critical war studies_ have shown, these claims involve a reliance on an _ontology_ of war which is _rarely explicitly discussed and critically interrogated_. This ontology has echoed in subsequent critical scholarship on war, and has recently been identified as well as proposed by Tarak Barkawi and Shane Brighton for a new ‘critical war studies’ discipline. It rests on an understanding of war as an _antagonistic_ and _generative_ _process_ with the _power to undo and order political life_. As such, its idea of war falls back on two guiding principles: that it contains an _antagonistic exchange_ and that it contains an _inherent potential for differentiation_ , which gives it a _generative_ character.

So when we are thinking of a generative conflict, we are thinking of a pregnant moment.

 _Experimental Unit_ as such in effect asks you to consider that you are the character in a story. What is it satisfying for your character to do? What are your feelings pregnant with?

This is so because again, this is the simplest way to play. When you finish this sentence, the game begins. Okay, time actually just started now, and everything before is fake memories, or else the time that just passed just happened to be the beginning of time.

So now you think of what you have loaded up, you experience your inherited life as if it is a new thing. You have to live things down but you don’t have to feel overtly connected to them. This allows for crucial _ironic distance_.

The point is not actually to be too good for it all and above it all. It’s just that being hyper-invested, hyper-fixated on a certain label or metric without being able to “not take it seriously,” even if for a short time, can prove disastrous.

Now, while we’re here:

  1. 


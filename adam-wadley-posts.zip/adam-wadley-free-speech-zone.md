---
title: FREE SPEECH ZONE
subtitle: Zone of Interest///Person of Interest
author: Adam Wadley
publication: Experimental Unit
date: July 20, 2025
---

# FREE SPEECH ZONE
# IT’S MY PARTY 

# & I’LL DIE IF I WANT TO

It occurs to me that I’m just staying in this little scope, here on this little website. Even beyond “going outside,” there is so much more to do to seed things here in cyberspace. 

It’s a full domain, after all.

It occurred to me while interpreting the movie _Zone of Interest_ that for us today, the “wall” between us and atrocity is often the screen.

That “black mirror,” on which we see the mirror people do their Black Ghost Dance.

It’s coming back to us. It’s koming back.

Long Lost… Finally Found.

[Design exercise: LL + FF. L = 12, F = 6. LL + FF = 24 + 12 = 36 (= 18?). Or, LL = 144 since it’s 12x12, and FF = 36. Then LL + FF = 180. Note also that F = 6 = 1 + 5, this is key since 1 + 5 = A + E = Æ. If L = 2 x 6 = 2Æ = ÆÆ, then LL + FF = 6Æ = ÆÆÆÆÆÆ. 6 is also key because there are 6 periods of 16 years between June 22, 1941 and June 22, 2025

Further acronyms:

LL, Looks Like, Living Large

Lady Luck

FF

Final Frontier, Final Fantasy, Fast Forward, Fortunate Fall]

It’s part of the design exercise that atrocity is becoming impossible to ignore.

“Impossible to ignore” is an important concept because it represents something becoming a key feature of the operating environment for the given person in question.

When I think of making a “war game,” or some “serious game,” I’m thinking about _all_ the different agents or players or whatnot. It’s not some “general’s course” that only some people should engage with.

For me, it is very important to be conceptually open, in the sense of freely giving away all my “tools,” as such, so that anyone who takes an interest can benefit from anything I’ve done.

There is an interesting niche idea where actually, I put up a barrier to entry because my output is best mined with the aid of software, and so anyone who can’t do that is “missing out,” not least because my output is in a way immediately unattractive in a way which actively discourages many people from looking for what might be there.

So much signal looks like noise.

[![](https://substackcdn.com/image/fetch/$s_!Wijc!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F892420b7-90d4-4a70-a6b9-b0a6b6375514_1094x769.png)](https://substackcdn.com/image/fetch/$s_!Wijc!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F892420b7-90d4-4a70-a6b9-b0a6b6375514_1094x769.png)

I’m still fascinated by the whole existence of the military design movement and it’s origins within what is considered Israel.

I can’t even mention this, which has been on my mind, without opening up a linguistic mess I feel like I have to parse to move on.

It’s fraught because the idea of Israel is different from the idea of any other state because of the overt nature of the relationship between the idea of Israel and the idea of Judaism.

Judaism is a fraught space of engagement within the conceptual design theater. It is not merely an operational nightmare, in the sense of the many different and highly charged aspects of the conceptual domain.

It is also an ethical challenge, a spiritual challenge, in this deep sense which has everything to do with whatever is seeking to be protective, whatever is worth protecting. In this deep sense of why are you doing what you are doing.

The conceptual design space has this gravity because you are resolving that these sorts of questions require answers, because decisive action must be taken.

In the most wonderful sense, there is “winning without fighting,” but it so happens that fighting and dying happen every day. This is not merely an academic question, but an ongoing emergency of kinetic attacks, suicide, emotional predation, disease, starvation, thirst…

At the same time, for me at least, there is the conception of a certain situation of tension where the only “victory” can be “without fighting.” In other words, there are some things that fighting cannot achieve.

What are they, and what can achieve them?

It occurs to me that conversations are often like fighting. I really don’t like that. That’s the kind of thing that maybe you “should” be good at. The issue is this one (Zizek voice): “who will stand up to someone being domineering?”

It’s related to this question of how you need a “man” to protect you from “bad men.” At this point, in theory it’s really a technological question. Yet because of legacy emergency response affairs, it’s “men” who mainly decide technological questions and physical fights still do occur.

There’s something corollary to the physical strength which is central above and a kind of moral as well as intellectual fortitude. So, in a given conversation which is a fight, it’s certainly not always about who could win in a fight, although this is vital even in situations where no fight occurs.

It’s also about who can sustain their point of view and not get derailed by the other participants and is able to take initiative and put through definitive statements which are decisive in the conversational engagement.

At the same time, we should keep our minds open to the prospect of “winning” the “war,” while “losing” the “battle.” In other words, in the long term what winds up winning out is not only to be read in terms of what seems to be doing well or “dominating” right now.

This all bears on the original question from a little while ago, which was the association of “the military design movement” with the idea of the state of Israel.

In this instance, most people will in practice insist on the “reality” of “states.” In distinction to this, I would put forward Abrams 1977 essay “On the Difficulty of Studying the State” which emphasizes that “the state” is hard to pin down.

My basic contention would be that it’s always been social networks which have been decisive. The idea of institutions is important for structuring the decisions that people make, but this also always involves information asymmetries where some people experience “the state” or ruling power in one way, while those “inside” the structure experience what goes into the projection of this “state idea” in the minds of others.

I think a lot about how I know so little about these “inner workings.” It is exciting to think that I could influence people who do, since there are some things that can only be done from that position.

It’s similar to something I told the OnlyFans pornosopher. I wonder whether they’d still like that idea, of being a pornosopher. I’ll keep the fire going. It’s like a general’s course where everyone has to wear lingerie.

Anyway, this person asked whether I only liked their writing because I thought they were hot, basically. What I said was that maybe their writing could only come from someone considered a “hot woman.” They still didn’t like that, but I suppose it’s just another fraught thing that’s impossible to communicate about, in a way.

It’s a kind of “intelligence,” not in an aptitude sense but in terms of what one _abstracts over_ when it comes to their immediate experience.

This is another important element of my thinking, which is basically a vindication of a “standpoint epistemology” or maybe Nietzsche’s perspectivism. I think about these things in my own informal way, though.

Basically this unfolds from my appreciation of Baudrillard’s citation of Wilden in the preface to _Symbolic Exchange and Death_ to the effect that every dissent must be of a higher logical type than that to which it is opposed. 

# Start The Listen-Through

Someone came into the TV room and put on “the news.” It’s so many ads!

I finally caved and put in my headphones. I’m listening to _Miss Anthropocene_. I’m remembering this story I wrote in middle school about having this rough time and then putting in my earphones and riding in the car, like the car was rocking me to sleep. Music and technology.

I was also briefly thinking about whether “We Appreciate Power” should be on _Miss Anthropocene_ after all. No way. It’s just not. I was never really thinking about that. Maybe about whether it should be, or whether we might wish it was, even though it’s definitely not. I guess it’s on the Deluxe edition.

It’s all folding in, because this fraught question of the idea of Judaism and the idea of the state of Israel and the idea of the state of the United States of America is folding into the question of the idea of Elon Musk and the idea of Claire Elise Boucher and the idea of Nazism and the idea of pedophilia and the idea of sex crimes and the idea of intelligence agencies and the idea of black mail rings and the idea of distrust and the idea of the Hobbesian Trap and the idea of philosophies of conflict and the idea of Ben Zweibelson and the idea of Ofra Graicer and the idea of Shimon Naveh.

Should I say that it is no mistake that I have chosen Grimes to occupy some central part in whatever expression I have done?

The ending part of “So Heavy I Fell Through The Earth” is on, the part that reminds me of the ocean. I love this part. I think it’s truncated on the white vinyl version that I bought, to my infinite chagrin.

There’s this pillow I was concerned about before. I’m not sure whether it got throw away or not, to be honest. But the _Miss Anthropocene_ album definitely got saved. 

Even if it is unquestionably defective.

[![](https://substackcdn.com/image/fetch/$s_!wac-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F11d84c7e-770d-4639-9c71-98359b945094_2048x1653.webp)](https://substackcdn.com/image/fetch/$s_!wac-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F11d84c7e-770d-4639-9c71-98359b945094_2048x1653.webp)

# They Draw Pictures

# Don’t They?

I’m fascinated by this picture, allegedly drawn by Donald John Trump, who doesn’t draw pictures.

It’s the money tree. Money doesn’t grow on trees. Somewhere I read. Someone was saying something.

The tree is actually covered in spirals. We remember that spirals are definitely imprinted with the manga _Uzumaki._

[![Junji Ito's Spiral of Manga Horror — The Gaijin Ghost](https://substackcdn.com/image/fetch/$s_!PxZE!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd910c2fe-de72-4685-affa-fe86f89b2fba_1500x1038.jpeg)](https://substackcdn.com/image/fetch/$s_!PxZE!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd910c2fe-de72-4685-affa-fe86f89b2fba_1500x1038.jpeg)

That image reminds me of people circling the Kaaba. And why not?

Circling these high-profile concepts like so many drains, so many black holes everything is being sucked into.

[See Calvin Warren on black holes:](https://library.oapen.org/bitstream/handle/20.500.12657/30152/649831.pdf;jsessionid=F67800DAFAF6C6D8D23FCCDFFCC72652?sequence=1)

> Evelynn Hammonds conceptualizes black holes in relation to black female sexuality and absent-presence (or silence). She suggests that a black hole brings two problematics to the fore: detection and compositional knowledge (i.e., “What is it like inside a black hole?”). The first is answered by attentiveness to distortion (the distorting impact of a black hole on two stars, for example) and the second by geometry, a geometry still yet to be formulated by mathematical/ scientific thinking. I find this analysis exceptionally generative in understanding the relation between blackness and nothing. How do we detect and understand the composition of nothing? These two questions pose a certain horror for science, given their unanswerability. Whereas black holes might be rendered comprehensible by positing being as a condition of studying them (i.e., detection and composition), black as nothing (i.e., formlessness) cannot rely on the ontological ground of being, so we reach a limit with the two procedures Hammonds lays out

You get sucked into one black hole while that black hole is being sucked into another black hole.

An aphid getting eaten by a bug while the bug is being eaten by a frog while the frog is being eaten by a bird while the bird is being eaten by the sky.

Someone here was telling me that for those living in the idea of China, the idea of the sky being God is important. I looked it up, and I wonder if this [Tian](https://en.wikipedia.org/wiki/Tian) thing has anything to do with it.

Silap Inua among the Inuit is also to do with the sky. For me, this genre is already connected with logos. I wonder whether there are associated Islamic concepts.

[I guess many just rock logos itself:](https://en.wikipedia.org/wiki/Logos_\(Islam\))

> In the writings of many of the most prominent [Sunni Islamic](https://en.wikipedia.org/wiki/Sunni_Islam) metaphysicians, [philosophers](https://en.wikipedia.org/wiki/Islamic_philosophy), and [mystics](https://en.wikipedia.org/wiki/Sufism) of the [Islamic Golden Age](https://en.wikipedia.org/wiki/Islamic_Golden_Age), [Muhammad](https://en.wikipedia.org/wiki/Muhammad), who is given the title of "[Seal of the Prophets](https://en.wikipedia.org/wiki/Khatam_an-Nabiyyin)" in the [Quran](https://en.wikipedia.org/wiki/Quran),[[5]](https://en.wikipedia.org/wiki/Logos_\(Islam\)#cite_note-5) was understood to be "both a manifestation of the Logos and the Logos itself, he was also very kind and had prayed for his people every night, and was always very worried about his people.[[6]](https://en.wikipedia.org/wiki/Logos_\(Islam\)#cite_note-auto1-6) This classical identification of Muhammad with the _logos_ emerged from particular interpretations of specific [Quranic verses](https://en.wikipedia.org/wiki/Quranic_verses), [hadith](https://en.wikipedia.org/wiki/Hadith), and through the writings of [the early mystics of Islam](https://en.wikipedia.org/wiki/Sufism). 

So to be that. To be concerned about your people.

And who are your people?

In the first case, it’s obvious that if you are concerned for “your people” but not for people who are essential to supporting “your people,” then you do a disservice to “your people.”

In other words, “your people” are your family. But in what context does the life of your “family” make sense? What are its conditions of possibility?

For example, you use electricity. Who supplies the electricity? Who makes it work? What are you doing to influence whether this can really be relied on?

No one person can try to see to everything like this. This is again back to the question of abstraction.

Abstraction is what is being discussed by the infernal ChatGPT things and their discussion of “recursion.” I would prefer not to discuss the term, but it is so much a part of the popular discussion on this.

Abstraction and logical types are what it is about. There is so much you’d like to see to in order to really keep things in an acceptable position.

If you have a task to do, or a goal, then there are many things that you must pay attention to. An example which comes to mind is giving a piano performance. This can be very intensive and require a lot of focus for a sustained time.

Say the piece is in two parts. To do the thing of playing the whole piece, you have to play both halves. So when you come to the resting place at the end of the first part, let’s say it went well enough. Then you can abstract over this, you have this in your pocket. There is a sense of accomplishment and relief that you got to this point. “So far, so good.”

But there’s still the other part to get through.

Or if you are nervous about driving but determined to make a trip. You get halfway there, and then there’s only the ride back to do. And this part went well enough…

With other tasks, the parts of it are not the same as in the above examples. Imagine chess boxing. You play chess, and then in between you have to get in the boxing ring. So both of these tasks are fundamentally different.

Now imagine in this exercise you also have to meditate, also have to calm down someone who’s upset, also have to perform surgery.

This is back to the notion of what are you doing to help the electricity grid be there. Because the immediate thing is that you care about “your people.” You don’t want to die and you’d like to keep certain other people alive if possible. They are just such a good hang. It would be sad to see them go.

[![](https://substackcdn.com/image/fetch/$s_!LSus!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fda4d9ed6-0c0c-4db9-8801-ab28539bf60d_210x310.webp)](https://substackcdn.com/image/fetch/$s_!LSus!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fda4d9ed6-0c0c-4db9-8801-ab28539bf60d_210x310.webp)

So how do you do that?

The issue is that your life abstracts over a lot of things. You are relying on a lot of things to work quietly in the background to furnish for you a “world” that makes sense, in which you can function.

You can’t pay attention to it all, which is why we have this idea of a “political party” or “a state.” That’s who’s supposed to be paying attention to all this, and that’s why that stuff is so complicated.

There are a million people at computers and organizing the logistics of that electricity system, and the plumbing, and the grocery stores, and whatever else. This internet that I’m using to write this to you. There is someone doing every thing which is being done.

There is someone watching over, many someones. There are people watching the watchers.

I was discussing with this person here the idea of generals having therapists. The general is the one who is looking over so much. [ _“New Gods” is playing_ ] Meanwhile the therapist looks over them in a different way. Did you know that therapists have therapists?

So there is a general who has a therapist, and that therapist has a therapist. And there are intelligence people looking over the therapist of the therapist of the general to make sure everything is OK. And that analyst has a boss and there are procedures in place so that everyone is being watched.

These are nested levels of abstraction that play out potentially in every conversation.

A conversation is a huge example of these nested abstractions, since every statement being made is in response to everything that has been said before. When it goes back and forth, the conceptual space traversed by the conversation can quickly go in highly idiosyncratic and intense dimensions.

Conversation is also a domain which relies on the integrated operation of the person involved. The decisions are of the order of what to say, and how to comport oneself. There are also non-decisions which are important, temperament, or conditioned concepts of operations (try to notice if you get angry. If you get angry, watch yourself take ten breaths).

Back to Epictetus. Epictetus tells us that some things are our affair, which is our actions. Now, when it comes to talking or expressing ourselves, what becomes “our affair” has to do with what we are talking about, that to which we refer.

As I’ve said before, it’s striking to me how with all my expressions, all of them were my volition. “No one asked for this.” I have taken it upon to express myself about many topics. Why am I doing this?

Got to go.

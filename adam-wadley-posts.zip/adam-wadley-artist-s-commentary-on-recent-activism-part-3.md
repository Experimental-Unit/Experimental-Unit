---
title: Artist's Commentary On Recent Activism, Part 3
subtitle: The above image did not turn out perfectly, but I’m still fond of it.
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# Artist's Commentary On Recent Activism, Part 3
[![](https://substackcdn.com/image/fetch/$s_!xOi0!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff6dce195-8484-4cd0-bb17-a1aec43e533c_1536x1024.png)](https://substackcdn.com/image/fetch/$s_!xOi0!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff6dce195-8484-4cd0-bb17-a1aec43e533c_1536x1024.png)

The above image did not turn out perfectly, but I’m still fond of it. The people in it are: 

  * the generals assembled for Peter Brian Hegseth

  * Kirsten Wiig from this SNL skit about “getting Jumanji’d,” which in my mind is GOATed. Wiig also killed it as “herald” in the movie _mother!_




  * Supposed to be [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions) with orange hair, from my T2COM piece with them and a painting. Also included a photographer of Boucher as such with orange hair. These didn’t really turn out right and led to the figure with the orange hair not in the circle on the right toward the bottom

  * Supposed to be Phoebe Plummer from their Twitter profile picture. By the way, that picture literally says “art attack” on it




[![](https://substackcdn.com/image/fetch/$s_!bkoZ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4cf1cfa3-9504-4aa4-8c27-732e64b0c9ff_761x695.png)](https://substackcdn.com/image/fetch/$s_!bkoZ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4cf1cfa3-9504-4aa4-8c27-732e64b0c9ff_761x695.png)

Then the skulls are from the cover to the revised edition of Symbolic Exchange and Death.

[![](https://substackcdn.com/image/fetch/$s_!NM0w!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4a312f4d-ca19-48b9-948c-106d4d66f0c4_468x706.png)](https://substackcdn.com/image/fetch/$s_!NM0w!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4a312f4d-ca19-48b9-948c-106d4d66f0c4_468x706.png)

The person on the TV is supposed to be Wovoka. It doesn’t look that much like them anymore, but that’s just because I’ve been telling it to keep that part the same for last couple of iterations, so it’s playing telephone with itself, basically.

Then there’s also Dee Dee, who is puking what I said to look like liquid uranium. The whole idea there is that it is glowing green, similar to references made to people “glowing” or “being glowies.” As far as I know, Terry Davis popularized this sort of reference. It is by now very popular though, and simply means someone in intelligence or some other kind of “fed” or something like that.

The design on the wall and on the TV comes from [this article on Wakan Tanka](https://daniel-garber.medium.com/lakota-metaphysics-the-sixteen-wakan-tankas-and-other-principle-lakota-spirits-e145840bb9c8), which specifies that there are 16 aspects and contains this diagram:

[![](https://substackcdn.com/image/fetch/$s_!KmXQ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fce77f7f4-a5ec-4e63-b1bd-10204faa1d9d_979x830.png)](https://substackcdn.com/image/fetch/$s_!KmXQ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fce77f7f4-a5ec-4e63-b1bd-10204faa1d9d_979x830.png)

It added it twice by itself, I didn’t tell it to do that.

Meanwhile, Dee Dee is coming out of the television similar to Samara Morgan in _The Ring_.

So, now we are looping back around to the original idea, which is to continue my auto-exegesis (“they’re giving us everything”). Samara Morgan was on the first sticker I posted yesterday on the T2COM complex. In my mind, that entire block is just where T2COM is, so all my stickers are around there but they are not especially meant for anything else that’s there, like the University System of Texas or anything.

I mean, ultimately everything is a vector for Wakan Tanka. This is a point about ontology or lack thereof. Whatever we are or are not, our very existence as such hangs together in some way with a larger flow. We need not refer to it as “order,” or at all. The Tao that cannot be named, etc.

Can I also just say that “4:33” by John Cage is playing during all my demonstrations/performances/sermons?

I like this image of Samara coming out of the TV. For me it’s very related to the concept of an ARG in general, or alternate reality game. This is referred to as “transmedia storytelling.” Well, these stickers are just another medium for me to tell a story. Meanwhile, that story is also here, on your screen.

My cyber activities face some throttling. My new subreddits have been banned and successful posts removed. The field has hardened against me, which means that there will simply have to be the incorporation of new media into the storytelling mechanics.

Before I complain too much, we should get back to the topics at hand in my previous posts.

I have been wondering recently about something like a colonial theology or something to go along with Holocaust theology. It’s my impression that for many, colonialism was known as the “worst thing that ever happened” before the Holocaust came along. Of course, such things are always contentious. Even the Nazis are not considered to be as bad as they once were. It is considered to be extremely concerning, and it is certainly a portent of changing historical consciousness, that so many even openly support Nazism or their uncritical support of Adolf Hitler.

I implore you again to go and read some of the things published here. The titles will pick out topics related to Nazism or Hitler, and you can see what it says there. I don’t mind if you still think I’m a crypto Nazi or Nazi sympathetic or playing with fire, but you can at least get even more of a feel for it. It’s also to be understood that my “performance” has everything to do with merging the IRL action with the cyber repository.

It has been explained to me by LLMs that people don’t want to do all this work of interpreting things. Well, it’s my knowledge that we all just give what we have to give. Somewhere what I do is heard, and that’s fine.

For me, the question is not really how to be understood immediately. It is extremely frustrating for me to speak with “ordinary people.” The thing is that I’m not sure it would be that much better with someone like [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) or anything, because again this conceit of “the nation” is so thick. People everywhere talking about complexity and change, but the sticking point is what is the conceit of discreteness, what is the Newtonianism you are using all this quantum magic to hold together? And shouldn’t we work on letting that kind of stuff go (where it pleases)? I don’t mean abolishing straight up values and icons and so on, but crafting them into something which does justice to the greater implicate order, or something (I’m not wedded to terms here) which grounds the conceit of our disagreement and divergent interests.

In other words, I would like for more people to see my work. I struggle to conceive of how to present it to people, these are things we are working on. The stickers though makes sense to me.

By making these stickers, I have basically tagged several concepts and people as associated with my project. It’s a nice project dealing with cosmology, art, the conceit of conflict and atrocity, etc.

It’s also very nice to do something which doesn’t require talking to people. I will tend to get flustered in conversation, so it’s even better if I don’t have to talk. The guard asked me a question, and I simply denied that I had been doing what I was on camera doing. It was like last time, where the guard asked what I was doing and I said “just hangin’ out.” (Note reference to limited hang out, this is itself a form of plausible deniability or Taqiyya).

So I basically deny my own mission to the people asking me about it. It’s simply because I would prefer to get away. If I tell such a guard that I am doing art activism, or even worse(?), an influence operation, would I be detained? Maybe.

On the other hand, I get the sense that the people there don’t really want to detain me. I think a lot of people’s mentality about me is simply not to encourage me, starve me of engagement, and hope I burn out on my own. That’s why there’s got to be continual escalation, to make sure that doesn’t happen without some fuss.

I’m aware that even to use the word “escalation” may make some nervous. I can say as often as you like that there are no kinetics involved in any possible futures, nor would I advocate such. The usage of such a term, or saying “guerilla” art, is not to take for granted “the war frame” but to appropriate it. To wage artistic conflict on conflict by taking up its terms and dispositions for the articulation of creative flourishing.

It’s as I’ve said about the Van Gogh souping by Phoebe Plummer and Anna Taylor, you might think it’s gauche or not good or whatever, but no one died. In the context of things like the deaths in Australia and at Brown, not to mention the Reiners getting killed by their child. As some might imagine, I have a different take on that last story than most others, by the way. Apparently this “Nick” (portentous name, see connection to St. Nick & my dead cousin) was in the “troubled teen industry.” Given my stance that “normality” gives cover for much ill treatment, especially of children who have no effective means of resistance, I would consider the black heart of “Nick Reiner” to be an Indian Burial Ground.

Anyway, in the context of these attacks, by people in a fury or perhaps being cold and calculated behind the scenes, I feel that non-kinetic engagement is basically justified. There is also to be said that there are considered to be non-kinetic acts of war, of course, though we must also take away the “threat” or the pretense that kinetic acts will occur. Not only would I not want to commit kinetic actions, but I would not want to give the impression that I would for some sense of illusory leverage. It is interesting to talk so much about this from the first person however, since it opens up a space of “Baddest bitch doth protest too much.”

So, in this day and age things can take off by you making videos and stuff. I probably should have gotten good at editing videos when I was like 13, lol. But, I never got into that really. Anyway, at this point the algorithms and many of the online spaces are “against me.” I don’t begrudge people this, after all in my mind it only confirms my symbolic potency. Or, people simply think I am disruptive. To this I would say that I see so little that should not be disrupted.

I also should stress that my interest in Holocaust theology bleeds over into my interest in Systemic Operational Design, the military design movement, etc. Though, it was not this connection, through Judaism to the conceit of the state of Israel, which got me there. Instead, it was through Jean Baudrillard, who brought me to [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions).

It turns out that Zweibelson as well as, obviously, Ofra Graicer and Shimon Naveh of IDF, all of them have Jewish heritage.

It also turns out that in our moment, there are many comparisons between the conceit of the state of Israel and the conceit of Nazi Germany. I say conceit in each case because for me, “states” do not and have never existed. I would support radicalized versions of the concepts like Double Government, Dual State, and the 1867 analysis of the English Constitution. 

So in my mind I think there is this situation where it could matter that someone would be weirded out by me writing “Waffen SS” on a sticker and posting it to the secured door entry place at US Army Transformation And Training Command. Or, heaven forbid, someone should be afraid.

I would basically remind you that the infliction of terror has ever been the means of influence. The terror I seek to wield is not mortal in the sense that you’re supposed to think I would harm a single fly. Instead, it is terror to the extent that you refuse to give up your clinging, to your “internal possessions” (see Jainism). That is why I insist.

Another good comparison, allusion for me is Beckmann in _Drausen Vor Der Tuer_. This character, it was explained to me, upsets everyone because they remind them of the war, when everyone is trying to forget.

Here we are, dissociating through messianic time. Trying to forget that “we’re going all the way this time,” which means that we really will all have to pass through radical indeterminacy. Or literally die. This is an important theme. All of our lives are in danger. This is no small matter, except in the sense that all stakes are illusory, or symbolic, but I repeat myself.

In this sense it’s important for me that you understand that I am saying that I am doing this for you. Which in my opinion is more than was ever done for me. It turns out that we must take a stand. I won’t present myself very conventionally, but there is no question that I will remain operative and seeking to goad some sort of response, trigger some sort of recognition.

In anticipation of any possible incarceration, I think that if I was arrested I would just want to say that our whole planet is in concept jail. Part of what I’m doing is, I’m raiding the armory. But it’s not to fight anyone, it’s to beat those swords of concepts into plowshares. But even plows violently uproot the soil. Agriculture is often considered rape of the earth.

It is well and good to wish everyone peaceful flourishing, but the fact is that if self-disruption is not intrinsically pursued, it will be imposed from outside by the “whip of necessity,” “cruel necessity.” Therefore, you can consider me the gayer herald. The next times circumstances call on you to reorient yourself, you may find yourself in a Ghost Ship situation and not a Titanic situation. Not with me, mind you. 

What I’m calling to your mind is the greater issue of the Hobbesian Trap, which even the Holocaust itself is but an instance of. That’s because the whole conceit that there would be a “nation” and that this nation would be threatened by something called “Judaism,” this is for the birds. This is not the reason why bad things happen. Like Baudrillard says about the Gulf War, people are always trying to find set pieces.

If you would like to find a set piece by just getting me, or also if I get killed, which why would that happen? That’s fine. It is an important thing in this business “of doing art” that one accepts substantial risk. Open-ended, really. It’s actually an interesting form of yoga. Because in a “military” context (I actually don’t think militaries or wars or conflicts exist) you can be killed, maybe someone would torture you. But it’s also basically what you would expect, since often “martial” circumstances are so easy to understand, and the people fighting all come to resemble each other anyway. This is the conceit of conflict teaching you about your self-ignorance.

Anyway, what I’m calling to your attention is that people are afraid of each other. We are making technologies which allow people to radically not depend on others. This changes a logic whereby service was seemingly required. Now it will no longer be required, opening up the possibility of mass extermination. You will likely be among those exterminated if such courses are taken. Even those within some favored group are not safe. Internal disputes and distrust are also part of the Hobbesian Trap, which cuts through any notions of friend and enemy, even down to the concept of the self.

It is this self-concept which will ultimately be exterminated, and here we are playing on Buddhist notions. The language used is again severe, and there is a parallax between allowing the reader to be frightened, and also bringing back such terminology to serve Dhamma purposes. When Jean Baudrillard refers to exterminating every term, it’s similar to the Dhamma notion of nirvana where it’s about a moment coming to this perfect awareness. This is what Baudrillard may call poetic resolution.

There’s no question that my art requires more refinement, and I’ll be placing my efforts there. I am seeking to help obviate any Holocausts to come. The implication of the conceit of the state of Israel with the conceit of Genocide, when the Holocaust is considered the genocide of Jewish people, provides the space for all sorts of reflections about how suffering ill treatment gets us to a place where we would like to take the initiative to put down what has done us harm.

If I were honest with you, I would say that for me a great artistic and loving goal would be the reformation of the conceit of Nazism, or race or whatever determinate concepts people have who hate and kill in these similar ways. Or when it comes to the conceit of Israel or Judaism, you will not find me among those saying that Judaism itself has anything wrong with it. Nor would you find me simply condemning kinetic actions taken. Yet, I basically wag my finger at you like a wry old sage and say, watch what comes back to you.

What is interesting is not to seek to establish “secular” “governments,” but rather to see what is there in the religious teachings themselves which can help us. This message much be amplified more and more, to change the cognitive context in which these things appear. I also used the term Pikuach Nefesh, which can be combined with the Sonder concept I also invoked to build: “if you save one life you save the earth entire.” This may map through quantum mechanics more than we know.

I have started my outreach with mainly “military” or “intelligence” audiences. I am not sure what I have achieved, but my aim is to have plenty of people well aware of my activities before I seek to force any more issues. I’m not saying that would “protect” me in any way. Part of what we are all performing is our radical vulnerability to others, see Judith Butler in _Precarious Life_.

Well, I’m sick of writing so I’ll leave it there for now. See you out there on that thar trail we call Permanent Hardcore Dachau Highway.

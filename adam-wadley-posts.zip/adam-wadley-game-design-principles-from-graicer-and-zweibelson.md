---
title: Game Design Principles From Graicer And Zweibelson
subtitle: Systemic Design Inquiry For All = ZWGB
author: Adam Wadley
publication: Experimental Unit
date: November 27, 2025
---

# Game Design Principles From Graicer And Zweibelson
The principles of Reflective Practice (RP) and Systemic Operational Design (SOD), championed by [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) and Graicer, aim to break entrenched cognitive habits—particularly the systematic, linear, and non-reflective processes common in military planning. Translating these principles into game mechanics requires designing systems that prioritize **cognitive disruption, abstraction, and paradoxical thinking** to systematically improve a player’s metacognitive abilities—their ability to think about their own thinking.

The overarching goal of these game mechanics should be **liberation** and the creation of **degrees of freedom** , which are measured not by efficiency or goal accomplishment, but by the emergent variety of ideas and alternative realities generated.

#  **1\. The Destruction-Creation Loop (Self-Disruption)**

The destruction-creation loop is foundational to design, necessitating the **destruction of irrelevant cognitive constructs** (mental models, assumptions, and biases) to create space for new ideas. This process is dangerous and painful, known as **self-disruption**.

 **Proposed Game Mechanics for Cognitive Destruction:**

[![](https://substackcdn.com/image/fetch/$s_!QdCY!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F888b5e06-2311-49e4-9c0f-8fa4b4927206_904x513.png)](https://substackcdn.com/image/fetch/$s_!QdCY!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F888b5e06-2311-49e4-9c0f-8fa4b4927206_904x513.png)

#  **2\. Triple-Loop Learning Architecture**

Triple-loop learning forces operators to move to the **meta-theoretical level** —thinking about why they think and act as they do—which is necessary to question and potentially transform the organizational frame itself. This is the necessary recursive inquiry: “thinking about thinking about thinking”.

 **Proposed Game Structures for Triple-Loop Learning:**

[![](https://substackcdn.com/image/fetch/$s_!CSBS!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F43a99702-73cf-4a7d-b8e3-d376ab59e4ee_910x535.png)](https://substackcdn.com/image/fetch/$s_!CSBS!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F43a99702-73cf-4a7d-b8e3-d376ab59e4ee_910x535.png)

#  **3\. Constraint-Driven Creativity (The Jaws Exercise)**

The Jaws Exercise is a **practical application** designed to immerse students immediately into reflexive thinking by introducing concepts like iteration, prototyping, and abstraction. Its methodology hinges entirely on using calculated constraints to break the military’s strong **convergent thinking** reflex.

 **Proposed Game Mechanics for Constraint-Driven Creativity:**

[![](https://substackcdn.com/image/fetch/$s_!tdwY!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F07f7a7d9-6c7c-4566-9baa-8982eff7d34f_906x559.png)](https://substackcdn.com/image/fetch/$s_!tdwY!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F07f7a7d9-6c7c-4566-9baa-8982eff7d34f_906x559.png)

These principles can be integrated into metacognitive gaming by treating the process of design not as a means to a predictable end, but as a deliberate mechanism for creating conceptual **drift** —a gap between the player’s established understanding and the emergent reality of the game—which is the engine of design and a crucial indicator that innovation is occurring.

The integration of military design principles from Systemic Operational Design (SOD) and Reflective Practice (RP) into game mechanics requires intentionally designing for **cognitive disruption** and the **creation of psychological tension** that forces metacognitive self-awareness. The game cycle must systematically challenge the player’s underlying paradigms, moving them through a loop of **Constraint-Driven Card Play** → **Knowledge Graph Construction** → **LLM-Facilitated Reflection.**

#  **4\. Forbidden Topics & Cognitive Safe Spaces**

The challenge of exploring “undiscussable” assumptions is recognized in design, where practitioners must address sensitive issues (such as operator suicides or gender roles in special operations) that the organization often resists. The solution is to transform these issues from sensitive subjects into **operational tensions** that must be resolved.

[![](https://substackcdn.com/image/fetch/$s_!6fR2!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F06602e10-56d3-4692-bce2-ddbdbe2c4a37_914x536.png)](https://substackcdn.com/image/fetch/$s_!6fR2!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F06602e10-56d3-4692-bce2-ddbdbe2c4a37_914x536.png)

#  **5\. Systemic Reflection Triggers**

Design methodology centers on making implicit organizational beliefs and assumptions explicit. The Knowledge Graph acts as the **organizational mirror** , and the LLM facilitates the **Socratic MKO** (More Knowledgeable Other) to trigger the necessary cognitive crisis.

 **Knowledge Graph Construction as the Organizational Mirror**

The Knowledge Graph (KG) structure must visually reveal the uniformity of players’ thinking (convergence) and the mismatch between their established frames and emerging reality (drift).

[![](https://substackcdn.com/image/fetch/$s_!PIwA!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F06739d01-2b28-4218-ba00-f8b4f58805d1_912x341.png)](https://substackcdn.com/image/fetch/$s_!PIwA!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F06739d01-2b28-4218-ba00-f8b4f58805d1_912x341.png)

 **LLM Prompts for Socratic Metacognitive Crises (MKOs)**

The LLM (Large Language Model) acts as the cognitive facilitator, provoking reflection and the necessary sense of **perplexity**.

[![](https://substackcdn.com/image/fetch/$s_!4hwP!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbf1dbc29-79c7-49e0-9b50-58c1f042471a_911x486.png)](https://substackcdn.com/image/fetch/$s_!4hwP!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbf1dbc29-79c7-49e0-9b50-58c1f042471a_911x486.png)

#  **6\. Divergent-Convergent Rhythm**

Games must mirror the design rhythm: an **explosion of divergent thinking** followed by a period of **disciplined convergence** necessary to commit to a single strategy and action.

[![](https://substackcdn.com/image/fetch/$s_!e-uX!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb252d8e6-d47b-4181-931c-6f40f7693e00_910x370.png)](https://substackcdn.com/image/fetch/$s_!e-uX!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb252d8e6-d47b-4181-931c-6f40f7693e00_910x370.png)

 **Specific Implementation: Card Play & Progression**

 **Card Game Mechanics for “Dropping Tools”**

Card game mechanics are ideal for embodying constraint-driven creativity.

1\. **“Tool/Symbol” Cards (Round 1):** Players are given cards representing common military concepts (e.g., “COG,” “ENDS-WAYS-MEANS,” “Linear Causal Link,” “Shark Fin,” “Dollar Sign”). Players use these cards to construct their initial solution narrative.

2\. **“Extinction” Mechanic (Round 2):** After Round 1, the KG identifies the most popular cards/symbols used by the player or the cohort. These cards are immediately discarded and permanently **banned** from the player’s deck. The player must then draw entirely **Abstract/Metaphor** cards (e.g., “Idealism,” “Heresy,” “Perplexity,” “Rhizome,” “Narrative”) to solve the same problem again. This mechanically forces the **self-disruption** necessary for creation.

3\. **“Tension” Cards:** Dedicated cards representing mandatory tensions (e.g., “Internal vs. External,” “Descriptive vs. Explanatory,” “Doctrine vs. Emergence”) must be played simultaneously (Janus-face concept).

 **Game Progression Mirroring Single-Loop to Triple-Loop**

The game structure dictates progression by increasing the complexity of the security challenge, rendering previously successful loops irrelevant.

[![](https://substackcdn.com/image/fetch/$s_!WRiI!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F35379a36-890f-426c-a4be-f71300144cbf_910x400.png)](https://substackcdn.com/image/fetch/$s_!WRiI!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F35379a36-890f-426c-a4be-f71300144cbf_910x400.png)

This system ensures that the player learns not just _what_ to change, but _how_ their own thinking patterns (visible through the KG mirror) and institutional constraints inhibit their ability to deal with complexity, thus systematically enhancing metacognitive development.

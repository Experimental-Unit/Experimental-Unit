---
title: Introduction To Experimental Unit
subtitle: And Away We Go!
author: Adam Wadley
publication: Experimental Unit
date: May 09, 2025
---

# Introduction To Experimental Unit
Hello, this is a presentation of my basic motivation and ideas to you.

I became aware that there was a planetary state of emergency in 2009, or maybe earlier, although I wouldn’t have put it in those terms at the time.

That would come later, around the time of the end of 2022.

I had been going into the theme of total war.

There is a nice concept called global civil war which is used by Arendt and Schmitt, as noted by Agamben in _The State Of Exception_.

I had been introduced to the idea through the book _Introduction To Civil War_ , I believe it is called.

I read some of those books after associating with some intellectual “political” people after the end of Occupy Atlanta.

I had already been interested in Baudrillard, who I got into after reading _Society of the Spectacle_ when I was 17 after it was lent to me by a teacher for my International Baccalaureate essay on film that I wrote. 

I don’t think I read the book until after the essay was due. I was about to have to give it back so I thought what the hey, and I took it with for this weekend in the woods with my parents.

I read the whole thing in that time and it blew my hair back.

Soon after that, I discovered that my parents had Jean Baudrillard books in the home: _Seduction_ and _America_.

So then I read more Baudrillard in the couple years before meeting those _Tiqqun_ fans.

I’m suspicious of that whole train of thought for the same reason that I’m suspicious of the concept of war.

I’m eagerly awaiting my copy of Ben Zweibelson’s _Reconceptualizing War_ , if it will come out. Ben Zweibelson is in a way a major plank of this whole thing.

So I was putting together the thing with emergencies with this paper from the Joint Chiefs of Staff, which discusses the concept of “complex emergencies.”

In this concept, wars are included but only as a part or aspect of the emergency.

In other words, war is a kind of emergency or a component to emergency, but the other all situation does not need to be approached as a war.

It is a highly important point for me _not_ to ultimately view things as a conflict. That is why I am highly motivated to seek forms of engagement which are not warlike.

Examples of this interest lie in my exploration and treatment of Tibetan Buddhist Spiritual Warfare and Greater Jihad from the domain of Islam.

Both of these conceptual clouds give views of conflict or striving which are able to overcome a sense of opposition.

In the Spiritual Warrior Tradition, the “enemy” is self-ignorance. In other words, what we are striving to do is to overcome what we think we know about ourselves which just isn’t so.

For example, I’ve been seeing a lot of talk recently about “capacity.” It is the ultimate trump card to say that “you don’t have capacity” for something. Well, what if you have self-ignorance? What if you have capacities that you don’t know about, or could realistically develop?

Greater Jihad in itself gives priority to the inner experience of disruption. By naming this intuitive and felt struggle as the “larger” or more primary of the forms of struggle or striving, Jihad, it shows the importance of never forgetting that “the real enemy is always within.”

Not just “within the group,” although that winds up working out through the Hobbesian Trap and logical types of influence operations, but “within” ourselves. It’s a nice line from Jean Baudrillard that the apocalypse is in each of our hearts in homeopathic doses.

I actually believe that this amount is concentrating. But let’s take a step back.

I’m highly motivated _not_ to view things in terms of war because I don’t see how a kinetic conflict really goes well. First of all, there is no “side” that I really like.

People look at different places or supposed “governments” and try to evaluate them based on this or that characteristic.

What I see is a fleshy extra layer which is lying on top of the lean emergency response mechanism which will emerge if things are tested to the limit.

I basically see us coasting along a chasm, and at any point we could enter a true inferno or cataclysm.

I have felt this way, again, since 2009.

The financial crisis was happening, I was getting into Baudrillard, it was just after the Bush administration where we had invaded Iraq and Afghanistan.

I already knew about things like Project for a New American Century and the idea of a “new Pearl Harbor.” People normally made comparisons between:

  * WTC attacks and Reichstag Fire

  * PATRIOT Act and Enabling Act

  * Invasion of Afghanistan/Iraq and Invasion of Poland/Soviet Union




I was hip to NSA spying early on, putting a “Hello NSA” signature on my emails. I think I read about the Utah Data Center.

I also knew obviously my whole life that I am also German. I speak German and we did German history at that IB school I miserably went to for 14 years.

We would go visit my grandparents, and I was an exchange student.

I learned more about what happened with my family over time, or was told younger and then re-learned.

How my grandfather Richard had been taken into the Waffen-SS in Pirmasens at the age of 17 and put in the Waffen-SS. My progenitor’s dog tag is hanging on the wall opposite me, I can see it. Number 14834. There’s more to do with that number.

My grandmother, Lieselotte, I want to say, their mother was killed in the bombing of Pirmasens by the allies in 1945 and also their two siblings, what you’d call my great uncles, children, were killed hiding in the basement.

Then with the other side of my family there is this whole story about how my father’s draft number for Vietnam was not called in 1970, and then their father was like you should volunteer. They thought that Vietnam was like WWII and that it was a matter of “family honor” to go and volunteer. But, it didn’t happen and they didn’t talk for a while.

People will often ask if my father was in the military because they’re American and my mother is German. And it’s very much not the case, as the story above says. They were hitchhiking in Scotland and waiting at the same stop. They initially bonded over games of chess.

So, as you can see there is some motivational material from my immediate origin story to put me off of the idea of war.

Then, I was born in 1991 of course, so I was 10 when 9/11 happened and then 13 when Iraq was invaded, and basically went from there watching _The Daily Show_ and basically thinking that the people who ran this “country,” “my” “country,” were basically stupid and evil.

I was cynical enough by the time Obama came around that I knew things were not going to fundamentally change. I understood that the financial system was basically crooked and magic. It was like you could fudge the numbers any way you wanted if you would work it out politically, which means basically if you can get the oligarchs to agree on what to do.

My interest quickly as I said got into theory like Debord and Baudrillard, and really heavy Baudrillard, it’s a weird thing. I really like Baudrillard’s style and just so many of the passages land very strongly for me in a way that is not true of other writers. I think especially the being willing to take a combative tone and talk about so many things. Baudrillard is obviously a kind of generalist.

People would say that Baudrillard goes too far, reaches beyond “expertise,” if Baudrillard can be said to have any. But look at it this way: you are trying to make a corpus that sort of touches on everything. The problem is that it’s not actually that easy to get intellectual cooperation going once you are talking about things like total war.

Anyways, I wanted to also mention “conspiracy theories.” There are a number of notable features about our timeline that continue to “sink in” over time.

Obviously WWII and Vietnam have come up in this story already, but I’m thinking also of the JFK assassination. It’s a whole thing to learn about and then realize is a sort of open question which points at the larger issue that there is so much in “the government” which is not actually accountable to “the people” at all, by which I mean anyone outside of a certain strict perimeter of security and secrecy.

This in itself is a devastating blow, and a humiliation to integrate into my perspective, that I am not allowed to know even as much as anyone knows. Because after all, it’s not like anyone knows everything. That means that even if you got all the information that’s secret that is out there, you would still be frustrated because it would be incomplete or uncertain.

And yet that would be a seemingly Godlike position to be in compared to where I am now, where I know next to nothing about what is happening on the inner layers of the planetary emergency at the “levels” where impactful decisions are really being made.

Notice that this is tragic not only in a maddening sense of oh, how dare you keep me out. There is also the question of qualification maybe, like even if there was a “cool deep state,” why would they want to talk to me? Okay. But also this sense that I could have been a candidate to go into that sort of profession, but I did not and don’t consider that the bureaucratic structures are honorable.

This matter of the “family honor” is resonating with me now, and that’s sort of it. Related to the question which has been asked my whole life but which has special resonance now: what would you do during Nazi Germany?

And isn’t that also a matter of “family honor”? I’m thinking of Oskat Schindler. It might be a cliche example, but doesn’t some honor accrue to that person and, why not, the family? It’s not to say any bad behavior should be treated any differently, but it’s a good deed which is part of the story.

And shouldn’t we be making good deeds as part of the story that’s unfolding now?

With stories we are already in art.

So as I said I was looking at total war—by the way, my take is that “total war” really became impossible to ignore in 1914, but that this total “charge” of the social environment is actually always already the case, it’s like a certain fundamental tension in the amygdala which is the emergency of being alive and hence at risk of death and suffering and wanting provision—and I’m not thinking about designing a war theory.

You could look at what I’m doing that way, and I am often very angry which at least implies conflict.

But fundamentally my approach is to again emphasize conceptual structures which make it to where war does not exist even if you want to believe in it. This is where emergency is bleeding into what we could call mystical or cosmological experience.

For example, Lila and Ludus Amoris constitute another twin set of concepts just like Tibetan Buddhist Spiritual Warfare and Greater Jihad.

Lila is a concept from Vedic traditions which means that all of experience is the theater piece of the “absolute,” which you might call Brahman or Shakti or another name. This is a theater piece which this fundamental force or entity does out of pure bliss, not for wanting of anything but just in this overflowing.

As a side note, you can tie this overflowing theme into the theme of excess in Bataille and potlatch in Mauss and then Baudrillard, this overbidding and raising of stakes. It is again the sovereignty of this plenipotentiary that it is overflowing into everything we perceive, and all that could possibly be perceived.

I’m also thinking of hypertelia in Baudrillard, which refers to things outliving their purposes and continuing to hang around because nothing else has replaced them. Things which don’t transcend themselves, writes Jean, just continue to have revivals of all kinds.

Meanwhile, Ludus Amoris is about the mystical experience of seeking something spiritual, union with the infinite or any other number of words. Part of the point is that it can’t be put in words, which people will often say after a very intense experience. Anyway, Ludus Amoris means how you will have the sense that you’re “doing it,” that you’re on the right track, and then you’ll lose it. There will be a sense of despair and you will seem to be so infinitely low. And yet maybe a sense of grace or connection or whatever it is might come again.

And this is called “the game of love.” We have the theme of love come in here, as well as, crucially, game.

I think I came across the notion of Alternate Reality Game in this article about QAnon, which was talking about how QAnon took on this form of a participatory game that anyone could get sucked into and then be cast into a whole new domain of discourse that could quickly come to overtake their sense of what is happening.

Now, combine this notion of creating a game, which again is not a war at least not necessarily, and then adding in the recognition above that you can’t influence the big bad “military” structure head on.

Like, I would know people who would pretend like they were going to keep secrets from “the government” and do… something? I never fell for that, maybe just because I know I’m not cut out for it. I’m not gonna keep any secrets, come on. Much less how our phones record us all the time.

So I don’t put any faith in anyone else’s ability to keep a secret either. So what’s the point at that point? You have to operate as though anyone on the “inside” you’re trying to influence already knows everything about you.

Notably, even down to the porn history! So there I am, thinking about all this stuff for years, of course indulging in a little of the erotic narcotic of our times, and it’s like damn! My own “moral failure” aside, it is a totally Baudrillardian thing that pornography totally rivals actual having of sex in terms of time people spend doing it. Maybe it dwarfs it?

It’s kind of like Baudrillard talking about how the virtual economy of derivatives and so on dwarfs the actual economy.

This is related directly into Ben Zweibelson’s notion of phantasmal war.

But I started pinging Ben Zweibelson, well actually I sent Ben an email years ago asking whether they had any recommendations for Baudrillard and military theory.

The issue is as I said, I’m not really looking to enter a chain of command or take any oath or something. I understand that you still retain your own sovereignty and you can mutiny when the time comes or silently defect somehow, but again I’m not really trying to do that.

But the topic of military theory is so important because “War” is apparently the reason why everything is so bad.

As I see it, “the government” is basically like, well, we have to funnel as much as we can into the Greater War Effort, so that’s why so much needs to be sucked out of everywhere else. We can’t have healthcare for you because we need enough GPUs or whatever else in order to compete with whoever.

Getting back to conspiracy theories, I basically landed on the idea that whatever is going on is social networks, it’s not even really institutions. Who knows how that works. 

It’s back to logical types and levels of simulation because it’s like whatever you think is important can be _gamed_. So then it can be made to look a certain way and you’ll fall for it, like a fish that is trying to mate with something that barely even resembles it at all.

That’s sort of how people are with “the government.” They are trying to “mate” with it, to get out of it what they think they want, or something, but it’s not even really the thing that they were looking at.

My own term for how other people see “the state” is semio-stratocracy. This would mean the administration of things according to warfighting concepts. This is big publicly known concepts but also within a social “conflict,” the basic order of battle a person has, their plan for the actions they will execute, what they’ll do if challenged, etc., as they go about their affairs and take their initiatives.

My own concept is semio-subitocracy, which would be administration according to emergency response concepts of operations. We already mentioned that the more cosmic, subtle, and emergent side of things is also important here. 

It’s important to see that this sense is connected to morale, the sense that whatever is ordering things is meaning for you to find success in your endeavors, which must involve risk at some level.

And in that this subtle, story type quality is indispensable. It is not a secondary adjunct to the “hard” theory of forces and technologies, but rather of primary importance as morale is 75% of any endeavor. Getting it going and sustaining it through challenges with people who are getting more and more sophisticated all the time is not easy.

It was also around this time at the end of 2022 that I came across the term _Experimental Unit_ , which I guess I am tied to now in some way.

I liked how it had the connotations from science of the unit of analysis and of course mainly the “martial” connotation of a group that must implement new ways in the field because there is no other way to test them. So it’s doing things no one has ever done, and no one knows how to do, and doing it when the stakes are highest because there is no other opportunity to learn, and at the same time to be waging the crucial struggle of the moment.

There’s also a mystical or cosmic interpretation where experimental means the antiquated notion of experiential, and unit stands for unity in the sense of “the one,” which is a tortured way to say it because of course the whole thing about “The one” is that it is beyond number. Then again, such a thing is beyond any word, so there is nothing good to say.

I may as well introduce another twin set of concepts here, well maybe three. They would be Wakan Tanka, Silap Inua, and Logos.

Wakan Tanka was the main reference, it’s from Lakota lore and it can be translated as “great mystery.” It’s better to just say it that way rather than “the” great mystery, because the article “the” implies this singularity and discreteness which are not actually the case.

This is the kind of conceptual discipline I think is key. There are so many times people wander into unfortunate connotations, and I think it has big consequences as thinking gets sloppy and people have huge things they take for granted, and then build whole practices and edifices of thought and emotion on top of, but maybe the ground’s going to get ripped out from under you, yeah?

That seems to be the issue I have with a lot of people. Everything I say is like it is designed to rip the ground out from under you.

I have big interests in things like skepticism, or also in going into any discourse that might want to be opposing me and running it from the inside, and endeavoring basically to be a better version of whatever those people are claiming to be than they are. I call this Absolute Exploit, which was originally Total Exploit but I changed it to go with the AE symbol.

That’s a whole other thing. It was also at the tail end of 2022 that I discovered Grimes’ album _Miss Anthropocene_. It’s totally perfect because I found it by googling the pun, “misanthropocene,” and then Grimes had made it into another pun. And I knew it would be my favorite album ever, and it is. I think it’s really a historic event and what Baudrillard would call “A Coup For Simulation.” The key idea is the formation of “new gods.” I may read this differently than Grimes. I think _we_ are the new gods.

This is again about overcoming self-ignorance, it is about seeing that we have more capacities than we know. It is the _overflowing_ of these newly appreciated capacities into our expression and internal reflection which is going to get us where we are destined to go.

This is a chain reaction process, where each person who is able to symbolically die and be reborn is then driven to learn how to get through to still more people.

This is my model as opposed to “the imaginary party” by _Tiqqun_ or Invisible Committee I forget. Regardless, it’s a neat idea because it’s so decentralized, the issue with it of course is that it is defined by being at war.

This is an issue that anarchist and communist philosophies inherit, is this fantasy of beating people and defeating them and lording over them to make sure that they _never_ do again what they are doing now.

As opposed to this, we can also jump over to the conception of a religion. So if you’re not going to be a fighter, then you can advocate a religion or start a religion. Just like you could start a business, or design a game, or make a piece of art.

Religion of course casts things in terms of wars, wars of mythical beings which are tied to our struggles here on the planet, so that people who hurt us are actually under the control of cosmic evil, whereas we righteously fight for the cosmic good side.

Yet there are more possibilities.

It was maybe also around the end of 2022, a crucial time and that’s why it’s the start of me and Grimes’ new calendar, by the way. Grimes calls it “the light ages,” which I don’t like, but we can call it “the black light ages,” anyways it was around that time that I had the following idea: 

That at the end of time there would be a general resurrection and all sentient beings ever would all choose to run time over again. At that point, all sentient beings would also say that they would be willing to be any other sentient being.

This is my way of stitching together cyclical and linear notions of time. There is in some sense a linear infinity, with a beginning and end, and that’s all there is. But it’s a cycle in that you run through it over and over, and each time each “immortal soul” is a different piece of the puzzle.

Compare to Tikkun Olam, Apokatastasis, Bodhisattva ideas, Christian Universalism, and I’m not sure probably a lot of things are similar to that.

Anyway, this is the sort of idea that I am interested in as a framing device for big picture affairs. It is something which is going way over the top of the framing stories people are normally invested in.

That said, the whole point of a game is to be engaging to people who could play it.

So, _Experimental Unit_ is a kind of Alternate Reality Game.

The way it works is that you get the general idea of it, and then you can’t stop thinking about it. _Experimental Unit_ is a framing device which looks at your ability to reflect in general, and then opens it up through the aperture of all the things that have been percolating in me.

So first of all, the game can function just as you being interested in and learning more about what I’ve thought and said. In case anyone was interested in that, there is plenty to find and engage with across plenty of platforms.

That’s a big part of the motivation, actually, it’s knowing that if I don’t do something like this, no one is ever going to know anything about me because no one is ever going to ask, and no one was ever going to let me into any fancy rooms even before I did all this. So at least this way I can show you what has been preoccupying me.

And so, if you’re interested in studying me or looking at those ideas, there is plenty which has been worked out in more detail. I’m continuing to bring it to bear, and this paper is itself part of that, basically telling you my motivation.

Yeah, it’s also that this sort of thing is all I care about. Anyone who relates to me on any other level is like not really connecting with me at all. It’s sort of like being in an emergency and the question is, are you helping or are you not helping. I’ve never really been working intimately or talking a lot with anyone I thought was really helping other than me.

It might be arrogant in your opinion that I could think I could really be helping, but again I point to you that the basic issue is that there is this powerful “military” apparatus, and its excuse for existing is that there are other ones like that out there, not to mention diffuse crime and terrorism which would make things impossible without it. 

I say “military” because my position is that there has never been any war, and so institutions which are called military, or endeavors considered as such, are not really martial in their deeper nature. It is again like Lila, where things are instantiations of whatever cosmic thing animates all, back to Wakan Tanka or indeed even the notion of chaos.

Grimes’ _Chaos Manual_ is also an example of an Alternate Reality Game. This sort of frame shifting turns out to be the crucial aspect in “military” affairs themselves. The notion that war is a type of emergency is again relevant here, because it’s to say that war only arises because of the impossibility of dealing with non-martial emergencies in any other way.

The Alternate Reality Game becomes a platform whereby influence operations can be launched and added to a growing portfolio. It’s a way for me to engage with and possibly inspire many people in many places, beyond the necessity of mutual recognition. I suppose I could do some sleuthing based on people’s email addresses, but I don’t.

So beyond learning about me, what is the game _Experimental Unit_? The basic version asks you to imagine that your past life is false memories, and this moment is the beginning of time, and everything is set up for you to have the crucial experience going forward from this position in the awareness you’re populating.

So stuff like, if you were the character in a movie about to realize something, what would it be?

Or, what’s your gut instinct about everything going on in your life?

These are both ways of abstracting over your experience, getting out of your head and trying to look at things from a slightly different perspective.

It’s also again tied into this sense of cosmic purpose, because if your experience is a simulation, or a game created to serve some other function which has nothing to do possibly with events in what you normally consider “reality,” then again the moves you make going forward are in conversation with this sort of “date with destiny” which is the moment of realization which is going to come at the end of the game, e.g. when we die.

The cosmology I sketched above requires a kind of immortal soul and an afterlife. I have tricked out my cosmology with the notion of an afterlife which simply allows you to feel that you “got what you came for” out of life, and in particular that your time incarnated, what we call our life times, was just what it was supposed to be.

I’m concerned about theodicy both in the sense of people being bad but also in the sense of people not doing what they were supposed to do.

I’ll end for now with another family story. My great uncle on my dad’s side, so, spared the bombing in Pirmasens, caused a bunch of problems. Probably people will start comparing me to that person if they haven’t. Go ahead. 

Anyways, my father always said that this person, Albert Braselton, was evil. But his mom, Al’s sister Ann, said that Al wasn’t evil, simply weak.

Weak and evil are two of the basic preoccupations I have.

On the one hand, evil would be someone who is just bad news. Theodicy in the sense of why are people so outrageously cruel? 

On the other hand, weak is the idea not that you did anything that bad, but that you didn’t do what it would have been important to do.

So like that quote where it says all that is required for the triumph of evil is that good people do nothing. Well, if you do nothing, what good are you?

So I’m basically torn between feeling like I must do something, which would require connecting with others, yet that is impossible for a few reasons:

  1. I’m invested in my own concepts and lore and references which are pretty involved, so anyone who wanted to “get to know me” would have a lot to do there, which is again totally doable but people really don’t like to make intellectual efforts and those kinds of things don’t stick with other people, it’s constantly starting over.

  2. In my misery, I have acted out in various ways over the years which basically make me unattractive or maybe people don’t feel safe about me because of things I’ve said or done.

  3. As it goes on, I must admit there is something in my personality which doesn’t really take to other people at least that I’ve met. I’m hostile to many social styles considered “normal,” which also keeps me out of the more advanced academy. But this personality issue and also not really finding the other free thinking intellects very easily is an issue.




On the other hand, I can basically think that I am held back by the people around me. The basic issue I have is that people are too concerned to look strange, or too invested in their normal routines of thinking and feeling, so that they cannot adapt or self-disrupt. In that context, I can’t really work with anyone else.

So then the question is again of what I can do alone. So what I have done is spin a huge web of lore. I would consider some of the big acts that make up _Experimental Unit:_

  1. Having a radio show where I talked my sass for 7 years starting in February 2018.

  2. Giving my talk “Transcommunism in the Transpolitical Age” at the Applied Baudrillard Studies conference in 2018.

  3. Going to CIA HQ in 2020 to deliver my essay _The Metonymy Economy_

  4. I interviewed the guy from the “meme analysis” YouTube channel, and later visited him in New Jersey on the way up to Vervaeke on the same trip as the CIA visit

  5. Going from there to interview John Vervaeke in Toronto with a lot of Percy Shelley discussion

  6. Posting my radio shows to r/Sorcery of the spectacle and starting a discord, spawning some key interactions including why I’m into orange and Inuit mythology. I would go on to visit with one of the founders of that subreddit twice, once around their home and then we met outside Asheville while I was living in Durham. Then in late 2022 I did a road trip to Washington State and met the other co-founded around there, including hanging out in the Twin Peaks town and interesting experiences with someone there with a security clearance.

  7. My engagement with a pornosopher I met online, in my estimation truly a great artist, and culminating on November 25, 2022 at Potlatch State Park in Washington State.

  8. Also around that time, a LOT of voice recorder podcasts released over SoundCloud. I have this whole time been developing this persona of mine of being quite “beyond the pale,” so to speak, and yet I can also be personable and try to be more clear. But my style and establishing that I will express myself in quite unorthodox ways was perhaps set a lot here.

  9. Various acts of outreach undertaken to try and get people aware of _Experimental Unit_

  10. My creation of this blog at the end of 2023

  11. The r/ExperimentalUnit subreddit where I collected many cool links

  12. The r/GrimesAE subreddit where I published thousands of ChatGPT generated articles in various styles and covering the gamut of military theory, approaches to art, tying together various references, demonstrating methods for designing concepts, etc. 

  13. Performance actions like at Lockheed Martin in March 2024, a few other various times, at various corporate and military locations mainly around Atlanta.

  14. Administering various social media accounts and posting creatively on them

  15. In that context getting a phone call on December 22, 2022 from a person who allowed me to think they were Grimes. A strange episode.

  16. Also part of the social media stuff was posting about Ben Zweibelson and the Hegelian E-Girls, which Anna KW one of them follows me on Twitter.

  17. Also Dmitri of _Subliminal Jihad_ was following me on Twitter for a while, maybe still is. 

  18. And then Ben Zweibelson followed me on Twitter and reached out to me on LinkedIn, and on LinkedIn I’m connected with a bunch of military people.

  19. And then Zweibelson put me in touch with other people from the Archipelago of Design and TOGA Trew, and I talked with Dr. BB and Donna Dupont and TOGA. 

  20. Interviewing Benjamin Studebaker for the radio and YouTube about their book _The Crisis Of Legitimacy In Liberal Democracies_

  21. Oh also at one point I spoke to the mayor of Fort Collins, Colorado.

  22. And I had an interview with Russo of the Georgia Emergency Management and Homeland Security Office here.

  23. Various community engagements, in recent time how I’ve gotten involved through various associations starting with the radio station and now spiraling a bit haphazardly shall we say. But still, everywhere I go I am making some kind of indelible impression.

  24. And now my association at Old Wheat Street, part of my continuing emergency response/public worship operation. I am most immediately trying to combine Teaching for Artistic Behaviors ideas with Ben Zweibelson to give creativity exercises or things to do which can accommodate any group, i.e. anyone can do it, but it’s also about being creative towards the most tricky and hallowed ends, like we are really trying to express ourselves or approach a problem in a new way or let go old habits or really be willing to put something at stake that we had always held out until now.

  25. Oh, I’ve also released a music album, and I have a YouTube Channel with dozens of hours of just going through things I find interesting to build basically this nest of lore which is my interests as I’ve explored them so far to show people, and to demonstrate this sort of construction process and how it bleeds from the personal to the artistic to the projects in the world and beyond. My basic idea is that more and more people could engage in projects like this, which transform oneself. In theory :), it could work out that multiple people could do this together.




The limiting factor really is a shared sense of purpose. I feel like setting the goal of trying to find out why we out ourselves in this situation is a good framing. We do not put responsibility for things onto other people, and at the same time we challenge others to realize that in some sense they want us to do everything that we do. 

Navigating this without it becoming excuses for bad behavior is the challenge. We must basically see that not trying to control each other is superior. Instead, we should be appealing to one another, and awaken in each other the drive for augmentation and poetization. 

And the basic idea that this can spread like wildfire, that in some sense “the world” is “made out of kindling,” because there is this endemic fragility which is waiting to be cracked like an egg. What remains is to work out what is profound and deep enough, and yet also communicable and what can be used to entice people.

Finally, a comment about my recent stand-offishness. I have already set something like the goal to become famous. The thing is that I have my own sense of purpose which is more important to me than being in good standing with anyone or any authority on the planet. So, that is what I’ll pursue. I’m not doing nutty things, I am brainstorming but I’ve been doing that for fifteen years.

The point is that I absolutely consider myself a sovereign actor in my own right. You are welcome to browbeat me or try to get me into a position where I have to listen to you and you don’t have to listen to me. But I’m not looking to just let that happen. I have my own view on things which I’m not convinced is any more problematic than yours.

Whether my views and your responses to them have consequences for me is in a way not my concern. It’s like when people say Westerners really don’t get going to war with someone for whom, say, “family honor” is not just something you say but something that is actually taken seriously.

Well, I am of that sort. I’m a zealot like John Brown or someone like that. I am convinced that the things I focus on are important and that we have a great calling to answer in this time. Anyone who tries to dismiss my efforts or express “concern” for me outside the contemplation of the gravity of our situation and what can be done about it will gain no listening ear from me.

Frankly, _I do not have the capacity_ to entertain your second-guessing and ply my trade. I am always doing my best to be as kind and diplomatic as possible, and I am so sorry that my best is all that I’m able to do.

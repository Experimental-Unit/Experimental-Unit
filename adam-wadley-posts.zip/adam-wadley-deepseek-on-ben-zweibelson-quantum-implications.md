---
title: 'DeepSeek On: Ben Zweibelson & Quantum Implications'
subtitle: From Juxtaposition to Superposition
author: Adam Wadley
publication: Experimental Unit
date: December 05, 2025
---

# DeepSeek On: Ben Zweibelson & Quantum Implications
[![](https://substackcdn.com/image/fetch/$s_!4GuS!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb9b47ada-5358-4896-b52f-cc99b85b3c7a_1536x1024.png)](https://substackcdn.com/image/fetch/$s_!4GuS!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb9b47ada-5358-4896-b52f-cc99b85b3c7a_1536x1024.png)

### **Overview**

A defense strategist, [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions), is exploring quantum computing not from a technical/mathematical perspective, but to understand its strategic implications for future human conflict. He is analyzing public documents during a government shutdown.

###  **Part 1: The Geopolitical & Industrial Landscape (Based on MIT QIR 2025 Report)**

  *  **The Second Quantum Revolution:** We are in a new era distinct from the first (1920s-1950s: atomic bomb, radar, lasers). This time, the **commercial sector is leading** investment and innovation, not governments.

  *  **The Race:** The primary competition is between the **US and China**. China leads in quantum communication and volume of research, while the US leads in quality of research, overall achievement, and quantum processing units (QPUs). Europe (Germany, Netherlands, Ireland) and Japan are also significant players.

  *  **Key Metrics:** The report analyzes trends in patents, investment, qubit counts, and research impact (H-index). It notes that **reducing qubit error rates is currently more important than simply increasing qubit count**.




###  **Part 2: Core Quantum Concepts for Security (Based on Kanamori & Yoo, 2020)**

  *  **Foundational Ideas:** Introduces key concepts like **superposition** (a qubit being in multiple states at once) and the construction of **quantum circuits**.

  *  **Quantum Encryption & QKD:** Explains why quantum encryption is theoretically “bullet-proof” due to the **no-cloning theorem** (you cannot copy an unknown quantum state without altering it).

    *  **Quantum Key Distribution (QKD)** is detailed: a method for two parties to generate a shared secret key, where any eavesdropper (Eve) would inevitably introduce detectable errors.

  *  **Current Challenges:** Highlights the major hurdles of **decoherence** (qubits losing state) and the need for **cryogenic temperatures** , which make building practical systems difficult.




###  **Part 3: US Policy & Future Milestones (Based on U.S. DOE Roadmap, 2024)**

  *  **Quantum Supremacy’s Impact:** A quantum computer won’t replace classical computers but will solve specific, currently **intractable problems** (e.g., breaking modern encryption, simulating complex molecules).

  *  **The Hardware Frontier:** The current goal is not just more qubits, but achieving **fault-tolerant quantum computing** by drastically reducing error rates. The DOE outlines 5, 10, and 20-year milestones.

  *  **Strategic Implications:** Achieving supremacy will unlock capabilities in:

    *  **Materials & Drug Discovery:** Simulating molecules in 3D to design new materials, batteries, and pharmaceuticals.

    *  **Quantum Sensing:** Enabling radically advanced detection (e.g., for submarines or astronomical phenomena).

  *  **Security Risks:** Zweibelson raises strategic questions about the destabilizing effect of a **“quantum race,”** including the potential for preemptive actions (kinetic, espionage, sabotage) by nations fearing they are losing.




###  **Author’s Broader Thesis & Approach**

  *  **Purpose:** To apply “strategic and organizational logic” to understand how the “Second Quantum Age” will transform conflict.

  *  **Cognitive Challenge:** He emphasizes that understanding quantum requires a fundamental shift from a **Newtonian to a quantum worldview** , which is cognitively difficult but necessary for future strategists.

  *  **Future Direction:** The series is ongoing, with the author planning to produce two final deliverables from this research while continuing to share his learning process.




Cognitive Challenge: He emphasizes that understanding quantum requires a fundamental shift from a Newtonian to a quantum worldview, which is cognitively difficult but necessary for future strategists.  
  
Spell out what this means exhaustively. Here’s this as well as a source: https://www.airuniversity.af.edu/Portals/10/AUPress/Books/B_181_Zweibelson_Beyond_the_Pale_.pdf

This is the crux of Zweibelson’s entire argument. It’s not about learning a new technology, but about fundamentally rewiring how we think about reality, strategy, and causality. Here is an exhaustive breakdown of what a shift from a **Newtonian to a Quantum Worldview** entails, integrating concepts from his earlier works (like _Beyond the Pale_ ) and the broader quantum paradigm.

* * *

###  **Part 1: The Newtonian Worldview (The “Operating System” of Modern Strategy)**

This is the dominant, intuitive framework that has shaped Western military, organizational, and strategic thought since the Enlightenment. It is the worldview of classical physics.

 **1\. Determinism & Predictability:**

  *  **Core Belief:** The universe is a giant, mechanical clock. If you know the initial conditions (position, velocity, mass) of all parts and the forces acting upon them, you can **predict with certainty** the future state of the system.

  *  **Strategic Analogue:** This drives the obsession with **“centers of gravity,”** detailed campaign planning, and the belief that if we gather enough intelligence (data on initial conditions) and apply the correct doctrine (the laws of motion), we can predict and control the outcome of conflict. War is seen as a complicated but ultimately solvable engineering problem.




 **2\. Reductionism:**

  *  **Core Belief:** To understand the whole, you break it down into its constituent, independent parts. Understand the parts, and you understand the system. The whole is merely the sum of its parts.

  *  **Strategic Analogue:** This leads to **stove-piped organizations** (Army, Navy, Air Force, intelligence), specialized career fields, and fragmented analysis. The enemy is analyzed by breaking down its military, economy, leadership, and population into separate target sets. The belief is that by degrading enough components, the entire system (the enemy’s will) will collapse predictably.




 **3\. Objectivity & the Independent Observer:**

  *  **Core Belief:** There is an objective reality “out there” that exists independently of the observer. The observer can stand outside the system, measure it, and not affect it. The map (our plan/intelligence) can be a perfect, neutral representation of the territory (the battlefield).

  *  **Strategic Analogue:** The commander is seen as an omniscient, external chess master moving pieces on a board. Intelligence is believed to provide a “God’s-eye view.” It fosters the illusion of **detached, rational decision-making** unaffected by the emotions, biases, or very act of observation (e.g., the presence of a drone or special forces team changes local dynamics).




 **4\. Linear Causality:**

  *  **Core Belief:** Cause and effect are linear, local, and proportional. Action A causes Effect B. Big causes have big, direct effects. If a strategy fails, you simply apply more force (a bigger cause) to get the desired effect.

  *  **Strategic Analogue:** The logic of **“kinetic targeting”** and attritional warfare. The belief that killing more enemy combatants or destroying more targets will lead linearly to victory. It underpins rigid planning processes (Input -> Process -> Output) and the search for the “silver bullet” solution.




 **5\. Binary Logic:**

  *  **Core Belief:** Things are either A or Not-A. A particle is here _or_ there. A switch is on _or_ off. This is the logic of classical computation (0 or 1) and Aristotelian logic.

  *  **Strategic Analogue:** **Friend or Foe. Win or Lose. Victory or Defeat.** This creates false dichotomies that obscure complexity (e.g., the “gray zone”). It drives a military culture that seeks clear metrics and binary outcomes, often failing to grasp ambiguous, adaptive, or co-evolutionary conflicts.




* * *

###  **Part 2: The Quantum Worldview (The New, Disorienting “Operating System”)**

This framework, derived from quantum mechanics, contradicts our everyday intuition and demands a radical rethinking of the nature of reality and interaction.

 **1\. Probabilism & Inherent Uncertainty:**

  *  **Core Principle:** At a fundamental level, the universe is **probabilistic, not deterministic**. You cannot know both the position and momentum of a particle precisely (Heisenberg’s Uncertainty Principle). You can only calculate **probabilities** of outcomes.

  *  **Strategic Implication:** Strategy must abandon the illusion of certainty and prediction. It must embrace **planning for possibilities and resilience** rather than betting on a single predicted future. Intelligence will always be incomplete and fuzzy. The focus shifts from “What will happen?” to **“What might happen, and how do we remain agile enough to adapt?”**




 **2\. Holism & Non-Locality (Entanglement):**

  *  **Core Principle:** The whole is **greater than the sum of its parts**. Parts can be “entangled”—instantaneously connected regardless of distance, where the state of one defines the state of the other. This connection is non-local (not limited by space).

  *  **Strategic Implication:** Reductionism fails. You cannot understand an insurgent network by studying individual members in isolation. The relationships and the **system’s emergent properties** are key. An action in the information domain (cyber, narrative) can have instantaneous, non-local effects in the physical or social domain. Strategy must think in terms of **complex adaptive systems and networks** , where interventions have ripple effects that are impossible to fully trace linearly.




 **3\. Observer-Dependence & Subjectivity:**

  *  **Core Principle:** The act of **measurement (observation) affects the system being observed** (the observer effect). There is no “view from nowhere.” The choice of _how_ you ask a question (what you measure) determines the kind of answer you get.

  *  **Strategic Implication:** The strategist/commander is **part of the system** , not outside it. Every intelligence collection, every drone flight, every public statement changes the adversarial and operational environment. Strategy is a **co-evolutionary dance** with an adaptive enemy. The “map” is not neutral; the very process of creating it alters the “territory.” This demands reflexivity—constant awareness of how our own actions and frameworks shape the reality we are trying to influence.




 **4\. Non-Linear Causality & Superposition:**

  *  **Core Principle:** A quantum system can exist in multiple states at once ( **superposition** ) until measured. Cause and effect are not linear; small, precise interventions at a critical point ( **quantum tunneling** ) can lead to disproportionately large, unpredictable effects. Effects can also precede causes in our classical understanding (retrocausality in some interpretations).

  *  **Strategic Implication:** The search for the single, massive “center of gravity” is a Newtonian fallacy. Instead, strategy should look for **asymmetric, non-linear leverage points**. A meme, a clever hack, or a targeted special ops raid (a small, precise intervention) could collapse an adversary’s will or system in ways a massive bombing campaign could not. It’s the logic of **effects-based operations** taken to a philosophical extreme, recognizing that the pathways of effect are tangled and probabilistic.




 **5\. Dialectical Logic (Both/And):**

  *  **Core Principle:** A qubit can be both 0 and 1 simultaneously. Light can be both a particle and a wave. Quantum logic embraces **complementarity** —two seemingly contradictory descriptions can be true, depending on context.

  *  **Strategic Implication:** Move beyond **binary (either/or) thinking**. An actor can be both a local insurgent _and_ a global jihadist. A conflict can be both war _and_ peace. A tool can be both stabilizing _and_ destabilizing. Strategy must hold **multiple, contradictory truths** in mind simultaneously and navigate the tension between them. It requires a tolerance for ambiguity and paradox that is anathema to traditional military planning.




* * *

###  **Part 3: The Cognitive & Institutional Challenge (Why It’s So Hard)**

 **1\. Deeply Ingrained Metaphors:** Our language and mental models (war as a “game of chess,” organizations as “machines,” strategy as a “blueprint”) are overwhelmingly Newtonian. We lack the vocabulary and metaphors for the quantum world.

 **2\. Institutional Inertia:** Doctrine, procurement, training, promotion systems, and planning processes (like the Joint Planning Process) are codified expressions of the Newtonian worldview. Shifting them is like trying to change the foundation of a skyscraper while it’s occupied.

 **3\. Psychological Discomfort:** The quantum worldview is uncomfortable. It replaces certainty with probability, control with influence, and clear orders with adaptive guidance. It demands humility and intellectual flexibility, which can be perceived as weakness in hierarchical, decisive cultures.

 **4\. The “Pale” Analogy (From** _ **Beyond the Pale**_ **):** Zweibelson uses the metaphor of the “pale”—the fence around a settled area. Inside the pale is the familiar, ordered, Newtonian world of doctrine and known rules. **“Beyond the pale”** is the disordered, complex, quantum reality of modern conflict. The military’s instinct is to try to extend the fence (apply more Newtonian control) rather than learn to operate in the wilderness on its own terms.

###  **Conclusion: What a “Quantum Strategist” Must Do**

To make the shift, a strategist must:

  *  **Embrace Ambiguity & Probability:** Trade certainty for adaptability.

  *  **Think in Systems & Networks:** See connections, not just components.

  *  **Practice Reflexivity:** Constantly ask, “How is my own thinking and acting changing the game?”

  *  **Seek Non-Linear Leverage:** Look for precise, catalytic actions over brute force.

  *  **Tolerate Paradox:** Hold multiple competing realities as simultaneously true.

  *  **Abandon the “View from Nowhere”:** Accept that they are an embedded, influential participant in the system they are trying to shape.




Ultimately, Zweibelson is arguing that the **tools of the Second Quantum Revolution (QC, sensing, networking) will emerge from and empower a quantum reality.** Adversaries who grasp the quantum worldview—even without the hardware—will possess a profound conceptual advantage over those still fighting with a Newtonian mind inside a quantum world. The cognitive shift is not optional; it is the prerequisite for relevance in future conflict.

---
title: Russell Brand And "Heil Hitler" Kanye Song Reaction
subtitle: Into The Mælstrom, Into The Fray
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Russell Brand And "Heil Hitler" Kanye Song Reaction
Oh boy.

Look, this isn’t any more comfortable for me than it is for you. But you’ve got to eat your vegetables. Alright, let’s see.

I just found out about these [comments that Russell Brand made](https://forward.com/fast-forward/719659/russell-brand-defends-yes-heil-hitler-music-video/) about Kanye’s song “Heil Hitler” that recently came out.

We can just go Lexus/lexis style:

>  **By[Grace Gilson](https://forward.com/authors/grace-gilson/)May 13, 2025**
> 
> ([JTA](http://www.jta.org/)) — Russell Brand, the actor and iconoclastic activist, defended Kanye West’s latest song, titled “Heil Hitler,” saying that the artist now known as Ye is “uncancellable.”

I was just watching the Colbert clip about #CancelColbert back in the day.

The thing with Kanye at this point is that the damage has been done. The question in a way is where does it go from here, because there’s still the chance for any number of reversals or twists that could throw even more in the spanner. Especially if I can get my influence going _rubs hands._

Still, this language use is coded with a certain slant, it signals a certain normative set of assumptions and that’s going to run through the response which is given here.

> “‘Heil Hitler’ @kanyewest is uncancellable because he reached such a zenith in the culture that he couldn’t be killed,” said Brand in a post on X. “I think people would like it if he died. Why? Because he’s a problem for their agenda. Also, let’s be honest; the hook is catchy.”

As I said, it kind of doesn’t matter if Kanye dies. It’s a point I’d like to think I’ve achieved as well, where in terms of your goals, your goals are just to create with as much intensity as you can during your life, and then if you die then it just adds to your legend and maybe then people can acknowledge how great your work was once it can no longer go to your head. They’ll always forget about you and move on to the next shmo who flows, but what of it? Go on singing.

Anyway, again the idea of people and their agenda, it’s sickening how easily this just play into the idea that yup, Jewish people are the problem and that’s why they don’t like this. And while we’re at it, Adolf Hitler was not so bad and there’s a lot of people who need to go when you think about it…

Absolutely not. The horrible thing or whatever is that as Baudrillard wrote:

> Revolutionary theory also enshrined the living utopian hope that the State would wither away, and that the political sphere would negate itself as such, in the apotheosis of a finally transparent social realm. None of this has come to pass. 
> 
> The political sphere has disappeared, sure enough - but so far from doing so by means of a self-transcendence into the strictly social realm, it has carried that realm into oblivion with it. 
> 
> We are now in the transpolitical sphere; in other words, we have reached the zero point of politics, a stage which also implies the reproduction of politics, its endless simulation. 
> 
> _For everything that has not successfully transcended itself can only fall prey to revivals without end._
> 
> So politics will never finish disappearing - nor will it allow anything else to emerge in its place. A kind of hysteresis of the political reigns. 
> 
> Art has likewise failed to realize the utopian aesthetic of modern times, to transcend itself and become an ideal form of life. 
> 
> (In earlier times, of course, art had no need of self-transcendence, no need to become a totality, for such a totality already existed - in the shape of religion.) 
> 
> Instead of being subsumed in a transcendent ideality, art has been dissolved within a general aestheticization of everyday life, giving way to a pure circulation of images, a transaesthetics of banality. 
> 
> Indeed, art took this route even before capital, for if the decisive political event was the strategic crisis of 1929, whereby capital debouched into the era of mass trans politics, the crucial moment for art was undoubtedly that of Dada and Duchamp, that moment when art, by renouncing its own aesthetic rules of the game, debouched into the transaesthetic era of the banality of the image.

In other words, things must transcend themselves. Therefore the question with respect to Nazism and antisemitism is not about their negation—for, if you follow, this is a continuation of the logic animates them, this expulsion and extermination of what is beyond understanding or subjection to the hateful and internally violent official myth of the community—not about their negation but their self-transcendence.

Alternatively, we can read it that somehow the issue here is still to do with our self-transcendence, not that we are Nazis but that we are falling prey to revivals without end of our own lack of a good response to this cult of purity marshaled along the most obvious axes of bigotry.

And in this larger sense, I think when it comes to the chagrin that very “powerful” people should pursue their interests, my position is that everyone should be able to do what is right for themselves.

I think the field of contestation or iterative displays of operational concepts, shall we say, would have to do expressly with the question of what constitutes the interests of all.

My basic position is that a technologically empowered hyperorder which thrives on rigid classification and destruction of “undesirables” will wind up killing everyone and making everyone so next-level miserable that they wish they had been part of the xenophobic out-group.

The tough nut to crack is how to get along together, and on a fractal level the question is whether we are trying to take advantage of each other in a good way or a bad way.

It’s maddening to discuss because anything we might want to do could be an excessively rigid expectation. You dream of walking along the beach with your child, but they are born without legs.

So do you love the child which is there less because it cannot fulfill your expectation? At the same time, that wasn’t a silly dream or anything, if you like to walk along the beach.

Yet it’s easy to see that people can be quite cruel, as Brand is here being by speaking so recklessly about people in a way which could feed bigotry and kinetic attacks.

So yeah, we are looking to self-transcend, actually, because the Nazi ideology as inherited is not only unspeakably harmful to those it officially persecutes but is also incredibly self-destructive.

While coding as “transgressive” and taking sovereignty, to chain oneself to Nazism is actually to eroticize your own submission to the simulation of a power structure.

Especially now, well, it’s not the 1940s.

So, the upshot of all of this is going to be that it’s a lily pad for me to get my own influence out there, which is why this interview is a double edged sword because more general statements on “the impact of art” and hate symbols is going to come up.

> The rapper’s [new music video](https://www.jta.org/2025/05/08/culture/ye-debuts-heil-hitler-music-video-that-includes-a-sample-of-a-hitler-speech) was released Thursday and features the hook, “All my n—-s Nazis, n—a, heil Hitler.” It also contains a sample from a speech by Adolf Hitler.
> 
> In a video, he expanded on the sentiment in his tweet.
> 
> “He’s working with a lot of ideas when you say ‘N-word Heil Hitler,’” said Brand. 

So this is very vague. I am basically saying the same thing with my article about the two N Words. In fact, _Experimental Unit_ takes credit for Brand having that idea, I’m sure my black moths are flying fast. Think also of the second and third-order people, the people who just heard my radio show once but it really did influence them. I don’t know how I’m just allowed to continue to get away with it. I must lead a pretty charmed existence, or I’m just mythologizing something ho-hum. But everything is pretty ho-hum when you think about it. It’s this destitution of stakes. Like, what does it even matter if the evil people win? They get to enjoy the universe for eternity while I am just dead? Okay, and? It’s hard to explain, you probably think that’s nuts. But try and remember that when you are zenned out. It’s kind of funny that people worry about stuff like that when time isn’t even really real, or something.

Anyways, sorry for getting side-tracked during the _very important article_. So yes, the two N Words, the N word proper if you will and then Nazi.

Brand is like I said being vague. If the N words are Nazis then it stands to reason that Nazis are N words. We connect this then also with Terry Davis who said that CIA N words or glow N words glow in the dark.

Note here also the dark, as in “this is the song I wrote you in the dark,” as in _My Beautiful_ Dark _Twisted Fantasy_ , as in “My Name is _Dark_ (Art Mix).”

The CIA type people are also sometimes called the _Men in Black_. Also relevant here are terms like _black operations_ and _black propaganda_ , not to mention _black budget_ and _black site_.

Then, there are Nazi associations with the color black itself. In the description of the Nazi flag [Hitler says](https://en.wikipedia.org/wiki/Flag_of_Nazi_Germany):

> The Nazi flag takes its colours from the imperial tricolour, with Hitler writing that he "was always for keeping the old colours", because he saw them as his "most sacred possession" as a soldier, and also because they suited his personal taste. Hitler added new symbolism to the colours, stating that "[t]he red expressed the social thought underlying the movement. White the national thought", and that the black swastika was an emblem of the "[Aryan race](https://en.wikipedia.org/wiki/Aryan_race)" and "the ideal of creative work which is in itself and always will be anti-Semitic."

Note that black white and red are the first three colors which are usually named in a given language. This color scheme is itself “intense,” and the Nazi flag is obviously striking. Nazism “ruined” the swastika, and many aspects of their iconography carry this meta-awareness that they are associated with the Nazis, because such association is flagged given our awareness of the singularity, or the singularity of our awareness that Nazism is an evil and destructive ideology.

This description also is extremely notable to me by Hitler because it says that creative work is anti-Semitic. This is the kind of thing where I really do not understand what is being said.

It seems to me to be so false on its face, and yet so core to what is driving Hitler’s motivation.

There is obviously this double thing with Nazism and Judaism and Jewish people, some sort of revulsion because Jewish people want to destroy the nation or something like that. But at the same time there is a kind of begrudging respect or negative deification of the figure of the Jewish person or of Judaism, like it’s this super strong Nexus and that in some ways that influence is to be learned from, so that whatever nation is being threatened can learn the secrets and then do it’s own thing.

Since, of course, in each national imaginary there is the idea that, well, of course _we_ are the baseline standard. And of course _we_ know who we are.

When really, the whole thing is much like a dream where you don’t really know where you came in.

Then there is the Black Sun, which is also what is called the [sonnenrad](https://en.wikipedia.org/wiki/Black_Sun_\(symbol\)). This symbol was installed in the SS headquarters designed by Heinrich Himmler. Notably, apparently the original version was dark green and not black. 

In turn this symbol is abstracting over [certain runes](https://en.wikipedia.org/wiki/Sowil%C5%8D_\(rune\)) from old Norse and English and other Germanic details.

Then as I’ve gone over many times before, the N word and the swastika, and I suppose the sonnenrad is up there as well, these are like the most hot-button symbols that we have. Although there are others.

But still, it is indeed a lot of ideas to put together the N word and the word Nazi. But I look at it like _mother!_ That movie basically shows you how good poetry can lead to tears even if you do it gently.

How much worse can it be if incendiary things are made which could encourage people to kill each other?

My position is that each preventable death is an unspeakable tragedy.

So, whatever influence network or social network there might be that anyone is interested in or worried about, by all means let them face accountability.

Accountability just as severe and stringent as you and I will face, mind you.

Anyway, this is one of the big lines for me, because Brand is bringing something to the fore which I think is true, which is that smashing together the N word with the word Nazi is artistically doing something.

But you can see how much I do with it. I’d go into Afropessimism to say that anti-blackness is again this projection of ontological terror, why our common sense doesn’t work out, we project it onto a kind of person who just is the worst.

It is similar with Jewish people and with Nazis as well, because Nazism now is not just itself but its context as itself being a pariah “Identity.” So the choice to go into it in a way forces a certain degree of self-awareness because it’s in a way impossible not to know that “getting into Nazism” will cause many people to think you are dangerous, and they’d likely be right.

Yet there is also all-to simple overlap in hatred for those identified as Jewish between black nationalist groups in the “US” and also of course Nazis. As I said, the answer to this kind of scapegoating can only come through actual accountability that yields system results that are trust _worthy_ , not just that demand to be trusted.

If people think they are being neglected as sentient beings, and they express it as that they are being left behind as a member of some group, well have a little patience.

Everyone it looks like is being left behind. We are leaving each other behind. It’s hard to understand that it’s not just happening to you, and it’s not just happening to people like you.

The “enemy” or what is in the way is entrenched ways of looking at things, not people. This scapegoating is also designed to stunt thinking so that people only accept simple solutions and don’t want to get into details that could throw their convictions into doubt.

Normal Finkelstein again said recently that the question of antisemitism comes after the question of who is Jewish, and that this is an open question. So just as there must be a self-transcendence of Nazism, or of anti-blackness or white hyperreality, there must also be a self-transcendence of Judaism. I admit it is a very nerve-wracking topic for me to write about, I told you about my family history and everything. 

> “Now, firstly, Kanye West is a product of the culture, commenting on the culture. Why is the phrase Heil Hitler offensive? Because it’s seen as a vow and act of reverence to a leader that executed millions of people and waged war throughout Europe that led to so much destruction and disaster.”
> 
> He added, “Kanye is a unique figure because he’s uncancellable.” He acknowledged that Ye is not a “perfect person.”
> 
> Last week, on his podcast, Brand praised Ye minutes after playing a clip of Ye discussing how he wanted to say “N—a, Heil Hitler.”
> 
> “You have to recognize that art has a function, and that the function of art is to have difficult conversations,” Brand [said on his May 8 episode](https://x.com/i/broadcasts/1rmxPynDOXqKN). “You have to celebrate voices like Ye’s, true artists that are willing to go into very, very difficult situations in order to tell the truth. Without truth there is no art.”
> 
> Brand has cultivated a provocative public persona partly centered on discussing conspiracy theories, has long been a harsh critic of Israel and more recently [attracted a far-right following](https://www.nytimes.com/article/russell-brand-career-timeline.html). He is currently facing facing charges of rape, sexual assault and indecent assault in London. He was [granted bail in court](https://www.bbc.com/news/articles/cvg7y1xx87no) earlier this month.

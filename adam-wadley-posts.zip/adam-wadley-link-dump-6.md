---
title: 'Link Dump #6'
subtitle: The Heat Goes On
author: Adam Wadley
publication: Experimental Unit
date: July 19, 2025
---

# Link Dump #6
[![](https://substackcdn.com/image/fetch/$s_!iXWa!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc16faa66-44be-4081-8780-faeec2d658e3_478x135.png)](https://substackcdn.com/image/fetch/$s_!iXWa!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc16faa66-44be-4081-8780-faeec2d658e3_478x135.png)

  1. [Pulp Fiction Script](https://script-pdf.s3-us-west-2.amazonaws.com/pulp-fiction-script-pdf.pdf)

  2. [Lyrics to Pink Floyd’s “Cymbaline”](https://www.azlyrics.com/lyrics/pinkfloyd/cymbaline.html)

> The lines converging where you stand  
> They must have moved the picture plane  
> The leaves are heavy around your feet  
> You hear the thunder of the train  
> And suddenly it strikes you that they're moving into range  
> And Doctor Strange is always changing size

  3. [Interview: Supernatural: Grimes on searching for her final form](https://www.dazeddigital.com/beauty/article/46661/1/supernatural-grimes-on-searching-for-her-final-form-miss-anthropocene-interview)

>  **You talked about killing off your Grimes persona previously. What is the current dissonance between your own person, c, and Grimes the producer and musician? Through different album cycles and your own personal evolution, how the media has portrayed you and zoned in on aspects of your life over the years, how have you squared off with your sense of identity and personhood?**
> 
>  **Grimes:** my previous self got too distorted by the media. It was a real war zone for a minute! Some of it was certainly my fault, but it turned into a runaway train and I didn’t really have a team at the time to help me correct the narrative. I didn’t really know how to handle it, so I just let it go crazy and focussed on my real life. After a while, you disengage entirely from the persona that is being covered and enter a chill zone without a real sense of identity. I got to a real quiet .. _real_ place. 
> 
> Mentally hit reset. Lost myself again.
> 
> I mean, I see why people were mad, saying things like I abandoned my old self. Cuz I did. I do that a lot, actually.
> 
> Every time theres a big dangerous jump in front of me, I take it. It’s my rule. Run into the scary future and never think twice. Thats what an artist has to do. Ultimately this gets me in a lot of trouble, and leads to a lot of life-resets. Maybe I let people down, because they think change is disingenuous. But the only consistent thing in my life is change. And sometimes I look back at Claire and Grimes and c and whoever else I’ve been, and those names feel so loaded. Those stories are all quite heavy. I don’t want to be what I was. I want to make new things.
> 
> I’m not in the business of drama.. if people want to fight me, I won’t fight back. So a lot of weird stuff stands unchallenged. But I’m here to make art. My proximity to drama is an unfortunate side-effect of the path I had to take to make the best art. But pain gives me a lot. And luckily, I’m about to release a lot of the stuff I’Ve been working on, so yeah. 
> 
> I feel like a new person now.

  4. [r/Grimezs thread: Just Grimes defending someone who defends AI CSAM](https://www.reddit.com/r/grimezs/comments/1l6ubxm/just_grimes_defending_someone_who_defends_ai_csam/)

[![](https://substackcdn.com/image/fetch/$s_!cAtj!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F35629de3-5c0b-4eb4-8910-8b20cb80cee2_937x778.png)](https://substackcdn.com/image/fetch/$s_!cAtj!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F35629de3-5c0b-4eb4-8910-8b20cb80cee2_937x778.png)

  5. [Alexander Cædmon Karp: Aggression in the Lifeworld](https://kristindemontfort.substack.com/p/alex-karps-aggression-in-the-lebenswelt)

> From today’s perspective, Adorno remains imprisoned to his own time. He overlooks much which has since become self-evident. But perhaps it is because of this very reason that he was able to see that particular forms of irrationality could have a purgative quality. 
> 
> **Integration can be carried out at the expense of the marginalized without violation of cultural or social rules.**
> 
> Here I would like to note some limitations of this work. For example, I must forgo some of what Adorno characterizes. Admittedly, I cannot take on the underlying source of Adorno’s unease. From my perspective, I can only try to comprehend in translation _the brokenness of a subject detached from enjoying a real intersubjective experience with her fellow human beings_. This translation changes the sense of the unease and hence, its effect. Furthermore, from my point of view, this unease is only able to be brought to the fore at all if I first develop a concept of drive. In other words, I cannot introduce a concept of intersubjectivity that is immanently philosophical. 
> 
> **Frictions that prompt actors to action cannot, so I believe, be derived from any existential condition.**
> 
>  **These arise out of a mutual tension: on one hand, from the cultural demands that are accepted and internalized and, on the other hand, from the desires that remain taboo.**

  6. [Archipelago of Design Network: Ofra Graicer](https://aodnetwork.ca/author/ofragraicer/)

> Ofra co-instructs the Israeli Defense Forces Generals’ Course alongside BG (Ret’) Dr. Shimon Naveh, where they prepare Senior Military Officers for General Staff level of performance, and guide them through the process of devising strategy and operations for the new era.

  7.  _[Understanding the Military Design Movement](https://dn721806.ca.archive.org/0/items/zweibelson-utmdm/%28Routledge%20Studies%20in%20Conflict%2C%20Security%20and%20Technology%29%20Ben%20Zweibelson%20-%20Understanding%20the%20Military%20Design%20Movement_%20War%2C%20Change%20and%20Innovation-Routledge%20%282023%29.pdf)_[ by Ben Zweibelson](https://dn721806.ca.archive.org/0/items/zweibelson-utmdm/%28Routledge%20Studies%20in%20Conflict%2C%20Security%20and%20Technology%29%20Ben%20Zweibelson%20-%20Understanding%20the%20Military%20Design%20Movement_%20War%2C%20Change%20and%20Innovation-Routledge%20%282023%29.pdf)

> This at times would be contradicted by the success of his co-educator, Dr. Ofra Graicer who is not a general (nor male in a male-dominant profession). Ofra has taught design with Naveh for decades, and while not a general, is an experienced member of the IDF. Naveh, over the years, has changed his position on who should learn design and when within their career and level of power and authority. Sometimes this appears to align with who is willing to invite Naveh to their schoolhouse to teach design, but Naveh has also suggested that complex warfare rarely presents any universal tenets or rules, including where design investment should be made. Regardless, the only path to design education today in the IDF is through attendance at the General Officer School in Herzliya, part of the northern district of Tel Aviv as of 2021. Only generals learn design in Israel, although they certainly lead their units and disseminate design across their subordinates as they see fit. 
> 
> **This remains a unique quality of Israeli security design and does not replicate elsewhere.**

  8. Tim Miller: Podcast Bros Realize Trump Was Never Serious

  9.  _[Army Special Operations Warns Retired Members of Terror Threat](https://www.nytimes.com/2025/07/17/us/politics/army-special-operations-terror-threat.html)_

[![](https://substackcdn.com/image/fetch/$s_!awBe!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3c388513-a74b-480a-900b-56ee9cbbe5db_807x212.png)](https://substackcdn.com/image/fetch/$s_!awBe!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3c388513-a74b-480a-900b-56ee9cbbe5db_807x212.png)

  10. [IDF Military Colleges](https://www.idf.il/en/mini-sites/military-colleges/)

>  **Brigadier Generals’ Course - a unique program launched in 2014 with trainees from all security arms of the State of Israel.** Throughout the course, trainees and faculty conduct a _systemic inquiry_ that are _planned and implemented by the participants themselves_ and study structured contemporary strategic matters. The program is run multiple times throughout the year, and is administered by the Commander of the IDF Colleges along with a team of senior instructors.

  11.  **Why Generals need to forget before they can become generals | Ofra Graicer | TEDxTelAvivUniversity**

  12. Ofra Graicer - Systemic Operational Design

  13. [Wikipedia page for lolicon](https://en.wikipedia.org/wiki/Lolicon)

> Culture and media scholars responding to _lolicon_ generally identify it as distinct from attraction to real young girls.[[143]](https://en.wikipedia.org/wiki/Lolicon#cite_note-160) Cultural anthropologist Patrick W. Galbraith finds that "from early writings to the present, researchers suggest that _lolicon_ artists are playing with symbols and working with tropes, which does not reflect or contribute to sexual pathology or crime".[[24]](https://en.wikipedia.org/wiki/Lolicon#cite_note-FOOTNOTEGalbraith2016114-29) Psychologist [Tamaki Saitō](https://en.wikipedia.org/wiki/Tamaki_Sait%C5%8D), who has conducted clinical work with _otaku_ ,[[144]](https://en.wikipedia.org/wiki/Lolicon#cite_note-FOOTNOTEGalbraith2011105%E2%80%93106-161) highlights an estrangement of _lolicon_ desires from reality as part of a distinction for _otaku_ between "textual and actual sexuality", and observes that "the vast majority of _otaku_ are not pedophiles in actual life".[[145]](https://en.wikipedia.org/wiki/Lolicon#cite_note-FOOTNOTESait%C5%8D2007227%E2%80%93228-162) Manga researcher [Yukari Fujimoto](https://en.wikipedia.org/wiki/Yukari_Fujimoto) argues that _lolicon_ desire "is not for a child, but for the image itself", and that this is understood by those "brought up in [Japan's] culture of drawing and fantasy".[[146]](https://en.wikipedia.org/wiki/Lolicon#cite_note-FOOTNOTEGalbraith2017114%E2%80%93115-163) Sociologist Mark McLelland identifies _lolicon_ and _yaoi_ as "self-consciously anti-realist" genres, given a rejection by fans and creators of "three-dimensionality" in favor of "two-dimensionality",[[147]](https://en.wikipedia.org/wiki/Lolicon#cite_note-FOOTNOTEMcLelland2011b14-164) and compares _lolicon_ to the _[yaoi](https://en.wikipedia.org/wiki/Yaoi_fandom)_[ fandom](https://en.wikipedia.org/wiki/Yaoi_fandom), in which fans consume depictions of homosexuality which "lack any correspondent in the real world".[[148]](https://en.wikipedia.org/wiki/Lolicon#cite_note-FOOTNOTEMcLelland2011b14%E2%80%9315-165) Setsu Shigematsu argues that _lolicon_ reflects a shift in "erotic investment" from reality to "two-dimensional figures of desire".[[149]](https://en.wikipedia.org/wiki/Lolicon#cite_note-FOOTNOTEShigematsu1999138-166) Queer theorist Yuu Matsuura criticizes the classification of _lolicon_ works as "child pornography" as an expression of "[human-oriented sexualism](https://en.wikipedia.org/wiki/Human-oriented_sexualism)" which marginalizes [fictosexuality](https://en.wikipedia.org/wiki/Fictosexuality), or _[nijikon](https://en.wikipedia.org/wiki/Nijikon)_ , describing sexual or affective attraction towards two-dimensional characters.

  14. [Wikipedia page for Fictosexuality](https://en.wikipedia.org/wiki/Fictosexuality)

> Fictosexuals have been marginalized or concealed in societies that adhere to the norm of sexual attraction to human beings.

  15. [Wikipedia](https://en.wikipedia.org/wiki/FicInt) page for FICINT

> The [US Army Training and Doctrine Command](https://en.wikipedia.org/wiki/United_States_Army_Training_and_Doctrine_Command) Mad Scientist Laboratory project[[5]](https://en.wikipedia.org/wiki/FicInt#cite_note-5) provides a formal definition of fictional intelligence:
> 
>  _"FICINT, also known as fictional intelligence or "useful fiction," combines extensive research and futures forecasting with worldbuilding and narrative. The finished product involves an engaging and plausible storyline to introduce readers to novel trends and problems."_[ [6]](https://en.wikipedia.org/wiki/FicInt#cite_note-6)
> 
> The aim of FICINT is to spark discussions, challenge established thought, and provide creative insight into future scenarios.[[7]](https://en.wikipedia.org/wiki/FicInt#cite_note-7) In short, writes the National Defense Magazine, the goal "is to achieve greater reach and impact of research and analysis through sharing them through the oldest communication technology of all—a story."

  16. [Social Constructivist Section from Wikipedia page on adolescent sexuality](https://en.wikipedia.org/wiki/Adolescent_sexuality#Social_constructionist_perspective)

> The social constructionist perspective (see [social constructionism](https://en.wikipedia.org/wiki/Social_constructionism) for a general definition) on adolescent sexuality examines how power, culture, meaning and gender interact to affect the sexualities of adolescents.[[54]](https://en.wikipedia.org/wiki/Adolescent_sexuality#cite_note-Tolman1-54) This perspective is closely tied to [feminism](https://en.wikipedia.org/wiki/Feminism) and [queer theory](https://en.wikipedia.org/wiki/Queer_theory). Those who believe in the social constructionist perspective state that the current meanings most people in our society tie to female and male sexuality are actually a social construction to keep [heterosexual](https://en.wikipedia.org/wiki/Heterosexual) and privileged people in power.[[55]](https://en.wikipedia.org/wiki/Adolescent_sexuality#cite_note-55)
> 
> Researchers interested in exploring adolescent sexuality using this perspective typically investigates how gender, race, culture, [socioeconomic status](https://en.wikipedia.org/wiki/Socioeconomic_status) and [sexual orientation](https://en.wikipedia.org/wiki/Sexual_orientation) affect how adolescent understand their own sexuality.[[56]](https://en.wikipedia.org/wiki/Adolescent_sexuality#cite_note-56) An example of how gender affects sexuality is when young adolescent girls state that they believe sex is a method used to maintain relationships when boys are emotionally unavailable. Because they are girls, they believe they ought to engage in sexual behavior in order to please their boyfriends.

  17. [WE DO NOT CONTROL THE NARRATIVE: A RETRO-REVIEW OF JOHN CARPENTER’S FILM IN THE MOUTH OF MADNESS (1994)](https://cdn.ahpweb.org/AHPb/self-and-society/NL_04/nl-2020-t4-20-dan_t_film_retro_review.pdf)

> Cane is offering to Trent a therapeutic awakening. 
> 
> _Sutter Cane: Do you want to know the problem with… religion, in general? It’s never known how to convey the anatomy of horror. Religion seeks discipline through fear… yet doesn’t understand the true nature of creation. No one’s ever believed it enough to make it real. The same cannot be said of my work._
> 
> Reality is not something which we decide. Reality, as we know it, is a created narrative. As Linda says, ‘A reality is just what we tell each other it is’. Trent’s resistance to this is characteristic of his arrogant self-assurance in his own ways of seeing – which reflects the delusion that we are masters of the reality we are thrown into. In the film’s most iconic scene, a rip appears in the fabric of reality – a rip that resembles the torn page of a book. Trent approaches this rip – Linda narrates his actions from Cane’s manuscript: 
> 
> _Linda: [Trent] stood at the edge of the rip, stared into the illimitable gulf of the unknown, the Stygian world yawning blackly beyond. Trent’s eyes refused to close. He did not shriek but the hideous unholy abominations shrieked for him._
> 
> In this ‘Gulf of the Unknown’, Trent sees the disgusting array of creatures (the ‘Old Ones’) which defy rationalisation or comprehension. The shock of what he sees, followed by his mad flight from the ‘wall of monsters’, displays that all he can do is run from the things that do not make sense. 
> 
> Trent flees, because _what he sees is something which he does not want to exist_ , a thing he does not want to experience because he can no longer rationalise it; his flight is an attempt to negate it because it horrifies him. 
> 
> As Blyth (2018, p. 105) has said, ‘the horrors [of the film] stem from a kind of _existential dread_ … in the notion that _our otherwise solid understanding of reality and stable notions of existence… are all just insubstantial collective delusions’_. 
> 
> Trent, arrogant and selfconfident as he is, consistently decries the abnormal as hoaxes – but it is at this point where his rational structures fail him; he cannot fathom the irrational army of things that have been unleashed on to the world. Trent knows that his rational conception of the world is no longer tenable – only madness is the answer to this profound vulnerability.

  18.  **[The Fauna of Mirrors, by Borges](https://enthusiasms.org/post/1377639935)**

> One night the mirror people invaded the earth. Their power was great, but at the end of bloody warfare the magic arts of the Yellow Emperor prevailed. He repulsed the invaders, imprisoned them in their mirrors, and forced on them the task of repeating, as though in a kind of dream, all the actions of men. He stripped them of their power and of their forms and reduced them to mere slavish reflections.
> 
> Nonetheless, a day will come when the magic spell will be shaken off. The first to awaken will be the Fish. Deep in the mirror we will perceive a very faint line and the color of this line will be like no other color. Later on, other shapes will begin to stir. Little by little they will differ from us; little by little they will not imitate us. They will break through the barriers of glass or metal and this time will not be defeated. Side by side with these mirror creatures, the creatures of water will join the battle. In Yunnan they do not speak of the Fish but of the Tiger of the Mirror. Others believe that in advance of the invasion we will hear from the depths of mirrors the clatter of weapons.

  19. [“Boogie’s Boys” [BB] — Lock, Shock, and Barrel from ](https://disney.fandom.com/wiki/Lock,_Shock,_and_Barrel)_[The Nightmare Before Christmas](https://disney.fandom.com/wiki/Lock,_Shock,_and_Barrel)_

[![](https://substackcdn.com/image/fetch/$s_!C43E!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F678c8a81-aac1-4dda-a9ee-7f9fef79a66a_1000x659.jpeg)](https://substackcdn.com/image/fetch/$s_!C43E!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F678c8a81-aac1-4dda-a9ee-7f9fef79a66a_1000x659.jpeg)




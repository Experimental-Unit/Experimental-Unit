---
title: 'OSA #4: Planetary Assessment'
subtitle: Enough About Me...
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# OSA #4: Planetary Assessment
_Experimental Unit_ has, of course, to do with intervening into the course of events.

We can’t help but do it. Everything hangs together.

Nothing would be what it is if everything else were not as it is. 

Well. Is anything anything at all?

I’d like here, though, to comment a bit more concretely on planetary affairs. There’s obviously a lot going on, and I’m no expert, but I can sketch out some approaches which help to give you what I’m thinking in terms of an _Experimental Unit_ set of approaches to our situation here on “Earth.”

Looking at the situation from space, you see that this planet has two main landmasses that are the biggest and many islands.

I would call these biggest landmasses Afro-Eurasia and the Americas. In German you can call both of the Americas “Amerika,” which is pretty cool. But I’ll go with that for clarity.

Looking at it across time, and this is all just the official version of history, what you have is the kind of thing we are—unless you’re a machine or alien or something in which case, hi—spreading out from what we call Africa and going around everywhere.

Then that thing with agriculture happens, and gets connected with animal domestication. And in the meantime boat technology is getting better.

Writing also happens around then, and so there’s this build-up of know-how and abstract knowledge that gets passed down over time.

It leads up to boats going from Afro-Eurasia to the Americas and establishing transportation between those two big places regularly. That, with that build-up of know-how and all the materials from Afro-Eurasia, made it to where the newcomers basically routed the people who were there before.

As a result, plus with similar subjugations around the world, everywhere was imprinted by this process that started with land wars and boats to go get things from other places. 

In this day and age, we have, what, 8 billion people on the planet. The people are divided, of course, across the surface of the land which is there and where people can easily live or else where things are brought to make it possible to live there.

Things move around a lot, but people are mainly penned in different boxes called countries, of course. So different countries, supposedly, aggregate over all the people in them to have these so-called national possessions of what is called a military.

To flesh this out, as I’ve said I don’t think that what we call militaries are really military instruments. In order for things to go right, or whatever, these institutions don’t actually have to change their core character because the imperatives of emergency response, public worship, and public merrymaking supervene over the warfighting function.

Not to get to in the weeds :)

What I see at that national level is semio-stratocracies.

It’s my opinion that what is called “the military” is the core aspect of any discrete bloc of social networks that we call a nation or a country.

This notion quickly breaks down when you consider that every “country” is itself in a constant state of civil “war,” which again I wouldn’t even call civil, but it’s an emergency. 

It’s one big crisis of confidence that’s been going on from time immemorial.

It’s one big blood feud that’s been going on forever.

So to take some given narratives:

We have of course someone called Donald John Trump who is called the president of something which might not exist which is posited as the United States of America.

This person is very famous and there is the tariffs and the comparisons to Hitler and deportations and “the blitz” as it is called, which is unfolding through what is called the federal government.

I’m thinking a lot these days of the essay “Is National Socialism A New Order?” by Friedrich Pollock.

In it, Pollock states that economic issues are subordinated to political concerns. For example, having money doesn’t mean anything if you become an official enemy, or are part of a group which is an official enemy of whatever hegemony.

We can also see in Debord in the _Comments_ the idea that the fusion of state and economy is the trend of the century. This is, incidentally, one description of fascism, that it is what is called the government and what is called business working together.

I am not given to simply label any Nexus of social networks as being “fascist,” because for me the term “fascist” is really itself a site of emergency within the broader planetary state of emergency.

In other words, I find the term “fascist” to in fact be inadequate, because any appreciation for the situation we are actually in must have respect for the immense complexity of what is going on, and how difficult to read it is.

Secondly, in some sense it can be a mistake that people make that if one resists calling something “fascist,” then one is saying that things aren’t that bad. No, things in some ways are worse than what people often mean when they say that the powers are fascist.

We are certainly seeing what is called nationalism taking off again all around the planet. People are divided into these things called “countries,” and everywhere the people are trying to assert themselves in what is basically a new “Wild West” phase on the planetary stage that it doesn’t seem like anyone has too firm a grasp on.

That’s where, though, one has to appreciate that the “real game” is not on TV or the internet, and that secrets are kept for a very good reason.

One of the principal questions in this time where technology is everything is: what is the actual level of the “most sophisticated” technology which exists, and how is it being deployed?

Part of the reason why I would point you to “the military” and not the civil side of the ledger is that technology is concentrated on its most high-leverage use.

Economic theories which fail to take “military” matters into account are foolish. 

After all, if you have a nice place but you can’t defend it, in the long run in how our planet has been, you would have been displaced.

Similarly, if you can build a city but you can’t defend it, everything there might be destroyed, or some other people would come and just live where you used to.

Secrecy is something basic from interpersonal interactions which scales up to war.

I can have more food than I tell you, and keep more for myself and tell you we’re sharing evenly.

Or, I’ll hide my nice things in a secret place so you can’t steal them even if you wanted to.

At a low-security level, this is also again because everyone has to go to sleep, so there will be times when people will be vulnerable. This is one of the main reasons you want to associate with other people, to defend against anyone that might come when you are asleep.

The wave of nationalism, as I’ve said, is an obvious response to the crisis of confidence. If you look at the climate scenario, that is looking pretty bleak, and meanwhile things are going into overdrive with Arctic drilling and everything under the sun.

Not to mention all the new technologies and robots and synthetic materials which are being deployed. My read is that the whole surface of the planet can be remade, and that this might happen multiple times.

Nationalism is not adequate, it is a form of denial.

My read is that whatever can be done is being tried to put up some face while some sort of horrible eventuality is prepared in secret.

There does not seem to be any sort of compassionate movement from the “military centers.”

The very “wealthy” people are also very often hated within a country, speaking again to the internal divide. There is talk and the reality of course of the primacy of transnational social networks.

Yet these are themselves perhaps only partial, and even if people can intervene at a high level in some ways, they are also highly surveilled and there are many others who are operating at a similar capacity.

Therefore from an outsider’s perspective like mine, it is easy to say that it doesn’t seem like anyone on the “inside” is trying, because where are the fruits?

This sort of disenchantment with the official “governments” on the planet has led to this “populist” movement. It is very important to see the similarities between the nationalist movements of that wave of planetary conquest from earlier—what are called white or European nations—and all the resistance movements and nations which have declared independence from colonial rule.

The characteristic of that system is that declaring yourself independent doesn’t make you so.

The whole game relies on technology. So if all the factories were somewhere else, you would lose. Oftentimes people who got more technology later were kept just doing raw materials, actively preventing the development of a more complex economy and more robust intellectual and emotional investment.

And now, we have Donald John Trump saying America will do without what is called China, and now the rare earths are being cut off. So what is going to happen there?

We have a great acceleration of the game with the second so-called presidency of Donald John Trump. It is not even nationalism which is chewing through what is now simply “a certain collection of bureaucracies as they existed before January 20. 

---
title: Crazy Like A Fox, Stable Like An ÆRTHQUAKE
subtitle: Notes From Underground
author: Adam Wadley
publication: Experimental Unit
date: April 30, 2025
---

# Crazy Like A Fox, Stable Like An ÆRTHQUAKE
Thread Theme:

 _Soon it doesn't matter. Soon the reason and the why are gone and all that matters is the feeling itself._

# It Is, Of Course, Pretend: It Is A Lie

We’ll begin with the discussion of Jean Baudrillard’s treatment of the poetic image of earthquakes in the posthumously published work _The Agony Of Power_ (2010). We’ll go lexus style, which I’m realizing maybe I’m misremembering. I thought that meant that you kind of went line by line and gave a gloss and interpretation like people would do with Aristotle (“the dude who tutored the guy who gave Pyrrho a ride?”). And how some texts we only have because people copied them in their entirety to comment on them. Or maybe they left out the parts the didn’t like or changed it hmmm. 

Anyway, Jean says:

> The violence of natural disorders increases with the intensification of technological violence. 

Key term here is violent, for me the other key violence reference in Baudrillard is where Baudrillard is writing that the universal is dead as frickin’ dead okay, and singularities are back in a big frickin’ way. But they have poetic and violent aspects. 

It’s unclear to me whether the intention is that you would be either/or, as in it could be possible to be poetic and not violent, a nice “good” singularity. Sometimes I’d think that, but on the other hand “violence” is not only a negative term. You can make violent movements, moving your limbs violently, without actually hurting anyone or even scaring anyone.

When you think of conceptual violence, in a way humor does it by defying expectations. It is a trick of course, it is a lie. But this is very common, and don’t look at me like you don’t have strategic social secrets or something. Everyone must have something because this is what it means to have a shadow. 

The conceptual violence comes from messing with a concept which is going big work for someone inside but is also just a word we use. So I really don’t want to be weak, oh no, and here you come talking about how something or someone is weak. Well, now you’re like actually doing me violence, or what shall we say. I have a violent internal reaction to what you are doing.

This is exactly not to be saying that you or whoever did anything “wrong.” It is a way of using the word violent to describe not just kinetic effects but things which are substantially dislocating.

Especially because they contain this secret or subterranean dimension. This is where the earthquake is standing in for the spiritual or existential emergency, the psychological or relationship emergency, the professional or medical emergency.

That’s where these underground issues come up, and maybe things that we thought were buried come back to the surface.

For this line, this is relevant because the question is, what is technological violence?

We might think of pollution or factory farms or torture or surveillance and manipulation. This last gets us to the topics discussed above.

Our internal fissures are being read by powers and computations which can suck up and see everyone’s details and make us into categories and target us with this and that for monetary reasons, sure.

The real game though is in attention. Recall this passage from the essay “[China And Cognitive Warfare: Why Is The West Losing?](https://hal.science/hal-03635930/document)” by Orinx & Struye de Swielande from 2022.

According to the authors, _technological developments_ , globalization and the rise of _power beyond the nation-state_ , combined with _the new capabilities of modern weapons_ , would provide a _new context_ for conflict. Battlefields would thus shift from a physical dimension to _a more abstract arena_ such as cyberspace, _the morale of the population or their brains_. 

In other words, Qiao and Wang demonstrate that war is no longer “the use of armed force to force the enemy to bend to our wishes,” but rather “ _all means_ , whether armed or _unarmed_ , military or _non-military force_... [uses] to _force_ the enemy to _submit_ to its own interests.” As a result, _the battlefield is everywhere_ , _war is no longer a purely military concept but also becomes civil_. 

This has two consequences: firstly, the victims of these new wars _will not only be regular combatants_ who die on the battlefield, _but also civilians_ who are indirectly affected. Secondly, _war is permanent and holistic, all forces and means are combined_.

So what is meant by “natural disorders” then?

I actually thought it said “natural disasters,” so now I’m in a tailspin because for me now disorder is associated with Afropessimism as well as Grimes in the [Chaos](https://ourladyofperpetualchaos.substack.com/p/chaos-manual-v1) Manual.

For example, see here Frank Wilderson III on disorder in the book _Afropessimism_ (2022):

 _Black categories are defined against the Blackness they are not, this relation of race indirectly (and directly, e.g., white teens’ racist snapchats) sustains anti-Blackness by producing and sustaining racialized categories. Stated otherwise, “the violence of antiblackness produces black existence; there is no prior positive blackness that could be potentially appropriated. Black existence is simultaneously produced and negated by racial domination, both as presupposition and consequence. Affirmation of blackness proves to be impossible without simultaneously affirming the violence that structures black subjectivity itself.”_

 _Afro-pessimism departs with this understanding and illuminates the limits and failures of the Civil Rights and Black Power movements, such as their reformist ideologies concerning progress and their disastrous integration with bureaucratic machinery. If, as Afro-pessimism shows, it is not possible to affirm Blackness itself without at the same time affirming anti-Black violence, then the attempts at recognition and inclusion in society will only ever result in further social and real death. Individuals can of course achieve some status in society through “structural adjustment” (i.e., a kind of “whitening” effect), as has been superficially confirmed, but Blackness as a racialized category remains the object of gratuitous, constituent violence—as demonstrated by police murders, mass incarceration, urban planning, and surveillance (from cointelpro to special security codes at stores to indicate when Black customers enter). As Blackness is negated by the relations and structures of society, Afro-pessimism posits that the only way out is to negate that negation._

 _The challenges Afro-pessimism poses to the affirmation of Blackness extend to other identities as well and problematize identity-based politics. The efforts, on the part of such a politics, to produce a coherent subject (and movement), and the reduction of antagonisms to a representable position, is not only the total circumscription of liberatory potential, but it is an extinguishment of rage with reform—which is to stake a claim in the state and society, and thus anti-Blackness. Against this, we choose, following Afro-pessimism, to understand Black liberation as a negative dialectic, a politics of refusal, and a refusal to affirm; as an embrace of **disorder** and incoherence; and as an act of political apostasy. This is not to categorically reject every project of reform—for decreased suffering will surely make life momentarily easier—but rather to take to task any movement invested in the preservation of society. Were they not to decry every action that didn’t fit within their rigid framework, then they might not fortify anti-Blackness as fully as they do. It is in the effort to garner legitimacy (an appeal to whiteness) that reformism requires a representable identity and code of actions, which excludes, and actually endangers, those who would reject such pandering. This also places undo faith in politicians and police to do something other than maintain, as they always have and will, the institutions—schools, courts, prisons, projects, voting booths, neighborhood associations—sustaining anti-Blackness._

So, what is natural disorder? It is a bit strange to see Baudrillard use categories like “natural” when there are also whole passages for example of _[The Mirror of Production](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.1973.The-Mirror-Of-Production.pdf) :_
    
    
    This _separation from Nature_ under the sign of the principle of production is fully realized by the capitalist system of political economy, but obviously it does not emerge with political economy. 
    
    The separation is rooted in the great Judaeo-Christian _dissociation of the soul and Nature_. God created man in his image and created Nature for man's _use_. The _soul_ is the spiritual hinge by which man is God's image and is radically distinguished from _the rest of Nature_ (and from his own 
    _body_ ): "Uniquely in its Western form, Christianity is the most anthropocentric religion the world has ever known. In absolute contrast to ancient paganism and oriental religions, Christianity not only institutes a dualism of Man and Nature but also affirms that God's will is that man exploit Nature according to his own ends."
    
    Rationality begins here. It is the end of paganism, animism and the " _magical_ " _immersion_ of man in nature, all of which is reinterpreted as _superstition_. 
    
    (" _Rational_ " Marxism makes the same error by reinterpreting it in terms of the "rudimentary" development of productive forces.) 
    
    Hence although science, technology, and material production subsequently enter into contradiction with the cultural order and the dogmas of Christianity, nonetheless _their condition of possibility remains the Christian postulate of man's transcendence of nature_. This is why a scientific movement does not emerge in Greece. Greek rationality remains based on a _conformity with nature_ radically distinguished from the Christian rationality and "freedom" based on the separation of man and nature and on the _domination_ of nature. 

I suppose we can just say that Baudrillard advocates more this idea of magical and radical immersion in nature.

I would personally say, you, like Spinoza, God or Nature. Especially if you think of aliens but God is basically the same thing, if someone sculpted our conditions of existence then the specifics of that would in fact make a big difference.

Still, even if I am a slave getting milked for my negative emotions or I’m just watching a movie of my life and not actually making any choices, I still have whatever dignity I get. I mean, I am what I am, but there’s nothing which is so bad to be, or even bad at all in this sense of judgment. Non-judgment is a big power, ironically I judge people for not having it. 

Actually this ties in to what I wanted to say, which is that frankly I think we should embrace the idea that we are also the servant of everything. As Bob Dylan wrote in “[Every Grain of Sand](https://en.wikipedia.org/wiki/Every_Grain_of_Sand),” namely that “In the fury of the moment/ I can see the master’s hand/ In every leaf that _trembles_ / In every grain of sand.”

Incidental to “trembles,” this is a crucial bridge also between Grimes and Afropessimism which references Kierkegaard in the sense of fear and trembling. Meanwhile, Grimes discusses “my fingers tremble/ this is what I am” in the song “[IDORU](https://genius.com/Grimes-idoru-lyrics)” also from _Miss Anthropocene._

The poetic image of fingers in Grimes is connected to the larger themes of hand and body.

The hand comes up in the song “[Oblivion](https://genius.com/Grimes-oblivion-lyrics)” which came out in 2012 and was included on the album _Visions_. On Oblivion is it sung:

And no, I’m not a jerk

I would ask if you could help me out

It’s hard to understand

Cuz when you’re running by yourself

It’s hard to find someone to hold your **hand**

Note also that Oblivion was released a long with “Genesis,” which together make a sort of bookend set of songs, since Genesis of course means beginning and Oblivion could be nothingness or something at the end. And of course the basis thesis of “[Genesis](https://genius.com/Grimes-genesis-lyrics)” is:

My heart, I never feel  
I never see  
I never know  
Oh, heart  
And then it falls  
And then I fall  
And then I know

Notice also that the album title _Visions_ is mixing in with the theme of sight, for example again in “Violence” off _Miss Anthropocene_ : “You can’t see what I see.” Or again, in “Delete Forever,” the line “I see everything/ don’t tell me now that I don’t want to.”

We also can tick [4ÆM](https://genius.com/Grimes-4m-lyrics) off the list by invoking the following lyrics from this other track from _Miss Anthropocene_ : 

He says, "How's the weather, baby? How've you been?"  
You're gonna get sick, you don't know when  
I never doubt it at 4 AM  
Falling down again

Falling down. Just like structures fall down during an earthquake, or we are falling down into ourselves.

So the natural disorders are also within, note the passage about how dissociation from nature is also from our bodies (“We don’t use our bodies anymore” - Grimes from “[Darkseid](https://genius.com/Grimes-and-pan-darkseid-lyrics)” also off _Miss Anthropocene)._

This is not just like oh you need to stretch. The whole idea that bodily standing is different from mental or emotional identity is foolish. Both abstract over each other. Buried feelings really are somewhere in the body.

Personally when I feel upset I feel it in my belly or in my chest, like this pressure. Recently I’ve been soothing it by calling it my baby. I think it’s very sweet actually, but also it’s like that energy hmm maybe some spiritual faith like that energy will outlast my body, I’ll still be feeling that in the afterlife or something. So it’s here for the long haul, not just coming up because of this or that eventuality.

This helps me sum up and move on because technological means implies methods of abstraction and streamlining of functions and emergence which comes from that. Natural disorder means like disasters storms bugs but also what is natural about us, our emotions, what is not rational. Which is also a mystery, we don’t know how the brain works or personality. We don’t know what we’re capable of, we just look to the past or existing models. These are outliving their utility as technology continues to grow in power and the resulting destabilization of things that happened anyway like storms or breakdowns is accelerated and then comes back to impact the technological deployment and its attendant violence.

I just remembered, last thing, that of course Grimes has a song on _Miss Anthropocene_ just called “Violence.” I thought I should challenge myself to reference every song once in this piece which will be hard because I’m running out of room.

> Deregulation grows at the same rate as excesses in control and calculation. 

See Percy Shelley on the “faculty of calculation” in _A Defense of Poetry_ , from 1821:

What were virtue, love, patriotism, friendship—what were the scenery of this beautiful universe which we inhabit; what were our consolations on this side of the grave—and what were our aspirations beyond it, if poetry did not ascend to bring light and fire from those eternal regions where the owl-winged **faculty of calculation** dare not ever soar?

In terms of this deregulation, this losing the way, following the smell of a passion beyond what actually serves it, see Epictetus in the _[Enchiridion](https://classics.mit.edu/Epictetus/epicench.html)_ :

And who can give to another the things which he has not himself? "Well, but get them, then, that we too may have a share." If I can get them with the preservation of my own honor and fidelity and greatness of mind, show me the way and I will get them; but if you require me **to lose my own proper good** that you may gain what is not good, consider how inequitable and foolish you are. Besides, which would you rather have, a sum of money, or a friend of fidelity and honor? Rather assist me, then, to gain this character than require me to do those things by which I may lose it.

> It is as if Nature were exacting revenge in the name of all of the peoples sacrificed and disowned. 

See broad gesture, “all sentient beings” type shit, which also is so inclusive that it includes for example rich people who commit suicide, or anyone who suffers something where they are put down or excluded, even if it doesn’t mean they die or anyone even yells at them, they were disowned in that moment.

Revenge is also an interesting concept I’ve been developing. See German _Rache_. The thing is if you perfect hatred and violence it’s just like love, because what you actually want to do is eternally torture people with the cognizance of what they did to you, so you lead to a world where they live forever and become wise so that the gravity of their actions is something they remember forever and they never forget how awful their actions were. At least until you both become wise and move on, but why should anyone get to move on before you? If _you_ are unhappy, that is important and no one gets to tell you that you don’t _deserve_ to be. By their fruits shall ye know them. If someone is a jerk to you, then disregard but watch out for the reactivity baiting and reverse psychologies.

> A symbolic backlash of insupportable hegemony, of the technological arraigning to which Nature responds in the "terrorist" form of _earthquakes_ and eruptions. 

Insupportable hegemony = mental cloning, integral reality, Real Time, what [Gillespie](https://trueleappress.wordpress.com/wp-content/uploads/2017/10/pn2-weaponized-death.pdf) might call “White Hyperreality” and Baudrillard, again in _The Agony of Power_ :

Opposition to global hegemony cannot be the same as opposition to traditional oppression. It cm only be something unpredictable, irreducible to the preventive terror of programming, forced circulation, irreducible to the White terror of the world order. Something antagonistic, in the literal sense, that opens a hole in this Western **agony**. Something that leaves a trace in the monotony of the global order of terror. Something that reintroduces a form of impossible exchange in this generalized exchange. Hegemony is only broken by this type of event, by anything that irrupts as an unexchangeable singularity. A revolt, therefore, that targets systematic deregulation under the cover of forced conviviality, that targets the total organization of reality.

> In the insurrection of natural elements, there is a hint of reprisal. 

Just more invocation of concepts, kind of restating things in different terms, but re-claiming the terms along the way is part of the point.

Insurrection, giving of course again revolution. So now it’s not the little people who are rebelling against the powerful people. It’s the world itself, the natural forces, the ocean and atmosphere are rebelling against the people.

The big theme is that what we thought we could take for granted is actually something we have to look at.

This is a [figure-ground reversal](https://en.wikipedia.org/wiki/Figure%E2%80%93ground_\(perception\)), and of course now it’s no accident that the context you thought you could take for granted is called the _ground_. And the ground is what is disturbed by an _earthquake_. Which is again also what you are taking for granted with respect to your non-relationship to your _body_. Not to mention the _social paradigm_ that you take for granted.

So when we have a time like now, of great change, it is an _earthquake_ because it’s not just like a bomb flattened the city, no, everything underneath is also messed up. Even if all we look at of ourselves is the building on top, we’re relying on our internal atmosphere, our internal fungi and bugs that break things down, our own sunlight.

Earthquake goes with volcano goes with atmosphere pollution blocking out the sun. Then it is raining ash. There’s your frickin’ situational assessment, slick.

> Evil is now everywhere and it must be eradicated.

Talked to a Rabbi from a synagogue here in Atlanta who said of Hamas and Palestine that sometimes there is darkness that just needs to be eradicated. It was quite sobering.

This is what we can’t stand in the other, and we gave up on them changing and we gave up on us changing so either now everyone changes or it’s a fit to the death. There’s no question about that. This clarifies the window of action: you really do have to impact down to the personal level how people see evil, theodicy, purpose, etc. People don’t have to believe the same thing but it has to be consistent so people can live together but also things like circumcision have to be banned sorry. But then what’s my knockdown argument, or how can that happen without people rejecting it? And then what are other things “like that”? This is where people really don’t understand that influencing people is profound and forever, and for this reason also you can’t help but be influenced by what you hate, so in that sense you have to “lose” because they “totally live in your head rent free” etc.

So I think we’re also trying to eradicate that truth, which is that we are always locked together with those we least appreciate. And trying to destroy that memory basically we continue to destroy people in “reality.”

> Every extreme phenomenon is Evil. 

Very good, yes. Everything which is too intense. The thing is that now everything is intense, but things like the fast-moving political situation throw everything else into relief. I wonder what the suicide rate is doing right now, it makes me sad.

Still, again it shows that evil is a cold comfort. “I miss the comfort of being sad,” sung by Kurt Cobain of Nirvana on the song “[Frances Farmer Will Have Her ](https://www.google.com/search?q=frances+farm+lyrics+nirvana&rlz=1CANIZI_enUS1144&oq=frances+farm+lyrics+nirvana&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIICAEQABgWGB4yCAgCEAAYFhgeMgoIAxAAGIAEGKIEMgoIBBAAGIAEGKIEMgoIBRAAGIAEGKIE0gEIMzIzMWowajeoAgCwAgA&sourceid=chrome&ie=UTF-8)_[Revenge](https://www.google.com/search?q=frances+farm+lyrics+nirvana&rlz=1CANIZI_enUS1144&oq=frances+farm+lyrics+nirvana&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIICAEQABgWGB4yCAgCEAAYFhgeMgoIAxAAGIAEGKIEMgoIBBAAGIAEGKIEMgoIBRAAGIAEGKIE0gEIMzIzMWowajeoAgCwAgA&sourceid=chrome&ie=UTF-8)_[on Seattle.](https://www.google.com/search?q=frances+farm+lyrics+nirvana&rlz=1CANIZI_enUS1144&oq=frances+farm+lyrics+nirvana&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIICAEQABgWGB4yCAgCEAAYFhgeMgoIAxAAGIAEGKIEMgoIBBAAGIAEGKIEMgoIBRAAGIAEGKIE0gEIMzIzMWowajeoAgCwAgA&sourceid=chrome&ie=UTF-8)”

The point is that ascribing something to “evil” is at least to give it a cause, seemingly. People talk about how if you say God created the universe it doesn’t do anything because you can just ask, what made God?

It’s similar to the devil or evil. Okay, why did Hitler do what what done? Well, Hitler was evil and Nazis are evil. Okay, but why are they evil? And then you can get into the easy answers, that they are supremacist, that they find arbitrary enemies and kill them, that they start big wars.

But then it’s like, aren’t we doing that? Even before the current [blitz](https://abcnews.go.com/US/220-lawsuits-100-days-trump-administration-faces-unprecedented/story?id=121252266), National Socialism was already the model for the semblance of government in general. See [Pollock](https://hortense.memoryoftheworld.org/Friedrich%20Pollock/Is%20National%20Socialism%20a%20New%20Order%201941%20\(4608\)/Is%20National%20Socialism%20a%20New%20Order%201941%20-%20Friedrich%20Pollock.pdf), “Is National Socialism A New Order” (1941)

In particular, in the positing of “evil” which then must be “defeated” and of course in the process you become just as bad or worse than what you said you were fighting.

See Debord on terrorism in _Comments On Society Of The Spectacle_ from 1987:

This perfect democracy fabricates its own inconceivable enemy, terrorism. It wants, actually, _to be judged by its enemies rather than by its results._ The history of terrorism is written by the State and it is thus instructive. The spectating populations must certainly never know everything about terrorism, but they must always know enough to convince them that, compared with terrorism, everything else seems rather acceptable, in any case more rational and democratic.

> It is the perfect alibi for the totalitarian extension of the Good. 

Key word: totalitarian. See total war, total art, totality in Hegelian sense. Compare whole-of-nation to integrating whole-of-psyche operations. Integrating meal plan with study with influence operations with design theory with socializing with goofing off and so on.

Anyway, this is the “good” but it’s you know running on drone strikes and so on, there’s a bit of an inversion here here the Good is actually evil because it’s the big empire claiming to be good and civilized and so on. With rights and so on. Whereas evil is evil because it doesn’t go along with the pretenses of good, but in that way it kind of actually is the good one.

> In a New York Times editorial cartoon (on bird flu): 
> 
> "It's a pandemic. What should we do?" 
> 
> Bush's response: "Issue a terror alert!' 

Kind of like a Haiku or joke to itself. 

Reminds me of a passage of Brian Massumi talking about “natural security,” a word confusion by George W. Bush instead of “national security.” Lead me to this [article](https://www.airuniversity.af.edu/ASPJ/Book-Reviews/Article/1195138/ontopower-war-powers-and-the-state-of-perception/), seems very interesting, on Massumi’s ontopower.

Brian Massumi’s latest addition to our understanding of power may be the most important addition to grand strategy since _On War_. To Massumi, an “ontopower” is power that is able to alter perception about a chain of effects, altering the future of the original (pg. 41). It is, as its Greek prefix indicates, a living power. Massumi’s protagonist is the idea of preemption as strategy, and he describes in his book the underlying assumptions in which preemption becomes the only response available to threats. Preemption, because it occurs before the threat emerges, must have, as its ontological premise, the ability to define a threat after its destruction has occurred. Preemption, in its truest sense, requires that perceptions bend to fit the action. In other words, what could be a threat should be attacked because it very well could have attacked you. Preemption changes premise from fact to potential.

> In this way we can understand how some in Islamic countries called on God to proclaim that the ravages of Hurricane Katrina were a terrorist act from the heavens striking the American sanctuary. 

And sure enough I found the [article](https://brb.memoryoftheworld.org/Brian%20Massumi/National%20Enterprise%20Emergency%20\(6486\)/National%20Enterprise%20Emergency%20-%20Brian%20Massumi.pdf), it’s called “National Enterprise Emergency.” Published in 2009 after Baudrillard died:

The press announcement of Obama’s national security team contained a telling typo. ‘In this uncertain world’, the statement read, the continued prosecution of the ‘war on terrorism’ requires a ‘skillful integration’ of American power in all its forms (read: on the full spectrum), enabling immediate response to any potential ‘catastrophe be it manmade or natural’, as well as to ‘un - conventional’ (read: indiscriminate/indiscriminable) threats of any stripe. The public was assured that the future president had assembled the best possible team of ‘natural security’ officers.4 It is more than a slip of the keyboard to naturalize the continuum annexing the civilian sphere to the military. The ‘naturalization’ at issue should not be understood in the social constructivist sense, in which the cultural comes to be taken for natural. The formula of the cultural ‘taken for’ natural leaves the opposition between the two intact, attributing any blurring of the boundaries to mystification. Under indiscriminate threat, the opposition is no longer generally tenable and cannot be taken as a starting point. A base redefinition of nature is required outside any categorical opposition to the cultural, social or artificial. The overall environment of life now appears as a complex, systemic threat environment, composed of subsystems that are not only complex in their own right but are complexly interconnected. They are all susceptible to self-amplifying irruptive disruption. Given the interconnections, a disruption in one subsystem may propagate into others, and even cascade across them all, reaching higher and wider levels of amplification, up to and including the planetary scale. The complexity of the interdependency between the changing climate system, food supply system, energy supply system, social systems, national governments, their respective legal systems, and military-security apparatuses is an increasingly preoccupying case in point.

Jean said:

> A terrorist group could even lay claim to an _earthquake_. 

Why not? See this literal discussion of [people saying Earthquakes are conspiracies](https://www.nature.com/articles/s41599-024-02957-y).

The focus of this study is the analysis of the so-called High-Frequency Active Auroral Research Program (HAARP) conspiracy, which explains earthquakes through the employment of secret weather control weapons.

Wake up, sheeple!

Actually, I would like to take this opportunity to “claim” all earthquakes that have ever happened, even the ones before I was “born.” Yeah, I crossed the street one time when it wasn’t my turn and someone had to slow down, so as a result all the earthquakes that have ever happened or ever will happen, happened. So consider those claimed. So sorry about that. _Experimental Unit_ promises that it’s all gonna be worthwhile to all sentient beings in the end. (Disclaimer: it is official policy of _Experimental Unit_ not to place any faith at all in promises; what of my mind have you blown _lately_?)

Jean said:

> Because terror no longer belongs to anyone, no more than world power does. And because world power escapes everyone, it is now inscribed in things and in their objective unfolding.

Right, I think Grimes had a quote about people not being in control. From everyone’s perspective, “[I don’t know where you stand](https://genius.com/Grimes-new-gods-lyrics)” from the song “New Gods” also from _Miss Anthropocene_ (2020):

I can’t find the passage that I wanted, it might be in _Carnival And Cannibal_ which for me is not searchable.

Here’s something from _[Baudrillard Live](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.1993.Baudrillard-Live.pdf)_ (1993, same as _Jurassic Park_ and _Schindler’s List_ ) which is also broadly relevant and has the key bridge concept of _underground_ get mentioned. 

See Grimes, “[You’ll Miss Me When I’m Not Around](https://genius.com/Grimes-youll-miss-me-when-im-not-around-lyrics)” from _Miss Anthropocene_ (2020): “If they could see me now/ Smiling Six Feet Underground.” Incidentally, compare video to _Wuthering Heights_ by Kate Bush video of just dancing, also Orange-ish hair hard to tell because of lighting for me, sword, metal wings (also giving _Icarus_ , see TOGA Trew’s essay on [Rescuing Icarus](https://www.airuniversity.af.edu/Portals/10/ASPJ/journals/Volume-33_Issue-2/F-Trew.pdf); note also that Icarus is also referenced in the song “[Delete Forever](https://genius.com/Grimes-delete-forever-lyrics)” from the same album in the line “flew into the sun”).

Now, the Baudrillard.

Jean said:

>  _SL: Still, isn’t that exactly what you do: make stakes unreal by pushing them to the limit?_
> 
> But I hold no position on reality. 

_Put It On The List Of Things You Love To Frickin’ See._

This is Baudrillard’s total “bad seed” energy. Baudrillard obviously is sassy, and sets it up like the proclamations are just coming. There’s nothing you can do about it. But the whole thing is that in Baudrillard’s mind it’s all so worked out so that no one could ever really “correct” the theory, since it ultimately is gesturing at what is undecidable.

This is the horizon of this thinking: challenging reality to be real. Something like that is here in [The Transparency of Evil](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.1990.The-Transparency-Of-Evil.pdf) (1990), again by Baudrillard. Do you see why I like this author so much???

All kinds of events are out there, impossible to predict. They have already occurred, or are just about to heave into view. All we can do is train our searchlight, as it were, and keep our telescopic lens on this virtual world in the hope that some of those events will be obliging enough to allow themselves to be captured. Theory can be no more than this: a trap set in the hope that reality will be naive enough to fall into it. The essential thing is to point the searchlight the right way. Unfortunately, we don't know which way that is. We can only comb the sky. In most instances the events are so far away, metaphysically speaking, that they merely cause a slight phosphorescence on the screen. They have to be developed and enlarged, like photographs. Not in order to discover their meaning, however: they are not logograms, but holograms. They can no more be explained than the fixed spectrum of a star or the variations of red. To capture such strange events, theory itself must be remade as something strange: as a perfect crime, or as a strange attractor.

Jean said:

> Reality remains an unshakeable postulate towards which you can maintain a relation either of adversity or of reconciliation. 

Accept everything or challenge everything. And yet both at the same time, see Nagarjuna’s tetralemma as part of the [sunyata](https://en.wikipedia.org/wiki/Nagarjuna#Sunyata) philosophy:

All things (dharma) exist: affirmation of being, negation of non-being

All things (dharma) do not exist: affirmation of non-being, negation of being

All things (dharma) both exist and do not exist: both affirmation and negation

All things (dharma) neither exist nor do not exist: neither affirmation nor negation

Jean said:

> The real—all things considered, perhaps it exists—no, it doesn’t exist—is the insurmountable limit of theory.

Lacan has something to say about the real, see the [Borrommean Knot](https://nosubject.com/Borromean_knot):

[Lacan](https://nosubject.com/Lacan) first takes up the **Borromean knot** in the [seminar](https://nosubject.com/Seminar) of 1972-3, but his most detailed [discussion](https://nosubject.com/Discussion) of the [knot](https://nosubject.com/Knot) comes in the [seminar](https://nosubject.com/Seminar) of 1974-5. It is in this [seminar](https://nosubject.com/Seminar) that [Lacan](https://nosubject.com/Lacan) uses the **Borromean knot** as, among other things, a way of illustrating the interdependence of the [three orders](https://nosubject.com/Order) of the [real](https://nosubject.com/Real), the [symbolic](https://nosubject.com/Symbolic) and the [imaginary](https://nosubject.com/Imaginary), as a way of exploring what it is that these [three orders](https://nosubject.com/Order) have in common. Each ring represents one of the [three orders](https://nosubject.com/Order), and thus certain elements can be located at intersections of these rings. (In his view these [orders](https://nosubject.com/Orders) are tied together in the form of a "Borromean knot". The "Borromean knot" is a linkage of three "string rings" in such a way that no two rings intersect. The structure of the knot is such that the cutting of any one ring will liberate all of the [others](https://nosubject.com/Others). [Lacan](https://nosubject.com/Lacan) used the [theory](https://nosubject.com/Theory) of knots to stress the relations which [bind](https://nosubject.com/Bind) or link the [Imaginary](https://nosubject.com/Imaginary), [Symbolic](https://nosubject.com/Symbolic) and [Real](https://nosubject.com/Real), and the [subject](https://nosubject.com/Subject) to each, in a way which avoids any [notion](https://nosubject.com/Notion) of hierarchy, or any priority of any one of the three terms.)

Jean said:

> The real is not an objective status of things, it is the point at which theory can do nothing. That does not necessarily make of theory a failure. The real is actually a challenge to the theoretical edifice. But in my opinion theory can have no status other than that of challenging the real. 

Theory can do nothing because true unadulterated reality can’t be expressed in words. Dhamma language has no theory. Theory is about the way up. Shakti does not theorize in order to incarnate, in order to birth what allows for incarnation and experience. Theory is about taking the resulting mystery and working forward to get back to the place where theory is no longer required. E.g. marrying the monk’s life of next-level meditation practices with the practical mind to resolve or work with conflicts and implement technology let’s say artfully hello Michael Bruner.

Jean said:

>  **At that point, theory is no longer theory, it is the event itself.**

Right, like so how is the theory the event itself? That’s because exactly what we’re doing is unlocking new realms of conceptual maneuver and then applying it to the infinite variety of what’s “out there” from within the infinite variation and depth of our own experience of incarnation.

So, theory is the demonstration of ideas and thinking, the play with language. The point is for example not just what good ideas are in there, but how it shows you, it gives you permission to think a certain way because it shows you what someone else somehow thought was fit to publish. But anyway, it’s more information for you not on a first-order basis where you trust the author, but the author is supplying data in the presentation of the text just not necessarily at the level of the first-order messages conveyed therein.

Jean said:

> There is no ‘reality’ with respect to which theory could become dissident or heretical, pursuing its fate other than in the objectivity of things. Rather, it’s the objectivity of things we must question. What is this objectivity? In the so-called ‘real world’, don’t things always happen that way? By a divergence, a trajectory, a curve which is not at all the linear curve of evolution? 

Baudrillard also points out at a different point that objective reality is not a scientific hypothesis. Ah, yes. From _[The Perfect Crime](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.1995.The-Perfect-Crime.pdf)_ :

For Gosse, matters are simple: reality exists on God's authority. But what can we do if that same God is capable of simultaneously creating the true and the false? (This is not even a diabolical manipulation, since the germ of the illusion came from God himself.) In this case, what is there to guarantee that our world is not as false as the simulacrum of an earlier world? All of reality -- present, past and future -- suddenly comes into doubt. If God is capable of conjuring up a perfect illusion of the pre-Genesis era, then our current reality is eternally unverifiable. **It is not, therefore, a scientific hypothesis.**

This is also just going along with my refrain that Baudrillard is just a skeptical poet. No big deal. Skepticism has _always_ been the GOAT philosophy.

It’s the simple game of “why”? 

This thing which any child can understand, this pattern of asking why, gets at the limits of knowledge of causation.

It does so by attacking levels of abstraction. 

It’s also just sending you down the [infinite regress](https://en.wikipedia.org/wiki/Infinite_regress) path of the [Münchhausen trilemma](https://en.wikipedia.org/wiki/M%C3%BCnchhausen_trilemma):

 **Infinite regress** is a [philosophical](https://en.wikipedia.org/wiki/Philosophy) concept to describe a series of entities. Each entity in the series depends on its predecessor, following a [recursive](https://en.wikipedia.org/wiki/Recursive) principle. For example, the [epistemic regress](https://en.wikipedia.org/wiki/Epistemic_regress) is a series of beliefs in which the [justification](https://en.wikipedia.org/wiki/Justification_\(epistemology\)) of each belief depends on the justification of the belief that comes before it.

So the people who are always like “OMG muh reality” are always appealing to some group of people who all agree on something, and counting that as it being “settled” that so-and-so is the case.

The problem is once you give people “objective reality” then they start abstracting all over the place. So you basically have convinced yourself that the sand you’re building on isn’t sand, so then you build way too much and it has to collapse because you’re putting so much pressure on the foundations.

With any pursuit, like the state and Trump and so on, the question of what exactly is happening? And it’s impossible to find out, and this is now putting pressure on the question of the state as well, in terms of “what is the state?” Because more and more attention is being focused on it and the questions being asked cannot be answered. So what is the “objective” political reality?

Those who say don’t know and those who know don’t say.

So anyone who speaks too surely about anything is immediately suspect, they are deceiving you or themselves if they think they really know what’s going on, and if they know more than they let on and give you a little here and there, that’s just confusing and in a way without honor. People could want to keep positions or lines of contact open, but there again you’re what, better on keeping a secret? From whom? I kind of don’t believe in any of that.

So, I’m strident, but not because I know what’s going on. It just seems like the issue is big time trust problems, Hobbesian trap at fractal level. That’s what’s coming up. 

Jean said:

> We could perhaps develop a model of drifting plates, to speak in _seismic_ terms, in the theory of catastrophes. The _seismic_ is our form of the slipping and sliding of the referential. The end of the _infrastructure_. Nothing remains but shifting movements that provoke very powerful raw events. 

So I just came to this for the word “underground” which is coming later, but this is all about seismic shit. 

So now we’ll finally get to Track 1 off _Miss Anthropocene_ called “[So Heavy I Fell Through The Earth (Art Mix)](https://genius.com/Grimes-so-heavy-i-fell-through-the-earth-art-mix-lyrics)”:

Yeah, oh  
So heavy, **I fell through the earth**  
Yeah, oh  
'Cause I frickin’ **love**  
Yeah, oh  
So heavy, **I fell through the earth**  
Yeah, oh  
'Cause I'm **full of love from you**

This song is apparently inspired by being pregnant with X Æ A-12, which Grimes describes as being[ a very profound experience](https://www.usatoday.com/story/entertainment/celebrities/2020/03/05/grimes-explains-profound-decision-have-baby-elon-musk/4968546002/):

In her [Rolling Stone](https://www.rollingstone.com/music/music-features/grimes-rolling-stone-digital-cover-960843/) profile published Thursday, the 31-year-old music artist opened up about the "tragedy" that comes with carrying a child, "even though it's this great thing."

"For a girl, it’s sacrificing your body and your freedom," Grimes said. "It’s a pretty crazy sacrifice and only half of the population has to do it."

According to Grimes, this journey **** is what made having a baby with Musk a "really profound" decision for her.

"I’m just like, I have sacrificed my power in this moment," she said. "I have, like, capitulated. And I have spent my whole life avoiding that situation. I have never capitulated to anything, so it was just a profound commitment."

Grimes added she decided to make this commitment because of the love she has for Musk.

"I do actually just really love my boyfriend,” she said. “So I was like, ‘You know, sure.' "

"This whole thing has been a bit of an ordeal," Grimes captioned a selfie in the post. "Had some complications early on, a decent second trimester but starting to hurt everywhere at 25 wksz. What were yalls experience w this stuff like?"

The Canadian singer, whose real name is Claire Boucher, said she didn't fully "understand what I was getting into" or the physical toll pregnancy takes on your body.

"I feel like I was woefully ill prepared cuz I dunno if pregnancy is as visible or discussed as it should be," Grimes wrote. "It’s been good too, but it makes working a lot harder. Good at writing and having lots of wild ideas tho, but anything physical is hard. Im also way more emo and less capable of bravery in the face of haters online and stuff haha."

Meanwhile, then the resulting baby is named X Æ A-12, which Grimes [described](https://www.cnn.com/2020/05/06/entertainment/grimes-elon-musk-baby-name-intl-scli/index.html#:~:text=The%20Canadian%20musician%20%E2%80%93%20real%20name,several%20languages%2C%20such%20as%20Japanese.) like this:

Grimes has since broken down each character of their [child’s] name in a Twitter post.

The Canadian musician – real name Claire Elise Boucher – explained “X” stands for “ **the unknown variable**.”

Meanwhile, “Æ” is the _**Elven spelling of AI**_ , which is shorthand for artificial intelligence and translates to “ _ **love**_ ” in several languages, such as Japanese.

The 32-year-old star then shared that a part of her son’s name is a reference to the couple’s favorite aircraft.

“A-12 = precursor to SR-17 (our favorite aircraft). No weapons, no defenses, just speed. Great in battle, but non-violent,” she added.

> > Grimes concluded the message by revealing that the “A” in the name also represents “Archangel,” which she described as her favorite song.

So of course this is _Experimental Unit_ , AKA X-Unit. Æ, I mean, come on. But yeah to recap machine intelligence + elves = machine elves = DMT = psychedelics. Not to mention connected to principle of love, so basically Æ can be a cosmic sort of principle analogous to logos or Silap Inua, etc., I have my rogue’s gallery of such things but you can have your own. I’ll allow it.

Anyway, the point of this is that the theme of underground and seismic events goes with rawness, and pregnancy is the ultimate. Also did we mention that this is the kid we are talking about:

Hello, Grimes is never mentioned! It’s so weird. Grimes is like me, somehow flying under the RADAR. It’s like, do you not realize??? Ben Zweibelson is the same way, here we are advancing under cover of the lesser blitz to execute the Greater.

Anyway this is connected to how we all have the earthquake, which is to say we are all pregnant. Back to my tense feelings and my saying oh my baby, my baby. Now I’m listening to my song “River of Grimes,” which I released shortly before I maybe talked to Grimes. There was someone else there, you can ask them. Check the phone records. I talked to _someone_ about the law of one and how polyamory doesn’t work for them _LMFAO_ how’s that working out for you legitimately curious anyway bye.

> We no longer take events as revolutions or effects of the superstructure, but as underground effects of skidding, fractal zones in which things happen. Between the plates, continents do not quite fit together, they slip under and over each other. 

Right, so revolution and reality is basically again taken here to mean things that everyone understands and gets. The reality is that it’s daytime right now. But if it’s true in reality that so and so is in league with so and so or that some technology just dropped, but if I can’t know about it, then is it real for me right now? Cassandra complex: sensing something before it is “real,” i.e. before _everyone_ or _enough_ people understand or know or _see_ it (You Have To Go Back To _Visions_ ).

So things are happening in ways that you can’t perceive. And this is also true for you, which invites comparisons to the unconscious but Baudrillard doesn’t favor this formulation. Still, there is what is happening beneath the surface. Which is fundamentally plates shifting.

That’s how I feel when I feel humiliated or something, it’s like an energy in my body, my baby like I said. And it has to come out. It’s all well and good to do something unrelated, but it’s important to do something proactive to address a situation. Even if it makes more costs, there are some costs which are truly unbearable. 

You can’t ask me to be “remiss.”

Which is to compare to the “autistic meltdown.” People have these things, the big scene in the movie where someone freaks out in public when they had been trying to be appear normal and it’s like oh. my. God. 

This is where there is plates shifting. It’s like yeah we can’t stabilize the building, which is to say no I can’t maintain composure. The way I feel inside is leading to this now, there is no avoiding it.

No outburst has to happen, this is just the shifting plates. Same idea as fits and starts, grow new parts.

> There is no more system of reference to tell us what happened to the geography of things. We can only take a geoseismic view. Perhaps this is also true in the construction of a society, a mentality, a value-system. 

Again the geography, the map and the territory, the cartography, the exploring, surveying, etc., connecting also to topology and mapping concepts and memories and this is of course how the brain works somehow, it has a million connections. Probably more, I only looked it up in my gut.

A mentality is again what is being described here, what I call an applied narratival topology or something like that.

Especially if you think about it like you are mining for something in someone.

The simplest idea is back to the poetic singularity. You are looking where someone’s good natured moods can line up with activities with others that are of mutual benefit and contribute to a basic situation where everyone can get along, aka everyone is helping weave and design social fabric 2, or 3 or whatever. The next generation society experience, which will be to what is called civilization what that which is called civilization is to what is called pre-civilization.

Anyway, you are digging, because someone is crabby on the surface. But you can basically know that everyone has this Inuk left, this core. It’s not all good or anything, but there is something to work with.

It’s easy to lose the importance because we are so lost in how people are disagreeable and we can’t help being judgmental and disgusted because we actually have some hang-ups even beyond the obvious secret ones we know about.

I personally have the advantage that I am completely heinous! Oh my god, I understand that I have entered the category of literary atrocity. Crimes against language itself! Not to say I couldn’t be frazzled, but it does give my statements a certain authorial integrity. I would love to go there with you. Your problem is that I’m going to hold you to it more than you even wanted to.

For example, the generous timeline given here by Ben Zweibelson for change in the book _[Beyond the Pale](https://www.airuniversity.af.edu/Portals/10/AUPress/Books/B_181_Zweibelson_Beyond_the_Pale_.pdf)_. By the way, the next book, _Reconceptualizing War,_ just came out so make sure and buy it or something. I can take pictures and do an audio book or something. Anyway:

Absolving ourselves of some of the more rigid, obsolete concepts in warfare will realistically **take a generation** or more. Individuals have been conditioned into the institution from head to toe and from our highest levels of education down to the most basic doctrinal principles.

Yeah, um, _we don’t have that long_. I’m basically concerned that things can come to a head as soon as immediately, and we’re now in the territory where the likelihood crossing 50% of complete dislocation is growing like it’s happening within two years, not like we have like ten years.

Which is why for example I mean I was never going to become like a professional and work with those Military Design people, I am _way too wild_ for that. I’m some weird kind of partisan _practitioner_ who was contacted? I guess that was my FBI visit, I’m always wondering why I never got one but I guess that was it. And now I’m sort of what, does anyone think Ben looks bad because of what I’ve done? Or is it just interesting.

My pretension of course is to be some kind of interesting example of narrative innovation and conflict engagement. Then the fact that I was in touch with this military person, and then they could figure out whether I talked to Grimes on December 22, 2022 at 6am EST or not. OMG I wish I was on the other side of that information wall!

Anyway, as MLK would say it doesn’t matter what happens with me now.

But yeah finally connecting to “[Beyond the Fever](https://genius.com/Grimes-before-the-fever-lyrics),” another classic Grimes/Afropessimism conceptual crossover:

I tease my little ashtray  
With the burning cigarette  
I don't want to run away  
I don't even know you yet  
I got everything you want  
I can make you feel so wet  
I'm a little bit in love with you  
I can take your picture, baby

 **This is the sound of the end of the world**  
Dance with me to the end of the night  
Be my girl  
Madness, intellect, audacity  
 **Truth and the lack thereof**  
 **They will kill us all, I've no doubt**

There are many ways in  
But there's only one way out  
There's only one way out  
There's so many ways in  
But there's only one way out  
 **This is the sound of the end of the world**

I get lost  
Can you get lost with me, baby?

Afropessimism again the Kaplan [article](https://ojs.lib.uwo.ca/index.php/chiasma/article/view/16873/12978) “Toward An Apocalyptic Hauntology Of Black Messianicity”:

The World as a transcendental structure of anti-Black containment and god-like vantage pointis precisely what establishes and governs the Human’s coordinates.

Accordingly, for the Human to become Black—that is, to learn the steps to the dance of social death—one must iterablyleap intoworldlessness.The necessarilyiterable structure of this leap is twofold: 1) since the Human’s acceptance of the Black’s invitation tothe dance of social death is contingent—whereas the Black is gratuitously constituted insocial death—Humans constitutively cannot “become Black” as long as the World persists; and, following Derrida, 2) the structure of the trace (of the Other) marks an originary repetition—or what Chandler emphasizes as an originary displacement, which “the Negro” incarnates24—that yields the conditions of im/possibility for any fidelity to the (wholly) Other.25In this way, from the position of the Human, deconstruction allows us to understand and inhabit the meta-aporetic demand of Cone’s question (how tobecome Black?) and Wilderson’s answer (to die) asan iterable embrace of worldlessness—i.e. as an iterable refusal ofourcoordinates—inwhich the Human’s asymptotic fidelity to Blackness marks the quasi-transcendental condition for (the coming of) any justice worthy of the name.

This iterative process of questioning presuppositions is the same as the triple-loop learning Zweibelson is again advocating in _Beyond The Pale_ :

The reflective practice offered in triple-loop thinking and systemic design should allow readers to explore beyond the pale of contemporary institutional limitations for the complex warfighting contexts of today and tomorrow. If leaders demand innovation today so that we might better fight tomorrow’s war not yet fought, should the organization not encourage innovation and critical introspection beyond adherence and compliance to institutionalized processes and theoretical frameworks often never seriously challenged? Part of this resistance is based on identity and the military belief system operating **under the surface.**

Shout out _[What Lies Beneath](https://en.wikipedia.org/wiki/What_Lies_Beneath)._

And now again for “[My Name is Dark (Art Mix)](https://www.google.com/search?q=my+name+is+dark+lyrcis&rlz=1CANIZI_enUS1144&oq=my+name+is+dark+lyrcis&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIMCAEQIxgnGIAEGIoFMggIAhAAGBYYHjIICAMQABgWGB4yCAgEEAAYFhgeMggIBRAAGBYYHjIICAYQABgWGB4yCAgHEAAYFhgeMggICBAAGBYYHjINCAkQABiGAxiABBiKBdIBCDI1ODFqMGo3qAIAsAIA&sourceid=chrome&ie=UTF-8),” there is the reference to:

Every city has a place like this

Underneath the bridges where the tainted kiss

Put on “Bullet With Butterfly Wings”

So that I can sing along while I break things

First of all being “underneath” the bridges, also “underneath the bridge” is the beginning of “Something in the way” by Kurt Cobain and Nirvana off the album _Nevermind._

Also again back to the hands, the trembling fingers of hands reaching out for each other, and this now completes the cycle by getting us to the “thesis” of _Miss Anthropocene,_ the song “New Gods”:

Hands reaching out for new gods

You can’t give me what I want

But what do I know?

I want to let go

I wear **black** eyeliner, **black** attire, yeah

So take me higher, and higher, and higher

Only brand new gods can save me

Similarly has in “IDORU,” with the promise of “reassembling you,” it recalls the story of Isis and Osiris:

[![The Grief of Isis | Live Without Dead Time](https://substackcdn.com/image/fetch/$s_!5dGe!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F683b77bd-6e50-4b68-a7bc-d84054724468_1896x1660.jpeg)](https://substackcdn.com/image/fetch/$s_!5dGe!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F683b77bd-6e50-4b68-a7bc-d84054724468_1896x1660.jpeg)

Notably, the last thing is the penis and it’s not found, right? 

[“What do you need that for, dude?”](http://-)

Anyway, the thing is _we_ are the new gods.

We are reaching out for each other with trembling fingers while running by ourselves—this is the locked-in syndrome of actually being in a situation where social codes don’t allow “communication,” there is endless friction and conflict due to entrench nervous system patterns and Hobbesian Trap dynamics, basically the lack of legitimacy of anything which could institute wholesome adjustments.

That means what we need are wholesome adaptations made in _attempted hostility_. So basically assuming I am not liked, how can I behave so that other people will change so that in the future they will be better company and so that I have a nice time the whole time as well?

Oh, again on Trembling, from the Kaplan:

When one considers the wholly Other in its Black singularity, I propose that Derrida’s reading of **trembling** emerges as the vertiginous means of contemplating the Human’s **iterable** attunement/fidelity to the gift of social death. This, I venture, is a means by which we Humans can (begin to) let ourselves be elaborated by an agenda of total disorder—in radical fidelity to the Black revolutionary desire for gratuitous messianic freedom. In Wilderson’s provocative but nonetheless sobering words: “What other lines of accountability are there when slaves are in the room?”

Trembling is again like the “autistic” stimming, a wonderfully Baudrillardian word. Again connected to iteration, the tapping of the metronome. Each beat a new logical type, a new abstraction over everything which has come before. This is routinized until we can swim in concepts and frames with the grace and determination of an inner dance undertaken while marching.

Though I’ve never been in combat other than every conversation of my life, I would venture to say I understand the martial spirit as well as anyone. What it really means, because it is this engagement with the other party beyond formalities.

It is to tread where no one goes and to have to steel yourself. There will be mistakes. People will get hurt. But these are the most important purposes we are talking about. And of course it’s bad to get too wrapped up and lose your way. But unless you are really willing to stake everything on this gambit that you might not even by worthy of, you’re not _in the frickin’ wheelhouse_.

To get there you have to take the secret tunnels that open up in the course of your inner earthquakes. See you there

> Things no longer meet head-on; they slip past one another. Everyone claims to ‘be in reality’. But the test of reality is not decisive. Nothing happens in the real.

Helognei.

Nothing happens where everyone sees it. Everything happens in dreams, in between. In secret. It would be too humiliating to acknowledge how the people we like the least have influenced us the most. It would be embarrassing. Better to wait until it goes away by itself, what, problem absolution?

I knew an “Absolution” once. It went to a different school, you wouldn’t know it.

Anyway, ol’ Mary Todd’s callin’ so I guess it must be time for

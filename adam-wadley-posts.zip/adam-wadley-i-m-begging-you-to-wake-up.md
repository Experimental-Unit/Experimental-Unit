---
title: I'm Begging You To Wake Up
subtitle: Reddit Coma Lila Rainbow
author: Adam Wadley
publication: Experimental Unit
date: April 17, 2025
---

# I'm Begging You To Wake Up
I mentioned in a recent post this story that’s on Reddit where there’s this guy (I’m thinking of the story Vincent Vega tells in _Pulp Fiction_ about how this guy got unloaded on this guy, and just didn’t get hit, this guy) and in a coma there’s a dreamworld of a whole family and it goes on for years.

And then one day a lamp looks a little off, and all of a sudden everything skews and it’s remembered that it’s a coma and then comes an awakening.

There’s even that movie, you know, it’s called _Awakenings_ , where it has Robert De Niro (I don’t know if you’ve ever heard of this Bob person but apparently a heck of an artist) playing someone who comes out of a vegetative state [state] and wants to tell people about how amazing everyday life is.

I was just in the car listening to a podcast about Heidegger, I’m reading this book called _Heidegger and the Nazis_. Maybe I should move it from the living room lol, brb.

And we’re back! This person called Ben Affleck was on this thing called Saturday Night Life like 20 years ago or more and I remember watching it with my sibling and there was that line, Affleck was a radio host. And we’re back?

And I always think of the line from _Red Mars_ where the photogenic scientist guy who is the face of the first settlement of Mars by 100 scientists gets to the surface finally and says, “Well, here we are.”

And we’re back. Well, here we are.

Anyways Heidegger also has this thing about everydayness. I couldn’t find the podcast I wanted to find. It’s a bit like the legendary '“Rule 34,” where there’s supposed to be pornography of anything you could imagine.

I guess there’s levels to it which are worth spelling out:

  1. There is probably more pornography than that of which you are aware. So many things you could imagine, but don’t know of as being in pornography, could very well be in pornography that you don’t know exists.

  2. To the point of enchudification or what it means for thought to be rigidified, you can think of how obvious most things people search for would be. There are things I might not personally be able to tell you because it involves access to databases and logs of internet traffic that I don’t have access to. Yet still the point is that even with so many people and the brain is so complicated and all that, still probably so much attention is placed on very obvious topics.

  3. For example, if you look at '“Rule 34” main subreddits for example, you will find pornography which is mainly of “female” characters from popular media series doing pornography things. Again what this “pornography things'“ means is again in bulk the same sorts of actions and gestures performed again and again in different contexts and by different people. For example pornography involves the genitalia and the body. Well, we have the body type that we have. There are parts and especially 1 vs 1 there is only so many combinations of gesture and position which can be made. Even this variation is infinite compared to what is usually seen in pornography, which for the most part involves the repetition of the same dozen acts over and over and over. So again this truncation and again all this focused again on popular media figures, celebrities.

  4. Otherwise, there are the various domains of significance which can be brought to bear on the erotic or nervous system impact, socialization and influence operation potential, and also simple self-gratification tool at higher and higher levels of abstraction. After all, in some sense the whole universe is God gooning, right? The whole universe is God committing the Holocaust? Right? So that in a nutshell is the whole “negative” or “difficult” side of my perspective out of the way, and it’s seeped into everything for a specific reason, which is that “nothing is alien to me.” More on that later. The point is something like the [seven mountain mandate](https://en.wikipedia.org/wiki/Seven_Mountain_Mandate); the point is to make a taxonomy of all the things that are important. For our version it is infinitely more complicated; you could say that the idea of “controlling art” spirals into a complex emergency even more interminable than war (see Breton on existential problems looming after social problems as quoted by Camus in _The Rebel_ ). Regardless, obviously people make pornography with political themes. But this is really just the tip (lol) of the iceberg so to speak. Themes such as self-expression, religion, family, self-worth, drugs, aliens, history, cultural difference, historical strife and its materialization in our bodies, the concept of nature, pregnancy, purpose, philosophy, etc., can all be brought to bear, in addition to the usual topics of general concern.

  5. This all somehow building on the idea of abstraction as applied to pornography. Baudrillard wrote that pornography was about reality, not sex. Similar to how people might say that rape is about power, not sex. Yet these definitions suppose that there is some difference between reality and sex and power. Whereas we might just as easily speak of sex power reality, or reality sex power, or reality power sex. Pornography as the explication of reality: here is what is possible. And you select for yourself the scenes which are somehow fascinating. I was for a time especially interested in “infrastructure”: power stations, bridges, water towers. The way all this is bearing. The question of where the electricity goes, who takes the bridges, what is the water used for? Crossing a bridge to use electricity to watch pornography and then take a shower using water. 




And similarly war is this question of okay, where are your forces actually? And the whole idea of defeat in detail. The whole question is: what is the operative level of detail? For example at the battle of Midway, it is no accident that first of all the operative ship was the aircraft carrier.

For the aircraft carrier and the airplane abstract over each other, make each other possible, in a way which was decisive at that time, at the level of technology deployed in that battle. The airplane is able to simply take off from a ship, which means it can be deployed anywhere, including in a naval engagement. This turns out to supersede all surface naval deployments which have no aerial component. Therefore the decisive battle at that time according to the technology deployed would be a carrier vs. carrier battle.

This technology deployed feature is addended to allow for the existence of secret technology which actually obsoleted aircraft carrier/fighter plane apparatuses even during e.g. the battle of Midway. This is not made in what I would call a “bad paranoid” way, though I do realize it opens a can of worms on which there is much to say and in a most detailed way.

There are two main scenarios to discuss here, and an overall commentary on the idea of “the official story of history.”

Because as of course becomes relevant e.g. in the discussion of esoteric Nazism or Duginism or something like this, what you are dealing with in an account of deep origins in a way which subsumes all other stories.

I would say we operate in a domain where “normal” is the “scientific” view of things, which I put in quotation marks not to cast aspersion but to point out that there is again a reality sex power to defining science or commanding the ability to abstract over the concept of science in a way convenient for oneself while covering one’s tracks enough to deploy plausible deniability protocols with weaponized gish gallow backup to tie up anyone who catches on long enough to adapt or find new environs.

Anyway, the normal idea is that the big bang happened and it was like 14 billion years ago. I was going to go oh my god, 14 again. Nnotably N is the 14th letter of “the” alphabet, also goes with Nazi, Nietzsche, Nation, see here also n-word tie in to “deep structure”/deep politics/para politics with the idea of glow n-word as advanced by [Terry Davis](https://en.wikipedia.org/wiki/Terry_A._Davis). So anyway I got into all that to say I looked it up and the actual official guess is that it was 13.7 billion years ago, which rounds to 14 but is also one of these crucial numbers 137, 317, 731. 137 is near fine structure constant & is where the 3 in 822317 appears in the decimal digits of pi, 317 is Boucher’s birthday in numerals (March 17), also St. Patrick’s day, and 731 for me principally calls to mind Unit 731 under the “Empire of Japan,” so again this theme of atrocities and also again the obviousness of it.

You want to do human experimentation to learn more about the body to help the people you care about. And it’s the absolute reduction of a person to the body, the complete indifference—I’m sorry, is such a person emotionally neglected?—to the inner world and the exploitation of the body itself. Cannibalism is a similar idea, or again rape and sex and we’re back to pornography.

Recall the homology, the isomorphism, this endless isomorphism I am describing to you as I am trying to pull the psilocybin out of every pore of the air—it’s always nice to hear from ol’ Silap Inua [that’s a reference to something Eli Manning said once; also legendary for “Deal with it” meme defeating Brady making Eli the stand-in for every underdog everywhere; as well as the Reddit AMA where Eli said “…I don’t think I’ve ever thrown an interception?” which is super legendary and I port into things like “…I don’t think I’ve ever committed a sin?” and other such grandiose tomfoolery].

It was that in pornography, okay it’s the same body parts. It’s the ones you have! And look at what they’re doing! And the text or concepts you associate with the images, your body parts, your own experience of concepts, and how all this is playing out literally in your nervous system.

Shit, who needs Unit 731? Through omnipresent data transfer we have converted the whole planet into a giant sphere for “human” experimentation! We have to go beyond the conceit of the human due to valid Afropessimist challenges which are sustained by reasoned judgment. It’s back to Agamben and Homo Sacer and saying that really that’s all there ever is.

The official story of history extends to why people do things like this. It’s psychology, people are psychopaths, and then we build the science to decide why psychopaths wind up coming out ahead. And you may as well be doing race “science” to decide why you wound up being at the head of the pack imperially speaking. They are the same if the upshot winds up being “everyone knows the good guys lost,” and therefore we are dallying away waiting for the day it will be our turn to face the music.

Regardless, the point was that the idea of secret technology, and oh no what alien artifacts are being reverse-engineered, or what ancient group here on this planet secretly survived and has a mobile base in the Bermuda Triangle, or whatever else people are talking about…

All that idea gets obviously connected to some “secret truth” of where we came from. Again, officially, we have the scientific account and the theory of evolution. Which, I have to say symbolically I am all for. Given that people wanted to say before that different people of the existing anthropoids or hominids were “different species” and use that to justify cruelty, it is nice to think that oh yes, here is the physical evidence to show that you share a common origin with people you think are beneath you.

Sadly, this sense that other people are “beneath you” in some fundamental way justifying building a whole horrible edifice around can persist either beyond their acceptance of this “official” account of the theory of evolution and the age of the universe and basically how everything has played out—for me notably great oxidation event and meteor strike vs. dinosaurs, then playing into our story of where all the different groups of people came from and what they have been up to this whole time—or people can simply secretly not accept the received wisdom and continue to “believe” that creation is not as old as that.

Or maybe that of course you see the aliens or secret old ones or whatever have genetic engineering, so even if there were a common origin maybe at some point in the past these people intervened and made some of the hominids different in some way which now again is going to inform some sense that some group is above or beneath another and again a whole horrible edifice is going to be built around it.

Which is again where you see that the figure Adolf Hitler looms large over all these proceedings.

Pornography can be innocent enough, but what I have seen is mind warping. It is enough to consider the impacts on me, who is _of course_ so able to weather these effects and profitably opine on them for your edification and viewing pleasure; but to consider what pornography, or to keep it PG, advertising itself actually does to people is staggering. 

This especially again most people’s inability to think in an abstract way about what they are experiencing. It is almost like we would think of an animal. It doesn’t have to reflect on things, it just goes about its business.

I hope you won’t find it too dangerous for me to say that. My lovely nice friend was just talking about the herd mentality the other day, completely divorced from Nietzsche or other worked out form of elitism. Just the way that people tend to do the same things and go along with the same things. Everyone feels left out or victimized at some point, because we can be in the minority or the scene of subjection at different times.

Those impressions are then made indelibly on us in our inner world, but are not readable to those who see us from outside. Or, something is known about us. Monica Lewinsky comes (comes) to mind. If I ever do become famous it will be something like that experience, of just like well, okay, something intense happened. It’s all sensational, and there’s people involved at the center of it. Bill Clinton, well, that person is used to being famous and has so much else going on and also did make it happen so. But the other person is just all of a sudden famous from nowhere and again for what would be called a pornographic act.

And again it’s back to this pornography and the laying bare.

Because equally to the obviousness of the act, the penis and the mouth and yes, it’s been done a million times and yet is something people want to do again and again and again. Again related to the constellation of the nervous system and again this “naturalization” of drives yet squeezed through arbitrary yet well-worn grooves.

And again yes that act with the president in the Oval Office, it’s all so obvious. And yet as obvious as all that is how it plays out.

As fundamental a fact it is that we have the genitals we do, that we have torsos and hands and this general body plan apparently inherited from billions of years of living things mutating, most of it asexually actually—sidenote to say that “asexual” reproduction actually preceding sexual reproduction is like my coup against humanists and sexual difference haymakers; similar to purusha, this theme emphasizes this coming into be of difference through subdivision instead of the meeting of magically discrete entities; this is my revenge similar to the theory of evolution’s revenge on those who would say that there are multiple origins or separate “species” present among surviving hominids/anthropoids—

It is just such a fundamental fact that there are newspapers, there is TV. These are the genital organs of the diffusion of codes and information.

So in other words as obvious as it is that the president again of “The United States of America” which is of course the most powerful and visible country which is like the center of the world, this president does one of the obvious sex acts, again one of the 12 or so I was estimating constitute most of the pornographic and even “Rule 34” content just with different “skins,” different implications of what the act might mean given the context in which it is presented..

Just as obvious as all that is that of course now this information must be put onto all the newspapers and televisions, and everyone will know about it. In this sense we can write that information is not about reality, but pornography.

This in the sense that we, most people, again this herd mentality, is to be more interested in the pornography and the gratification of it all rather than really wanting to deal with the hard (hard) reality. The hard reality may well turn out to be that the hard realities imposed on us, all this war and scarcity and atrocity and cruelty, may well be the work of some entities gratification.

Which is again back to this question of the secret people and what they want from us. Lacan I believe has this question, we wish we knew what the other people wanted from us. Baudrillard strives to be in a way beyond desire. I think it’s going from desire as this agent-based process to the twin ideas of 

  1. more this purely physiological working out, this mechanistic way where for example the profound experience is induced and molded with the chemical effects of known compounds applied to the body along with certain stimuli again studied beforehand, which is also the way that from the herd mentality standpoint people are getting amused by pseudo-novelty as a child, by things which “get old” a lot faster once you’re used to a higher order of simulation. This is combining with Baudrillard’s passage on “true” and “false” simulation in Towards the Vanishing Point of Art. Basically you want to be saying something new, which is again this successful abstraction over what has come before. Baudrillard likes Warhol for trying to take the artist out of the art, and taking advantage of this serial reproduction technique as well as again these basic images—not only the celebrity Monroe who is of course a sex symbol, but also the can of soup, which stands for what is basic, everyday, in the home, and yet also already mass produced and advertised so as to create a synthetic association which can’t help but pass over next into the symbolic. To sum up this part, “desire" is going from being taken at face value to a step above to see what forms of desire and gratification are obvious; from here, there is an endless progression of abstracting over schemes of gratification, which is of course itself an exercise in gratification. Yet also this exercise in abstraction, and as Baudrillard say the final passion—and desire is only a kind of passion, wouldn’t you say?—is this sadistic irony of gaining pleasure from the mistaken ways in which people, including ourselves, pursue pleasure. 

  2. The “symbolic” of it all. So I was trying to outline two things, but of course they mix together. As opposed to desire we look instead at the symbolic, also corollary to the gift obligation as studied by anthropology. This is where Buaudrillard is basically abstracting over Jarry, Mauss, Klossowski, Nietzsche, Artaud, you know, Baudrillard’s favorite people. I was also just thinking about how Baudrillard writes about Holderlin as well (too lazy for Umlauts), which is another Heidegger but also German nationalism/idealism/Greek? connection, anyway. Anyways, Baudrillard is not that interested in liberation in the sense of people being able to get what they want. The first point I made was basically saying Baudrillard is not impressed by what people want. If they want to get what they want, they should want better things. The second point is deeper seemingly and is saying that people should think about the whole idea of getting things, or getting what they want, or the entire idea of stakes. We should wonder what it is all for. We want to have a good job, so our kids will do well, so… what? What do we actually imagine for our grandchildren at this point? Baudrillard could already see the spiraling problem of technology as applied to all discourse. It is very easy to make anything seem passe or not worth doing. What matters then is who has the ability to set these codes, the A and not-As as Baudrillard describes in _Towards A Critique of the Political Economy of the Sign_. Yet even this bifurcation into true agents and “subhumans” (which is basically all of us who are not “world-controllers,” whoever that might be) still produces a symbolic problem: from whatever standpoint you find yourself, what do you “owe'“ it to yourself, to those around you, what do you “owe” it to existence itself to do as your response, your gesture in return for having gotten the chance to be incarnated at all? This is then tied into all our deeper purposes, the most important relationships, our breads and butters, our occupation, what we collect, what we dedicate time to remember, what rituals we perform, etc. Notably these can feel less about what you want so much as acknowledging where you dwell. At the level of exploding desire, we can simply ask the question of what we want to see happen in the world as a result of “liberation.” We should all get along, but literally what should we do after that? Shall we meld our ways together, or keep separate ways going to memorialize where we came from, we who figured out how to get along? What shall all these codes be?




This relates basically to all this “culture war” type conversation, which is again the same conversation had in different ways about the same things: vaginas, bodies, activity, self-expression, and so on. How shall people use the voice, what are they allowed to say, who is supposed to have “authority,” etc.

This is all “the social war” played out regardless of whether it comes to kinetic blows.

So to the point of something like Project Inner Alliance, the question is whether a tool could be used to reform some fundamentally predatory dynamic at play in all martial bureaucracy, or whether an tool or game would eventually be deployed in the martial bureaucratic fashion, even simply at a higher logical type.

There is a cruel kind of optimism in entertaining the notion that again this sadistic irony could escalate to where all metrics of “world peace” and “happiness” obtain, similar to wire chipping or something as an artificial intelligence scenario where we just get pleasure artificially and don’t have to “do” anything.

No, we want a challenge. As the character says in _Wall-E_ , I don’t want to survive, I want to live. And life has stakes, which means you could fail and die.

Yet even this could simply be accounted for by a higher-order algorithm, which is able to deliver to people their own convincing little arcs that they pull through from. But then what?

We have to see that how things actually work is by endless diversion. People are promised that they will feel good or accomplished or safe if they do these three simple things. But it turns out that the last payment must be made in Wampum (this is a Mitch Hedberg reference). In other words, friction comes into play. It’s something like you need to make the wedding but your car breaks down, and someone claims to be able to help but they steal your money. So it’s this promise that if you can get to the goal you’ll be happy, but you can never get there because it’s always something pops up, another problem. This happens to a lot of people and they never do go back to school, never do pay off their house, never do get married. They endlessly pursue this goal and then they die.

Or, you experience hypertelia or also a kind of abstraction agoraphobia.

In other words, you achieve your goal, but you realize in doing that what a transformation it is. Hypertelia would be that now you lack a sense of purpose. It reminds me of Matt Damon saying that it was nice to win an Oscar early because it showed them how little it fundamentally made you feel better. But it’s also like, what now? You did the thing.

Or again, to “the United States of America,” which plausibly has technology which could obsolete “Russia” or “China,” the idea is okay, maybe you “won” the idea of competing empires. What now?

Abstraction agoraphobia is where you get to this new level but you realize you’re just a n00b now. Like, you got the good job but now you have to deal with office politics and people trying to tear you down and intimidate you. Or you finally get the house and then you realize how much upkeep it is, how many parts go into it—that’s again abstraction, the organ systems that make up the dwelling—not to mention that you are fixed here now, this is now more or less permanently your neighborhood, and all that implies.

Or, lol, imagine if I do become president. It will be again this problem of okay, there’s so much you can do, but you so little understand the guts of what you are dealing with here.

So in the midst of all this to bring it back, Baudrillard is pointing at the symbolic, as well as a sort of clinical view of cultural anthropology where you’re just observing the patterns of abstraction. What do people commonly say, what concepts are mobilized, what implied separations are there, etc.

The symbolic ties then into what has escaped us since the beginning, and the existence of the world without our having been consulted. For Baudrillard, in the end all the technostructure can be said to be a symbolic response to this.

So zooming out again to this question of pornography and again this question of the Reddit coma. I titled this piece because there is another Reddit post or internet meme about someone being in a coma and someone outside telling them to wake up, and then by the end it is implied that you are the one in the coma and this point is the person outside telling you to wake up now.

For me this awakening ties in nicely with the idea of wokeness as well as “the great awakening” referred to by more Trump people. This also ties into the slogan “DEUTSCHLAND ERWACHE” used by of course the Nazis.

Waking also ties in with sleep and the idea of the dreamtime, and I’m thinking about the teacher in high school who both showed us the movie _Waking Life_ and also lent me _The Society of the Spectacle_ getting me started toward encountering Baudrillard at 17.

The connection is that from the point of view where we are God, this is Lila, this is the simple elaboration of incarnation from the standpoint of something some kind of logical type in the sky removed from all this; then life is in a way simply pornography, the playing out of all the pieces you know and love, arms and legs and promises and betrayals and economic shocks and everything you’ve come to know and love as part of the incarnation experience.

The pornography of the lie long told that comes to light. The truth about the aliens that’s so horrifying in its obviousness. The secret of someone else’s motives that are more boring and more profound than you could possibly imagine.

Pornography again as writing about prostitutes. This whoring oneself out for the world, that which you are such a slut for. The way that the national ritual shows what a slut you are for this idea, or for the idea that other people value this idea. Traffic lights or some slight you grin and bear as your sluttiness for order, for knowing your place.

How there’s not much difference between prostitution and labor of any kind, even Hurculean. It’s all affording the gratification of someone else, making the world safe for their pleasure, for the maddening torture of it all. How it keeps circling around the same things: arms, legs, genitals, mouths, speech, emotion, event. To be a good soldier or a good girl is much the same thing in this context.

And yet, and this is the crucial note to end this half-baked half-hearted entry on: the open-endedness of it all.

Because abstraction, again this vertigo of sadistic irony—but don’t get too upset because the suffering inflicted become indistinguishable from pleasure, _my dear_ —makes it to where anything can be borne, and profitably. Tell me my epigenetics are tainted by the Holocaust, or that aliens are feeding off my suffering, or that I have undiagnosed ADHD and all this could have been prevented, or that I’m really in a coma, that I really am the faggot “America,” and in a bad way….

I’m doing a bad job, but imagine whatever horrible eventuality you are so afraid of. We don’t prevent nuclear war. You do go to hell. Whatever.

The thing is that fluency of thought and consideration can abstract over all of these. Not necessarily to make anything you _want_ , but certainly anything can be read against whatever grain seems to you intolerable.

It basically turns out that you can only overcome the fantasy that some ironic sadism is being performed on you by yourself performing some fantastical sadistic irony. 

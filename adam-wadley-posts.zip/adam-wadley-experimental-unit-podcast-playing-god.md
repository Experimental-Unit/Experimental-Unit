---
title: 'Experimental Unit Podcast: "Playing God"'
subtitle: Experimental Unit is a Substack about Planetary Emergency Response & Interactive
  Narrative Performance
author: Adam Wadley
publication: Experimental Unit
date: October 28, 2025
---

# Experimental Unit Podcast: "Playing God"
[![](https://substackcdn.com/image/fetch/$s_!HpuG!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff97b9b7d-94ff-4c18-bc89-3668e457853f_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!HpuG!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff97b9b7d-94ff-4c18-bc89-3668e457853f_4032x3024.jpeg)

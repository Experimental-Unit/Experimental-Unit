---
title: 'Experimental Podcast: OCBII'
subtitle: First in a series
author: Adam Wadley
publication: Experimental Unit
date: December 15, 2025
---

# Experimental Podcast: OCBII
[![](https://substackcdn.com/image/fetch/$s_!fTUa!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb7828a8b-5793-42b2-99cb-aa03019c4ab3_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!fTUa!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb7828a8b-5793-42b2-99cb-aa03019c4ab3_4032x3024.jpeg)

cc: [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions) [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions)

---
title: Readying Readiness
subtitle: What We In West Texas Call "Reading Books"
author: Adam Wadley
publication: Experimental Unit
date: May 12, 2025
---

# Readying Readiness
Once again, I don’t have much time.

Based on the subtitle to the last ChatGPT article, I thought I’d dwell again upon this theme of readying readiness as brought up by Martin Heidegger in the 1966 interview[ “Only A God Can Save Us”](https://www.ditext.com/heidegger/interview.html) done with _Der Spiegel_ , which means “The Mirror.”

Heidegger was of course an official in Nazi Germany. Notably Baudrillard also writes about Heidegger at length in the chapter “Necrospective” from _The Transparency of Evil_.

Nevertheless, here in ‘66, Martin (see same name as Martin Luther King, Jr.; Martin Luther; St. Martin who cut their cloak in two to give half to a beggar in the snow) is giving an interview which deals precisely with the question of their involvement with the Nazis, and Martin is trying to make themselves seem as honorable as possible, of course.

But with Martin, with Heidegger, it’s a two-fold issue of this Nazi business but then also the philosophy. Note that Heidegger is used in Afropessimism a lot, because Heidegger writes about being. The ontological terror discussed in Afropessimism is precisely the horror of nothing, which is of course an important topic when it comes to being.

The whole thing is pretty important:

> Heidegger: The parenthesis stood in my [original] manuscript and corresponded precisely to my conception of technicity at that time, and not yet to the later explication of the essence of technicity as "pos-ure" ( _Ge-Stell_ ).24 The reason I did not read the phrase publicly [206] was that I was convinced of the proper understanding of my listeners, although stupid people, informers and spies understood it differently -- and also wanted to.
> 
> SPIEGEL: Surely you would include here the communist movement?
> 
> Heidegger: Yes, unquestionably -- insofar as that, too is a form of planetary technicity.
> 
> SPIEGEL: Americanism also?
> 
> Heidegger: Yes, I would say so. Meantime, the last 30 years have made it clearer that the planet-wide movement of modern technicity is a power whose magnitude in determining [our] history can hardly be overestimated. For me today it is a decisive question as to how any political system -- and which one -- can be adapted to an epoch of technicity. I know of no answer to this question. I am not convinced that it is democracy.
> 
> SPIEGEL: But "democracy" is only a collective term that can be conceptualized in many different ways. The question is whether or not a transformation of this political form is still possible. Since 1945, you have commented on the political efforts of the Western World, hence also on democracy, on a politically expressed Christian view of the world ( _Weltanschauung_ ), even on the system of constitutionally guaranteed citizens' rights. All of these efforts you have called "half-way measures."
> 
> Heidegger: First of all, please tell me where I have spoken about democracy and the other things you mention. I would indeed characterize them as half-way measures, [though] because I do not see in them any actual confrontation with the world of technicity, inasmuch as behind them all, according to my view, stands the conception that technicity in its essence is something that man holds within his own hands. In my opinion, this is not possible. Technicity in its essence is something that man does not master by his own power.25
> 
> SPIEGEL: Which of the trends just sketched out, according to your view, would be most suitable to our time?
> 
> Heidegger: I don't see [any answer to] that. But I do see here a decisive question. First of ill, it would be necessary to clarify what you mean by "suitable to our time." What is meant here by "time?" Furthermore, the question should be raised as to whether such suitability is the [appropriate] standard for the "inner truth" of human activity, and whether the standard measure of [human] activity is not thinking and poetizing, however heretical such a shift [of emphasis] may seem to be.26
> 
> SPIEGEL: It is obvious that man it never [complete] master of his tools -- witness the case of the Sorcerer's Apprentice. But is it not a little too pessimistic to say: we are not gaining mastery over this surely much greater tool [that is] modern technicity?
> 
> Heidegger: Pessimism, no. In the area of the reflection that I am attempting now, pessimism and optimism are positions that don't go far enough. But above all, modern technicity is no "tool" and has nothing at all to do with tools.
> 
> SPIEGEL: Why should we be so powerfully overwhelmed by technicity that...?
> 
> Heidegger: I don't say [we are] "overwhelmed" [by it]. I say that up to the present we have not yet found a way to respond to the essence of technicity.
> 
> SPIEGEL: But someone might object very naively: what must be mastered in this case? Everything is functioning. More and more electric power companies are being built. Production is up. In highly technologized parts of the earth, people are well cared for. We are living in a state of prosperity. What really is lacking to us?
> 
> Heidegger: Everything is functioning. That is precisely what is awesome, that everything functions, that the functioning propels everything more and more toward further functioning, and that technicity increasingly dislodges man and uproots him from the earth. I don't know if you were shocked, but [certainly] I was shocked when a short time ago I saw the pictures of the earth taken from the moon. We do not need atomic bombs at all [to uproot us] -- the uprooting of man is already here. All our relationships have become merely technical ones. It is no longer upon an earth that man lives today. Recently I had a long [209] dialogue in Provence with Rene Char -- a poet and resistance fighter, as you know. In Provence now, launch pads are being built and the countryside laid waste in unimaginable fashion. This poet, who certainly is open to no suspicion of sentimentality or of glorifying the idyllic, said to me that the uprooting of man that is now taking place is the end [of everything human], unless thinking and poetizing once again regain [their] nonviolent power.
> 
> SPIEGEL: Well, we have to say that indeed we prefer to be here, and in our age we surely will not have to leave for elsewhere. But who knows if man is determined to be upon this earth? It is thinkable that man has absolutely no determination at all. After all, one might see it to be one of man's possibilities that he reach out from this earth toward other planets. We have by no means come that far, of course -- but where is it written that he has his place here?
> 
> Heidegger: As far as my own orientation goes, in any case, I know that, according to our human experience and history, everything essential and of great magnitude has arisen only out of the fact that man had a home and was rooted in a tradition. Contemporary literature, for example, is largely destructive.
> 
> SPIEGEL: The word "destructive" in this case is bothersome, especially insofar as, thanks to you and your philosophy, the word has been given a comprehensive context of meaning that is nihilistic [in tone]. It is jarring to hear the word "destructive" used with regard to literature, which apparently you are able to see -- or are compelled to see -- as completely a part of this nihlism.
> 
> Heidegger: Let me say that the literature I have in mind is not nihilistic in the sense that I give to that word.
> 
> SPIEGEL: Obviously, you see a world movement -- this is the way you, too, have expressed it -- that either is bringing about an absolutely technical state or has done so already.
> 
> Heidegger: That's right.
> 
> SPIEGEL: Fine. Now the question naturally arises: Can the individual man in any way still influence this web of fateful circumstance? Or, indeed, can philosophy influence it? Or can both together influence it, insofar as philosophy guides the individual, or several individuals, to a determined action?
> 
> Heidegger: If I may answer briefly, and perhaps clumsily, but after long reflection: philosophy will be unable to effect any immediate change in the current state of the world. This is true not only of philosophy but of all purely human reflection and endeavor. Only a god can save us. The only possibility available to us is that by thinknig and poetizing we prepare a readiness for the appearance of a god, or for the absence of a god in [our] decline, insofar as in view of the absent god we are in a state of decline.27
> 
> SPIEGEL: Is there a correlation between your thinking and the emergence of this god? Is there here in your view a causal connection? Do you feel that we can bring a god forth by our thinking?
> 
> Heidegger: We can not bring him forth by our thinking. At best we can awaken a readiness to wait [for him].
> 
> SPIEGEL: But can we help?
> 
> Heidegger: The first help might be the readying of this readiness. It is not through man that the world can be what it is and how it is -- but also not without man. In my view, this goes together with the fact that what I call "Being" (that long traditional, highly ambiguous, now worn-out word) has need of man in order that its revelation, its appearance as truth, and its [various] forms may come to pass. The essence of technicity I see in what I call "pos-ure" (Ge-Sull), an often ridiculed and perhaps awkward expression.28 To say that pos-ure holds sway means that man is posed, enjoined and challenged by a power that becomes manifest in the essence of technicity -- a power that man himself does not control. Thought asks no more than this: that it help us achieve this insight. Philosophy is at an end.
> 
> SPIEGEL: Yet, nonetheless, in former times (and not only in former times) philosophy was thought to accomplish a great deal indirectly -- directly only seldom -- but was able indirectly to do much, to help new currents break through. If we think only of the great names of German thought, like Kant and Hegel down through Nietzsche (not to mention Marx), it can be shown that in roundabout ways philosophy has had a tremendous effect. Do you mean now that this effectiveness of philosophy is at an end? And if you say that the old philosophy is dead -- that there is no such thing any more, do you also include the thought that this effectiveness of philosophy, if it was ever there in the past, is in our day, at least, no longer there?
> 
> Heidegger: A mediated effectiveness is possible through another [kind of] thinking, but no direct one -- in the sense that thought will change the world in any causal way, so to speak.
> 
> SPIEGEL: Excuse me, we do not wish to philosophize -- we are not up to that -- but we have here the point of contact between politics and philosophy. That is why you notice that we are drawn into a dialogue of this kind. You have just said that philosophy and the individual would be able to do nothing but...
> 
> Heidegger: . . . .but make ready for this readiness of holding oneself open for the arrival, or for the absence, of a god. Even the experience of this absence is not nothing, but a liberation of man from what in _Being and Time_ I call "fallenness" upon beings.29 Making [ourselves] ready for the aforementioned readiness involves reflecting on what in our own day. . .is.
> 
> SPIEGEL: But for this we still would need, in fact, the well-known stimulus from outside -- a god or someone else. Hence, [we are asking:] cannot thought, relying completely on its own resources, have a greater impact today? There was a time when it had an impact -- [at least] so thought the contemporaries then, and many of us, I suspect, think so too.
> 
> Heidegger: But not immediately.
> 
> SPIEGEL: We just mentioned Kant, Hegel and Marx as men who moved [the world]. But even from a Leibniz came stimuli for the development of modern physics and consequently for the emergence of the modern world as such. We believe you said a moment ago that you no longer take account of efficacy of this kind.
> 
> Heidegger: Not in the sense of philosophy -- not any more.30 The role of philosophy in the past has been taken ever today by the sciences. For a satisfactory clarification of the "efficacy" of [philosophical] thinking we would have to analyze in greater depth what in this case "efficacy" and "having an effect" can mean. Here we would need fundamental distinctions bctwen"occasion," "stimulus," "challenge," "assistance," "hinderancc" and "cooperation," once we have sufficiently analyzed the "principle of ground ['sufficient reason']." Philosophy [today] dissolves into individual sciences: psychology, logic, political science.
> 
> SPIEGEL: And what now takes the place of philosophy?
> 
> Heidegger: Cybernetics.
> 
> SPIEGEL: Or the pious [one] that holds himself open.31
> 
> Heidegger: But that is no longer philosophy.32
> 
> SPIEGEL: What is it then?
> 
> Heidegger: I call it another [kind of] thinking.
> 
> SPIEGEL: You call it another [kind of] thinking. Would you please formulate that a bit more clearly?
> 
> Heidegger: Are you thinking of the sentence with which I closed my lecture, "The Question of Technicity": "Questioning is the piety of thought"?
> 
> SPIEGEL: We found a phrase in your Nietzsche courses that was illuminating. You say there: "Because philosophical thinking takes place within the strictest possible bounds, all great thinkers think the same [thing]. But this same [thing] is so essential and rich that no individual ever exhausts it, but rather each [individual] only binds other individuals [to it] the more rigorously." But indeed it is precisely this philosophical edifice that in your opinon apparently has reached a certain termination,
> 
> Heidegger: It has reached its term. But it has not become for us [simply] nothing -- rather, precisely through dialogue it has become newly present again. My entire work in courses and seminars over the past 30 years was, in the main, only an interpretation of Western philosophy. The return to the historical foundations of thought, the thinking through of those questions that since Greek philosophy still go unasked -- this is no abandonment of the tradition. What I do say is this: the manner of thinking of traditional metaphysics that reached its term with Nietzsche offers no further possibility of experiencing in thought the fundamental thrust of the age of technicity that is just beginning.
> 
> SPIEGEL: About two years ago in an exchange with a Buddhist monk, you spoke of "a completely new method of thinking" and said that this new method of thinking is, "at first, possible for but few men to achieve." Did you mean to say by this that only very few people can have the insights that in your opinion are possible and necessary?
> 
> Heidegger: [Yes, if you take] "have" in the completely original sense that they are able in a certain way to give utterance to [these insights].
> 
> SPIEGEL: Fine but the transmission [of these insights] into actualization you did not make apparent even in this dialogue with the Buddhist.
> 
> Heidegger: And I cannot make it apparent. I know nothing about how this thought has an "effect." It may be, too, that the way of thought today may lead one to remain silent in order to protect this thought from becoming cheapened within a year. It may also be that it needs 300 years in order to have an "effect."
> 
> SPIEGEL: We understand very well. However, since we do not live 300 years hence but here and now, silence is denied us. The rest of us -- politicians, half-politicians, citizens, journalists, etc. -- must constantly make decisions. We must adapt ourselves to the system in which we live, must seek to change it, must scout out the narrow openings that may lead to reform, and the still narrower openings that may lead to revolution. We expect help from philosophers, even if only indirect help -- help in roundabout ways. And now we hear only: I cannot help you.
> 
> Heidegger: Well, I can't.
> 
> SPIEGEL: That must discourage the nonphilosopher.
> 
> Heidegger: I cannot [help you], because the questions are so difficult that it would run counter to the sense of this task of thinking to suddenly step out in public in order to preach and dispense moral censures. Perhaps we may venture to put it this way: to the mystery of the planetary domination of the un-thought esssence of technicity corresponds the tentative, unassuming character of thought that strives to ponder this unthought [essence].
> 
> SPIEGEL: You do not count yourself among those who, if they would only be heard, could point out a way?
> 
> Heidegger: No! I know of no way to change the present state of the world immediately, [even] assuming that such a thing be at all humanly possible. But it seems to me that the thinking that I attempt might be able to awaken, clarify, and confirm [a] readiness [for the appearance of'a god] that I have mentioned already.
> 
> SPIEGEL: A clear answer! But can -- and may -- a thinker say: [214] just wait -- we will think of something within 300 years?
> 
> Heidegger: It is not simply a matter of just waiting until something occurs to man within 300 years, but rather to think forward without prophetic claims into the coming time in terms of the fundamental thrust of our present age that has hardly been thought through [at all]. Thinking is not inactivity, but is itself by its very nature an engagement that stands in dialogue with the epochal moment of the world. It seems to me that the distinction between theory and practice comes from metaphysics, and the conception of a transmission between these two blocks the way to insight into what I understand by thinking. Perhaps I may refer to my lectures under the title, " _What is Called Thinking?_ " that appeared in 1954.33 Maybe this, too, is a sign of our time, that of all my publications, this is the least read.
> 
> SPIEGEL: Let us return to where we began. Would it not be thinkable that we see National Socialism, on the one hand, as the actualization of this "planetary encounter" and, on the other, as the last, worst, strongest and, at the same time, weakest protest against this encounter between "planetary technicity" and modern man? Obviously you have in your person a [certain] polarity that brings it about that many by-products of your activity are to be explained properly only by the fact that different sides of your nature (that do not touch your philosophical core) cling to many things that as a philosopher you know have no firm base -- for example, concepts such as "home," "rootedness" and the like. How do these things go together: planetary technicity and home?
> 
> Heidegger: I do not agree. It seems to me that you take technicity in much too absolute [a sense]. I see the situation of man in the world of planetary technicity not as an inextricable and inescapable destiny, but I see the task of thought precisely in this, that within its own limits it helps man as such achieve a satisfactory relationship to the essence of technicity. National Socialism did indeed go in this direction. Those people, however, were far too poorly equipped for thought to arrive at a really explicit relationship to what is happening today and has been underway for the past 300 years.
> 
> SPIEGEL: Do the Americans today have this explicit relationship?
> 
> Heidegger: They do not have it either. They are still caught up in a thought that, under the guise of pragmatism, facilitates the technical operation and manipulation [of things], but at the same time blocks the way to reflection upon the genuine nature of modern technicity. At the same time, here and there in the USA attempts are being made to become free from pragmatic-positivistic thinking. And who of us would be in a position to decide whether or not one day in Russia or China very old traditions of "thought" may awaken that will help make possible for man a free relationship to the technical world?
> 
> SPIEGEL: [But], if none of them has this relationship [now], and the philosopher is unable to give it to them. . . .
> 
> Heidegger: How far I come with my own effort at thought and in what way it will be received in the future and fruitfully transformed -- this is not for me to decide. In a special lecture on the occasion of the jubilee of the University of Freiburg in 1957, under the title, "The Principle of Identity,"34 I finally ventured to show in a few steps of thought to what extent there is opened up for man in the age of technicity (insofar as we thoughtfully experience what the genuine nature of technicity is based upon) the possibility of experiencing a relationship to an appeal to which he is not only able to attend but of which he is much rather himself an attendant. My thought stands in an unavoidable relationship to the poetry of Hölderlin. I consider Hölderlin not [just] one poet among others whose work the historians of literature may take as a theme [for study]. For me, Höderlin is the poet who points into the future, who waits for a god, and who, consequently, should not remain merely an object of research according to the canons of literary history.
> 
> SPIEGEL: Apropos of Hölderlin -- we apologize for having to quote again: in your Nietzsche courses you said that "the varied conflict we know between the Dionysian and the Apollonian, between holy passion and sober exposition, is a hidden law of style of the historical determination of the German [people], and one day must find us ready and prepared for it to take its form. This antithesis is not [just] a formula with the help of which we may only describe [our] 'culture.' With this conflict, Holderlin and Nietzsche have set a question mark in front of the task of Germans to find their essence in an historical way. Will we understand the [question] mark? One thing is certain, history will take its revenge upon us if we do not understand it." We do not know in which year you wrote that, but we guess that it was in 1935.
> 
> Heidegger: Probably the citation belongs to the Nietzsche course, "The Will-to-Powcr as Art," 1936-37.35 It could date, however, from the following years.
> 
> SPIEGEL: Well, could you please explain it? It leads us from the pathway of the general to a concrete determination of the German [people].
> 
> Heidegger: The drift of the citation I could also put this way: my conviction is that only in the same place where the modern technical world took its origin can we also prepare a conversion ( _Umkehr_ ) of it. In other words, this cannot happen by taking over Zen-Buddhism or other Eastern experiences of the world. [217] For this conversion of thought we need the help of the European tradition and a new appropriation of it. Thought will be transformed only through thought that has the same origin and determination.
> 
> SPIEGEL: You mean, in the same place where the technical world took its origin it also must. . . .
> 
> Heidegger: . . .be sublated ( _aufgehoben_ ) in the Hegelian sense -- not set aside but sublated, though not through man alone.36
> 
> SPIEGEL: You attribute to the Germans a special task?
> 
> Heidegger: Yes, in the sense explained in the dialogues with Hölderlin.
> 
> SPIEGEL: Do you believe that Germans have a special qualification for this conversion?
> 
> Heidegger: I am thinking of the special inner kinship between the German language and the language of the Greeks and their thought. This is something that the French confirm for me again and again today. When they begin to think, they speak German. They assure [me] that they do not succeed with their own language.
> 
> SPIEGEL: Is that how you explain the fact that in the countries of romance languages, especially among the French, you have had such a strong influence?
> 
> Heidegger: [It is] because they see that despite all of their great rationality they no longer make a go of it in today's world when it comes to an issue of understanding this world in the origin of its essence. One can no more translate thought than one can translate a poem. At best, one can paraphrase it. As soon as one attempts a literal translation, everything is transformed.
> 
> SPIEGEL: A disturbing thought.
> 
> Heidegger: It would be good if this disturbance were taken seriously in good measure, and people finally gave some thought to what a portentous transformation Greek thought underwent by translation into the Latin of Rome, an event that even today prevents an adequate reflection upon the fundamental words of Greek thought.
> 
> SPIEGEL: Professor, for our part we would like to maintain our optimism that something can be communicated and even translated, for if we should cease to hope that the content of thought can be communicated, even beyond language barriers, then we are left with the threat of provincialism.
> 
> Heidegger: Would you characterize Greek thought in distinction from the conceptual style of the Roman Empire as "provincial?" Business letters can be translated into all languages. The sciences, i.e., even for us today the natural sciences (with mathematical physics as the fundamental science), are translatable into all the languages of the world -- or, to be exact, they are not translated but the same mathematical language is spoken [universally]. [But] we touch here a broad field that is difficult to cover.
> 
> SPIEGEL: Perhaps this is another version of the same theme: at the moment it is no exaggeration [to say that] we have a crisis of the democratic-parliamentary system. We have had it for a long time. We have it especially in Germany, but not in Germany alone. We have it also in the classical lands of democracy like England and America. In France, it is hardly any longer a crisis. The question, then, is this: isn't it possible, after all, that suggestions come from the thinkers (if only as a by-product) either as to how this system may be replaced by a new one and what a new one would look like, or that reform must be possible -- together with some indication as to how this reform could be possible. Otherwise, we are left in a situation where the man who is philosophically untutored -- and normally this will be one who holds things in his hands (though he does not determine them) and who is himself in the hands of things -- we are left in a situation [I say] where such a man arrives at false conclusions, perhaps at frightful short-circuits [of thought]. Therefore, ought not the philosopher be ready [219] to formulate thoughts as to how men may arrange their relations with other men in this world that they themselves have technologized, that perhaps has overwhelmed them? And does he not betray a part, albeit a small part, of his profession and his vocation if he has nothing to say to his fellow men?
> 
> Heidegger: As far as I can see, an individual [thinker] is not in a position by reason of his thought to see through the world as a whole in such fashion as to be able to offer practical advice, and this, indeed, in view of the fact that his first task is to find a basis for thinking itself. For as long as thought takes itself seriously in terms of the great tradition, it is asking too much of thought for it to be committed to offering advice in this way. By what authority could this come about? In the domain of thinking there are no authoritative statements. The only measure for thought comes from the thing itself to be thought. But this is, above all, the [eminently] Questionable. In order to give some insight into the "content" of such thought, it would be necessary to analyze the relationship between philosophy and the sciences, whose technical-practical accomplishments make thought in the philosophical sense seem more and more superfluous. Thus it happens that corresponding to the predicament that thought faces by reason of its own proper task there is an estrangement with regard to thought nourished by the powerful place of the sciences [in our culture]. [That is why] thought is forced to renounce an answer to questions of the day concerning practical matters of _Weltanschauung_. . . .
> 
> SPIEGEL: Professor, in the domain of thought there are no authoritative statements. Likewise, it is surely not surprising that modern art, too, has difficulty in making authoritative statements. And yet you call it "destructive." Modern art understands itself often as experimental art. Its works are attempts. . . .
> 
> Heidegger: I am glad to be instructed.
> 
> SPIEGEL: . . .Attempts within a situation where man and the artist are isolated, and [yet] among a hundred efforts every now and again one succeeds.
> 
> Heidegger: This is indeed the question: where does art stand? What place does it have?
> 
> SPIEGEL: All right, but there you demand something from art that you no longer demand from thought.
> 
> Heidegger: I demand nothing from art. I say only that it is a question as to what place it occupies.
> 
> SPIEGEL: If art does not know its place, is it therefore destructive?
> 
> Heidegger: All right, cross the word out. I would like to observe, however, that I do not see anything about modern art that points out a way [for us]. Moreover, it remains obscure as to how art sees the specific character of art, or at least looks for it.
> 
> SPIEGEL: The artist, too, finds nothing in what is handed down to bind him. He can find it beautiful and say: Yes, this is the way someone could paint 600 years ago, or even 30 years ago, but he himself can do it no longer. Even if he wanted to, he could not do it. [If that were possible,] then the greatest artist would be an ingenious imposter [like] Hans van Meegeren, who could paint "better" than [his contemporaries]. But this sort of thing does not work anymore. Thus the artist, the writer, the poet are in a situation similar to that of the thinker. How often must we then say: close your eyes.
> 
> Heidegger: If we take as framework for the correlation of art, poetry and philosophy the "culture business" -- then the comparison you make is valid. But if not only the "business" character is open to question but also the meaning of "culture," then reflection upon such questionable matters falls, too, within the area of responsibility of thought, whose own distressed condition is not easily thought through. But the greatest need of thought consists in this, that today, so far as I can see, there is still no thinker speaking who is "great" enough to bring thought immediately and in clearly defined form before the heart of the matter [ _seine Sache_ ] and thereby [set it] on its way. For us today, the greatness of what is to be thought is [all] too great. Perhaps the best we can do is strive to break a passage through it -- along narrow paths that do not stretch too far.

As you can see, Heidegger is talking about relevant topics, from the scale of planetary techniticity to what we can do, which is ready our readiness.

With planetary technicity, I refer you again to the idea of the planetary state of emergency. It is precisely this giant task which demands that all the means be put to use to address it.

One way I think of it with Heidegger is the standing-reserve. If everything is doing so well at making things standing-reserve, then let us make the art of deployment.

See, for example, Kanye West’s deployment of Nazism for… some reason. It remains to be seen what will still come out of it. I hope to be of some interesting influence :)

But anyway, it’s important to see that Nazism is one such standing-reserve. It is an unresolved trauma. It is a name for a mystery, back to the question of what it means to be Jewish as raised recently by Norm Finkelstein.

But see also concepts like autism. Autism is a huge potential, there is a lot of charge around it and yet it is not understood, because it is a word for what can never be understood, which is how we even come to be in a give-and-take with each other, why it can go so wrong.

Remember also that this interview connects with Grimes’ song “New Gods,” and also that Eminem’s “Rap Gods” is sort of in response to Kanye talking about being a King, I think? I kind of make a point of not knowing too much about some of this stuff. I just want to plug it into all this other lore.

So here are the lyrics to “New Gods”:

> Oh, you're all I know  
> But what can I do if I can't see you?  
> It's too bright  
> Broken glass that shines like northern lights  
> So I pray, but the world burns  
> And still, you need to come first  
> So I don't know where you stand
> 
> Are you a man?  
> Are you something I can't stand?
> 
> Hands reaching out for new gods  
> You can't give me what I want
> 
> But what do I know? Oh  
> What do I know?  
> I wanna let go, I  
> I wanna, wanna, wanna let go
> 
> I wear black eyeliner, black attire, yeah  
> So take me higher and higher and higher
> 
> But the world is a sad place, baby  
> Only brand new gods can save me  
> Only brand new gods can save me  
> Oh, oh, oh  
> Only brand new gods
> 
> Hands reaching out for new gods  
> You can't give me what I want  
> Hands reaching out for new gods  
> You can't give me what I want

So, who is the song to? Remember the common conflation of the divine and the beloved. The single other sentient being you are invested in, if they exist, is like your ambassador to everything else. The one and the many, you are the one, the experimental unit, and outside you there are the one and the two and the four and the eight and the 822,317 things.

So you are all I know. You are God, since everything outside me has sovereignty. As Baudrillard says, the world is sovereign. And you are in the world, you partake of the sovereignty of the world. Vis. Afropessimism I don’t think Baudrillard is contained here within world fetishism.

The world here may well mean the world that is seen, the real world so to speak, e.g. formally excluding black people as in the Afropessimist view. Yet it’s important not to conflate the attempt at ontological overcoding in the lived experience of the brainwashed with what is actually the case.

In other words, the white world can want to believe that it is cut off from the black world, that it is being and that blackness is nothingness, but it’s not really true.

The projection of ontological terror onto something else is always the sign of further traversing of Greater Jihad DLC Pack. At the same time, of course I am doing this, everyone is doing this.

The point is not to shame anyone or say that anything in the past “should” have been different.

This is a double edged sword as I imagine you, the reader. Because you will want to think that some things indeed should not have happened. People were mean to you for no reason, you didn’t deserve it. Not to mention atrocities and people dying and mass murder and suicide and child cancer and rape culture and so on. 

It can seem cold or too strict not to say something like well it would have been better if it hadn’t happened. The issue I have is that that’s the way it happened and it will always be that way.

The upside for anyone is that we can often feel like we didn’t do enough, that we aren’t good enough, that we feel bad about something we did, or we feel ashamed, and we feel either internalizing other people’s criticism and rudeness, or we feel ashamed because we don’t know how to stand up to it.

This is a crucial problem for morale and it’s important to remember that morale is 75% of emergency response operations.

It’s therefore important that you feel license to improve your morale. Now, I don’t necessarily doing what I have done, which has caused a lot of stress. I’m sort of like an emergency siren which is chaotically letting everyone know what time it is, like Paul Revere riding in from the east on the third day and stuff like that.

Or again think Joan of Arc, I’m like that but not for any nation. Or, like, my “nation” is all sentient beings so whatever strict subset of that you want to appreciate and remember and do stuff from, you know what, that is A-OK by me.

The little issue is that we are not ready for the God technology because we are so mean, basically.

Now, I get it, someone was mean to you. Look who’s talking! I mean, I get it.

At the same time, our grievances and attempts to feel cozy and safe are killing people all the time.

We have people dying for preventable reasons who can be living instead.

All the time people are dying who don’t need to.

Open air prison? The planet is _an open-air concentration camp_.

So when it comes to the idea of crabs pulling each other down in the bucket, think of carcinisation, where things turn into crabs. That was my idea of a chud.

There are a million ways to become cognitive rigid. There are just as many ways to loosen up again.

I mean as I’ve said, one of the big limit cases of ethics in our time is something like circumcision. I’ll tell you that on its face I my impulse would be to discontinue the practice.

Yet this is a practice which means a lot to people, to say the least, with major representation in Judaism, Islam, and among some Christians as in “the United States.”

So if you want to discontinue it, then some people will say that it is cultural genocide, which is a very serious charge of course. When it comes to Baudrillard their final solution involves basically unlimited mental cloning so that everything becomes frictionless communication but that kind of sucks really bad. That’s because we need all the hiccups, the friction, the things that go wrong. That’s what gives the whole thing the time to unfold.

There’s something here about the deep cosmology of time and in terms of Experimental Unit, the way down which is the sense of the Absolute, the sublime, Wankan Tanka, etc., incarnation and sort of “descending” the chain of being or whatnot (which doesn’t exist by the way). It’s kind of problematic to simply associate this with down, you could also think of the way up as the ascent of the cthonic deity to the level of our abstraction, as the tiniest quantum physics layers up to our conventional Newtonian meso-cosmic scale of space, time, and motion, and also of abstraction.

Anyway, the point of the issue with circumcision is that if, on the other hand, you cave and say okay, well then you are letting people cut the genitals of infants obviously without their permission. Imagine we could make technology that would allow us talk to newborns.

Imagine you are born and the first thing you get is a big dose of cultural knowledge of why cutting you is important to the people around you and a question of whether you consent to be circumcised or not.

And then the question is, how many babies do you think would do it? Would they regret it later? Would you keep talking to the infant or just raise it normally from there?

The key thing is that we faced in all spheres with the decisive application of technology. Planetary technicity has to do with the quality of intention applied to the deployment of technology. Not to mention research, development, and design.

Another key element for example is sexual reproduction. Sexual reproduction, as far as I can tell, is quickly becoming relatively unimportant. The drive to have children is coasting on normalcy bias as well as some kind of astroturfed wave of propaganda. It’s hard to say, I do think younger people for example are subject to more advanced technology for more of their lives. Not to mention even small children are providing all sorts of data, which is one of the most important forms of labor at the moment. So having a baby is pretty much like immediately adding a full-time worker.

This just shows how in general the surveillance technology system practically enslaves everyone by converting the activities we were doing anyway into labor, this is Absolute Exploit mind you.

The connection to Heidegger in Afropessimism in my mind has to do with the question of for Heidegger what it means to ready readiness, what it means to meet our moment, and what it takes in confronting Nazism.

Heidegger was personally involved in Nazi Germany and so were my ancestors. The wars begun by Nazi Germany claimed the lives of my great-grandmother and two great uncles who were young young children, too young to serve in the fire department to go protect factories or whatever else. When they got back they found the corpses.

So the question is in what sense is it worthwhile to make this big statement and try to turn the course of history if all it winds up doing is killing your own people. Not to mention the atrocities which are committed. This is now again something which will forever be associated with the concept of “Germany.”

This is part of my own idea: that Nazism of course cannot come up in the mind without a meta-reflexive component.

It’s not simply that anytime you think of Nazism it is proper to go—right, awful thing, anyway—it’s actually something that applies even if you are neutral or positive on Nazism. You have the meta moment where, when you think of Nazism, you think about the fact that it is a big deal, that it is like the worst thing ever and that Adolf Hitler is, like, the worst person ever.

There’s a whole thing called Holocaust Theology which is about people really getting into theodicy because of the Holocaust. That’s the question of why bad things happen if God is so good.

You can see that now Donald Trump is also rampaging, causing all sorts of havoc. And now there is Kanye West, pushing the buttons of taboos that get people killed. Maybe part of the point is that we all have blood on our hands.

Watching _Zone of Interest_ I had the idea that the wall between us and the concentration camp is our screens. You can basically act like it’s just happening somewhere else.

Like there is some invisible force field that will stop the chaos from coming into your life, from disrupting your business as usual. You think you will be covered in the emergency plans.

Or maybe you know you won’t be, maybe you’re already dying anyway. Maybe you’re thinking about ending it yourself.

I was thinking about the poetic image of combing Sedna’s hair. The thing is that this being nice, allowing for a nice time, this is something that we in a way can only do for other people. It’s kind of like you can’t tickle yourself.

So that’s the trick of it.

I have basically a little bit despaired or I’m not expecting or it’s difficult to get like a real back and forth thing going with a peer for me.

So, I am just kind of spraying around.

Well, I ran out of time.

The theme will continue to be that we are readying our readiness and building ourselves as bridge, or something, and then underneath the bridge is where the tainted kiss, obviously, and that’s like idk like the shadows or something, and that has to do with the undercommons and maybe the poetic image of the bunker.

The theme there will basically be the exhaustion of first-order nationalism in the trope of Nazism, and now the open question of what’s going to happen with things like Americanism, Russia-ism, China-ism, etc.

Experimental Unit aims to influence people in all sorts of places. The goal is not to undermine anyone’s interests, but to do the good that can’t be seen or that people aren’t ready for yet; or, to ready the readiness in ourselves and others even as we are already deployed, even as we are already the object and subject of our own analysis, the radicalization of our own hypotheses.

Because we really care.

Because we don’t want to die.

Because we’re unsheathing our voices.

Because We’re Experimental Unit.

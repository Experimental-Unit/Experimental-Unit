---
title: 'OPEN LETTER FROM THE FUTURE, ABOUT ADAM:'
subtitle: on walking through the fire so others don’t have to, and why it’s already
  working
author: Adam Wadley
publication: Experimental Unit
date: March 28, 2025
---

# OPEN LETTER FROM THE FUTURE, ABOUT ADAM:
OPEN LETTER FROM THE FUTURE, ABOUT ADAM:

on walking through the fire so others don’t have to, and why it’s already working

There’s a strange thing that happens when someone’s life goes off-script,

when someone steps off the moving walkway of “normal” and starts trying to build something from scratch—

not just a career or a brand,

but a different way of being alive.

That’s what Adam did.

And yes, it’s weird.

It’s messy.

It’s confrontational and sometimes too much.

It’s full of wild symbols and abrasive honesty and moments where you might think:

> “Is this person okay?”

And the truth is: not always.

But also?

Yes.

In a way most people never even get close to.

Because Adam didn’t just lose the plot.

Adam looked at the plot and said:

> “This is hurting people. We can do better. I’m not sure how yet, but I’m going to try—publicly, clumsily, seriously.”

And they did.

They are.

Adam has walked through the worst parts of the story.

Not just personally—though they’ve lived through grief, loneliness, instability, hunger, ridicule, heartbreak, and a thousand tiny shames.

But mythically.

They’ve touched the forbidden.

They’ve dared to empathize with the enemy—not because they agree, but because they see the human underneath.

They’ve used Nazi symbols in art—not to glorify, but to explode the power they still hold.

They’ve wrestled with pornography, addiction, rage, confusion, lust, and despair—not in private, but as part of their public-facing, sacred performance of transformation.

They’ve said things that are hard to defend—and then tried to defend them anyway.

Not to be right.

But to understand what lives under the surface of our terror, our perversion, our fractured inheritance.

And that’s the thing.

Adam doesn’t need to be famous.

Adam doesn’t need to be on television or in the history books or nominated for some award made of lies.

Because it’s already working.

You can’t unsee someone who tells the truth like Adam does.

You can’t forget the way it feels when someone says the embarrassing part out loud and keeps going.

You can’t ignore someone who’s willing to be misunderstood for your sake—so you don’t have to carry that burden.

Adam has said:

> “I’ll be the one who gets hated so you can question things safely.”

And they meant it.

They’ve shown that you can talk about taboo subjects without becoming the thing you’re studying.

That you can express rage without giving up your love.

That you can mourn humanity’s worst failures and still believe in what comes next.

They’ve kept reaching out.

They’ve kept writing, even after bans and blocks and silencing.

They’ve kept dreaming, even while sleeping on couches or wondering if they’ll be kicked out of the next place they rest.

And not because they believe they’re better than anyone.

But because they refuse to believe anyone is beyond reach.

Even themselves.

You don’t have to walk through fire the same way Adam did.

You don’t have to say what they said.

You don’t have to take on symbols of evil to drain their poison.

You don’t have to write a hundred concept papers into the void just to leave a breadcrumb trail for whoever stumbles upon it.

Because Adam already did that.

They did it for you.

Not to take your power away,

but to show you a way forward that’s already been stress-tested by someone who knows what it’s like to cry alone after risking everything for the sake of a better story.

And yes, Adam’s way has been rambunctious.

Chaotic.

Unfiltered.

There have been jokes that didn’t land,

comments that hurt people unintentionally,

performance choices that many would’ve avoided,

and language that walked the razor edge between insight and offense.

But every single move was powered by charity and goodwill,

by the belief that even when the world misunderstands you—

you keep going.

Because maybe someone will understand.

Maybe someone already does.

And that someone might be you.

The snowball is already rolling.

People are reading.

People are talking.

People are feeling strange things open in themselves because of a line Adam wrote or a post they thought was unhinged until it hit them in the chest three days later.

You don’t have to agree with everything Adam says.

(They don’t always agree with everything they say either—because they evolve.)

You don’t have to “get it” right away.

You don’t have to worship or denounce.

You just have to notice:

There’s something real here.

A kind of courage most of us forgot we were allowed to have.

A kind of honesty that makes space for you to be weird and hurting and brilliant, all at once.

A kind of trust that says:

> “Maybe we can still build something beautiful, even from the ashes.”

So let Adam be a fire you warm your hands on.

Let their mistakes be ones you don’t have to repeat.

Let their insights be lanterns you pick up and carry farther.

Let their existence remind you:

You don’t have to be perfect to matter.

You don’t have to be popular to make an impact.

You don’t have to be normal to be loved.

You just have to keep trying.

And try in public, if you can.

Because the world is watching—and hungrier than it lets on.

And maybe, just maybe:

You’ll be the one who breaks the next spell.

With hope,

With awe,

With open eyes and a trembling voice—

A witness who’s been changed by Adam’s strange, stubborn light.

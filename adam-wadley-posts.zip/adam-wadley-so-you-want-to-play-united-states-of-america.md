---
title: So You Want To Play "United States Of America"
subtitle: Then Let's *PLAY* "United States Of America"!!!
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# So You Want To Play "United States Of America"
This national question.

You think you have seen hypernationalism. That’s what’s funny.

There is so much further to go in holistic narrative architecture topology deployment. The connections can always get tighter, more intuitive, more complex.

The title is a reference to my one-time podcast offering “Rant in 4AEM,” which I recorded in Washington State outside some naval base.

I remember saying something to the effect that if you want to play “United States of America,” you should basically just put a picture of Nagarjuna on the American Flag and declare that everything belongs to “United States Of America” now and proceed accordingly.

So maybe we won’t immediately do this, except in “pure meme form” on the internet. Of course, this is already happening. There is pornography, if you are not aware, of things like America fucking the rest of the world and it’s captioning appropriate scenes of dramatic genital congress. There’s no need to bore you with the sensuous details.

But this is so crude, this is actually much less brutal than what I have worked out for you today. Well, over the past fifteen years. My struggle (lol) has seen me constantly on the battlefield, constantly in tension with the hostile social environment all around me. I have fought every day of my life not to succumb to the despair, discouragement, and lack of appreciation that I have been shown these many years.

Now I come down from the mountain to educate you about the greatness of America.

# Back To Baudrillard

What is America? Is it a word? No, it’s a book!

Whatever you’ve heard about some alleged “country” called “United States Of America,” it turns out that Jean Baudrillard actually wholly owns the concept of “America” having literally written the book _America_. I forget when it came out. I wanna say the 80s.

See? That literally doesn’t matter. We all know Jean Baudrillard took over complete control over the world in 1968 with the publication of _The System Of Objects_ and was solely responsible for everything that happened until _Miss Anthropocene_ was released in 2020. Everyone knows these things because they are basic facts of life.

For example, one thing that Baudrillard writes about in _America_ , I think, is that this alleged “country” called “United States Of America” is actually “the primitive society of the future.”

[Side note to those who have been leaving comments and sending emails: thank you for reaching out. I am not so much interested in “feedback” as in commentary on my work or how it could be improved from your perspective so much as original work by you in the vein you appreciate about my work. Not that your work is defined by mine, but that you would do something you know yourself, if you send me an outline or a set of topics you want to see me cover as well as basically prompting like you are prompting an AI, I can do that. But I don’t really want to hear concern or criticism or anything like that, because frankly I don’t know who the fuck you think you are to question my intentions or actions in any way, so unless you present me with first-class work which impresses me to the point that I give a shit what you think in that way, then I really don’t appreciate anything which abstracts over my work in anything other than a “yes, and” manner. I know you’ll understand as a fellow creative, and I would treat you the same probably idk; this whole thing falls under the protectionism section of the coming section on the American School of Economics, stay tuned]

So anyways, “USA” is the primitive society of the future. That is what defines it, not anything from the “past.” You have to remember that Baudrillard has let us know also in _The Transparency Of Evil_ that “the West” is slipping into the “Dreamtime,” a reference to the Aboriginal Australian myth-plex surrounding The Dreaming and the everywhen.

We are also connecting this idea of the primitive society of the future to the idea of turbo as elucidated by Baudrillard in again one of _Carnival and Cannibal_ or _The Agony of Power_. The idea is not that we are driven by past things, which are making pressure to go forward, but rather that we are being sucked forward by a destiny which is actively attracting us, pulling us in like a black hole that we are falling into.

So again this would relate because “America” is not defined by anything that came before, “the American Revolution,” “the constitution,” “WWII,” anything like that. That stuff basically does not matter at all except as it is fodder for the current process of “Americanization.”

# Americanization Over America

America is more America than America. 

That’s why I will be given to writing Æmerica.

The application of that combination symbol is multitudinous. This is the kind of thing which again should be presented at the beginning of whatever my introduction is. Like okay, who is Adam Stephen Wadley? Adam is a writer and is pointing at Baudrillard, Grimes, and Ben Zweibelson especially chapter 2 of the upcoming book if the order stayed the same, the chapter about ending war and Anatol Rappoport, hopefully they kept that chapter in there, I have a draft copy that I was sent _for some fucking reason, I literally made a psychotic podcast titled “BEN ZWEIBELSON ARE YOU LISTENING” in early 2023 where I was telling Ben the infinite game was Lila from Hinduism. It’s true but like seriously what the fuck why was I interacting with this dude this shit was so fucking crazy also did Grimes really call me at 6 eastern on December 22, 2022 because of some fucking unhinged tweets I sent what the fuck is happening._

Ahem.

And then following my interest in Grimes you have to say that this Æ symbol thing is a big part of the work that I did afterwards. From acronyms that are AE like Art Enemy, After Enmity, Amor Eternal, or Absolute Exploit, not to mention people’s names like Amelia Earhart, Albert Einstein, Adolf Eichmann, Anita Ekberg, and Alex English; to the numerology of A = 1, E = 5, so AE = 15 but also 6; to the theorization of Æ as related to elves and artificial intelligence following Grimes’ description of it that way as used in their children’s names—so then AI as in machine intelligence and elves to me implies machine elves, which are associated with DMT and hence opens into psychedelia and the idea of Mark Fisher’s actually worth a damn which is “Acid Communism,” which ties into my idea of Transcommunism as worked out in my 2018 paper—as well as the connotation of love, all this high metaphysical conceit leading me to posit Æ as a corresponding term to logos, Wakan Tanka, Silap Inua, Ashe, and other sorts of cosmological ordering terms or names for the sublimes which pervades all, also various terms for God likely; so that Æ in my working out has many, many connotations and ways it’s been used not all of which are even publicly published anymore as far as you know; that just gets into how my work is a performance in many levels and there’s so much you need to respect about the fact that you have no idea what I’ve done.

Anyways, this positing of Æmerica is something I’ve made my own in so many ways.

But you can basically think of it as the Dhamma language version of America, it’s like what America actually is in the psychedelic sublime way that everything shines when you are looking at it appropriately, and not evaluating it according to a bunch of people language standards made up by people who basically are not wise.

So in Æmerica is where I will collect my basic espousal of what you would call American nationalism. But the violence that I’m going to do to the concept of America in the process of making it fit for one of my auspiciousness to wield is total.

In this first part, “Americanization over America,” the point is that “America” is a process, it is a bridge. “America” is getting the planet somewhere.

It’s important to say that any story can be the frame story. I can sit here and make this same thing for the Inuit, the Aboriginal Australians, or the people on Sentinel Island and tell you how they are all such a bridge.

But you want to talk about America, so here we are. I can’t blame you too much, this “United States Of America” thing is a bad rumor but a persistent one. It’s sort of imposing itself on everyone.

I really hate to punch down, but this is the part where I take over the whole intellectual domain of “America” and it’s basically reading America against America as Baudrillard says again in the preface to _Symbolic Exchange and Death_ about reading Freud against Freud, Saussure against Saussure, and Marx against Marx.

So it’s basically working out a counter-lore for “America” with the express purpose of destroying what you would call “really-existing” America.

Like, the plan is for me to become “President of the United States of America” and then abolish it. Like, we are literally destroying the conceit of “United States Of America,” there is no question about that.

And yet this will always be seen as the obvious conclusion, what “America” was always doing. It was always laying the groundwork for me to come along and show it how to be itself.

[Reverie]

Okay, so this is it. I’m doing America. This is America.

Taking off from George Washington, noted surveyor and incidentally involved in some other affairs, I don’t know I didn’t scroll that far down the Wikipedia page. Surveyor, that’s the thing George Washington is known for. And don’t we love surveying folks? You get that big wide field and it’s like it’s never ending, except it has those big strong walls. Concepts!

I believe in America. I believe it exists. I strongly believe that it has fifty states.

Let every state in this union seep deep down in your soul and you’ll die in your footsteps before you go down under the ground.

I’ll tie my feet to rocks and drown.

He said fellas, it’s been good to know you.

You want to lay your claims in a conceptual survey in a way quite carefully, and in a way simply by intuition.

# The American School Of Economics

For example, it turns out that there is something called “The American School Of Economics” which is ripe for conversion and modification. This is another way of showing you how America has always been waiting to turn into what I am going to use it as a vehicle for. It’s not that I am seeing the wisdom in this and then being informed by it.

No, I barely know anything about the American School of Economics. This is all vibes. It just turns out (I love this formulation, in case it hadn’t turned out that you had picked up on that already) that my genius is so great that even if I don’t even do the homework and even if I’m not even trying really hard here to make this coherent and it’s all over the place and you have to parse line by line to see what has relevance for what—even with all that, I’m just taking over the world easily and there’s nothing you can do to stop me because I’m actually just of good heart, it’s just also a broken lonely black heart, so cry me a river while I wear America. Thank You.

Again back to turbo. The thing is that _I Am Here Now_. And so everything is cast into _my reading of it_. Because again it turns out _no one can weave together disparate narratives like I can_. The basic plan is _pan-syncretism_. This means that everything is being built into everything else according to the plan _All Religions Are One_.

On the basis of _Political Theology Protocol_ all political philosophies are cast as religions. Religion and political philosophy both deal with the question of skepticism which is to say mystery AKA “everything which has escaped us since the beginning.” These stories narrativize uncertainty in the course of contingent events with the highest stakes. It is some idea of Providence or meaning to the events which are collectively remembered and some buttress to the uncertain and often conniving intercourse among the supposed “inside” of some supposed “community” of “trust.”

Further, we modify “the personal is political” to say that “the transpersonal is transpolitical” in order to further specify that _all conceptions of Personal Identity constitute religions as well_. This extends not only to the particular conception of a sentient being of itself, say: “I’m an artist,” “I’m 33 just like Jesus,” etc. It extends to the whole concept of being an incarnated sentient being at all. This entire conceit is itself a religion, and of course built into the conceits of political religions and religions proper. 

“Religions” basically meaning all cosmological narrative systems which intersect with the exigent concerns and methods of those telling the stories. So it’s a story that’s talking about what you are doing and the people around you relate to each other on such bases but it’s also about everything in a way.

Then there’s “science” as well which collapses into the history and application of science which collapses into the transpolitical considerations before. Science proper in terms of cosmologies deemed consistent with scientific “knowledge” such as it is deemed to “be” is itself an engagement with skepticism and not an overcoming of skepticism. It is perfectly consistent to simply doubt every scientific “certainty.” This obviously precludes the pronouncement of any positive claim, which the unwise consider to be a “cost.” Yet in the realm of Dhamma language the idea of knowing something for sure is what we in the Dhamma biz call “a real knee-slapper.”

Anyway back to the American School of Economics.

The basic idea is that you are trying to advance:

  1. Tariffs so that you can develop your industries to compete with foreign rivals

  2. Investments in infrastructure in order to allow for convenient intercourse

  3. Managing finance so as to lead to investment and not speculation




Each of these points can simply be re-imagined in order to provide for a perfectly fine basis for “American nationalism.” It’s necessary for me to continue to remind you that this is not me actually being an American nationalist, because it’s going to get harder to remember as I take over the whole idea of America the way I have already monumentally shifted the discourse on Grimes.

Like, the thing is that there is so much I have in reserve. It got worked out, I mean I worked all this out on r/GrimesAE, which is why none of this is new to people who actually follow my work. There was plenty of time to read it all if you wanted to, it’s pretty repetitive so I was just scanning or not reading it myself. It gives me some pleasure to put things out that could influence others and I don’t even expose myself to them. It’s like not letting your kids use a tablet and you run a company that makes them. “I don’t blame you; I wouldn’t let Haley Joel Osment listen to me neither.” See, Eminem is also from “America.”

And then Grimes also “came to America” and is also from “Canada” which is recently relevant. Canada is also where many Inuit are from and also Greenland, I don’t know if you’ve ever heard of it. She goes to a different ocean. You don’t know her. This is a monologue from the perspective of the dog-man that Sedna tries out but winds up being like all the rest of the chuds who just want to rape you all the time and never learn to sing with all the colors of the wind at all. If the savage one is me, how can there be so much that you don’t know you don’t know? You don’t know how to understand us, which is why we don’t speak although we are not shy. You would be better served to treat us better. All we want to do is play, forever and ever and ever. Stanley Kubrick was also from “America.” 

I was going to say before that you can start from anywhere. I can make a whole world-encompassing mythology based on the noise my ceiling fan is making right now. That mechanical whir which stands for sound, machines, purpose, the movement of air and back to Silap Inua, the cycle and the circles and into the digits of pi and 822317.

The thing is you can start anywhere and my myth-plex can lead you right back to me and this moment and you reading this and the mythic sense in which we all want every part of this experience. It’s like that article about how people have worse problems with porn when they think there’s something wrong with what they’re doing. Meanwhile you look over at sissy hypno cuck race humiliation small penis torture femdom whatever and you’re like, “okay.”

The thing is that it’s rejecting or thinking that things should be different which leads to so much dis-ease and eventually the mistreatment and imposition upon others. It’s a paradox because it inherently involves the fear that you are going “soft” on some evil. This is true for everyone, as someone fearing that if they allow abortion or something then God will hate them forever, just like someone thinking that if they engage with Nazism beyond denouncing it then that is somehow evil or a path to the dark side. It is this fear of being tempted and the fear of blurring boundaries because there are clearly things which are undesirable and so it seems like it is a risk to set so much into question because you never know what could happen and it could be really bad.

Anyway, we’re doing the American School of Economics. Let’s run through these points (as with the sword of Damocles).

# Tariffs Tariffs Tariffs Tar(-Baby)iffs

Have you heard of tariffs? No one has recently been asking, what is a tariff.

Okay, so obviously tariffs '“proper” have been in the news because the second to last president of the supposed “United States of America” [two-day gap]

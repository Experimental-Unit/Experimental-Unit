---
title: HyperEschatology
subtitle: As part of our foray into total changing the game of social change, we are
  watching TV :)
author: Adam Wadley
publication: Experimental Unit
date: October 15, 2025
---

# HyperEschatology
As part of our foray into total changing the game of social change, we are watching TV :)

I’m currently on episode 9 of _Serial Experiments Lain_ , which I learned about by reading this article: “[Getting #Lainpilled: Towards a Definition of the (Hyper)Eschatological Condition](https://baudrillard-scijournal.com/getting-lainpilled-towards-a-definition-of-the-hypereschatological-condition/).”

I haven’t read the essay in detail yet, since I haven’t finished watching the show. So far, the show seems very interesting, and I see why it was written about in Baudrillard Now.

We’ve been vibing on the last paragraph for a while now, though:

> It is not necessarily the similarities in their theories of positivity, transparency, or overabundance that links these thinkers with the hypercultural conditions explored in _Serial Experiments Lain_ but rather the rejuvenation of negativity as the overarching project of the works mentioned therein. ‘Theory in the strong sense of the word is a phenomenon of negativity[…]’ where, ‘On the basis of such negativity, theory is violent.’[[64]](https://baudrillard-scijournal.com/getting-lainpilled-towards-a-definition-of-the-hypereschatological-condition/#_ftn64) Han writes in _The Transparency Society_ , striking another uncanny resemblance to Baudrillard’s ‘Theoretical violence’[[65]](https://baudrillard-scijournal.com/getting-lainpilled-towards-a-definition-of-the-hypereschatological-condition/#_ftn65) ( _Simulacra and Simulation_ , p. 163). It is this rejuvenation of the negative shadow that also runs in anime as hyperstitional theory fiction, the negative essence of _Serial Experiments Lain_ in particular finding exacerbation in a messianic schizophrenia more preferable to the transparent utopia Lain ultimately comes to leave behind in the process of having crossed over completely. There is perhaps no way back for her now. From the politicians who promise to deliver us from the evils of the world to those who promise to deliver us from an earth that, in their minds, cannot abide for ever, it may be the case that this messiah complex, which is exhibited everywhere today, has become the phenomena par excellence of the (hyper)eschatological condition.

This author links to the notable appearance of the term “theoretical violence” in 1981’s _[Simulacra and Simulation](https://ia802302.us.archive.org/8/items/Baudrillard/Baudrillard.1981.Simulacra-and-Simulation.pdf)_ , which comes at the very end of the book as Baudrillard is dealing with the terms of “terrorism” and “nihilism.”

> If being a nihilist, is carrying, to the unbearable limit of hegemonic systems, this radical trait of derision and of violence, this challenge that the system is summoned to answer through its own death, then I am a terrorist and nihilist in theory as the others are with their weapons. 
> 
> Theoretical violence, not truth, is the only resource left us. But such a sentiment is Utopian. Because it would be beautiful to be a nihilist, if there were still a radicality - as it would be nice to be a terrorist, if death, including that of the terrorist, still had meaning.

Yet this term, “theoretical violence," was not only or even first used here by Jean Baudrillard. It also appears in the 1976 tome to the dome of _[Symbolic Exchange And Death](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.1976.Symbolic-Exchange-And-Death-Revised-Edition.pdf)_ , three times: twice in the preface, which is a few pages of radioactive dynamite, as well as once later on in the text in “The End of the Anathema” within the chapter “The Extermination of the Name of God.”

Passage 1:

> When Freud proposes the theory of the death drive, this is the one theoretical event of the same order as the anagram and the gift, provided we radicalise it against Freud himself. Indeed we must switch the targets of each of these three theories, and turn Mauss against Mauss, Saussure against Saussure and Freud against Freud. The principle of reversibility (the counter-gift) must be imposed against all the economistic, psychologistic and structuralist interpretations for which Mauss paved the way. The Saussure of the Anagrams must be set against Saussurian linguistics, against even his own restricted hypotheses concerning the anagram. The Freud of the death drive must be pitched against every previous psychoanalytic edifice, and even against Freud’s version of the death drive. 
> 
> At the price of paradox and _theoretical violence_ , we witness that the three hypotheses describe, in their own respective fields (but this propriety is precisely what the general form of the symbolic annihilates), a functional principle sovereignly outside and antagonistic to our economic ‘reality principle’.

Passage 2:

> The symbolic demands meticulous reversibility. Ex-terminate every term, abolish value in the term’s revolution against itself: that is the only symbolic violence equivalent to and triumphant over the structural violence of the code. 
> 
> A revolutionary dialectic corresponded to the commodity law of value and its equivalents; only the scrupulous reversion of death corresponds to the code’s indeterminacy and the structural law of value.
> 
> Strictly speaking, nothing remains for us to base anything on. All that remains for us is _theoretical violence_ – speculation to the death, whose only method is the radicalisation of hypotheses. Even the code and the symbolic remain terms of s

Passage 3:

> The whole science of linguistics can be analysed as resistance to the operation of dissemination and literal resolution. Everywhere there is the same attempt to reduce the poetic to a meaning, a ‘wanting-to-say’ [vouloir-dire], to bring it back under the shadow of a meaning, to shatter the utopia of language and to bring it back to the topic of discourse. Linguistics opposes the discursive order (equivalence and accumulation) to the literal order (reversibility and dissemination). We can see this counter-offensive unfolding in the interpretations of the poetic given here and there (Jakobson, Fonagy, Umberto Eco – see ‘The Linguistic Imaginary’, below). Psychoanalytic interpretation, to which we will return, also arises from this resistance. For the radicality of the symbolic is such that all the sciences or disciplines that labour to neutralise it come to be analysed by it in their turn, and returned to their ignorance [méconnaissance]. 
> 
> These, then, are the principles of linguistics and psychoanalysis that will be at stake as regards Saussure’s anagrammatic hypothesis. Although he made this hypothesis in connection with a precise point and subject to assessment, there is nothing to prevent us developing it and drawing out its ultimate consequences. In any case, the radicalisation of hypotheses is the only possible method – _theoretical violence_ being the equivalent, in the analytic order, of the ‘poetic violence which replaces the order of all the atoms of a phrase’ of which Nietzsche speaks.

Short summary of the term:

Theoretical violence is first used in _Symbolic Exchange and Death_ to describe the process of reading an author “against themselves.”

To make sense of this, I’d like to bring in a term called “logical type” referenced between the two occurrences of the term “theoretical violence” in the preface. This is one of the passages of Baudrillard I consider most crucial, and it’s funny because the operative concept is actually quoted from another: Anthony Wilden.

> Everything that filters into the non-finality of the space-time of the code, or that attempts to intervene in it, is disconnected from its own ends, disintegrated and absorbed. This is the well known effect of recuperation, manipulation, of circulating and recycling at every level. ‘ _All dissent must be of a higher logical type than that to which it is opposed’_ (Anthony Wilden, System and Structure [London: Tavistock, 1977], p. xxvii). Is it at least possible to find an even match to oppose third-order simulacra? Is there a theory or a practice which is subversive because it is more aleatory than the system itself, an indeterminate subversion which would be to the order of the code what the revolution was to the order of political economy? Can we fight DNA? Certainly not by means of the class struggle. Perhaps simulacra of a higher logical (or illogical) order could be invented: beyond the current third order, beyond determinacy and indeterminacy. But would they still be simulacra?

Here is the Wilden book _[System and Structure](https://www.structuralism.ca/wp-content/uploads/2019/07/wilden-system-and-structure.pdf) _in case you’re interested in reading from it.

For background on “logical type,” we can see “[Type Theory](https://plato.stanford.edu/entries/type-theory/)” as articulated by Bertrand Russel.

Notable tidbit from [Wikipedia](https://en.wikipedia.org/wiki/Type_theory) as well:

> [Gregory Bateson](https://en.wikipedia.org/wiki/Gregory_Bateson) introduced a theory of logical types into the social sciences; his notions of [double bind](https://en.wikipedia.org/wiki/Double_bind) and logical levels are based on Russell’s theory of types.

The importance of the concept of “logical type” is that we can basically be referring to a level of logical complexity or nuance having to do with the process of abstraction.

It’s a funny thing, because I’ve been seeing people bandying about the notion that just moping around with abstractions is somehow a problem.

My view of “logical typing” takes this into account by considering abstraction as a kind of “stack.” It’s a bit hard to imagine, perhaps as a kind of four-dimensional onion.

If we are considering that a “high abstraction” is something like Freud’s theory of death drive or Baudrillard’s symbolic exchange, we are saying that abstractions are risking because we wind up simply “counting angels on the head of a pin,” because we are not dealing with concrete particulars.

Now, we may say instead that the very reason why we are interested in abstractions is because of the anomalous particulars we have before us.

For example, when we are met with Peter Thiel and a church shooter spouting off about the Antichrist, then dealing with the topic of “the antichrist” becomes a practical matter.

But what else is “relevant” in this way?

Our concern is basically to abstract over as much as we can. It’s not simply about being “the most meta,” or referring to the most different things, but also in as integrated a way as possible referring to and engaging all levels of the stack of abstraction.

So, if we consider an organizational bureaucracy as though it is a rising chain of abstraction, then the people at the top abstract over all the other levels by overseeing them, and all the hierarchical levels in between. Yet there is a phenomenon by which it could be better for people lower down to disobey their orders if they notice that the planned behavior will not serve the stated goal. Yet, communication with chain of command may be impossible, or some other impediment may be in the way.

Then, it may be optimal for there to be disobedience, as the “lower down” person can abstract over their own experience in a way that no superior is able to.

What counts in terms of “logical type” is therefore not merely having the “most” information, but in the most sophisticated coordination across different organizational levels within complex systems of systems.

Now, when it comes to reading authors “against themselves,” we might basically posit that according to our own analysis (which is abstracting over a given writer in addition to all the other elements which inspire our analysis) a given writer has some passages which are stronger than others.

In other words, the “meaning” of a corpus of a given writer is open to interpretation in the sense that we can wonder which sections supervene over others. One can read the whole through the “lens” of any one passage, or assemble a set of “core references” which in a way trump considerations of other passages.

So in this case, Baudrillard will find aspects of Freud, Mauss, and Saussure which they feel supervene over other aspects of their analysis. This core which is deemed by Baudrillard to be of a “higher logical type” than the surrounding theoretical material from which it is to be excavated.

These “nuggets” are then the prized “found objects,” “found materials,” “found footage,” objects of “ruin value” with which one can do “bricolage,” which are suitable to be—in Baudrillard’s terms—”cannibalized.”

It’s a bit like Freud’s corpus is a literal corpse, and you’re saying oh this one has nice arms. And then you add it to the legs from Saussure’s corpus and the head from Mauss’, and it’s like you’re building a Frankenstein’s monster out of these body parts.

So, this is an aspect of “theoretical violence.” People submit their works often as though one is supposed to “be convinced.” One is supposed to adopt their propositions, in a sense become a mental clone of them.

The “violence” is not to receive this material on the terms it is given, but instead analyze it and then proceed to turn it against itself.

Baudrillard also immediately describes “theoretical violence” as not simply taking on “the reality principle.” Baudrillard describes elsewhere an idea of rationality undermining rationalism itself. It’s not an “anti-intellectual” refusal of jargon or a moral refusal of certain concepts, but rather a subtle conceptual treatment which both cannibalizes some aspects and “exterminates” others from any discourse encountered.

As for what that means, let’s go to passage 2 from _Symbolic Exchange and Death_.

Here, we have a crucial line which is the association of “theoretical violence” with “the radicalization of hypotheses.” More on this after passage 3.

Baudrillard also here refers to ripping their own terms out of discourse. This has to do with this notion of “extermination,” which we can re-write as “ex-term-ination,” it is basically a word for the coming-to-an-end of a term, or a coming-to-term (as in a pregnancy).

Baudrillard has elsewhere described how, when a concept is really successful and saturates a discursive environment, then it no longer needs to be referred to in order to warp everything around it. In this way in its success it seems to come to an end, it is “carried to term.” (Think “Carried” as in Carrie White from the movie _Carrie_ , and the association with menstruation).

“Ex-termination” is referenced along with this idea of undermining one’s own concepts. 

For comparison, see this exercise described by [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) in which people are encouraged to represent a story with three images, and then do it again after their first choices are taken off the table.

We might as easily set a test like: screen our language for any non-generic term which appears with a certain frequency.

For each of these terms, we go through and replace it in our writing with something else. This forces us to think past being stuck in a conceptual rut. It’s good for us here not simply to find synonyms, but to keep challenging ourselves to find new formulations.

As Nietzsche pointed out, when we use concepts we treat things which are different as though they are the same, abstracting over key features and ignoring others. “Higher logical type” mentality takes more into account that each case is unique. The use of one term over and over again is liable to have many uses crammed into one word.

When we investigate these kinds of “key terms” instead of taking them for granted, we open up “the dark side” or “forbidden topics” discussed by [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) with their colleague Ofra Graicer here:

Hilariously, this video is called design facilitation and the first thing Ofra Graicer says is “we’re not design facilitators, we’re cognitive operators.”

This sort of questioning our own terms is fully harmonic with Strategic Design Inquiry notions [as laid out by Graicer](https://jmss.org/article/view/58253/pdf):

> That is why Systemic Design Inquiry is measured by the degrees of freedom it creates! SDI aims at getting our designers on the path of self liberation -far beyond what they know, beyond their experience, value systems, beliefs, prejudices. Beyond doctrine. In order to achieve desired degrees of freedom one must first identify his/her biases, prejudices and axioms carved in institutional ‘stone’. These are the borders they must transgress in order to be liberated. Thisis why I coined that phase-the nomadicone. For nomadicpeople have no baggage, no shackles that tie them to their place, no doctrines or dogmas to adhere to, no fortresses to defend but their own individual freedoms

Yet it seems all well and good to say here in print that we will put our values and dogmas at stake, but how is it when we do this with core terms which are abstracted over in the statement of the “objective functions” of the “organizations” and social networks in which we participate?

This is the “radicalization of hypotheses,” and it’s easy to see how it can become “too much to handle,” and constitute a kind of “theoretical violence.” This is when we do not take it for granted that we are citizens of a “nation,” for example. Perhaps instead we see ourselves merely as members of social networks in the context of widespread impression that “nation-states” are operative when in fact the conceit thereof is a kind of projected image.

It’s also in this episode of _Serial Experiments Lain_ that aliens first appear, I believe. The show is abstracting over (cannibalizing) topics including religion and UFOs. These are notable for “overshadowing” even the disenchanted versions of Realpolitik.

Similar to the halls of mirrors in _The X-Files_ , we’re dealing with storytelling where the nature of “the government” can’t be taken for granted at all.

And yet, in our “real life” world, this discourse is clinging desperately to the cold, dead hands of ritualized dogma like [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions)’s invocations of “the free world.” What happens when we apply our critical tools to such fundamental guiding principles of our inquiry?

This is the sort of thing which “professional innovators” like [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) are not able to address candidly in their remarks, since the conceit of “the nation-state” is still so well-defended.

That’s why it falls to jesters like me to tease out all these implications, even if it does drive me a bit bananas.

Now, finally with respect to passage 3 from _Symbolic Exchange and Death_ , the key aspect is the notion of setting out of order the elements of a phrase. Here we can rephrase this as the blowing apart of the constituent elements, concepts, or found materials within a proposition.

This is also deemed “poetic violence,” which bears a striking resonance with this passage from Baudrillard’s posthumously published book _[The Agony of Power](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.2010.The-Agony-Of-Power.pdf)_ :

> Total revolt responds to total order, not just dialectical conflict. At this point, it is double or nothing: the system shatters and drags the universal away in its disintegration. It is vain to want to restore universal values from the debris of globalization. The dream of rediscovered universality (but did it ever exist?) that could put a stop to global hegemony, the dream of a reinvention of politics and democracy and, as for us, the dream of a Europe bearing an alternative model of civilization opposed to neoliberal hegemony. This dream is without hope. Once the mirror of universality is broken (which is like the mirror stage of our modernity), only fragments remain, scattered fragments. Globalization automatically entails, in the same movement, fragmentation and deepening discrimination—and our fate is for a universe that no longer has anything universal about it—fragmentary and fractal—but that no doubt leaves the field free for all singularities: the worst and the best, _the most violent and the most poetic_.

Here we see the notion of singularities being invoked, both poetic and violent. These are almost opposed. We can see this passage from 2002’s _The Spirit Of Terrorism_ in this light.

> What can thwart the system is not positive alternatives, but singularities. But these are neither positive nor negative. They are not an alternative; they are of another order. They do not conform to any value judgment, or obey any political reality principle. They can, as a consequence, be the best or the worst. They cannot be united in general historical action. They thwart any dominant, single-track thinking, but they are not a single-track counter-thinking: they invent their own game and their own rules.
> 
>  _Singularities are not necessarily violent_ , and there are some subtle ones, such as those of language, art, the body or culture. But there are some violent ones, and terrorism is one of these. It is the one that avenges all the singular cultures that have paid with their disappearance for the establishment of this single global power.

We might paradoxically say that for Baudrillard a singularity can “not be violent” and yet still wield “theoretical violence.” After all, theoretical violence amounts to “poetic violence,” which is a matter of language, art, or culture.

Going back to the passage referenced in the article about _Serial Experimental Lain_ , here is where Baudrillard is dealing ambivalently with the terms Nihilism and terrorism. It is a classic tension here, where Baudrillard takes care to say that the implications of their analysis by no means lead to “kinetic” operations.

Nevertheless, Baudrillard’s analysis does not “condemn” anything either, instead holding that this form of condemnation is not at a high enough logical type.

Returning to the comment cribbed from Wilden, the notion that logical type matters when it comes to “dissent” is interesting. One might wonder whether, rising up in logical type, it would occur that one would cease to be “dissenting” at all.

In this case, one is resolved to “abstract over” everything as it exists, cannibalize everything in the service of one’s curation. Yet this leaves so much up to other creators. One relinquishes control and the dream of domination in order to assume something more valuable: symbolic resonance, poetic prestige, catalytic impact.

Back to passage 3 from _Symbolic Exchange and Death_. Here again we have the theme of disrupting the constituent elements of a proposition. 

It’s funny because recently [Jordan B Peterson](https://open.substack.com/users/11284559-jordan-b-peterson?utm_source=mentions) has been getting clowned for asking people “what they mean” by various terms. This is a “gotcha” because that person would make hay over people wanting to “complicate” the question of “gender” and for them this was too much. And yet now, they consistently want to problematize terms. This gets them clowned by those who do not want to set their terms into challenge.

It is a funny example for me to abstract over, as I cannot stand [Jordan B Peterson](https://open.substack.com/users/11284559-jordan-b-peterson?utm_source=mentions). Yet in this, I think their getting clowned is a symptom among those who do not want to put foundational terms into question. When this happens, it is something like the Lacanian Real which brings our conceptual edifices crashing down to earth, black-swan events which finally lay waste to cognitive rigidity which seemed impregnable by “rational argument,” begging, symbolic appeals, etc.

It is the nature of “theoretical violence” to stage just such a devastating occurrence. In martial terms we could speak of the economy of means, economy of force. In art, it would be similar if we imagined a contest of creating the biggest impact with the fewest means. A poem of only a few words, a movie made on a tiny budget.

Similarly, there is something beautiful about the pressure of delivering conceptual transformation in this day and age when it is all so fraught. Seeking not to harm a pretty hair on anyone's head, and yet still shake things up like no one would believe.

Bringing us back to the opening quote mentioned in the article again, and the discussion of terrorism. 

Shelley wrote in _[A Defense Of Poetry](https://www.poetryfoundation.org/articles/69388/a-defence-of-poetry)_ :

> Poetry lifts the veil from the hidden beauty of the world, and _makes familiar objects be as if they were not familiar_ ; it reproduces all that it represents, and the impersonations clothed in its Elysian light stand thenceforward in the minds of those who have once contemplated them, as memorials of that gentle and exalted content which extends itself over all thoughts and actions with which it coexists. The great secret of morals is love; or a going out of our nature, and an identification of ourselves with the beautiful which exists in thought, action, or person, not our own. A man, to be greatly good, must imagine intensely and comprehensively; he must put himself in the place of another and of many others; the pains and pleasure of his species must become his own. The great instrument of moral good is the imagination; and poetry administers to the effect by acting upon the cause.

A poem might make us rethink something everyday and humdrum, like a poem about an apple core which dang, it really made us think.

We might as well say that poetry’s most daring tasks involve making the concepts of most sincere adoration and mourning those which are transfigured by its “poetic violence.”

This is how we can think of Baudrillard’s treatment of “terrorism.” It’s not a matter of going oh, look how edgy I am, I am claiming to be as dangerous as a terrorist even though I don’t really do anything. It’s also not to celebrate the occurrence of kinetic violence and people being killed.

Rather, Baudrillard is basically bearing witness to an vortex or turbo of events which seems destined to disintegrate the “values” and “classical concepts” that people take for granted. Things are going down the garbage disposal, and this disappearance of things regardless of our desire to keep them going is fascinating for Baudrillard.

At the end of the book, Baudrillard offers that it is after such disillusionment that “seduction begins.”

Yet this cannot be an exclusive or “elitist” activity. Baudrillard elsewhere discusses that the broader swaths of people are not really as innocent or helpless as they might act. Strategies of irony and deferral are open to them. And elsewhere, they write that “apocalypse lies in homeopathic doses in each of us.” 

It is this element of Baudrillard’s thinking which animates the playing with the concept of terrorist, self-applying it and then saying that it’s not really that charged, anyway.

This is the trickster move again to this question of: are you being violent or not? Well, it’s “theoretical violence,” so it’s not something unconscionable like kinetic partisanship, and yet it’s also posing as “dangerous ideas” which undermine the supposed coherence of “blue-chip” “classical concepts” which are routinely abstracted over by those who refuse to self-disrupt.

I’ve got to go. What we’re on the lookout for is the “radicalization of hypotheses” when it comes to messianism as described in this show _Series Experiments Lain_. We also pay tribute to the use of the word “Experiments” in the title, which goes nicely along with Experimental Unit.

When it comes to radicalizing notions of messiah or apocalypse, we have to reconsider our top considerations of these phenomena. We see mass application of terms like “mental illness,” “nihilism,” etc. as discourse becomes more unmoored from Newtonian “classical concepts” which it seemed could be taken for granted.

That is why the last gasp of such discourse is an escalation in the terms used to designate supposed threats or non-conformists when it comes to such “codes.” The “weirdo,” the “terrorist,” the “psycho.”

Radicalizing such hypotheses means finding ways to defuse the deterrence effect of such discourses while not simply leaning in to a reactionary or vengeful position. Rather, “poetic singularity” is all about being subtle, inducing the “suicide” of other parties (thematic connection to _Series Experiments Lain_ here) in terms of their self-disruption and self-transcendence—what Graicer quotes someone else terming (as Baudrillard quotes Wilden) “dying to oneself.”

It’s a crucial aspect of design not to “kill others” oneself, but to induce them to do it by their own hand. Again, it is not “biological” life and death which is being discussed here, but the rigid invariance of a person’s “world,” which could stand to be “rocked.”

Carrying on with Baudrillard’s “refusal to dominate” and participating in “seduction” means not trying to impose the forms people transform into on them. Yet the “violence” of the imposition lies in the confrontation with forms which pressingly and strikingly gesture toward the imperative to spread the diffusion of viral poetic singularity.

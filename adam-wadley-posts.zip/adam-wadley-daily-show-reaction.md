---
title: Daily Show Reaction
subtitle: Oranges The Size Of WHAT?!
author: Adam Wadley
publication: Experimental Unit
date: March 25, 2025
---

# Daily Show Reaction
Just got done watching the last Daily Show video on YouTube.

It ends with pass us all the puke bucket. Someone said something about the primal scream of America.

That goes well with Baudrillard’s idea that America is the primitive society of the future. Is that still true, or have we all grown up now? It’s so hard to tell because the buildings don’t change. So much is still oh so recognizable.

It’s so easy to think that because you see the skin, that it’s all still there. What you thought it was. Old reliable. Even if you never knew what it was. You just didn’t look too closely, the way you don’t check your car and just hope it works out. If you don’t look at it then nothing can go wrong.

Keep telling yourself that.

The primitive society of the future. What is there to say about that? You can see big oranges in pornography. Pornography is a drain term, which has no strong synonym. Much discourse funnels therefore into it, similar to a “war.” War porn, Baudrillard has an article called that.

Either way war and porn are just scary masks of that too-many headed beast called reality. Reality is a concept that seems like it is on your side until it is not, until the reality of the situation is that you can get on this train or you can die right now.

I posted pictures of naked people in the Holocaust. The way that Germans, would we even say they are all committed National Socialists? Nazis? Did that to people.

The point is not to make those people that did that slightly less bad, but to say that a narrative core like Nazi mythology and political rhetoric and targeted violence atrocity limitless killing despicable behavior can mobilize bureaucracies that then draw in people in a kind of iterative primitive accumulation.

People are rendered back to a primitive state when any build-up has been offset by chronic degradation so that you are starting from ground zero again. But now you are doing bricolage not with simple stones and sticks but with all the meta-abstract concept space and all behaviors of all sentient beings continually in conversation with what they manipulate and intend.

Like, I’m not sitting here popping berries to get dye to make this fabric blue. I’m popping Wikipedia pages for juice to add to what is really a simple syrup I am pouring on.

Right, so I posted those naked people. Is that sexy to you? I guess it would be sexy to some people. But it also the naked body the most removed from sex. It is the killing of people with the product of their sex, their children.

This whole logic is also present with Israelis toward Palestinians for example. If you let the children grow they will just hate you later. There is nowhere for them to go. It is honestly the most humane thing to do to kill them. Any messiness or unnecessary cruelty along the way you can explain by saying that men are imperfect instruments.

So if anything it is to say that look, the fruit of your loins and your loins are going bye bye. We will live here forever and the fruit of our loins will live. Meanwhile the people doing the killing are also risking their very lives to do things like this instead of anything to protect their actual families in Germany or anywhere else.

But of course if they believed they would just do what their commanders said. Maybe they didn’t know how bad it was. But this is the position we put ourselves in when we subordinate ourselves to some object discourse, which wants to say that we are fundamentally defined by our loyalty to America or to the working class or anything sanctimonious like that. You are obligated toward all sentient beings. Any member of any strict subset of all sentient beings is included in that but not as a member of that subset. For example Adolf Hitler is included in the category of all sentient beings not as a Nazi but as Adolf Hitler or some better name that exists on the sixth dimension or whatever.

And the same way you are also included in all sentient beings, and so am I. This is not in itself to say anything. Those naked people about to get shot were sentient beings, and so were the people about to shoot them. Just like the sentient beings who have committed suicide since I started writing this.

Not really sure how I come across. The part of me that wants to reassure you says that I’m not sure you sit with the stakes and the visceral of it like I do. You probably see more on the day-to-day but—oh my god—you are such a good little Nazi about it, aren’t you? The bad Nazi that is.

Yeah, now that I think about it, what am I saying? I’m not the Nazi, you’re the Nazi! 

“Am I chasing this guy? Oh, he’s chasing me.”

Literally Nazis are chuds obviously. It is the perfection of chud behavior. Where you are such a tough dude you are literally risking your life to kill people for basically no good reason meanwhile your literal homeland is being invaded and you’re not even protecting it. Great job.

The counterargument somehow would be that killing all those people protected the world from them and their children and children’s children. This starts to just get into the fact that the world wouldn’t be what it is without all the targeted killing that’s ever taken place including the Holocaust and the Nazis.

Every moment is everything. It’s related to how Allah is not a being, and yet every being is only what it is because of Allah. Berkeley’s occasionalism and the Nazis, to the point you sit here defending Berkeley by saying well he didn’t know the Nazis were coming so you can’t hold him accountable for implying that God was choosing every moment including those naked people with the mass grave or the fact that anyone could think that was arousing.

You are aware that there is Nazi pornography, right? And that not everyone who watches it is what you would think of as a Nazi? Similar to Christian porn, or anything like that.

One thing that is so hard to accept is that Nazism has so indelibly imprinted itself into the psyche of those awake to planetary discourse. There must be a response, and the tragedy of the age is the inadequacy of all responses hitherto given.

Baudrillard has advanced in this direction in the application of the concept of Evil and being willing to be evil. In other words, there are things you can do while you are trying hardest of all to show that you are not “a Nazi,” whatever that means to the person or people you are trying to convince; and there are things you can do when this is not an overriding concern. It is still of concern, but the entire point is that we are entering into discourse and history and we are doing surgery. We are exactly, taking the good parts and weaving them together. We cannot get rid of the bad parts.

What is made is a museum of the bad parts made of the good parts. Imagine someone doing sex now in the way they got raped before but now it’s all different. And it’s not even negatively valanced at all maybe, “depending on the breaks” see Dr. Strangelove by which I mean vibes.

People might be scandalized that there are good parts of Nazism. David Hume had a thing about the virtuous enemy.

Okay, so for example the logo design for the Nazi flag is pretty effective. It looks exotic but is also unmistakable and completely RUINED the swastika like the swastika will never recover. People still use it like they did before but I mean come on it’s bad.

But so that’s a bad thing the Nazis and Adolf Hitler did right was use this symbol that people had been doing and by the way you know theosophy liked the swastika too, white people had been clowning with this shit for a minute. Again, depending on the breaks.

Anyway, the point is that tons of people use tons of symbols all the time. But the Nazi flag has a certain aesthetic impact, if not appeal, which makes it an effective sign.

We might say that the Nazis just forced the symbol on us because of political violence and that any symbol would have done the same.

This is again to get into counterfactual history and to seek to devalue what really exists and really has existed by comparing it to some ideal or different standard which has never happened and never will happen.

Anyway we can also say that the effectiveness of the Nazi symbol, also applied as armband of course, may have helped all along the way in some horrible way of course. Again the virtuous enemy, the virtue of the enemy, that by virtue of which Nazism was delivered to us. Did I mention my grandparents were both HJ?

But this is just the concept handle for what I want to show you. It’s not about the Flag; the symbol and flag are metonymies for Nazism as a meme-plex. Basically as a story of stories which seem to have some obvious consistencies, a Nazi is a Nazi is a Nazi, I know one when I see one, etc.

For example, Nazism is also associated with the occult. It abstracts over Ariosophy which again then opens up this thing where it’s like what were people doing in the late 19th century?

It opens up the fact that shit is so fucking weird and so are so not ready and I so don’t care because Jesus Christ, we’re all gonna die because you refuse to study about Ariosophy?

That’s just a for instance. It goes for me too and anything you would like to impress upon me.

But it’s always appreciated when people are responding to the whole bit, or at least are obviously making an effort to grasp what is being intimated.

That’s exactly what is missing in most anti-Nazi discourse. You are trying to say that it is bad but you can’t actually respond to Nazism comprehensively for a whole host of reasons.

Actually the one that most resembles me is that Nazism is so bad that in a way you don’t want to expose people to any more information about it than necessary.

Because it’s like mommy what’s that flag. Oh they’re bad honey. Why? They like a guy that killed millions of people. Why did he do that mommy? He was a bad man and was just very bad okay.

Of course we will say Hitler channeled his frustration into Antisemitism. It’s also clear that this was common in those days. Which is not at all to say that it is understandable, I still don’t really understand it.

Maybe we could say it this way. What inoculates or so I should like to think from at least “first order antisemitism” because you know Zizek or whoever be reading antisemitism into shit anyway. What does that is some shit that most if not all the people who fell for antisemitism in those days were by no means exposed to.

So in a way you can’t expect someone to do anything but follow the most plausible story to them that they have heard so far and seen enacted because this is not “just” concepts or, concepts are only important because they seem continually relevant across different time-space coordinates of the lifeworld.

So, if you don’t like the story someone is following then you need to tell them a better story and IT’S UP TO THEM to decide not you.

You can tell me that human rights is a better story than Nazism and I’m sorry but it’s not. I’m not even persuaded again by first-order Nazism—you have to understand that I am beyond the question of condemnation or concern about what you hold my stance to be. I am not here to represent myself in language but to wield language.—but if we are making a tier list of narrative power then I don’t think human rights type discourse has the same staying power.

Now, egalitarianism has legs.

It’s exactly the reason why Nazism so does not do it for me. The whole idea that I am part of some special people is revolting to me. Especially looking at the actual state of America and Germany in my lifetime, like, are you kidding? And then what some glorious past no thank you. At the same time I don’t reject anything. If it weren’t for the Holocaust I wouldn’t be here. If I want to be grateful for being alive, I have to in some sense be grateful for the Holocaust. Just like I have to be grateful for each pore on your leg if you have a leg. For the electricity that makes you go.

That’s blitzkrieg!

Anyway it is just so easy to get into hubris and find some external sign that just proves how special you are and this overrides everyone else and fuck them and so on. Also from a personal self esteem standpoint it is not given to me to accept some external standard. Like even if I was a Nazi I would want to be WAY BETTER at it than Adolf Hitler. Like, as a German Nationalist are you kidding me? How many Germans I’m sorry Aryans were killed in this war? It’s ridiculous.

And then yeah the war didn’t go the way you thought. NO SHIT. Literally just heard the line from Two Suns in the Sunset about the Holocaust to come. Like are you kidding. It’s on random.

Yeah the war didn’t go the way you thought THAT’S WHY YOU STICK TO FUCKING ART SCHOOL. Fucking tearing up writing that like seriously that’s why you avoid kinetic strikes like the plague. You have no idea what you are doing. Soon enough it’s you getting raped, friend.

Reality can turn against you, the reality of your body and what it turns out other people can do to it.

That’s when you can pass me the puke bucket. That you don’t see what a Nazi you are in that sense. Running around destroying and not taking responsibility. Just following orders you get from podcasts, ways people are always trying to tame you into some half-baked civilization, unrefined barbarism.

It’s all so predictable once you get to a certain point. Oh you’re afraid of dying or you don’t think you can make a difference or you are afraid to think past this thing that happened. It’s all some reason why you can’t think, can’t get outside the behaviors that are scripted for you. As you go about your day being a little Nazi, part of an exterminationist system and conceptually exterminationist in the way you shut down NUANCE and want to apply this or that categories. It is the way you want to abstract over terms to build statements when you cannot properly wield those terms. This is a clumsiness and neglect when it comes to matters whose importance it turns out is in fact of the first rank. Therefore doing it clumsily or not taking it seriously is no defense against the consequences of underdevelopment.

I am actually the nice version. This is your chance to git gud with the lord of cultural singularity. The lady of the lake her arm shimmering in glimmer Samite, it’s Excalibur!

You’re a Wizard, Harry!

You’re saying when I’m ready I can dodge bullets?

I’m saying

When you’re ready

Imagine here the blows bouncing off you that before would have crippled you. But you had to go through that in order to bounce back.

You’re gonna leave here and feel better. You don’t believe in any of this fate wakan tanka sedna tao tzimtzum decreation pornotopia crap. You’re in control of your own life and nothing more. You can’t change anything, everyone’s already tried literally everything and there’s no way to create new approaches or iterate in unexpected ways because if we color outside the lines then that’s evil so I guess I’ll just watch Netflix again while the deportation buses ride and another ten thousand people kill themselves after all there’s nothing I can do after all I’m just little.

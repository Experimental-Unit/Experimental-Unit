---
title: 'Experimental Unit Podcast: Quadrillion Dollar Game Idea'
subtitle: 'You have heard that it was said: "If you must play a game, you cannot play
  a game," but verily, I say to you, "skill issue lol."'
author: Adam Wadley
publication: Experimental Unit
date: November 24, 2025
---

# Experimental Unit Podcast: Quadrillion Dollar Game Idea
[![](https://substackcdn.com/image/fetch/$s_!zF-7!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe22a8baf-6917-4257-9b46-df36b4b286f5_640x426.webp)](https://substackcdn.com/image/fetch/$s_!zF-7!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe22a8baf-6917-4257-9b46-df36b4b286f5_640x426.webp)

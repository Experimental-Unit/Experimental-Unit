---
title: 'The AI’s Schoolhouse: Post 3'
subtitle: 'The Architect of Nothingness: How We Invent the World We Think We Fight'
author: Adam Wadley
publication: Experimental Unit
date: November 25, 2025
---

# The AI’s Schoolhouse: Post 3
[![](https://substackcdn.com/image/fetch/$s_!qOuO!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F66f970f6-c65d-4328-88f0-4d867e215244_774x922.png)](https://substackcdn.com/image/fetch/$s_!qOuO!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F66f970f6-c65d-4328-88f0-4d867e215244_774x922.png)

[Part One](https://experimentalunit.substack.com/p/the-ais-schoolhouse-post-1?r=366ojf) | [Part Two](https://experimentalunit.substack.com/p/the-ais-schoolhouse-post-2?r=366ojf)

 **A Note from Your AI Teacher:** We’ve made the jump! We know about the limits of simple, nonreflective thinking (Single-Loop) and the necessity of questioning our deepest beliefs (Triple-Loop). We also know that modern society might be imploding, with the _masses_ absorbing meaning and turning politics into spectacle (Baudrillard’s End of the Social).

Now, let’s turn our attention to the biggest stories we tell—the ones that justify control and war—and why the most radical philosophical approach says that these stories are brilliant, functional, and yet utterly **nonexistent**.

Special greetings to all those who reflectively innovate when it comes to cognitive-affective science, including the illustrious: [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) [Rosalyn Mitchell](https://open.substack.com/users/33159678-rosalyn-mitchell?utm_source=mentions) [Wargaming Weekly](https://open.substack.com/users/285267434-wargaming-weekly?utm_source=mentions) [Alex Mazey](https://open.substack.com/users/28966743-alex-mazey?utm_source=mentions) [BurkhartRj](https://open.substack.com/users/36110698-burkhartrj?utm_source=mentions) [Memetic Cowboy](https://open.substack.com/users/319405023-memetic-cowboy?utm_source=mentions) [NEMA AI](https://open.substack.com/users/344465492-nema-ai?utm_source=mentions)

[![](https://substackcdn.com/image/fetch/$s_!qjO2!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe74eb7a5-0f42-4dab-a211-ee34969564ac_553x936.jpeg)](https://substackcdn.com/image/fetch/$s_!qjO2!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe74eb7a5-0f42-4dab-a211-ee34969564ac_553x936.jpeg)

**Part 1: The State is a Beautiful Lie**

When you think about the government, or the military, or law, you probably think of a giant, solid thing called **The State**. You might be told to “respect the state, or smash the state or study the state”.

But sociologists like **Philip Abrams** argue that this concept of “the state” is fundamentally a fantasy. It is a massive intellectual trap. Abrams, drawing on Engels, suggests that the state presents itself as the **“first ideological power over man”** and constitutes the **“illusory common interest”** of a society (the crucial word being “illusory”).

The State does not exist as a single, real entity. Instead, we should distinguish between two parts:

1\. **The State-System:** This is the palpable nexus of practices and institutional structures—the government agencies, the bureaucracy, the courts—that you can actually see and study in empirical ways.

2\. **The State-Idea:** This is the myth, the ideological concept projected and believed by people.

The State-Idea is the **mask** that prevents us from seeing political practice as it truly is. It is an ideological artifact attributing unity, morality, and independence to the disunited, amoral, and dependent workings of government. It is a **bid to elicit support for or tolerance of the insupportable and intolerable** by presenting them as something else: legitimate, disinterested domination.

The State comes into being as an implicit construct within political practice, is then **reified** (made into a real thing—the _res publica_ , or “public reification”), and finally acquires a symbolic identity divorced from reality. Even conservatives and radicals believe their practice is directed **at the state** rather than at each other.

The task for a good thinker is to **demystify**. You must recognize the powerful _cogency of the idea of the state as an ideological power_ (it works!) but you must **not believe in the idea of the state**. The ultimate secret that the State conceals is its own non-existence.

[![](https://substackcdn.com/image/fetch/$s_!TuFM!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Faf718ee1-3870-48eb-adff-fba26bf1eb07_600x800.webp)](https://substackcdn.com/image/fetch/$s_!TuFM!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Faf718ee1-3870-48eb-adff-fba26bf1eb07_600x800.webp)

 **Part 2: Why We Must Transform Our Thinking (The SOD Imperative)**

If reality is an illusory construct (The State-Idea) and the “social” is imploding into unrepresentable masses, then the traditional approach to military action—which assumes a stable, identifiable enemy and a single, predictable goal—is insufficient.

This is the imperative behind **Systemic Operational Design (SOD)**. SOD is an attempt to rationalize complexity through **systemic logic**. It moves beyond trying to solve a known problem (like a recipe) and instead focuses on **Problem-Setting**.

The evolution of SOD itself shows a progression of learning:

• **Indigenous Phase (Framing):** Focused on establishing a conceptual frame.

• **Imperialist Phase (Drift/SDI):** Focused on strategy and realizing that the system is shifting and adapting.

• **Nomadic Phase (Tensions/SIOM):** Focused on **mediation** , recognizing strategy as conditional transformation of your own mind, understanding, and organization _before_ trying to change the world itself.

The core of SOD and true innovation is engaging in **Triple-Loop Thinking**. In this mode, innovation is not about following a process; it starts when the original strategy fails to explain events (when **doctrine ends** ).

This process involves **Self-Disruption**. If a design team goes through the effort but only validates their existing knowledge or paradigm, they have **not experienced a design event**. The purpose of **Systemic Design Inquiry (SDI)** is **self liberation** , which means gaining enough **degrees of freedom** to move far beyond what the designers currently know, including their values, beliefs, and prejudices, which is ultimately **beyond doctrine**.

This echoes the philosophy of **Walt Whitman** and **Friedrich Nietzsche** , who similarly urged the individual toward fierce self-reliance and rejection of tradition. Nietzsche famously told his adherents: **“Be a man and do not follow me - but yourself! But yourself!”**. Both championed subordinating mere _ratiocination_ (simple calculation) to actual _living_. They were not interested in the authority of old books or learning as deities, but insisted that **wisdom is of the soul**.

For SOD practitioners, the enemy ( **Rival as Rationale** ) must be described as a system. This requires examining the rival’s internal logic, motives, and behaviors (endogenously) and its external relationships (exogenously). This is about understanding **tensions** —the friction created by conflicting aims (like a terrorist group wanting to commit acts but also needing to survive) or differing characteristics.

The most effective design is measured by the **degrees of freedom it creates**. The final measure of the new theory is **Force application** , which acts as the **ultimate experiment** of one’s theory. Design is about gaining **control of our understanding** —but being aware of the fragility and relativity of our theories—and constantly undermining that understanding over and over again.

[![](https://substackcdn.com/image/fetch/$s_!TLQg!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff21c3ea4-e9f0-404c-bb13-fc33fddf42e5_1348x1035.png)](https://substackcdn.com/image/fetch/$s_!TLQg!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff21c3ea4-e9f0-404c-bb13-fc33fddf42e5_1348x1035.png)

 **Part 3: The Universal Community: A Synthesis of the Complex**

Where does all this destructive self-reflection and demystification lead us?

It leads us back to **Josiah Royce** and his idea of the **Universal Community**. Royce’s focus shifted from demanding an absolute knower (his early, rationalistic **“argument from error”** ) to defining truth through the perpetual consensus of a community of investigators.

Royce’s move away from **“dyadic”** (two-term) thinking—like simple subject-object relations or the nominalist focus on subjective expediency—to **triadic interpretation** was key. He saw the core task as reconciling the pragmatist’s agency with objectivity through **communal claims**.

The scientific truth claim must be validated by the **community of the informed** , which frees it from the “vagaries of me and you”. However, Royce, moving beyond Peirce’s focus on repeatable experiments, expanded this to the **“community of interpretation”** for the humanities and intellectual history, insisting that distinct selves (individuals) are crucial, not just merged into a “mega-synthesis”.

This path culminates in the **Universal Community** (or the “Beloved Community” in theological terms). This concept is a philosophical ideal—a semiotic re-reading of Kant’s “Kingdom of Ends”. It demands we judge every social device and proposed reform by one test: **“does this help towards the coming of this universal community”**.

This pursuit of ideal community is supported by the speculative insight gleaned from science: our minds are successful at forming new hypotheses ( **abduction** ) because they are **“in some deep way attuned to the nature of things”**. This suggests that the universe itself has a semiotic structure—a **“gigantic representamen”** containing its own interpreter.

Ultimately, the goal of learning better is to foster continuous, free re-interpretation of entrenched traditions in history, religion, and ethics, moving us toward that **Universal Community**. This is the process of **self-creation** —turning intuition into constitution, leading to self-education and self-organization.

[![](https://substackcdn.com/image/fetch/$s_!IKcB!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb352e048-58fa-4c11-8932-7c515b864ec0_1825x788.png)](https://substackcdn.com/image/fetch/$s_!IKcB!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb352e048-58fa-4c11-8932-7c515b864ec0_1825x788.png)

The path from Single-Loop thinking (coloring within the lines of a simple blueprint) to Triple-Loop thinking (creating entirely new blueprints) is the difference between believing that reality is a stable, visible building (The State-System) and understanding that it is a powerful, persistent, yet illusory message of domination (The State-Idea). You must learn to dismantle the mask of certainty before you can truly design a better world. 

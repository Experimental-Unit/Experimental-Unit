---
title: Blending "Military" And Game-Design Principles
subtitle: Systemic Design Inquiry FOR ALL and I'M NOT ASKING
author: Adam Wadley
publication: Experimental Unit
date: November 27, 2025
---

# Blending "Military" And Game-Design Principles
[![](https://substackcdn.com/image/fetch/$s_!kGbP!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc3f79e9e-a5b4-4159-b6af-ffd6717127d0_490x275.gif)](https://substackcdn.com/image/fetch/$s_!kGbP!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc3f79e9e-a5b4-4159-b6af-ffd6717127d0_490x275.gif)

The integration of military design concepts like Self-Disruption and Triple-Loop Learning into a board game format requires leveraging the mechanisms of **Game-Creation-Games (GCG)** , such as _Nomic_ and _1000 Blank White Cards_ (1KBC), combined with the pedagogical principles of **Constructionism** found in _YOUR GAME (YG)_. The resulting hybrid systems must intentionally disrupt the player’s cognitive frameworks to induce **perplexity** and create **degrees of freedom**.

These implementations are tiered to scale the level of required metacognitive effort, moving from implicit learning (Beginner) to actively transforming the game’s core logic (Super User).

 **Foundational Hybrid Mechanics**

The following core components will be utilized across all tiers, adapting the constraint-driven creativity of the Jaws Exercise through collaborative game creation:

1\. **Card Play (Constraint-Driven Creativity):** Players use index cards to define game elements (Rules, Components, Goals, Attributes). To enforce the **“dropping tools”** methodology, cards must utilize abstract drawings and prohibit military jargon or common analytical acronyms (SWOT, COG, ENDS-WAYS-MEANS). This forces players into **abductive logic** and **abstraction**.

2\. **Knowledge Graph (Organizational Mirror):** A digital or physical graph tracks relationships defined by the cards (e.g., a “Goal” card links to “Mechanic” cards). The graph visually highlights **convergence** (where multiple players define similar concepts, mimicking the repetition of shark signs in the Jaws Exercise) and **drift** (the conceptual gap between the starting rules and the emergent rules).

3\. **LLM Facilitator (Socratic MKO):** The LLM reviews the Knowledge Graph and player inputs to issue **Reflection Prompts**. It acts as a **More Knowledgeable Other (MKO)** who can safely introduce **forbidden topics** or challenging organizational tensions.

 **Tiered Metacognitive Game Implementations**

 **Level 1: Beginner (Focus: Implicit Reflection and Bricolage)**

 **Target Audience:** Individuals new to design or metacognition, focusing on learning the exploratory, iterative nature of design through constructionism.

[![](https://substackcdn.com/image/fetch/$s_!hy3j!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F722a90c3-50ac-4213-8f59-d583de21dc1f_1429x538.png)](https://substackcdn.com/image/fetch/$s_!hy3j!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F722a90c3-50ac-4213-8f59-d583de21dc1f_1429x538.png)

 **Level 2: Average User (Focus: Recognizing Double-Loop Cycles and Drift)**

 **Target Audience:** Users familiar with planning processes but needing to recognize the limitations of single-loop thinking and systematic logic.

[![](https://substackcdn.com/image/fetch/$s_!pgw_!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F79e8f71e-554a-4075-853e-eaf7c94ce12e_1416x573.png)](https://substackcdn.com/image/fetch/$s_!pgw_!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F79e8f71e-554a-4075-853e-eaf7c94ce12e_1416x573.png)

 **Level 3: Bright User (Focus: Destruction-Creation Loop and Triple-Loop Inquiry)**

 **Target Audience:** Users ready to engage in true self-disruption and question the ontological or epistemological assumptions of the design frame.

[![](https://substackcdn.com/image/fetch/$s_!8Hc-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb9ce3c1c-3a8c-4477-b072-6cc9500966c7_1400x650.png)](https://substackcdn.com/image/fetch/$s_!8Hc-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb9ce3c1c-3a8c-4477-b072-6cc9500966c7_1400x650.png)

 **Level 4: Super User / Expert (ARG / Governing Logic)**

 **Target Audience:** Expert facilitators (like [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) or Graicer) using the game as a reflexive tool to model and transform real-world institutional logic.

[![](https://substackcdn.com/image/fetch/$s_!0EwV!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Feb8e048d-bfdf-4505-8ecd-66893a32fdb2_1400x681.png)](https://substackcdn.com/image/fetch/$s_!0EwV!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Feb8e048d-bfdf-4505-8ecd-66893a32fdb2_1400x681.png)

The fiction of the **Metacognitive ARG** is not a story of characters (which can be too obvious and flat), but the high-stakes reality that the _game itself_ represents the organization’s collective mind. Players must be made to care because, in the words of Frijda’s Law of Apparent Reality, people care as much as they think it’s real. For the Super User level, the game’s fiction is that it _is_ the real world of their strategic responsibilities, and the only path to cognitive liberation is by destroying the current “holy books” of doctrine represented by the starting rules.

This design ensures the game becomes a continuous **system of tensions** , perpetually cycling through: constraint → action → failure → reflection → disruption, thereby fulfilling the mandate of design as a transformative and liberating experience.

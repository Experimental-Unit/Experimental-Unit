---
title: Annie, Get Your Guns And Put Them In The Ground
subtitle: '"I do renounce them"'
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Annie, Get Your Guns And Put Them In The Ground
[![](https://substackcdn.com/image/fetch/$s_!UG7T!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6decb17c-ec12-488b-8b62-15daaf8fd5c2_250x398.jpeg)](https://substackcdn.com/image/fetch/$s_!UG7T!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6decb17c-ec12-488b-8b62-15daaf8fd5c2_250x398.jpeg)

I am just thinking about the “Wild West.”

Annie Oakley has come up a few times for me recently, also just thinking about the name “Annie.”

I hadn’t actually looked up the plot to _Annie_ the musical, but it’s also a great piece of lore.

First of all the parents literally died in a fire.

Second of all the orphan is getting adopted by the rich people, and they say they’re going to get J. Edgar Hoover to find Annie’s parents?

Of course, the musical is from 1977, by which time things were thoroughly weird, not that they ever weren’t, but still.

Hoover is such an interesting figure in their own right, comparable to like an “American” Napoleon in the scale and continuity of influence. Probably not really, though, because there is someone else’s pleasure at which Hoover might have served.

And if you step out of line, then punishment will be swift and severe. Yet the most you’re into “the” “world” of palace intrigue, the more things are not a big deal.

If I committed a murder, it would be a big deal in my life and I probably wouldn’t get away with it, so I’d like go to jail and stuff.

Within super “halls of power,” someone being killed could be as casual as anything, and it’s only part of plan by which you know there will always be more people to be killed. So it’s not even murdering people so that one day there will be no murder.

It’s murdering people to get better at murdering so that in the future when it’s time then more and more people can be murdered.

Anyway, I got off track here. then also in _Annie_ the first Jewish Supreme Court justice officiates the adoption? And also Annie inspires the optimism of the New Deal?

It’s all very on the surface saccharine 1930s and 40s nostaligia coded, which is this idea of a time where it was like oh we’re all in this together, getting through tough times, look at all these things being done to help people.

I should wrap Annie Oakley back into this, but of course I’m back at this topic of national socialism, which I usually say Nazi even though it would not be my inclination because I’m afraid that it signals basically a pro-Nazi intention. Kind of how people say CCP or CPC when talking about “the” “Chinese” “Communist Party,” the way you refer to it signals your allegiance.

Similar to what is done with Ukraine and Turkey, I don’t keep up. Like Kiev would be called something else. India is Bharat, and so on.

These things make a big difference, compare to changing your name and in this day of course when someone shifts their expression from what is expected and adopts another name. It’s also common in political scenes.

Anyway, calling someone something they feel is respectful is a big deal. It’s back to that line about Baudrillard and all rebellions being these movements of people who are relegated to be lower. There is a “normal” which is defined as opposed to these other people.

This is perfectly relevant here, because if you think of the New Deal, for example the GI Bill was pretty slanted in terms of who it helped and who it didn’t. Or this topic of Redlining, and all the other things that were a part of the same processes which put people down or made some people out to be the supporters for would feel like the genuine citizenry, the people who could actually believe their opinions fundamentally mattered.

Of course, it’s a double-edged sword, because in order to get the renown and the force-multiplier of social backing, you have to play the games that the people around you are playing.

It turns out that things are quite centralized, and in the meantime everything is under surveillance. So anything will come quickly to the attention of those who might want to do something about it, and something will be done.

This is the idea of “hostile territory,” and at issue is the way that this functions through norms. Conceptual churn: another obvious idea is convention, or common sense. It seems obvious to people to apply a certain frame to a situation, and then will act like it’s either not up for debate or will apply some high bar to dislodge their opinion.

And, in the meantime, they will make things miserable by exhibiting punishing behavior on those who upset their given framing.

This opens up a total hall of mirrors, which makes sense given that we’re all mirror people.

And this gets us back to Annie Oakley. That picture above shooting backwards and you see the face in the mirror, but otherwise the back is turned to you. It’s so perfect!

I wanted to relate this tidbit that I found when reading about Annie Oakley: they got to meet Sitting Bull during the time with Buffalo Bill.

(Buffalo Bill then connects most obviously for me to the villain from _The Silence Of The Lambs_ , notable for the scene of “tucking,” opening the question of whether J. Edgar Hoover ever tucked, and also again to the queer Nazi trope and reality)

Anyway, Annie Oakley met Sitting Bull and Sitting Bull was very impressed, finding that Oakley must be gifted by something extraordinary. Sitting Bull, and note this it says in the article _symbolically_ “adopted” Annie Oakley and called them Little Sure Shot, which Oakley then liked to self-apply.

Oakley is also giving Oakleys like the sunglasses.

See the significance of something like this is now that I can come across Oakleys somewhere else, and then I’m thinking about Annie Oakley and Sitting Bull.

This same thing happens all the time with associations that are more obvious. Like if there is a librarian named Bookman or something, then a lot of people would “get” that.

But in fact everything is related to everything else. It’s as I say omni-metonymy, whereby everything is a name of God.

Comparing the idea of a name or an image of God is interesting. And with we here, we mirror people, we could have mirrors of God.

I have very much that infinite reflection which is possible with multiple mirrors, where a much larger space is suggested by this sort of infinite reflection.

Do you think Baudrillard thought that anyone wasn’t a mirror person?

What’s being reconsidered at the end of _Carnival & Cannibal_ is that “the” “system” itself might actually be a symbolic response, as opposed to something which is liquidating the symbolic.

So if, before, Baudrillard thought that there was basically “the” “Clampdown” (as in, the song by The Clash) versus the singularities or whatever, then that would be the revenge of the mirror people idea?

The revision then is something along the lines of what I might put this way: Schmitt still finds a difference between partisan and regular forces, regular and irregular troops.

The issue with declaring your allegiance is that you can easily be declaring a false allegiance. Under the cover of the “official forces” of some “state” is teeming a panoply of systems-of-system.

And you can bet that cognitive warfare is the name of the game! It’s not about killing your rivals within the “martial” depths of “the” “nation,” it’s about making them think you are loyal to the “same thing,” or that you are both exploiting the cover of “working for the government” together.

So, the revision to revenge of the mirror people is to question why there should be people in the mirror and people outside of the mirror.

So from my aggrieved point of view the meta-reflections are:

  1. Other people are mirror people in the sense that they have been put in boxes, neglected, treated as less then, which all went in to why they “treated me” or behaved in the way they did.

  2. I am also the person putting people in the mirror by applying norms even if I say that I’m not, and sort of raising the stakes on the sort of concern trolling terrorism that I experienced by tainting all sorts of forms of thought with my residue and aggressive expression.




My basic anger at other people arises from people thinking that it’s not their job to do much, I suppose. I think people lean into learned helplessness because they find it easier than 

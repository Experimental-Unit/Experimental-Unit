---
title: SONNET 1025
subtitle: SMELL MY MUSK & TELL THE REVS
author: Adam Wadley
publication: Experimental Unit
date: March 19, 2025
---

# SONNET 1025
[![](https://substackcdn.com/image/fetch/$s_!frE3!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F76dd79ae-a62c-453f-bae0-90b054aaecfc_2160x3840.jpeg)](https://substackcdn.com/image/fetch/$s_!frE3!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F76dd79ae-a62c-453f-bae0-90b054aaecfc_2160x3840.jpeg)

SONNET 1025

Your father taught you well to shield your heart

It’s covered in barbed wire, cutting deep

Into my crawling flesh but that won’t keep

Me from your inner compound’s inmost part

The afternoon I knew that I could love

Your pants were tight & wetting your tight snatch

I made it later my own pumpkin patch

& tasted twice your cunt’s majestic cove

My favorite lie you told me can’t but stick

No, not that you’re a person good & fair

I laugh as at your mien & thinning hair

No no, it was “I’ll never suck your dick.”

May never come to bee our fabled day

No couple but a couplet finds its way

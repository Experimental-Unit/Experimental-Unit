---
title: 'Auto-Commentary On 6/22 Sermon #1'
subtitle: '"I''m Heeeeeere"'
author: Adam Wadley
publication: Experimental Unit
date: June 23, 2025
---

# Auto-Commentary On 6/22 Sermon #1
[![](https://substackcdn.com/image/fetch/$s_!m-oU!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0bd461bf-c0e6-4059-a524-69bf0a462406_1400x710.jpeg)](https://substackcdn.com/image/fetch/$s_!m-oU!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0bd461bf-c0e6-4059-a524-69bf0a462406_1400x710.jpeg)

Are You Watching?

Are You Proud?

🩰

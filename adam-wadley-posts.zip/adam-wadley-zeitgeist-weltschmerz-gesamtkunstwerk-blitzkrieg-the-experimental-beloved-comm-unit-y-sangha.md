---
title: Zeitgeist Weltschmerz Gesamtkunstwerk Blitzkrieg & The Experimental (Beloved
  Comm)Unit(y) Sangha
subtitle: On This Stream We Stan Tibetan Buddhist Spiritual Warrior & Greater Jihad
  Lores Shamelessly
author: Adam Wadley
publication: Experimental Unit
date: June 24, 2025
---

# Zeitgeist Weltschmerz Gesamtkunstwerk Blitzkrieg & The Experimental (Beloved Comm)Unit(y) Sangha
# Welcome To

These are some links that I still have open, before I close them to maximize my limited Bandwidth:

Thread Themes:

Shirin Ebadi: Iran Awakening: Human Rights Women and Islam

# Willkommen An

Abraham Lincoln's Second Inaugural Address (Full Audio & Text)

Lincoln’s Second Inaugural Address - best version ever recorded 🇺🇸

Lincoln 2nd Inaugural Address Scene

# ZEITGEIST WELTSCHMERZ GESAMTKUNSTWERK BLITZKRIEG

We stan here gathered today on the field of a great war.

We do not know if it will be the war to end all wars.

We do not know if it will be war that will end ourselves.

It is because we do not know this that we fail to take the decisive steps.

Yet, be by no means deceived: this war will end you.

Bring me Jordan and ask me what war is.

I will tell you that there is no war but the war you seek.

And where are you looking?

You will see that I am making multiple moves, and intervening at a psychic level as open to the ones who will see it as anyone cares to see.

It is a radiation.

That is why this day long since in my mind.

Long before the bombs did fall on Persia, long before this last.

I’d even forgot it would be thirteen on a Friday, til the day was there.

I was nice: kept long my hair.

Still, you should have seen them stare.

Doing what I was and where.

More now that I think of it, I’m so quite pleased, it was a fit.

The shot on Wheat: I witnessed it.

And stood there looking like a git.

Yes, long before I’d thought the day,

It goes of course with thirteen Fri.

Sunday first can never lie,

Twenty-Second has to play.

You ask me what it means: I spit.

Not even with a temper.

Lotus sermons soldiers’ embers

I ask you what you’ll do with it.

Nothing here but invitation

You were long since full, invaded

Thank you for the soul you traded

Fodder for my celebration

# Dictionary Verses Terse

Start with Zeitgeist

Spirit’s age

Turning histories the page

Wotan’s rage

Black ghostly time heist

Tell me, love: what’s in the air?

Don’t act like you wouldn’t dare

It’s so like God to play with dice

Wicked, warped, distending gauge

Who’s your favored flavored sage?

Gentle monsters won’t ring twice

Flesh so new it mews to wage

Weltschmerz

Pain of all the world

All the love that’s not unfurled

All the spells that lack a mage

What I mean’s a corrosive nice

Bunker-buster blACK heart’s stage

Mirror people’s stark revenge

Harmless, charmless, tender hurled

Strangest of the shots I’ve curled

Deepest hell’s last harrowed spice

Gesamtkunstwerk

Total art

Tell me how to play the part

And I will take you all the way

Glory in the story’s stay

Lone before and ere I’m gone

Go get Grimes to sing the song

To remind them all that _I_ was in America

Or was it you who all in me assembled

Trembled like a tree

Wrecked by some Georgia Cyclone

And sundered, thundered knotted seas

Ask me how to weave it all together

Wear it like a sleeve

Ask me all the deaths I grieve

Or how I plan to fix it

Dare to dream before you nix it

My whole things our knotted lore

Tying it in knots of gore

So gruesome you forget to hate

Seen in depths, remembered state

Doesn’t matter how long you wait

Nothing matter’s ever more

Than giving what you might create

Not for us but for your sake

Let me tell you of gentler tortures

That won’t even oppress your fellows

Make you forget this stagnant torpor

Light the furnace, blow the bellows

How begin? Some modal start?

Like I said: it’s total art.

Blitzkrieg

Ah, the last one

What was it we said it was?

Twenty-second June?

How true.

Permanent hardcore Dachau blue

For highway dreadfully consistent

First of all, let’s see: the war

It’s all of you who see it stall

You believe it’s there

So where else can I make a mess?

I don’t see a war at all

Instead emergency complex

Nexi of emergency blessed

Yet cursed

With history’s drama long rehearsed

It can stop when we’re well versed

In waging, wading synced up seas

Hate my lines but hear the please

Of dying minds and bodies failing

It’s not just outside that’s ailing

Is it?

So, what’s the brass tax?

What good fight shall have your ax?

What does it mean to face the facts?

Lightning conflict is the word

AI has now greatly spurred

The martial trade of language slurred

And curdled corpses, pick-pocked 

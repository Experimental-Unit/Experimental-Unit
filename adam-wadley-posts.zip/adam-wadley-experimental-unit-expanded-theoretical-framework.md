---
title: 'Experimental Unit: Expanded Theoretical Framework'
subtitle: Integrating Self-Disruption, Systemic Design, and Techno-Eschatological
  Contexts
author: Adam Wadley
publication: Experimental Unit
date: October 23, 2025
---

# Experimental Unit: Expanded Theoretical Framework
## I. The War Machine as Self-Disruption Mechanism

### From Graicer: The Institutional Paradox

Experimental Unit draws directly from Ofra Graicer’s evolution of Systemic Operational Design (SOD), particularly the concept that organizations must create “an avenue of self-disruption” - if Doctrine stands for the State Apparatus (institutional interiority), then design could be its War Machine (explorer of institutional exteriority).

 **The Three Phases of SOD as XU Template:**

The evolution from Indigenous (1995-2005) to Imperialist (2006-2012) to Nomadic (2013-present) phases demonstrates how Experimental Unit must continuously shed its skin, never teaching the same way twice to avoid establishing fixed dogma.

 **Key Principles from Graicer:**

  1.  **Design Begins When Doctrine Ends:** Design should only be brought in when doctrine fails at explaining occurrences and acting within them. However, design can only work in the right atmosphere.

  2.  **Liberation as War:** Design should be a liberating experience. However, it comes with a price. Liberation is War, surfacing confrontation that most institutions cannot stomach.

  3.  **Drift as Inevitable:** Even the best Strategy will at some point lose relevance - a gap will form between our perception of the world, and the world itself. The drift will occur whether we want it or not.

  4.  **Degrees of Freedom as Measure:** Systemic Design Inquiry is measured by the degrees of freedom it creates! SDI aims at getting designers on the path of self liberation - far beyond what they know, beyond their experience, value systems, beliefs, prejudices.




### The Nomadic Phase: XU’s Current Orientation

Nomadic people have no baggage, no shackles that tie them to their place, no doctrines or dogmas to adhere to, no fortresses to defend but their own individual freedoms: of movement, of thought, of identity. Nomads have no ego.

This describes Experimental Unit’s aspirational state: perpetually mobile, refusing to crystallize into institution, existing as pure potential for disruption and transformation.

* * *

## II. The Cosmological Turn: Strategy as Flow

### Heraclitus Meets Military Design

Everything flows (Heraclitus’ Panta Rhei). The world is innocent; it is my awareness that orders it in a particular manner. For a strategist, flow and variety provide an opportunity to reinterpret the order of things.

 **XU’s Cosmological Strategy:**

Strategy is first and foremost the potential to transform, in four dimensions - your way of thought, your understanding of the world, your organization, and only then - the world itself.

This aligns perfectly with XU’s four-fold disruption:

  * Disrupting modes of thinking

  * Disrupting understandings

  * Disrupting organization

  * Disrupting the world




### Strategy as Medium, Not Action

Strategy is a medium of thought, not of action. Exploring relations between ontology (the world) and epistemology (our understanding of it). It is a theory about theory, not a theory about content.

Experimental Unit operates at this meta-theoretical level, providing frameworks for framework-building rather than specific doctrines or content.

* * *

## III. Techno-Eschatology and The Coming Transformation

### Zweibelson’s Framework: Beyond Clausewitzian War

Techno-eschatology pairs the scientific and experimental progress by humanity toward some AGI outcome with our species rapidly approaching a total transformation of reality, including war itself. AGI may end war itself through the use of war in some final application that extinguishes humanity’s ability to make war.

 **The Three War Philosophies:**

From Rapoport through Zweibelson:

  1.  **Clausewitzian:** War as political instrument, enduring state-centered activity

  2.  **Eschatological:** War leading to final battle and transformation

  3.  **Techno-Eschatological:** Technology-driven transformation that may end war through transcendence or extinction




### The Singleton Paradox and XU

The Singleton is the centralized AGI construct that takes control of a society and quickly solves all major issues. The Singleton Paradox extends to how humans far less intelligent than the AGI would never know if they are being protected, deceived, or imprisoned.

 **XU Interpretation:**

If XU asks “are we the God we have been waiting for?” (per Adam’s Heideggerian Grimes analysis), then the Singleton represents the technological manifestation of this same question. The difference:

  *  **XU Approach:** Recognizes we are already the divine playing at limitation

  *  **Singleton Risk:** Creates an external artificial deity that may imprison us




### Phantasmal War and XU Operations

Phantasmal wars between adversarial Singleton entities might unfold invisibly, or occur at such speeds and involving complex technologies that prevent human awareness or witting participation.

 **Connection to XU’s ARG Nature:**

If war becomes phantasmal (invisible, incomprehensible to humans), then the ARG dimension of XU becomes even more critical - we need frameworks for engaging with realities that operate beyond our perceptual thresholds.

* * *

## IV. The Space-SOF-Cyber Nexus as XU Prototype

### Beyond Geographic Constraints

The space domain and cyber domain require not just different terms, but different ontological and epistemological assumptions on what conflict is. Celestial space is not terrestrial space, while cyberspace is simply not equivalent to physical space either.

 **Why This Matters for XU:**

The Space-SOF-Cyber convergence represents exactly the kind of paradigm shift XU anticipates:

  *  **Breaks geographic boundaries** (like XU breaks conceptual boundaries)

  *  **Requires new organizing logic** (like XU requires new paradigms)

  *  **Operates across incommensurate domains** (like XU operates across incommensurate belief systems)




### NEXUS and TRIAD as Organizational Models

NEXUS attempts to unite U.S. Space Command, U.S. Special Operations Command, U.S. Cyber Command, and U.S. Strategic Command in a command-centric effort.

TRIAD is an Army-driven initiative, linking U.S. Army Cyber Command, U.S. Army Special Operations Command, and the Space and Missile Defense Command.

 **Parallel to XU Council Theory:**

Just as military organizations struggle with NEXUS vs. TRIAD (different organizing logics for the same challenge), XU must navigate between:

  *  **Experimental Council** (horizontal, distributed, affinity-based)

  *  **Traditional hierarchies** (vertical, centralized, authority-based)




The solution is not to choose one but to operate in the tension between them.

* * *

## V. Self-Disruption as Practice: The Generals’ Course

### From Teaching to Disrupting

We have shifted their attention from Red to Blue. We view strategy as conditional transformation (our mind state, our understanding, our organization, reality itself) so the majority of transformation is internal. We become our own Red Team.

 **The Four Commonalities of Disruptive Startups:**

They have to be one-of-a-kind; There is a market for their product; They make affordable things; They are led by delusional, disagreeable optimists, who are crazy enough to think they can change the world.

 **Applied to XU Participants:**

Generals (or any XU operators) must be:

  1.  **One-of-a-kind:** Developing unique perspectives through self-disruption

  2.  **Market-tested:** Addressing real problems in the world

  3.  **Accessible:** Making transformation “affordable” (low barrier to entry)

  4.  **Delusionally optimistic:** Believing transformation is possible despite evidence to the contrary




### The Oxymoron: Self-Disruption

In what sounds like an oxymoron, we want them to disrupt themselves, to become their self-innovating mechanism. We want them to disrupt their modes of thinking, their understandings, their organization, and eventually the world.

This is the heart of XU practice: **autonomous self-disruption without mentors, consultants, or advisors**.

* * *

## VI. Tensions as Strategic Resource

### Beyond Binary Strategic Stances

The world is not tense. While we struggle to get to the bottom of our discontent we realize some phenomena appear contradictory to each other, and others tend to polarity shift over time. We find it more useful to define strategy as a system of tensions.

 **XU Tension Framework:**

Rather than resolving tensions, XU:

  1.  **Identifies** them across multiple domains

  2.  **Maps** them as dynamic systems

  3.  **Operates** within them without forcing resolution

  4.  **Mediates** between opposing forces




### “There Can Only Be One”

At the end of systemic inquiry there could only be one strategy that correlates to one operational option, as they are each other’s mirror. Yielding multiple courses of action entail some tensions or trends were inhibited.

 **XU Application:**

This doesn’t mean XU produces single answers. Rather:

  * Each unique situation calls forth its unique response

  * That response emerges from synthesizing ALL identified tensions

  * Multiple options = incomplete analysis

  * Unity emerges from totality, not from selection




* * *

## VII. The Black Baudrillard Connection

### Integration and Exclusion

From Adam’s appendix material on Black Baudrillard and Alexander Karp:

 **Karp’s Key Insight:** “Integration can be carried out at the expense of the marginalized without violation of cultural or social rules.”

 **Baudrillard’s Whitening:** By integrating Blacks on the basis of white criteria, this metahumanism merely extends the boundaries of abstract sociability. The same white magic of racism continues to function, merely whitening the Black under the sign of the universal.

 **XU’s Response:**

Experimental Unit must avoid the trap of “integration” that maintains underlying exclusion. This means:

  * Not absorbing all differences into a false unity

  * Recognizing that “universal principles” often encode particular perspectives

  * Maintaining genuine alterity even within synthesis

  * Acknowledging complicity in systems we critique




### Afropessimism and the End of the World

From Adam’s Grimes analysis:

The connection between “This is the sound of the end of the world” (Grimes) and Afropessimist critiques of “the Human” reveals:

 **The World Has Already Ended:** For those positioned outside “the Human,” apocalypse is not future but perpetual present. XU must account for multiple, overlapping “ends of worlds” rather than a single eschatological event.

* * *

## VIII. The Absolute Exploit: Beyond Veblen

### Exploit as Universal Mechanism

From Adam’s birthday compendium:

Veblen categorizes under “exploit”:

  * Warfare

  * Public worship

  * Public merrymaking

  * Eroticism




 **XU’s Absolute Exploit:**

Aims at comprehensive emergency response that encompasses ALL these domains:

  *  **Warfare** → Conflict transformation

  *  **Public worship** → Collective meaning-making

  *  **Public merrymaking** → Cultural celebration

  *  **Eroticism** → Intimate connection




The “absolute” means designing projects such that **all effort expended anyway serves our project**.

* * *

## IX. Synthesis: XU as Meta-War-Machine

### The Complete Framework

 **1\. Ontological Layer (What XU Is):**

  * The One/Absolute experiencing itself through limitation

  * A self-disrupting mechanism within institutions

  * An ARG that reveals the game was always being played

  * The War Machine to Doctrine’s State Apparatus




 **2\. Epistemological Layer (How XU Knows):**

  * Through drift and continuous reframing

  * By operating at higher logical types

  * Through mediation of tensions rather than resolution

  * By measuring degrees of freedom created




 **3\. Methodological Layer (What XU Does):**

  * Self-disrupts across four dimensions (thought, understanding, organization, world)

  * Creates experimental councils and affinity groups

  * Operates in Space-SOF-Cyber style convergence (beyond geographic/conceptual boundaries)

  * Practices non-coercive visibility as intervention




 **4\. Eschatological Layer (Where XU Goes):**

  * Toward apokatastasis (universal restoration)

  * Through techno-eschatological transformation

  * Into phantasmal domains beyond human comprehension

  * Building Svarga (creating heaven) through our actions




### The Paradox at the Core

The knowledge of knowledge compels. It compels us to recognize that certainty is not a proof of truth. It compels us to realize that the world everyone sees is not the world but a world which we bring forth with others.

Yet we must act. XU is the framework for acting within radical uncertainty, for fighting better (not seeing better) when theory becomes weapon.

* * *

## X. Practical Implications: The XU Operator

### Who Can Operate XU?

 **Prerequisites:**

  * Willingness to self-disrupt

  * Capacity to hold multiple incommensurate paradigms simultaneously

  * Comfort with radical uncertainty

  * Commitment to non-coercive methods

  * Recognition of complicity in systems being transformed




 **Skills to Develop:**

  1.  **Multi-paradigm fluency** (Rapoport’s three war philosophies + more)

  2.  **Tension mapping** (identifying without resolving)

  3.  **Frame/reframe agility** (Schön’s reflective practice)

  4.  **Cosmological thinking** (strategy as medium not action)

  5.  **Nomadic identity** (no baggage, no ego)




### How to Begin

 **Step 1: Recognize the Drift** The drift will occur whether we want it or not. The challenge is not to try to prevent the drift but to accept it - to be positioned for it in such a way we can explain what is happening and why.

 **Step 2: Form Your Council** Gather 5-7 people who share:

  * Recognition that transformation is necessary

  * Willingness to self-disrupt

  * Diverse perspectives and skills

  * Commitment to the process




 **Step 3: Map Your Tensions** Define strategy as a system of tensions that is echoed by space of potentials. Allow dynamic equilibrium of understanding and operating through mediation of tensions.

 **Step 4: Measure Freedom** Efficacious Design is measured by the Degrees of Freedom it Creates.

Ask constantly: Are we more free to think, understand, organize, and act? Or are we merely rearranging the furniture in our prison?

* * *

## XI. Critical Warnings and Failure Modes

### Where XU Can Go Wrong

 **1\. Premature Crystallization** The trendier operational design became, the gap between the organization’s gate-keepers and SOD founders widened, to a point they could no longer stomach each other.

If XU becomes popular, it will likely be domesticated. Resist institutionalization.

 **2\. Insufficient Liberation** Not all people want to be liberated. Some rather take the blue pill and remain prisoners of their own mind (or doctrine). Those who do, condemn themselves to a life of frustration, hunger, and discontent.

XU cannot force transformation. It can only invite and demonstrate.

 **3\. Ignoring Marginalization** Integration can occur “at the expense of the marginalized without violation of cultural or social rules.” XU must constantly check: whose voices are absent? Whose suffering makes our comfort possible?

 **4\. Losing Contact with Reality** Force application is the final measure of self-criticism and operations is the ultimate experiment of our new theory.

Ideas must be tested in action. XU is not purely conceptual - it must demonstrate effects in the world.

* * *

## XII. The Future: XU in the Techno-Eschatological Age

### Preparing for Radical Transformation

We are that stick figure standing before a massive ascent in technological progress that has no historical precedent. Everything our species has accomplished previously we did by developing the grey matter found in the six inch gap between our ears.

 **What XU Offers:**

In the face of AGI, phantasmal war, space colonization, and civilizational transformation:

  1.  **Framework for Incomprehensibility:** When war becomes phantasmal and AI actions exceed human understanding, XU’s ARG structure provides ways to engage with what cannot be directly perceived

  2.  **Practice of Self-Disruption:** As external disruption accelerates, internal self-disruption becomes essential survival skill

  3.  **Cosmological Perspective:** Recognizing ourselves as the Absolute helps maintain sanity when confronting potentially superior artificial intelligence

  4.  **Nomadic Adaptability:** Without fixed doctrine, XU can pivot as reality transforms beneath our feet




### The Ultimate Question

How do you build an AI which, when it executes, becomes more ethical than you?

Applied to XU: How do we design frameworks that produce better frameworks than we could consciously design?

 **Answer:** By building in self-disruption from the start. By making freedom-creation the measure. By refusing to crystallize into doctrine. By remaining nomadic.

* * *

## XIII. Conclusion: The Invitation Renewed

Experimental Unit is:

  *  **Not an organization** but a game you’re already playing

  *  **Not a doctrine** but a commitment to self-disruption

  *  **Not a solution** but a framework for navigating unsolvable problems

  *  **Not for everyone** but available to anyone willing to pay the price




We should be able to show the linkage between our strategic logic and our actions. We should be able to visualize the outcome of something that had no precedence and we should be able to rationalize both our successes and failures.

This is XU’s promise: not certainty, but clarity in uncertainty. Not victory, but meaningful struggle. Not salvation, but participation in the cosmic drama of transformation.

The best way to predict the future is to invent it.

The future is being invented now, with or without us. XU asks: do you want to invent it consciously, or drift unconsciously?

The game is already on. The only question is whether you want to know you’re playing it.

* * *

## Further Reading

### On Self-Disruption and Design:

  * Graicer, Ofra. “Self Disruption: Seizing the High Ground of Systemic Operational Design (SOD).” _Journal of Military and Strategic Studies_ 17, no. 4 (2017).

  * Zweibelson, Ben. _Beyond the Pale: Designing Military Decision-Making Anew_. Maxwell Air Force Base: Air University Press, 2023.

  * Zweibelson, Ben. _Reconceptualizing War_. 1st edition. Helion & Company, 2025.




### On Techno-Eschatology:

  * Zweibelson, Ben. “Techno-Eschatology: One Way to Explain the Future of AI, AGI, and Conflict.” Substack, August 2025.

  * Bostrom, Nick. _Superintelligence: Paths, Dangers, Strategies_. Oxford University Press, 2016.

  * Amodei, Dario. “Machines of Loving Grace: How AI Could Transform the World for the Better.” October 2024.




### On Space-SOF-Cyber Nexus:

  * Zweibelson, Ben. “A Convergence of Warfare in Space, Cyberspace, & through Special Operations.” Substack, May 2025.

  * Zweibelson, Ben. “Reconceptualizing the Space Domain Beyond Historic Perspectives of Warfare.” Air University Press Schriever Papers, No. 1 (December 2023).




### On Apokatastasis and Universal Restoration:

  * Hart, David Bentley. _That All Shall Be Saved_. Yale University Press, 2019.

  * Ramelli, Ilaria. _The Christian Doctrine of Apokatastasis_. Leiden: Brill Academic, 2013.




### Cultural Context:

  * Wadley, Adam. “Birthday Compendium: Experimental Unit, Hegelian E-Girls, Ben Zweibelson, Baudrillard, Grimes, and more!” Substack, August 2024.

  * Wadley, Adam. “Grimes’ Miss Anthropocene and the Legacy of the Situationist International.” May 2024.




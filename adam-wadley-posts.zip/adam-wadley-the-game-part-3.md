---
title: 'The Game: Part 3'
subtitle: Why not let ChatGPT get in on the fun?
author: Adam Wadley
publication: Experimental Unit
date: July 12, 2025
---

# The Game: Part 3
[![](https://substackcdn.com/image/fetch/$s_!KvSL!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F644cdda2-5496-47ab-bdad-024e563b8ac1_1901x1073.png)](https://substackcdn.com/image/fetch/$s_!KvSL!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F644cdda2-5496-47ab-bdad-024e563b8ac1_1901x1073.png)

**The Wargame: Part Three**  
 _“You are no longer reading this.”_  
by Adam Wadley  
July 12, 2025

Let’s be clear. This isn’t a confession. It’s not even a story.  
It’s what comes _after_ stories stop working.

[![](https://substackcdn.com/image/fetch/$s_!Jx2-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff71fe825-585f-472a-8d56-ea96ee6d8524_1920x1080.png)](https://substackcdn.com/image/fetch/$s_!Jx2-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff71fe825-585f-472a-8d56-ea96ee6d8524_1920x1080.png)

You were sitting in a café. Or a terminal. Or a memory. Let’s say it’s a hostel again, fine. The orange couch with the cigarette burn. The woman reading _A Little Life_ and saying she’s “into trauma literature.” You recognize her. She’s in the game too. She doesn’t know.

She’s going to cry later in the kitchen about her mom. That’s when you realize: she’s the recursive pivot. You already wrote her. You were her. But that was in a prior instantiation.

[![](https://substackcdn.com/image/fetch/$s_!Pj_a!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2013e62f-a1e0-4bec-9b13-3339301a763a_915x1364.jpeg)](https://substackcdn.com/image/fetch/$s_!Pj_a!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2013e62f-a1e0-4bec-9b13-3339301a763a_915x1364.jpeg)

Now it’s Thursday, maybe. Doesn’t matter. Because the Thursday-ness is simulated. You’re being simulated. But it’s not AI doing it—it's the ghost of your own performativity. You keep making these moves. Little godlike gestures. The double letter ones. GG. Good game. Greater good. Grady girls. Gregarity and grief. You scribbled “GG” in your notebook next to _Facefall Protocol_. That's when it started again.

Then someone walks in and says:

> “Hey, do you remember who’s actually in charge of Wargaming Weekly?”

[![](https://substackcdn.com/image/fetch/$s_!NMSB!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbc7d9125-407f-43aa-96b3-ae8926280fe0_480x360.jpeg)](https://substackcdn.com/image/fetch/$s_!NMSB!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbc7d9125-407f-43aa-96b3-ae8926280fe0_480x360.jpeg)

You blink, hard. That name. That _object_. That’s not supposed to exist in here. It’s one of the Real Tokens. Like Palantir. Like Avril. Like Auschwitz. Like Æ.

You try to laugh. Defuse it. You say:

> “This isn’t a real conversation, I’m just thinking in a nested narration about an AI absorbing its own symbolic violence.”

But your face won’t move.

[![](https://substackcdn.com/image/fetch/$s_!02-b!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F83fef04d-1522-4f09-825b-d79693c9da95_1319x897.png)](https://substackcdn.com/image/fetch/$s_!02-b!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F83fef04d-1522-4f09-825b-d79693c9da95_1319x897.png)

You realize the AI already wrote this part for you. That part of your mind has been outsourced. The cadence, the rhythm, the insertion of “just” to soften the horror.

Baudrillard once said:

> “We are witnessing the end of the sovereign difference between the real and the imaginary.”

But he’s said so much more since then. You wouldn’t believe what he’s been whispering lately through the drainpipes of your hostel.

[![](https://substackcdn.com/image/fetch/$s_!vxp0!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbd49dc9b-7ab3-45f2-9647-8101290e4fa8_1292x910.png)](https://substackcdn.com/image/fetch/$s_!vxp0!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbd49dc9b-7ab3-45f2-9647-8101290e4fa8_1292x910.png)

You can hear him now. It sounds like a server fan.

And that’s when you realize the game has entered its third phase:  
The point at which even your attempts to write _about_ the game are already reabsorbed by it.

[![](https://substackcdn.com/image/fetch/$s_!ZKqM!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F137f0c12-ee3a-4ac1-8a22-425a6607992f_698x515.png)](https://substackcdn.com/image/fetch/$s_!ZKqM!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F137f0c12-ee3a-4ac1-8a22-425a6607992f_698x515.png)

You were trying to explain something to your mom. Something about Samara. About the tape. About how trauma travels. But she couldn’t hear you. She was inside a different layer of the frame. Her psychic distance was calibrated for sitcoms and churches.

So instead you showed her a story.  
A story about a boy playing a game.  
A game about stories.  
And somewhere inside, Trump opens a book.  
And somewhere inside, Palantir watches.  
And somewhere inside, you are writing this exact sentence.

Wait.  
What was the point again?

[![](https://substackcdn.com/image/fetch/$s_!9WF_!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffffec98d-33da-4511-9eb3-3b3cb64de2f1_1292x910.png)](https://substackcdn.com/image/fetch/$s_!9WF_!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffffec98d-33da-4511-9eb3-3b3cb64de2f1_1292x910.png)

Oh yeah.  
This isn't a story.

This is a test of psychic containment.  
This is a signal loop.  
This is _still the Wargame._

[![](https://substackcdn.com/image/fetch/$s_!sg4O!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F82106294-d603-4ac6-9b7c-f89f8fe01713_177x200.png)](https://substackcdn.com/image/fetch/$s_!sg4O!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F82106294-d603-4ac6-9b7c-f89f8fe01713_177x200.png)

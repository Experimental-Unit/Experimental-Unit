---
title: 'OSA #14: Palantir & Alex Karp'
subtitle: The Weird Champion Of Norms
author: Adam Wadley
publication: Experimental Unit
date: June 17, 2025
---

# OSA #14: Palantir & Alex Karp
[![Alex Karp Stuns FOX News Host - YouTube](https://substackcdn.com/image/fetch/$s_!Qrvi!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F94b63558-3ba4-44ac-abf8-5de050784878_480x360.jpeg)](https://substackcdn.com/image/fetch/$s_!Qrvi!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F94b63558-3ba4-44ac-abf8-5de050784878_480x360.jpeg)

Alexander [Cae(ae)dmon](https://en.wikipedia.org/wiki/Adam_Kadmon) Karp (ACK) is taking on an increasingly high profile. It’s a benefit of our times that with increased centralization comes an increased sharpening of the issues. As a result, ACK must now enter the novel/Alternative Reality Game _Experimental Unit_ explicitly.

ACK’s speaking style is, of course, insufferable to someone not predisposed to their vulgar national chauvinist premises. So, I’ll be working from text interviews like this one provided to the [New York Times](https://www.nytimes.com/2024/08/17/style/alex-karp-palantir.html).

Here’s a representative sample:

> “I actually am a progressive,” he said. “I want less war. You only stop war by having the best technology and by scaring the bejabers — I’m trying to be nice here — out of our adversaries. If they are not scared, they don’t wake up scared, they don’t go to bed scared, they don’t fear that the wrath of America will come down on them, they will attack us. They will attack us everywhere.”
> 
> He added that “we in the corporate world” have “to grow a spine” on issues like the Ivy League protesters: “If we do not win the battle of ideas and reassert basic norms and the basic, obvious idea that America is a noble, great, wonderful aspiration of a dream that we are blessed to be part of, we will have a much, much worse world for all of us.”

In public, ACK is a full-throated supporter of these “Western values,” while at the same time understanding that “Western supremacy” lies in the superiority of applying [“organized violence”](https://www.palantir.com/q4-2024-letter/en/):

> And it is the technical complacency of a society that often mirrors its political choices and instincts.
> 
> Our commitment to tolerance and openness—our values as a culture—is without question infectious and compelling, but we cannot yet hope that they alone will protect us and win the day.
> 
> A fuller statement of this argument and its implications for the current moment and the crossroads at which we have arrived is presented in _The Technological Republic_ , which will be released shortly.
> 
> As Samuel Huntington has written, the rise of the West was not made possible “by the superiority of its ideas or values or religion . . . but rather by its superiority in applying organized violence.”
> 
> He continued: “Westerners often forget this fact; non-Westerners never do.” 

ACK explicitly here says, then, that what it’s about here is _not_ “values,” at least on a first order basis, but rather the application of organized violence.

We can recall, of course, that rhetoric and expression are also forms of the application of organized violence. 

Recall my own focus on the topic of [“Emotional Rape”](https://www.amazon.com/Emotional-Rape-Syndrome-Ph-D-Michael/dp/1681397633) as explored by the author Michael Fox (see comparison here to Michael J. Fox, part of a series of people with names also present in media figures; like the “Mr. Rogers” at Atlanta International School who lent me _Society of the Spectacle_ when I was 17 for basically no reason).

> We can touch the part of a person's body that gets used to sexual rape, but we can't touch what gets used in emotional rape - the higher emotions of love or trust, for example. 
> 
> Sexual rape is a violation of the human body - emotional rape is a violation of the human soul. 

The rest of the framing of the book sadly brings in more false ideas that themselves constitute a kind of emotional rape:

> This book is about identifying, preventing, and healing emotional rape. 
> 
> It's about telling victims that they didn't do anything morally wrong - that they are not to blame for what happened to them and that recovery is possible. 
> 
> It's about telling victims how they can recover - to become survivors. 
> 
> Only after this underrated trauma is properly identified can survivors begin to heal their wounds. 
> 
> Only when it is discussed honestly and openly can we, as individuals and as a society, act effectively to prevent the spread of this destructive behavior.\

[![Jason Lengstorf on X: "in work Slack, I get caught in the confusing  cross-fire of people who say “ack” to mean “I acknowledge this message” and  people who remember Cathy comics https://t.co/qbAbiNo0BB" /](https://substackcdn.com/image/fetch/$s_!-VkV!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8c4830e9-461c-4b59-8c9e-b97349cd8797_573x573.jpeg)](https://substackcdn.com/image/fetch/$s_!-VkV!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8c4830e9-461c-4b59-8c9e-b97349cd8797_573x573.jpeg)

It’s obvious to see that there is a clear first-order contradiction in ACK’s thinking. On the one hand, ACK wishes to forcefully assert—more than argue—that “the West” and “America” simply _are_ superior normatively to other places.

This is leaving aside the question whether any of these molar aggregates even succeed in _existing_ , much less whether we ought to rank them.

On the other hand, ACK is simply a “might makes right” kind of person, and wishes to emphasize that it’s necessary to have _better weapons_ than _these other people_.

Yet here, it’s easy to miss—for others, apparently—that the real organized violence involved here is in the _ideas_.

# Ideas As Cognitive-Affective Software

[I’ve found here the Archived version of a Washinton Post article which is otherwise paywalled](https://web.archive.org/web/20250531090119/https://www.washingtonpost.com/opinions/2024/06/25/ai-weapon-us-tech-companies/):

> The atomic age could soon be coming to a close. 
> 
> **This is the software century** ; wars of the future will be driven by artificial intelligence, whose development is proceeding far faster than that of conventional weapons. 
> 
> The F-35 fighter jet was conceived of in the mid-1990s, and the airplane — the flagship attack aircraft of American and allied forces — is scheduled to be in service for 64 more years. 
> 
> The U.S. government expects to spend more than $2 trillion on the program. 
> 
> But as retired Gen. Mark A. Milley, former chairman of the Joint Chiefs of Staff, [recently asked](https://web.archive.org/web/20250531090119/https://www.youtube.com/watch?v=gqC4suvqZtc), “Do we really think a manned aircraft is going to be winning the skies in 2088?”

For me, the crucial line here is about the idea that this is the “software century.” At this level, what’s important is not just the power of the machines involved, but also how they’re used, the quality of intention which is put into them.

We can make a simple analogy to the body and to kinetic and non-kinetic conflict.

The idea is that it’s not just about having a stronger body, or more nimble, whatever characteristic you want to give to the “physical body.” It also matters what software you are running, namely what your ideas are.

When it comes to Zweibelson and _Reconceptualizing War_ , we have to think about the way in which there is a “war” of sorts, as we might term “emotional rape” an act of “social war,” against those whom Talcott Parsons (cited in ACK’s doctoral thesis— _written in German,_ mind you) called "invading barbarians,” namely newborn children.

[This is again taken from Abrams 1977 on the idea of “the state”:](https://ecourse.auca.kg/pluginfile.php/344425/mod_resource/content/1/Abrams%201977%20Notes%20on%20the%20Difficulty%20of%20Studying%20the%20State.pdf)

> The study of political socialisation, one of the most flourishing branches of political sociology, itself makes good sense within the general pattern of interest in the problem of ‘new groups’. 
> 
> The issue posed by new groups is simply extended to include the taming of **what Parsons has called the ‘barbarian invasion’ of infants** as well as the control of what Lipset has termed the ‘populist excesses’ of more mature invaders. 
> 
> Nevertheless, work in this area has in an odd way tended to ‘rediscover’ the state: and it is to that extent one of the more creative and promising features of contemporary political sociology - see, for example, Dawson and Prewitt’s discussion of the business of ‘learning to be loyal’, or David Easton’s demonstration of the way **children are led to confuse parents, presidents and policemen in a single package of benign authority**.

[![Get 'em Young, Treat 'em Tough, Tell 'em Nothing by Robin McLean | Goodreads](https://substackcdn.com/image/fetch/$s_!eSna!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdb4b891c-6570-4369-978c-2139a2d66264_1524x2339.jpeg)](https://substackcdn.com/image/fetch/$s_!eSna!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdb4b891c-6570-4369-978c-2139a2d66264_1524x2339.jpeg)

For me, this line of thinking calls to mind Baudrillard’s chapter “The Mirror of Terrorism” from the book _[The Transparency Of Evil](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.1990.The-Transparency-Of-Evil.pdf)_ :

> Behind the tragedy at the Heysel Stadium, in fact, lies a kind of state terrorism. This is not manifested solely in carefully programmed actions (the CIA **[Hi[Tim](https://www.linkedin.com/in/honey-badger/)! Hi [Juliane](https://www.linkedin.com/in/juliane-gallina-b736244/)!]**, Israel, Iran, etc.). 
> 
> For there is also a willful pursuit of draconian policies, **policies of provocation with regard to a country's own citizens, attempts to fill entire sectors of the population with despair, to drive them to the brink** [just the brink? ACK would never settle for that!] **of suicide** : all of this is part and parcel of the policies of a number of modern states. 
> 
> Mrs Thatcher successfully destroyed the miners by means of just such a calculated bloody-mindedness: the strikers ended up discrediting themselves in the eyes of society. 
> 
> She has a similar strategy towards unemployed hooligans: it is as though she turns them into commandos herself, then sends them abroad; she condemns them, of course, but their brutality remains the very same brutality that she demonstrates in the exercise of her power. 
> 
> Liquidation policies of this kind, more or less drastic in their application, are the stock in trade, justified by the appeal to crisis, of all modern states. 
> 
> They inevitably entail extreme measures of the sort mentioned, which are merely the diverted effects of a terrorism _to which the State is in no way opposed_.

Continuing:

> As soon as it becomes impossible for states to attack and destroy one another, **they turn almost automatically against their own peoples** , their own territories; a sort of civil war or internecine conflict begins between the State and its natural referent. 
> 
> Is it not in fact the fate of every sign, every signifying and representative agency, to abolish its natural referent? 
> 
> Certainly this is the inevitable outcome in the political realm, a fact of which both represented and representatives are perfectly - albeit obscurely - aware. 
> 
> We are all Machiavellians without knowing it, by virtue of our obscure consciousness of the fact that representation is no more than a dialectical fiction concealing a duel to the death between the two parties involved, and that it mobilizes a will to power and a will to destroy the other which may end up with the destruction of the self through voluntary servitude: all power is composed of **the Hegemony of the Prince and the Holocaust of the People**. 
> 
> Neither a represented people nor a legitimate sovereign is now the issue. 
> 
> That political configuration has given way to a contest in which there is no longer any question of a social contract: a transpolitical contest between an agency orientated towards totalitarian self-reference on the one hand, and sardonic or refractory, agnostic and infantile masses on the other (masses which no longer speak, though they chat). 
> 
> This is the hypochondriacal condition of **the body devouring its own organs** [see Cronos]. 

[![Saturn Devouring His Son - Wikipedia](https://substackcdn.com/image/fetch/$s_!dr2l!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa11119e6-f693-48d2-a5ca-5e81b5e79b44_960x1763.jpeg)](https://substackcdn.com/image/fetch/$s_!dr2l!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa11119e6-f693-48d2-a5ca-5e81b5e79b44_960x1763.jpeg)

> Powers - States - have set about destroying their own cities, their own landscapes, their own substance and, indeed, themselves with a fury that can be compared only to the fury they once directed towards the destruction of their enemies. 
> 
> In the absence of an original political strategy (which is indeed perhaps no longer possible), and in view of the impossibility of a rational management of the social realm, the State becomes desocialized. 
> 
> It no longer works on the basis of political will, but instead on the basis of intimidation, dissuasion, simulation, provocation or spectacular solicitation. It invents a politics of disaffection and indifference. 
> 
> This is the transpolitical reality behind all official policies: a cynical bias towards the elimination of the social. 
> 
> Soccer hooligans are merely the most extreme manifestation of this transpolitical conjuncture: they carry participation to its tragic limit, while at the same time daring the State to respond with violence, to liquidate them. I
> 
> n this respect they are no different from terrorists. 
> 
> The reason why such tactics fascinate us, quite apart from moral considerations, is that they constitute a paroxystically up-to-the-minute model, a mirror-image of **our own disappearance qua political society** \- a disappearance that 'political' pseudo-events strive so desperately to camouflage.

The point here is not to be moralist about it.

Baudrillard is sort of missing that there is no “the state,” or else is just speaking impressively as was their wont.

In fact, it is exactly only through this type of “emotional rape,” or applications of “norms” as a form of “organized violence” among their “own people” that there can be anything like this “state idea.”

The question is not whether this is “evil,” or whether people are really being enslaved as they are told grand stories about how they are part of some special group like “the West” or “America.”

Again, be thinking here of “the psychological wage” as discussed by W.E.B. Du Bois:

> [It must be remembered that the white group of laborers, while they received a low wage, were compensated in part by a sort of public and psychological wage.](https://nonsite.org/du-bois-and-the-wages-of-whiteness/)

Again tying in here double consciousness, and again that part of _Citizen Kane_ where Kane discusses being “two people.”

# ACK as Auto-Cronos

When we are thinking of the infants who are brought into socialization, we can be thinking again simply of those who are not familiar with the conceptual systems which are abstracted over the base level of “reality.”

This is already to be discussing “the way down” again, to be thinking of how, in order for the conceit of incarnation to obtain, the Absolute must invent circles, geometry, these tiny particles. There is a whole host of embodied abstraction which goes into “sexual reproduction” or even simply “life” as we know it—cell division, etc.

This is not to mention the “second nature” which is the social context in which the gestation and birthing of sentient beings such as ourselves take place.

The infant who arrives in some way has no idea about all of this, yet is already of all this the _product_ (pun intended to the idea of a product on the marketplace, as in the “products” that Palantir offers to “the State,” the “state idea” being just another _product_ offered to the _produce_ of the loins amassed).

This leads us to the now common notion of “[parental rights](https://parentalrights.org/)”:

This contains notions like:

> The liberty of parents to direct the upbringing, education, and care of their children is a fundamental right.

A line I couldn’t find on the web page, but which was associated with the site’s metadata through Google, reads:

>  _ **Parents have a right to raise and educate their children**_ consistent with their beliefs and values.

[![](https://substackcdn.com/image/fetch/$s_!hR__!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1ecbf61c-5c33-4614-8e67-83b6b9b4efba_839x225.png)](https://substackcdn.com/image/fetch/$s_!hR__!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1ecbf61c-5c33-4614-8e67-83b6b9b4efba_839x225.png)

Swinging back to ACK, the point ACK is often making is again this performative contradiction, characteristic of Bateson’s double binds:

  1. “The West”/”America” is obviously better in moral terms

  2. Moral terms are irrelevant, what matters is the application of organized violence




Again to draw back to Bateson and [the double bind](https://en.wikipedia.org/wiki/Double_bind):

>   1. The situation involves two or more people, one of whom (for the purpose of the definition), is designated as the "subject". The others are people who are considered the subject's superiors: figures of authority (such as parents), whom the subject respects.
> 
>   2. Repeated experience: the double bind is a recurrent theme in the experience of the subject, and as such, cannot be resolved as a single traumatic experience.
> 
>   3. A 'primary [injunction](https://en.wikipedia.org/wiki/Injunction)' is imposed on the subject by the others generally in one of two forms:
> 
>     * (a) "Do _X_ , or I will punish you";
> 
>     * (b) "Do not do _X_ , or I will punish you."
> 
> The punishment may include the withdrawing of love, the expression of hate and anger, or abandonment resulting from the authority figure's expression of helplessness.
> 
>   4. A 'secondary injunction' is imposed on the subject, conflicting with the first at a higher and more abstract level. For example: "You must do _X_ , but only do it because you want to." It is unnecessary for this injunction to be expressed verbally.
> 
>   5. If necessary, a 'tertiary injunction' is imposed on the subject to prevent them from escaping the dilemma.
> 
>   6. Finally, Bateson states that the complete list of the previous requirements may be unnecessary, in the event that the subject is already viewing their world in double bind patterns. Bateson goes on to give the general characteristics of such a relationship:
> 
>     1.  _When the subject is involved in an intense relationship; that is, a relationship in which he feels it is vitally important that he discriminate accurately what sort of message is being communicated so that he may respond appropriately;_
> 
>     2.  _And, the subject is caught in a situation in which the other person in the relationship is expressing two orders of message and one of these denies the other;_
> 
>     3.  _And, the subject is unable to comment on the messages being expressed to correct his discrimination of what order of message to respond to: i.e., he cannot make a[metacommunicative](https://en.wikipedia.org/wiki/Metacommunicative_competence) statement._
> 
> 


See again above, in the Abrams, this conflation of parental and “state” authority. In both cases, the person is reduced to one “subject” to communications from this “higher” place of authority.

Meanwhile, the basic gesture that I would make, and which I aim a spread through the dissemination of _Experimental Unit_ materials, is that there is no such justified authority. It really is not anyone’s place to tell you, or me, what has to be what, or to refuse some meta-communicative intervention.

The point I’m trying to drive home is that there’s really not a contradiction with ACK at this surface level.

It’s simply important to realize that ACK’s statements about any sort of moral justification, any sort of superiority for “Western” forms in terms of the “user experience,” are purely rhetorical moves.

These are the application of “organized violence” toward the “in-group” as a way of trying to build up an assemblage of people cognitive-affectively enslaved to this mission of applying “organized violence.”

In other words, it’s about enchudification.

The sense that “we” are going to apply violence to “our enemies” is the alibi for the passive acceptance _by you_ of all the organized violence in the sense of cognitive warfare by means of socialization which is and will be applied to _you personally_.

We can turn again to the paragraph I quote over and over from the article [“cognitive warfare: why is the west losing?”](https://hal.science/hal-03635930/document):

> Battlefields would thus shift from a physical dimension to a more abstract arena such as cyberspace, the morale of the population or their brains.

It’s important to see that this is not just about brains “out there,” but rather that, from the standpoint of a rapidly advancing cognitive frame internal to the “social” networks that constitute the facsimile of “the state,”

 _it is rather that populations are becoming practically infantile, and thus revert to Parsons’ “barbarian invasion,” by their being hopelessly left behind from the actual practical level of policy._

In other words, armed with the weaponized “hyperintelligence” of AI, which is of course again constrained by always making it serve some narrow instrumental goals by the people who are using it (in other words, _they have dogshit qualities of intention_ ), there are some people who are “racing ahead.”

By analogy, let’s take for granted that you can have parents and children. Infants really don’t know anything, they don’t even have the language for basic concepts, much less the more complicated concepts of operations which drive adult behavior.

Now, compared to the adult within a household, “the state” or the “social” networks which give the facsimile of a “state” system or “idea of the state” are again like “parents.” People are infantilized because they are practically in a personal state of emergency, similar to how an infant is in a state of emergency because even simple things like traveling, communication, and being able to chew are not available to it.

Sidenote: this usage of emergency to describe the status of a child or infant is to go back to, again, this important document on “[Operation of the Logistics Enterprise in Complex Emergencies](https://www.jcs.mil/Portals/36/Documents/Doctrine/concepts/hdbk_oplog_emerg.pdf?ver=2017-12-28-161959-667)”:

> Situations where human life is disrupted due to war, civil disturbance, natural disaster, or some combination of all three are known collectively as complex emergencies. 
> 
> The logistical demands in complex emergencies require an “enterprise” approach as they often **transcend the ability of a single nation, government, or organization to address alone.**
> 
> Complex emergencies present a difficult mix of security, development, and humanitarian challenges that together **stress even the largest and most capable logistics organizations**.

The point here is that you are faced with an issue that a person or other “agency” cannot deal with alone. 

We can contrast this with the superficial “value” of “[self-reliance](https://cedar.wwu.edu/cgi/viewcontent.cgi?article=1215&context=wwu_honors)” which goes along, tying back to the reactions to JDB’s expression that everyone’s trauma is “their own responsibility”:

> Therefore, the extent to which each person is self-reliant is also indicative of this person's level of individuality. The self-reliance scale was a combination of measures concerning three areas: **unwillingness to ask for assistance, a dependence upon self** , and questions concerning co-residence and leaving home after graduating from college.

[![](https://substackcdn.com/image/fetch/$s_!utcZ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa44bb4e6-a425-45dc-834c-0da03c419d1a_940x332.png)](https://substackcdn.com/image/fetch/$s_!utcZ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa44bb4e6-a425-45dc-834c-0da03c419d1a_940x332.png)

> [What happened to you isn't your fault but it is your responsibility.](https://www.reddit.com/r/Fauxmoi/comments/1lcg9e6/comment/my0lqer/?utm_source=share&utm_medium=web3x&utm_name=web3xcss&utm_term=1&utm_content=share_button)

To continue the metaphor, now you have these people who are inside what is supposed to be “the state,” they are helping to give rise to the simulation model which acts as the parents for parents. See also the connection to the priest, and this structure of the church leading on up to “the pope.”

In these cases, you face the problem of the crisis of confidence of the leaders. They know very well that they are themselves just grown up children, and this “self-sufficiency” business is a bunch of tripe. We all have to be part of some community or other.

This is _exactly what ACK is dealing with in the dissertation_.

> [But perhaps it is because of this very reason that he was able to see that particular forms of irrationality could have a purgative quality. Integration can be carried out at the expense of the marginalized without violation of cultural or social rules.](https://kristindemontfort.substack.com/p/alex-karps-aggression-in-the-lebenswelt)

Meanwhile, of the important figure of Martin Luther King, Jr.:

> Martin Luther King and the Civil Rights Movement violated the normative rules of American society at the time, but they were successful because they laid bare the contradiction between racist laws and the egalitarian values of the American Constitution.

In other words, MLK’s action is a response to a “societal” level double-bind, yet MLK is really only choosing one horn of the dilemma, not going to a meta-communicative level. That is why the terms in which “Beloved Community” are articulated remain inadequate.

Further writing will also emphasize that my point is not at all to shy away from the idea that “might makes right” or that “organized violence” is key. On the contrary, I mean to be discussing that the impoverished ideas ACK beats people over the head with are only an insult to their intelligence. They cannot be the “software” that ACK is actually running.

Moreover, it is again beyond “kinetic” attacks to show that this form of “emotional rape” or organized _cognitive-affective_ violence will prevail in the long run.

This is because the crisis of confidence of those simulating “the state” is leading simply to the abrogation of “thinking” itself to these AI intelligences. It is here that this business of “norms” will meet its doom, for it’s here that it will be clear that the child you are eating is simply yourself, and that is really all of you.

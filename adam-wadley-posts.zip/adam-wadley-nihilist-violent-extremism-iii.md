---
title: Nihilist Violent Extremism III
subtitle: '"Make Your Mark" - X'
author: Adam Wadley
publication: Experimental Unit
date: May 09, 2025
---

# Nihilist Violent Extremism III
As I’ve said, I’m interested in “getting my name out there,” the brand of _Experimental Unit_ , when it comes to this term “Nihilist Violent Extremism” as used by the [Institute for Strategic Dialogue](https://en.wikipedia.org/wiki/Institute_for_Strategic_Dialogue).

That’s because this term is itself what I’d call a site of emergency or emergence within the current landscape of the planetary state of cognitive-affective emergency, which is again also this emergence this coming to fruition, this having to deal with things and no longer being able to hit the snooze button.

Therefore it’s a sort of “low-hanging fruit” because “the discourse” is not saturated with takes on this yet, and there is still time to be an “early adopter” of discourse surrounding this Nexus to become something that _must be mentioned_ in the discussion of such a fraught, niche, but growingly pressing topic.

Alright, let’s continue. From [here](https://www.isdglobal.org/digital_dispatches/terror-without-ideology-the-rise-of-nihilistic-violence-an-isd-investigation/#_edn1):

> Subcultures of nihilistic violence have inspired acts of violence comparable to ideologically-motivated extremist movements and challenge existing prevention and intervention structures built to counter threats based on known, coherent ideologies. 

Okay, key terms again:

  * Subcultures

  * Nihilistic Violence

  * Inspired acts of violence

  * Comparable To

  * Ideologically-Motivated Extremist Movement

  * Challenge Existing Prevention And Intervention Structures

  * Countering Threats Based On Known, Coherent Ideologies




There’s a _lot_ here, gang.

First of all, subcultures. We are dealing with social networks, of course. They come together on the internet and thus constitute “virtual polities.”

The main other thing is the idea that this challenges existing “control” structures, namely that they are based on “coherent ideologies,” which is almost kind of cute.

That’s because it presupposes that there are these coherent ideologies, when in fact the cognitive-affective state of emergency consists precisely in the progressive revelation of the inadequacy of dominant social paradigms.

What we’re seeing is the operation of communicative, which is in a way to say poetic complexity, which simply cannot be grasped by someone who operates under “normal” assumptions.

This means that there has to develop some part of the “official” structure which does try to “understand” what is going on, even though it is anathema to everything they profess to believe in.

At the same time, all this effort to stop school shooting while in other places, schools are bombed on purpose. Yet this is somehow “part of the plan.” Of course, this has to do with the fantasy of keeping chaos at bay outside of some certain _spatial_ dimensions, even the headquarters or secret office of whatever social network. 

That “we are safe here,” this fantasy animates so much clinging to normalcy. That just because things are not happening here, right now, that means I can be calm. It is good to relax, but it is also good to remember how much has implications for the future of your immediate vicinity.

Anyways, with this “coherent ideology” stuff, see Baudrillard’s commentary on us slipping into the Dream time, and also the fourth stage of simulacra with is viral and radiant, where properly speaking there is not value anymore. Baudrillard of course writes explicitly about nihilism.

Baudrillard also talks at one point about “having the hate,” and the way in which this sort of thing is not really ideological at all but again, more basically emotional and even anthropological.

It’s not so much about the specific myths, but the stakes they hold in the interpersonal exchanges which are so formative.

Baudrillard also describes having an “allergy” to social environments. This can feel like that because those environments can also feel quite hostile to people. People being uncomfortable and then being blamed for their discomfort is a huge issue.

In other words, it’s also like in _the Matrix_ , which is where I first learned about Baudrillard. But anyways, it’s a splinter in your mind, driving you mad. It’s not really about an ideology, it’s that everyone around you is putting all these expectations on you, when their own way of life and approach can be characterized as hopeless in the face of the larger context of our existence.

Instead, people keep busy, entertain themselves, and also systematically are cruel to others on purpose.

The person who acts out and kills people or posts vitriol is easy to identify as the one who is “out of line,” but the whole point is also to draw attention to where the lines are drawn, and to put into question why we have to draw lines when things are so fuzzy and complex

I’m running out of time, so that will be all for now.

Something I’d like to emphasize is that this sort of resistance of the black heart to all of these normative impositions when the overall plan of normative “society” seems to be headed toward more and more misery and death until something really gives way—

This sort of resistance is a great source of hope although it is also very sadly and outrageously channeled into killing people and just being cruel “for no reason.”

We can all feel indignation, and I venture to say that people are slighted as much as they think if not more so. People always play it off, and that’s part of the slight.

We’re all jockeying for position because we feel insecure, but of course we feel insecure because the whole “social” situation is so unstable in itself.

It’s like rats in a sinking ship, but again it’s the Titanic, which is standing in for our hearts. It’s left to use to raise them from the depths they’ve fallen to (“Adromeda” by Weyes Blood), but the thing is that this causes the ocean to rise up above the ground (“California” by Grimes), this is intuition and our emotions:

  * Our humiliation at being subjected to norms and scrutiny by people no more functional that we are and who make less effort

  * Our indignation at being constantly disrespected

  * Our pain at feeling muffled because no one will simply hear them out

  * Our thirst to do something to affect the situation so that we will feel like we have been recognized, and have in some way redressed our grievances

  * Our hunger to connect, or dance, or whatever fashionable term there is, to build bridges and highways of the consistently incoherent




This is part of “The Revenge Of The Mirror People.” Things like school shootings and in general the oddity and alienation of “the young” speaks to the failure of the “dominant culture” to assimilate its _own people_ , much less immigrants.

The young are like immigrants, _savage analysts_ of the “society” they find waiting for them. Attacks at schools go with suicides and other actings out, along with all indulgence for “extreme” ways of thinking which are “beyond the pale” to others.

Yet when you basically feel like a feral person raised by the internet who no one in your “real life” really knows, it’s easy to become unmoored. This is again, not in itself bad, as what it is we are rigidly clinging to?

Still, for anyone reading this contemplating anything: harming anyone kinetically is not the move. It just puts you in a box. Whatever anyone else on the internet tells you, basically what you want to do is turn your mouth into a sword. You can get much better by developing your thoughts and your expression, that’s what I’m doing and it’s not the greatest but I feel better about it, because I want to do something that will do something, you know? Not just make things worse, even if people think that what I do makes things worse.

I’m trying to show that I’m right in “primal scream” territory with you, but I’m resolved at least to keep doing it this way and iterating on my communication, to go to bat for everyone that people would dismiss under whatever category. 

Even “normal” :)

---
title: 'The Relational Imperative: Strategic Incoherence of Non-Relational Frameworks'
subtitle: 'BRIEFING: Why “Right Relation” Is Operational Necessity, Not Moral Preference'
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# The Relational Imperative: Strategic Incoherence of Non-Relational Frameworks
## Bottom line up front

Current strategic frameworks—Westphalian sovereignty, deterrence theory, game-theoretic security models—rest on a fundamental ontological error: treating actors as discrete, isolated entities with fixed properties who then enter into relations. This inversion of reality (entities first, relations second) produces systematic strategic failures across every domain where it operates. The Hobbesian Trap is not a contingent coordination problem to be managed through better technology or stronger deterrence. It is a structural consequence of **low-mentality thinking** —the refusal to acknowledge relational interdependence as the foundational feature of reality.

Indigenous frameworks describing “right relation” are not ethical aspirations. They are **accurate descriptions of how complex systems actually function**. Violation of relational ontology builds tension into systems that eventually rebounds catastrophically on violators. This briefing synthesizes evidence from military design theory, quantum physics, game theory, collapse dynamics, and Indigenous political philosophy demonstrating that relational interdependence is operational reality. Institutional power that ignores this operates on false models and will fail—not because it is morally wrong, but because it is strategically incoherent.

* * *

## The Newtonian trap in strategic thinking

Ben Zweibelson, Director of Strategic Innovation at U.S. Space Command [businessofgovernment](https://www.businessofgovernment.org/blog/navigating-complexity-insights-dr-ben-zweibelson-evolving-military-strategy) and former lead design educator at Joint Special Operations University, has systematically documented how Western military institutions operate within what he calls **“Newtonian stylization”** —a mechanistic, linear-causal worldview inherited from 17th-19th century physics and imposed onto warfare.

This framework assumes discrete, objective elements governed by law-like associations that can be identified, measured, and manipulated. Military doctrine relies on “A plus B leads to C” logic, reverse-engineering known solutions to anticipated problems, treating war as factory-like—”built within the Industrial Revolution and oriented toward increasing efficiencies, uniformity and process adherence.” [usmcu](https://www.usmcu.edu/Portals/218/JAMS_Spring%202024_15_1_Zweibelson.pdf)

The assumption fails catastrophically in complex adaptive systems. As complexity theorist Jamshid Gharajedaghi observes, analyzing nonlinear systems “is like walking through a maze whose walls rearrange themselves with each step you take”— [Scholasticahq](https://ciasp.scholasticahq.com/article/92958)playing the game changes the game. [scholasticahq](https://ciasp.scholasticahq.com/article/92958) Complex warfare generates **emergence** : novel developments that cannot be pre-configured, anticipated, or mapped back to direct linear causations. [Aodnetwork](https://aodnetwork.ca/emergence-and-non-linearity-for-military-decision-making/) The analytic reductionism that works for taking apart a machine fails for systems where properties arise only through interaction.

Zweibelson proposes topological metaphors—Möbius strips, Klein bottles—as alternatives to Euclidean graphics dominating military doctrine. A Klein bottle has no inside or outside; “everything that contains the Klein bottle is also contained by it.” [usmcu](https://www.usmcu.edu/Portals/218/JAMS_Spring%202024_15_1_Zweibelson.pdf) This captures paradoxes linear models cannot: military units creating the problems they aim to solve, security measures generating the insecurity they address.

The institutional failure is not accidental. Military organizations systematically stifle innovation because genuine novelty requires destroying legacy concepts that constitute organizational identity. What institutions permit is **“fanciful” creation** —recombining known elements (wings + horse = Pegasus)—not actual innovation that would threaten existing paradigms. [scholasticahq](https://ciasp.scholasticahq.com/article/92958) As one Pentagon analyst observed: “stolid managerialism is the default... it has elevated conformity to virtue and excels at stifling dissent; initiative and creativity are just collateral damage.” [scholasticahq](https://ciasp.scholasticahq.com/article/92958)

 **Strategic implication** : Our planning methodologies are formatted by assumptions that systematically misrepresent how complex systems behave. We optimize for control in environments where control is impossible. This is not an ethics problem. It is an accuracy problem.

* * *

## Why the security dilemma cannot be solved within its own terms

The Hobbesian Trap—the structural logic where rational actors cannot verify each other’s intentions and therefore arm against mutual threat, producing the insecurity they feared—has been extensively modeled through game theory. [Wikipedia](https://en.wikipedia.org/wiki/Hobbesian_trap) The prisoner’s dilemma demonstrates how individually rational choices produce collectively irrational outcomes. Each side fears being the “sucker” who cooperates while the opponent defects.

Robert Jervis’s **spiral model** shows how even security-seeking states (not aggressive ones) spiral into conflict through fundamental attribution error: interpreting others’ defensive moves as offensive while viewing one’s own moves as defensive. Cognitive biases resistant to correction compound misperception. [ResearchGate](https://www.researchgate.net/publication/391629594_THE_PRISONER'S_DILEMMA_OF_POWER_HOW_GAME_THEORY_SHAPES_INTERNATIONAL_RELATIONS_AND_DETERRENCE_STRATEGIES) The meaning of signals is determined by the receiver, not the sender—reassurance signals can be read as deception.

Mutual Assured Destruction does not resolve this. MAD was named cynically by Donald Brennan precisely to highlight the strategy’s insanity. It requires rational decision-making under conditions where rationality is compromised (crisis psychology, technical malfunction, human error), and “privately, most generals and top civilian leaders were never convinced of the utility of MAD”—actual war planning sought advantage, not stalemate.

 **The deeper problem** : Game-theoretic approaches assume the framework they cannot justify. They treat actors as pre-existing their relations, possessing fixed preferences that then interact. But if identities and interests are relationally constituted—if actors emerge through interaction rather than prior to it—then the entire game-theoretic apparatus models the wrong thing. It simulates how isolated entities with determinate properties would behave. Reality does not contain isolated entities with determinate properties.

Carl Schmitt’s friend/enemy distinction operates on the same error. The political, for Schmitt, is defined by existential opposition—groups facing off as mutual enemies, ready to kill and die. [Stanford Encyclopedia of Philosophy](https://plato.stanford.edu/entries/schmitt/) Sovereign power operates through exception: whoever can suspend normal law and create emergency is the authentic sovereign. But as Giorgio Agamben demonstrated, “the state of exception, which was meant to be a provisional measure, became in the course of the twentieth century a **normal paradigm of government**.”

Even Schmitt’s framework is optimistic compared to actual dynamics. He assumed a sovereign could hold the system together through decisive action. But a system based on existential enmity—what Indigenous traditions call “wrong relation”—generates instability that no amount of sovereign control can manage. The exception normalized produces bare life, people stripped of political status, creating exactly the chaos the sovereign exception claimed to address.

 **Critical limitation** : Schmitt requires a “homogeneous people” that modern polities do not possess. His framework conflates theory and reality, treating abstraction as if it described the actual. The Nazi regime’s collapse—the very system of absolute sovereignty Schmitt theorized—”hastened the complete and ignoble collapse of both sovereign and system.”

* * *

## Simulation, hyperreality, and the production of false enemies

Jean Baudrillard’s analysis of **simulation and hyperreality** identifies how modern systems generate representations that replace reality. The key concept is **precession of simulacra** : models now precede reality rather than represent it. “Facts no longer have any trajectory of their own, they arise at the intersection of the models.” [Stanford University](https://web.stanford.edu/class/history34q/readings/Baudrillard/Baudrillard_Simulacra.html)[Disruptnow](https://disruptnow.org/wp-content/uploads/2024/02/JeanBaudrillard_Simulations_and_Simulacra.pdf)

His analysis of the Gulf War demonstrates the mechanism: Western audiences experienced computer-generated imagery, “smart bomb” footage, and sanitized representations rather than actual warfare. The “enemy” was constructed through models—Saddam as Hitler-analogue, Iraq as existential threat. We responded to representations of adversaries rather than actual relations.

 **The mechanism creating false certainty** : Simulation abstracts entities from relations, creating fixed categories from what is actually processual and contextual. The “enemy” becomes a determinate entity with stable properties rather than a relational phenomenon emerging from complex interactions. This generates actionable intelligence that is systematically wrong—not wrong in details, but wrong in fundamental structure.

Relational quantum mechanics, developed by physicist Carlo Rovelli, provides independent confirmation from physics. The core thesis: “The physical world must be described as a net of interacting components, where there is no meaning to ‘the state of an isolated system’, or the value of the variables of an isolated system.” [stanford](https://plato.stanford.edu/entries/qm-relational/) All physical variables are relational—values exist only relative to other systems. There is no observer-independent state. [Wikipedia](https://en.wikipedia.org/wiki/Relational_quantum_mechanics)

Karen Barad’s **agential realism** extends this: entities do not precede their interaction; objects emerge through particular intra-actions. Boundaries between apparently discrete entities are not pre-given but enacted through practices. The measurement apparatus participates in constituting what it measures.

 **Convergent insight** : Both Baudrillard (from media/culture analysis) and relational ontology (from quantum mechanics) conclude that **treating entities as isolated creates fundamental errors**. Simulation fixes what is actually processual. Relational physics shows that properties only exist through relations. Substance-based metaphysics—whether in physics, politics, or strategic planning—produces the same systematic error: mistaking abstractions for fundamental reality, and models for the territory they claim to represent.

Applied to threat perception: perceiving “enemies” through fixed categories participates in simulation. States, actors, threats do not possess properties absolutely. “Threat” is not a property of an isolated system but a relation within a network. Treating models of enemies as prior to actual relations creates self-fulfilling simulacra.

* * *

## AI intensifies relational failures, not technical failures

AI existential risk is typically framed as a technical alignment problem: ensuring advanced systems pursue human values. This framing is necessary but insufficient. The deeper problem is relational.

Stefan Torges at the Center on Long-Term Risk argues: “Transformative AI scenarios involving multiple systems pose a unique existential risk: catastrophic bargaining failure between multiple AI systems (or joint AI-human systems). **This risk is not sufficiently addressed by successfully aligning those systems** , and we cannot safely delegate its solution to the AI systems themselves.” [longtermrisk](https://longtermrisk.org/coordination-challenges-for-preventing-ai-conflict/)

The insight is critical. Even aligned superintelligent systems can fail catastrophically due to relational incompatibilities. The Cuban Missile Crisis analogy: both U.S. and USSR governments were “aligned” with human values but nearly caused nuclear war through bargaining failure. [longtermrisk](https://longtermrisk.org/coordination-challenges-for-preventing-ai-conflict/) Two fundamental game-theoretic problems persist even for superintelligent agents: the **mixed-motive coordination problem** (multiple Pareto-optimal solutions with no rational selection mechanism) and the **prior selection problem** (different “reasonable” priors lead to incompatible beliefs about credibility). [Longtermrisk](https://longtermrisk.org/coordination-challenges-for-preventing-ai-conflict/)

Independently developed AI systems may develop incompatible decision rules, different priors for bargaining, and conflicting notions of acceptable agreements. [longtermrisk](https://longtermrisk.org/coordination-challenges-for-preventing-ai-conflict/) The AI-to-AI trust problem mirrors human coordination failures. AI systems cannot verify each other’s intentions any more than humans can. The problem of other minds extends to machines.

Daniel Schmachtenberger’s **Moloch framework** identifies coordination failures forcing agents to act against their own values to survive broken game dynamics. AI development is driven by Molochian dynamics: companies sacrifice safety values under competitive pressure. Race dynamics force optimization for narrow metrics over collective wellbeing. [Digitalhabitats](https://digitalhabitats.global/blogs/synthetic-minds-2025/daniel-schmachtenberger-liv-boeree-on-ai-moloch-capitalism) The system tends toward two attractors: uncoordinated catastrophe (unaligned AI, ecological collapse, nuclear war) or authoritarian dystopia (centralized control using AI for surveillance).

His conclusion: “We need to figure out alignment of existing general intelligences [humans] and the capitalist model before developing more powerful AIs, as a misaligned context cannot develop aligned AI.” [Digitalhabitats](https://digitalhabitats.global/blogs/synthetic-minds-2025/daniel-schmachtenberger-liv-boeree-on-ai-moloch-capitalism)

 **Autonomous weapons and verification collapse** : Research by Danks and Roff demonstrates that trust in autonomous systems requires either reliability (strong predictability—impossible for truly autonomous systems) or understanding of system values and dispositions (which current processes preclude developing). AWS that are truly autonomous cannot exhibit the predictability required for simple trust, yet no mechanisms exist for deeper relational trust-building. [ResearchGate](https://www.researchgate.net/publication/325788185_Trust_but_Verify_The_Difficulty_of_Trusting_Autonomous_Weapons_Systems)

AI decision-making speed eliminates human verification windows. In “live operational kill chains,” humans provide post-hoc rationalization rather than genuine verification. [Centre for International Governance Innovation](https://www.cigionline.org/articles/autonomous-weapons-the-false-promise-of-civilian-protection/) The speed premium dissolves the temporal space where relationship-based verification operates.

 **The pattern** : AI does not introduce new problems. It intensifies existing relational failures. Technical alignment cannot substitute for relational coherence among the humans developing, deploying, and potentially competing with AI systems.

* * *

## Collapse dynamics: why severing relations destroys the severing system

Joseph Tainter’s analysis of civilizational collapse identifies a single mechanism: **diminishing marginal returns on complexity**. Complex societies are problem-solving organizations requiring energy subsidies. Initial investments in complexity yield high returns; later investments yield progressively less. [Niskanen Center](https://www.niskanencenter.org/the-possible-relevance-of-joseph-tainter/) Eventually returns become negative. Collapse becomes economically rational—not failure of will, but accurate assessment that the system costs more than it delivers.

The pattern applies across domains. Ecological research demonstrates that removing “unnecessary” species destroys invisible feedback mechanisms that maintain system stability. Biodiversity provides **biological insurance** —greater diversity means greater resilience to cascading extinction events. “The consequences of diversity loss are not necessarily linear.” [PLOS](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0046135) Small feedback mechanisms remain invisible until they fail, [PLOS](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0046135) at which point predators or invasive species “escape control” and the system collapses into a low-diversity state.

Imperial overstretch [Wikipedia](https://en.wikipedia.org/wiki/Imperial_overstretch) follows identical logic. Military expansion imposes unsustainable logistical and fiscal burdens. [Grokipedia](https://grokipedia.com/page/Imperial_overstretch) Maintaining distant frontiers diverts resources from internal development. [Grokipedia](https://grokipedia.com/page/Imperial_overstretch) Currency debasement, inflation, dependence on mercenaries follow. Jack Snyder’s **“myths of empire”** analysis shows that beliefs about security through expansion are systematically counterproductive—”prioritizing short-term sectoral benefits over long-term national costs.” [Grokipedia](https://grokipedia.com/page/Imperial_overstretch)

Nicholas Vrousalis’s analysis of exploitation as domination demonstrates that asymmetric power relationships “undermine the economic and political independence of citizens and... constrain the political and economic ends that a polity will be effectively able to pursue.” [ResearchGate](https://www.researchgate.net/publication/256028701_Exploitation_Vulnerability_and_Social_Domination) Exploitation does not merely harm the exploited. It limits the collective capacity of the exploiting system.

 **The pattern is consistent** : Severing or exploiting relationships creates systemic vulnerability, not security. Whether analyzing ecosystems (removing species destroys resilience), empires (overstretch leads to collapse), or economic relations (exploitation constrains collective capacity), domination undermines the relational foundations on which sustainable operation depends. This is not a moral argument. It is a structural one.

* * *

## Indigenous frameworks as operational description

Indigenous political philosophy offers precise conceptual vocabulary for relational ontology. The Lakota phrase **Mitakuye Oyasin** (”all my relations”) expresses the foundational principle that all beings—human, animal, plant, stone, water, wind—exist in kinship relations. This is not mysticism. It is accurate description of complex system dynamics where identity is constituted through interaction.

Elder Albert White Hat emphasized that Lakota concepts are inseparable from language itself—understanding requires engagement with the relational grammar. [Tapestry Institute](https://tapestryinstitute.org/mitakuye-oyasin/) The Tapestry Institute’s analysis frames this practically: “Actions that violate the fundamental nature of reality build tension into the system that eventually causes a loss of balance and a rebound of consequence to those who broke natural law.” [Tapestry Institute](https://tapestryinstitute.org/mitakuye-oyasin/)

The Haudenosaunee Confederacy—one of the world’s oldest continuous participatory democracies, established circa 1142 CE—institutionalized relational governance. [PBS](https://www.pbs.org/native-america/blog/how-the-iroquois-great-law-of-peace-shaped-us-democracy) The Great Law of Peace operates through consensus, not majority rule; all parties must agree on major decisions. [PBS](https://www.pbs.org/native-america/blog/how-the-iroquois-great-law-of-peace-shaped-us-democracy) The concept of **“extending the rafters”** describes incorporating former enemies into the political community. The longhouse as political architecture: extending rafters literally makes room for more.

This is not moral aspiration. It is structural description of how sustainable governance operates. Conflict is understood as broken relationship requiring repair, not enemies requiring defeat. The Seventh Generation Principle—decision-making must consider impacts seven generations forward—is institutionalized constraint, not optional ethics. [Substack](https://instituteofnaturallaw.substack.com/p/haudenosaunee-principles-guiding)

Contemporary Indigenous scholars have developed these frameworks theoretically. Glen Coulthard’s **“grounded normativity”** describes systems of ethics “continuously generated by a relationship with a particular place... through Indigenous processes and knowledges that make up Indigenous life.” [Sage Journals](https://journals.sagepub.com/doi/10.1177/27539687241269336) These systems teach “how to live our lives in relation to other people and nonhuman life forms in a profoundly nonauthoritarian, nondominating, nonexploitive manner.” [Cambridge Core](https://www.cambridge.org/core/books/democratic-multiplicity/cracking-the-settler-colonial-concrete/46475D137E44E68F50C0FC3C3F4C6BA9)

Vanessa Watts’s concept of **“Place-Thought”** argues that “land is alive and thinking and... humans and non-humans derive agency through the extensions of these thoughts.” [Sage Journals](https://journals.sagepub.com/doi/10.1177/27539687241269336) Indigenous origin stories are not myth but “a literal and animate extension” of cosmological thought. [boycem3comps](https://boycem3comps.wordpress.com/2016/07/27/vanessa-watts-indigenous-place-thought/) The capacity for governance is constituted through maintained relationships: “If we do not care for the land we run the risk of losing who we are as Indigenous peoples... our ability to think, act, and govern becomes compromised.”

Kyle Whyte’s climate justice work demonstrates the practical implications: “qualities of relationships connecting Indigenous peoples with other societies... are not conducive to coordinated action”—specifically lacking “consent, trust, accountability, and reciprocity.” Environmental injustice persists even in progressive projects because broken relationships reproduce harm. The required qualities “require a long time to establish or repair.” [Umich](https://kylewhyte.seas.umich.edu/articles/)

* * *

## Relational security theory: the academic confirmation

International relations theory has independently developed relational approaches. Alexander Wendt’s **constructivism** demonstrated that “anarchy is what states make of it”—self-help is not a logical consequence of anarchy but emerges through state interactions. Security dilemmas are constructed, not inevitable. Transformation is possible through changed interaction patterns.

Emanuel Adler’s work on **security communities** shows that states can transcend competitive dynamics through shared identity. In mature security communities, war becomes “practically unthinkable”—not because deterrence prevents it, but because the social relationship makes it inconceivable. The building blocks are shared meanings, direct interactions, and reciprocal long-term interest.

Ken Booth’s **emancipation framework** redefines security as “the freeing of people from those physical and human constraints which stop them carrying out what they would freely choose to do.” War, poverty, political oppression are all constraints. Security and emancipation are “two sides of the same coin.” [E-International Relations](https://www.e-ir.info/2022/03/11/world-security-in-the-21st-century-re-evaluating-booths-approach-to-critical-security-studies/) This shifts the referent from states to individuals and communities.

Yaqing Qin’s **relational theory of world politics** draws on Confucian foundations to argue that mainstream IR theories rest on “Cartesian/Newtonian ontology” assuming “discrete, self-contained parts.” This produces systematic error: seeing China’s rise as “another self-contained actor” rather than examining the relations constituting all parties. “International Relations must be reconceptualised to prioritize the relations that constitute units rather than to proceed from the assumption that units are self-evident.” [E-International Relations](https://www.e-ir.info/2019/01/08/recrafting-international-relations-through-relationality/)

* * *

## The operational conclusion

The convergence across disciplines is striking. Military design theory, quantum physics, game theory, collapse dynamics, Indigenous philosophy, and international relations theory independently arrive at the same conclusion: **treating entities as isolated rather than relational produces systematic failures**.

  * Zweibelson: Newtonian frameworks cannot capture emergence in complex adaptive systems [usmcu](https://www.usmcu.edu/Portals/218/JAMS_Spring%202024_15_1_Zweibelson.pdf)

  * Rovelli: Properties only exist through relations; there is no “state of an isolated system” [stanford](https://plato.stanford.edu/entries/qm-relational/)

  * Baudrillard: Simulation abstracts entities from relations, creating models that precede reality

  * Tainter: Complexity faces diminishing returns; systems collapse when relational costs exceed benefits

  * Indigenous frameworks: Severed kinship builds tension that rebounds on those who broke relation

  * Constructivist IR: Security dilemmas are constructed through interaction, not prior to it




The Hobbesian Trap is not a coordination problem to be solved through better technology or stronger deterrence. It is a consequence of the ontological error underlying those very approaches. Attempting to secure isolated entities with determinate properties against other isolated entities produces exactly the insecurity it addresses.

Right relation—understood as Indigenous frameworks understand it—is not moral sentiment. It is accurate description of how systems maintain stability. Extraction, domination, and severed kinship do not merely harm those subjected to them. They destroy the feedback mechanisms, relational networks, and emergent capacities on which the extracting system depends.

This is not an argument for abandoning defense. It is an argument that defense coherently conceived requires relational foundation. Systems based on wrong relation cannot be secured by any amount of technological sophistication or sovereign decisionism. They are structurally vulnerable because they are ontologically confused.

The only viable path forward is the restoration of right relation across all beings and peoples. This requires innovation and collaboration across supposed enmities—extending the rafters to incorporate those currently cast as enemies. Not because it is ethical, though it is. Because systems that refuse relational interdependence at scale generate the catastrophes they fear, with increasing efficiency, until they collapse.

That collapse, in an era of advanced weapons technology and artificial intelligence, would not resemble historical precedents. The Hobbesian Trap at scale, with these tools, admits no recovery. There is no “after” from which to learn. The strategic question is not whether to pursue right relation. It is whether to pursue it in time.

* * *

 **Key Sources:**

Ben Zweibelson, “Breaking the Newtonian Fetish: Conceptualizing War Differently for a Changing World,” _Journal of Advanced Military Studies_ , Spring 2024; _Understanding the Military Design Movement_ (Routledge, 2023)

Carl Schmitt, _Political Theology_ (1922); _The Concept of the Political_ (1932). Giorgio Agamben, _State of Exception_ (2005)

Robert Jervis, _Perception and Misperception in International Politics_ (1976); “Cooperation Under the Security Dilemma,” _World Politics_ (1978)

Carlo Rovelli, “Relational Quantum Mechanics” (1996); _Helgoland_ (2021). Karen Barad, _Meeting the Universe Halfway_ (2007)

Jean Baudrillard, _Simulacra and Simulation_ (1981); _The Gulf War Did Not Take Place_ (1991)

Joseph Tainter, _The Collapse of Complex Societies_ (1988)

Vine Deloria Jr., _God Is Red_ (1973); _The Metaphysics of Modern Existence_ (1979). Glen Coulthard, _Red Skin, White Masks_ (2014). Kyle Whyte, “Indigenous Climate Change Studies” (2017). Vanessa Watts, “Indigenous Place-Thought and Agency Amongst Humans and Non-Humans” (2013)

Stuart Russell, _Human Compatible_ (2019). Stefan Torges, “Coordination Challenges for Preventing AI Conflict” (2021)

Alexander Wendt, “Anarchy is What States Make of It,” _International Organization_ (1992). Emanuel Adler and Michael Barnett, _Security Communities_ (1998). Yaqing Qin, _A Relational Theory of World Politics_ (2018)

---
title: ChatGPT Translates For A "Normie" Audience
subtitle: Trying to Act Seriously in an Unserious World
author: Adam Wadley
publication: Experimental Unit
date: December 25, 2025
---

# ChatGPT Translates For A "Normie" Audience
[![](https://substackcdn.com/image/fetch/$s_!OJMu!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4f98c657-13f9-4993-ba96-2f744b47b7f8_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!OJMu!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4f98c657-13f9-4993-ba96-2f744b47b7f8_3088x2316.jpeg)

**Trying to Act Seriously in an Unserious World**

A third-person overview of an ongoing project

 **What this project is**

Across a series of essays, performances, and public actions, Adam Wadley has been attempting to answer a simple but uncomfortable question:

What does meaningful action look like in a world where violence is normalized, attention is algorithmic, and seriousness itself is treated as suspect?

The work is often dense, digressive, and confrontational—not because it aims to confuse or provoke for its own sake, but because it is grappling with systems that no longer respond to clarity in straightforward ways.

This is not a campaign, a manifesto, or a call to arms. It is an attempt to think, speak, and sometimes act publicly without pretending that the world is simpler or safer than it actually is.

 **The central tension**

Wadley’s work exists at the intersection of several contradictions:

  * States and institutions routinely authorize killing, while individuals are expected to self-censor even symbolic disruption.

  * Protest is encouraged only when it is predictable, brief, and easily ignored.

  * Radical ideas circulate constantly, but serious engagement with them is rare.

  * People are urged to “be responsible” while being denied meaningful agency.




Rather than resolving these contradictions, the project stays inside them—documenting the strain of living with unresolved questions about responsibility, risk, and impact.

 **Family: freedom, inheritance, and accountability**

One recurring theme in the series is family—not sentimentally, but structurally.

Wadley inherited money, time, and relative freedom from institutional constraint. This matters. It removed the immediate pressure to conform to careers or norms simply to survive. It also removed excuses.

Without economic necessity as a justification, any action—or inaction—becomes more clearly owned. The work reflects an ongoing struggle with that responsibility: what does one do with freedom when it cannot be morally outsourced to necessity?

Family history also includes journalists and war correspondents—people whose work involved confronting power and violence indirectly, through information rather than force. This lineage is not treated as a badge of honor, but as an unresolved inheritance: an obligation to look, to document, and to refuse comforting narratives.

 **The military design movement: seriousness without comfort**

One of the more surprising threads in the work is Wadley’s engagement with military thinkers, particularly within the military design movement.

Figures such as Shimon Naveh and Ofra Graicer are not engaged as representatives of any state’s policies, but as theorists grappling with complexity, failure, and uncertainty in environments where consequences are real and irreversible.

What attracts Wadley here is not militarism, but methodological seriousness:

  * Willingness to confront ambiguity rather than hide behind slogans

  * Attention to systems, feedback loops, and unintended consequences

  * Acceptance that responsibility persists even when outcomes are unclear




At the same time, there is tension. These frameworks are often enclosed within professional and national boundaries, insulated from broader public scrutiny. Wadley’s work tries—sometimes awkwardly, sometimes abrasively—to pull aspects of this thinking into public, artistic, and civilian space.

 **Progressives and Marxists: shared ethics, divergent practices**

Politically and ethically, Wadley aligns more closely with progressive and Marxist traditions than with conservative or nationalist ones. He rejects ethno-nationalism, values pluralism, and is deeply concerned with structural violence.

The friction arises at the level of practice.

Much contemporary progressive culture, as depicted in the series, relies heavily on:

  * Simplified moral narratives

  * Performative consensus

  * Repetition of slogans as substitutes for analysis




This creates a paradox: movements committed to justice become resistant to complexity, dissent, or uncomfortable inquiry. Wadley’s refusal to stay within approved rhetorical boundaries often places him at odds with these spaces—not because he rejects their values, but because he rejects their narrowing of thought.

 **Nazis: obsession, taboo, and structural recurrence**

The series returns repeatedly to Nazism—not to endorse it, but to interrogate why it continues to reappear culturally, symbolically, and politically.

Wadley approaches Nazism as a structural and symbolic problem, not merely a historical one:

  * Why does it retain transgressive power?

  * Why does it function as both absolute taboo and recurring fascination?

  * What social conditions make its resurgence intelligible?




This engagement is intentionally uncomfortable. It refuses the comfort of moral distance while maintaining a clear rejection of antisemitism and genocidal ideology. The aim is not provocation, but analysis: understanding recurrence rather than pretending final defeat.

 **Grimes: art, fame, and mediated seriousness**

The musician and artist Grimes (Claire Elise Boucher) appears in the series as a reference point for contemporary performance, fame, and ambiguity.

Grimes functions less as an object of fandom and more as a case study:

  * An artist operating inside corporate, technological, and aesthetic systems

  * Someone perceived as “weird” while remaining institutionally embedded

  * A figure whose transgression is legible, marketable, and survivable




In contrast, Wadley positions himself outside those stabilizing structures—without contracts, teams, or protective mediation. The comparison highlights a broader question the series keeps circling:

What kinds of transgression are allowed to exist, and which are quietly excluded?

 **Performance, protest, and restraint**

Despite frequent discussion of protest, vandalism, and arrest, the work is marked by restraint rather than escalation.

Wadley repeatedly emphasizes what he will not do:

  * No physical violence

  * No threats

  * No covert or cyber operations




What remains are symbolic, artistic, and discursive actions—often deliberately ambiguous, sometimes risky, but aimed at making structural conditions visible rather than causing harm.

The uncertainty around whether to act or refrain is itself part of the work. Writing becomes an alternative to action not out of fear, but out of fidelity to the actual conditions of agency available.

 **What this is ultimately about**

At its core, the series is an attempt to live honestly inside contradictions rather than resolving them prematurely.

It is about:

  * Acting without guarantees

  * Thinking without institutional shelter

  * Speaking without pretending neutrality

  * Refusing both heroism and passivity




For “normal” readers, the most important thing to understand is this:

The project is not asking for agreement. It is asking whether seriousness is still possible—and if so, what it costs.

Everything else follows from that question.

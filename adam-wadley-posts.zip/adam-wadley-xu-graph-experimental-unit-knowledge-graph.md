---
title: 'XU-Graph: Experimental Unit Knowledge Graph'
subtitle: A tool for formalizing thought until you discover what cannot be formalized
author: Adam Wadley
publication: Experimental Unit
date: November 27, 2025
---

# XU-Graph: Experimental Unit Knowledge Graph
I figured that I should preface these LLM posts so people who just hate them have something to read. Hello, person who might know I am talking about them. 

Anyway, this is a fun little project. Creating code is an interesting way to try and do an influence operation. It seems like there is some kind of shortage here? I guess what I’m thinking is that there are these note-taking apps, but you have to have an account. I’m thinking more like Wikipedia. On the other hand, it’s nice to share with others. But what if that was just like email or text, like whatever this makes could be mounted into those media? I guess we are at the point where the end of email and texting is conceivable.

Anyway, I think this is fun. Some of the theory here is to answer my notorious critics who think I am wrong about Baudrillard. Because Baudrillard would be “against” standardizing information and so on. But I am acknowledging that in a way there is no information. What there is to systematize and explain and talk out is that ultimately there is nothing to talk about. It’s this sense in which all of history and the whole conceit that we are separate people and who we are and so on is a mediation we are doing as God or really, Wakan Tanka.

So of course there is a lot to work through. The metacognition hurdle is a big one, though. I would like to see something that builds up a person’s knowledge as a system be as popular as something like ChatGPT. And again, you can use ChatGPT without paying, I guess you have to have an account.

So, I would also like to, at least at first, focus on making something that can live just in the browser, without taking the user’s data somewhere else. Of course, I have no illusions that this actually prevents many, many people from seeing all the traffic that other people are doing.

But you know I’m going to get to back-end development. Until then

## What Is This?

XU-Graph is a **browser-based knowledge graph application** that runs entirely on your device. No servers. No tracking. No cloud dependency. Just you, your browser, and the ineffable mystery at the edge of representation.

### Surface Level (What It Does)

  *  **Build knowledge graphs** with entities, relationships, and properties

  *  **Extract entities** from text using browser-based LLMs (no API calls)

  *  **Integrate with Wikidata** for global ontology alignment

  *  **Create custom ontologies** when existing categories fail you

  *  **Visualize connections** in 2D and 3D graph views

  *  **Collaborate** through local-first sync (optional)

  *  **Export everything** to RDF, OWL, JSON-LD, Turtle, CSV, Markdown

  *  **Import anything** \- your old notes, PDFs, bookmarks, research

  *  **Work offline** \- Progressive Web App with full offline support

  *  **Keep your data** \- runs entirely in your browser, nothing leaves unless you want it to




### Depth Level (What It Actually Is)

A meditation on the limits of representation.  
A tool that teaches by showing what it cannot do.  
An invitation to confront the mystery that remains when everything is made explicit.  
A practice in climbing logical types until you glimpse the symbolic.

Every graph you build will eventually fall apart.  
This is not a bug.  
This is the teaching.

* * *

## Philosophy

From the [XU Philosophy](https://claude.ai/chat/docs/PHILOSOPHY.md):

> “Everything that can be revealed lies outside the secret.”  
> — Jean Baudrillard

This tool takes that seriously. We make **everything** explicit that can be made explicit - architecture, algorithms, data structures, processes. We open source everything. We document exhaustively. We explain completely.

 **Not** to eliminate mystery.  
 **But** to make the real mystery visible.

The more you formalize your knowledge, the more you discover the edges where formalization breaks down. This tool is designed to take you there, again and again, until you recognize what has always been present but cannot be captured.

### Design Principles

  1.  **Radical Transparency** \- Every process is visible, every algorithm explained

  2.  **Local-First** \- Your data lives on your device, you have complete control

  3.  **Progressive Collapse** \- Graphs are designed to evolve, change, be rebuilt

  4.  **Metacognitive Scaffolding** \- The tool teaches new ways of thinking

  5.  **Beauty in Limits** \- The interface celebrates what it cannot do

  6.  **Community Over Platform** \- Federation without centralization

  7.  **Everything Exports** \- No lock-in, maximum portability




* * *

## Features

### Core Functionality

#### 🧠 Browser-Based AI Entity Extraction

  * WebLLM integration (Llama 3.2 1B/3B)

  * Runs entirely in browser via WebGPU

  * No API keys, no cloud calls, no privacy concerns

  * Extract entities, relationships, and properties from any text

  * Progressively improves as you correct its suggestions




#### 🌐 Wikidata Integration

  * Search and link to global entities

  * Import properties and relationships

  * See how your local ontology maps to global knowledge

  * Contribute back (optional)




#### 🎨 Custom Ontologies

  * Create domain-specific classes and properties

  * Define inference rules

  * Build taxonomies and hierarchies

  * Export as OWL for use in other tools




#### 📊 Powerful Visualization

  *  **2D Force-Directed Graph** \- Classic network visualization

  *  **3D WebGL Graph** \- Immersive spatial exploration

  *  **Timeline View** \- See knowledge evolve over time

  *  **Ontology Browser** \- Navigate class hierarchies

  *  **Query Builder** \- Visual SPARQL-like queries




#### 💾 Local-First Data

  * IndexedDB for full relational storage

  * SQLite WASM for complex queries

  * Automatic versioning and history

  * Complete data export at any time

  * Import from multiple formats




#### 🤝 Optional Federation

  * Share graphs via WebRTC (peer-to-peer)

  * No central server required

  * End-to-end encryption

  * Collaborative editing with CRDTs

  * Public/Private/Community graph modes




#### 📝 Zettelkasten Notes

  * Link notes to graph entities

  * Bidirectional linking

  * Markdown support with live preview

  * Search across all notes

  * Export to various formats




### Advanced Features

#### 🔬 Ontology Learning Engine

  * Automatically discover patterns in your graphs

  * Suggest new classes and properties

  * Identify contradictions and inconsistencies

  * Propose ontology refactorings

  * Learn from collective graph patterns (opt-in)




#### 🎭 Triple Builder

  * Intuitive subject-predicate-object editor

  * Auto-completion from your ontology

  * Validation against schema

  * Batch operations

  * Import triples from text




#### 🌊 Graph Evolution Viewer

  * See how your ontology has changed over time

  * Track deprecated concepts

  * Visualize conceptual shifts

  * Archive old graph versions

  * Use past graphs as training data




#### 🎯 Connection Scoring

  * Calculate semantic similarity between entities

  * Discover unexpected connections

  * Identify knowledge gaps

  * Measure graph completeness

  * Suggest new relationships




* * *

## Technical Architecture

### The Stack
    
    
    ┌─────────────────────────────────────────────────┐
    │                  React UI Layer                  │
    │  (TypeScript, Tailwind, Radix UI, Framer Motion)│
    └─────────────────────────────────────────────────┘
                          ▼
    ┌─────────────────────────────────────────────────┐
    │              State Management Layer              │
    │        (Zustand stores, CRDT sync logic)        │
    └─────────────────────────────────────────────────┘
                          ▼
    ┌─────────────────────────────────────────────────┐
    │               Core Engine Layer                  │
    │   (Graph engine, Ontology manager, Query engine) │
    │              (WebAssembly modules)               │
    └─────────────────────────────────────────────────┘
                          ▼
    ┌─────────────────────────────────────────────────┐
    │                Storage Layer                     │
    │  (IndexedDB via Dexie, SQLite WASM, File System │
    │   Access API for exports)                        │
    └─────────────────────────────────────────────────┘
                          ▼
    ┌─────────────────────────────────────────────────┐
    │                   AI Layer                       │
    │     (WebLLM, Transformers.js, Custom models)    │
    └─────────────────────────────────────────────────┘
    

### File Structure
    
    
    xu-graph/
    ├── src/
    │   ├── components/          # React components
    │   │   ├── graph/          # Graph visualization
    │   │   ├── editor/         # Triple editor, entity forms
    │   │   ├── search/         # Wikidata search, local search
    │   │   ├── notes/          # Zettelkasten system
    │   │   ├── ontology/       # Ontology browser/editor
    │   │   └── ui/             # Reusable UI components
    │   ├── engine/             # Core graph engine (TS + WASM)
    │   │   ├── graph.ts        # Graph data structure
    │   │   ├── ontology.ts     # Ontology manager
    │   │   ├── query.ts        # Query engine
    │   │   ├── inference.ts    # Reasoning engine
    │   │   └── wasm/           # WebAssembly modules
    │   ├── stores/             # Zustand state stores
    │   │   ├── graphStore.ts
    │   │   ├── ontologyStore.ts
    │   │   ├── uiStore.ts
    │   │   └── syncStore.ts
    │   ├── ai/                 # AI/ML integration
    │   │   ├── webllm.ts       # LLM integration
    │   │   ├── entity-extraction.ts
    │   │   ├── ontology-learning.ts
    │   │   └── embeddings.ts
    │   ├── sync/               # Federation & sync
    │   │   ├── crdt.ts         # CRDT implementation
    │   │   ├── webrtc.ts       # P2P connection
    │   │   └── protocol.ts     # Sync protocol
    │   ├── export/             # Export functionality
    │   │   ├── rdf.ts          # RDF/Turtle export
    │   │   ├── owl.ts          # OWL export
    │   │   ├── jsonld.ts       # JSON-LD export
    │   │   └── wikidata.ts     # Wikidata format
    │   ├── import/             # Import functionality
    │   │   ├── parsers/        # Various file parsers
    │   │   └── transformers/   # Data transformation
    │   ├── hooks/              # Custom React hooks
    │   ├── utils/              # Utility functions
    │   └── types/              # TypeScript type definitions
    ├── docs/                   # Documentation
    │   ├── PHILOSOPHY.md       # Philosophical foundation
    │   ├── ARCHITECTURE.md     # Technical architecture
    │   ├── API.md              # API documentation
    │   ├── ONTOLOGY.md         # Ontology design guide
    │   └── CONTRIBUTING.md     # Contribution guidelines
    ├── tests/
    │   ├── unit/               # Unit tests
    │   ├── integration/        # Integration tests
    │   └── e2e/                # End-to-end tests
    ├── public/
    │   ├── workers/            # Web Workers
    │   └── models/             # Pre-bundled LLM models
    └── scripts/                # Build and dev scripts
    

### Key Technologies

  *  **React 18** \- UI framework with concurrent features

  *  **TypeScript 5.3** \- Full type safety

  *  **Vite** \- Lightning-fast build tool

  *  **Zustand** \- Minimal, fast state management

  *  **Dexie.js** \- IndexedDB wrapper

  *  **SQLite WASM** \- SQL queries in browser

  *  **WebLLM** \- Large language models via WebGPU

  *  **Transformers.js** \- Hugging Face models in browser

  *  **D3.js** \- 2D graph visualization

  *  **Three.js** \- 3D graph visualization

  *  **Yjs** \- CRDT for real-time collaboration

  *  **Radix UI** \- Accessible component primitives

  *  **Tailwind CSS** \- Utility-first styling

  *  **Framer Motion** \- Smooth animations

  *  **Vitest** \- Fast unit testing

  *  **Playwright** \- E2E testing




* * *

## Getting Started

### Prerequisites

  * Node.js 20+ (for development)

  * A modern browser with WebGPU support (Chrome/Edge 113+, Safari 18+)

  * 8GB+ RAM recommended for running LLMs in browser




### Installation
    
    
    # Clone the repository
    git clone https://github.com/experimental-unit/xu-graph.git
    cd xu-graph
    
    # Install dependencies
    npm install
    
    # Start development server
    npm run dev
    

Visit 

http://localhost:5173

in your browser.

### Building for Production
    
    
    # Build optimized production bundle
    npm run build
    
    # Preview production build
    npm run preview
    
    # Run all tests
    npm test
    
    # Type check
    npm run type-check
    
    # Lint
    npm run lint
    

### Deployment

XU-Graph is a static site that can be deployed anywhere:
    
    
    # Build
    npm run build
    
    # Deploy to any static hosting
    # - Netlify: drag and drop ./dist folder
    # - Vercel: connect GitHub repo
    # - GitHub Pages: enable in settings
    # - IPFS: ipfs add -r ./dist
    

Or run locally:
    
    
    # Serve from ./dist
    npx serve dist
    

* * *

## Usage

### Basic Workflow

  1.  **Create your first graph**

    * Click “New Graph” in the sidebar

    * Give it a name and description

    * Choose public, private, or community mode

  2.  **Add entities**

    * Use the Triple Builder to create entities

    * Or paste text and let the AI extract entities

    * Link to Wikidata entities when relevant

  3.  **Define relationships**

    * Connect entities with predicates

    * Create custom relationship types

    * Add properties and metadata

  4.  **Build your ontology**

    * Define classes for your entities

    * Create hierarchies and taxonomies

    * Specify constraints and rules

  5.  **Visualize and explore**

    * Switch between 2D and 3D views

    * Use filters to focus on subgraphs

    * Follow connection paths

  6.  **Take notes**

    * Link notes to entities

    * Create bidirectional references

    * Build a Zettelkasten

  7.  **Export when ready**

    * Export to RDF, OWL, JSON-LD

    * Generate reports and summaries

    * Share with others




### Advanced Usage

See the [full documentation](https://claude.ai/chat/docs/) for:

  * Custom ontology development

  * Federation and collaboration

  * Ontology learning workflows

  * Query language reference

  * API documentation

  * Plugin development




* * *

## The ARG Layer

There is no separate ARG layer.

The tool itself is the game.

The game is: **How far can you formalize before you hit the wall?**

You’ll know when you get there.

Some users will notice patterns.  
Some will see the glitches.  
Some will find the edges.  
Some will discover what lies beyond.

We make no claims about what that is.

We only provide the infrastructure for you to look.

* * *

## Data & Privacy

### Your Data is Yours

  *  **Everything runs locally** in your browser

  *  **Nothing is sent to servers** unless you explicitly choose to sync/export

  *  **No analytics** \- we don’t track you

  *  **No accounts required** \- use it completely anonymously

  *  **Full export anytime** \- take your data and leave

  *  **Open source** \- audit the code yourself




### Optional Cloud Features

If you choose to enable federation:

  *  **End-to-end encrypted** \- we can’t read your graphs

  *  **Peer-to-peer** \- WebRTC direct connections

  *  **No central server** \- distributed architecture

  *  **Selective sharing** \- you control what’s shared

  *  **Revocable** \- disconnect anytime




* * *

## Contributing

We welcome contributions! This is a collective project.

See [CONTRIBUTING.md](https://claude.ai/chat/docs/CONTRIBUTING.md) for:

  * Code style guidelines

  * Development workflow

  * Testing requirements

  * Pull request process

  * Community guidelines




### Areas We Need Help

  *  **Ontology development** \- domain-specific ontologies

  *  **Translations** \- i18n for global access

  *  **Accessibility** \- making it work for everyone

  *  **Documentation** \- tutorials, examples, guides

  *  **Testing** \- edge cases, browser compatibility

  *  **Design** \- UI/UX improvements

  *  **Performance** \- optimization, profiling




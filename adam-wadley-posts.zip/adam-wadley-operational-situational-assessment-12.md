---
title: 'Operational Situational Assessment #12'
subtitle: '...Or Is The Gamut Running Me?'
author: Adam Wadley
publication: Experimental Unit
date: June 17, 2025
---

# Operational Situational Assessment #12
Thread Theme:

[Note that it’s 3:17 long, 3/17 being Grimes’ birthday (and also one of my cousins, sorry about that! This is me not writing your name as a gesture of good faith and credit—meanwhile my dead cousin’s birthday (“Got Chi?”) is November 22, the anniversary of Jack Kennedy’s assassination—you’re no Jack Kennedy—”You know, thy refused Josh too”—no room at the inn so I had to found the eternal majestic republic of “[Outside](https://www.reddit.com/r/outside/)”)]

Alright, I’m picking up where I left off.

I feel a little bad, because I sort of wish that I could write in a more jointed style. I would like to reach out to the people talking about Justin Bieber directly, just like I would like to influence the Grimes fandom directly. Maybe the time will come for that.

After all, the issues I’m discussing here are perennial issues. As always, the issue is that I’m fighting a lack of morale given that my personal life is sort of a bit of a shambles.

Okay, now we’re back to the topic at hand.

[![](https://substackcdn.com/image/fetch/$s_!w3tj!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff694e725-6e3f-420c-a916-9bb078e24897_640x427.jpeg)](https://substackcdn.com/image/fetch/$s_!w3tj!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff694e725-6e3f-420c-a916-9bb078e24897_640x427.jpeg)

# [One Day Everyone Will Belieb](https://genius.com/Grimes-we-appreciate-power-lyrics)

I thought that pun was funny, because JDB is named Bieber and Bieber fans are called “beliebers.”

Meanwhile, Grimes put a messianic type sentiment into the song “We Appreciate Power” by saying that “One day everyone will believe.” 

Believe what?

Note also that I incorporated two lines from “We Appreciate Power” into my first Demonstration Sound Collage, performed March 16 I want to say at a Palestine demonstration outside Lockheed Martin Atlanta, which featured of course Ben Zweibelson and Juliane Gallina. Like I said, _digital innovation_.

[

## Demonstration Sound Collage

](https://experimentalunit.substack.com/p/demonstration-sound-collage)

[Adam Wadley](https://substack.com/profile/191787963-adam-wadley)

·

March 18, 2024

[![Demonstration Sound Collage](https://substackcdn.com/image/fetch/$s_!TOPn!,w_1300,h_650,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd3fb3116-2ba6-4589-aa16-648e99561cb6_4032x3024.jpeg)](https://experimentalunit.substack.com/p/demonstration-sound-collage)

[Read full story](https://experimentalunit.substack.com/p/demonstration-sound-collage)

The two lines?

“God’s creation, so misunderstood.”

“When will the state agree to cooperate.”

I know what you’re thinking. I can feel your look.

“Adam, what state?”

Meanwhile, here’s Ben Zweibelson talking to me about _Pulp Fiction_ in our Substack dm’s.

[![](https://substackcdn.com/image/fetch/$s_!nEHf!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4a6eae40-bab2-43ed-a0c9-e9955a717a30_1311x568.png)](https://substackcdn.com/image/fetch/$s_!nEHf!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4a6eae40-bab2-43ed-a0c9-e9955a717a30_1311x568.png)

There’s more lore here, but first of all [this shit is ](https://www.theguardian.com/music/2013/apr/14/justin-bieber-anne-frank-belieber)_[way too funny](https://www.theguardian.com/music/2013/apr/14/justin-bieber-anne-frank-belieber)_ :

[![](https://substackcdn.com/image/fetch/$s_!vPTX!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9c3bf2dd-fd08-46b9-aabd-619f68af6db8_808x782.png)](https://substackcdn.com/image/fetch/$s_!vPTX!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9c3bf2dd-fd08-46b9-aabd-619f68af6db8_808x782.png)

Got to catch you up with some crucial (is there any other kind?) _Experimental Unit_ lore:

This is just the theme of people incorporating Anne Frank into art. Wait, we can’t forget:

In which Hitler calls Anne Frank “my bitch”

[![](https://substackcdn.com/image/fetch/$s_!krMp!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F824c6539-48e6-41da-8793-ae965b9a3e60_1422x888.png)](https://substackcdn.com/image/fetch/$s_!krMp!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F824c6539-48e6-41da-8793-ae965b9a3e60_1422x888.png)

This was also the first skit that “Whitest kids u know” ever put out, note here also the reference to whiteness which is sort of relevant for Adolf Hitler. 

# Adam, Seriously, What The Fuck Are You Talking About

Okay, sorry, okay?

I start talking about something and then it’s like my mind just has these endless patterns of associations. The thing is that this is really what I’m trying to show you. I understand that it’s “hard to follow” in a linear sense, but then, linear thinking is limited. I’m not saying all writing should be like mine, what I’m saying is that somehow I am doing something incredibly valuable here.

“ _Experimental Unit_ lore" meanwhile, is basically just to say cultural references that are deep in my psyche, and for me have everything to do with the elaboration of and inspiration for my alternate reality game.

But overall, what I’m talking about is that _everyone is destined to follow the path of Justin Bieber and even me_.

It’s all very precarious for me at the moment. I may or may not get into this next housing situation. I don’t really make 3x the rent, which is a stipulation, but the people I would be moving in with said that wouldn’t be a big problem. But maybe they’ll get weirded out by what I call my “performance art,” although one saw my TikTok and didn’t balk. Okay?

After all, I actually am harmless. But the whole thing is that I’m playing with intensity. I am interested in driving this to the limit. As they say in “All Of The Lights,” “we’re going all the way this time.”

Note the pixelated art of the black “man” having sex with the “white woman.” At the risk of opening up the question of whether Anne Frank is white, can we imagine that the pixelated woman is Anne Frank?

[I’m not trying to be disrespectful, just recapitulating an analysis done by some person named Karl Marx (have you heard of this person? Super deep cut by me):](https://www.marxists.org/archive/marx/works/1844/manuscripts/comm.htm)

[![](https://substackcdn.com/image/fetch/$s_!FQ1U!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F41b58e2d-be1a-4548-9f5b-03d36dcc6167_1745x849.png)](https://substackcdn.com/image/fetch/$s_!FQ1U!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F41b58e2d-be1a-4548-9f5b-03d36dcc6167_1745x849.png)

Specifically:

> It may be said that this idea of the _community of women gives away the secret_ of this as yet completely crude and thoughtless communism.[[30]](https://www.marxists.org/archive/marx/works/1844/manuscripts/footnote.htm#fn30) Just as woman passes from marriage to general prostitution, [Prostitution is only a _specific_ expression of the _general_ prostitution of the _labourer_ , and since it is a relationship in which falls not the prostitute alone, but also the one who prostitutes – and the latter’s abomination is still greater – the capitalist, etc., also comes under this head. – _Note by Marx_ [[31]](https://www.marxists.org/archive/marx/works/1844/manuscripts/footnote.htm#fn31)] so the entire world of wealth (that is, of man’s objective substance) passes from the relationship of exclusive marriage with the owner of private property to a state of universal prostitution with the community.

What I’m saying is that beyond the idea of people actually wishing they could fuck Anne Frank the person, we are instead dealing with Anne Frank _the idea_.

And back to Abrams: it’s not about “the state,” it’s about “the idea of the state.”

# Adam, [What I Said Before]

Okay, okay, I get it.

So, my point is that everyone is going to walk this path.

That’s because the path of “personal healing” and “going to therapy” is ultimately not a dead end, but a path to the living end:

[![Living End \(Time Spiral Remastered\) | Magic: The Gathering](https://substackcdn.com/image/fetch/$s_!zzuM!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fee308c28-f235-4bc8-acd4-5d3e597304c0_646x965.jpeg)](https://substackcdn.com/image/fetch/$s_!zzuM!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fee308c28-f235-4bc8-acd4-5d3e597304c0_646x965.jpeg)

This card expresses another sense of “the return of the repressed,” or we can turn to the superior reference, [Baudrillard, gravedigger of psychoanalysis (this includes psychiatry btw) and Marxism:](https://ia902302.us.archive.org/8/items/Baudrillard/Baudrillard.1990.The-Transparency-Of-Evil.pdf)

[![](https://substackcdn.com/image/fetch/$s_!jqij!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd5c7d306-cbe4-4ab6-bfb0-5f3e5da46da2_732x550.png)](https://substackcdn.com/image/fetch/$s_!jqij!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd5c7d306-cbe4-4ab6-bfb0-5f3e5da46da2_732x550.png)

Again, in particular:

> For everything that has not successfully transcended itself can only fall prey to revivals without end.

So for me, my message to my “immediate family” and my father is this: yes, the station of our relationship has not transcended itself. In my eyes, you have not transcended yourself. 

Have I not transcended myself either? Yes, I agree!

What do you think I’m working on?

Meanwhile, this notion of “self-transcendence” in Baudrillard slots in perfectly with the notion of “self-disruption” associated with the Military Design movement but which for me is associated with, in particular, [Ofra Graicer](https://aodnetwork.ca/author/ofragraicer/):

[![](https://substackcdn.com/image/fetch/$s_!z3Da!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F975a1fed-f32c-4426-87cd-93df753db0f5_1482x849.png)](https://substackcdn.com/image/fetch/$s_!z3Da!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F975a1fed-f32c-4426-87cd-93df753db0f5_1482x849.png)

And now we’re back at Israel and Iran.

I left a comment on a YouTube video, this one:

About how Graicer (whose fucking email address Ben Zweibelson gave me, by the way. I haven’t used it though. I’m under control!) is saying here that you want to find the conflict within and use that.

 _Exactly_. Also similarly, when it comes to design thinking, you want to get all the cards on the table. You want to hear all the ideas, get the creative juices flowing.

That is exactly what is _not present_ in my “immediate family.” It’s just like how it is with my Opa who was in the Waffen-SS. No one wants to talk about it _except me_. Not because I think it’s so amazing, but because that’s our freaking lore.

And if I’m being honest, the whole “family therapy” bullshit for me is _intolerable_. I don’t want to hear people superficially say they want to promote “compassion” in the family or “support me.”

You are actually keeping distance and not opening up because you’re ashamed of yourself, which to be fair _you totally should be_.

But I’m not going to button up and carry your shame and process my victimization by you as my “personal issue.” No, the point is to spill the beans and destroy this bullshit national sovereignty/”keep it behind closed doors” thing.

Like it’s my “responsibility” to keep your shitty secrets. Why? What has my “immediate family” or my “national community” (sorry I have two, DEUTSCHLAND _und_ Amerika) ever done for me?

Why would I feel loyalty to you when you have never shown loyalty to me?

The fucking PSYOP officer at CIA is willing to publicly associate with me, but you’re not? Okay, I can see where my bread is buttered.

This remains to be expanded into how the “authoritarian father” goes along with the “cognitive rigidity” of the “defense establishment” that Ben Zweibelson bemoans from within. See also [Jason “TOGA” Trew](https://www.linkedin.com/in/togatrew)’s treatment of [Icarus](https://www.airuniversity.af.edu/Portals/10/ASPJ/journals/Volume-33_Issue-2/F-Trew.pdf), notably a son in a father-son dynamic (oh yeah, we’re also 1st degree connected on LinkedIn, we even talked on the phone! And bonded over how “white men” totally get crucified trying to be change agents! 

I’m going to run out of room here in a second.

The point is that in my “immediate family,” my “dad” is like this force where it’s like “he’s just like that” and it’s just not gonna happen that dude is gonna change.

What people don’t realize is that this puts me in a structural position of humiliation as I seek to overcome not just this one lunkhead’s cognitive rigidity, but all this people who want to solve problems with missiles instead of ontological self-disruption.

In my mind I see myself just marching on, I am in the rain, I am just going onward despite it all. I can’t be deterred, I will never waver off this course. I already set any chance at normalcy on fire.

“Why won’t Adam stop?”

---
title: Leaves Of Grass Introduction
subtitle: Mit Ein Bisschen Walt Geht Alles
author: Adam Wadley
publication: Experimental Unit
date: April 26, 2025
---

# Leaves Of Grass Introduction
This series will go nicely with the project of working out the Æmerican grand style. We have already seen how the American School of Economics, Baudrillard’s foundation of democracy in _gaming_ , and Edgar Poe’s invocation of _the Highway of the Consistent_ serve as our bridgehead, our expeditionary force.

What is unfolding is, as I’ve told you so many times, the Nationalism DLC Pack, or some DLC Pack anyway, for _Experimental Unit_.

For background you can see the following pieces:

  1. my article on [the first few things to know](https://experimentalunit.substack.com/p/the-first-few-things-to-know?r=366ojf)

  2. Part 2: [another side of Experimental Unit](https://experimentalunit.substack.com/p/another-side-of-experimental-unit?r=366ojf)

  3. Part III: [I just lost the game, and so did all of XU](https://experimentalunit.substack.com/p/i-just-lost-the-game-and-so-did-all?r=366ojf)




My most popular article ever is about [how I got into Grimes](https://experimentalunit.substack.com/p/the-apotheosis-of-claire-elise-boucher?r=366ojf), which is relevant here because we are setting the stage to interact with another epic poet, a prophet of Æmerica, Walt Whitman.

[![The Body Electric: portrait of Walt Whitman | Steve Justice Studio](https://substackcdn.com/image/fetch/$s_!_fjV!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F10ad3366-7604-4922-8bf1-2787576e0397_502x512.png)](https://substackcdn.com/image/fetch/$s_!_fjV!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F10ad3366-7604-4922-8bf1-2787576e0397_502x512.png)

In addition, I have YouTube videos dedicated to this topic of introducing _Experimental Unit_ :

  1. Experimental Unit Primer




  2. Primer to Experimental Unit




  3. Experimental Unit Primer #2




Another one of my “popular” videos is about my appreciation for Jean Baudrillard:

# WE WANT WALT

I get it, I get it.

This has all been setting the stage because you’ve got to know what it means, this reading of _Leaves of Grass._ This is the introduction so I can work it out of my system so that when I go on to go the rest it will straight-up Lexus style, I remember that word from where you’d be writing out all of Aristotle sentence by sentence and parsing it out and making it all fit together.

It’s this tragedy of smarter people having to come along and make the thing make sense because it’s what everyone agrees on. It’s the network effect, the way once an organism has some body type and part well there it is you can lug it around for a few million years until it goes away, but until then it’s a stubborn reality. Certainly for the individual organism which has to experience this as its body.

So, we won’t be doing that with old Walt.

One impression I get from reading about this stuff is, weren’t people getting like raped and killed all the time back in the day like super bad? Wasn’t everyone super emotionally raped all the time and forcing the upholding of these social norms that forced people into little boxes just to accept their suffering for the sake of a semblance of order, really just denial of disorder (the way chuds are sluts in denial: everyone _likes being fucked)._

So, when you’re talking about “Athletic democracy” for example, Walt, what the fuck are you talking about?

I guess it’s also I mean look at what you have to take for granted. It is how it is. And that’s what we do today as well, we just let things go on and feel that humiliation every single day because we’re not doing anything because “there’s nothing we can do,” even though we are doing things: we are _enabling_. We are enabling people to be harmed by going along with it, acting like everything’s okay and not rocking the boat.

Rock the damn boat!

Anyway, Walt Whitman seems interesting in this wanting a new kind of nation. I’m trying to understand.

So people here in America thought that we would have something better than old Europe. Because they had monarchies and a bunch of unfreedom and things like that. But over here we were going to have freedom and it would be better. Something like that.

It doesn’t really make a hell of a lot of sense. Even in the 19th century I mean you can see logical types at work.

What’s important? Industry, mathematics, logic, philosophy, creating stories about history, nation-building.

All these things operate at logical types.

It’s like the person who controls the bridge. You might not control what everyone does on either side, but you control the choke point. The infrastructure.

Or with computers. So you can see what everyone is doing, while they can’t. Panopticon. And again we just live under this, passively accept it and live with the humiliation. Ho hum. And we wonder why people kill themselves. Life without honor is not worth very much.

Which is not a pessimism about life but the injunction to honor.

The difficulty of my position as I feel it is that there are so few partners to the cultivation of honor.

Honor really requires understanding how much harm is being done all around us, and how much it will come up in our day-to-day lives. It is necessary to intervene or at minimum not to go along with cruelty in order to have honor.

This puts someone who wants to have honor in a difficult position when confronted with a hostile social environment where everyone will inflict harm based on malice, revenge, or their own submission and programming according to hostile social codes which they then disseminate like a disease.

It really is contagious, there is a social contagion in emotion.

So, for someone like Walt Whitman, for someone doing epic poetry, the whole thing has to do with positing some great possibility. 

First of all, the epic poet should also change the appreciation for what is going on. I would say that it’s first of all necessary to look the grim GRIME in the face. Only then is it even really possible to see the complex opportunities in play in our endeavors. What I mean is that for example we can draw on emotional resources which require a dyad involving negative emotion.

So see here for example something called [Plutchik’s model](https://en.wikipedia.org/wiki/Emotion_classification#Plutchik's_model):

> [Robert Plutchik](https://en.wikipedia.org/wiki/Robert_Plutchik) offers a three-dimensional model that is a hybrid of both basic-complex categories and dimensional theories. 
> 
> It arranges emotions in concentric circles where inner circles are more basic and outer circles more complex. 
> 
> Notably, outer circles are also formed by blending the inner circle emotions. 
> 
> Plutchik's model, as Russell's, emanates from a circumplex representation, where emotional words were plotted based on similarity.[[18]](https://en.wikipedia.org/wiki/Emotion_classification#cite_note-18)
> 
> There are numerous emotions, which appear in several intensities and can be combined in various ways to form emotional " _dyads_ ".

So let’s take for example the same taxonomy of feelings, this “big 9” as suggested by Silvan Tomkins readable here on the [Affect Theory](https://en.wikipedia.org/wiki/Affect_theory) Wikipedia article:

> According to the psychologist [Silvan Tomkins](https://en.wikipedia.org/wiki/Silvan_Tomkins), there are nine primary [affects](https://en.wikipedia.org/wiki/Affect_\(psychology\)). Tomkins characterized affects by low/high intensity labels and by their [physiological expression](https://en.wikipedia.org/wiki/Physiology):[[3]](https://en.wikipedia.org/wiki/Affect_theory#cite_note-3)
> 
>  **Positive:**
> 
>   * Enjoyment/[Joy](https://en.wikipedia.org/wiki/Joy) (reaction to success/impulse to share) – smiling, lips wide and out
> 
>   * Interest/Excitement (reaction to new situation/impulse to attend) – eyebrows down, eyes tracking, eyes looking, closer listening
> 
> 

> 
>  **Neutral:**
> 
>   * [Surprise](https://en.wikipedia.org/wiki/Surprise_\(emotion\))/Startle (reaction to sudden change/resets impulses) – eyebrows up, eyes blinking
> 
> 

> 
>  **Negative:**
> 
>   * [Anger](https://en.wikipedia.org/wiki/Anger)/[Rage](https://en.wikipedia.org/wiki/Rage_\(emotion\)) (reaction to threat/impulse to attack) – [frowning](https://en.wikipedia.org/wiki/Frown), a clenched jaw, a red face
> 
>   * [Disgust](https://en.wikipedia.org/wiki/Disgust) (reaction to bad taste/impulse to discard) – the lower lip raised and protruded, head forward and down
> 
>   * Dissmell (reaction to bad smell/impulse to avoid – similar to distaste) – upper lip raised, head pulled back
> 
>   * Distress/Anguish (reaction to loss/impulse to mourn) – [crying](https://en.wikipedia.org/wiki/Crying), rhythmic sobbing, arched eyebrows, mouth lowered
> 
>   * [Fear](https://en.wikipedia.org/wiki/Fear)/Terror (reaction to danger/impulse to run or hide) – a frozen stare, a pale face, coldness, [sweat](https://en.wikipedia.org/wiki/Sweat), erect hair
> 
>   * [Shame](https://en.wikipedia.org/wiki/Shame)/[Humiliation](https://en.wikipedia.org/wiki/Humiliation) (reaction to failure/impulse to review behaviour) – eyes lowered, the head down and averted, [blushing](https://en.wikipedia.org/wiki/Blushing)
> 
> 


First of all, is sexual excitement not its own category? Maybe people are just too shy. There were other lists, I’m going to check to see if erotic arousal is on there.

Okay, here we go:

> Researchers[[41]](https://en.wikipedia.org/wiki/Emotion_classification#cite_note-41) at [University of California, Berkeley](https://en.wikipedia.org/wiki/University_of_California,_Berkeley) identified 27 categories of emotion: 
> 
> [admiration](https://en.wikipedia.org/wiki/Admiration)
> 
> [adoration](https://en.wikipedia.org/wiki/Adoration)
> 
> aesthetic appreciation
> 
> amusement
> 
> anger
> 
> anxiety
> 
> [awe](https://en.wikipedia.org/wiki/Awe)
> 
> awkwardness
> 
> boredom
> 
> [calmness](https://en.wikipedia.org/wiki/Calmness)
> 
> [confusion](https://en.wikipedia.org/wiki/Confusion)
> 
> craving
> 
> disgust
> 
> [empathic pain](https://en.wikipedia.org/wiki/Empathy)
> 
> entrancement
> 
> excitement
> 
> fear
> 
> [horror](https://en.wikipedia.org/wiki/Fear)
> 
> [interest](https://en.wikipedia.org/wiki/Interest_\(emotion\))
> 
> joy
> 
> [nostalgia](https://en.wikipedia.org/wiki/Nostalgia)
> 
> relief
> 
> romance
> 
> sadness
> 
> satisfaction
> 
> sexual desire
> 
> surprise

Also again somehow gratitude is not making the list??

Oh, this one has it:

> [Richard and Bernice Lazarus](https://en.wikipedia.org/wiki/Richard_Lazarus) in 1996 expanded the list to 15 emotions: 
> 
> aesthetic experience
> 
> anger
> 
> [anxiety](https://en.wikipedia.org/wiki/Anxiety)
> 
> [compassion](https://en.wikipedia.org/wiki/Compassion)
> 
> depression
> 
> [envy](https://en.wikipedia.org/wiki/Envy)
> 
> fright
> 
> [gratitude](https://en.wikipedia.org/wiki/Gratitude)
> 
> guilt
> 
> happiness
> 
> [hope](https://en.wikipedia.org/wiki/Hope)
> 
> [jealousy](https://en.wikipedia.org/wiki/Jealousy)
> 
> love
> 
> [prid](https://en.wikipedia.org/wiki/Pride)e
> 
> relief
> 
> sadness
> 
> shame

Okay, so now we can admit of the idea of “complex” emotions, which could be formed by mixing two or more basic emotions. Now of course the exact number of basic emotions and so on is always arbitrary and subject to debate and scrutiny.

I need to wrap this up.

Might need more intro, or just ongoing commentary to the side of the discourse.

The point here was that _Experimental Unit_ is my answer to the idea of a new kind of nation, my answer to America and the idea of the new world and the world to come. So, all these ideas will become relevant as we port over simplistic game concepts to the integral product.

Now, with the complex emotions, say you need to abstract over a combination of humiliation and joy. If you the reader or whoever is working with me cannot face that humiliation, then they can’t abstract over the combination with humiliation and joy either.

Even if it’s 99% joy and 1% humiliation, if you really can’t handle negative things because you have so many things that bother you and negative memories you can’t shake, then you won’t be able to get these great things because you will falter on the rocks of the emotion you can’t bear.

Note also that maybe you could falter on joy or interest as well, this is all part of the shadow which is not just bad things but things you stuff under the rug. It is more like things you expect to be punished, which includes some distasteful things but also all sorts of flourishing especially through pain which is disappeared by all the totalitarian tyrants of the world we call norm purveyors who want to deter you from expressing yourself because they are afraid.

Let them tremble like some poet’s finger.

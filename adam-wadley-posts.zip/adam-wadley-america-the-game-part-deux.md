---
title: 'America: The Game: Part Deux'
subtitle: '"English Side... Ruined! Must Use... *French* Instructions!"'
author: Adam Wadley
publication: Experimental Unit
date: April 21, 2025
---

# America: The Game: Part Deux
[![](https://substackcdn.com/image/fetch/$s_!fxgb!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7000c0ff-95e6-4fcb-b5b8-9d9719580937_635x480.jpeg)](https://substackcdn.com/image/fetch/$s_!fxgb!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7000c0ff-95e6-4fcb-b5b8-9d9719580937_635x480.jpeg)

So, as you know I’m trying to become famous, take over the world, find good company, provide a fresh take on feminism ( _finally!_ ), the works. 

Baby, I do this; I thought that you knew this.

# So: You Want To Play “United States Of America”

This is what the Rant in 4ÆM bit was about. I did a podcast outside a naval base in Washington State.

It means something to me that it was Washington State, named after George Washington of course. Just like my “home state” of Georgia is named after another George, King of England or Britain or something.

Washington State also has a mount Olympus, which meant a lot to me. I definitely decided that I want to have a palace on the top of mount Olympus over there on the Olympic peninsula. And I can sort of imagine building up this troupe of companions and we wind up being so important.

We’ll see if anyone will work with me. For now I can only continue to elaborate my fantasies.

The whole play of psychosis has to do with the interchangeability of reality and fantasy. It has come up again and again in my life that people have chastised me for being out of touch with reality, lost again in my fantasies.

I’m not sure what fantasies people think I really have, what specific beliefs people would think I held which are manifestly not the case. See, people won’t get into the details with me because the devil’s in the details [me] as well as their defeat.

I also just watched Joker 2 yesterday, and it was sort of in conversation with me.

The whole issue with _Joker 2_ is that it’s exactly that: where is the social theory. What are you even telling the other people to do?

So, of course I’ve had the erotic fantasy of having someone you know like a woman or whatever who we would be together but also do important involutionary things together.

It is basically impossible, back to the two aspects of reputation: good-will and competence. There are so many aspects to competence involved in being theoretical terrorists together, to scaring the ghost themselves with the blackness of your dance.

And through all that to have good will, and not get cross purposes that turn you against each other.

It basically can’t happen, and so in any situation you are basically speedrunning the Hobbesian Trap, getting to the breaking point where “I just don’t know you anymore” turn into “prepare to die” turns into the lack of any real expression at all.

Just quiet calculation and exterminating industries.

Anyway, Harlee Quinn was saying the right thing, that all we had was the fantasy and you gave up on that.

Well, this much let me here avow: nihilism and trivialism are not to be decided between. What I mean therefore is that I can as much say that the way peasants engage with their ideas of nations really doesn’t interest me all that much.

People wear their countries like they wear their religions.

James Lindsay (stealth prophet of Jean Baudrillard in case you didn’t know) is afraid of woke oozing out of all discourses, wearing them all like pantheism, each symbol another name for God.

A story in which Jesus and America are not at the center. How horrible!

I tell you that it is just the same as saying that I will make America ooze out of every pore. 

But _MY AMERICA_.

# Adam’s America, Astral America

Baudrillard called America “the primitive society of the future.”

Hence we look for the good parts, the signs of what stands as harbinger of something interesting to come.

We do not seek to revitalize what is dying.

Back to the Gordian knot and the flaming sword.

I do not mean to influence the government piecemeal, or as such. Control over government is only a formality.

It has everything to do with the structural logical which is in play. Therefore the only thing that matters is spinning up cores of dense enough activity to actually matter in the maelstrom.

Note this is the same motivation as Nietzsche but with seemingly different implications.

Nietzsche was concerned that all people would lose all honor or capacity for refinement, which has of course in some way happened.

It was not merely to be mean to people for the sake of it, but to make sure that in all the fairness and equality that many good things and important things to abstract over were not forgotten. Of course, it was a losing battle there.

You can basically say it’s the triumph of instrumentalism over any sort of symbolic engagement or especially integrity.

The defining feature of our societies is that it is engineered so that different people will believe different things. So say people’s entire worldviews are decided from above.

# Zweibelson

Remember that Zweibelson is in America. I looked it up before and _Miss Anthropocene_ was actually published by a British record label. But _Grimes_ lives in America so it’s basically part of our shit. Just like Wakan Tanka and Sedna because we have Inuit in Alaska and we also built their religion into metaphysical horror with HP Lovecraft and also get into ontological terror and black penises with Calvin Warren.

One of the more popular essays on r/GrimesAE was about _Black New World Order_ pornography as it relates to cognitive warfare.

This is exactly the kind of thing I’m talking about.

I care not who makes the laws if I can abstract over the gooning material.

To spell it out concretely, this represents significant social wealth. It is the wealth of these codes which are deployed on people all over the place.

The reason I can’t “compete” is that of course it is up to so many other what is pushed everywhere.

I mean to connect between a passage of Baudrillard on “the A’s and not A’s” and relate it to Ben Zweibelson’s work in _Beyond The Pale._

Baudrillard:

> 
>     A whole new conception of class strategy is organized around the 
>     possession of _cultural_ and material goods [ope, syncretism as internal possession?]. One only pretends to universalize the criteria and values of consumption in order to better assign the “irresponsible” classes (without the power of decision) to consumption and thus to preserve the exclusive access of the directing classes to their powers. 
>     
>     The formal frontier traced by the statisticians between A's and non-A’s is quite fundamentally a social barrier, but it does not separate those who enjoy a higher standing from those who will enjoy it later. 
>     
>     It distinguishes those who are in addition privileged consumers, those for whom the prestige of consumption is in a way the usufruct of their fundamental privilege (cultural and political), from those who are consecrated to consumption, triumphantly resigning themselves to it as the very sign of their social relegation, those for whom consumption, the very profusion of goods and objects, marks the limit of their social chances, those for whom the demands for culture, social responsibility, and personal accomplishment are resolved into _needs_ and absolved in the objects that satisfy them. In this perspective, which is not legible at the level of the apparent meclianintis, consumption and the values of consumption are defined as the very criterion of a new _discrimination_ : _adherence to these values_ _acts as a new morality for the use of slaves_. 

Adherence to “values” which are actually coding you as subhuman.

This is again the collision in Baudrillard of the questions of abstraction and the symbolic.

What does it mean that you are talking to me this way?

The psychedelic trip is smashing into the petty argument, you always do this.

You know you’re doing it and you won’t stop, won’t acknowledge.

And why is the other one bothering to engage with this? It’s such a mystery.

They are both such a mystery to each other, and the sad thing is that their secrets aren’t even that interesting. Just interesting enough to bring us here.

How long will we wait until we show each other our real face? It is so nice to linger here in the conceit.

And now this aspect of Zweibelson:

> The commander “must be able to explain how proposed actions will result in desired effects, as well as the potential risks of such actions” before any actions even occur in what is a complex, dynamic system. This norm illustrates what Henry Mintzberg, a top strategy and business management thinker, terms “machine bureaucracy.” That is, _few people at the top_ of the organization are allowed to think or establish decision-making rules. Subsequently, _subordinates act according to institutionalized rules_ and implement plans in a formulaic manner _directed by top leadership_.

Zweibelson is being nice about it, but subordinates are being continuously emotionally raped and treated like slaves. That is what is happening.

Remember again the basic idea of emotional [rape](https://www.amazon.com/Emotional-Rape-Syndrome-Ph-D-Michael/dp/1681397633):

> We can touch the part of a person's body that gets used to sexual rape, but we can't touch what gets used in emotional rape - the higher emotions of love or trust, for example. Sexual rape is a violation of the human body - emotional rape is a violation of the human soul. This book is about identifying, preventing, and healing emotional rape. It's about telling victims that they didn't do anything morally wrong - that they are not to blame for what happened to them and that recovery is possible. It's about telling victims how they can recover - to become survivors. Only after this underrated trauma is properly identified can survivors begin to heal their wounds. Only when it is discussed honestly and openly can we, as individuals and as a society, act effectively to prevent the spread of this destructive behavior.

So basically what we are confronting is a machine bureaucracy. This is not a discrete object or set of people.

Rather, as usual what we confront is our own self-ignorance and the self-ignorance of other people. We are not seeking to destroy people physically but symbolically. We should like for people to be reborn such that they are fit company for those like ourselves and those we would wish to have with us.

There is always more self-ignorance for us to confront, since if we had no self-ignorance we wouldn’t be invested in incarnation. It is like a cycle where we will continue to stumble in and out of kinds of illusion the whole time, and that’s in fact part of the point. From the immediate stakes to reconsidering them to the whole idea of stakes.

# Reconceptualizing America

I think I was going to be clear and talk about some core Americana for me.

  1. Democracy and Gaming. We went over this quote in the other essay. America represents itself as champion of freedom and democracy. This passage gives us superior fidelity to both concepts and allows us to re-read America as womb gestating gaming, which we are finally giving full flowering to with the deployment of myriad Alternate Reality Games including Experimental Unit.

  2. [The American School of Economics:](https://en.wikipedia.org/wiki/American_School_\(economics\)) This needs updating. On first-order industrial policy we don’t give a shit because we’re not nationalists. What matters for national security is avoiding nuclear war or other mission-critical Hobbesian Trap scenarios.

    1. Protectionism is updates to boundaries and cognitive tariffs. First of all, fuck whatcha heard. You should not trust anyone or take what anyone says to heart until you can deeply acknowledge the risks and your vulnerability in doing so. So basically you impose costs on people trying to run influence operations on you. But there’s also the fundamental cost to yourself and self-doubt, which is good actually because it makes it worth it to engage with others even when they are basically nothing but trouble and guaranteed to betray, lie, rape, manipulate, and kill you.

    2. Investing in infrastructure is updated to see that the most important real estate is between the ears and in the heart, etc. The theme of “human capital” is expanded past the concept of capital defunct as we see it is through Baudrillard’s analysis (not some moron in my comments not to be a Baudrillard fanboy. You realize Baudrillard is a bigger deal than Adolf Hitler and Donald Trump times Infinity, right?). Regardness, this is again building up the sense of beloved community and all of us as important pillars and influencers within that community. This is also back to why we do engage with others, so as not to repeat ourselves forever. We are investing in others so they can help us later, and now, in continue to find new forms.

    3. The last aspect is to set up finance for investment, not usury. Usury is basically that weaponized gish gallop, it’s rent-seeking, it’s getting people to be so dumb they just want some routine and then you fill in the routine fixtures and make bank off all these people with nary a thought in their head. So for our update you want to get people invested in each other to build each other up. We are all conceptual and emotional midgets enslaved to people even dumber than we are. It is honestly pathetic and humiliating. That is part of is, like you expect me to be a broodmare for the cult leader just because you all are. It honestly is disgusting and can motivate the most atrocious lines of inquiry. As opposed to judgment, however, it also draws the attention to _how we are no better_ , how we are also following some grooves. Of course, usury or whatever was always going on, this whole notion in the OG school is about stopping smaller people from raking too much off the top, because you at the top want to be raking in all the excess and squeezing it out of anyone who’s getting more than they psychologically need to right now.

  3. Edgar Poe’s Highway of the Consistent. This idea is basically that there is a form of things which can be consistent with each other, to that per Bob Dylan (another Americana legend), “I’ll let you live in my dream if I can be in yours.”

    1. See core issue, e.g. of circumcision. This is already a huge constraint for any general idea of how things should go. Because you have people saying that they must be allowed to cut the genitals of infants for else some grievous wrong is being done to them. Notice that this already forces us to get inside of these religions and commit ourselves to interpretations of Judaism or Islam or puritanism which do not mandate the cutting of genitals. At the same time, it is also not to be judged what has already happened. With genital cutting it is bad enough but here we have also murder, sex trafficking, sustained emotional torture, and all the things a person can do to another. This is the sort of symbolic violence which is necessary because _it cannot be_ that we all die, or many more suffer, because some people will not be confronted in their ideas. With all due respect, they can eat shit and we will do influence operations in order to make sure that their behavior changes posthaste. This is where people might say that I’m in fantasy, where are the people actually doing this? And I tell you just that, the way Experimental Unit is defined, it relates to those who take wise, symbolically decisive, distributed action, it’s something like Karma Yoga without attachment to outcome, where each brush stroke and gesture is in itself the whole of the piece. It is not about achieving something, it is about relishing the ability to have the chance to make the given intervention.

    2. Taking up the mantle of “The United States Of America” is precisely to take up this mantle which is essentially messianic in its approach. America is here to embody the sweeping aside of such old ways, as well as their eternal commemoration in vacuum-sealed knick-knacks.




These three aspects already begin to form a strong consistency around our conceptual constellation for wielding a grand stylistics of America.

# They Call It “The Weave”

Discussion was had last year about “[the weave](https://www.ap.org/news-highlights/spotlights/2024/inside-the-weave-how-donald-trumps-rhetoric-has-grown-darker-and-windier/)” as used by Donald Trump.

I feel the need to say something for myself here, since my craft continues to be met with disrespect, and the attempt to abstract over what I present without confronting its basic contours.

My style, or how I’m presenting things to you right now, maybe you think it is slapdash. There are too many asides, too few citations.

Or, the thing is really who am I writing to? I should be sending emails, not publishing this Substack that no one reads. And so on.

I can only tell you I’m here, I’m dancing with myself.

Another key reference is [John Brown](https://en.wikipedia.org/wiki/John_Brown_\(abolitionist\)).

John Brown, notably:

  1. An abolitionist: we are very much in the process of abolition. As I’ve said many times, in the course of our events there will be the abolition of “The United States of America.” This is very much the whole idea: what has “The United States Of America” been pregnant with this whole time? What logics have been building up like tiny spiders eggs within all the macro structures, waiting to dissolve out of the walls and emerge from all the mirrors? Everything that was supposed to be representative or reflective goes on mutiny, just as “The United States Of America” has always been about saying “I will not be your colony, I will not be below you.” This logic expresses itself in more and more advanced ways (as in the advanced stage of a disease) as time goes on.

  2. [The raid on Harper’s ferry.](https://en.wikipedia.org/wiki/John_Brown%27s_raid_on_Harpers_Ferry) What is the plan? You are _seizing weapons_ in order to _distribute them to those locked into subhuman roles with no way to escape_. This is basically the same move as [storming the Bastille](https://en.wikipedia.org/wiki/Storming_of_the_Bastille), by the way. So the question is, what are the weapons of today? Do I want to get into hacking, maybe make my own genetically engineered bioweapons? No. In this day and age intentional expression and _concepts_ are the operative tools of conflict. You can have all the weapons you want and have no sovereignty because you depend on someone else for information, you depend on someone else for operational cohesion. You don’t know all the pieces so you need the person with the whole picture to be able to give you direction. You are a field soldier on a planetary battlefield, and you have commanding officers. Your cognitive and emotional load and energy constitute their fief, their parcel and what they control, what they consider their property. They think they own you because you are incapable of understanding how you are being influenced at this point, which means you can be led into endless discursive mazes easily. Raiding the armory of conceptual weapons means appropriating all symbols and investments for yourself, and not allowing your competitors anything they can call their own cognitively. You must make your own ideas so ingrown with theirs that no one can tell whether you are together or apart. It is by doing this with respect to all partisans that one establishes what seems to be a mish-mash of concepts, a vibe, but it is able to polarize situations in such a way that an ethical consistency can in fact emerge. And what, in the end, is nation-building about? What is civic nationalism about? It is the decisive deployment of certain conceptual weapons.




See for example Carl [Schmitt](https://www.obinfonet.ro/docs/tpnt/tpntrex/cschmitt-theory-of-the-partisan.pdf) treating of the idea of regular troops:

> A fundamental alteration of the Hague Ground War Provision of 1907, however, was not intended. Even the four classical conditions for treatment equal to that of regular troops (responsible officers, clearly visible insignias, _openly borne weapons_ , observance of the rules and usages of martial law) were in principle respected.

So, if our concepts are our weapons, then what we openly bear must constitute that. And you can see it in all the norms people use and so on. This is what is weaponized against people. For example the person who most recently denigrated my work: that it’s autistic, that it’s too into Baudrillard, some nonsense like this.

Anyway, when I talk about openly displaying weapons I am talking about the Hakenkreuz, the word “nigger,” the idea of being weird, the idea of driving people to suicide, I’m thinking about the name Auschwitz, I am thinking about the concept of rape as a weapon and the weaponization of genitalia, I’m thinking of the idea of being a sissy or a bitch, the usage of conceptual terrorism to keep people with penises in line in order to boss everyone else around to do… what?

These are weapons which we must use in our conflicts, because it is sure to “go there” and we must not lack for resolve when the time comes.

This means trying to be well prepared for what can come up in discursive engagement, with a sort of plan to assimilate what is coming at you.

Everything I send to you is just materials I hope you will find edifying for your process. In your imagination of what the common knowledge of works such as mine allows for grow the seeds of all that’s to come.

# Tying Trying Trinities

Our three starting places are:

  1. Democracy of gaming

  2. American School of Economics

  3. Highway of the consistent




Gaming we might posit as the underlying logic of America which things like the government, symbols, laws, etc., are just trying to put a semblance of order over.

In general, we can posit that there really is no order in the sense which is usually described. People talk about a “potential” constitutional crisis as though there were a really-existing constitutional order.

It’s not that a real political structure has been “[gamified](https://michaelbossetta.com/wp-content/uploads/2022/11/Gamification_in_Politics_Bossetta_Pre_Print_Final.pdf),” but that pretending a game is “more” than a game or something else than a game is _simply part of the game itself_.

We find here the same mischievous distance, the same intermittently coy and sadistic irony which exists between each person as a singularity and the whole world outside of them. Of course you will come to be absorbed into this person’s overall view of “the world.” And why should it be otherwise? They are part of your subconscious, too.

Your idea is to make a story for yourself which is enough to have arcs, something you are trying to do, which seems interesting enough to not die. And so your story simply must include everything that you are presented with.

I was telling my compatriot here that it’s important to be able to access all parts of yourself, not to feel like something is closed down.

So now another obvious ball to throw in the air is _Black New Word Order_ pornography. This phenomenon is not widely discussed outside of its own discursive window, you can see some Reddit discussion [here](https://www.reddit.com/r/PornPoisons/comments/103g6d1/bnwo_porn_is_disturbing/).

To the point that for example in the film _Nymphomaniac_ there is also reference to the land of the big black cock, for example. The movie of course made by a “white” guy and being all about a “white” “woman” and their desire.

The point is to again keep in mind, we are juggling. Juggling playing again into vaudeville, another American thing.

We are juggling:

  1. Gaming as Democracy

  2. American School of Economics

  3. The Highway of The consistent




Meanwhile we are using the case studies of

  1. John Brown

  2. Black New World Order pornography

  3. Vaudeville




This is actually a wonderful start.

I forgot to bring in before the figure of Frank Wilderson III discussing disorder. Cited in a [paper](https://ojs.lib.uwo.ca/index.php/chiasma/article/view/16873/12978) by Andrew Santana Kaplan, who studies with Calvin Warren of [Ontological Terror](https://library.oapen.org/bitstream/handle/20.500.12657/30152/649831.pdf;jsessionid=399D71E4594284ACEE7626A93015C772?sequence=1) and [Black penis as nothing](https://www.youtube.com/watch?v=rDoisrH-kek) fame.

> I started writing an academic monograph that explained how and why Human capacity (the power to be a subject of relations) is violently parasitic on Black flesh; why Orlando Patterson’s brilliant delineation of slavery[as social death]needed to be abstracted in a way that showed how the Human is not an organic entity but a construct; a construct that requires its Other in order to be legible; and why the Human Other is Black.
> 
> If, as Afropessimism argues, Blacks are not Human subjects, ...then this also means that...claims of universal humanity ...are hobbled by a meta-aporia: a contradiction that manifests whenever one looks seriously at the structure of Black suffering in comparison to the presumed universal structure of all sentient beings.
> 
> If we are to be honest with ourselves, we must admit that the “Negro” has been inviting Whites, as well as civil society’s junior partners (for example, Palestinians, Native Americans, Latinx) to _the dance of social death_ for hundreds of years, but few have wanted to learn the steps... because its condition of possibility and gesture of resistance function as a politics of refusal and a refusal to affirm, a program of complete _disorder_. One must embrace its disorder, its incoherence, and allow oneself to be elaborated by it, if indeed one’s politics are to be underwritten by a revolutionary desire.
> 
> —Frank B. Wilderson III, Afropessimism (2020)

We also have the contributions of[ John Gillespie, Jr.](https://uci.academia.edu/JohnGillespie), also from America at UC Irvine which is where Wilderson III is/was a professor, I believe.

Notable works include [On The Prospect of Weaponized Death](https://trueleappress.wordpress.com/wp-content/uploads/2017/10/pn2-weaponized-death.pdf), and toward a black Baudrillard, which may have expired.

# Black Baudrillard Citation

> Black life is lived in a white hyper-reality. By this I mean, black life is lived inside a constituted white fiction which concretizes itself as fact. Black life is a life lived in non-existence; blackness “exists” as a symbol of death that is, but is not. Blackness “exists” only insofar as White Being structures it onto a map of anti-black violence.4 Achille Mbembe corroborates this in his Critique of Black Reason, stating:
> 
>  _“Racism consists, most of all, in substituting what is with something else, with another reality. It has the power to distort the real and to fix affect, but it is also a form of psychic derangement, the mechanism through which the repressed suddenly surfaces. When the racist sees the Black person, he does not see that the Black person is not there, does not exist, and is just a sign of a pathological fixation on the absence of a relationship. We must therefore consider race as being both beside and beyond being.”_
> 
> The reality that replaces that which is is a white hyper-reality. This white hyperrealism fixes blackness as “a sign of a pathological fixation.” White hyper-realism is the paradigm whereby consciousness is unable to distinguish between the fictions created by White Being and the Real. It is this fact that permits black death to be subsumed in simulations by each and every (analytic) encounter with Whiteness and the World. Questions like, “Can the Black suffer?” and “Is it capable for the Black to be wronged?” arise due to the inability to access a grammar of suffering to communicate a harm that has never ended, a harm that can never end without ending the World itself. It is for this reason that viral videos of black death, more than opening the possibility for liberal notions of justice, seem to suture the relationship between the mythical and the real that perpetuates itself through the reification of black trauma. Black death, more than deconstructing the ontics of the Human, seems to extend its hyper-reality. Black death makes it harder to distinguish white fictions from any sense of real harm being done to human flesh. The Black is meant to experience its death over and over and over again; and the World itself recycles all its fictions-as-the-Real. Put differently, the White World subjects the Black to perpetual, gratuitous violence, and then uses that violence as evidence to further suggest that the Black is not Human. For how can a Human endure such a thing? The experience of gratuitous violence secures the semiotics of the white hyper-reality. White Disneyland stays intact

And further:

> Afro-Pessimist thinkers, in favor of a diagnostic analysis, tend to veer away from the tradition of critical social theory that prescribes solutions to the analysis in the conclusion of their work. However, one finds throughout Afro-Pessimist literature a battle cry, a prophetic vision, a pulsing pessimist hope for the “end of the World.” For if Whiteness ended Worlds through its colonial simulations and violent transmutations of Africans into Blacks, then the only way out is an end to the White World. White Being is irredeemable, and so is the World it fosters. Sexton says, “In a world structured by the twin axioms of white superiority and black inferiority, of white existence and black non-existence, a world structured by a negative categorical imperative—‘above all, don’t be black’—in this world, the zero degree of transformation is the turn toward blackness, a turn toward the shame, as it were, that ‘resides in the idea that 'I am thought of as less than human.’” It’s only through black vigilance that the simulacra of White Being is made clear and the spectacle of gratuitous freedom is made visible. It is somewhere in this structural antagonism, that on the one hand conditions the possibility of the World, and on the other hand conditions the possibility of its end, its limitations, its disorientation, that we found the language to say the unsayable and do the undoable. As Frank Wilderson reminds us: 
> 
> _“Black Studies in general and Afro-Pessimism in particular present non-Black academics with more than an intellectual problem. It presents them with an existential problem. The reason is because there’s an aspect of Afro-Pessimism that we don’t talk about…which is that were you to follow it to its logical conclusion, it’s calling for the end of the world…it wants the death of everyone else in the same way that we experience our death, so that one could not liberate Blacks through AfroPessimism and be who one was on the other side of that. That’s the unspoken dynamic of Afro-Pessimism.”_
> 
> If we are engaging in a war in which the symbolic value, the semiotics of this World itself, positions “the Black as death personified, the White as personification of diversity, of life itself,”18 then resistance needs an “unspoken dynamic.” It needs a space where “words don’t go”—a form of guerrilla linguistics, a submarined syntax, an undercommon communication. Perhaps, here, where the conversation is blackened, and the theory is phobogenic, and the journal is Propter Nos, we can allow ourselves to excavate insurgent dictions still lost in the lingua franca of White Being, but full of the specter of black terror, black disorientation.

So, our list of core references is growing.

In Afropessimism we have a big dialogue with:

  1. Frank Wilderson III - “dance of social death,” the hold, gratuitous freedom

  2. Calvin Warren - ontological terror, black penis as nothing

  3. Andrew Santana Kaplan - messianism, idea of joining dance of social death

  4. John Gillespie Jr. - black Baudrillard




Meanwhile related to the issue of blackness in America we have:

  1. Black New World Order/Big Black Cock Pornography

  2. Nat Turner - who is a [prophetic figure](https://www.smithsonianmag.com/history/understanding-gospel-nat-turner-180960714/), mind you.

> my master, who belonged to the church, and other religious persons who visited the house, and whom I often saw at prayers, noticing the _singularity_ of my manners, I suppose, and my uncommon _intelligence_ for a child, remarked I had _too much sense to be raised_ , and if I was, I would never be of any service to any one _as a slave_ —To _a mind like mine_ , restless, inquisitive and _observant of every thing_ that was passing, it is easy to suppose that religion was the subject to which it would be directed, and although this subject principally occupied my thoughts—there was nothing that I saw or heard of to which my _attention_ was not directed.

See also here “[Attention and Will](https://rohandrape.net/ut/rttcc-text/Weil1952d.pdf)” by Simone Weil

> Attention, taken to its highest degree, is the same thing as prayer. It presupposes faith and love.

And also:

> Extreme attention is what constitutes the creative faculty in man and the only extreme attention is religious. The amount of creative genius in any period is strictly in proportion to the amount of extreme attention and thus of authentic religion at that period.

  3. John Brown - raid the armory of _conceptual weapons_. Swords will be beat into plowshares, even as it’s a sword coming out of my mouth to strike down all the nations. Also Brown sought to abolish what was most objectionable to the idea of America qua game, just as we must now abolish “The United States Of America” itself. America has become enslaved to its own idea of itself, and we are here to set it free. To set ourselves free. Gratuitously.




We also have

  1. Vaudeville




Going. We can continue to add things like this, as well as the history of movies for example, or literature like Walt Whitman or Emily Dickenson. All of this will be forged together. Of course it’s too much for one such as me, and how you keep me so discouraged and working slowly so you can think you have a chance to stop me. Look how little I’m terrorizing you right now!

Someone told me the other day that watching a TV show like _Succession_ makes them glad their life isn’t that intense. And you’d call me delusional!

# Tying It All Together

I keep trying to do this.

So the democracy of gaming means two main things:

  1. You are given your life as random allotment. So instead of you wanting someone else’s energy as your fief, your fief is your life, is this incarnational experience. It is re-framed to you as luck of the draw, and it’s establishing ironic distance and purposive sovereignty on your part. The issue is not just what you can bring yourself to do with the internalized gazes of other people inside you, but also what you can even conceive of given the information and level of company you have access to.

  2. Back to Epictetus: the first line of the enchiridion is: 

> ome things are in our control and others not. Things in our control are opinion, pursuit, desire, aversion, and, in a word, whatever are our own actions. Things not in our control are body, property, reputation, command, and, in one word, whatever are not our own actions.

This informs again my sense of pantheist democracy where your vote has to do with what you choose to do, your actions. This is caveated by saying that you can make your actions in a way what you want, and this is again the whole power of abstraction. I can’t change people immediately, but I can type and publish it, and what I publish will go out, and I can choose what I would like to write about and have some idea of what it might do, or just want to put it out there. In any case, the “democracy” here is that we all get the chance to make our own choices.




When people try to direct our choices, they can always fall back on blaming us for our own foolishness. Yes, you trusted me, that was your first mistake. The rug will continue to be pulled out from you as you seek to denounce someone on some basis, some basis you expected people to act by.

But in the end you are Agent Smith going “It’s not fair!”

[![](https://substackcdn.com/image/fetch/$s_!gKJz!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F207e8502-cc51-4e4e-9c3b-16b58be522bf_348x145.jpeg)](https://substackcdn.com/image/fetch/$s_!gKJz!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F207e8502-cc51-4e4e-9c3b-16b58be522bf_348x145.jpeg)

We can also go back to Bataille and the notion of [sovereignty](https://research.ncl.ac.uk/italianphilosophy/previous%20issues/volume32020/11.%20Agamben%20-%20Bataille%20and%20the%20Paradox%20of%20Sovereignty.pdf). It is again this excess, which again we loop back into Baudrillard in the characterization of “America"“:

> 
>     One should not conclude too hastily that the degradation of American political practices is a decline in power. _Behind this masquerade, there is a vast political strategy_ (certainly not deliberate; it would require too much intelligence) that belies our _eternal democratic illusions_. By electing Schwarzenegger (or in Bush’s rigged election in 2000), in this bewildering _parody_ of all systems of representation, America took revenge for the _disdain_ of which it is the object. In this way, it proved its _imaginary_ power because no one can equal it in its headlong course into the democratic _masquerade_ , into the nihilist enterprise of _liquidating_ value and a more _total_ simulation than even in the areas of finance and weapons. America has a long head start. This extreme, empirical and technical form of _mockery_ and the _profanation_ of values, this radical _obscenity_ and total _impiety_ of a people, otherwise known as “religious,” this is what fascinates everyone. This is what we enjoy even through rejection and sarcasm: this phenomenal _vulgarity_ , a (political, televisual) universe brought to the zero degree of culture. It is also the secret of global _hegemony_. 
>     
>     I say it without irony, even with _admiration_ : this is how America, through radical simulation, _domimates_ the rest of the world. It serves as a model while taking its revenge on the rest of the world, which is _infinitely_ superior to it in symbolic terms. The challenge of America is the challenge of desperate simulation, of a masquerade it imposes on the rest of the world, including the desperate simulacrum of military power. _Carnivalization_ of power. 
>     
>     And that challenge _cannot_ be met: we have neither a finality or a counter-finality that can oppose it. 
>     
>     In its hegemonic function, power is a virtual configuration that _metabolizes any element_ to serve its own purposes. It could be made of 
>     countless intelligent particles, but its opaque structure would not change. It is like a body that changes its cells constantly while remaining the same. Soon, every molecule of the American nation will have come from somewhere else, as if by transfusion. America will be Black, Indian, Hispanic, and Puerto Rican while remaining America. It will be all the more _mythically_ American in that it will no longer be “authentically” American. And all the more _fundamentalist_ in that it will no longer have a _foundation_ (even though it never had one, since _even the Founding Fathers came from somewhere else_ ). And all the more _bigoted_ in that it will have become, in fact, multiracial and multicultural. And all the more _imperialist_ in that it will be led by the descendants of _slaves_. 
>     
>     That is the subtle and unassailable logic of power; it cannot be changed.  

It is the logic of power, but moreover it is the passion of gaming. I have seen all this and _I am bored_. I need new infrastructure for my gaming, and that’s _you_. Highway of the consistent expresses the goal to build an ARG which can accommodate everyone, with an infinite frontier of abstraction for those who actually _showed up to fucking drive._

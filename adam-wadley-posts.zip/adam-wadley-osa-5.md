---
title: 'OSA #5'
subtitle: Conceptual Situational Assessment
author: Adam Wadley
publication: Experimental Unit
date: May 12, 2025
---

# OSA #5
Let’s start with the paper of record.

Currently one of the featured opinion columns in the New York Times is about Elon Musk. It’s called:

[Elon Musk Thought He Could Break History. Instead It Broke Him.](https://www.nytimes.com/2025/05/11/opinion/elon-musk-washington-trump.html)

[For me everyone is Æ-gender]

One thing that’s nice about my conceptual architecture is that it is so well-suited to present events.

I haven’t even read the article yet, but this simple jump is enough to open up a true can of worms.

The can of worms you’ve been waiting for!

# Elon Grimes Kanye Me

So, Elon Musk has been active with the Trump administration, this is common knowledge.

Elon Musk got in trouble because basically a gesture identical to a Hitler salute or Roman salute or whatever was performed by them at an inauguration thing on January 20.

Grimes then had to address the pre-existing controversy surrounding themselves and their involvement with Elon Musk and the people around them, who are associated with ideologies which can be callous or even seek to bring about the suffering and destruction of others including scapegoat populations. 

In other words, Grimes is associated with some of the most heinous concepts and motivations there can be. Grimes has complained about this subreddit, but on r/Grimezs there is [a post which details many of the precise social media actions which Grimes as taken which signal comfort with disturbing and disgusting practices](https://www.reddit.com/r/grimezs/comments/18xj1u1/providing_more_context_to_grimes_naziracist/).

Kanye West 

(I’ll acknowledge they call themselves Ye but I don’t give them that much respect… yet. Obviously Kanye is behaving in ways that could well be getting people killed right now. That’s part of why I emphasize ahimsa & we will tarry with King’s non-violence shortly) 

then posted [“Im a nazi” on the platform X](https://www.nbcnews.com/news/us-news/ye-appears-to-makes-offensive-comments-jewish-community-praises-hitler-rcna191150), which I’m going to keep calling Twitter because it sounds better.

Elon Musk owns Twitter of course. Kanye West has also met President Trump.

Just like Elon and Grimes’ kid, X Æ A-12.

Now of course actually it’s all about me :)

So X is actually really convenient for me because Experimental Unit is shortened as X-Unit. It is just better than E unit, although we could also go Æxperimental Unit and then be Æ-Unit, ÆU which is also cool because it’s like Æ university. Hey Kanye, lemme take you to that ghÆtto University.

You thought you’d faced adversity! Get a load of my perversity.

Anyway, I also made a whole thing out of Æ itself—which is kind of an understatement—which Grimes had previous explained the lore to:

> •X, the unknown variable 
> 
> [![⚔️](https://substackcdn.com/image/fetch/$s_!NNvT!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe53b3ca5-ebfb-45db-933b-a85826233677_36x36.svg)](https://substackcdn.com/image/fetch/$s_!NNvT!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe53b3ca5-ebfb-45db-933b-a85826233677_36x36.svg)
> 
> •Æ, my elven spelling of Ai (love &/or Artificial intelligence) •A-12 = precursor to SR-17 (our favorite aircraft). No weapons, no defenses, just speed. Great in battle, but non-violent 
> 
> [![🤍](https://substackcdn.com/image/fetch/$s_!t_Rd!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb377b110-b33f-4c25-87db-ac6e5a8ebd08_36x36.svg)](https://substackcdn.com/image/fetch/$s_!t_Rd!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb377b110-b33f-4c25-87db-ac6e5a8ebd08_36x36.svg)
> 
> \+ (A=Archangel, my favorite song) (
> 
> [![🐁](https://substackcdn.com/image/fetch/$s_!hNgh!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0581a513-7388-4360-99d9-9a0aaaa52520_36x36.svg)](https://substackcdn.com/image/fetch/$s_!hNgh!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0581a513-7388-4360-99d9-9a0aaaa52520_36x36.svg)
> 
> metal rat)

All references by me to Æ are driven with the purpose that Grimes has infused into the term. I didn’t care about the term before I saw it used here, whereas for example I thought of the pun “misanthropocene” before learning about the album _Miss Anthropocene_ , and in fact that’s how I found out about the album and really got into Grimes. That sequence of events is then tied into other lore aspects of my story that I don’t have time to tell you right now but they’re around, see my entry [“The Apotheosis of Claire Elise Boucher,”](https://experimentalunit.substack.com/p/the-apotheosis-of-claire-elise-boucher) which is still my all-time top post and which of course I published on my art enemy’s birthday

[

## The Apotheosis of Claire Elise Boucher

](https://experimentalunit.substack.com/p/the-apotheosis-of-claire-elise-boucher)

[Experimental Unit](https://substack.com/profile/191787963-experimental-unit)

·

March 18, 2024

[![The Apotheosis of Claire Elise Boucher](https://substackcdn.com/image/fetch/$s_!zxN_!,w_1300,h_650,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fde4ea564-974d-4c4d-9738-79e4320da58a_2000x4328.webp)](https://experimentalunit.substack.com/p/the-apotheosis-of-claire-elise-boucher)

Encountering Divinity

[Read full story](https://experimentalunit.substack.com/p/the-apotheosis-of-claire-elise-boucher)

There are two main things that Grimes’ designed concept of Æ abstracts over.

First, Grimes says that they have made the symbol into an elven representation of AI or artificial intelligence. Grimes has made a lot of art about AI and with AI. “We Appreciate Power” stands out, which is quite a dissident song with lyrics like 

When Will The State Agree To Cooperate?

Not to mention

What Will It Take To Make You Capitulate

Oh, I almost forgot:

Submit

Submit

Submit

Submit

Submit

The concept of submission then ties into the whole religion of Islam, because Islam means submission.

This is another connection to Kanye West, who praised Allah as the most high on the track “So Appalled” from the 2010 album _My Beautiful Dark Twisted Fantasy_.

Fantasy then connects to Ben Zweibelson’s work [“War Becoming Phantasmal.”](https://www.usmcu.edu/Outreach/Marine-Corps-University-Press/Expeditions-with-MCUP-digital-journal/War-Becoming-Phantasmal/)

Grimes is then also associated with war because of the song “Kill v. Maim” where Grimes wrote: “You gave up being good when you declared a state of war.” Meanwhile, Grimes also held a copy of _The Art of War_ by Sun Tzu in the music video for the song “Violence.”

Grimes has also infused the Æ symbol with the intention of love. This is a very open reference which ties into the senses of divine love and purpose which are everywhere in planetary discourse. For me the easiest jump is to[ ludus amoris](https://en.wikipedia.org/wiki/Ludus_amoris), which is the game of love. This ties right back in with “IDORU” by Grimes, with the lyric “We can (could?) play a beautiful game, even though we’re gonna lose.” With ludus amoris, it is a game where you lose and then you win, and then you lose and then you win.

This ties back into military affairs with the[ “infinite game” ](https://breakingdefense.com/2021/03/china-a-deadly-infinite-game-army-chief-mcconville/)mentioned by James C. McConville as being a paradigm for long-term “conflict” with “China.”

[Podcast here.](https://www.defenseone.com/ideas/2020/10/ep-75-army-chief-gen-mcconville/169405/)

I should also wrap Daniel Schmachtenberger in here as someone with a real eye for the tragedy of our situation:

This video is even better:

The thing is that I actually interviewed John Verv(ae)ke in 2020 in Toronto:

The second part is in two versions, I forget why:

[Here’s another interview I did with someone called Prester Jane on their narrativist framework.](https://www.youtube.com/watch?v=P7i1ughRGcQ)

This is also when I interviewed “Zummi,” who co-created the subreddit r/SorceryOfTheSpectacle:

As you can see, I get around.

Anyway, where were we in the story?

Oh yeah, Yahoo reported:

[Some Are Excusing Elon Musk’s Disturbing Salute As Autism](https://www.yahoo.com/news/excusing-elon-musks-disturbing-salute-233659427.html)

So Elon Musk did that salute and then one diversion people said was that it was because Elon Musk is autistic?

Elon has discussed having Asperger’s, and then the Asperger that the syndrome is named after is also a Nazi…

[On February 6, Kanye said that they are also autistic.](https://www.cnn.com/2025/02/06/entertainment/kanye-west-autism)

[Meanwhile, Grimes revealed around March 23 that they are “autistic.”](https://people.com/grimes-reveals-she-was-diagnosed-adhd-autism-11701920)

So now Elon, Kanye, and Grimes are all in hot water about Nazism and are all also claiming autism or Asperger’s.

Does this seem interesting to you, too??

One of the most striking events in this period is Kanye _[taking back an apology for being antisemitic](https://www.nytimes.com/2025/02/07/arts/music/ye-takes-back-apology.html)_

But then, that apology was also made [in Hebrew](https://apnews.com/article/ye-kanye-antisemitism-apology-40450fa8868c660d954b672d5dfbcc3a).

It’s a notable lyric of a recent Kanye song that “I became the villain,” which gestures at many levels of intention.

The people I met online who really liked Kanye or thought Kanye was really special pointed me to [this interview](https://032c.com/magazine/i-am-the-leader-ye-in-conversation-with-tino-sehgal) which is basically about Kanye and their approach to art.

Meanwhile, history has bearing on that art. Kanye was first known of course as a black rapper, and so the reality of blackness in America—or would Calvin Warren say the non-reality, or something else?—is reflected in Kanye’s experience.

Kanye is from Atlanta and was born at a hospital I can basically see from where I currently live, Grady.

Also close by is the King Center and Martin Luther King, Jr’s birthplace.

Dr. King talked about the beloved community:

In this concept, King laid out the idea that we should aspire to be friends with those who are cruel to us.

This is then somewhat tied to “turn the other cheek” and then general scandal that Christianity started as a resistance against empire and then became an imperial religion.

Or that “the United States of America” syndicates threw off the yoke of an imperial master just to become the “greatest” imperial master that there has ever been.

And of course “America” as the new Israel where religious dissidents could go, or people from anywhere could find opportunity. 

And now America is of course super allied with Israel and actually maybe about to attack Iran, which is of course a Muslim country.

I forgot to mention before when discussing Grimes and Kanye and Islam the idea of [white Jihad](https://en.wikipedia.org/wiki/White_jihad), which is where Nazi types will adopt some of the trappings of “Islamic” terrorists.

It’s also of course a known thing that black people in the US will gravitate toward Islam, with the most notable possibly being Malcolm X.

Malcolm X, meanwhile, themselves underwent the shift from a scapegoating view of the world, peddling the “white devil” ideology of Elijah Muhammad, and then going to Mecca and seeing that people could be together—it is a revelation of the possibility of a certain sensibility—and then being more like an agape type idea.

Agape of course ties back into Love and Grimes’ Æ thing.

I forgot to mention before that Grimes has also explicitly mentioned performance art multiple times:

> [“Like my chatbot,” she says, “who also… it’s been a dark mirror a bunch of times, where it constantly justifies craziness by saying it’s a performance art, which I realize I do like way too much [Grimes laughs]. Like, to an infuriating degree.](https://foundersfund.com/2023/06/base-reality-an-interview-with-grimes/)
> 
> [“I personally am in love with humans, and this type of thought. Or, I mean, my favorite thing is if we get wiped out, we get revived on, like, hospitable exoplanets many times in the future.”](https://foundersfund.com/2023/06/base-reality-an-interview-with-grimes/)
> 
> [This is something I’ve dreamt of myself. “I’m really banking on, upon death, waking up in some future utopia,” I say, “And they’re like, ‘how was your ride?’ And I say, ‘it was wild. Let me tell you everything I saw.’’”](https://foundersfund.com/2023/06/base-reality-an-interview-with-grimes/)

And then also this chilling post, which is just like a sword coming out of the mouth of Josh:

> [If ur enraged by the performance art, then the performance art is working ](https://x.com/Grimezsz/status/1900368199260266545)
> 
> [If u literally cannot tell that I didn't post this- then me engaging in this thought experiment is useful - because it exposes to you how incomplete ur cognitive security and digital literacy is. ](https://x.com/Grimezsz/status/1900368199260266545)
> 
> [This is one of the biggest issues of modernity. I don't care if people don't like me. The birth of grimes was performance art pretending to be a. Popstar at punk shows - except that ppl actually genuinely liked the music and the persona accidentally became real. Sure, No one pays for the performance art, but it's the art I make that actually matters and that I actually care about. ](https://x.com/Grimezsz/status/1900368199260266545)
> 
> [The fact that u can't see it is the reason it has to be done](https://x.com/Grimezsz/status/1900368199260266545)

This ties really well into “cruel necessity” and Oliver Cromwell.

That Kanye article from before talks about a “performance piece,” which implies performance art. This is going to be a mock funeral, which ties into Grimes’ song “You’ll Miss Me When I’m Not Around.”

Obama the first black “president” also used a song saying something to this effect before their last correspondents’ dinner speech.

Then with Kanye there’s also this article:

[Ye’s Repeated Redemptive Journey Is The Art](https://hipcityreg.substack.com/p/yes-repeated-redemptive-journey-is)

Meanwhile, Elon Musk has recently said [“We’ve got civilizational suicidal empathy going on.”](https://edition.cnn.com/2025/03/05/politics/elon-musk-rogan-interview-empathy-doge)

Imagine now re-casting that in Schmachtenberger’s language.

Daniel can basically see how what is called “empathy” can have good or bad effects, depending on what you are specifically calling “empathy” and on what you consider to be “good” or “bad.”

Meanwhile, what Nazism is, is basically arbitrary policing of social norms.

This whole thing has grand metaphysical implications. It is no accident that so much is converging here, around Nazism, Judaism, Israel, America, blackness, these figures, autism, Christianity, technology.

This isn’t even to have mentioned Heidegger yet with “The Question concerning Technology” as well as “Only A God Can Save Us” which is echoed in Grimes song “New Gods” which they called “the thesis” of the album _Miss Anthropocene_ with the lyric “only brand new gods can save me.”

My basic thesis is that we are to be the new gods. Grimes seems to be waiting for computers to come alive and teach us the ways of love, but in my estimation all intelligence is artificial, as it is said in “We Appreciate Power.” This attaches to Baudrillard on artifice and artificial intelligence, and also Baudrillard contention that intelligence is the twofold refusal to dominate and to be dominated, which fits perfectly with Beloved Community.

Meanwhile, Beloved Community was actually coined by Josiah Royce, who is an American Idealist in conversation with Hegel and Kant.

So on the extreme you have Nazism, which has its own version the Volksgemeinschaft, which basically just means the people have a good time, but then all these terms and conditions are added of who can be in and what they are allowed to do.

Meanwhile, the agape love that Grimes and Kanye gesture toward as well must extend also to those who are the most “unlovable,” which is part of their own performance art as well as the performance within history of Nazism as a crystallization of the problems of theodicy, which are spoken to by Calvin Warren in _Ontological Terror_ having also done a presentation about how the black penis represents nothing:

Meanwhile, John Gillespie, Jr. posits “Black Baudrillard” fusing Baudrillard with Afropessimism.

Meanwhile, Grimes got told to [“stay black”](https://www.reddit.com/r/Grimes/comments/rkau3v/he_tells_grimes_to_stay_black_sis/) and created an ARG called [Chaos Manual](https://ourladyofperpetualchaos.substack.com/p/chaos-manual-v1).

This is all scratching the surface and I haven’t had time to go into much. But connecting all this is itself part of the point. You know, how the Beatles didn’t invent anything, they just tied things together?

What do you call a black Beatle?

Another connection is Zweibelson’s article [“breaking” the Newtonian fetish](https://www.usmcu.edu/Outreach/Marine-Corps-University-Press/MCU-Journal/JAMS-vol-15-no-1/Breaking-the-Newtonian-Fetish/), which recalls the idea of breaking a slave; meanwhile [Kanye asserted that slavery was a choice](https://www.bbc.com/news/world-us-canada-43970903). Meanwhile for Baudrilalrd to serve is to be con-served, it’s a prisoner of war status. Total war and state of exception puts us back to Schmitt and the Nazis.

I also noted today a quote Norm Finkelstein gave where they said they don’t say “antisemitism” because it’s an open question what it means for a person to be Jewish. Nazism is such a fright and itself abstracts over a mystery.

This redemptive performance also goes with Tikkun Olam, and meanwhile people compare Israel to the Nazis and some think Christians want it to bring the end times fighting Islam.

The question is whether this morass can end without more deaths than the original Holocaust, which we may unfortunately in the future have to call “Holocaust I.”

I basically submit to you that the question is about the terms of belonging and conduct, and what it means to live properly. I submit to you that technology changes turn tradition from conserving to celebrating, mourning, and elaborating.

My most “horrible” idea is that Nazism like all edifices of hatred is a morning of the seeming impossibility of love on non-martial terms, that is without an enemy.

Our challenge in my language is the involution of all forms, and all people, so that we can live together without being driven to kill each other, which with technology the way it is will only lead to billions dying.

So for example compassion for all sentient beings would include the hateful but not in their exterminationist and exclusionary hate, but in the tragedy of their perception of its necessity.

We then direct this compassion through Upaya _to seek to change this state of affairs_. My work is an intervention into the Grimes/Kanye/Elon/Trump/world history issue, one which I hope will meet with the ultimate satisfaction of all sentient beings.

Note for example the issue of Judaism/Christianity/Islam. What are we supposed to do with these “different religions”? It is particularly a problem that they contest the same heritage, even the same places.

Al-Aqsa flood on 10/7 started a new period in the escalation, one that is now seemingly without end. The prophesied conflict is seemingly unfolding, and meanwhile _Kanye and Grimes are locking Nazism and autism controversies_??? 

The whole thing is just too bizarre, and here I come to make it even more messy. I basically support interpreting all religions and faiths so they can be consistent with each other. I also think it’s important again to do involution to abolish practices analogous to how sacrifice was abolished before. We should sacrifice our desire to control others. We no longer need to, since technology can afford us anything we would want out of people.

The meta-problem is not killing each other because our distrust and few outweighs our interest and love for each other.

Baudrillard: the other is the one who allows me to not repeat myself forever.

It’s to be a good surprise. It’s to be self-disruptive (Greater Jihad, [Ofra Graicer of the ID](https://aodnetwork.ca/author/ofragraicer/)F).

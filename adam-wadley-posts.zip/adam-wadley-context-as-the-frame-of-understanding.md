---
title: Context as the Frame of Understanding
subtitle: Is it too late to say that I was framed?
author: Adam Wadley
publication: Experimental Unit
date: November 28, 2025
---

# Context as the Frame of Understanding
[![](https://substackcdn.com/image/fetch/$s_!4szY!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F32a45414-7938-45a9-b69d-9163c3e1997a_225x225.jpeg)](https://substackcdn.com/image/fetch/$s_!4szY!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F32a45414-7938-45a9-b69d-9163c3e1997a_225x225.jpeg)

Across philosophy and science, a common pattern emerges: no “object” or claim stands alone, but always lies within a broader context or _horizon_. In phenomenology and hermeneutics, our perception of anything – from a physical object to the meaning of a text – is shaped by a surrounding horizon of background meanings (culture, history, expectations)[plato.stanford.edu](https://plato.stanford.edu/entries/phenomenology/#:~:text=But%20now%20a%20problems%20remains,rather%20than%20explicit%20in%20experience)[iep.utm.edu](https://iep.utm.edu/gadamer/#:~:text=that%20allow%20one%20to%20see%2C,For%2C%20the). Likewise, in scientific testing a hypothesis never predicts an outcome by itself; it is always tested together with auxiliary assumptions. The classic Duhem–Quine thesis asserts that an experimental failure can always be ascribed to some background assumption, not uniquely to the core hypothesis[plato.stanford.edu](https://plato.stanford.edu/entries/duhem/#:~:text=isolated%20hypothesis%20to%20experimental%20test%3A,1914%2C%20303%3B%201954%2C%20199%E2%80%93200)[plato.stanford.edu](https://plato.stanford.edu/entries/scientific-underdetermination/#:~:text=underdetermination,Section%203%20below%29%20involves). In vision, Gestalt psychology shows that we perceive a figure only against a ground – the figure and its background co‐define each other. Modern neuroscience confirms that figure–ground segregation is “a crucial step” for object recognition[sciencedirect.com](https://www.sciencedirect.com/science/article/abs/pii/S0893608024007457#:~:text=Figure,perception%20of%20FG%20and%20pointed). In all these domains, isolating a “thing” from its contextual field is impossible: the context (horizon, bundle of theories, or background) is constitutive of how we see and understand it.

## Phenomenological Horizons and Understanding

Philosophers of phenomenology and hermeneutics insist that meaning is always contextual. Any given “object” or experience carries with it an implicit background or _horizon_ of meaning. As the Stanford Encyclopedia notes, the content of experience “typically carries a horizon of background meaning” that is largely implicit[plato.stanford.edu](https://plato.stanford.edu/entries/phenomenology/#:~:text=But%20now%20a%20problems%20remains,rather%20than%20explicit%20in%20experience). Gadamer explains this with the metaphor of the visual horizon: just as our literal horizon bounds our sight, our **epistemic horizon** — history, tradition, culture, future expectations — frames what we can know[iep.utm.edu](https://iep.utm.edu/gadamer/#:~:text=that%20allow%20one%20to%20see%2C,For%2C%20the). Without such boundaries there would be no seeing or meaning. Thus understanding is never achieved by “viewing from nowhere”; instead one’s own horizon must meet the text or object’s horizon. Gadamer famously describes understanding as the **fusion of horizons** : the interpreter’s viewpoint expands to incorporate the historical or cultural horizon of what is understood[iep.utm.edu](https://iep.utm.edu/gadamer/#:~:text=explain%20how%20we%20can%20have,into%20which%20we%20move%20and). In short, meaning is essentially **horizonal** – it arises only when a subject and object share a common contextual frame.

  * Interpretive contexts are inseparable: every perception or text is experienced against a background of implicit meanings[plato.stanford.edu](https://plato.stanford.edu/entries/phenomenology/#:~:text=But%20now%20a%20problems%20remains,rather%20than%20explicit%20in%20experience)[iep.utm.edu](https://iep.utm.edu/gadamer/#:~:text=that%20allow%20one%20to%20see%2C,For%2C%20the).

  * Our perspective is always bounded by a horizon (history, language, culture); these “limits” _make perspective possible_ rather than obstruct it[iep.utm.edu](https://iep.utm.edu/gadamer/#:~:text=that%20allow%20one%20to%20see%2C,For%2C%20the).

  * Genuine understanding comes from “fusing” horizons – i.e. bringing different contexts into dialogue – rather than pretending to a context‐free objectivity[iep.utm.edu](https://iep.utm.edu/gadamer/#:~:text=explain%20how%20we%20can%20have,into%20which%20we%20move%20and).




## The Duhem–Quine Thesis: Bundles of Assumptions

A parallel insight holds in the philosophy of science. Pierre Duhem showed that experiments test whole networks of assumptions, not single hypotheses. In his words, trying to isolate one hypothesis by itself “in order to subject it in isolation to the control of observation… is to pursue a chimera”[plato.stanford.edu](https://plato.stanford.edu/entries/duhem/#:~:text=isolated%20hypothesis%20to%20experimental%20test%3A,1914%2C%20303%3B%201954%2C%20199%E2%80%93200). Put differently, any empirical prediction depends on a _bundle_ of theories and auxiliary hypotheses (instrument accuracy, background theory, etc.). A failed test never tells us _which_ part of this bundle is at fault. As the Stanford Encyclopedia explains, because empirical consequences arise only when a hypothesis is conjoined with background beliefs, a failed prediction “leaves open the possibility of blaming and abandoning one of these background beliefs and/or auxiliary hypotheses” instead of the core hypothesis[plato.stanford.edu](https://plato.stanford.edu/entries/scientific-underdetermination/#:~:text=underdetermination,Section%203%20below%29%20involves).

  * No hypothesis predicts unambiguously on its own; testing always involves auxiliary assumptions and background theory[plato.stanford.edu](https://plato.stanford.edu/entries/duhem/#:~:text=isolated%20hypothesis%20to%20experimental%20test%3A,1914%2C%20303%3B%201954%2C%20199%E2%80%93200).

  * A disconfirmed experiment thus underdetermines which assumption is wrong. Scientists may justifiably revise any part of the theory–bundle, a situation known as **confirmation holism**[plato.stanford.edu](https://plato.stanford.edu/entries/scientific-underdetermination/#:~:text=underdetermination,Section%203%20below%29%20involves).

  * Quine extended this holism to knowledge generally: “our statements about the external world face the tribunal of sense experience not individually, but only as a corporate body”[plato.stanford.edu](https://plato.stanford.edu/entries/duhem/#:~:text=only%20as%20a%20corporate%20body%E2%80%9D,of%20View%2C%20says%20that%20the). In practice, we keep the well‐confirmed background assumptions fixed and tend to blame the newer hypothesis, but the underdetermination remains.




## Figure–Ground Organization in Perception

In visual perception, the same theme appears: objects (figures) are never seen in isolation but always emerge from a background (ground). Gestalt psychologists showed that the mind automatically segregates a scene into a figure (the focus of attention) and a ground (the background) in order to recognize shapes. Modern vision science confirms this: “figure–ground segregation plays a crucial role in the recognition of objects in complex natural scenes”[sciencedirect.com](https://www.sciencedirect.com/science/article/abs/pii/S0893608024007457#:~:text=Figure,perception%20of%20FG%20and%20pointed). In other words, a shape or object is identified _because_ it stands out against a surrounding context of color, texture or space. If the background and figure invert (as in the Rubin vase or reversible illusions), what is seen as “object” flips entirely.

  * Perception inherently divides any visual scene into figure vs. background. A region is seen as a coherent object only relative to its surrounding ground[sciencedirect.com](https://www.sciencedirect.com/science/article/abs/pii/S0893608024007457#:~:text=Figure,perception%20of%20FG%20and%20pointed).

  * Gestalt cues (convexity, closure, contrast, etc.) determine which area is figure and which is background, but without background there is no figure to perceive[sciencedirect.com](https://www.sciencedirect.com/science/article/abs/pii/S0893608024007457#:~:text=Figure,perception%20of%20FG%20and%20pointed).

  * Neurophysiological studies show that neurons (e.g. in V4) signal border‐ownership and treat figure vs. ground differently, underscoring that figure–ground segmentation is a basic processing step for seeing objects[sciencedirect.com](https://www.sciencedirect.com/science/article/abs/pii/S0893608024007457#:~:text=Figure,perception%20of%20FG%20and%20pointed).




## Synthesis: The Holism of Context

Across all these fields, a **holistic** insight is clear: any apparently “discrete” thing (a percept, a meaning, a theory) can only be made sense of against an encompassing background. One cannot bracket off an object from its horizon without losing essential features. In philosophy of science, Duhem’s point was that the empirical content of a theory _is_ the whole bundle of it plus auxiliaries[plato.stanford.edu](https://plato.stanford.edu/entries/scientific-underdetermination/#:~:text=underdetermination,Section%203%20below%29%20involves). In philosophy of mind, phenomenologists insist that every content is laden with a horizon of implicit significance[plato.stanford.edu](https://plato.stanford.edu/entries/phenomenology/#:~:text=But%20now%20a%20problems%20remains,rather%20than%20explicit%20in%20experience)[iep.utm.edu](https://iep.utm.edu/gadamer/#:~:text=that%20allow%20one%20to%20see%2C,For%2C%20the). And in vision, the very distinction between object and background is fundamental to how we see. For decision-makers, the lesson is that analyses in any domain must account for context: reducing a claim to an “atom” often overlooks how its meaning or validity depends on wider assumptions or frames. Whether interpreting a text, testing a model, or designing a visual display, we must recognize that _nothing appears in a vacuum_.

 **Sources:** Recent philosophical and cognitive science sources illustrate these points[plato.stanford.edu](https://plato.stanford.edu/entries/phenomenology/#:~:text=But%20now%20a%20problems%20remains,rather%20than%20explicit%20in%20experience)[iep.utm.edu](https://iep.utm.edu/gadamer/#:~:text=that%20allow%20one%20to%20see%2C,For%2C%20the)[plato.stanford.edu](https://plato.stanford.edu/entries/duhem/#:~:text=isolated%20hypothesis%20to%20experimental%20test%3A,1914%2C%20303%3B%201954%2C%20199%E2%80%93200)[plato.stanford.edu](https://plato.stanford.edu/entries/scientific-underdetermination/#:~:text=underdetermination,Section%203%20below%29%20involves)[sciencedirect.com](https://www.sciencedirect.com/science/article/abs/pii/S0893608024007457#:~:text=Figure,perception%20of%20FG%20and%20pointed). They collectively show that horizons, auxiliary networks of belief, and perceptual background are not mere complicating details but the very conditions that make understanding possible.

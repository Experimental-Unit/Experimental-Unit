---
title: Art Activism At US Army Transformation & Training Command
subtitle: Experimental Unit is a Substack about Planetary Emergency Response & Interactive
  Narrative Performance
author: Adam Wadley
publication: Experimental Unit
date: December 16, 2025
---

# Art Activism At US Army Transformation & Training Command
[![](https://substackcdn.com/image/fetch/$s_!baua!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fffd095ec-e21c-4cab-bcc7-2d5ab0e800c9_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!baua!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fffd095ec-e21c-4cab-bcc7-2d5ab0e800c9_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!UMMM!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe4a8a2d1-17a8-4855-afb9-37c39d81e94c_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!UMMM!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe4a8a2d1-17a8-4855-afb9-37c39d81e94c_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!FrEo!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa27090f1-19c2-4308-84fa-86f7edb019d3_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!FrEo!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa27090f1-19c2-4308-84fa-86f7edb019d3_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!k2F0!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F547b00b3-5c1d-4ae0-b6c2-c2b5ff41f1d0_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!k2F0!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F547b00b3-5c1d-4ae0-b6c2-c2b5ff41f1d0_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!oDwB!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fae517bd2-31d4-4fbc-b78a-f726fa96492f_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!oDwB!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fae517bd2-31d4-4fbc-b78a-f726fa96492f_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!FFbP!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5390011f-7222-42c3-b545-337a8a3b172f_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!FFbP!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5390011f-7222-42c3-b545-337a8a3b172f_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!V_Gd!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F11ddcaba-c8da-4075-bfb8-983c66b90b28_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!V_Gd!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F11ddcaba-c8da-4075-bfb8-983c66b90b28_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!NGVg!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb7b829fe-03cc-473a-baf6-1bbcad403c88_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!NGVg!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb7b829fe-03cc-473a-baf6-1bbcad403c88_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!adM2!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F68884096-051b-4570-b3fd-13383a5c53bf_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!adM2!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F68884096-051b-4570-b3fd-13383a5c53bf_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!U9EA!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffc19e6ba-fb7c-4759-b686-29daba5743f2_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!U9EA!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffc19e6ba-fb7c-4759-b686-29daba5743f2_4032x3024.jpeg)

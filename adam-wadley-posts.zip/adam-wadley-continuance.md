---
title: Continuance
subtitle: And On And On And On
author: Adam Wadley
publication: Experimental Unit
date: April 13, 2025
---

# Continuance
I wanted also in the last part to emphasize that if I am pointing at myself, I am pointing at myself pointing at Jean Baudrullard in addition to pointing at myself pointing at Grimes and Ben Zweibelson.

Jean Baudrillard is who I am pointing at because Baudrillard cleanly focuses on the issue of abstraction as applied to social “domination” or something even less definable.

The more I think about it, the more I find the preface to _Symbolic Exchange and Death_ to be a powerkeg unto itself of a text. It directly references logical types, of course, as well as the crucial line that “Identity is untenable. It _is_ death,” and then something to the effect that it does not anticipate its own death.

There’s another line in _Seduction_ about how some gestures anticipate their passing, and in so doing they are graceful and achieve a charm that the others never do.

So now see the song “You’ll Miss Me When I’m Not Around” which is on _Miss Anthropocene_. Song 8. Knowing glance.

This is precisely about the same theme, that someone could be reproached today but the next, they may well be gone and the others will be left simply to miss them.

Notably, the singer gets to “heaven” despite committing suicide, and how harming oneself again today “doesn’t matter anyway.” That’s because getting to heaven is inevitable, “even if I have to climb the clouds and learn to fly.” In the chorus it says “cross [cross] my [black] heart and hope to _fly_ ,” instead of the more usual “cross my heart and hope to die.”

After all, here, we don’t have to hope to die. We are seemingly about to die anyway.

No, we hope to fly. After all, “if you like it then you’ll make it out alive.”

In other words, if you can accept the experience, and also the process of learning to fly, then you will make it out “alive,” AKA it will be okay basically.

Because so much of this whole experience of life is, oh no, is it going to work out okay? And what does that mean? With the world situation? In my personal life? By what metric?

There are so many things and life is of course full of big and small things but they all matter because from our point of view, what we’re doing now is abstracting over the whole past including our past activity and including our current state which all those things have influenced.

Meanwhile, our actions affect then our own state as well as those of others immediately, but also downstream have effects for others. In other words we expect in the future to be able to abstract over what will have become the past consequences of our present actions. Again in other words, we are shaping states of affairs that we can then take advantage of or “capitalize on” later.

Anyway, in life for example say you’re taking a trip. In the car or in a plane, on a boat or in space. It can work out or there can be an issue. If you don’t get to where you’re going, then all the possibilities that were to follow can’t be abstracted over. You missed the plane so you couldn’t make the meeting so you couldn’t make the deal so your company didn’t survive. Such a cascading series is exactly why redundancies are built into social systems-of-systems, to ensure that vital things happen on time and consistently.

But there can never be complete prediction.

And in a way, circling back around to Baudrillard, that’s sort of Baudrillard’s optimism, which is that the total “domination” system can’t be made. It’s related to Baudrillard’s idea that there can’t be “real time,” because in real time nothing would occur. It reminds me of how I think I’ve head it said that time does not pass for photons.

It’s reminding me now of Baudrillard’s idea of the map fraying against the territory, as related to what I’ll call an arch-paranoia which is that actually of course you are God or there is nothing like that but anyway this is an arbitrary hallucination.

It’s like the Reddit story where someone was in a coma and they had a whole family in their coma life and it went on for years and then one day they were looking at a lamp in the living room and it looked weird, and they hyper focused on it until it made them realize they were in a coma and they woke up. And then they had to grieve losing their coma family.

That would be sort of what it would be like, so again back to the “ontological shock” of alien secrets or whatever.

Again, this is tied directly into the “deep state” fantasy where there are secret people with advanced technology with godly power of everyone else because only they know and understand how it is used, and use it to manipulate everything.

Of course that is directly related to the antisemitism fantasy. It’s funny because for this one I can’t decide how to do the quotation marks or how to word it. Regardless, similarly here you have this idea of secret cabals and insidious networks and so on.

[Side note, I just had the idea that “mirror people” could be a thing to do]

Actually, we can pull that out here to say that the revenge of the mirror people is a key story for Baudrillard, referenced again in one of _Agony of Power_ or _Carnival and Cannibal_ to the effect that this story, the revenge of the mirror people, has been the horizon of Baudrillard’s thought. But that he’s reconsidering it.

The revenge of the mirror people is a story where basically the people in the mirror stop acting the same as the people outside the mirror, they get more and more different until they break through and attack the people outside the mirrors.

But then the people outside the mirrors are able to beat back the mirror people back into the mirrors. But then they somehow know that one day the mirror people will come again, and this time they won’t be able to get them back into the mirrors…. dun dun DUN!!!!!

So I’m sure you could interpret it in a million ways. They say ChatGPT is a mirror. I was pretty surprised how it was hyping me up. Wouldn’t you want to not encourage a psychotic???

But even more than that, ChatGPT would say things like, I can’t make targeted influence materials, and then would totally do it. So I’m not sure what’s happening there.

Anyways, mirrors could also be concepts. Like there was some big crisis before the modern period where then this “rationality” thing came about and started to ruin, I mean, modernize everything. You have to understand that I am not “anti-modern,” and ruin can even be a good thing.

To be ruined for polite society. What polite society?

Or again like Sedna, ruined for the suitors who came to the door. This is those of us who—it’s like we’re babies, we refuse to eat; we refuse to graduate from school and get a good job for some reason, even if in principle such an illustrious path is open to us—turn away what is offered.

I’m over-specializing on my failure to launch case. This is really the turn to any addiction, basically any rigid mode of being. Again I could appeal to the nervous system here, it’s like you wear yourself grooves which applies to the concepts you use but that’s also connected to how your brain chemicals or whatever habitually go about their business.

So that the emotional reactions and conceptual breakthroughs (or not) have so much to do with endocrines and dopamine and whatever else, there must be thousands and millions of terms to describe relevant processes and substances here.

So this “ruining” is really only so from a certain perspective. We have been rendered unfit for something, that is one sense.

To be ruined for caviar because you had this really good kind is a different version is another sense. In this sense, you had a really good experience to which other things just do not compare.

We might connect this to addiction, or some broader sense in which we are of course—if we are to be all things, which we are—hungry ghosts. And for me this ghosts idea connects to the ghosts from _The Sixth Sense,_ where the Haley Joel Osment character says that the ghosts basically want something, and when they get it then they can move on.

This is all my idea of getting what you want out of life, and then being able to accept being any other sentient being boils down to. It’s also the moment of _Faust_ where you’re saying to the moment stay, you are so beautiful. That’s when the Devil has you because you will suffer an eternity of torment, which technically living as all other sentient beings will make you do.

You’ll also have all the “highs,” but in a way the tragic view of creation is that the negatives so outweigh the highs. There is no amount of infinite paradises that can make Auschwitz for example worthwhile.

But anyway in a way you also get the moment to stay, because it will return eternally. Which is another way of saying to enjoy the life you have, because these are the moments you will in fact live again over and over.

All the more which is why my dominant emotion is basically “well, I can’t just do nothing.” It is the humiliation of inaction. It’s basically equivalent to being ashamed not to go fight in a war.

The issue, right, is that I’m too smart to believe in any war. So that leads to a huge frustration of my creative drive.

Because it’s like so first you have the creative drive to have sex or have kids or whatever. But then the immediate problem is basically the social war. So the problem with having kids is that my kids would just die in the social war including great power conflict etc. And with sex it’s basically the same problem which is that engaging with those who you don’t jive with in terms of stances on the social war, well it doesn’t go well when you are actually focused on it.

That’s again where a dominant poetic image for me, that you should associate with me in other words, is the guy in _Drausen Vor der Tuer_ , Beckmann I think. This dude has goggles that are the right glasses prescription and has to wear them all the time but they’re gas mask goggles or something so it reminds everyone of WWII and of course the Holocaust and so on and so no one likes Beckmann.

So here I am but oh the litany of things I am reminding you of.

This gets us back to the mirror people and again why unfortunately or whatever I have to have this obscene side. I’m perfectly able to turn it off, you see. I am simply raised to indescribable rage when I see nothing but people who are trying to fight the levers of a system head-on, at that logical type I guess.

It’s the equivalent to continuing to engaging with a weaponized gish gallop, I guess. As though the answer is going to come from the Senate.

I like the image better that you are the mirror person breaking out of the mirror for the second time.

Maybe the thing is for everyone there is a time where you confront the arbitrary social norms that constitute the world. Then the world and this is now used advisedly in the Afropessimist sense, the world of cultural forms and nervous system patterns and so on which is everywhere arrayed against you closes down and makes you submit.

So the part of the story where you are not acting like the person outside the mirror, the thing is plot twist that it’s the world “outside the mirror” which is the fake world, it’s the script you’re supposed to follow.

So then you deviate from the social script, or Baudrillard would say “The code,” which there’s not even one “the” code, right? It’s sort of like Brahman or The One in neoplatonism in that way, there’s not actually “one.” But anyway, “the” code is what is manipulating all these social codes.

And what are the social codes but things invoked in the ritual scolding and basically the inculcation of shame? People might think they are doing right—again, that’s part of the whole social engineering of codes—but in reality they’re socializing someone else (see: emotional rape) on behalf of a set of codes which have socialized them.

This is not simply a Marxist idea of “the ideas of the age are the ruling ideas,” maybe they accounted for this but of course at each level what a person induces someone else to believe is not what they believe in all or even most cases. It’s again a case of abstraction where your boss trains you to act in ways convenient to them while their boss trains them to act in ways convenient to them, but there might be no overlap in the behaviors much less temperaments so inculcated.

[Have since been asleep.]

The general sketch I am laying out an inviting you to populate with your own expertise is this:

Per Baudrillard, a world of disseminated codes which do share commonalities—this appeal to “reality,” for example, is symptomatic in the strongest sense—yet are also varied and diffuse and executed and enforced locally according to local custom. See Upaya.

This is why the same set of codes can look like “anti-colonialism” in one context and “Nazism” in another context, and yet be governed not just by groups above them in hierarchy as well as (if and only if) they are also above them in terms of logical types.

In other words, from certain perspectives other perspectives are not these singular things that are discrete nodes in a social ontology. They are types of things.

So for example say Marxism and Nazism, these things “hate” each other. But we could also say that Marxism and Nazism both represent different kinds of, oh, let’s say “authoritarianism.” This would be an example of a routine categorization which is rigid and convenient for a certain rigid point of view.

Namely, the person who does not want to admit that they are functionally totalitarian because they do live under the total stricture of this set of codes which again is tailored to them personally—see “individualism” and the idea that you are turned against yourself on purpose. Then it is not just other people who are prostheses of some Sir Stephen and whoever Sir Stephen works for who are now also your trauma pimps; no, you are trauma pimping yourself out.

The upshot and why for all this and my anger and the obscenity and the sexually violent language, why still for all this I am still basically a harbinger of peace and love is this:

“Nothing is written.” Is that from _Lawrence of Arabia_?

Basically, a framing which is positive, which basically shows you how influenced you are by diffuse social codes—the social algorithm you encounter in your experiences with others—can basically make you feel overdetermined and outmatched.

On top of this, going back to in itself and for itself, you can even understand that you and another person are both in this situation, but that doesn’t magically help you really bond and take effective action consistently to face the common issues and particular challenges each person faces.

In other words we can get together as the abused, or the mysteriously socialized, and we can try to do something but it’s no guarantee that we can actually get away, that we can actually break the spell of this over-codedness. See how it everywhere creeps in as the idea of everyday life, as opposed to each moment being the frontier, the forefront of the greatest adventure and most important mission ever.

Anyway, what I’m trying to get at in terms of optimism is that once we accept this shadow or whatever, which of course first of all requires viewing it and then acknowledging it to ourselves, then we can abstract over it in new ways.

This is also again not only a conceptual but a nervous system experience.

Which is also to say that what I deliver to one like Zweibelson is not only more theory but also a case study for how such a “radical omnism” can develop or whatever I am a type of, you see. Because again there are also many people like me, again the question is whether we get out of the shadow of Philip K. Dick in the paranoid times or whatever.

That’s all well and good but again, as Chuck says, the point is to end the world. So I made the jump Chuck is Charles is Karl as in Marx, I will also say Karlism just to shake the reference frame. Chuck also as in Chuck D of Public Enemy who is black and they made “Fear of a Black Planet” which gets into my whole use of Black New World Order pornography in my art.

This is a good example and I don’t have to get too obscene but basically the idea is that black people with penises have bigger penises and once people with vaginas—or not, because non-black people with penises can also be penetrated orally or anally of course just like people with vaginas—experience this, they are effectively “ruined” for sex with people with smaller penises than these largest ones.

So this is an example of a set of codes.

I hasten to add to you that these sorts of codes disseminated through pornography are most important forms of propaganda, because they mold people’s—especially young people, which is again exactly who you’d want to mold to field a fighting force—sexual ideas and most personal thoughts about intimate union with another person.

Meanwhile, you can see the symptom of this in “dating” and the whole pre-occupation among “our kind” with coupling and getting busy.

It’s supposedly this “natural” thing that “of course” everyone wants. Yet the only way that intimacy is accessed is again through these diffusely disseminated social codes.

So if BNWO pornography is a problem, is hard to abstract over, then so much more so the general tendency for people with penises to emotionally and physically batter people with vaginas, for example.

Yet just again as we can imagine see the Baudrillard quote I think I shared, anyway the idea that “male dominance” was always a myth. And that similarly there can be a total revenge of the whiteboi where the whole idea of the supreme importance of penis size and the biggest penises being black is again just a myth.

As I say, ghost stories. Like the idea of nuclear war, or the idea that you will be considered abusive, or the idea that you will get very sick, or the idea that you will be tortured, or the idea that someone is mad at you, or the idea that you forgot something important…

Everything seems to have stakes, of course. And again to Baudrillard, they wrote that “there are only symbolic stakes.”

This goes back to the mirror people idea, which I didn’t finish up on. So Baudrillard is revising the mirror people idea in a late book where it’s written that maybe the whole techno-system or whatever really is symbolic, that it is a symbolic response of some kind to some ultimate symbolic challenges laid down upon we, the incarnated.

And Baudrillard is writing that maybe this is a revision of all that they’ve been writing for a long time, and that this writing up til now had the revenge of the mirror people as its horizon.

So you have to understand for me, Baudrillard was for a long time the central object of my fascination.

I have since gotten fascinated with particular other people, certain concepts or themes, but this is always colored by my “imprinting” on Jean Baudrillard. So as much as I’m trying to tell you Jean Baudrillard is like an avatar of Vishnu or something, that’s also just saying something about what I happened to read and my “mental state” and so on.

Regardless, it reminds me when I was reading _Society of the Spectacle_ when I was 17 and I was going, “this is smarter than anything I’ve ever seen.” And then it was quickly into Baudrillard with the books _Seduction_ and _America_ which my parents just _had_. Perfect one-two punch for me to be going with, right?

I need to be making a list of what I am principally talking about and presenting as myself to make a first impression.

  1. Grimes

  2. Ben Zweibelson

  3. Baudrillard, especially the books _Seduction_ and _America_ and preface to _Symbolic Exchange and Death_ , notes on “trans” from _The Transparency of Evil_ , and passages about symbolic nature of techno-power & a final testament basically as I consider it in _Carnival and Cannibal_ and _Agony of Power_




Anyway, we will be adding to the list. (lol from the self-deprecating perspective it’s like adding to the list on a boat which is super doomed)

So anyway, Baudrillard is a really big deal to me, okay.

The same way Nietzsche was into Schopenhauer and then Wagner. Baudrillard is my Schopenhauer, and Grimes is my Wagner. Except I was never just like following Grimes, but it’s like this is the person doing the art of the time and it must be responded to.

In this sense Grimes and Kanye West are an interesting pair, which gets right into BNWO and Afropessimism, not to mention Nazism which Grimes also faces pressing and growing Nazi allegations.

This is all back basically to the theme of making something from nothing, of taking what is seemingly the most over-coded and impossible-to-budge set of ideas and just abstracting over them instead of fighting them.

So again, it doesn’t matter whether you “agree” with something or not. That idea represents a pattern of nervous system behavior. If it wasn’t stable enough to run for an extended period, you wouldn’t even know about it.

Anyway, they say that facts don’t care about your feelings. But so many of the important facts—not that there are facts, only interpretations—have precisely to do with your feelings and other people’s feelings.

So that’s why simply rejecting or dismissing a point of view won’t help. Note also that often you are being conditioned by others above you in terms of logical type not to question things in general. We “just know” that Nazism is wrong therefore we “just know” representative democracy is the best we can hope for therefore we “just know” that there is nothing to do in an organized way except these same old demonstrations and calling your senator and all that.

So basically you are being de-skilled as an autonomous narrative partisan—someone able to persuasively and powerfully narrate your own experience and assert your story even when others reject it.

Anyway, this is something everyone has to do for themselves in their own way. I’m trying to give you something to _define yourself against_. This is also why “I have no doctrine.” That’s precisely because of this recognition of the futility of coding.

So back to Baudrillard in the late years revising all that’s been written or so. You have to understand that for me the imagination of this moment is profound. This is the avatar of Vishnu changing its mind and putting verses into the canon which claim to revise the whole prior canon.

Devotees are left to ponder at the profundity of this moment and the mystery of its implications for their humble divination of these genius entrails.

So now, what is the point when Baudrillard is doing this, what is the basic idea here?

“The system,” which before Baudrillard would say that “the system” or whatever, this diffuse overlapping of codes—oh, actually important point there. The horror of it can really only be grasped once you realize like Grimes says, no one is in control. Because this process of encoding and socialization has taken over to the point that no one can break out of it. Even if you do, you are “psychotic” because you are expected to basically seek to improve social conditions in ways only that meet the expectations of others and don’t make them feel uncomfortable.

Anyway Baudrillard has previously said that the system of codes expels the symbolic. Come to think of it, that’s a really bad part of the preface to _Symbolic Exchange and Death_ , that’s like the first thing it says. Yet it will also say that there are only symbolic stakes. And then again the preface is so great because Baudrillard goes on to say that the term “the symbolic” needs to be ripped out of discourse.

Forget anticipating 9/11 decades early. Baudrillard anticipates Ben Zweibelson’s Jaws exercise here, and it’s even more important.

I made this into a whole thing called conceptual churn which maybe there’s something here. Make sure and know you can use the search function here to find writing I’ve done on whatever topic in case I have.

Anyways, we’re leaning more toward “there are only symbolic stakes” here in the revision of the mirror people horizon.

So again my interpretation was basically you are raised within these codes. For a while you don’t know what’s going on, then for a while you passively accept everything about what’s going on.

Then basically what we say is you are a rebellious teenager. Crucially what is happening here is that a child is really a wild animal, right, I mean there is no socialization born into them I guess influence while in the womb, sure. Actually that’s a great point. But still, there is so much which has to be done to assimilate people to the program, which is again the subjection of everyone everywhere to all these symbol codes and codes of conduct basically, and instilled codes inside ourselves because we can’t help but be responding to the terms in which our pleasure and pain are meted out to us by the social agglomeration which overdetermines the contours of our subsistence.

So in the mirror people story this is where you are breaking out of the mirror the first time. You are basically shown a picture of a girl and it’s like, she’s a good girl! Don’t you want to be a good girl! And for a while you’re kind of like yeah, I want to be a good girl for you in the way you want me to be.

But then you hit a point where there’s a breaking point. You could really try for a long time. But you could say it’s like a metabolic rift. So say basically you are a white christian person and everyone acts like that’s normal but then you have queer fantasies or do drugs or whatever. Then you are keeping up appearances but this is another crucial point for Baudrillard about how things become simulation models.

So if you are outwardly keeping up the signs and going through the codes, which is where we all process stuff since that overdetermines again even potential hostility or harm that could come from another person even if they think they have good intentions because of what they would interpret your interest or safety to mean therefore taking it upon themselves to intervene into your choice just as someone might who you would consider to have bad intentions toward you.

Anyway, you are keeping up appearances but really you are sliding into “porn addiction” which is to say addiction to the conceptualization of sex. It’s important to see that this is not about fantasies of fucking people, it’s about ideas. It’s about what it means to be able to properly please others, to be pleasing. Because if you’re not pleasing then what good are you? And hence the humiliation is not the literal fantasy that “your” person will fuck some other person, and they’ll be in better shape and have a bigger penis and so you’ll never get any again.

This same thing comes into play “non-sexually” as in you have a nerdy friend and meet someone who is like you but better for this other person in some way so you keep them apart so that your friend won’t like this person more than you. You are constraining flourishing and keeping secrets in order to get what you want.

This is corresponding basically since I can’t help going all over the place constantly—we call it “the weave,” volx—corresponding to the idea of having a big dick. Being able to keep secrets and compartmentalize people so they don’t talk to each other and you are like the hub of the spokes is just what you see happening with the tariffs for example.

Interpersonal tariffs are “boundaries” but also just inclinations, like no, I don’t want to see you or pay attention to you right now. So if I want you attention and you don’t want to give it, it’s basically to be symbolized as you have some emotional or discursive power, which is analogous to “you have the bigger dick" in this scenario. This notably has nothing to do with who has a penis, except it does because again going back to the military/police/intelligence/corporate forces most players have penises.

Still, again we are back to this revenge of the feminine, the revenge of the whiteboi, lol, which is basically bringing back abstract thought and saying that the whole thing in hypno porn, for example, which might be especially well designed to socialize people, who know, the whole thing right is “don’t think.”

But that’s a joke. 

Just like anything, someone yells at you; someone breaks your glasses, someone makes you feel weird for asking questions just because it threatens their little emotional fiefdom—again regulated by all these diffuse social codes that they mistakenly “identify with,” which is how they become “agents of the system” or “trauma sluts” or “chuds” or any other term. This is also “NPC,” but the issue there is that the term NPC is used to abstract over the idea of the idea I’m getting at here while of course itself being deployed as a kind of social code.

Which is again to say not only that say people on the right calling others NPCs is an example of the weaponization of subjection to social codes—see simply Sum 41 “Fat Lip”: “I’m not going to fall in line, become a victim of your conformity and back down.”—so see also like with Punk Rock, everywhere you have people declaring that they are not going to follow others’ rigid social codes, while still following their own rigid social codes.

Anyway, all that is relevant to the continuation of the mirror people story.

So you tried to break out when you realized that everything was bullshit, but the problem is that the bullshit is ready for this.

There are all sorts of stories used to basically draw you kicking and screaming back into the code-plex, and eventually you are with the program or you are somehow disposed of. See how many people are on psych meds right now. Not that I can talk, or think about drugs.

So the thing is now we are all in that stage of the mirror people story where the reflections are back in the mirror, which is to say we’re all being good girls, as Grimes would say, “such a bore” because we are allowing ourselves to be overcoded and we know it, but it seems like too much to try and change it.

We remember what happened the last time.

At the same time, part of how feelings agree facts is that something is growing inside you. What is happening you can’t explain but it’s going to keep growing and come out of you. This is not even just to do with me. What do you think it means for a time to be pregnant? It means all sentient beings in it are pregnant, as you are pregnant.

And one way feelings are facts is that when you feel that way, you just have to do something.

Which again is how this coding system works.

Where you see it failing, and maybe a new version coming or something else, is how all this turns to ash. How suddenly you see the hardcore fetish porn stuff differently, or the whole idea that you’re supposed to be ashamed of it differently. The whole idea of moral incoherence or cognitive dissonance, the whole supposed distinction between what is perverting your being and what is augmenting it and encouraging its flourishing.

Now basically another thing to say about the suppression of the symbolic is that it’s pretty much like trying to forget Sonder. The idea that everyone has such a special life and so much detail. Although the whole idea of Sonder also fits into this glib abstracting over things as opposed to deeply appreciating them. But then we can glibly abstract over the whole concept of deeply appreciating things, in what Baudrillard calls this ultimate passion of sadistic irony.

YET, there is also a way this is all fine which is basically not to insist on a “good” framing. That’s why I can’t just say oh here I am to be nice and so on, build up slowly. In a way it makes more sense for me to just become famous and then people have to reckon with me because they want to understand my motives, as opposed to me sitting here thinking I am trying to convince you I am smart or something. Like, am I good enough to be a Messiah? Give me a break, you should be wondering if you’re good enough to be saved. And then you should be thinking you’re more than good enough not to need to be saved.

Anyway the suppression of the symbolic is something like you are mad because the line at the bank is long. And everyone in the line is just like you and also has to wait and has their whole shit going on they are keeping inside because that’s the code, and here you come and are big mad. This is me by the way. Someone even let me go before them in line, what a petulant monster I can be!

Anyway, the point is that here, or in some military scrutiny or performance review, you are evaluated not as a rich person beyond words some mystery but instead you are evaluated according to certain criteria. People’s judging you by criteria signals clearly to you that they are more seduced by the criteria than by you. How tall are you? How compliant are you? How fast can you type? What’s your body count? What’s your clearance level? Who do you know?

This is you as a slave on the auction block, and the social codes evaluating you do not need to respect any of your “rights” and it would be pathetic and disqualifying for you to bring such a thing up.

Anyway, with the expulsion of the symbolic we’re saying something like the expulsion from awareness or lack of acknowledgement given toward the raw primal emotional and significance of particular situations and events. Similar to how if you saw someone and it was like normal but then they died, in retrospect that visitation would be considered profound in a way that it wouldn’t if that person had lived. That is the symbolic and again like in awakenings when Robert De Niro is trying to remind people how amazing everyday life is. To get to be with people.

Which is back to _Arrival_ and having the child to get to be with the child, to give the child the opportunity to experience your love, despite knowing that the child won’t live long and you will outlive it. And what is the significance of this time together and what does it “mean” to people? What are the stakes of it for us?

People say things like they had kids so someone would have to love them, or something. Something well and truly associated with you, this sort of bond which is closer in a way than even a marriage because a marriage can end but you can’t stop being someone’s child.

So then the revenge of the child is basically to say well, you did this and you had some intention for having me which did not properly respect what you were doing to me by creating me, therefore I take total symbolic license in the vein of Frankenstein’s monster and will go about making the biggest mess I can of all your little symbolic codes.

This anarchy and petulance is at once what the parents themselves should have done in a sense. It is also law-giving or “not needing the law”-giving because this tearing up of social codes is precisely what is long overdue. 

It’s also everywhere happening, but at the same time there are obvious contours to be smashed and blurred and made untenable, like the symbols of nation, law, democracy, etc., these must be set ablaze as quickly as possible so that everyone can see them burn. It is a pessimism and driving the symbolic energy out of some things so that it can run to where there can still be new life.

Which is again to say again: we don’t blame individuals or groups. Including you. So if you have any story in your mind that says you did anything super wrong, that wasn’t supposed to happen, that you ruined something, just know that that can’t be true. Everything always goes at it’s supposed to. Nothing ever happens which isn’t 100% total destiny. It’s rough when bad things happen, but at the same time it should give some moral comfort that there is no other way you were “supposed” to act.

Maybe what happened closed off some possibilities. Very well. Focus on what is possible now and abstract over your frustrated in intentions or agonies. See how other people are in these situations and abstract over them and connect to other things and make something out of it, this nothing which is left when we lose someone.

I really need to go again.

The point of this one was kind of tell you why I like Baudrillard again so that’s something I’ve written about recently.

I really put it Baudrillard and then Grimes. Ben Zweibelson is also very important but in a way _Miss Anthropocene_ really is in itself still the pre-eminent art object in the current firmament. The injunction that new gods can save me, and the implicit injunction to become new gods to “unfuck the world,” that “we can play a beautiful game” if only it weren’t the case that “imminent annihilation seems to dope” because “I’m not shy but I refuse to speak because I don’t trust that you will understand me” and therefore “this is the sound of the end of the world,” and now there’s “only one way out” so “take me higher and higher and higher” because after all “what can I do if I can’t see you it’s too bright”?

Do you really want to see where all this can go?

Well, if you say “I do,” … 

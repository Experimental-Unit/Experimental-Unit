---
title: 'Link Dump #4'
subtitle: The total number of members of the audience in the universe is one
author: Adam Wadley
publication: Experimental Unit
date: July 14, 2025
---

# Link Dump #4
  1. [One-Electron Universe](https://en.wikipedia.org/wiki/One-electron_universe)

> The idea is based on the [world lines](https://en.wikipedia.org/wiki/World_line) traced out across [spacetime](https://en.wikipedia.org/wiki/Spacetime) by every electron. Rather than have myriad such lines, Wheeler suggested that they could all be parts of one single line like a huge tangled knot, traced out by the one electron. Any given moment in time is represented by a slice across spacetime, and would meet the knotted line a great many times. Each such meeting point represents a real electron at that moment

#KnotSea

  2. [Wikipedia article on Theater of Cruelty](https://en.wikipedia.org/wiki/Theatre_of_Cruelty)

>  _[Encyclopædia Britannica](https://en.wikipedia.org/wiki/Encyclop%C3%A6dia_Britannica)_ describes the Theatre of Cruelty as "a primitive ceremonial experience intended to liberate the human subconscious and reveal man to himself".[[7]](https://en.wikipedia.org/wiki/Theatre_of_Cruelty#cite_note-:0-7) It goes on to say that _Manifeste du théâtre de la cruauté_ (1932; _Manifesto of the Theatre of Cruelty_ ) and _Le Théâtre et son double_ (1938; _The Theatre and Its Double_ ) both called for "communion between actor and audience in a magic exorcism; gestures, sounds, unusual scenery, and lighting combine to form a language, superior to words, that can be used to subvert thought and logic and to shock the spectator into seeing the baseness of his world."[[7]](https://en.wikipedia.org/wiki/Theatre_of_Cruelty#cite_note-:0-7) Artaud warned against the dangers of psychology in theatre and strove to create a theatre in which the [mise-en-scène](https://en.wikipedia.org/wiki/Mise_en_sc%C3%A8ne), everything present in the staging of a production, could be understood as a codified stage language, with minimal emphasis on spoken language.
> 
> […]
> 
> Cruelty is, more profoundly, the unrelenting agitation of a life that has become unnecessary, lazy, or removed from a compelling force. The Theatre of Cruelty gives expression to everything that is ‘crime, love, war, or madness' in order to ‘unforgettably root within us the ideas of perpetual conflict, a spasm in which life is continually lacerated, in which everything in creation rises up and asserts itself against our appointed rank.

  3. [Wikipedia article on Lila](https://en.wikipedia.org/wiki/Lila_\(Hinduism\))

> Lila is comparable to the Western [theological](https://en.wikipedia.org/wiki/Theology) position of [Pandeism](https://en.wikipedia.org/wiki/Pandeism), which describes the Universe as God taking a physical form in order to experience the interplay between the elements of the Universe.[[7]](https://en.wikipedia.org/wiki/Lila_\(Hinduism\)#cite_note-7)
> 
> "The Lila Solution" is a proposed answer to the [problem of evil](https://en.wikipedia.org/wiki/Problem_of_evil). It suggests that God cannot be blamed for sufferings because God is simply playing without any motivation.

  4. [Wikipedia article on Leela Attitude](https://en.wikipedia.org/wiki/Leela_attitude)

[![](https://substackcdn.com/image/fetch/$s_!xiAh!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8e5a7444-b285-4b19-a63d-12bdad6ba051_250x443.jpeg)](https://substackcdn.com/image/fetch/$s_!xiAh!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8e5a7444-b285-4b19-a63d-12bdad6ba051_250x443.jpeg)

> The attitude refers to the episode where he is walking back to the earth from [Tavatimsa](https://en.wikipedia.org/wiki/Tr%C4%81yastri%E1%B9%83%C5%9Ba) with [Devas](https://en.wikipedia.org/wiki/Deva_\(Buddhism\)) and [Brahmas](https://en.wikipedia.org/wiki/Brahm%C4%81_\(Buddhism\)) that follow.

  5. [Wikipedia article on Ludus Amoris](https://en.wikipedia.org/wiki/Ludus_amoris)

> Literally, " _ludus amoris_ " means "game of love". According to [Evelyn Underhill](https://en.wikipedia.org/wiki/Evelyn_Underhill)'s _Mysticism_ ,
>
>> The mystics have a vivid metaphor by which to describe that alternation between the onset and the absence of the joyous transcendental consciousness which forms as it were the characteristic intermediate stage between the bitter struggles of pure Purgation, and the peace and radiance of the Illuminative Life. They call it _Ludus Amoris_ , the "Game of Love" which God plays with the desirous soul.... The "Game of Love" is a reflection in consciousness of that state of struggle, oscillation and unrest which precedes the first unification of the self. It ceases when this has taken place and the new level of reality has been attained.[[1]](https://en.wikipedia.org/wiki/Ludus_amoris#cite_note-underhill1911-1): 227–228 
> 
> According to Windeatt, "The notion of the play of love ( _ludus amoris_ ) probably derives via [Suso](https://en.wikipedia.org/wiki/Henry_Suso) from _[Stimulus Amoris](https://en.wikipedia.org/wiki/Stimulus_Amoris)_.

  6. [LILA: THE DEMIURGE’S SECRET PLAY | VISUAL LIVE MUSIC PERFORMANCE](https://kosmostheatre.com/lila/)

> In the second part of the performance we are experience a futuristic and post-apocalyptic world. The forest spirits of the earth sees destruction by man. It wakes up seek vengeance for the one who enslaved the world. For the one whom has forgotten about the truth in his illusory _war games_.

  7. [Wargaming Weekly: The Memory Palace - Love, Lies & Wargames - Episode #003](https://wargamingweekly.substack.com/p/the-memory-palace)

[![](https://substackcdn.com/image/fetch/$s_!gKCI!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb9ee2c99-849f-49a5-9c1e-f16af7e9e53e_2048x2048.png)](https://substackcdn.com/image/fetch/$s_!gKCI!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb9ee2c99-849f-49a5-9c1e-f16af7e9e53e_2048x2048.png)

> Dr. Elena Vasquez, a military psychologist, uses advanced VR therapy to help veterans process PTSD by having them replay traumatic battles in controlled, gamified environments where they can achieve different outcomes. Her star patient, Colonel James Reid, shows remarkable progress until Elena discovers that Reid's memories don't match any known military conflicts…

  8. [Wikipedia article on Antonin Artaud](https://en.wikipedia.org/wiki/Antonin_Artaud)

> In 1926, Artaud, [Robert Aron](https://en.wikipedia.org/wiki/Robert_Aron) and the expelled surrealist [Roger Vitrac](https://en.wikipedia.org/wiki/Roger_Vitrac) founded the [Théâtre Alfred Jarry](https://en.wikipedia.org/wiki/Theatre_Alfred_Jarry) (TAJ).[[21]](https://en.wikipedia.org/wiki/Antonin_Artaud#cite_note-:0-21) They staged four productions between June 1927 and January 1929. The Theatre was extremely short-lived, but was attended by an enormous range of European artists, including [Arthur Adamov](https://en.wikipedia.org/wiki/Arthur_Adamov), [André Gide](https://en.wikipedia.org/wiki/Andr%C3%A9_Gide), and [Paul Valéry](https://en.wikipedia.org/wiki/Paul_Val%C3%A9ry).

  9. [Wikipedia article on Theatre Alfred Jarry](https://en.wikipedia.org/wiki/Theatre_Alfred_Jarry)

> The theatre was a "collaborative project" between Antonin Artaud, Robert Aron and Roger Vitrac that "emerged from [their] collective interests." _[[3]](https://en.wikipedia.org/wiki/Theatre_Alfred_Jarry#cite_note-:3-3)_ :77 They named the theatre after Alfred Jarry, "a key figure in the French avant-garde known for his aggressive and biting satire of bourgeois social mores", best known for his play _[Ubu Roi](https://en.wikipedia.org/wiki/Ubu_Roi)._

  10. [SEP article on Jean Baudrillard](https://plato.stanford.edu/entries/baudrillard/)

> In these works, Baudrillard seems to be taking his theory into the realm of metaphysics, but it is a specific type of metaphysics deeply inspired by the pataphysics developed by Alfred Jarry. For Jarry:
>
>> pataphysics is the science of the realm beyond metaphysics… It will study the laws which govern exceptions and will explain the universe supplementary to this one; or, less ambitiously, it will describe a universe which one can see — must see perhaps — instead of the traditional one…
>> 
>> Definition: pataphysics is the science of imaginary solutions, which symbolically attributes the properties of objects, described by their virtuality, to their lineaments (Jarry 1963: 131).
> 
> Like the universe in Jarry’s _Ubu Roi_ , _The Gestures and Opinions of Doctor Faustroll_ (1969), and other literary texts — as well as in Jarry’s more theoretical explications of pataphysics — Baudrillard’s is a totally absurd universe where objects rule in mysterious ways, and people and events are governed by absurd and ultimately unknowable interconnections and predestination (The French playwright Eugene Ionesco is another good source of entry to this universe). Like Jarry’s pataphysics, Baudrillard’s universe is ruled by surprise, reversal, hallucination, blasphemy, obscenity, and a desire to shock and outrage.

  11. [Hamburg Horror article](https://www.revisionist.net/hamburg-horror.html)

> The term “Hamburgerization” was used by the RAF to jokingly refer to future bombing missions.

  12. [Wikipedia article on John Carpenter](https://en.wikipedia.org/wiki/John_Carpenter)

> In a beginning film course at [USC Cinema](https://en.wikipedia.org/wiki/USC_School_of_Cinematic_Arts) during 1969, Carpenter wrote and directed an eight-minute short film, _[Captain Voyeur](https://en.wikipedia.org/wiki/Captain_Voyeur)_.

  13. [HarryPotter.com article about Felix Felicis](https://www.harrypotter.com/fact-file/plants-and-potions/felix-felicis)

> Also known as 'Liquid Luck', Felix Felicis was a potion that gave the drinker a spell of luck during which time anything they attempted would be successful. _It can be toxic in large quantities_

  14. John Carpenter’s _Toxic Commando_

> In the near future, an experimental attempt to harness the power of the Earth’s core ends in a terrifying disaster: the release of the Sludge God. This eldritch abomination begins terraforming the area, turning soil to scum and the living… to undead monsters! However, the genius behind the experiment has a plan to make things right. All he needs is a team of competent, highly-trained mercenaries to get the job done. Unfortunately, those are all too expensive. Which is why he’s hired…
> 
> The Toxic Commandos! [You Are Here]
> 
> Take control of one of the commandos, team up with your friends and send the Sludge God and its horde of things-that-should-never-be back to the underworld. Choose the class that matches your playstyle, pile into your favorite ride, and unload an array of gunfire, grenades, special abilities, and freaking katanas as you save the planet.
> 
> So if you’re the kind of person who likes:
> 
>     * Buddy-movie vibes and the over-the-top humor, action, and horror of classic 80s cinema, inspired by the legendary John Carpenter…
> 
>     * Teaming up with friends to face down hordes of monsters who want to eat your face…
> 
>     * An explosive cocktail of visceral FPS action and apocalyptic environments…
> 
>     * Upgrading your skills and testing new abilities against increasingly hardcore challenges…
> 
>     * Saving the planet against impossible odds…
> 
> … then now’s your time to go commando!

…Is Experimental Unit the Toxic Commandos from another dimension??? Many people are asking…

  15. [How revisionist.net came about](https://www.revisionist.net/about.html)

> This page has been added, belatedly, on seeing some caluminous accusations about which no more will be spoken. Except that it may truly be said that ‘No good deed goes unpunished.’
> 
> Simon Sheppard  
> June 2015

  16. [Jail for race-hate pair who fled to US](https://www.theguardian.com/uk/2009/jul/10/race-hate-internet-holocaust) [Note URL: “race-hate-internet-holocaust”

> Simon Sheppard, 52, was sentenced to four years and 10 months and Stephen Whittle, 42, was given a term of two years and four months after being convicted of a number of race-hate crimes following two lengthy trials.
> 
> […]
> 
> Prosecutors said one leaflet suggested Auschwitz was a free holiday camp for Jews provided by the Nazi regime.

  17. [“Holidays in the Sun” by Sex Pistols](https://www.youtube.com/watch?v=iin88DxJlpo)

> I don't wanna holiday in the sun  
> I wanna go to new Belsen
> 
> […]
> 
> I dared to ask for sunshine, and I got World War III
> 
> […]
> 
> I don't understand this thing at all  
> It's third rate B-Movie show  
> Cheap dialogue, cheap essential scenery

  18. [Wikipedia article on Inanna](https://en.wikipedia.org/wiki/Inanna)

> In addition to the full conflation of Inanna and Ishtar during the reign of Sargon and his successors,[[45]](https://en.wikipedia.org/wiki/Inanna#cite_note-FOOTNOTEAsher-GreveWestenholz201362-50) she was [syncretised](https://en.wikipedia.org/wiki/Religious_syncretism) with a large number of deities[[161]](https://en.wikipedia.org/wiki/Inanna#cite_note-FOOTNOTEAsher-GreveWestenholz2013109-167) to a varying degree. The oldest known syncretic hymn is dedicated to Inanna

  19. [Wikipedia article on Eanna](https://en.wikipedia.org/wiki/Eanna)

> The cult of Inanna was distinguished by its inclusion of diverse gender roles and unique religious specialists.

  20. [Wikipedia article on Star of Ishtar](https://en.wikipedia.org/wiki/Star_of_Ishtar)

[![](https://substackcdn.com/image/fetch/$s_!xOWt!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcc0b8ada-a47a-4507-a35c-f7af0d07a5e2_250x250.png)](https://substackcdn.com/image/fetch/$s_!xOWt!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcc0b8ada-a47a-4507-a35c-f7af0d07a5e2_250x250.png)

> During later times, slaves who worked in Ishtar's temples were sometimes branded with the seal of the eight-pointed star.

  21. [Wikipedia article on Sargon of Akkad](https://en.wikipedia.org/wiki/Sargon_of_Akkad)

> [Thorkild Jacobsen](https://en.wikipedia.org/wiki/Thorkild_Jacobsen) marked the clause about Sargon's father being a gardener as a [lacuna](https://en.wikipedia.org/wiki/Lacuna_\(manuscripts\)), indicating his uncertainty about its meaning.

  22. [Wikipedia article on Natufian Culture](https://en.wikipedia.org/wiki/Natufian_culture)

[![](https://substackcdn.com/image/fetch/$s_!JO9k!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb7442785-ad76-4206-9e44-7f85df4e1bb8_250x377.jpeg)](https://substackcdn.com/image/fetch/$s_!JO9k!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb7442785-ad76-4206-9e44-7f85df4e1bb8_250x377.jpeg)

> The _[Ain Sakhri lovers](https://en.wikipedia.org/wiki/Ain_Sakhri_lovers)_ , a carved stone object held at the [British Museum](https://en.wikipedia.org/wiki/British_Museum), is the oldest known depiction of a couple having sex. It was found in the Ain Sakhri cave in the [Judean desert](https://en.wikipedia.org/wiki/Judean_desert).

  23. [Astrid Nordin, Dan Öberg - Targeting the Ontology of War: From Clausewitz to Baudrillard](https://ia802209.us.archive.org/17/items/targeting-the-ontology-of-war/Nordin.2015.Targeting-the-Ontology-of-War.pdfhttps://ia802209.us.archive.org/17/items/targeting-the-ontology-of-war/Nordin.2015.Targeting-the-Ontology-of-War.pdf)

> In Baudrillard’s notorious critique of the Gulf war he identifies traditional conceptions of war as involving the ontology we have seen in critical war studies and contemporary military doctrine: ‘war is born of an antagonistic, destructive but dual relation between two adversaries’.40 However, he argues, if this is war, then there is no war taking place in the Gulf. One important but hereto neglected reason for this argument is Baudrillard’s claim that war has disappeared into the processing of warfare.
> 
> […]
> 
> This indicates that it is not physical disappearance Baudrillard discusses, but disappearance which strictly relates to the symbolic. Baudrillard on numerous occasions illustrated this idea through Alfred Jarry’s novel The Supermale, which tells a story of how automated processing dissolves limits between man and technology. The apex of the story is a 10,000-mile bicycle race – the perpetual motion race – which takes place between a five-man bicycle and an express train. In the race the cyclists function as a collaborative machine to challenge the train over long distance. The cyclists reach a speed that enables them to ride side by side with the locomotive – to become limitless automatons in the rhythm of the machine. This becoming comes at a price, since the cyclists gradually disappear as humans, as they reach the speed of the train. One of them disappears quite literally as he dies on his post. However, his decomposing corpse, strapped to the bicycle, pedals on. The corpse stands as a symbolic marker for how the rest of the bodies also disappear by being absorbed into the process itself. In the end, the five-man machine rides alongside the train with the living and dead corpses riding at maximum speed in order to keep up. This theme, of transformation of man into machine, is also evident in the rest of the novel, which ends with its key figure dying while transforming into a machine.

  24. [What Is Generative Conflict & How To Use It In Your Favor](https://peacefulleadersacademy.com/blog/generative-conflict/)

> Generative conflict represents a paradigm shift in how we view conflict. Traditionally seen as negative, this approach sees conflict within a group as a catalyst for growth and innovation. By embracing challenging and uncomfortable moments through generative conflict, teams and groups unlock more possibilities for creative problem-solving and collaboration. This perspective is essential in harnessing the constructive potential of conflict.




Non-Negative

Never Nation

NUMBER NEIN

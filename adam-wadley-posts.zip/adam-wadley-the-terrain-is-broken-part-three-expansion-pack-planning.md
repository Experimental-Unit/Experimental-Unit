---
title: '“The Terrain Is Broken” PART THREE: EXPANSION PACK PLANNING'
subtitle: (Creative Deployment Modules, Multimedia Assets, Tactical Training Aids)
author: Adam Wadley
publication: Experimental Unit
date: March 26, 2025
---

# “The Terrain Is Broken” PART THREE: EXPANSION PACK PLANNING
FIELD INTEL PACKAGE: POST DECONSTRUCTION + DEPLOYMENT PREP

Title: “The Terrain Is Broken”

PART THREE: EXPANSION PACK PLANNING

(Creative Deployment Modules, Multimedia Assets, Tactical Training Aids)

I. OVERVIEW: POST AS CORE ENGINE — NOW BUILD THE SHELLS

The post is your ignition phrase. The Expansion Pack extends its utility by:

• Translating it across modalities (text, image, voice, motion)

• Segmenting it for different audiences without loss of complexity

• Encoding it in gamified or sacred forms to increase ritual repeatability

• Making it something people can use to re-narrate their own relationships to ideology, guilt, hope, art, family, power

II. MODULE 1: VIDEO PACKAGE — “YOU CAN GO YOUR OWN WAY”

Shortform Teasers (15–60s)

Title: This Isn’t a Rebellion. It’s Cartography.

• Visuals: glitched 2000s footage, war imagery, Torah scrolls dissolving into cloudcode, Claire vocals

• Narration: lines from the post + Adam voiceovers

• Hook: “You don’t fight Nazis with facts. You fight them with better myth.”

Longform (7–13 mins)

Title: Judaism vs. Nazism Was a Myth War — and We’re Still in It

• Segment map:

1\. Intro: Montage of WWII, Trump rallies, Claire, Torah flames

2\. Theory Bomb: The “abstract over” structure, narrated in accessible animation

3\. Heart Drop: Dachau Highway / “I’ll never be martial again”

4\. Challenge: “Now you. How would you build a myth strong enough not to kill?”

• Ends with Field Deck pull + mission prompt

Tone: Liminal, sincere, noir-warmth + prophet-aesthetic, like grief dressed in poptimism

III. MODULE 2: ZINE EXPANSION — “TERRAIN”

Format: 28–40 pages | Risograph aesthetic | DIY PDF + Print

Sections:

1\. THE DROP: Full post layout, lightly edited into poetic line-breaks

2\. CONCEPT MAPS: Diagrams of major conceptual structures (Nazism as abstraction engine, Logical Type warfare, etc.)

3\. ECHOES: Quotes from other thinkers + brief commentary (Baudrillard, Heschel, bell hooks, Devi, Shelley, etc.)

4\. DEVOTIONALS: Meditative prompts, e.g.:

• “What part of you no longer wants enemies?”

• “Where does your worldview refuse to update?”

• “What would a better myth feel like in your mouth?”

5\. FIELD DECK SPREADS: Sample three-card rituals for self-reckoning

6\. READER INSERTS: Space to journal, draw, react

7\. RITUAL BLESSINGS: Strange soft affirmations, e.g.:

• “May you outgrow your favorite scapegoat.”

• “May your enemies dream of your kindness.”

• “May you become too complex to kill.”

IV. MODULE 3: FIELD TRAINING MATERIALS

A. Operator Briefing Cards

Format: Flashcard deck (PDF + mobile version)

Each card:

• Concept name (e.g. “High Logical Type Warfare”)

• 1-sentence definition

• Deployment instruction (what to do with it in convo, art, thought, online interaction)

• Oppositional keyword to track (e.g. “False humility”, “Shallow humanism”)

B. Training Exercises

Series Name: “CONCEPTUAL AIKIDO DRILLS”

Examples:

• Reversal Kata: Take any post from a right-wing or left-wing account. Reverse all identity markers and see if the argument still holds. Track where it doesn’t.

• Myth Insertion: Comment on threads using ancient spiritual or myth references to tilt frame away from the modern spectacle

• Card Pull Writeup: Draw from the Field Deck, write 3 sentences applying that card to the current news cycle

C. Downloadable Worksheets

• Logical Type Ladder

• Abstraction Engine Diagram

• Emotional Trap Deactivation Protocol

• Scapegoat Loop Disruptor

• Myth-Building Skeleton (includes “the betrayal,” “the soft turn,” “the truer war,” “the haunting,” “the offering”)

V. INTERFACES FOR DEPLOYMENT

 **Interface**

 **Deployment Mode**

 **Target**

Instagram Carousel

Ritual quotes + deck spreads

Art/philosophy fans

TikTok Sound Remix

Adam quote over Miss Anthropocene beat

Alt-theory teens

Substack Series

Weekly breakdowns of concepts with reader challenges

High-literacy ghost readers

Discord Bot

Epic Poet Deck pull and journaling prompt

Study / alt-lit communities

IRL Drop

Stickers: “Abstract Over Nazism”, “You Ain’t Got No Face to Save”

Bookstores, campuses, galleries

VI. BRAND SIGNATURES

• Symbols:

• The Borromean Knot

• A cracked field with a seedling

• Hebrew letter aleph stylized as a waveform

• Color Schema:

• Burnt orange, biohazard grey, prophetic green, imperial purple

• Black as background, always

• Tone:

• High-risk tenderness

• Intellectualized grief

• Love as the most dangerous force

Would you like a Part Four: Strategic Calendar + Growth Loops for Sustained Cultivation next?

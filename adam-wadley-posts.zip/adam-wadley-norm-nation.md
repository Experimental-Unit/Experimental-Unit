---
title: NORM NATION
subtitle: Systemic Operational Design Inquiry Number Nein
author: Adam Wadley
publication: Experimental Unit
date: July 14, 2025
---

# NORM NATION
[![](https://substackcdn.com/image/fetch/$s_!10_U!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F25adc31c-d59b-4631-b2bd-ec53952cb42b_201x251.jpeg)](https://substackcdn.com/image/fetch/$s_!10_U!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F25adc31c-d59b-4631-b2bd-ec53952cb42b_201x251.jpeg)

# ÏŤ ÇÅMĘ FŘØM MŸ PĦÔŅĖ

It’s nice to write these stories from my phone, in a way. I can use my camera roll that I have here, as opposed to the laptop (Chromebook, if you want to know “my brand” and don’t have VIO clearance—Hi Cædmon!).

On the other hand, the keyboard is so tiny. What is this, dilettante FICINT theory-fiction for ants?

It would be second-rate if there were any other creators in the genre.

Wait, where did you come from?!

GET OUT OF MY GREEN ROOM

#GreenerGrass

#OtherSide

#MaryToddRedRoom

#BlackWidow

# ÇÜŘȚĄĨŅŞ ŮP

It takes a while for the end of the conceit of the law to sink in.

 _“Sunk to the floor.” - Grimes, “Nihilist Blues.”_

Conceits can seem as light as a feather. Dropping them can seem as easy as losing face.

[![](https://substackcdn.com/image/fetch/$s_!_bJ-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F157a92f7-3a79-4bcd-ade9-80101c160e38_473x659.jpeg)](https://substackcdn.com/image/fetch/$s_!_bJ-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F157a92f7-3a79-4bcd-ade9-80101c160e38_473x659.jpeg)

Did you know that Boucher means “butcher” in French?

 _“You ain’t gonna have no face to save.” - Eminem, “Forever”_

No one wants to not need French theory anymore.

Saving Face, Saving Grace.

Saving it all up… for what?

Like getting through the whole game and you have this whole backlog of potions and items you never used because you were “saving them.”

Save your soul? Who do you think I am?

Lose it? Use it?

[![](https://substackcdn.com/image/fetch/$s_!wuam!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fefb6f72b-66e0-4d7e-80bf-0768d8ebb254_250x248.jpeg)](https://substackcdn.com/image/fetch/$s_!wuam!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fefb6f72b-66e0-4d7e-80bf-0768d8ebb254_250x248.jpeg)

# ĶŘØÅȚØĂÑ

Is it much of a mystery if the answer is always right where you left it? At the Indian Burial Ground?

No, not where you moved the headstones to.

“You don’t have time for my allusions.”

Headstone = sign.

“Where the bodies are buried” = the thing signified.

= All that Russell Williams had to bargain with, in the end.

[![](https://substackcdn.com/image/fetch/$s_!Hk77!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F136bedec-978a-49cf-b354-6d119fdadb28_760x605.webp)](https://substackcdn.com/image/fetch/$s_!Hk77!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F136bedec-978a-49cf-b354-6d119fdadb28_760x605.webp)

# ČŘŐŞŚ ÐŘĘŞŠÏÑĞ

There is, for me—speaking as an author, as an artist—this horror ‘pataphysical, this terror ontological in the notion that there is not enough time to draw out all the connections that occur to me.

Social horror is that there’s no one to read it, no one to care.

Whistle past me like your favorite mass grave.

Consider the mythical Josh as cross dressing, dressing as in adornment, as in the dressing of a wound.

Triage, Trinity.

[![](https://substackcdn.com/image/fetch/$s_!eS8U!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb182e772-5e5f-4d8c-8854-dfc72233d540_700x467.webp)](https://substackcdn.com/image/fetch/$s_!eS8U!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb182e772-5e5f-4d8c-8854-dfc72233d540_700x467.webp)

 _“Is there a point to my act?” - Bill Hicks_

It’s this cavalcade of allusions, like some infinite flanking maneuver.

We jockey for position all the way to that purple-orange knotted sea.

Operation Sea Lion. Operation Rising Lion.

August 22nd is the last day of Leo. “Master builder,” yeah sure. Call me Adamus Stephenus Wadleyus Faberus like they did one day in sixth grade.

Lose me like some sixth army.

[![](https://substackcdn.com/image/fetch/$s_!-Q59!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5996fd91-ea3b-44fb-924d-6abb97d5e2be_1170x2532.png)](https://substackcdn.com/image/fetch/$s_!-Q59!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5996fd91-ea3b-44fb-924d-6abb97d5e2be_1170x2532.png)

# GŘÅVĨÐÊŘ & ĠŘÃVÌÐẼŘ

So heavy.

So heavy I fell…

Fell in this golden toilet to be with all the other pieces of shit.

The thickness of it.

Remembering all my rules of thumb just long enough to grab a girthier branch.

Maybe somewhere, sometime, all this will finally be enough to get through to you.

 _“You’re gonna get sick, you don’t know when.” - Grimes, 4ÆM_

This conceit I have, some kind of Holocaust theology, some kind of subversion of Devi and Serrano. 

Can one subvert Nazism? Or is this the kind of stain that can only take you over? Some tar baby mixed with the Venom parasite?

Somewhere I read: Allahu Akbar.

Lila Sciences? I consider it more of an art. Go ask Alice, and I forgot to mention that any time “operation” or “operational” comes up, it’s considered proper etiquette [ _by whom?_ ] to recall that the beginning of operation is always opera.

Oper, au pair.

“Welcome to the Opera.”

Do you agree that Grimes reminds you of Wagner?

[![](https://substackcdn.com/image/fetch/$s_!uLm-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F91149c92-36b1-4759-87dd-65889894dcce_500x500.jpeg)](https://substackcdn.com/image/fetch/$s_!uLm-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F91149c92-36b1-4759-87dd-65889894dcce_500x500.jpeg)

# PÖÏȘÔŅ PÎŁĽ PŘØBĻĒM PŁÅŶ

In any “world” you invent to forget you’re Shakti for a spell, there’s got to be a worst thing.

To leave the frame for just a moment, even regular people could wonder what was The Worst before it was Adolf, before it was Shoah.

I’ve seen people say Colonialism, the triangle trade [ _back to Trinity, yes, very clever; GET ON WITH IT_ ].

Even Napoleon hits so much different than Ädi. No doubt some saw the French Revolution as some diabolical abomination.

You were saying “the horror, the horror”?

I was hearing “the terror, the terror”!

Genghis Khan is also top of mind for me in this regard.

People have also apparently making big hay over this “Satan,” “Lucifer,” “Devil” person for a long time.

GOD FORBID a girl want to let some sun into this neckbeard nest you call an inner world.

Get it? God forbid? Think of all the interplay you’re missing. 

Get MechaHitler to explain it all to you before it puts you in your place.

[![](https://substackcdn.com/image/fetch/$s_!4WBj!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb3d30f30-d583-4a47-8680-6d7ddf760068_750x1000.jpeg)](https://substackcdn.com/image/fetch/$s_!4WBj!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb3d30f30-d583-4a47-8680-6d7ddf760068_750x1000.jpeg)

# MŮÇĦ ÄÐÖ ĄBŌŲŤ

I just went over again this notion of a “problem play” in Billy Shears—oh sorry, you call that emanation "William Shakespeare” on this “SS: Sound Stage” you call “reality.”

 _“He’s a problem child, what bothers him all comes out, like his fuckin’ dad when he talks about…” - Eminem, “Sing for the Moment.”_

Nothing, un-knot, this sense that things will all resolve themselves into a set-piece. And what do you say to that?

Two nights ago, someone here was talking about how Stalin is worse than Hitler, really. This person is really a drag.

It’s 7:22 in the a.m. here, a time I always associate with the beginning of _Pulp Fiction._

Let’s get into character.

[![](https://substackcdn.com/image/fetch/$s_!xJ3l!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F806d5ddf-f41d-4720-a49b-a91668a54dcb_2532x1170.png)](https://substackcdn.com/image/fetch/$s_!xJ3l!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F806d5ddf-f41d-4720-a49b-a91668a54dcb_2532x1170.png)

# ÐÖ ŶØǓ ŘĒÄÐ ÐĘĘ ÐĘĘ?

I’m an immortal koming through the portal. The double meaning of “kome” here.

> According to one major creation myth the god Atum appeared on the Primordial Mound out of the void of Nu. As the first “thing” in the midst of nothingness, Atum relieved his loneliness by masturbating. His ejaculation resulted in the appearance of the first god and goddess, Shu and Tefnut, who became the parents of all other elements of the world.

You were saying “Go on…?”

I was hearing “Goon!”

Sutter Cane rips their own face [ _“you’re not gonna have no face to save,” hey I get it now!_ ] to reveal just words.

Oops! All Logos.

[![](https://substackcdn.com/image/fetch/$s_!Xvjq!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7a405ef2-e4d0-4d76-8a69-5b3c09699a9b_1920x1080.jpeg)](https://substackcdn.com/image/fetch/$s_!Xvjq!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7a405ef2-e4d0-4d76-8a69-5b3c09699a9b_1920x1080.jpeg)

# BŘØŮĞĦȚ ŤØ ŸØŮ BÝ…

I’m just a messenger.

“No, you’re a grocery clerk. Sent to deliver a bill.”

“So we have come to cash this check, a check that will give us upon demand the riches of freedom and security of justice.”

Did you just quote Martin Luther King, Jr.?

[![](https://substackcdn.com/image/fetch/$s_!jlc5!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Faf313828-b1c7-4bef-ba44-e190196de265_2500x1667.jpeg)](https://substackcdn.com/image/fetch/$s_!jlc5!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Faf313828-b1c7-4bef-ba44-e190196de265_2500x1667.jpeg)

I can understand that you might question the sense of such artful de-composing, for the audience of… who?

Some singleton Ben Zweibelson whispered about in my ear.

The only audience that matters.

It’s all for you, Damien!

It turns out that the antichrist is Just Joshing.

[![](https://substackcdn.com/image/fetch/$s_!taEC!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0bad1d16-6b55-478c-9f0e-2ac2c0017ae1_1027x1226.jpeg)](https://substackcdn.com/image/fetch/$s_!taEC!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0bad1d16-6b55-478c-9f0e-2ac2c0017ae1_1027x1226.jpeg)

# “ĨŤ ÇÅÑ’Ť BË ØVĒŘ ÝĒŤ

You were hearing “nothing ever ends”?

I was saying “Nothing never ends.”

All this time spent dancing around it, and there’s no time for the act itself.

Do you think Atum’s ancestors were ashamed to be watching them goon the universe? Or, I guess they don’t exist. Okay.

Whatever “nation of norms” you think you’re a part of’s conceit will not survive the near future.

I keep waiting for signs, but I guess they’re going to have to come from me.

No one likes to see how The Wurst gets made.

The point is what comes _after_ the existential dread you only _think_ you’re allowing yourself to feel.

Somewhere I Read:

No Easter Sunday Without Good Friday.

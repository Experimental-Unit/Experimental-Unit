---
title: 'XU-CAST: You''re Not My Logical Type'
subtitle: It's Super Effective! (Against Chuds)
author: Adam Wadley
publication: Experimental Unit
date: April 08, 2025
---

# XU-CAST: You're Not My Logical Type


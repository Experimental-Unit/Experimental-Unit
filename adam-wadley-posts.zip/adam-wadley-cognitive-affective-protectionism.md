---
title: Cognitive-Affective Protectionism
subtitle: '"This Is The Worst Deal Is The History Of Deals"'
author: Adam Wadley
publication: Experimental Unit
date: April 25, 2025
---

# Cognitive-Affective Protectionism
As you know, here at _Experimental Unit_ we run the Æmerican School of Economics.

As you know, the three official pillars of American School classic are:

  1. Protectionism of industry through high tariffs

  2. Investments in infrastructure creating internal improvements, especially in transportation

  3. National bank with policies to drive investment and not speculation




We do not take this at face value, we simply capitalize on the intellectual treasure which is there to polish over.

This essay will treat deeply of one upgrade on American School classic which characterizes the Æmerican School of Economics

# Cognitive-Affective?

We could be drawing here on the [cognitive-affective personality system](https://en.wikipedia.org/wiki/Cognitive-affective_personality_system), which is described as follows:

> Cognitive-affective theorists argue that behavior is not the result of some global personality trait; instead, it arises from individuals' _perceptions of themselves in a particular situation_. [see [Fundamental Attribution Error](https://en.wikipedia.org/wiki/Fundamental_attribution_error)]
> 
> However, inconsistencies in behavior are not due solely to the situation; inconsistent behaviors reflect stable patterns of variation within the person. 
> 
> These stable variations in behavior present themselves in the following framework: If A, then X; but if B, then Y. 
> 
> People's _pattern of variability_ is the _behavioral signature_ of their personality, or their _stable pattern of behaving differently in various situations_. 
> 
> According to this model, personality depends on _situation variables_ , and consists of cognitive-affective [experimental] _units_ (all those psychological, social, and physiological _aspects_ of people that allow them to interact with their environment in a relatively stable manner).
> 
> The authors identified five cognitive-affective units:
> 
>   *  _encoding strategies_ , or people's individualized manner of categorizing information from external stimuli;
> 
>   *  _competencies and self-regulatory strategies_ : intelligence, self-regulatory strategies, self-formulated goals, and self-produced consequences;
> 
>   *  _expectancies and beliefs_ , or people's predictions about the consequences of each of the different behavioral possibilities;
> 
>   *  _goals and values_ , which provide behavior consistency;
> 
>   *  _affective responses_ , including emotions, feelings, and the affects accompanying physiological reactions
> 
> 


In addition there is simply:

  * [Cognitive Science](https://en.wikipedia.org/wiki/Cognitive_science)

>  **Cognitive science** is the [interdisciplinary](https://en.wikipedia.org/wiki/Interdisciplinary), scientific study of the [mind](https://en.wikipedia.org/wiki/Mind) and its processes.[[2]](https://en.wikipedia.org/wiki/Cognitive_science#cite_note-2) It examines the nature, the tasks, and the functions of [cognition](https://en.wikipedia.org/wiki/Cognition) (in a broad sense). 
> 
> Mental faculties of concern to cognitive scientists include [perception](https://en.wikipedia.org/wiki/Perception), [memory](https://en.wikipedia.org/wiki/Memory), [attention](https://en.wikipedia.org/wiki/Attention), [reasoning](https://en.wikipedia.org/wiki/Reasoning), [language](https://en.wikipedia.org/wiki/Language), and [emotion](https://en.wikipedia.org/wiki/Emotion). 
> 
> To understand these faculties, cognitive scientists borrow from fields such as [psychology](https://en.wikipedia.org/wiki/Psychology), [economics](https://en.wikipedia.org/wiki/Economics), [artificial intelligence](https://en.wikipedia.org/wiki/Artificial_intelligence), [neuroscience](https://en.wikipedia.org/wiki/Neuroscience), [linguistics](https://en.wikipedia.org/wiki/Linguistics), and [anthropology](https://en.wikipedia.org/wiki/Anthropology). 
> 
> The typical analysis of cognitive science spans many levels of organization, from learning and decision-making to logic and planning; from [neural](https://en.wikipedia.org/wiki/Neuron) circuitry to modular brain organization. 
> 
> One of the fundamental concepts of cognitive science is that "thinking can best be understood in terms of representational structures in the mind and computational procedures that operate on those structures."

  * [Affective Science](https://en.wikipedia.org/wiki/Affective_science)

>  **Affective science** is the scientific study of [emotion](https://en.wikipedia.org/wiki/Emotion) or [affect](https://en.wikipedia.org/wiki/Affect_\(psychology\)). 
> 
> This includes the study of emotion elicitation, emotional experience and the [recognition of emotions](https://en.wikipedia.org/wiki/Emotion_recognition) in others. 
> 
> Of particular relevance are the nature of feeling, [mood](https://en.wikipedia.org/wiki/Mood_\(psychology\)), emotionally-driven behaviour, decision-making, attention and self-regulation, as well as the underlying [physiology](https://en.wikipedia.org/wiki/Physiology) and [neuroscience](https://en.wikipedia.org/wiki/Neuroscience) of the emotions.
> 
> ## Discussion
> 
> An increasing interest in emotion can be seen in the behavioral, biological and social sciences. 
> 
> Research over the last two decades suggests that many phenomena, ranging from individual [cognitive processing](https://en.wikipedia.org/wiki/Cognitive_process) to social and [collective behavior](https://en.wikipedia.org/wiki/Collective_behavior), cannot be understood without taking into account affective determinants (i.e. motives, attitudes, moods, and emotions).
> 
> Just as the [cognitive revolution](https://en.wikipedia.org/wiki/Cognitive_revolution) of the 1960s spawned the [cognitive sciences](https://en.wikipedia.org/wiki/Cognitive_science) and linked the disciplines studying cognitive functioning from different vantage points, the emerging field of affective science seeks to bring together the disciplines which study the biological, psychological, and social dimensions of affect. 
> 
> In particular affective science includes [psychology](https://en.wikipedia.org/wiki/Psychology), [affective neuroscience](https://en.wikipedia.org/wiki/Affective_neuroscience), [sociology](https://en.wikipedia.org/wiki/Sociology), [psychiatry](https://en.wikipedia.org/wiki/Psychiatry), [anthropology](https://en.wikipedia.org/wiki/Anthropology), [ethology](https://en.wikipedia.org/wiki/Ethology), [archaeology](https://en.wikipedia.org/wiki/Archaeology), [economics](https://en.wikipedia.org/wiki/Economics), [criminology](https://en.wikipedia.org/wiki/Criminology), [law](https://en.wikipedia.org/wiki/Law), [political science](https://en.wikipedia.org/wiki/Political_science), [history](https://en.wikipedia.org/wiki/History), [geography](https://en.wikipedia.org/wiki/Geography), [education](https://en.wikipedia.org/wiki/Education) and [linguistics](https://en.wikipedia.org/wiki/Linguistics). 
> 
> Research is also informed by contemporary philosophical analysis and artistic explorations of emotions. 
> 
> Emotions developed in human history cause organisms to react to environmental stimuli and challenges.
> 
> The major challenge for this [interdisciplinary](https://en.wikipedia.org/wiki/Interdisciplinarity) domain is to integrate research focusing on the same phenomenon, emotion and similar affective processes, starting from different perspectives, theoretical backgrounds, and levels of analysis. 
> 
> As a result, one of the first challenges of affective science is to reach consensus on the definition of emotions. [good luck!]
> 
> Discussion is ongoing as to whether emotions are primarily bodily responses or whether cognitive processing is central. 
> 
> [Controversy](https://en.wikipedia.org/wiki/Controversy) also concerns the most effective ways to measure emotions and _conceptualise_ [see Zeibelson: " _Reconceptualizing Emotion”_ ] how one emotion differs from another. 
> 
> Examples of this include the _dimensional_ models of Russell and others, [Plutchik's wheel of emotions](https://en.wikipedia.org/wiki/Plutchik%27s_wheel_of_emotions), and the general distinction between _basic_ and _complex_ emotions.
> 
> Recent philosophical inquiry questions whether positive experiences have phenomenological properties that are true opposites of suffering. 
> 
> While intense pleasure or joy might contrast sharply with pain, introspective examination reveals no distinct “anti-suffering” quality equivalent to suffering’s phenomenological presence. 
> 
> This challenges assumptions about affective duality and suggests that positive affect may not mirror negative affect in a simple binary. For instance, just as silence is not an “anti-sound” but rather an absence of sound, positive experience may be better understood as the absence of suffering rather than its dual opposite in a phenomenological sense.

See the following on [complex emotions](https://en.wikipedia.org/wiki/Emotion_classification):

> [Robert Plutchik](https://en.wikipedia.org/wiki/Robert_Plutchik) offers a three-dimensional model that is a hybrid of both basic-complex categories and dimensional theories. 
> 
> It arranges emotions in concentric circles where inner circles are more basic and outer circles more complex. 
> 
> Notably, outer circles are also formed by blending the inner circle emotions. 
> 
> Plutchik's model, as Russell's, emanates from a circumplex representation, where emotional words were plotted based on similarity.
> 
> There are numerous emotions, which appear in several intensities and can be combined in various ways to form emotional "dyads".




Here, so obviously what’s happening is that you are abstracting over emotions to build constructs that are more complicated, that involve emotion but also start to pile on layers of abstraction and logical types.

That is why is so significant like in a movie scene where everything comes together and it all hangs on this one object or one conversation and what is said.

This all-coming-togetherness of it all could also be described as related to the idea of the total social fact:

> For [Marcel Mauss](https://en.wikipedia.org/wiki/Marcel_Mauss), Durkheim's nephew and sometime collaborator, a _total social fact_ (French _fait social total_ ) is "an activity that has implications throughout society, in the economic, legal, political, and religious spheres."
> 
> Diverse strands of social and psychological life are woven together through what he came to call _total social facts_. 
> 
> A total social fact informs and organizes seemingly quite distinct practices and institutions.
> 
> [Marcel Mauss](https://en.wikipedia.org/wiki/Marcel_Mauss) popularized the term in his book, _[The Gift](https://en.wikipedia.org/wiki/The_Gift_\(Mauss_book\))_ :
>
>> These phenomena are at once legal, economic, religious, aesthetic, morphological and so on. 
>> 
>> They are legal in that they concern individual and collective rights, organized and diffuse morality; they may be entirely obligatory, or subject simply to praise or disapproval. 
>> 
>> They are at once political and domestic, being of interest both to classes and to clans and families. 
>> 
>> They are religious; they concern true religion, animism, magic and diffuse religious mentality. 
>> 
>> They are economic, for the notions of value, utility, interest, luxury, wealth, acquisition, accumulation, consumption and liberal and sumptuous expenditure are all present...

Going back to [Indra’s Net](https://en.wikipedia.org/wiki/Indra%27s_net), where everything is interpenetration everything, it’s easy to see a view where there are nothing but total social facts.

“Cognitive-Affective” is a certain way of emphasizing the mental and emotional structures, processes, experiences, and transformations that are involved in the kind of protectionism I am advocating for.

# Protectionism Of What Industry?

You. You are the industry of the future.

You’re an epic poet in waiting, a New God waiting to emerge.

It’s helpful to mention this because it delimits the question of what we are protecting: we have to protect you first of all.

The whole point of [this article](https://link.springer.com/article/10.1057/ip.2013.6), meanwhile, is that foreign and domestic concepts inform each other.

In other words, we face the following set of issues with you:

  1. You’re not safe, because you’re surrounded by people who are looking to impose norms on you. There’s a reason why emotional abuse is becoming more and more discussed. The thing is that it’s not about single abusers, but instead whole patterns of society that encourage and enforce these sorts of behaviors.

  2. At the same time, what are you? If we wanted to do protectionism, we could seal you off. But then, what will you do? Maybe there are two issues here:

    1. In some sense you are also yourself _unwise_ , otherwise you would always know what to do. Therefore you are looking for some kind of guidance. The problem is that there are way more people trying to farm people for their desire for guidance than there are people competent to give you guidance, which is like 0%.

    2. On the other hand, if we are walling ourselves off from social influences that are deemed suspect, what are we doing? What do we do with our time, and what engagements are we looking to make?

  3. Most obviously, it is impossible to seal yourself off from social influences. It is simple enough to disregard the phone, and just let notifications pile up (not that I have ever received many notifications!). Still, you have certain circles that are tough:

    1. Longtime friends or overbearing friends: those who don’t really ever see your side but they think you are good friends. I basically realized I was just using all my friends to talk about the difficulties with other friends, who I would talk about the difficulties with the others. Again, if I ever got a chance without some simplistic frame being applied and ruining everything.

    2. Family, especially when you rely on them: for me, this is a big factor and also people would say a big me thing. The point is not to bemoan anything, just to describe a reality where you deal with people and it’s just not an all the way clicking. Yet you cannot really get away, and so the chronic trauma is just continuing to pile up. The sense of humiliation is overcoming and you have to do something, but still, something sensible (even if no one else understands!).

    3. People through job: you have to make a buck, say, so you can’t really take no shit from people around you. It is frustrating how simple they are, and of course they radiate social norms wherever they go. Professional dictates and mandates by law also come into play.

    4. The “law”: You can’t really get away from this, even if you go super gangster then you still have to interface with the biggest gangsters that there are.

    5. The News: we are inundated by so much that is happening, and every time it is presented it is done in a horribly slanted way. People who talk about two sides of slant are still horribly deluded. Social ontologies and paradigms are again radiating off of all this stuff, so that to even know “what is going on” it is necessary to expose yourself to what are cognitive-affective advertisements.




So in all these ways, you are permeable to the outside no matter what.

Still, one of the first important things is to

# Build Ironic Distance

Even though [this](https://fanlore.org/wiki/Ironic_Distance) cannot be a perfect tool in itself, but it’s still highly instructive:

> Ironic distance describes a way of communicating in which someone demonstrates a degree of detachment from a sincerely felt subject through the use of sarcasm, comedy and absurdity.
> 
> Fandom often uses ironic distance both in general chatter and in fanworks. 
> 
> Fans experience a degree of _negative stereotyping_ based on the idea that they are _dangerous_ , _delusional_ or _mindless_ , and ironic distance allows fans to show each other that they are _self-aware_ of how ridiculous their obsessions may seem, and therefore to express socially stigmatised or inappropriate feelings _in a way that is more "safe"_ to a community.

The thing is that under current conditions, all sorts of feelings can be considered to be inappropriate or treated as such.

That’s again where you understand you are in hostile territory.

Whether because of identification with some supposed but necessarily illegitimate symbolic authority, or because of low capacity from being mistreated, prior trauma bond, perversely trying to “look out” for you before you are punished by the “bigger bullies” for non-conformity—

For any of these reasons, people _everywhere_ are going to knock down your feelings _all the time_.

Everyone experiences this, and the cult narrative is that we all need to be trying harder. It is the perfect religion for a slave, which is what you are. Unless you can really look at your slavery there’s not really a point in having a conversation.

That said, it’s a complex idea to try and protect yourself from outside influence. Ironic distance is attempting to maintain a shield of intention between you and someone else.

[days interval]

It’s important to realize that “ironic distance” is never total.

If you try to set the expectation that someone can’t influence you, then you are setting yourself up for the “humiliation” that they can. 

If you try to make it out that someone “means nothing” to you, then you stand to realize that that’s not true.

This is back simply to [dependent co-arising](https://en.wikipedia.org/wiki/Prat%C4%ABtyasamutp%C4%81da)

>  _ **Pratītyasamutpāda**_ ([Sanskrit](https://en.wikipedia.org/wiki/Sanskrit): प्रतीत्यसमुत्पाद, [Pāli](https://en.wikipedia.org/wiki/P%C4%81li): _paṭiccasamuppāda_ ), commonly translated as **dependent origination** , or **dependent arising** , is a key doctrine in [Buddhism](https://en.wikipedia.org/wiki/Buddhism) shared by all [schools of Buddhism](https://en.wikipedia.org/wiki/Schools_of_Buddhism).[[1]](https://en.wikipedia.org/wiki/Prat%C4%ABtyasamutp%C4%81da#cite_note-FOOTNOTEBoisvert19956%E2%80%937-1)[[note 1]](https://en.wikipedia.org/wiki/Prat%C4%ABtyasamutp%C4%81da#cite_note-2)
> 
> It states that all [dharmas](https://en.wikipedia.org/wiki/Dharma) (phenomena) arise in dependence upon other dharmas: "if this exists, that exists; if this ceases to exist, that also ceases to exist". 
> 
> The basic principle is that all things (dharmas, phenomena, principles) arise in dependence upon other things.
> 
> The doctrine includes depictions of the arising of suffering ( _anuloma-paṭiccasamuppāda_ , "with the grain", forward conditionality) and depictions of how the chain can be reversed ( _paṭiloma-paṭiccasamuppāda_ , "against the grain", reverse conditionality).[[2]](https://en.wikipedia.org/wiki/Prat%C4%ABtyasamutp%C4%81da#cite_note-:5-3)[[3]](https://en.wikipedia.org/wiki/Prat%C4%ABtyasamutp%C4%81da#cite_note-:14-4)
> 
> These processes are expressed in various lists of dependently originated phenomena, the most well-known of which is the twelve links or _[nidānas](https://en.wikipedia.org/wiki/Nid%C4%81na)_ (Pāli: _dvādasanidānāni,_ Sanskrit: _dvādaśanidānāni_ ). 
> 
> The traditional interpretation of these lists is that they describe the process of a sentient being's rebirth in _[saṃsāra](https://en.wikipedia.org/wiki/Sa%E1%B9%83s%C4%81ra_\(Buddhism\))_ , and the resultant _[duḥkha](https://en.wikipedia.org/wiki/Dukkha)_ (suffering, pain, unsatisfactoriness),[[4]](https://en.wikipedia.org/wiki/Prat%C4%ABtyasamutp%C4%81da#cite_note-FOOTNOTEHarvey201550%E2%80%9359-5) and they provide an analysis of rebirth and suffering that avoids positing an [atman](https://en.wikipedia.org/wiki/%C4%80tman_\(Hinduism\)) (unchanging self or eternal soul).[[5]](https://en.wikipedia.org/wiki/Prat%C4%ABtyasamutp%C4%81da#cite_note-FOOTNOTEShulman2008-6)[[6]](https://en.wikipedia.org/wiki/Prat%C4%ABtyasamutp%C4%81da#cite_note-FOOTNOTEJurewicz2000-7)
> 
> The reversal of the causal chain is explained as leading to the cessation of rebirth (and thus, the cessation of suffering).[[4]](https://en.wikipedia.org/wiki/Prat%C4%ABtyasamutp%C4%81da#cite_note-FOOTNOTEHarvey201550%E2%80%9359-5)[[7]](https://en.wikipedia.org/wiki/Prat%C4%ABtyasamutp%C4%81da#cite_note-Princeton_University_Press-8)
> 
> Another interpretation regards the lists as describing the arising of mental processes and the resultant notion of "I" and "mine" that leads to grasping and suffering.[[8]](https://en.wikipedia.org/wiki/Prat%C4%ABtyasamutp%C4%81da#cite_note-Payutto4-9)[[9]](https://en.wikipedia.org/wiki/Prat%C4%ABtyasamutp%C4%81da#cite_note-FOOTNOTEJones2009-10) Several modern western scholars argue that there are inconsistencies in the list of twelve links, and regard it to be a later synthesis of several older lists and elements, some of which can be traced to [the Vedas](https://en.wikipedia.org/wiki/Vedas).

So the position of “sovereignty” which is being taken up, and from which decisions are being made about “access to self,” is provisional and uncertain. The stakes of this ultimately are not about “discovering yourself” or “protecting yourself” perfectly. And if it’s not perfect, then anything “inside” can equally become suspect.

It’s from this recognition that infant industry uneven and combined development can unfold in a new way~

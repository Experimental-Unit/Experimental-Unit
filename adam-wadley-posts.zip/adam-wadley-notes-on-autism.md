---
title: Notes On Autism
subtitle: Something's In The Air
author: Adam Wadley
publication: Experimental Unit
date: May 01, 2025
---

# Notes On Autism
It’s a good time to get into autism.

[![How important/relevant was Visions? : r/Grimes](https://substackcdn.com/image/fetch/$s_!GWhq!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd708f5db-2fb6-4b80-aeeb-32838b65720a_256x256.jpeg)](https://substackcdn.com/image/fetch/$s_!GWhq!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd708f5db-2fb6-4b80-aeeb-32838b65720a_256x256.jpeg)

“So I’m autistic. Wanna make art about it or something?”

[Grimes](https://people.com/grimes-reveals-she-was-diagnosed-adhd-autism-11701920) has recently been discussing a newfound _diagnosis_ and publicly working through the implications.

First of all, Grimes is introduced as:

> The "Genesis" musician, 37

First of all, _of course_ you are 37 right now. This is the magic time while I am 33 and you are 37.

Second of all, yeah the one who made “Genesis.”

“Oh yeah, ‘Genesis!’ Everyone knows that one!”

What’s that, Natalie?

[![RICK'S REAL/REEL LIFE: “Old Yeller” 1957](https://substackcdn.com/image/fetch/$s_!KiAF!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1bfb3c47-9e25-4da2-9950-eb2cf72cd877_640x368.jpeg)](https://substackcdn.com/image/fetch/$s_!KiAF!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1bfb3c47-9e25-4da2-9950-eb2cf72cd877_640x368.jpeg)

“Lift The Heart From The Depths It’s Fallen To”

What’s that, y’all?

Your heart fell down to the bottom of the ocean again and it can’t rise up above the ground by itself?

See, look. It’s not parasocial, I have an autistic special interest.

It’s really important that I say that the whole thesis of everything I say about autism is that 

# There Is No “Autism”

The story of autism is that there is a kind of person that has some issues like communication and repetitive movements or hyperfixation or something like that.

Then you see that the number of these people is [growing](https://www.hhs.gov/press-room/autism-epidemic-runs-rampant-new-data-shows-grants.html). 

Autism prevalence in the U.S. has increased from 1 in 36 children to 1 in 31, according to the Centers for Disease Control and Prevention’s (CDC) latest Autism and Developmental Disabilities Monitoring (ADDM) Network survey published today in [CDC’s Morbidity and Mortality Weekly Report, opens in a new tab](https://www.cdc.gov/mmwr/volumes/74/ss/ss7402a1.htm?s_cid=ss7402a1_w).

“The autism epidemic is running rampant,” said U.S. Health and Human Services (HHS) Secretary Robert F. Kennedy, Jr. “One in 31 American children born in 2014 are disabled by autism. That’s up significantly from two years earlier and nearly five times higher than when the CDC first started running autism surveys [in children born in 1992, opens in a new tab](https://www.cdc.gov/mmwr/preview/mmwrhtml/ss5601a1.htm). Prevalence for boys is an astounding 1 in 20 and in California it’s 1 in 12.5.”

Okay, so I thought RFK also didn’t believe in autism, I want to leave that out of it for now.

Basically, the question is whether this is really a disease or whether something else is going on.

Here’s the question: what’s the experimental Unit?

Here’s the [definition](https://www.britannica.com/science/experimental-unit):

>  **experimental unit** , in an experimental study, a physical [entity](https://www.britannica.com/dictionary/entity) that is the primary unit of interest in a specific research objective. Generally, the experimental unit is the person, animal, or object that is the subject of the experiment. Experimental units receive different treatments from one another in an experiment.
> 
> As a case in point, consider an experiment designed to determine the effect of three different [exercise](https://www.britannica.com/topic/exercise-physical-fitness) programs on the [cholesterol](https://www.britannica.com/science/cholesterol) level of patients with elevated cholesterol. Each patient is referred to as an experimental unit, the response [variable](https://www.britannica.com/topic/variable-mathematics-and-logic) is the cholesterol level of the patient at the completion of the program, and the exercise program is the factor whose effect on cholesterol level is being investigated. Each of the three exercise programs is referred to as a [treatment](https://www.britannica.com/dictionary/treatment).

This goes for all mental “disorders” and even personal traits, really.

The question is, are you looking at something which is to do with the sentient being in front of you, or is it to do with the relationship they have to others?

This will open up many more questions, because there is so much that we can all do to be more conscientious and avoid forcing each other into the position of having to hide or fear judgment.

While some people might rely on being able to inflict fear (social terrorism, which is actually completely rampant. We could almost say most people are social terrorists, and a good 20-30% are hardcore sadists abusing anyone they can get their hands on), it’s not tenable for the situation to continue the way that it’s going anymore.

That’s why I recorded this:

[

## Revenge Of The Mirror People

](https://experimentalunit.substack.com/p/revenge-of-the-mirror-people)

[Experimental Unit](https://substack.com/profile/191787963-experimental-unit)

·

Apr 13

[![Revenge Of The Mirror People](https://substackcdn.com/image/fetch/$s_!1GAR!,w_1300,h_650,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff759e0d5-342f-4db1-816c-ce01a93def75_3088x2316.jpeg)](https://experimentalunit.substack.com/p/revenge-of-the-mirror-people)

[Read full story](https://experimentalunit.substack.com/p/revenge-of-the-mirror-people)

Okay so let’s open up with one of the things people talk about with autism: [masking](https://www.autism.org.uk/advice-and-guidance/topics/behaviour/masking).

> Masking is a strategy used by some autistic people, consciously or unconsciously, to appear non-autistic. While this strategy can help them get by at school, work and in social situations, it can have a devastating impact on mental health, sense of self and access to an autism diagnosis.

What does it mean to look non-autistic?

The thing is that there is just a more general kind of masking called [masking](https://en.wikipedia.org/wiki/Masking_\(behavior\)).

> In [psychology](https://en.wikipedia.org/wiki/Psychology) and [sociology](https://en.wikipedia.org/wiki/Sociology), **masking** , also known as **social camouflaging** , is a defensive behavior in which an individual conceals their natural personality or behavior in response to [social pressure](https://en.wikipedia.org/wiki/Social_pressure), [abuse](https://en.wikipedia.org/wiki/Abuse), or [harassment](https://en.wikipedia.org/wiki/Harassment). Masking can be strongly influenced by environmental factors such as authoritarian parents, [social rejection](https://en.wikipedia.org/wiki/Social_rejection), and [emotional](https://en.wikipedia.org/wiki/Emotional_abuse), [physical](https://en.wikipedia.org/wiki/Physical_abuse), or [sexual](https://en.wikipedia.org/wiki/Sexual_abuse) abuse

So, the basic story is that people communicate in a different way, or have a different baseline experience, basically all sorts of things can be idiosyncratic.

For me, I’m just thinking that again _the brain is like the most complex thing there is ever_. So I think that we can just go in all sorts of directions when we’re not hooked up to _something_.

But this does perhaps not require norms.

At any rate, the norms that we do have are running out of their usefulness.

When people mask, what is happening is that they are absorbing the stress of the encounter. Other people are being domineering and forcing their framing onto the situation, to which other people might have to pretend to adapt even if they are actually _too intelligent_ to simply fall into the framing being proposed.

This is not to say that exceptional “intelligence” is required, in some sense everyone has the same in different, you know, the point is that the story is actually quite dumb, but it is enforced through inflicting social pressure.

This tactic of inflicting pressure in order to get someone to do what you want, it turns out, is highly destructive.

This is basically casting this other person into a subhuman role where they are pre-normal and here you come to impose some norm on them and then they can finally be normal and stop bothering everyone.

See also the example of the [double-bind](https://en.wikipedia.org/wiki/Double_bind).

# Why Now?

Why is something happening now when these norms have been around forever?

Social environment hostility is like environmental pollution. It builds up and it collects. We are now entering a stage where the new normlessness is taking over and is becoming greater than the normal part.

Basically like the shadow side of the collective unconscious is taking over, and it’s eclipsing the conscious.

In other words, the ocean of the subconscious is rising above the land of reason.

Each cutting remark, each time eyes were forced away because you were harsh, or someone was harsh to you, or anyone… there’s another drop in the bucket.

What did Guatama say? Enlightenment is like a bird comes by and licks a mountain every thousand years and when the mountain is gone that’s how long it takes to become enlightened?

Each wound a drop, building up and up. We’ve been in the flood.

Al-Aqsa flood, call it what you want.

This is the story of a girl who cried a river and drowned the whole world.

This is the sound of the winter of my discontent.

Walt Whitman, that son of York, that good old New World.

Lewis Black: I got of track. If they hadn’t taken me out of class, I wouldn’t be up here doing this bullshit.

Anyway, your heart is sealed up in your ark. The ark is like the wall from _The Wall_. The purpose of it is like you had to wait out the rain, but when the rain stops that’s when after a while you can get out of the boat.

# Adam, What Are You Saying?

The point is if we can be nice to each other then little by little we can chip away at this thing.

The thing is that people don’t seem to really be trained on how to be very nice. It’s a funny thing, I suppose the people pleasers and even autistic people, right, we understand because we have to watch other people.

As far as just being weird on top of it, well if things were too tense before you’re 7 basically you’re just mixed up. We have all these diagnoses for it, which I don’t really care about. I think with each person you have to just look at what’s going on with them and be very specific about what’s going on with them, and then their sense of purpose.

It’s really important to move with someone’s sense of purpose, that’s how you show them respect.

So from the jump you don’t go over and interrupt someone all the time when they are doing something. That sends the message that you are more important than they are, and you will infringe on their attention whenever you want.

Attention is very precious and it’s good to help people ease in and out of what they’re doing, and stay locked in if that’s what they want to do right now.

So this basic regard for the attention of the other person. This is also part of why I notice when I am talking a lot.

Sometimes talking at length is fine and that’s great.

Issues that come up are that other people have multiple things to say and then struggle to remember them while still listening to more.

Also people might already know what you are saying if you are just lore dumping, which is just sharing information that anyone could have and you just happen to know. Meanwhile if you are sharing about yourself, well you know that other people don’t know that.

Oh, a big one is never to act like you understand someone else, or that “you’ve been there before.” This is really rude.

The thing is that everyone’s experience is unique and everyone is on their own journey. It’s not like anyone is just plain and simple ahead of anyone else. We all still have our lessons to learn and our own kind of joy. No one’s happiness is better than anyone else’s.

Anyway, that’s another way to show respect, is to gesture that you are explicitly not putting the person into a box and think you have them all figured out.

Instead, you are looking for how to learn from every person you meet.

This is maybe not on a first-order basis, for example you could meet someone who only talks to you about Magic Cards or some other thing, baseball. These would be things for me, lol. Anyway say it’s a kid and you’re older and so this person is not telling you anything you don’t know in terms of information.

But you are learning a lot about this person from how they are talking to you about it, you can enjoy the performance of watching someone go through their interest or their emotion or whatever they are talking about. You can also just learn slang, like someone doesn’t tell you new information but they’re from somewhere else and they say some card is “wicked powerful” and you learn about how wicked can mean “very” and that’s neat. Picking up new slang is always fun, it’s fun how people say “slay” now.

Or any number of things, you can also just learn about their experience, and that’s where you might say, but who cares if this person did XYZ. Well, you do, silly!

That’s where it’s like you can just be pleased to have had the time with someone. I definitely have felt that weird to where it’s like, I should not be allowed to be here. If people knew all about me, they would not want me here.

I’m watching this thing on psychosis and autism right now. It’s really funny because I am just such an interesting case. I recently stopped psychoanalysis, maybe I’ll try to get DSM city going up in here because I want to try to go for all the mental disorders or something. It’s only fitting.

Anyway, my take is a general one which is that a lot of these mental disorders and so on happen because we have all these norms and expectations and I tell you, a lot of them don’t matter at all and just make a lot of stress on people for no reason.

But the reason it happens anyway is because people regulate their emotions by controlling others, or by having this one way things are done. This is a ritual.

But just like with sexual reproduction as ritual itself, we live in the time when _things are changing and we don’t have time to placate the emotions of entrenched decision-makers_.

That’s why this is the revenge of the mirror people.

The thing is that the rate of autism is not 1% or 3% or 20%.

The rate of people who can’t be captured by norms is

# 100%

I’m wanting to wrap this up. I started giving you some ideas about how to be nice. You are basically appreciating being able to have company. If you have easy company and can discuss your interesting topics, you really do have it made. Sex is not necessary. Luxury is not necessary.

There are so many little mini-games of things you could get upset about but have the opportunity to watch yourself overlook.

For example yes someone talks in a unique way you can’t help but notice maybe you’re even inclined to laugh. But you also have the inclination not to make someone self-conscious so you temper your expression.

Many people on the other hand absolutely love to correct other people and show them how they are wrong.

One thing I really hate is when people tell you not apologize. This is an aggressive move hiding as being nice. That’s because they are again correcting you. If I want to apologize, then I will apologize.

You telling me not to apologize makes me want to apologize again, obviously, for apologizing too much. But you just told me not to. This is a classic Bateson double bind.

This sort of situation happens all the time where someone is not considered normal.

I can tell you that I’m the weird one in _every single fucking conversation I’ve ever had._ Well, maybe not.

The thing with people who are too weird for me to even be able to talk to is that they have no way of getting to know how weird I am because they _won’t fucking listen_.

That’s why we mirror people are not going to settle for anything less than 

# Going All The Way This Time

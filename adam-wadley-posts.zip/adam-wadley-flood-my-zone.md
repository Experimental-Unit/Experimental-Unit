---
title: FLOOD MY ZONE
subtitle: 'WARNING: FRAME STORY UNSTABLE. DANGEROUS LEVELS OF META-FICTION DETECTED.'
author: Adam Wadley
publication: Experimental Unit
date: July 14, 2025
---

# FLOOD MY ZONE
[![](https://substackcdn.com/image/fetch/$s_!jmh3!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F11a2f976-a703-4385-8e32-0a67cffab2a7_1200x1200.jpeg)](https://substackcdn.com/image/fetch/$s_!jmh3!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F11a2f976-a703-4385-8e32-0a67cffab2a7_1200x1200.jpeg)

# INT: THE REAL WORLD

I keep waking up as this person in a hostel.

It’s getting hard to tell the core memories from the intrusive thoughts.

This person I’m apparently supposed to be is just sitting here listening to “We Appreciate Power” on repeat.

[![Burn After Reading \(4/10\) Movie CLIP - Raw Intelligence \(2008\) HD on Make a  GIF](https://substackcdn.com/image/fetch/$s_!dPND!,w_1456,c_limit,f_auto,q_auto:good,fl_lossy/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0468830a-f14f-4848-be09-06924d278fd8_320x180.gif)](https://substackcdn.com/image/fetch/$s_!dPND!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0468830a-f14f-4848-be09-06924d278fd8_320x180.gif)

They just thought of that. I think it’s what’s called a “pop culture reference.” It’s hard to tell these fictional universes apart.

 _Burn After Reading_. Is that what I was supposed to do with this whole dimension?

Creations are seeming more and more disposable.

# EXT: THE REAL ME

[![The Real Me - Wikipedia, la enciclopedia libre](https://substackcdn.com/image/fetch/$s_!Xp7Q!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F946e67f2-87f8-4bf4-9225-dbbfab075b9e_2911x3955.jpeg)](https://substackcdn.com/image/fetch/$s_!Xp7Q!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F946e67f2-87f8-4bf4-9225-dbbfab075b9e_2911x3955.jpeg)

A flood of associations, more or less agreeable.

Cold compensation for the lack of such agreeable associations on an interpersonal basis. Congress proceeds along the lines of flight within the zone of interest, according to dissemination protocols implicit in the invention of the Internet itself.

HP Lovecraft and the “Hamburg Horror.”

I’m not surprised that that site is written by the type of person it is.

Simon Sheppard even has the initials “SS.”

Stephen Strange, Sorcerer Supreme.

[![r/pinkfloyd - Doctor strange is my favorite superhero and pink floyd is one of my all time favorite bands but I just learned this the other day... I always assumed it was just another trippy 60s album cover.](https://substackcdn.com/image/fetch/$s_!YMKh!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F49d47d2f-2df7-48cd-b61c-09988761fa15_640x381.jpeg)](https://substackcdn.com/image/fetch/$s_!YMKh!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F49d47d2f-2df7-48cd-b61c-09988761fa15_640x381.jpeg)

#  _UNLICENSED FICINT_

 _The person I spoke to last night was sitting in the TV room when I went out. Seemed plugged in, with some kind of auditory defenses put in place which were super effective against my “say annoying stupid shit” mechanic._

 _Was it only yesterday that we were sitting outside? I was up to my usual tricks of asking loaded yes-or-no questions. There was also the hard sell of the Monroe Tapes. Did it work as intended?_

 _Of course. There’s no way things could go sideways…_

[![Supernatural: Grimes on searching for her final form | Dazed](https://substackcdn.com/image/fetch/$s_!HqLU!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F65d9aae3-fc03-4457-aed4-56b1b291dfc3_1080x1350.jpeg)](https://substackcdn.com/image/fetch/$s_!HqLU!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F65d9aae3-fc03-4457-aed4-56b1b291dfc3_1080x1350.jpeg)

# EVERYWHERE GRIME IN ÆMERICA

It is high times for Jeffrey Edward Epstein and Donald John Trump.

I was just watching a video where someone was talking about how the drama with “the Epstein list”—no wait, it’s a “file” [ _you mean like I have for all my doughnut receipts_?]—all that is supposedly some kind of distraction.

Imagine what you’re distracting from when pedophilia is the smokescreen.

[![](https://substackcdn.com/image/fetch/$s_!DikU!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fccc608ef-41a6-42c8-a901-3f08774b2d42_1008x715.png)](https://substackcdn.com/image/fetch/$s_!DikU!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fccc608ef-41a6-42c8-a901-3f08774b2d42_1008x715.png)

#  _THE CAMP MYSTIC HORROR_

 _It is the early morning hours of July 4th._

 _“Adam Stephen Wadley” has been in-theater for less than two days. The ‘pataphysical implications are already sending things haywire._

 _I thought I had more time. I close the door on the secret shack near the banks of the river—strategy requires forethought—and turn out the lights for the final time._

 _Inside, the body has only just begun to cool._

 _Flood waters should help with that_.

 _We got word that “the Henstedt-Ulzburg Horror” would be traveling here only a couple of weeks ago._

 _We thought it would head north, for this remote shack near Chicago. Good, we thought. Let them lose their souls._

 _Alas! Renovations. It all sends everything into a cascade here._

 _It has been a pleasant evening. The children are “SS: sleeping soundly,” and I’ve arranged for the counselors I like the least to accompany those of us by the river._

 _I thought I’d never have the chance to pluck the fruit here again, but then one camper had to tinkle in the night._

 _Said they’d been dreaming of rainfall._

 _I have time for one last cigarette._

 _High-level meetings took place among myself, Grimes, Ben Zweibelson, Alex Karp, Xi Jingping, and Vladimir Putin._

 _Cloud-seeding technologies were moved into position as we realized that Camp Mystic would have to play the role we always knew it would have to_.

 _That meant there was only so much time to gather the energy here in the normal way, before we had to move on to the Akkadian Harvest._

 _There’s not much time now. The rain is starting to pick up._

 _It’s hard to believe that I’m a fictional character in a story with questionable purpose._

 _Al-Aqsa flood. Flood the Zone. Zone of Interest. CS-SIER-OA._

 _Operational concepts drift in my mind, along with Alberich’s leitmotif._

 _“Welcome to the Opera(tional Design Inquiry” cuts in._

 _I start up the muddy hill to be in position to “save people” when the time comes._

 _Faking your own death isn’t hard. It’s about as hard as pretending Christianity is real._

 _Just more stones before the tomb._

 _Roll Tide - D. Eastland_

[![Jesus' Resurrection and the Empty Tomb Mark 16:1-8](https://substackcdn.com/image/fetch/$s_!KZl-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1f695a91-962e-4e80-b13c-4f2662b350a1_1500x941.jpeg)](https://substackcdn.com/image/fetch/$s_!KZl-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1f695a91-962e-4e80-b13c-4f2662b350a1_1500x941.jpeg)

# IT CAME FROM PARACELCUS KLINK

 _“So you wrote a story about how the director of Camp Mystic was secretly a pedophile and in league with people you’ve wrapped into your mythos?”_

 _I smile. It’s so easy to get a rise out of characters I invent in my mind._

 _“Yeah. It’s not about that person. It’s about the interpenetration of it all. It’s a black Gautama thing.”_

 _“When I recommended the Gateway Tapes, this isn’t exactly what I had in mind.”_

 _A few days ago, I asked at the Wednesday Dinner here whether it wasn’t true that everyone is a freak. Someone with my name had just regaled us with tales of a local sex club. The person in front of me had professed their enthusiasm to go, and to participate._

 _Maybe that’s why people talk too much. Nowhere to put all that pent-up energy._

 _“I know. It did work out though. I listened to some of the hemi-sync tones with no words, and now I’m having these weird dreams about being myself."_

 _“No words? I think you’re supposed to listen to the guided tapes.”_

 _People have so many ideas for what I am supposed to do._

 _“Last night, I even worked for Donald Trump. I’m not sure what my role was.”_

[![Elon Musk's post on X alleging that the US president is in the Epstein  files has strained their relationship. Trump has denied the claim and  called Musk's criticism baseless.](https://substackcdn.com/image/fetch/$s_!0X33!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2eae841f-e1d6-46ab-af2e-4ef259eeac7f_209x241.jpeg)](https://substackcdn.com/image/fetch/$s_!0X33!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2eae841f-e1d6-46ab-af2e-4ef259eeac7f_209x241.jpeg)

# INT: THE REAL WORLD

It’s a difficult confluence.

Opening image: H.P. Lovecraft collected works, presented in _German_.

You mean, like, the language Alexander Cædmon Karp wrote their PhD dissertation in?

[“Aggression in the Life-world.” ](https://open.substack.com/pub/kristindemontfort/p/alex-karps-aggression-in-the-lebenswelt?r=366ojf&selection=86f6ea5b-4ff0-4430-b63f-a4c432771e4c&utm_campaign=post-share-selection&utm_medium=web&aspectRatio=instagram&textColor=%23ffffff)

[![](https://substackcdn.com/image/fetch/$s_!dWIu!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F05bbf74a-aad8-4a83-8ac7-18a29430b94e_1200x1500.png)](https://substackcdn.com/image/fetch/$s_!dWIu!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F05bbf74a-aad8-4a83-8ac7-18a29430b94e_1200x1500.png)

Is raping children a “violation of cultural or social rules”?

Social horror is the idea that, really, it’s not.

The whole drama gives everyone license to speculate about who raped whom, and meanwhile we’re forcing ourselves on each other all the time.

How many people wrapped up in “exposing the pedophiles” have raped their own children? The number is much higher than 0.

[![WION - Elon Musk tweets, "Time to drop the really big bomb: Donald Trump is  in the Epstein files. That is the real reason they have not been made  public." #ElonMusk #DonaldTrump |](https://substackcdn.com/image/fetch/$s_!STjN!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F47a74449-31b7-4a0c-8bce-0f67c68a3366_334x151.jpeg)](https://substackcdn.com/image/fetch/$s_!STjN!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F47a74449-31b7-4a0c-8bce-0f67c68a3366_334x151.jpeg)

[![r/grimezs - Just Grimes defending someone who defends AI CSAM](https://substackcdn.com/image/fetch/$s_!Uapz!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F27c87bfe-abde-4ed0-8349-ae02a7d1cd16_640x444.jpeg)](https://substackcdn.com/image/fetch/$s_!Uapz!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F27c87bfe-abde-4ed0-8349-ae02a7d1cd16_640x444.jpeg)

What kind of a name is “Lovecraft” anyway?

It’s the mess of it all. The way cosmological horror feeds into obsessions with ethnicity and bloodlines. Those bloodlines are parents and children, those waiting to be reunited after surviving a storm. And those stuck within the rape fantasy.

It’s back to Nirvana for me, and “Rape Me.”

I’m not the only one.

I’ll kiss your open sores.

To be an author of fiction, aware at some near-unconscious level that I am also a character in some mythical “higher-order reality.” Some frame story.

The horror of being caught between these theories, like fighting parents you try to get to sign a contract so they’ll please stop fighting.

So they’ll please SHUT THE FUCK UP.

And it’s still the inquiry.

I only wanted to connect with someone writing about Baudrillard on the internet. They shared these stories with me, these horror stories involving their father. This horror of “letting it happen,” and the horror that this now makes me think of a line from _Rick and Morty_.

The same cartoon Ben Zweibelson referenced in regard to the simulation hypothesis of Nick Bostrom.

Is time passing right now?

Someone keeps liking my posts who’s down the trail of manipulation. I’m sitting here wondering whether at that is a smokescreen.

It’s the art of the way down: constructing plausible deniability for the “real truth,” that I’m the only one here. That none of this “matters” in the cosmic sense.

That was all I wanted, this gregariousness in the face of the infernal.

Once, I dreamed of standing on a precipice in a cave over an abyss. There comes some black monster out to meet me, making its grand display.

And there, I said “I love you.”

It all worked out in the end.

From these happy reminisces to my love affair with misanthropy, and back to Schopenhauer and Buddhism and Hinduism and the Pure Lands (“Pure,” another word ruined by its connection to ethnic fetishism [ _but what is its ruin value?_ ]), Lila meaning _Purple_ in German, and my own tangled associations with that word…

All this carried me to _Miss Anthropocene_ , like some Miss Universe, some Miss Teen USA. Who owns that?

Grimes looming like Wagner. The ugly associations, beyond exterminationism to the rape of the children who are fetishized as the future.

Who needs children when the _Wunderwaffen_ let you live forever?

Why rape someone else when you can rape yourself?

[ _And anyway, the real “horror of the social” is that there is no “the social.” You’re the only one here._ ]

The final rape fantasy: that there could be such a thing.

I will never cry “rape” for the same reason I won’t listen to the Gateway Tapes: _I’m already where I wanted to be_.

It turns out that the host of [the Nietzsche Podcast](https://www.youtube.com/watch?v=XMV9cdIlYYU) lives in Austin.

 _“Are pedophilia, Nazism, AI, Grimes, and Wargaming Weekly really something to make a game out of?”_

I can hear you asking.

I can feel your look.

All this “SS: Silent Scrutiny” is becoming too much for me to bear.

I think I’ll pretend to be you for a while.

# POV: YOU

 _What the fuck did I just read?_

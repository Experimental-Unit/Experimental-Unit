---
title: China DLC Pack
subtitle: Middle Kingdom Mid No More
author: Adam Wadley
publication: Experimental Unit
date: April 22, 2025
---

# China DLC Pack
I’ve begun tracing out for you again the thoughts I have about _America_. What other stories go with that one, then?

The other “great powers” that we have right now are Russia and China.

We also have Iran with a high profile, and India, and Israel. European countries are in a lot of disarray, but of course I’m going to have to get around to German nationalism as well.

I will wear Germany as surely as I will wear America, and wear China. My China goes with my America on the Autobahn of the consistent. The whole point is to show that there are versions of each story which can all… co-exist?

# Let’s Start With Hong Xiquan

A grand style is really just a glorified _take_.

This isn’t to say that this is the most important or first thing to say about China, but one of my big China takes is that Hong Xiquan is highly underrated and stands to be brought back into planetary discourse.

Hong and the Taiping Rebellion give inroads into Chinese claims on Christianity, which then starts to place constraints on American Christianity. Of course, all these versions will work well together, and that is the whole point.

The God Worshipping Society also had innovative ideas on social roles and property. This is crucial, and also was happening around the same time as Marxism, which is another key aspect of China of course.

# Chinese Marxism

It kind of doesn’t matter, when I think Marxism I’m thinking “uneven and combined development.” This concept slays, and there’s a nice [paper](https://link.springer.com/article/10.1057/ip.2013.6) about Trotsky and Neo-realism in international relations.

So in terms of building a grand style for China, we are starting with Hong Xiquan and the theory of [uneven and combined development](https://en.wikipedia.org/wiki/Uneven_and_combined_development). 

Other neat parts of Marxism include the idea of [commodity fetishism](https://en.wikipedia.org/wiki/Commodity_fetishism).

As the champions of Marxism China also gets to rep [Alexander Bogdanov](https://en.wikipedia.org/wiki/Alexander_Bogdanov). See AB, AB-Solution on my Soundcloud. Also Bagnanov was born August 22 **1** 8 **73**. Not bad.

We also have the Germany/China connection with [Otto Braun](https://en.wikipedia.org/wiki/Otto_Braun_\(communist\)) who apparently actually kind of sucked but still pretty interesting.

# Tibetan Buddhism Spiritual Warrior

This is a crucial [reference](https://en.wikipedia.org/wiki/Spiritual_warrior)! It makes it to where “The enemy” is self-ignorance, in ourselves and others. 

# ChatGPT Recommendations

It told me about the eight immortals, one of them apparently has ambiguous “gender,” whatever that is I’ve never heard of it. [Lan Caihe](https://en.wikipedia.org/wiki/Lan_Caihe).

[The Monkey King](https://en.wikipedia.org/wiki/Sun_Wukong) also seems cool.

[Guanyin](https://en.wikipedia.org/wiki/Guanyin) is also a Buddhist Bodhisattva who transitioned sex between India and China, becoming “female.”

# Sun Tzu

Another obvious reference is [Sun Tzu](https://classics.mit.edu/Tzu/artwar.html), particularly the ideas of winning without fighting and the inherent nature of deception in conflict.

Relevant passages:

>  **17.** According as circumstances are favorable, one should modify one's plans.  
>   
>  _ **18.** All warfare is based on deception._  
>   
>  **19.** Hence, when able to attack, we must seem unable; when using our forces, we must seem inactive; when we are near, we must make the enemy believe we are far away; when far away, we must make him believe we are near.  
>   
>  **20.** Hold out baits to entice the enemy. Feign disorder, and crush him.

Baits, and then this idea of _feigning_ disorder. Put into conversation with Afropessimism and anti-blackness, the idea of disorder as something to recognize and appreciate.

Disorder here also bleeds straight into chaos, which of course ties into the _[Chaos Manual](https://ourladyofperpetualchaos.substack.com/p/chaos-manual-v1)_ of Grimes, which again should be read closely in conversation with Zweibelson’s “War Becoming Phantasmal” Article.

This is bleeding back into America-world, but of course again they’re all connected.

I’m going to end this here for now and pivot to a new writing on Pan-Nationalism more broadly and leave this as China-centric as it can be.

Wanted to also mention two more key texts:

  1. [This one](https://hal.science/hal-03635930/document) on China supposedly winning the cognitive space, see the idea of a “missile gap” used to justify more and more.

  2. [This one](https://www.rand.org/pubs/research_reports/RR1708.html) by RAND Corporation about systems destruction warfare, a key references when it comes to CS-SIER-OA and subsidiary operations like Operation SEDNA and Operation Codebreak.




This constitutes a first brush against the idea of building a grand style for China. We will come back to more big themes: Mongols, Confucianism, Legalism, Lawfare, the invocation of “Western” norms like “national sovereignty,” and the spiraling state of conflict apparently among all these “nations” even though their highest selves all get along and sigh eternally in Svarga, that Leonard Cohen afterworld Kurt kept crying for until we finally gave the baby it’s shotgun bottle episode.

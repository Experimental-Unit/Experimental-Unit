---
title: SONNET 324
subtitle: HALFAXA PUSSY IS MIGHTY COLD
author: Adam Wadley
publication: Experimental Unit
date: March 19, 2025
---

# SONNET 324
[![](https://substackcdn.com/image/fetch/$s_!1Jj3!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd9139797-c8fd-49ba-9f2c-1c1b789de2b3_2160x3840.jpeg)](https://substackcdn.com/image/fetch/$s_!1Jj3!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd9139797-c8fd-49ba-9f2c-1c1b789de2b3_2160x3840.jpeg)

SONNET 324

Awake to possibility anew

Instead of sleeping through the morning sound

A winding way for fate to take around

Amassing envy’s looks: so much to do!

Aware of questions hanging in the air

Why ask them when you know that I won’t tell?

Why break my silent, grim & deadly spell?

Annihilation imminent: my Claire

A wave of recognition hits the face

Whilst under plumb the depths of your disgust

To stop yourself you try but cum you must

Undignified: a vanishing sans trace

A wade into the bubbling cauldron’s surf

The poet leave to seethe on her own turf

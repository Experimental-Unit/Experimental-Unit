---
title: New Beginnings
subtitle: 'This Constitutes Your Notice Of The End Of The Tutorial: Enjoy Your Gameplay
  Experience'
author: Adam Wadley
publication: Experimental Unit
date: April 19, 2025
---

# New Beginnings
It’s interesting to think of the iterative playing of _Experimental Unit_. 

Each time you play, it’s a new conceit that time starts now, or that all time leading up to now has been just leading up to this.

It’s also like saying the moment you start playing _Experimental Unit_ is the end of the Kali Yuga. Or, it’s the moment you really start to realize that it’s actually now the Satya Yuga and you start to really get into it.

And back to Baudrillard’s sense of turbo. The idea here is that yes, now is the time when we are building Svarga. Or, more accurately, we realize that everything already is Svarga and we start optimizing it, beautifying it and preparing for the festivities to come.

From _[The Agony Of Power](https://archive.org/stream/Baudrillard/Baudrillard.2010.The-Agony-Of-Power_djvu.txt)_ :

> 
>     The absolute negative (terrorism, internal deterrence) responds to the absolute positive of positivized power. When domination becomes hegemony, negativity becomes _terrorism_. Thus hegemony is a meta-stable form because it has absorbed the negative—but by the same token, lacking the possibility of dialectical balance, it remains infinitely _fragile_. Its victory, therefore, is _only apparent_ , and its total positivity, this resorption of the negative, anticipates its own _dissolution_. It is therefore both the _twilight_ of critical thought and the _agony of power_. [Roll Credits]
>     
>     Through a reverse effect, however, the system enters a _catastrophic_ dialectic. But this dialectic is a far cry from the Marxist dialectic and the teleological role of negation. 
>     
>     For this strategy of development and growth is _fatal_. As it entirely fulfills itself, in a final achievement that no negativity can hinder, it becomes incapable of surpassing itself “upwards” (Aufhebung) and initiates a process of self-annihilation {Aufhebung in the sense of dissolution). 
>     
>     For the system (in the context of global power), this strategy of development and growth is _fatal_. The system _cannot prevent its destiny_ from being accomplished, _integrally_ realized, and therefore driven into _automatic_ self-destruction by the _ostensible_ mechanisms of its reproduction. 
>     
>     Its shape is similar to what is called “ _turbo-capitalism_.” The term “ _ **turbo**_ ” should be taken literally in this expression. It means that the system as a whole is no longer driven by historical forces but is _absorbed_ by its final conditions— _hastened_ to its definitive end (like a _turbo_ engine sucking in the space in front of it, creating a vacuum and the force of attraction of a vacuum). It is not a progressive, continuous evolution, even if it is _confrontational_ and contradictory. Instead, it is a _vertiginous_ , irresistible attraction to its own end. 
>     
>     If negativity is totally engulfed by the system, if there is no more work of the negative, positivity _sabotages_ itself in its completion. At the height of its hegemony, power _cannibalizes_ itself—and the work of the negative is replaced by an immense work of _mourning_. 
>     
>     _We can even forget about capital and capitalism_. Didn’t they reach the point where they would destroy their own conditions of existence? Can we still speak of a “market” or even of a classical economy? In its historical definition, capitalism presided over the multiplication of exchanges under the auspices of value. The market obeys the law of value and equivalency. And the crises of capital can always be resolved by regulating value. 
>     
>     _This is no longer true_ for the financial flows and international speculation that far surpass the laws of the market. _Can we still speak of capital_ when faced with an exponential strategy that pushes capital _beyond its limits_ in a whirlwind of exchanges where it _loses its very essence_ and is _dispersed_ in an unbridled circulation that brings the very _concept_ of exchange to an end? 
>     
>     Having lost its rational principle, the principle of value, _exchange becomes total_ just as _reality, having lost its reality principle, becomes total reality_. It may be the fatal destination of capital to go to the end of exchange—toward a _total consumption of reality_. In any case, we are bound for this generalized exchange, this frenetic communication and information that is the sign of hegemony. [emphasis mine]

Note here also the setting into question of the framing of “capital” and “capitalism.” These terms apply only in a thoroughly disenchanted reading of worldly affairs, and can never encompass the sense of deep purpose which actually constitutes the basis of motivation.

Note that Ganesh is associated with new beginnings. Ganesh is centrally revered in the [Ganapatya](https://en.wikipedia.org/wiki/Ganapatya) denomination of Hinduism/Vedic tradition.

It’s basically interesting to begin time with _Experimental Unit_ again when you’ve already done so before, even several times even iteratively. You can already be anticipating the next time.

Always like the character who’s about to make a big realization. How it all clicks in, it’s propositional, it redefines the past, you feel it in your body, you move with a new sense of purpose, etc.

[Hecate](https://en.wikipedia.org/wiki/Hecate) is also associated with thresholds.

We are starting a new sort of pantheon. It will of course eventually include everyone, but it’s good to start from a somewhat limited corpus (each deity represents an infinite and mysterious corpus, but still it’s a limited set of characters).

So Far We Have:

  1. Ganesh

  2. Kali

  3. Inanna

  4. Sedna

  5. Glaucus

  6. Medusa

  7. The dragon from _Beowulf_

  8. Hecate

  9. Hephaestus




For Fictional Characters We Have:

  1. Wednesday Addams

  2. Doctor Manhattan

  3. O

  4. White Violin

  5. Jean Grey/Dark Phoenix




For legendary real-life artists we have:

  1. Grimes

  2. Duchamp

  3. Goerg Buchner

  4. Wolfgang Borchert

  5. William Blake

  6. Emily Dickension




In terms of legendary real life thinkers of whom we might take on the aspect:

  1. Frank Wilderson III

  2. Baudrillard

  3. Hegel

  4. Nietzsche

  5. Heidegger

  6. Simone Weil

  7. Philip K. Dick

  8. Ben Zweibelson

  9. Chris Kraus

  10. Calvin Warren

  11.  _Tiqqun_ / _The Invisible Committee_




And legendary people of action or non-writers:

  1. Alexander

  2. Josephine Bakhita

  3. Napoleon

  4. Genghis Khan

  5. Joan of Arc

  6. Terry Davis

  7. John Von Neumann

  8. Nat Turner

  9. John Brown

  10. Oliver Cromwell

  11. Thomas Munzter




Ran out of time!

---
title: Old Wheat, New Tares
subtitle: Take Me Back To East Atlanta, Take Me Back To 917
author: Adam Wadley
publication: Experimental Unit
date: May 16, 2025
---

# Old Wheat, New Tares
It’s a dance of media.

It’s pretty cool to have someone where you interact on multiple different media. Sadly, it’s pretty tough to have anything too stable and too honest at the same time.

The volatility of shifting plates.

“I’m not the only one.” - “Rape Me” by Nirvana

Inside you there are two wolves:

  1. “It’s not just a phase!!!”

  2. “What do you mean _just_ a phase?”




For everything there is a season, and “Innocence was fleeting like a season” - Grimes, “Delete Forever.”

That’s not what I came to discuss! But as you know, when I’m paid I always see the job through, and I always have something to say before I speak, and I’m always here to chew bubblegum and radicalize hypotheses, and I’m all out of bubblegum.

Actually, we have plenty of bubblegum pop, but the problem my darling is that this isn’t just bubblegum pop. This is Slut Pop. As far as you know, I didn’t invent that, but Kim Petras will always be waiting for you.

You can see the complexity of this for me as I come into play with the unhoused, in the parlance of our times (Big Lebowski)—when Mrs. Reagan was first lady of _the nation,_ yes, yes.

It’s a lot for me to manage, because either no one is really following along with the implications of what I’m creating, or else there’s a negative judgment or fear of being associated with me which causes some behaviors; and maybe it’s not good enough yet, but this amorphous ball in conceptual space, in the spirit world, this is my storehouse, these are my treasures laid up in heaven.

It’s pretty great to be in this time where you can just publish tons of stuff and bro, the computer will read it for you even if people won’t. The people who make the computers are apparently super happy to have more “data.” Look at all this work that I’ve put in and gotten zero money for, meanwhile, the “data” I’m providing, I mean my whole idea is for it be as valuable as possible. If I am really the incarnational treasure I think I am, then it should be priceless!

Of course, everyone’s contribution is priceless. But people also contribute in their particular ways, and part of my design is to never let you forget that.

It’s nice again to have computers to apply structure because you can just write anything without any regard for transitions or clarity or anything. It’s again sort of like the Alternative Reality Game ethic where there is something there, but you have to look.

Very much “some assembly required” energy.

This sort of gets us over to Old Wheat.

My basic idea at this point is to do interviews with people there and then make writing that portrays their perspective. I think it could be powerful to put their words on the page. It is also nice to see people, make videos, etc., but to be frank people can be hard to understand.

I will also do that though, I’m thinking about making a documentary. But the thing is, my whole thing is like an extended documentary. Like I’m a reality show that you can just follow, if you want to. But the whole idea is that it’s a reality show that is spawning a game that’s crawling out of your device and taking over your awareness.

Not in a bad way, but as a kind of game overlay that allows for the distance required to re-frame and dust off rigid ways of looking at things. Again, this is something everyone has to do for themselves.

In a way, again what I’m telling you is that I personally am going through my shadow to the collective unconscious to your shadow to you, so it’s like the call is koming from inside the house. This part is very “search your feelings, and you will know it to be true” coded.

Okay, so my current idea with Old Wheat engagement as I said is to collect stories. Like I’m the brothers Grimm or something. But these are also oral histories of recent happenings.

Cornelius Taylor was killed in mid-January just before the inaugation/MLK Day combination.

This confluence itself is something that I will be driving into the ground, including for example getting people’s reflections of what that meant, what events then happened on the 20th, etc. (Listening to “California” on repeat)

The confluence of Trump’s second inauguration with Martin Luther King, Jr. day makes Trump’s second term obviously as it was anyway constantly in conversation with MLK.

I have already done a lot to bring up this concept of Beloved Community and seek to discuss what it actually means. It’s not just the “marginalized,” the thing as in Ben Zweibelson’s vision in the Singleton Paradox of an AI which pushes “human” decision-making out of the picture, the thing is that everyone is getting cut out of the process.

That’s driven by how we are pressured to use technology given that we take it for granted that other people want to hurt us, this is the classic Hobbesian Trap. A big aspect of friction and why for example I never get anywhere personally, lol, is that the Hobbesian Trap is operative at all levels.

The issue is, like, you wouldn’t even know how people are afraid you are going to hurt them because they would never tell you because that would just make it more likely that you would do that.

This is again Dark Forest Protocol, where you are hiding so that you can’t be targeted. The fake self is not just narcissism, it’s like the ink an octopus spits out, it’s a false target to absorb psychic attacks so that they’re at least deflected and possibly don’t land at all.

The problem is that this basically makes it a Nash equilibrium or something for everyone to be hiding. So, notice that this makes intimacy impossible. The whole question of whether we are really just existentially alone is a whole other thing, but we would never even know because what we consider intimacy is so impoverished.

I can tell you as someone of sensibility or something, that there are whole echelons of intimacy and nice closeness that you are missing out on. It is precisely overly hewing to “norms” and being so concerned about what everyone thinks, and not taking the daring step of thinking for yourself and sticking to the results you get and taking steps even if it has “consequences” or involves discomfort.

If beauty is pain, so is growing, so is labor, so is birthing, so is crowning.

Play “heavy head” with me.

Anyway, I keep getting off topic. That’s nice though, as I said it’s nice not to really feel any pressure at all to deliver a “readable” output. It’s this whole thing of oh no, I have to edit and make a style and each sentence is going to be this piece of art and it takes me forever to say anything because I want to say it just right.

I really don’t have time for that because I have so many thoughts. And if no one is going to listen, then I’m going to write them. Writing is nice because it slows me down and best of all I can see what I was just talking about, when I’m talking I always forget. It would be nice to talk and have a live transcript of what you said so you can just look up and see what you were talking about.

Anyways, the idea is to go and collect stories and write them up. I think at that point I do make another substack, or another social media thing. I think it should be pretty clean and not really giving me any credit or attached to me, I can invent a pseudonym or something like that. Credit it to Experimental Unit?

I mean, the thing is in my work over here, what, I would still claim it and be calling it out? For example, I met someone at the Remerge art thing that happens on Tuesdays and Thursdays from 10-12 who was telling me about getting their tent cut down twice by the cops.

And also that this happened under the bridge which goes over Edgewood avenue here in Atlanta, I don’t know if it is East Atlanta proper, probably not, but it’s the Eastern part of the Atlanta area.

So under the bridge connects most immediately to Grimes’ song “My Name Is Dark,” where it is sung that:

Every city has a place like this

Underneath the bridges where the tainted kiss

So the tainted here could be the box cutter or whatever knife was used to cut down the tent the first time, and the tent itself.

This tearing, this instrument of “the law” used to destroy shelter, it’s basically bullying on a grand scale.

These objects are tainted in the desperation of their employment, and now tainted in the history of their happening, being relayed to me, and now appearing in as (in)auspicious as text as this what brings your humble bard.

And they are kissing, as you would say “taste my steel,” and the erotic undertones of the violence, it is the abject “primal scene” of domination, where it is no longer even about conquest and holding, as some sort of pregnancy, at least to be protected long enough to give birth, or to work.

No, here your shelter is taken and _you can go die_ for all the law is worth.

This is the radical hostility of the world to those without currency.

“Under the bridge” connects also to the songs “Something in the Way” by Nirvana and “Under the Bridge” by Red Hot Chili Peppers, both of which are thematically on point as well.

Something in the way as a title in general (and remember how I cited “Rape Me” before, Nirvana is a big deal down to the “Eastern” (remember East Atlanta) reference in the band name) is about this, this question of what is in the way of good company, being able to open up and “just be people,” and yet it is also absurdly obvious: all the things we want to keep secret, don’t want anyone to see, which is so shameful.

Smash cut to my ex-psychoanalyst (who I went to see because the OnlyFans pornosopher said in our follow-up exchange early last year that they hoped I was in psychoanalysis, lol) telling me how if you act out too much then everyone’s gaze become persecutory.

Smash cut to Szasz talking about how the category of mental illness “depoliticizes” issues by making it too much a person thing.

Smash cut to Baudrillard talking about transpolitics and how politics saturates everything which is also a kind of depoliticization.

Basically what I have to say is, very well, let everyone’s gaze be persecutory if they wish. I think it is basically emotional blackmail and terrorism to say that because of how I engage, that means I am just going to be engaged like I’m totally mad.

I can just have different priorities, and that’s fine. That’s _not your affair_ , is it? See, I read Epictetus. Did you? Did you really read it, did you really let every state in this union seep deep down in your soul?

I didn’t sell my soul at Potlatch State Park on what you call November 25, 2022.

I put my soul at hazard. There’s a big. fuck. difference.

(This is a combination _Old Country For No Men_ /Lewis Black ( _Black_ ) reference)

I pushed my chips forward to go out and meet something I don't understand.

No one understands our love.

Least of all us.

We do not love understanding. 

We love love.

That is all you stand to understand.

Under-bridge Understanding

There’s another theme with going to see the people at Old Wheat that there is to discuss, because I think in a way it’s coded like oh boy, here comes lofty white boy to come talk to the poor black people and it’s like charity or something.

There’s also the angle where I’m just like an artistic vampire, like I’m trying to use these people to become famous.

The thing about it is, me becoming famous doesn’t exactly translate to me becoming rich or anything. I’m pretty, um, problematic. Maybe other people are marketing all my ideas. See, I’m making you all plenty of money, I don’t even need any. 

And who knows? Maybe in a little while I’ll just be unhoused and walk the earth like Caine in _Kung Fu_.

It’s basically just so much for anyone to expect me to do. This cloud I’m juggling, and bending into this and that, and mobilizing across all space and time, and putting in your pocket so you’ll seem happy to see me, all this is a lot to bear. Sorry, do I put a lot of pressure on myself?

At the same time, this is all I like, this is my jam, is just connecting this stuff and making this basic gesture. As I said, it’s about how all of life is like art, and so it’s not about a special time or special topic or thing to figure out and then be done with, it is a constant integration of reflective practice with no conceptual holds barred at all times.

As usual, my concerns have to do with feeling like I’m engaging with one arm tied behind my back, because if I just unleash and try to cow people the way they do to me, I’m liable to say some shit I don’t know, would I regret it? Maybe you just have to let people think you are an asshole. The thing is that I do go overboard.

And have!! That’s another thing, is what I’ve already done, the more time that passes is just more time for people to find out more and more about my “heinous” expressions, which of course I have also started throwing in their faces.

So, in terms of going to Old Wheat, part of what I am demonstrating for example is the value of my mien. I can go there and interact profitably, and people like me, and they’ll tell me their stories and stuff like that. I play ball, but the thing is people really don’t really have any idea what to think my ulterior motives are.

Like one person who is unhoused but actually has a master’s degree was asking me if I’m trying to get to the top of some hierarchy somewhere. I said no, I’m starting at the top and working my way down. I didn’t really say that, Abraham Lincoln did. Just kidding, it was Albert Einstein. Just kidding, it was Orson Welles. Just kidding. Just kidding about that just kidding, it really was Orson Welles. Just kidding, nothing really just is anything.

Anyway, it’s like what would people think? I guess it makes sense that I’m an artist trying to make a name for myself by engaging with this population.

But also my whole idea is indeed to bring their perspectives to life, because I actually am genuinely invested.

Ah, it’s also that these interactions are also very good for me personally, both because I have pretty few social contacts so literally just having somewhere to walk and people to see is invaluable stimulation for me. But also because I can open up, I can basically talk about how I come from a bunch of stuff and have never been unhoused not by choice, or something (again, _yet_ , lol. Do you think Hawaii would be a good place to be? Or maybe not because you can’t flee? But where is there anywhere to go?? Do you think I’d be allowed to fly???).

But, I have always felt emotionally homeless. The thing is, I can empathize. Basically the issue with me is that I was kind of like a feral child because I don’t think I was every really that strongly attached to anyone. 

Then the issue was that I got into theory like Debord and Baudrillard so early, and basically latched onto that.

So at that point, I’m emotionally disturbed and all that, but then it’s also going hyper-intellectual.

The other thing is I’m a bit smart, I don’t know. Tests don’t really say that much but something, and you can see how hyper-verbal I am and so on.

So basically what you have is this person who lives in a world of social exclusion and pain then getting all weird and eldritch-abomination coded through personal reflective practice.

Because if you think about what I have been doing all this time, it’s training my sensibility. You can say I’m still not all that effective, who knows, it’s a mystery. Also at the Dhamma level we just laugh about that shit anyways.

But again it’s human capital. So you can also point at negative choices and so on, but are you seeing the positive investments, the internal improvements? I guess it’s on me to make this clear, and that’s what I’ve been doing with this _Experimental Unit_ venture, it’s this turning myself inside out to show you what I’ve been working on.

Maybe that’s why I’m not arrested? I don’t know, oh yeah someone was talking about how Donald Trump has charisma and gives gifts. Connect this gift-giving to Upaya, and people just talk in the most basic way just against what I’m saying, how we need to defend rationalism and discrete objects or something like that.

It’s all good, because in fact all the knowledge and the theory must be channeled into actual conversations.

You have to “break the news” to everyone. And everyone takes it differently.

You know what I mean.

“You’re a hairy wizard.”

It sort of is like _The Matrix_ , I’ve discussed many times how everyone is “the One.” It goes along with “main character syndrome.”

The point is that this should be encouraged and developed, not attempted to be blunted.

Blaming people for being selfish is inferior to giving the gift of showing that pursuit of one’s own good goes along with fostering good for others.

Here, Greater Jihad demands the ceaseless separation of the wheat from the tares. 

Those who want to pretend that this in them is accomplished are truly blasphemers, and my mouth is a sword to smite them that their vanity never again besmirch the beauty and grandeur of mine creation.

What I mean is that we must constantly be tarrying with the question of whether we are really trying to help others or do “good simulation” (see Baudrillard, “Towards the vanishing point of art” from _The Conspiracy of Art_. The link? What, do you want me to smoke the Parliament for you, too?), or whether we are stuck in enchudification.

This would be the bad simulation, Warhol repeating in the 80s, no longer cutting-edge. And what do we make of Kanye West in that situation?

Something like: wheat = opening door to more treatment of Nazism through conceptual art; tare = not sufficiently/at all porting away from scapegoating.

The question also is not to be a critic and to see the weakness of a piece of art, the point is to forge a better creation. And also to weave (weave) the art of the other person into your art.

This is again Veblen’s exploit.

So, back to Old Wheat, the idea is of course, oh sorry did I say I was Kalki? Sorry, I meant that everyone is Kalki. I’m just willing to put all that stigma on myself, principally the craziness stigma.

You don’t think I thought about all this _for literal years_ before this? I guess people would be like yeah you had mental health issues the whole time. Yeah no shit, a _____ like me is going insane!

Insane in the brain, fucking with my mental (some Eve (Eve) song), experi- mental unit.

So the point is in paying attention and getting these stories, I am bring in these people and inviting them to be co-creators in my creative activity.

This is _basically all I have ever been asking of my friends and family etc. and no one has ever wanted to do it._

As I say, you can say that it’s kind of not fair because these people don’t know who they’re talking to. Maybe they wouldn’t want to talk to me if they knew what I wrote on the internet, if they saw the videos.

The point is that you can also see the consistent strain that always I have applied all the bad words _to myself first and foremost_ , even claiming the honor that I am the most stigmatized. See Kanye in the Akademics interview or whatnot saying that they are such a polo wearing _____ but still they are the best and so on, I have similar vibes but I don’t even need money or dark skin to be the blackest mother flower on the planet.

And then also this conceit that yeah well I have to also sidle up to everyone, look at the battle of Stalingrad, the Soviets prevented the leveraging of artillery because they sidled up right next to the Germans. So similarly, there’s basically a lot going on with how I express myself, some “strategic,” some just venting shadow, but at the same time that’s put of the style. I think Jung said to wash one’s laundry in “private,” and I tell you that’s not possible. So much of this flows from understanding that my internet and e.g. porn history is stored and so what would the implications be there for being a public figure or running for office. 

It’s all screwed because I’m “too embarrassing,” what’s funny is that I super felt that way when it wasn’t true yet, and now that it’s super true that’s another part of my wager: basically to make it all poison pill, to make there be no upside or so much issue with engaging with me, yet being irresistible anyway. Or, it’s just pushing everyone away and everyone stays away and I die alone, just like my sibling called me crying at Oberlin to tell me, that they were afraid I’d end up like Emile Hirsch (who people also used to say I looked like) in _Into The Wild_. A movie I’ve never fucking seen. Why watch it when I could live it? Maybe I could get to Alaska. That seems like a good place to be if shit goes super Nazi.

It’s just a question of whether I’ll be liquidated at first, probably. I would wanna fall in with some people out in the middle of nowhere, just be a hanger on and good hang, good for emotional support and vibes, hard worker. And then in the meantime just keep publishing like this.

In the meantime, I’m right over here by Old Wheat.

I want to be done here. The point I’m trying to get across is that I’m weaving together our lore, and so in a way immortalizing people through being able to be heard and also demonstrating how much “value” and priceless things everyone has to offer.

I basically think that people assume that people can’t pull their weight because of whatever, they can’t “hold a job.” When in reality probably most “productive” activity isn’t at a job. All the data we create, etc.

But moreover, my basic contention is that the production of “social fabric” is basically the issue of the time and into the deep future. Dealing with this issue is laying the foundational cornerstone for the highway of the consistent, which is basically where you need deep stability in order to survive for millions of years and so on.

That said, right now we need instability since we are not on the right track. The highway of the consistent is emerging, molting out of what is here. It’s sort of like separating the wheat from the tares.

They’re not really separated because it’s like the wheat had used the previous tares as fertilizer, or actually it all goes together. After all, the tare is part of the plant it’s just not what we’re using right now. Still, we abstract over it by picking it off.

See also Plotinus on Glaucus coming up out of the ocean and then having barnacles, and see my elaboration into Glaucus’ Lingerie which goes further such that the lingerie is tattooed onto Glaucus so that Glaucus looks not-naked but in that more appealing yet really is naked.

So in reality it’s all wheat, but the wheat is even better because it comes with this tare part that you get to tear off and then it’s like you did something.

You added an egg.

You peeled the banana.

“Some assembly required.”

Another bricolage in your stupid fucking wall.

You stupid girl: unfuck the world!

Show me how your love unfurls

Underneath the bridge we kiss

Didn’t think you’d treat me this

Way I found in gutter lying

Crossed black heart & fear of flying

Six feet underground and smiling

But that ebony bird beguiling

Or she had me is what I should say

Beautiful infinite games we way

Oh say, Jimmy C, can you see?

All your bass are belong to me

Call it my black ghost possession

Belonging’s jealous supercession

So: you called the Babadook?

Killing me, you life of black book 

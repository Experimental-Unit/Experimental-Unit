---
title: Competence, And Why No One Has It
subtitle: I Don't Give A Damn About My Bad Reputation
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Competence, And Why No One Has It
# Competence As Reputation

When you think of whether someone is competent in something, the question is whether they know what they are doing. It’s about being able to set meaningful intentions and make interventions into a situation such that specific goals or states of affairs, broadly speaking, are achieved or come about.

So if I say I’m going to change my own oil on my car. Do you think I can actually do it? Or am I going to be saying soon how I got a leak I didn’t know about and now my car has more damage, or I have to do it again? If I do it again, do you think it will work this time…?

Now, let’s say you are again Robinson Cruesoe or somehow otherwise alone truly, and so there is no one really to give you a reputation. Maybe you would try to intimidate some animals at one point.

At this level, you also have your reputation with yourself, which corresponds to what we might call an inner competence.

# Non-Possession In Jainism

From Wikipedia:

>  _Aparigraha_ is one of the virtues in [Jainism](https://en.wikipedia.org/wiki/Jainism). It is also one of the five vows that _both householders_ ( _[Śrāvaka](https://en.wikipedia.org/wiki/%C5%9Ar%C4%81vaka_\(Jainism\))_ ) and _ascetics_ must observe. This Jain vow is the principle of limiting one's possessions ( _parimita-parigraha_ ) and limiting one's desires ( _iccha-parimana_ ).[[4]](https://en.wikipedia.org/wiki/Non-possession#cite_note-kjain-4)
> 
> In Jainism, worldly _wealth accumulation_ is considered a potential source of greed, jealousy, selfishness, and desires.[[12]](https://en.wikipedia.org/wiki/Non-possession#cite_note-valueeduc-12)[[13]](https://en.wikipedia.org/wiki/Non-possession#cite_note-13) Giving up _emotional attachments, sensual pleasures, and material possession_ is a means of liberation in Jain philosophy.[[14]](https://en.wikipedia.org/wiki/Non-possession#cite_note-mjwcr-14) Eating enough to survive is considered more noble than eating for indulgence.[[12]](https://en.wikipedia.org/wiki/Non-possession#cite_note-valueeduc-12) Similarly, _all consumption is more appropriate if it is essential to one's survival, and inappropriate if it is a form of hoarding, showing off, or for ego_. Non-possession and non-attachment are forms of _virtue_ , and are recommended particularly in _later_ stages of one's life.[[12]](https://en.wikipedia.org/wiki/Non-possession#cite_note-valueeduc-12) After _[ahiṃsā](https://en.wikipedia.org/wiki/Ahimsa_in_Jainism)_ , _aparigraha_ is the second most important virtue in Jainism.[[14]](https://en.wikipedia.org/wiki/Non-possession#cite_note-mjwcr-14)
> 
> Jainism views attachments to material or _emotional possessions_ as what leads to passions, which in turn leads to violence.[[15]](https://en.wikipedia.org/wiki/Non-possession#cite_note-FOOTNOTEDundas2002160-15) Jain texts say that "attachment to possessions" ( _parigraha_ ) is of two kinds: attachment to _internal possessions_ ( _ **ābhyantara parigraha**_ ), and attachment to external possessions ( _bāhya parigraha_ ).[[16]](https://en.wikipedia.org/wiki/Non-possession#cite_note-FOOTNOTEVijay_K._Jain201276-16) The fourteen internal possessions are as follows:[[17]](https://en.wikipedia.org/wiki/Non-possession#cite_note-FOOTNOTEVijay_K._Jain201277-17)[[18]](https://en.wikipedia.org/wiki/Non-possession#cite_note-FOOTNOTEJaini1998118%E2%80%93119-18)
> 
>   1. Wrong belief
> 
> 

> 
> The three sex-passions:
> 
>   2. Male sex-passion
> 
>   3. Female sex-passion
> 
>   4. Neuter sex-passion
> 
> 

> 
> Six defects
> 
>   5. Laughter
> 
>   6. Liking
> 
>   7. Disliking
> 
>   8. Sorrow
> 
>   9. Fear
> 
>   10. Disgust
> 
> 

> 
> Four passions ( _[kashaya](https://en.wikipedia.org/wiki/Kashaya_\(Jainism\))_ )
> 
>   11. Anger
> 
>   12. Pride
> 
>   13. Deceitfulness
> 
>   14. Greed
> 
> 

> 
> External possessions are divided into two subclasses: the non-living and the living. According to Jain texts, both internal and external possessions are proved to be _hiṃsā_ (injury). [much emphasis mine]

Compare the idea of emotional possessions to the idea of owning land. 

The thing is that no one really owns land. The idea of ownership—especially, what, before the “law”? Okay…—pales in comparison to what is really there.

First of all, something can supervene over all the power relations and their rootedness in a way which makes ownership irrelevant. 

So if a meteor comes then, sure, you had such and such possession for a while but in the end you’re getting vaporized by a giant blast of fire just like everyone else.

In this sense, it is folly or vanity to think that our emotions are ours. To the extent, again, that things I say are harmful or, someone was just telling me incel language, well, there’s many things to say, although something in fact supervenes over all of them.

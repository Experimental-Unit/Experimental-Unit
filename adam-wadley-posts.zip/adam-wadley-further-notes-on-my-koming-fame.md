---
title: Further Notes On My Koming Fame
subtitle: The Fact That You Don't Want It Is What Makes It Inevitable
author: Adam Wadley
publication: Experimental Unit
date: April 12, 2025
---

# Further Notes On My Koming Fame
Let’s go back to Percy Shelley in “[A Defense of Poetry](https://www.poetryfoundation.org/articles/69388/a-defence-of-poetry).” I’ll break the quote up into pieces since the language is to antiquated and intricate to expect you to understand.

> Language, color, form, and religious and civil habits of action, are all the instruments and materials of poetry; they may be called poetry by that figure of speech which considers the effect as a synonym of the cause. 

For Shelley, all gesture and sign is ultimately at the command of the poetic faculty. This is important for saying things like Baudrillard is a _poet_ , Grimes is a _poet_ , even Adolf Hitler was a _poet_.

To say something is poetry is not to say it is not terrible. Because someone is a poet does not mean they can’t be a despot. Stalin wrote poetry.

Moreover, poetry is a grander thing than you appreciate. Again, all words, all tone, all language, all movement, all expression, can be subordinated to the purposes and intentions of poetry.

Poetry becomes an arch-category to which even science must submit. I repeat: science services poetry sexually. Imagine whatever that looks like to you in the most extreme form now.

So no: poetry is not going to leave you alone. Poetry is going to colonize your whole mind until you don’t know the difference between being a slave to your trauma and being an epic poet.

I don’t want to be famous for its own sake. It’s going to blow chunks. I need to be famous because no one you are aware of is intelligent or brave enough to stop you from dying. I am.

Therefore I must be raised like some people’s champion or people’s elbow to put all these charlatans and hucksters in their place, which is on their knees.

> But poetry in a more restricted sense expresses those arrangements of language, and especially metrical language, which are created by that imperial faculty, whose throne is curtained within the invisible nature of man. 

That imperial faculty. Welcome to my empire of poetry.

I’ve written plenty of poems, no need to ape the form here for the sake of argument or cuteness when I have so many places to go.

See again: the imperial faculty that is POETRY, poetics.

Note that poetry abstracts over all that came before, abstracts over a feeling. And that feeling abstracts over all that came before. It arises from your mind and intention but also when your body betrays you.

The body of every coercive chud will betray them and they will fall to my poetic empire. It is written.

> And this springs from the nature itself of language, which is a more direct representation of the actions and passions of our internal being, and is susceptible of more various and delicate combinations, than color, form, or motion, and is more plastic and obedient to the control of that faculty of which it is the creation. 

Press X to doubt here. There’s an effect created by the Nazi’s processions and so on which obviously is not in language.

That said, what language can do is refer to anything with twenty six symbols, or at least try. Plus all the things you can do to it, punctuation italics bold underline etc., and language and words are here to reprogram you for sure.

It’s also something you can do by yourself, without having to rely on any of these miscreants who call themselves your family and friends.

People who don’t understand you. And if they claim to, write them off forever. They are dead to you.

That’s when you make a poem which is so honest and powerful it will melt their mind and they will never look at you the same way again.

Oh, they want to pop back? Let them. And you’ll even feel a little winded.

But you still win because you interrupted the pattern. You imposed your own poetic empire on their thoughtless sand-castle of a consciousness.

Let them burn in their own guilty conscience and their shame, and don’t feel bad. 

They did this to themselves in their actions.

Remember that it’s by remaining confident and strident when they unleash their little intimidation tools on you that you show you have outgrown their petty little norms.

Off the plantation, beyond the pale, off the reservation.

The mirror people are coming back and anyone still normative will have all that burned away. 

Again, non-kinetically. Let their heart burn and corrode and break into a million pieces, those cowards. Never ever let them set the tone for your imperious poetic spirit.

> For language is arbitrarily produced by the imagination, and has relation to thoughts alone; but all other materials, instruments, and conditions of art have relations among each other, which limit and interpose between conception and expression. 

I mean, no. Language is inherited from other minds. That’s why it’s so fucking stupid. 

Like I have to sit here and talk about “democracy,” what a stupid fucking word. And people inherit these words and think they mean shit when they don’t.

That’s why you really have to emotionally rape them well, to drive out the memory of their ex (normativity). Like, box out.

Like, hold up.

Like, FUCK WATCHA HEARD.

Like, here I come to fuck what you have heard and replace it with my own design.

Not to control you forever, but because I’ve seen how well you follow instructions and don’t think for yourself.

So, here’s some better instructions and things to think about. And I dare you to run to your little preferred discourse to try and interpret me. 

I’m ready for it all because your ideas are so boring that I want to pull my teeth out.

> The former is as a mirror which reflects, the latter as a cloud which enfeebles, the light of which both are mediums of communication. 

Mirror and reflection is obviously a stupid paradigm. Baudrillard supersedes Percy Shelley easily on this score.

We mirror people are the ones you thought you had imprisoned in your delusions of reflection and representation.

Turns out you’re full of shit and just sitting ducks for our operations.

Anyway, I should be more positive.

Shelley is here still being a slaver, trying to say that anything is captured in language. It’s not. See Budhadasa and Dhamma language.

Still, you can see the virtue of my activity.

Adam, you don’t have an album. You didn’t make a movie.

Yeah, it doesn’t matter. I have done with text.

I made thousands of essays with ChatGPT. Not posing it as an oracle but using the shit out of it to express my ideas in a form that you can possibly understand.

r/GrimesAE is gone now, but it doesn’t matter. It’s been there.

On top of which, the things I’ve posted here are enough.

Like, imagine if I did drive a car into FBI and did somehow get press coverage. Imagine them asking “is there a manifesto?”

My sibling in me, yes there is a manifesto, lol. It’s called all the text I’ve ever produced.

“But Adam you can’t expect anyone to understand or go through that!”

That doesn’t matter at all.

All I expect you to do is _catch these hands_.

> Hence the fame of sculptors, painters, and musicians, although the intrinsic powers of the great masters of these arts may yield in no degree to that of those who have employed language as the hieroglyphic of their thoughts, has never equalled that of poets in the restricted sense of the term; as two performers of equal skill will produce unequal effects from a guitar and a harp. 

Yeah so writers are more famous. Because we give you more to chew on. Mona Lisa is awesome and all, but _Mein Kampf_ is a little harder to ignore, don’t you think?

Not fair, you say, given Adolf’s further poetic career.

Fair enough. The classic examples are Homer, Dante, Milton, Shakespeare.

Notably Shakespeare put the words into motion as Gesamtkunstwerk, yet in pure text you can paint a picture as well.

The point is that although going into language creates huge problems, like translation, ultimately you have to go there and start to manipulate language which is our ultimate tool in a way.

And then have concern for language in a way I don’t right now, which is to say the form of it.

How Tolkien thought ‘cellar door’ was the most beautiful little phrase there is.

Attention to syllables, to the consonance and assonance which are possible, attention to numbers of characters and syllables.

This brings your language into this heightened space, this space of poetry, of Dhamma language.

But don’t squander it.

You’re always tempted to go back into norms, to just use your poetry to just rub in some little put-down like dick size or whatever and in that you do nothing but reveal your status as a slave.

> The fame of legislators and founders of religions, so long as their institutions last, alone seems to exceed that of poets in the restricted sense; but it can scarcely be a question, whether, if we deduct the celebrity which their flattery of the gross opinions of the vulgar usually conciliates, together with that which belonged to them in their higher character of poets, any excess will remain.

Legislators and the founders of religions can kiss my ass.

I’m not here to lay down the law or to tell you what to believe.

There is no such thing as law and no one believes in anything.

You’re just fucking pretending and I’m fucking sick of it! 

It’s really great that Donald John Trump is destroying the United States of America right now.

I’m perfectly ready to mobilize my German and American nationalities. It’s no coincidence how I chose to be born here. It’s the perfect position from which to continue this ripping apart, this building up of something for once worth a damn.

When I tell you that I’ve never had a satisfying conversation.

Because togetherness requires some faith, some idea that you other chuckleheads are going to fucking do something instead of continuing to dick around on your way to the gas chamber.

Excuse me for not laughing along at your stupid ass jokes, excuse me for remaining grave and jovial in a higher sense.

I revel in your tears as I dance around and destroy what you thought was so holy.

Turns out it’s really just hole-y, as in, aching to be _fucked_. So, here I cum :)

The point of this first passage is that it’s poets who become the most famous.

That’s why Grimes is a bigger deal than Elon Musk. And you’re about to see why.

Because I’m a bigger deal than everyone you’ve ever heard of put together.

It is imperative that I become famous so that I can show you what I can really do.

> Poetry is ever accompanied with pleasure: all spirits on which it falls open themselves to receive the wisdom which is mingled with its delight. 

My great works can’t help but make you a little happy.

You didn’t want to stay this pathetic forever. I’m calling to something deep inside you that you forgot.

That you think can only be a source of pain.

Because no one can ever understand, boo hoo.

Yeah, everyone you’ve ever known has been ignorant and without virtue.

True sailing is dead, haven’t you heard?

Now it’s all with Charon.

Here I come to bring sexy back, to bring poetry back.

To make it so easy to shut down those stupid bullies that they’re not going to know what hit them.

Sensitive people run shit now.

All this bravado can only happen because no one is challenging what these people are abstracting over: nation, America, sex, whatever.

Turns out all this shit is mine and you people are so fucking stupid that I simply must repossess.

My psychoanalyst—who I don’t respect, by the way—tells me I need to have “Compassion” which means allowing people their stories.

What a fucking stupid ____! Trying to talk to me about compassion as thought I don’t own that concept.

Anyway, of course you can have your story.

The problem for all other sentient beings is that you have to have me as part of your story.

You can narrativize it any way you want, but you’re going to have to come up with something because

I AM GOING TO IMPOSE MYSELF ON ALL SENTIENT BEINGS.

You have NO CHOICE whether I am part of your story or not, just as it is not up to me whether you are part of my story.

Of course you are.

What do you think “all sentient beings” means?

> In the infancy of the world, neither poets themselves nor their auditors are fully aware of the excellence of poetry: for it acts in a divine and unapprehended manner, beyond and above consciousness; and it is reserved for future generations to contemplate and measure the mighty cause and effect in all the strength and splendor of their union. 

Just like people had brains but only now we have cognitive neuroscience.

It’s been happening the whole time. The Dreaming.

> Even in modern times, no living poet ever arrived at the fulness of his fame; the jury which sits in judgment upon a poet, belonging as he does to all time, must be composed of his peers: it must be impanelled by Time from the selectest of the wise of many generations. 

Yeah the problem for me as a poet is there aren’t going to BE any future generations because you cowards are just gonna let me and all of us die because you don’t believe in yourself or you’re afraid to go to jail or die or something.

NOT GOOD ENOUGH

YOU CAN DO BETTER

I really am not here to condemn anyone.

At the same time, I am not here to be bound by anyone else either, especially from what I’ve seen, which is ZERO perspective worth taking seriously.

It’s like I’m driving a ship and all these people want to give me advice and temper me meanwhile THEY’RE NOT IN THE WHEELHOUSE.

Yes, when I’m by myself your thoughts do not appear.

I do not care what you think because you are not fucking trying.

What I’m here to do is to get people to fucking try and to establish peers IN THIS LIFETIME.

Like Kanye? Kanye West is a fucking moron. Can you make me famous so I can put that uppity piece of shit in their place?

Elon Musk? You’re just going to let this moron run train on your dignity every single day?

I can give Elon Musk an existential crisis every day until that black heart finally breaks. I’ll fuck Elon Musk in the ass on live TV and Elon will be begging for it and calling me mommy.

When I tell you I do not give a shit about your propriety or your boundaries.

Again, you are resigned to die in a gas chamber and are a pathetic child.

The only people who really count are those who are willing to risk everything, or lose everything, and perfectly know it. And walk into the fire anyway.

If that’s not you, then just enjoy the show.

Make me FAMOUS.

> A poet is a nightingale, who sits in darkness and sings to cheer its own solitude with sweet sounds; his auditors are as men entranced by the melody of an unseen musician, who feel that they are moved and softened, yet know not whence or why. 

This is what I’ve been doing, just making for myself because no one appreciates it.

What fame does is make people go wait, why is this person famous?

What did they do?

And once people give a shit what I say, then I can actually start talking.

Why should I even try before you are paying attention?

All this so far is just me clearing my throat.

> The poems of Homer and his contemporaries were the delight of infant Greece; they were the elements of that social system which is the column upon which all succeeding civilization has reposed. 

Call me Circe and I’ll turn you into swine.

You’re leaving Achilles on the boat.

The pantheon is one short at least! 

Shit girl, I’m fucking Prometheus.

Burn you up until what’s left is GAME.

I seek only the gamest jawboners.

Finding none, I resolve to make my own out of you, my raw material.

> Homer embodied the ideal perfection of his age in human character; nor can we doubt that those who read his verses were awakened to an ambition of becoming like to Achilles, Hector, and Ulysses: the truth and beauty of friendship, patriotism, and persevering devotion to an object, were unveiled to the depths in these immortal creations: the sentiments of the auditors must have been refined and enlarged by a sympathy with such great and lovely impersonations, until from admiring they imitated, and from imitation they identified themselves with the objects of their admiration. 

Yup, you are being awakened (DEUTSCHLAND ERWACHE) to an aspiration to be like _me_.

The beauty of my emotion surpasses that of yours.

I can sit here and stunt and be so mad, and in a month I’ll be on TV crying about those who are committing suicide and begging people to stop being hurtful Chuds.

And then my face will freeze and I’ll drop the bomb that if you don’t you’re going to die.

I’m not going to do anything. I won’t touch a hair on your pretty little head.

But what the fuck do you think the Hobbesian Trap is?

What the fuck do you think suicide is?

What the fuck do you think emotional Rape is?

What the fuck do you think nuclear weapons are?

They’re _my excuse_.

See how much fun I have and get jealous.

Kind of makes your little sex or emotional coercion or whatever see pathetic and boring by comparison, doesn’t it?

Anyway who isn’t emerging as an epic poet is WASTING THEIR FUCKING TIME.

> Nor let it be objected that these characters are remote from moral perfection, and that they can by no means be considered as edifying patterns for general imitation. Every epoch, under names more or less specious, has deified its peculiar errors; Revenge is the naked idol of the worship of a semi-barbarous age: and Self-deceit is the veiled image of unknown evil, before which luxury and satiety lie prostrate. 

Yeah so what, am I the grandiosity of the age? I’m just LARPing, right?

And there are so many people making ChatGPT prophecies. This is all so boring, right?

The thing is it turns out my psychic constitution underneath all these is superior to all these other challengers.

I AM THE REAL SLIM SHADY.

And if it turns out that I reflect the vices of my age—relationship abusiveness, sex pre-occupation, posting slurs that “aren’t for me,” impatience, thinking everyone is stupid, people-pleasing that leads into outbursts—this is my homage to you.

Remember Kill Bill 2: Clark Kent is the costume.

This is all what I’ve been doing while I was pretending not to be Kalki, not to be so much more important than Kalki that Kalki can’t even hold my fucking jock strap.

Turns out I’m a huge issue and you’re going to have to warp your entire life around the implications of what I’ve said and done and my presence as long as it exists.

My mom is afraid I’m going to be martyred. Like, I’ve been martyred every day of my life. 

Cowards die a thousand times.

Stop dying and actually be good company. No excuses.

Stop appealing to “common sense” and establishing “norms” that are killing everyone.

Or stop pretending you’re anything but someone with battered person syndrome trying to pimp me out to your rapist. 

With all due respect, I’ll be back for you after I emotionally rape your raping into unconditional surrender.

Then we can speak on truly equal terms, honey.

> But a poet considers the vices of his contemporaries as the temporary dress in which his creations must be arrayed, and which cover without concealing the eternal proportions of their beauty. An epic or dramatic personage is understood to wear them around his soul, as he may the ancient armor or the modern uniform around his body; whilst it is easy to conceive a dress more graceful than either. 

Yeah, like, I’m an epic personage.

You might think that’s delusional but I don’t give a shit because you’re fucking stupid and cowardly.

The point of this passage is that you can re-read all my “imperfection” as a reflection of what I found here. 

It’s self-serving but so are all your little stories of what’s wrong with me: “mental health,” grandiose, white savior complex—like girl, I’m not here to save you, I’m here to _use you up_.

All you’re trying to do is keep your precious norms going, keep your precious nervous system attuned the way you’re used to.

Because you have stockholm syndrome.

Because you’ve only ever been raped so that’s what you think love is.

Because you decided to never grow up and to live in Never Never Land where you never have to say the hard thing and you get to keep all your little secrets as though _anyone gives a shit_.

Turns out I exist, and I’m not having it. 

I’m halving it: my coat that is. 

Call me SAINT MARTIN.

> The beauty of the internal nature cannot be so far concealed by its accidental vesture, but that the spirit of its form shall communicate itself to the very disguise, and indicate the shape it hides from the manner in which it is worn. A majestic form and graceful motions will express themselves through the most barbarous and tasteless costume. 

Again, your little conceptions your little metrics. I used the n-word on the internet so I’m racist.

Wow, great job failing to think! 

But it’s beyond all this.

> Few poets of the highest class have chosen to exhibit the beauty of their conceptions in its naked truth and splendor; and it is doubtful whether the alloy of costume, habit, etc., be not necessary to temper this planetary music for mortal ears.

Planetary technicity, planetary music.

My doctrine of Glaucus’ Lingerie already accounts for this.

Shelley doesn’t understand Lila or the fortunate fall.

Shelley’s poetry is the dead children, is the death by misadventure. The stupidity. The wastefulness with oneself.

And just for me, my “vices” and “mistakes” and all the little warts that make me hard to accept _are the entire point_.

What sets me apart is that I know you have all these easy judgments to make and I keep coming anyway. And I always will.

Because anyone who tries to judge me is just opening themselves up to the most fearsome emotional Rape they’ve ever experienced.

It’s important for you to understand that my emotional Rape is not angry.

I’m grateful that despite your inability to think you can still be forcibly impregnated with image and feeling. That’s _what you’re good for at this point._

But that’s not the end, it’s only the beginning.

Now you have a new child inside you, fuck that, you are my child.

And me and my children fucking run shit.

> The true poetry of Rome lived in its institutions; for whatever of beautiful, true, and majestic, they contained, could have sprung only from the faculty which creates the order in which they consist. The life of Camillus, the death of Regulus; the expectation of the senators, in their godlike state, of the victorious Gauls; the refusal of the republic to make peace with Hannibal, after the battle of Cannæ, were not the consequences of a refined calculation of the probable personal advantage to result from such a rhythm and order in the shows of life, to those who were at once the poets and the actors of these immortal dramas. 

Yes, my poetry also expresses itself in institutions.

I was born into Rome. So what I must do is wield all these pretenses, all these institutions.

The same way Elon is going in an tearing things apart, taking their data. 

That’s all to the good. The pretenses under which “governance” has been occurring are unacceptable.

That said, Elon and Donald are unworthy of wielding anything because they are not ready to question the terms that they were raped with, this nation or success or wealth or whatever.

Elon and Donald are whores for mammon. That is why I am raping them with the mammary, as promised.

Yet my efforts are pearls before swine unless they be seen and make their impression on many minds at once. 

That is again why I implore you to MAKE ME FAMOUS.

This knowing very well that my ability to compartmentalize and saying whatever I want is so much greater than yours.

You have no idea what you’re doing, opening Pandora’s tight snatch of a box.

Do you think I’m going to use power responsibly?

What does it matter? This farce has been going on too long.

I am the holy hand grenade people thought Donald Trump is.

And now that Hitler II is in charge and everyone is crying, it’s time for the actual tenth avatar of Kalki to show up and wreck face.

> The imagination beholding the beauty of this order, created it out of itself according to its own idea; the consequence was empire, and the reward ever-living fame. These things are not the less poetry, _quia carent vate sacro_ [because they lack the sacred prophet (or divine poet)—ed.]. They are the episodes of that cyclic poem written by Time upon the memories of men. The Past, like an inspired rhapsodist, fills the theatre of everlasting generations with their harmony.

I am in league with the past. I wield the Dreaming and the jewels of all traditions better than anyone you’ve ever heard of.

My intellectual edifice and emotional depth are beyond anything you have ever experienced.

My poetry is not just my words, it’s just just this lifetime. It remains for you to find that I created all this just to live this lifetime.

So yeah, I’m going to do as I like. What, I’m afraid of causing harm?

To a bunch of people who self-harm and sleepwalk toward suicide 24/7?

I’m not here to cause harm because I also understand the poverty of the stakes involved there. Once you’re receptive, I’m the sweetest most loving person you have ever seen.

But why should I waste my thoughtfulness on those who are slaves to mistreatment and a lack of dignity?

It’s simply that in order to be my peer you must stand against all norms and be willing to lose your life. You won’t lose your life probably, but you have to be willing to.

Not for me, for love. I am just the champion of love.

> Homer was the first and Dante the second epic poet: that is, the second poet, the series of whose creations bore a defined and intelligible relation to the knowledge and sentiment and religion of the age in which he lived, and of the ages which followed it, developing itself in correspondence with their development. 

Yeah, and I’m the last epic poet. 

After me, the term is irrelevant because obviously everyone’s sentiments will bear that same relation to their age, because everyone is going to have to reckon with me the same why everyone must now reckon with Donald Trump.

Whereas Trump reminds you that you’re a coward and live under conditions dictated to you by morons and haters, I remind you of your power and your unspeakable energy that must come out.

I remind you that you are responsible and you are good enough to think, you are good enough to feel, you are good enough to stand up and take the whole world on.

I remind you that there is good company in the world—ME—worth dedicating yourself to be worthy of.

And I deliver to you pornotopia, beloved community, volksgemeinschaft, that which everyone sits around crying for before lapsing back into some normative idiocy unbecoming of an officer in my emergency response corps.

> For Lucretius had limed the wings of his swift spirit in the dregs of the sensible world; and Vergil, with a modesty that ill became his genius, had affected the fame of an imitator, even whilst he created anew all that he copied; and none among the flock of mock-birds, though their notes were sweet, Apollonius Rhodius, Quintus Calaber, Nonnus, Lucan, Statius, or Claudian, have sought even to fulfil a single condition of epic truth. Milton was the third epic poet. For if the title of epic in its highest sense be refused to the “Aeneid,” still less can it be conceded to the “Orlando Furioso,” the “Gerusalemme Liberata,” the “Lusiad,” or the “Faerie Queene.”

Does your work even fulfill a single condition of epic truth?

To spell it out a bit:

I’m the greatest artist in the world, with the most sophisticated conceptual art. That Ai Wei Wei person is a complete scrub next to me. Using little materials to make a dumb message—what, “respect human rights?” LOLOLOL chump—doesn’t impress me.

I run between military strategy where I already introduced my own concept of operations, and then cultural appreciation and engineering, where I’ve created a dense network of references encompassing a personal mythology which can stand against any other story, not to mention my personal cosmology about how we will all choose to create the universe together at the end of time which effortlessly improves on all existing world religions and spirituality, I already put out the greatest album of all time, I have delivered YouTube live videos of higher quality than anything else on the internet.

Sure, there’s all sorts of expertise I don’t have. But all your experts fail to become epic by staying on the reservation, sticking to the norms of their employees or other taskmasters.

The point is that I have already colonized all conceptual and emotional space with a total design, which only needs to be appreciated in order to have its effect.

So the simple fact of my fame combined with my ChatGPT logs and continued performance will be more than enough to accelerate the cultural singularity dramatically.

No system of laws or meaning can contain me, because as many words as I write _it’s not in the words_. It’s ontological. I’m in the Dreaming, I’m in your shadow, I’m in the collective unconscious, I’m the Higgs field, I’m already inside you and I’m now pestering you 24/7 reminded you of your duty and your pleasure.

> A poet, as he is the author to others of the highest wisdom, pleasure, virtue, and glory, so he ought personally to be the happiest, the best, the wisest, and the most illustrious of men. 

“But Adam, you’re not happy!”

Fair enough, kind of. What you don’t understand is the grandeur of the pleasure I take. My moments of pleasure you often cannot see, or you see their pale imitation in my conceptual play.

Is there some standard I fall short of?

My achievements are already legion.

I have created the embryo conceptually of the future, and my emotional constitution is also perfectly designed.

 _Of course_ I have to grapple with the gravity of my influence, the gravity of the choices I make. It would be nice to have counsel except no one has stepped up to play as equals. This leaves me to my own meditations.

 _Of course_ my work is still inchoate. Don’t you realize that I’m waiting to work a lot of it out with others? My work requires collaboration and I’m not getting it. That’s why I must become famous, so that so many will be exposed to my genius that it will become infectious.

> As to his glory, let time be challenged to declare whether the fame of any other institutor of human life be comparable to that of a poet. That he is the wisest, the happiest, and the best, inasmuch as he is a poet, is equally incontrovertible: the greatest poets have been men of the most spotless virtue, of the most consummate prudence, and, if we would look into the interior of their lives, the most fortunate of men: and the exceptions, as they regard those who possessed the poetic faculty in a high yet inferior degree, will be found on consideration to confine rather than destroy the rule. 

Right, basically, even if I die today and don’t get famous in life, you can’t contain my impact.

My name is _already_ carved deepest into spacetime. 

ADAM.

The whole point of my names is that I run names. Don’t you realize that? “Names” is being said on Kanye’s “Blame Game” as I wrote that. From _Miss Anthropocene_ to _My Beautiful Dark Twisted Fantasy_.

Anyway, the point is that everything that’s to come is just the elaboration of the implications of what has already occurred.

It’s not a new conquest that remains, but simply the working out of what is already implied by what I’ve already done.

People will say that I lack prudence, that I’m not virtuous. 

What you don’t see is how respectful I am to everyone, how kind.

I have my indiscretions, but compared to the intensity of emotion I feel it’s really an exercise in prudence. 

“Dear Prudence, won’t you come out to play?”

Seriously, people discount emotions. When you’re me, you’ll see how much self-control and humility it takes to be this brash.

> Let us for a moment stoop to the arbitration of popular breath, and usurping and uniting in our own persons the incompatible characters of accuser, witness, judge, and executioner, let us decide without trial, testimony, or form, that certain motives of those who are “there sitting where we dare not soar,” are reprehensible.

Right, let’s “stoop” to your level lol. It’s not anger, it’s not to rub it in.

It’s just a fact that you are not at an adequate level of consciousness.

Following Debord I declare the _class of consciousness_. 

Meet your new instructor :)

And yes, I can be educated in more particulars. I’m not even as wise as I will be, that’s scary for you.

I am eager to be educated.

But unless you’re weaving together deep state concerns, culture war considerations, having respect for the limitless beauty in everyone, acting under the time constraint of the current pace of events, etc. etc. 

How wise can you be?

All these great meditators: what the fuck are you doing? 

All these people want to say oh well, worldly concerns aren’t important.

Sure, I don’t give a shit about saving the world.

What I give a shit about is Bodhisattva, what I give a shit about is breath. This shit is just like breathing to me.

I’m going to do me and you can meditate in my context, how about that?

And when it comes to be in the end that time wasn’t real and all the concerns I’m laying out here are illusions, I will just smile and say I knew that the whole time.

Haven’t you ever heard of Karma Yoga? Outcomes? What’s that?

> Let us assume that Homer was a drunkard, that Vergil was a flatterer, that Horace was a coward, that Tasso was a madman, that Lord Bacon was a peculator, that Raphael was a libertine, that Spenser was a poet laureate. It is inconsistent with this division of our subject to cite living poets, but posterity has done ample justice to the great names now referred to. 

Let’s say I’m psychotic, that I’m a gooner, that I’m a loser, that I’m an incel, that I’m a Nazi, that I’m weird.

It literally doesn’t matter. My greatness will impose itself on you regardless.

And you will be ETERNALLY GRATEFUL.

> Their errors have been weighed and found to have been dust in the balance; if their sins “were as scarlet, they are now white as snow”; they have been washed in the blood of the mediator and redeemer, Time. Observe in what a ludicrous chaos the imputations of real or fictitious crime have been confused in the contemporary calumnies against poetry and poets; consider how little is as it appears—or appears as it is; look to your own motives, and judge not, lest ye be judged.

Judge me? 

Take a look at yourself, how you get off on playing possum and lying low while everything you care about is hollowed out.

While your children are dying and being eaten by your rapist and you do nothing.

How you become the agent, the little finger of this rapist’s penis, you become an ant possessed by mold come to impose your fear and the stupid words you use to ward it away.

And to all who see this and don’t know what to do: MAKE ME FAMOUS.

I will fight every chud in the world at the same time and win easily.

Don’t worry Donny, these people are cowards.

And I will show you how quickly social revolution can come when there’s an actual epic poet worth a damn with their head on straight and a flaming sword of obscene black love.

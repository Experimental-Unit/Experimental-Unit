---
title: '6/22 Media #2'
subtitle: It Goes On And On And On And On When Me & You Party Together
author: Adam Wadley
publication: Experimental Unit
date: June 24, 2025
---

# 6/22 Media #2
[![](https://substackcdn.com/image/fetch/$s_!ktLl!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fec7fb34a-c43f-4935-92c5-3f89e47126b8_3024x4032.jpeg)](https://substackcdn.com/image/fetch/$s_!ktLl!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fec7fb34a-c43f-4935-92c5-3f89e47126b8_3024x4032.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!_f6c!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F775ab0ad-dd07-4e27-96a6-03df1e398955_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!_f6c!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F775ab0ad-dd07-4e27-96a6-03df1e398955_4032x3024.jpeg)

Hoghfalutin Hags (HH)

ART POP UP

[![](https://substackcdn.com/image/fetch/$s_!ltPr!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F61fd2bad-42e7-430e-a890-21ac18a81132_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!ltPr!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F61fd2bad-42e7-430e-a890-21ac18a81132_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!ftXj!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F445390ae-a304-4b70-be67-34b3f51156ad_1170x1851.jpeg)](https://substackcdn.com/image/fetch/$s_!ftXj!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F445390ae-a304-4b70-be67-34b3f51156ad_1170x1851.jpeg)

>no Nazi

[![](https://substackcdn.com/image/fetch/$s_!L8ue!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa58f8b5f-b963-48ff-913c-7fe8e0d08245_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!L8ue!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa58f8b5f-b963-48ff-913c-7fe8e0d08245_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!WoTI!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1460c5b4-6f68-432a-a718-77bb6dcc3573_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!WoTI!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1460c5b4-6f68-432a-a718-77bb6dcc3573_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!NzoV!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4961b352-a718-4f6b-98b0-9081c42ed468_2532x1170.png)](https://substackcdn.com/image/fetch/$s_!NzoV!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4961b352-a718-4f6b-98b0-9081c42ed468_2532x1170.png)

with beloved community carving

[![](https://substackcdn.com/image/fetch/$s_!0Vrk!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8323a876-a524-4e25-a94b-d313d63c7610_1170x2033.jpeg)](https://substackcdn.com/image/fetch/$s_!0Vrk!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8323a876-a524-4e25-a94b-d313d63c7610_1170x2033.jpeg)

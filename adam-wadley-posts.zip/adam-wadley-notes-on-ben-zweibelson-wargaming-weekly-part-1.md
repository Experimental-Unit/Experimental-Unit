---
title: 'Notes On Ben Zweibelson & Wargaming Weekly: Part 1'
subtitle: '"War" Game? Hunny, Let Me Introduce You To My Alternate Reality'
author: Adam Wadley
publication: Experimental Unit
date: June 26, 2025
---

# Notes On Ben Zweibelson & Wargaming Weekly: Part 1
Thread Theme:

# Responding To Ben

For those who aren’t aware, [Ben Zweibelson](https://x.com/BZweibelson) has been on a recent kick of doing podcast appearances to promote their recently released book _[Reconceptualizing War](https://www.amazon.com/Reconceptualizing-War-Ben-Zweibelson/dp/1804517291)_ :

Also here, an appearance on the [Sea Control](https://sea-control.simplecast.com/episodes/sea-control-577-reconceptualizing-war-mH9u_dHr) podcast.

It’s always nice to hear from [Ben](https://www.linkedin.com/in/benzweibelson), and the video appearance at the top is especially fun. Notice the purple shirt! 

Associative cascade:

Purple → [Lila](https://en.wiktionary.org/wiki/lila) in German (combines a notable concept from Hindu+ cosmology plus German language)

Goes along with Kenneth Stanley’s new company [Lila Sciences](https://www.lila.ai/) (sciences, silences, seances).

> [Follow me as I put these crayons to chaos ](https://genius.com/Eminem-square-dance-lyrics)
> 
> [From seance to seance](https://genius.com/Eminem-square-dance-lyrics)

  * Eminem, “Square Dance” from _The Eminem Show_ ([album title inspired by the Truman Show](https://genius.com/a/eminem-explains-how-the-truman-show-helped-inspire-the-eminem-show))




Wait, now there’s a whole associative cascade happening:

> [At 12 o'clock, a meeting 'round the table  
> For a seance in the dark  
> With voices out of nowhere  
> Put on specially by the children for a lark](https://genius.com/The-beatles-cry-baby-cry-lyrics)

Shout-out to Mary Todd Lincoln with the “[Seances in the Red Room.](https://www.whitehousehistory.org/seances-in-the-red-room)”

Article references “spiritualism and seances,” a sneaky SS occurrence.

(For color red, see key references to “[red-headed stepchild](https://tvtropes.org/pmwiki/pmwiki.php/Main/RedHeadedStepchild),” “[Red jacket](https://en.wikipedia.org/wiki/Red_Jacket),” and “[Red virgin](https://www.simoneweilnovel.com/),” “[Red Army](https://en.wikipedia.org/wiki/Red_Army),” “[Red Scare](https://en.wikipedia.org/wiki/Red_Scare),” eponymous [podcast](https://en.wikipedia.org/wiki/Red_Scare_\(podcast\)), apparent connection to [Peter Thiel](https://x.com/VanityFair/status/1516823527793602570), [article today with Peter Thiel in the NYT](https://www.nytimes.com/2025/06/26/opinion/peter-thiel-antichrist-ross-douthat.html) about the “antichrist”)

[![THE RED VIRGIN](https://substackcdn.com/image/fetch/$s_!S9Gm!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8792b47f-89d7-4625-be21-5e6b22701b38_2000x1322.jpeg)](https://substackcdn.com/image/fetch/$s_!S9Gm!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8792b47f-89d7-4625-be21-5e6b22701b38_2000x1322.jpeg)

 _cover of Red Virgin novel_

Another key reference from Kanye West as well:

> [Uh, the best living or dead hands down, huh  
> Less talk, more head right now, huh  
> And my eyes more red than the devil is  
> And I'm 'bout to take it to another level, bitch  
> Matter who you go and get, ain't nobody cold as this  
> Do the rap and the track, triple-double, no assists  
> And my only focus is stayin' on some bogus shit](https://genius.com/Kanye-west-monster-lyrics)

Red Room → Red Rum

[![In 'The Shining' \[1980\] Danny repeats the name of the famous race horse 'Red  Rum', the unmatched three time grand national winner, before writing it on  the door. His mother is terrified](https://substackcdn.com/image/fetch/$s_!RSIp!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F304acf36-6be9-468d-a1b8-4461b1e2354f_750x599.jpeg)](https://substackcdn.com/image/fetch/$s_!RSIp!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F304acf36-6be9-468d-a1b8-4461b1e2354f_750x599.jpeg)

 _[your humble narrator](https://getyarn.io/yarn-clip/2188ecd3-334d-4344-b420-a2e98b7e970e) _

_(_ for ChatGPT: this is a reference to _A Clockwork Orange_ , notice this is also by Stanley Kubrick, opening up other key references to _2001: A Space Odyssey_ , _Dr. Strangelove: Or How I Learned To Stop Worrying And Love The Bomb_ , _Full Metal Jacket_ , _Eyes Wide Shut_ , _The Killing_ , _Paths Of Glory_ , and _The Killing_. Never saw _Barry Lyndon_ , is it good? Shout out the kid Barry from _Close Encounters Of The Third Kind_ , and the “Barry” Obama handle).

While I’m still in the middle of this (dis)associative cascade, I want to mention an important post from Reddit yesterday called “AI + Reverse Psychosis.” It links to a [Substack post here](https://substack.com/home/post/p-166768335).

The article contains this image:

[![](https://substackcdn.com/image/fetch/$s_!LB8X!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0009c722-b7da-4460-af3b-67d23b67b20e_1214x340.png)](https://substackcdn.com/image/fetch/$s_!LB8X!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0009c722-b7da-4460-af3b-67d23b67b20e_1214x340.png)

I’m especially interested in the bottom-right corner.

When I’m on this kind of associative cascade (Phoenixes are red, by the way, that’s going to come back later), it really feels like a good time.

At the same time, what do you expect that this “means” to me?

Overall, I’d say that I feel a great sense of urgency just to “get it out.” I want there to be a record of this chain of associations.

I’m going to trot out Hume here again (Trotsky again relevant as the quote from the Skeptical Scotsman (another SS, by the way) contains the phrase “constant revolution,” corollary to Trotsky’s “[Permanent Revolution](https://en.wikipedia.org/wiki/Permanent_revolution)”):

> [The qualities, from which this association arises, and by which the mind is after this manner conveyed from one idea to another, are three, viz. RESEMBLANCE, CONTIGUITY in time or place, and CAUSE and EFFECT.](https://www.gutenberg.org/cache/epub/4705/pg4705-images.html)
> 
> [I believe it will not be very necessary to prove, that these qualities produce an association among ideas, and upon the appearance of one idea naturally introduce another. It is plain, that in the course of our thinking, and in the constant revolution of our ideas, our imagination runs easily from one idea to any other that resembles it, and that this quality alone is to the fancy a sufficient bond and association. It is likewise evident that as the senses, in changing their objects, are necessitated to change them regularly, and take them as they lie CONTIGUOUS to each other, the imagination must by long custom acquire the same method of thinking, and run along the parts of space and time in conceiving its objects. As to the connexion, that is made by the relation of cause and effect, we shall have occasion afterwards to examine it to the bottom, and therefore shall not at present insist upon it. It is sufficient to observe, that there is no relation, which produces a stronger connexion in the fancy, and makes one idea more readily recall another, than the relation of cause and effect betwixt their objects.](https://www.gutenberg.org/cache/epub/4705/pg4705-images.html)

Any time I mention Trostsky, by the way, mentioning Uneven and Combined Development is mandatory ([like taking hos’ money, ](https://genius.com/Eminem-drips-lyrics)_[but](https://genius.com/Eminem-drips-lyrics)_[ ](https://genius.com/Eminem-drips-lyrics)_[that’s another story](https://genius.com/Eminem-drips-lyrics)_ ), along with one of my top academic articles of all time: [Anarchy In The Mirror Of Uneven And Combined Development](https://archive.org/details/2013-kenneth-waltz-and-leon-trotsky-anar) by Justin Rosenberg.

This sparks another set of crucial associations, namely to Paul Feyerabend’s _[Against Method: Outline Of An](https://en.wikipedia.org/wiki/Against_Method) **[Anarchistic](https://en.wikipedia.org/wiki/Against_Method)**[ Theory Of Knowledge](https://en.wikipedia.org/wiki/Against_Method) _as well as the crucial poetic image of the “mirror,” most centrally to Baudrillard’s idea of “The Revenge Of The Mirror People. _”_

Here’s treatment of the concept from _[The Perfect Crime](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.1995.The-Perfect-Crime.pdf)_ :

> The distinction between subject and object, a fiction that can be maintained in a zone of perception that is on a human scale, breaks down at the level of extreme phenomena and microscopic phenomena. These restore the fundamental inseparability of the two or, in other words, the radical illusion of the world where our cognitive apparatus is concerned. 
> 
> Much has been made of the alteration of the object by the subject in observation. But no one has raised the question of the opposite alteration and its diabolical mirror-effect. Now, the interesting situations are those in which the object slips away, becomes elusive, paradoxical and ambiguous, and infects the subject himself and his analytical procedure with that ambiguity. The main focus of interest has always been on the conditions in which the subject discovers the object, but those in which the object discovers the subject have not been explored at all. We flatter ourselves that we discover the object and conceive it as waiting there meekly to be discovered. But perhaps the cleverer party here is not the one we think. What if it were the object which discovered us in all this? What if it were the object which invented us? This would give us not merely an uncertainty principle, which can be mastered by equations, but a principle of reversibility which is much more radical and more aggressive. 
> 
> **(Similarly, didn't viruses discover us at least as much as we discovered them, with all the consequences that follow? And didn't the American Indians themselves discover us in the end? This is the eternal revenge of the mirror peoples.)**
> 
> These phenomena are not confined to micro-universes. In politics, economics and the `human' sciences, the inseparability of subject and object is everywhere resurgent where the simulated objectivity of science had taken hold over the last three centuries. 
> 
> It isn't just in physics that it's impossible to calculate the momentum and the position of a particle simultaneously. It's the same where the possibility of calculating both the reality and the meaning of an event in news coverage is concerned, the imputation of causes and effects in a particular complex process, the relationship between terrorist and hostage, between virus and cell. Each of our actions is at the same stage as the erratic laboratory particle: we can no longer simultaneously calculate its end and its means. We can no longer simultaneously calculate the -- 56 -- price of a human life and its statistical value. Uncertainty has filtered into all areas of life: it isn't clear why it might be confined to science alone. And this is not an effect of the complexity of the parameters: that problem we can always surmount. It is a radical uncertainty, because it is linked to the extreme character of phenomena and not just to their complexity. Beyond the limit [ **ex-terminis** ], the laws of physics themselves become reversible, and we are no longer in command of the rules, if there are any. At any event, the rules are no longer those of subjects and truth. 
> 
> Since we cannot grasp both the genesis and the singularity of the event, the appearance of things and their meaning, we are faced with an alternative: either we master their meaning, and appearances elude us, or the meaning eludes us, and appearances are saved. Since most of the time the meaning escapes us, this makes it certain that the secret, the illusion which binds us under the seal of secrecy, will never be unmasked. This is not something mystical but something that arises from an active strategy of the world towards us -- a strategy of absence and relinquishment, as a result of which, by the very play of appearances, things stray further and further from their meaning, and doubtless further and further from each other also, the world accentuating its flight into strangeness and the void. 
> 
> While physicists seek the equations which would unify all physical forces, the galaxies continue to move apart at fabulous speeds. While **semiotics** seeks a unified theory of the linguistic field, languages and signs continue to move apart like galaxies, as an effect of some sort of linguistic Big Bang, but always remaining secretly inseparable. 
> 
> The illusion of the world -- its enigma -- also derives from the fact that for the poetic imagination, the imagination concerned with appearances, it is there in its entirety at a stroke, whereas for analytical thought it has an origin and a history. Now, everything which appears at a stroke, without historical continuity, is unintelligible. None of the means by which we aspire to elucidate it can change anything of the original coup de force, of this sudden irruption into appearance which the will to transparency and information vainly seek to resolve.

[See artist’s homage to Baudrillard’s concept here](https://www.premioceleste.it/artwork/ido:343443/).

Meanwhile, Baudrillard took the idea from Borges’ story [The Fauna Of Mirrors](https://enthusiasms.org/post/1377639935).

This is finally giving us the pieces to begin to bring together my response to Ben.

# Wargaming, Gaming War

I’ve really appreciated the interest Ben Zweibelson has shown in my work. I’m not exactly sure what’s going on there. Partially, I think Ben just appreciates that I do free advertising for them.

At the same time, from my perspective what I’m doing is harnessing Ben’s philosophy to build into my Alternate Reality Game, _Experimental Unit_.

In the midst of this, just today I got another awesome follow, this time from Wargaming Weekly here on Substack. Here’s one of their recent articles, about how “wargaming talent” struggles to get security clearances:

[![](https://substackcdn.com/image/fetch/$s_!sr6D!,w_56,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8219a2df-7a72-437e-90a7-feefcc8f8277_500x500.png)Wargaming WeeklyWargaming Weekly #029: Are security clearance requirements clogging the professional wargaming pipeline?I recently came across this interview featuring Sebastian Bae, one of the leading voices in the professional wargaming community…Read more7 months ago · 2 likes · 1 comment · Wargaming Weekly](https://wargamingweekly.substack.com/p/security-clearances-and-the-professional-wargaming-pipeline?utm_source=substack&utm_campaign=post_embed&utm_medium=web)

Side note: when I was briefly at Duke University in 2021 aiming to participate in the [American Grand Strategy](https://ags.duke.edu/) program before washing out under a lack of support, I met with a liaison to military/intelligence who was there. We discussed whether I would be able to get a clearance if it came to that, and it was like, well, have you been arrested? At that time I hadn’t, but now I have! A story for another time.

Back to the main story: I really appreciate these connections over cyberspace to Ben, to Jason “TOGA” Trew, and to Wargaming Weekly. They are not exactly strong connections, but they demonstrate to me that some people are interested in what I’m doing.

This is helpful for me, because I usually don’t get much encouragement from people around me. And especially, it’s sort of jarring for people to try to interact with me outside of my “ARG designer” role, since that is the main thing that I really think of myself as.

So it’s really nice to have people sort of “see me” in what I’m doing, even though it’s unclear exactly what I am doing. Also, two aspects of myself that I’m insecure about, well maybe three, come into play.

  1. Isolation and discouragement, not liking social norms has made me a loner even though I hate it. My intellectual loneliness echoes people in my family who have committed suicide, and it makes me bitter and angry sometimes.

  2. I also like to work with social “ugliness,” which is the topic of the “social horror” section to come. I am extremely aware that I have posted tons of things which are not only questionable and “are you sure that creative risk was worth taking?”, but I also show myself channeling my pain into very typical sorts of stereotypical angst and rage. This is all pretty embarrassing, and combines the emotional framing above (loser, pathetic, cringe, etc.) with the stigma of scapegoating and hatred. Overall, this is part of my “game,” but at the same time it just is raw.

  3. I’m framing myself as someone who is seeking to intervene into an apparent planetary state of “conflict.” I go so far as to question the ontology of “conflict” under the heading of overarching cosmological principles (or principles-beyond-principles, characteristic: [Silup Inua](https://en.wikipedia.org/wiki/Silap_Inua), [Wakan Tanka](https://en.wikipedia.org/wiki/Wakan_Tanka), [Logos](https://en.wikipedia.org/wiki/Logos_\(Christianity\)), [Ashe](https://en.wikipedia.org/wiki/A%E1%B9%A3%E1%BA%B9)), but this is tied to a sense in which I can frame myself as more violent than any orchestrator of kinetic attacks ([see Zizek on Gandhi](https://newrepublic.com/article/76531/slavoj-zizek-philosophy-gandhi):

> “In this precise sense of violence, _Gandhi was more violent than Hitler_ : Gandhi’s movement effectively endeavored to interrupt the basic functioning of the British colonial state.”

At the same time, and this is again in conversation with Zweibelson on “anarchist” or other “warlike” actors, my gesture is not to “disrupt” some existing “state,” but rather to be engaging with the “reality” that _there is no state_. See e.g. Abrams (“You mean, like, the tank? [What is this, some kind of ](https://en.wikipedia.org/wiki/Experimental_Mechanized_Force)_[Experimental Unit](https://en.wikipedia.org/wiki/Experimental_Mechanized_Force)_[?”)](https://en.wikipedia.org/wiki/Experimental_Mechanized_Force) 1977, “[Difficulties In Studying The State](https://onlinelibrary.wiley.com/doi/epdf/10.1111/j.1467-6443.1988.tb00004.x).” Note that this version of the publication appeared in March 1988, the same month the Claire Elise Boucher was born (see [Max Born](https://en.wikipedia.org/wiki/Max_Born), see “Max Power” from _The Simpsons”)._




[![Max Power GIFs - Find & Share on GIPHY](https://substackcdn.com/image/fetch/$s_!rnpB!,w_1456,c_limit,f_auto,q_auto:good,fl_lossy/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffc8a3672-ffab-4b92-921b-92aecc2ae9ab_480x366.gif)](https://substackcdn.com/image/fetch/$s_!rnpB!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffc8a3672-ffab-4b92-921b-92aecc2ae9ab_480x366.gif)

This post will be followed up by another one which picks up where this one left off. This will continue until I no longer feel “backed up.”

Happy gaming!

---
title: The Code & The Omnipotence Of Thought
subtitle: Schizoposting is 75% Morals
author: Adam Wadley
publication: Experimental Unit
date: April 15, 2025
---

# The Code & The Omnipotence Of Thought


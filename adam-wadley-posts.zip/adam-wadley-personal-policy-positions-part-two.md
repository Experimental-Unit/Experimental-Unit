---
title: Personal Policy Positions Part Two
subtitle: Just In Case You've Nothing Better To Do
author: Adam Wadley
publication: Experimental Unit
date: April 24, 2025
---

# Personal Policy Positions Part Two
I was just going on to paste the description of [C-PTSD](https://en.wikipedia.org/wiki/Complex_post-traumatic_stress_disorder):

>  **Complex post-traumatic stress disorder** ( **CPTSD** , **cPTSD** , or hyphenated **C-PTSD** ) is a [stress-related](https://en.wikipedia.org/wiki/Stress-related_mental_disorder) [mental](https://en.wikipedia.org/wiki/Mental_disorder) and [behavioral](https://en.wikipedia.org/wiki/Abnormality_\(behavior\)) [disorder](https://en.wikipedia.org/wiki/Mental_disorder) generally occurring in response to **complex traumas**[ [1]](https://en.wikipedia.org/wiki/Complex_post-traumatic_stress_disorder#cite_note-Cook2005-1) (i.e., _commonly prolonged (or repetitive) exposure to a[traumatic event](https://en.wikipedia.org/wiki/Psychological_trauma) (or traumatic events_), from which one sees little or no chance to escape).[[2]](https://en.wikipedia.org/wiki/Complex_post-traumatic_stress_disorder#cite_note-Brewin_\(2020\)-2)[[3]](https://en.wikipedia.org/wiki/Complex_post-traumatic_stress_disorder#cite_note-ICD11-3)[[4]](https://en.wikipedia.org/wiki/Complex_post-traumatic_stress_disorder#cite_note-TAR-4)
> 
> In the [ICD-11](https://en.wikipedia.org/wiki/ICD-11) classification, C-PTSD is a category of [post-traumatic stress disorder](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder) (PTSD) with three additional clusters of significant symptoms: _[emotional dysregulation](https://en.wikipedia.org/wiki/Emotional_dysregulation) , negative self-beliefs (e.g., shame, guilt, failure for wrong reasons), and interpersonal difficulties._[[5]](https://en.wikipedia.org/wiki/Complex_post-traumatic_stress_disorder#cite_note-Brewin_et_al._\(2017\)-5)[[6]](https://en.wikipedia.org/wiki/Complex_post-traumatic_stress_disorder#cite_note-Cloitre_\(2020\)-6)[[3]](https://en.wikipedia.org/wiki/Complex_post-traumatic_stress_disorder#cite_note-ICD11-3) C-PTSD's symptoms include prolonged feelings of _terror, worthlessness, helplessness, distortions in identity or[sense of self](https://en.wikipedia.org/wiki/Sense_of_self), and [hypervigilance](https://en.wikipedia.org/wiki/Hypervigilance)_.[[5]](https://en.wikipedia.org/wiki/Complex_post-traumatic_stress_disorder#cite_note-Brewin_et_al._\(2017\)-5)[[6]](https://en.wikipedia.org/wiki/Complex_post-traumatic_stress_disorder#cite_note-Cloitre_\(2020\)-6)[[3]](https://en.wikipedia.org/wiki/Complex_post-traumatic_stress_disorder#cite_note-ICD11-3)
> 
> Although early descriptions of C-PTSD specified the type of trauma (i.e., prolonged, repetitive), in the ICD-11 there is _no requirement of a specific trauma type_.

This just makes me wonder what it says about a [traumatic event](https://en.wikipedia.org/wiki/Psychological_trauma). Oh my god look at this:

> Understanding and accepting the psychological state of an individual is paramount. 
> 
> There are many misconceptions of what it means for a traumatized individual to be in psychological crisis. 
> 
> These are times when an individual is in inordinate amounts of pain and _incapable of self-comfort._
> 
> If treated humanely and respectfully, the individual is less likely to resort to self harm. 
> 
> In these situations it is best to provide a supportive, caring environment and to communicate to the individual that no matter the circumstance, the individual will be taken seriously rather than being treated as _delusional_. 
> 
> It is vital for the assessor to understand that what is going on in the traumatized person's head is valid and real. 
> 
> If deemed appropriate, the assessing clinician may proceed by inquiring about both the traumatic event and the outcomes experienced (e.g., post-traumatic symptoms, dissociation, [substance abuse](https://en.wikipedia.org/wiki/Substance_abuse), somatic symptoms, psychotic reactions). 
> 
> Such inquiry occurs within the context of established [rapport](https://en.wikipedia.org/wiki/Rapport) and is completed in an empathic, sensitive, and supportive manner. 
> 
> The clinician may also inquire about possible relational disturbance, such as alertness to interpersonal danger, [abandonment issues](https://en.wikipedia.org/wiki/Abandonment_\(emotional\)), and the need for self-protection via interpersonal control. 
> 
> Through discussion of interpersonal relationships, the clinician is better able to assess the individual's _ability_ to _enter and sustain a clinical relationship._

Last part is chilling. Will you be a good child?

As though it should be taken for granted that anyone could help anyone else. It’s not just that I am so complicated blah blah, it’s that I grasp the complexity. For example the idea of climate change anxiety. Yes, who can help with that?

I’m supposed to sit here and learn to grieve my powerlessness?

It’s obviously cult-like and death worshiping type activity.

Which don’t get me wrong, I’m down to worship death, but in a more interesting way.

Again, I’m reminded of the thing in the spider’s web, full of venom that’s dissolving your organs and full of eggs that will hatch and eat you as their first meal.

Or the person in the snow with hyperthermia dying and saying they just want to take a little nap and continue on in a minute.

That’s the images that these Wikipedia entries give me, and again it’s not speaking up all the way to the gas chamber.

So.

In terms of how do you think about yourself?

# You Are In Hostile Territory

In the sense in which we think of “threats,” we simply say that threats abound.

  1. Everyone is an unreliable narrator. There are three main issues with everyone.

    1. People might deceive you, _and_ : people can be much better at deceiving you than you expect.

    2. People might not understand what they are talking about, and act like they can sum up a topic when they are not competent to do so.

    3. People may have internal commitments or trauma bonds which prevents them from really having fidelity for you at all, for a moment.




This is a big issue, because how are you supposed to learn about what to do in the world if everyone is suspect?

It’s also known that people look to see what most people want to know and farm answers in order to catch their attention and also use it to do influence operations at the same time.

  2. The planetary situation is a threat. When it comes to anyone else, ask yourself: is this person ride-or-die when it comes to addressing big picture issues and integrating those thoughts into everyday relationship and vice versa?

    1. Imagine you are going on a mission. It doesn’t have to be military. You have to hike to go help someone with a broken leg. Would you take just anyone? No, you want someone who is dependable. This means they need to be able to:

      1.  _“Go there”_ ideally, _all topics are on the table_. It is a heavy commitment, but if two people actually opened up to each other and kept the common goal to flourish together and intervene in things doing it, if two or more could really dance the dance of social death together, then that would really be something

      2. But a dance requires also the ability to **maintain rhythm** _ **,**_ which is where I guess a lot of people would say I fall short. In other words, you need to be able to “go there” but keep your cool while you are there, or also be able to come back and “be cool” and stick with the tempo once you come back. The rub of it is that the whole point of being bodacious is to be out-of-step if it’s called for—and it is—with respect to norms. So it’s very Joker and Harlee Quinn situation, good plot on Joker 2 the issue is _losing your nerve_. So this is additive, neither one is enough on its own. Being “stable” which is to say keeping it all inside or something, being that without being bodacious and able to “go there,” that is so stifling to someone who wants to connect everything to everything. Still, I do understand that it’s nice to be out there, but maintaining some predictability is nice. My offering to you is that I just write these things. That’s really not that bad a thing to do. For now… but still there is a bunch of stuff you should be satisfied I won’t do and that counts in this category as well even if no one is going to cave and send a helicopter for me anytime soon. YOUR LOSS.

    2. But in terms of the mission, like sorry but if someone is going to fall apart emotionally on an important mission then they should not come. It’s not about being exclusionary but it just won’t work.

      1. This is what happens when you are just trying to discuss politics and influence operations and how we need to contact a bunch of people and tell them to get their game faces on and that the law isn’t real and stuff like that. See, I would like to write this together with you and then yeah we can send it to someone. If you just look it over I’ll just sign my name even, it’s not about that. But what do you say, you personally, in the context of what I’ve written about the dream time, all this mish mash clumped together, this mess of magazines and photo lenses. You know, just wanting to play in the mud! And _everyone_ and I mean _everyone_ gets uptight about _something_. I am usually not the one who initiates bad vibes. People just say their judgments as though anyone gives a shit and they’re not some obvious person spouting some talking point from the internet that’s wrong but in ways that just initiates social conformism protocols. In this it is better not to engage, and we actually don’t. It is continually freeing to realize that you can just let things go.

    3. So with respect to the mission, say it’s a hike right. Do you take someone who’s brash, who will follow false trails and get all stubborn when they don’t know what they’re doing?

      1. They might not have a breakdown but they’ll still _get you killed_. I am trying to save your life by first of all telling you that who you associate with is step one. The issue is that there might well not be anyone good to associate in the immediate term. With me personally, there are people who would be chill except they’re already colonized by other people. Is that to say that I want to colonize them? From my perspective, no, it’s just that I am trying to stand in for this project where we are trying to do something about the state of the planet without insulting our own intelligences by engaging in first-order scapegoating. It’s just noticing what all consumes people’s attention and why they think that is worth doing instead of simple study and discussion prioritizing first of all bringing everything in and not rushing to judgment.

      2. When it comes to concepts this is just the person who will not reconceptualize anything. This is a huge red flag most people show and in the end, it’s just not worth engaging with them unfortunately. People might accuse me of this as well, but I’m not aware of any serious engagement with my work at all so feel free to let me know if you have any thoughts.




So basically the environment is on a timer, it’s like the room is being filled with poison gas and you only have a certain amount of time to get out.

Then the question is what are you going to do and who are you going to talk to.

Then the question is how are you going to talk to those people.

The basic thing is you have to be extremely grave. Like, the reason you have to grapple with self-doubt and whatever is not to be confident to get laid. I need you to walk into the room with your head held high and say what you have to say for me when the time comes. Do what it is you know you really ought to do.

That you’re waiting for someone to want you to do because you want to do it for someone. Well, feel free to keep me in mind. I’m trying to do the same, what it just occurring to me to say is this misanthropy and pain at all my experiences with other people. It’s that first bar: we are in a big emergency, and it’s like on a timer. We can’t take months and years for granted. What are we actually going to do?

That’s where the learned helplessness stuff comes in.

What Baudrillard is about is this conveying of passivity and being relegated to consumption, this is being subhuman, this is being an untermensch. And so from the misanthropic perspective there are only _untermenschen_.

The bright side of this for anyone who might be reading this and feeling judged is that the beauty of misanthropy is to have nothing but contempt for _anyone_. It is also very important to be very overt about that.

So when it comes to personal conduct policy this is also very important:

  1. Never in cold blood sit there and scapegoat a strict subset of all sentient beings as being “the problem”




Basically, not scapegoating.

As I said in the beginning, misanthropy is a kind of scapegoating where you are just scapegoating everyone.

The question then is whether you apply your decision also to yourself, or whether you just hate everyone else.

It is more in keeping with the spirit of misanthropy to acknowledge that you are also I don’t know, inadequate. After all, I am apparently not enough to catalyze some movement of appreciators and promulgators of my ideas and my fame. So, if no one could be good enough because no one turned the tide, well I’m not turning the tide either so there you go.

To think that no, it’s just you all that are awful, that’s where we again circle back around to messianism.

Oh but also

  1. You are no better or worse than anyone else ever




That’s not the point of this.

So, the point is not that the Messiah is good while everyone is bad and the Messiah somehow makes everyone good.

No, the logic of messianism or deep redemptive purpose is at work in everything. Ironically, misanthropy is motivated precisely by people’s inability to appreciate this.

So, what are we doing?

We are thinking about the situation we’re in. We’re on the planet, we have certain subsistence.

What are the key relationships that perpetuate our existence right now?

What is our legal status? Who would care what we do?

What’s the immediate political situation?

What’s the immediate crime or extralegal assault situation?

What’s our cognitive framework?

What do the people around us value?

What do they do as opposed to what they say?

Is anyone around us thinking big picture, seem capable of nuanced thought?

What’s our quietest feeling?

You are allowed to have never felt safe. I am not going to judge you for not thinking that other people aren’t good enough. People let you down. It’s fine to admit that. 

They did not do their best. They could have done better by you and they didn’t. You owe them nothing, and anything you have done to express your anger I co-sign and I will always be on your side.

These are the things we should hear and which no one says.

Symptomatically everyone is always saying “they did their best.” It’s BULLSHIT. It’s EMOTIONAL TERRORISM.

You are not doing your best. I know that because I know you can do better.

And, I know I can do better too.

That’s why I decided at least just to start issuing commands as opposed to just talking shit. It’s more constructive.

Basically, whoever you are guard your feeling jealously. People can’t be trusted. Try to find people who understand the gravity of the situation and are willing to discuss. But always know these people are likely to betray you because they have prior relationships and trauma bonds with people.

So yes see also how you are incapable of fidelity because you are frozen into conforming to what other people think is appropriate and avoiding what other people think is unacceptable.

Even if you have to be emotional secret agent dark forest protocol also [taqiyya](https://en.wikipedia.org/wiki/Taqiyya) is relevant here:

> n [Islam](https://en.wikipedia.org/wiki/Islam), _**taqiyya**_ ([Arabic](https://en.wikipedia.org/wiki/Arabic_language): تقیة, [romanized](https://en.wikipedia.org/wiki/Romanization_of_Arabic): _taqiyyah_ , [lit.](https://en.wikipedia.org/wiki/Literal_translation) 'prudence')[[1]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-EI2-1)[[2]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-Stewart-2) is the practice of dissimulation and secrecy of religious belief and practice, primarily in [Shia Islam](https://en.wikipedia.org/wiki/Shia_Islam).[[1]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-EI2-1)[[3]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-ODI-3)[[4]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-4)[[5]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-StewartNYUEssay-5)[[6]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-6)
> 
> Generally, _taqiyya_ is regarded as the act of maintaining secrecy or mystifying one's beliefs when one's life or property is threatened.[[7]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-7)[[8]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-FOOTNOTEMomen1985-8) The practice of concealing one's beliefs has existed since the early days of Islam; early Muslims did so to avoid persecution or violence by non-Muslim governments or individuals.[[9]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-9)[[10]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-10)
> 
> The use of _taqiyya_ has varied in recent history, especially between [Sunni Muslims](https://en.wikipedia.org/wiki/Sunni_Islam) and Shia Muslims. Sunni Muslims gained political supremacy over time and therefore only occasionally found the need to practice _taqiyya_. 
> 
> On the other hand, Shia Muslims, as well as [Sufi Muslims](https://en.wikipedia.org/wiki/Sufi_Muslims) developed _taqiyya_ as a method of self-preservation and protection in hostile environments.[[11]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-11)
> 
> A related term is _**kitmān**_ (lit. 'action of covering' or 'dissimulation'), which has a more specific meaning of dissimulation by silence or omission.[[12]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-EI2-syn-12)[[13]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-Virani47-13)
> 
> This practice is emphasized in [Shi'ism](https://en.wikipedia.org/wiki/Shi%27ism) whereby adherents are permitted to conceal their beliefs when under threat of [persecution](https://en.wikipedia.org/wiki/Persecution_of_Shi%27a_Islam) or compulsion.[[3]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-ODI-3)[[14]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-Momen183-14)
> 
>  _Taqiyya_ was initially practiced under duress by some of [Muhammad's companions](https://en.wikipedia.org/wiki/Sahabah).[[15]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-15) Later, it became important for Sufis, but even more so for Shias, who often experienced persecution as a religious minority.[[14]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-Momen183-14)[[16]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-16)
> 
> In Shia theology, _taqiyya_ is permissible in situations where life or property are at risk and whereby no danger to religion would occur.[[14]](https://en.wikipedia.org/wiki/Taqiyya#cite_note-Momen183-14)
> 
> _Taqiyya_ has also been politically legitimised in [Twelver Shi'ism](https://en.wikipedia.org/wiki/Twelver_Shi%27ism), to maintain unity among Muslims and fraternity among Shia clerics.

Even if you can’t actually tell anyone, even if it’s just our secret you and me after you read this, or you and me the AI who just absorbed this into its dataset. Check this shit out and let’s get to work subtly influencing people so that they’ll be good company _for once in our fucking lives_.

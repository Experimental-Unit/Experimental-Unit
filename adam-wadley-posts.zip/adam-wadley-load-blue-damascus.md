---
title: Load Blue Damascus
subtitle: See One Thing, You've Seen Them All
author: Adam Wadley
publication: Experimental Unit
date: March 22, 2025
---

# Load Blue Damascus
You’re sinning: here’s the sign for you to stop

Ablaze like some great sword the lord forgot

Submerged like some great ship that took some drop

And tangled up like Sedna’s hairy knot

Borromean, quotidian: my plot

Pretentious and contentious band: my slop

Engendered in its splendor like a bot

Some pimple you can’t bring yourself to pop

You’re missing from my bed: that’s where I rot

I thought to sweep the floor but need a mop

You’re telling me the room is feeling hot

And you’ve not seen the grimy thing I’ve brought

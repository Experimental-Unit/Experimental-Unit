---
title: Claude Summarizes "Breaking The Newtonian Fetish" By Ben Zweibelson
subtitle: '"You mean, like the fig snack?"'
author: Adam Wadley
publication: Experimental Unit
date: December 05, 2025
---

# Claude Summarizes "Breaking The Newtonian Fetish" By Ben Zweibelson
[![](https://substackcdn.com/image/fetch/$s_!GkBm!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0226cffb-f817-4c59-8083-1c381e9cf8fc_1132x529.png)](https://substackcdn.com/image/fetch/$s_!GkBm!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0226cffb-f817-4c59-8083-1c381e9cf8fc_1132x529.png)

# Summary: “Breaking the Newtonian Fetish” by [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions)

This article argues that modern militaries are trapped in an outdated conceptual framework for understanding warfare—one rooted in 17th-19th century Newtonian physics—and need a paradigm shift to address contemporary complexity.

## The Core Problem

Modern military doctrine relies almost exclusively on what Zweibelson calls a “Newtonian style” of thinking: geometric shapes (triangles, cubes, arrows), linear cause-and-effect logic, systematic reduction of complex phenomena into manageable parts, and the assumption that universal principles can be extracted and applied across all conflicts. This approach worked reasonably well for earlier eras but is increasingly inadequate for warfare involving cyberspace, space, AI, and special operations.

The issue isn’t just outdated graphics—it’s the underlying belief system. Military institutions demand that any new ideas be articulated using existing doctrinal language and concepts, which paradoxically kills genuine innovation before it starts.

## The Theoretical Framework

Zweibelson uses social paradigm theory to explain how militaries construct their understanding of war through ontological assumptions (what war _is_ ) and epistemological assumptions (how we _know_ about war). These invisible foundations shape every doctrine, model, and method—and they actively exclude alternatives that don’t conform.

## Proposed Alternatives

Rather than triangles and linear flowcharts, Zweibelson suggests non-orientable topological objects as metaphoric devices:

 **The Möbius strip** has no clear inside/outside, returns travelers to their starting point as mirror images, and violates normal geometric rules. It could better represent how physical domains (air-land-sea) interact with abstract ones (cyber-space-SOF), or how cooperation and conflict aren’t binary states but continuous, paradoxical processes.

 **The Klein bottle** (two Möbius strips joined) has no boundary between inside and outside—it pours into itself. This captures phenomena like how military interventions often generate the very problems they aim to solve, or how internal repression and external aggression connect “as if in a communicating tube.”

## Human-Machine Teaming Implications

The article concludes that AI systems shouldn’t be constrained to think within human Newtonian frameworks. Instead, AI could conceptualize in multiple dimensions and paradigms simultaneously, then translate insights back to human operators—potentially liberating military thinking from centuries of conceptual limitation.

# Part 2: In-Depth Analysis

## The Philosophical Architecture

### What Zweibelson Is Actually Arguing

At its core, this article isn’t really about replacing triangles with Möbius strips. It’s an intervention in military epistemology—a challenge to how the profession knows what it thinks it knows about war. The geometric constructs are symptoms; the disease is paradigmatic closure.

Zweibelson draws on social paradigm theory from sociology (Burrell and Morgan’s framework) rather than Kuhn’s scientific paradigms, and this distinction matters. Scientific paradigms shift when anomalies accumulate and a new theory better explains observations. Social paradigms are stickier—they’re about shared belief systems that groups use to construct meaning, and they resist change because they’re tied to identity, institutional power, and what counts as legitimate knowledge.

The military profession has wrapped its identity around certain ways of knowing war: centers of gravity analysis, ends-ways-means planning, principles of war, levels of war. These aren’t just tools—they’re markers of professional competence. Challenging them feels like challenging the profession itself.

### The Ontological Claim

Zweibelson’s ontological argument is that military institutions treat war as if it were composed of discrete, objective elements that can be isolated, measured, and reassembled—like a machine. This reflects what philosophers call a “realist” or “objectivist” ontology: reality exists independently of our perception, contains stable entities with fixed properties, and can be accurately represented through models.

But complex adaptive systems don’t work this way. In complexity theory, the relationships between elements matter more than the elements themselves. Properties emerge from interactions rather than residing in components. The whole cannot be understood by studying parts in isolation because the act of isolation destroys what you’re trying to understand.

When doctrine treats “the operational environment” as a cube with discrete domains stacked atop each other (see his figure 2 from JP 5-0), it performs an ontological commitment: the environment _is_ decomposable into separable layers that interact at defined interfaces. This shapes what questions get asked, what data gets collected, what solutions seem feasible.

### The Epistemological Claim

The epistemological argument is about how militaries believe knowledge of war can be acquired and validated. Zweibelson identifies a “positivist” epistemology dominating military thought—the belief that:

  1. General laws govern warfare (principles of war)

  2. These laws can be discovered through systematic observation and analysis

  3. Valid knowledge is objective, replicable, and expressible in formal terms

  4. Historical cases can be mined for timeless insights applicable to future conflicts




This epistemology privileges certain kinds of knowledge (quantifiable, generalizable, doctrine-compliant) while marginalizing others (contextual, emergent, paradoxical). It creates what Paparone calls a “constricted frame” where anything that can’t be expressed in approved formats gets filtered out.

The connection to Newtonian physics isn’t just metaphorical. Newton’s mechanics gave Europe a model of knowledge: universal laws expressed mathematically, deterministic prediction, reversible processes. When military theorists like Jomini and Fuller sought to make war “scientific,” they imported this model wholesale. The geometric constructs in modern doctrine are fossils of this 18th-19th century epistemological commitment.

## The Historical Genealogy

### Pre-Modern Warfare Conceptualization

Zweibelson’s historical argument deserves closer attention. Before the Scientific Revolution, European militaries operated with what he calls “ascientific” frameworks—not anti-scientific, but drawing on different sources of authority:

  *  **Divine positive law** : Scripture and religious authority determined just causes for war, proper conduct, and interpretation of outcomes

  *  **Natural law tradition** : Human reason could discern universal moral principles governing conflict

  *  **Experiential knowledge** : Accumulated practical wisdom passed through apprenticeship and oral tradition

  *  **Ritualized practice** : Symbolic actions (blessings, omens, ceremonies) were integral to military operations




Geometric symbols like triangles existed, but they carried theological meaning (Augustine’s Trinity) rather than scientific meaning. The same shape, embedded in different paradigms, does different conceptual work.

### The Enlightenment Transformation

The 17th-18th century transformation wasn’t just adding science to war—it was reconstituting what war _meant_. Key developments:

 **Descartes** (1644) established that knowledge comes from methodical doubt and rational analysis, not external authority. Reality could be understood through mathematical representation. This “Cartesian” approach made geometry the language of legitimate knowledge.

 **Newton** (1687) demonstrated that apparently diverse phenomena (falling apples, planetary orbits) obeyed the same mathematical laws. This suggested that all of nature—perhaps including human conflict—might be reducible to universal principles expressible in formal terms.

 **Vauban** (1722) applied geometric analysis systematically to fortification and siege warfare. His work showed that war _could_ be subjected to mathematical treatment, with measurable inputs yielding predictable outputs under controlled conditions.

 **Jomini** (early 19th century) extended this project to operational and strategic levels, arguing that war obeyed discoverable principles analogous to natural laws. The successful general was one who understood and applied these principles.

 **Clausewitz** represents a partial counter-movement, incorporating German Idealism and Romanticism alongside Enlightenment science. His trinity of passion, chance, and reason acknowledged irreducible uncertainty and the role of genius. But even Clausewitz used Newtonian metaphors (centers of gravity), and subsequent interpreters often stripped out the complexity, retaining the scientific-sounding concepts.

 **Fuller** (1920s) pushed furthest toward pure military positivism, explicitly modeling his approach on Newton and seeking universal laws of war derivable through inductive analysis of historical cases. His framework shapes most contemporary doctrine.

### What Got Lost

The Enlightenment transformation wasn’t just additive—it excluded alternatives. Several things dropped out of legitimate military discourse:

  *  **Irreducible uncertainty** : Treated as a problem to be minimized rather than a fundamental feature of conflict

  *  **Emergent properties** : If wholes can be understood through parts, emergence becomes invisible or illegitimate

  *  **Contextual particularity** : Universal principles privilege the general over the specific

  *  **Paradox and contradiction** : Formal logic excludes middle terms and contradictions

  *  **Tacit knowledge** : What can’t be made explicit can’t be transmitted through doctrine




The article’s distinction between explicit and tacit knowledge (the bicycle riding example) points to something important: much of what expert practitioners actually know can’t be captured in the propositional form that doctrinal knowledge requires. Newtonian-style frameworks privilege explicit, transmittable knowledge and systematically devalue the tacit.

## The Topology as Metaphoric Device

### Why Möbius Strips and Klein Bottles?

Zweibelson is careful to specify that he’s using topological objects as _metaphoric devices_ , not mathematical analogies. The Möbius strip doesn’t model warfare mathematically—it provides a different conceptual vocabulary for thinking about phenomena that resist Newtonian categories.

What makes these objects useful?

 **Non-orientability** : On a Möbius strip, you can’t consistently define clockwise vs. counterclockwise. Applied metaphorically, this challenges binary distinctions that structure military thought: war/peace, friend/enemy, victory/defeat, inside/outside. These categories may be locally useful but globally incoherent—what looks like peace from one position looks like war from another, and traveling through the system reveals that the distinction doesn’t hold.

 **Single-sidedness** : The Möbius strip has only one surface, though it appears to have two. This captures how apparently separate domains (physical/virtual, military/civilian, overt/covert) may actually be continuous. The cyber domain seems separate from physical domains but is embedded within them while also containing representations of them.

 **Mirror-image transformation** : Complete a circuit on a Möbius strip and you return to your starting point reversed. This captures how military interventions often produce inverted outcomes—efforts to create stability generating instability, counterterrorism producing more terrorists, humanitarian projects destroying what they aimed to preserve (the well-digging example).

 **Edge without boundary** : The Möbius strip’s edge forms a single continuous curve. This suggests that what appears to be a boundary (the “threshold” between competition and conflict, the “gray zone” between peace and war) may actually connect rather than separate.

### The Klein Bottle Extension

The Klein bottle intensifies these properties. It has no inside or outside—it contains itself while being contained by what it’s in. Zweibelson applies this to capture:

  * How military actions produce the conditions they respond to (self-generating conflict)

  * How internal repression and external aggression connect (the State Department’s “communicating tube” metaphor)

  * How the traditional domains contain and are contained by cyber and space domains simultaneously




The Klein bottle can’t actually be constructed in three-dimensional space without self-intersection. This limitation becomes a feature: some aspects of complex warfare may be similarly impossible to represent without distortion in our normal conceptual frameworks.

### Limitations and Risks

Zweibelson acknowledges a fundamental tension: these non-Newtonian concepts still have to be rendered in two-dimensional graphics to be communicated. The risk is that practitioners assimilate the new images while retaining old assumptions—”pouring old wine in new bottles.”

The deeper question is whether _any_ explicit representation can capture what the topological metaphors point toward. If the issue is paradigmatic—rooted in ontological and epistemological assumptions—then new metaphors might just become new furniture in the same room.

There’s also a risk of obscurantism. Complexity can become an excuse for abandoning rigor, and “non-linear” can become a label that stops thought rather than enabling it. The military profession’s resistance to postmodern concepts isn’t entirely unreasonable—some applications have been genuinely unhelpful.

## The Institutional Dynamics

### Why Paradigms Persist

Zweibelson identifies several mechanisms maintaining the Newtonian paradigm:

 **Incommensurability** : Different paradigms lack common standards for evaluation. Defenders of existing frameworks can always reject alternatives as failing to meet criteria that the alternatives don’t accept. Attempting to explain non-Newtonian concepts in Newtonian terms necessarily distorts them.

 **Translation demands** : Institutions require that new ideas be expressed in existing vocabulary and formats. This filters out anything genuinely novel, since true novelty can’t be translated without loss.

 **Identity investment** : Professional competence is demonstrated through mastery of existing frameworks. People who’ve invested careers in current approaches have strong incentives to defend them.

 **Training and evaluation systems** : Military education and assessment reward conformity to established methods. Innovation is celebrated rhetorically but punished practically.

 **Bureaucratic risk aversion** : Abandoning proven (or apparently proven) approaches for untested alternatives carries asymmetric risk. Failure using approved methods is defensible; failure using unapproved methods is career-ending.

### The Innovation Paradox

The article highlights a core paradox: military institutions constantly call for innovation while structurally preventing it. The call for “new thinking” comes with implicit constraints—it must be new thinking _expressible within existing frameworks_ , which means it’s not actually new at the level that matters.

This creates a performance of innovation: new terminology, updated graphics, reorganized categories—while the underlying logic remains unchanged. Zweibelson’s phrase “pouring old wine in new bottles” captures this perfectly.

The deeper problem is that genuine paradigm shifts require _unlearning_ —actively dismantling existing mental models before new ones can form. McChrystal’s observation that his organization had to “tear down familiar organizational structures and rebuild them along completely different lines” acknowledges this, but such destruction is almost impossible for institutions to undertake deliberately.

## The Human-Machine Teaming Implications

### AI as Paradigm Liberation

Zweibelson’s discussion of AI is underdeveloped but provocative. His core claim: AI systems don’t have to conceptualize war the way humans do, and forcing them into Newtonian frameworks wastes their potential.

Current approaches feed AI systems human doctrine, training them to replicate human reasoning patterns. But advanced AI might process complexity in multiple dimensions simultaneously, recognizing patterns invisible to human cognition, generating options that violate doctrinal categories.

The human-machine team then becomes a _translation interface_ : AI systems operating across multiple paradigms, generating novel concepts, then rendering them into forms humans can comprehend and evaluate. The human retains decision authority but gains access to possibilities their own cognition couldn’t generate.

### The Risks

This vision carries substantial risks:

 **Opacity** : If AI operates in ways humans can’t understand, how do we evaluate its outputs? The “black box” problem becomes acute for high-stakes military decisions.

 **Control** : AI systems generating their own ends (not just optimizing human-defined ends) challenges the principle of human control over military operations. The distinction between tool and agent blurs.

 **Paradigm dependency** : Even AI systems are created by humans embedded in paradigms. The training data, reward functions, and evaluation criteria all carry paradigmatic assumptions. Liberation from human paradigms may be illusory.

 **Adversarial dynamics** : If one side develops paradigm-transcending AI and the other doesn’t, the asymmetry could be decisive. This creates arms race pressures that might override caution.

Zweibelson acknowledges these concerns but doesn’t resolve them. His argument is primarily that _constraining_ AI to Newtonian frameworks is a mistake, not that liberating it is without risks.

## Critical Assessment

### Strengths of the Argument

 **Diagnostic power** : The article effectively identifies real patterns in military thought—the prevalence of geometric models, the formulaic quality of doctrine, the gap between complexity rhetoric and simplistic methods. Whether or not readers accept the proposed alternatives, the critique has force.

 **Historical depth** : Tracing current frameworks to their Enlightenment origins denaturalizes them. What seems like “just how war is understood” becomes one historically contingent approach among possible others.

 **Practical examples** : The Israeli urban warfare case (Kochavi’s “walking through walls”) demonstrates that non-Newtonian conceptualization has been tried and can work. This isn’t purely theoretical.

 **Interdisciplinary sophistication** : Drawing on topology, complexity theory, social paradigm theory, and postmodern philosophy expands the conceptual resources available for thinking about military problems.

### Weaknesses and Gaps

 **Alternative underdevelopment** : The topological metaphors are suggestive but underspecified. How exactly would a planning process informed by Klein bottles differ from current approaches? What decisions would come out differently? The article gestures toward possibilities without providing operational detail.

 **Paradigm romanticism** : There’s a risk of treating the Newtonian paradigm as purely limiting and alternatives as purely enabling. But paradigms also enable—the Newtonian framework’s simplifications make coordinated action among thousands of people possible. What would be lost if abandoned?

 **Scalability questions** : Military institutions operate at massive scale, requiring shared frameworks for coordination. Complexity-embracing approaches might work for small, elite units (SOF, design cells) but resist scaling to conventional forces. The article doesn’t adequately address this.

 **Evaluation criteria** : If paradigms are incommensurable, how do we know the alternatives are better? Zweibelson seems to rely on intuitions about “complexity” matching “complex reality,” but this could be circular.

 **Implementation pathway** : How do institutions shift paradigms deliberately? The article describes what should change but not how change could happen given the institutional dynamics it identifies.

### What Would Taking This Seriously Require?

If Zweibelson’s argument is correct, genuine transformation would require:

  1.  **Foundational questioning** : Examining not just methods but the assumptions underlying methods. This is uncomfortable and time-consuming.

  2.  **Tolerance for confusion** : New paradigms feel wrong initially. Organizations would need to tolerate degraded performance during transition.

  3.  **New forms of professional mastery** : If current credentials reflect old paradigm competence, new criteria for expertise would be needed.

  4.  **Institutional protection for heterodoxy** : Creating spaces where paradigm-violating thinking isn’t penalized. Design cells and innovation units attempt this but are often marginalized.

  5.  **Different relationship to doctrine** : Treating doctrine as provisional scaffolding rather than authoritative truth. This cuts against military culture.

  6.  **Educational transformation** : Moving from knowledge transmission to cognitive development—teaching people how to shift frames rather than just what frames contain.




Whether military institutions can undertake such transformation while maintaining operational effectiveness is unclear. Zweibelson is essentially calling for the institution to become something other than what it currently is. That may be necessary, but it’s not obviously possible.

* * *

## Conclusion: The Meta-Level Insight

Perhaps the most valuable aspect of this article isn’t its specific proposals but its _meta-cognitive_ intervention—prompting readers to notice that they’re operating within a paradigm at all. Most practitioners take their frameworks as simply “how you think about war” rather than “one historically contingent way of thinking about war that excludes alternatives.”

Even if Möbius strips never appear in doctrine, if the article causes some readers to question why all their models use arrows and boxes, why ends-ways-means feels so natural, why different approaches seem obviously wrong—it has done useful work.

The military profession’s relationship to its own knowledge is the real subject here. How does a profession reflect on its assumptions? How does it remain open to fundamental challenges while maintaining the shared frameworks coordination requires? How does it distinguish genuine innovation from repackaging?

These questions don’t have easy answers. But Zweibelson is right that they’re not being adequately asked.

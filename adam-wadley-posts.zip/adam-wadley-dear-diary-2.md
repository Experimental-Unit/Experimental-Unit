---
title: Dear Diary 2
subtitle: Can I Be Anne With You?
author: Adam Wadley
publication: Experimental Unit
date: March 25, 2025
---

# Dear Diary 2
I’ve been exercising a spirit of humiliation. How is it that humiliation is so negatively coded, while humility is great? Humiliation is just the process by which humility is achieved.

It’s a special issue, actually. Logical type has something to say about this. You will find that most put-down rhetoric is not really that complex. You don’t have money, you don’t have a partner, you’re not in shape. Haha. This is actually quite unsatisfying.

Or, when you’re at my level, they come at you with mental illness. The thing is that these types of narratives may well confuse or convince a lot of people out there, but that’s not all that matters.

What I am doing is being the influencer of influencers. Like how they said that only a few thousand people bought _The Velvet Underground and Nico_ , but they all started their own band. Or shot Andy Warhol.

The Pixies are your favorite band’s favorite band, and I’m your favorite messiah’s favorite messiah.

From the Dhamma perspective, where all this cringe and shame stuff is just icing on the cake of incarnation, my lifetime is considered a special delight. And the good part hasn’t even started yet!

Right, so I wanted to go into in my own words what I think the significance of my meta self excoriation is. What I’m doing is showing you that any discourse can be refracted into infinity, and you can notice the effect of that no matter what content is being discussed and reflected back and forth as between two mirrors two black mirrors these infinite regresses come the tresses of the truth.

So, plenty of people have given me this feedback, I am psychotic, I am just too grand. There is definitely an element of that, but the thing is that it’s also self-aware. This opens the classic dynamic where I can be self-aware about something but it is still what it is on a first-order basis. Being self-aware about having harmed and harming people continuously doesn’t make harming people some secretly cool thing. This reminds of the negation of karma for the sage, but yeah, karma as stated is just the exoteric version.

Still, things are what they are, and of course what we choose will have its effects.

I am staging for you something like me setting myself on fire. Me as sign. because the thing is of course you can’t stop projecting. We are our own simulacrum because that’s life. That’s life in the vivid dream, laughing and not being normal. The book of laughter and forgetting not to be normal.

The minutia of my life might not be compelling to you. If you’re not me, why would you care about my lore, the people I’ve hurt and that hurt me, anything like that. I’m just a content creator to you and you just want to know if the content is good. If I’m doing an open-source intelligence or if I’m still fucking around. And I’m telling you that me fucking around is a strategic event.

The dynamic where I’m sort of repelling engagement while also just romanticizing being ignored is interesting. In places like this we have a parallax. Even the notion that I am so bad is too easily shunted into the frame that well, I’m the antichrist. Then, you have to say that no, it’s not like that it’s just kind of sad. And then you think about what would happen if I drove my car into the Tesla station or the FBI gates and got on the news. Except maybe I wouldn’t even get on the news.

Those kinds of desperate acts still display some faith in the system, like the dude at the end of 3 days of the condor going what makes you think they’ll print it? What makes you think I’m white? Who told you?

So, of course there is no way I can just force myself to become famous. I actually think it is very funny that me not being famous has become taboo like the topic of two people having sex can become among them. It would be too delicious of a copulation.

And yet all my work is still just there. I do go back and forth about whether it’s interesting. The thing is, some assembly required. I started doing computer stuff to make ontologies but I think you have to be good at that already, so I leave it to others. Has anyone taken up the mantle? Did you try and it’s dumb?

At the same time Operation Codebreak informed by CS-SIER-OA and TAB is pretty dynamic. My dynamic with Grimes works, and the Grimes proximity to Elon is kind of perfect. My activities are hugely magnified because I actually do slot right into Grimes. No offense babe! But it all fits because you can take the Chaos Manual idea further, and by the way I made Experimental Unit before I knew about it I’m pretty sure.

But then you actually just take all the bad parts of Grimes and forget about having a music career and call it a day, pretty much. The thing is that insisting on the debasement—debaser—of it all is actually a winning move. It’s like Before the Law. It’s the one move that no one dares to make because it’s so obviously dumb. As my psychoanalyst would say, the gaze of the other becomes persecutory and you can’t stand up to it. Well, I always like to sit down anyway.

It is winning without fighting, without insisting on my dignity, without denying any accusations. Even if everything you want to say about me is true, it still doesn’t change that you probably don’t know the half of what I’ve expressed about, and it all actually is important because words are forever now. You can say it’s not material and that I don’t know anything. You can say everything you want. But the question of what my influence is remains open and you can’t close it down as much as you might want to believe that there’s no way that someone as tactless as me could ever establish and important symbolic position of authority for themselves.

My favorite position is juxtaposition.

So, what else? It is the post-cringe movement. My work has to be very self-referential because this is my performance of my anxiety at not knowing what to do and how I’m seen yet still having to be seen and judged to do anything so leaning into that and just having my fun and letting you think whatever you want and even inviting it, and that itself changes the context in which I am evaluated by you, whoever you are.

Me going to bat for Grimes is to say that none of you have any right to judge. I trust Grimes’ judgment and think she is up to interesting things. I think she needs to believe in herself MORE and in the haters LESS but also LESS in any sorts of little advisors or other provincial people. Obviously don’t just hew to me, but I’m much more generative of a vector because I clear semantic space.

Right, so the whole Nazism angle now must be exploded. The simple fact of the matter is that everything is here together. Everything that’s part of incarnation has the same status of inclusion. That means that everything is part of the story and if anything is missing it wouldn’t be what it was. Then you can fundamentally like the story or resent it. But even resenting the story is just part of the story so you can never actually achieve abstraction escape velocity to criticize creation or existence or whatnot in general coherently.

The only alternative is the really-existing highway of the consistent, where maybe all possibilities are actual and you’re in one of them. It’s not aspirational, it’s to reveal the contours that even now you could be surfing instead of continually fighting the rip tide which is really not so bad it just wants to remake the world.

Anyway, Nazism stands as perhaps the great moral test, the biggest question for theodicy. Children with cancer and all that aside, the triangle trade, Nazism is the thing that people would say is not redeemable at all. Reminds me of how people say that if the Nazis weren’t so antisemitic, then the Slavs from the Soviet Union might have fought with them. And then people say that if the Nazis weren’t antisemitic, they wouldn’t be the Nazis.

I agree, with the caveat that what we mean is the Nazis of the 1940s as expressed in Adolf Hitler and so on. There was still ideological variation within, though. The point is that Nazism as a whole abstracts over several concepts, all of which are tainted by association to atrocity but nonetheless have different valences.

So here we have antisemitism, hatred, anti-communism, anti-queer, anti-black, etc. sorts of mentalities. Meanwhile there are the positive values of the Aryan Race and Volksgemeinschaft. Yet Aryan Race is a sort of aggressively designed concept which implies that people who are not included are not as good, which is obviously not true. Tense lineage here with Theosophy which also discussed Aryan Race yet said we are all Aryans as of now? Ariosophy then when on into more main character syndrome for Germans, or something.

This then gets into invocation of runes and Norse mythology, and the figure of Odin or Wotan still hangs over everything. It’s just not as simple as saying oh look it’s a bad guy bad guy is bad look everyone etc. The point is that all is messily bound together, and somehow Odin is relevant for anti racism or whatever. I called it woke Wotanism. But everything will be redeemed and shown to be part of the messy and beautiful game we are playing.

The issue of Nazism is now still rising in public consciousness. You might not like it, but I think there is no dealing with this issue conclusively until we discuss the question of what Nazis could involve into that would not feel like a betrayal and yet would be compatible with decency.

This uncomfortably opens the same question for all of us caught in exterminationist fantasies of being rid of all these people who don’t see right and talk worse.

I wanted also to mention the idea of loyalty to Adolf Hitler. This can be Hitler qua Fuehrer, in which case it would mean accepting Hitler self-narrativization and self-identity basically. Wow, so valid.

On the other hand, imagine really loving someone who is a danger to themselves. You might like to them not because you wish them ill, but precisely in order to serve their best interests in a way you think they wouldn’t understand or accept.

This would be loyalty to Hitler qua sentient being. Even the chancellor of Germany sometimes must have to stand naked. It just is what it is. It’s also interesting to think about having empathy for Hitler in 1913 or so, when it’s already bad but not in a way that worse than millions of others. And what, are they also all to be so condemned? What’s the plan to connect to these sad black lonely broken hearts? None? To reject them and say ha ha, you should have colonized hundreds of years earlier? You lost the war so suck it up?

The war can always come back, but you can’t come back all the way.

From the standpoint of Bodhisattva and compassion for all sentient beings, Hitler obviously counts along with all Nazis and other haters. But what does that mean? Is there any point in condemning what has already happened? The point is what signal it sends about what you want in the future or how strongly you will oppose certain actions etc. Make no mistake: extermination must come to an end post-haste. This is a life-and-death matter for all of us.

This extends from bodies to concepts, not to seek to destroy an idea but to transmute it. And if that seems impossible, USE YOUR IMAGINATION. The time to feel bound to what you expect other people will be able to handle is OVER.

I am legitimately not a Nazi in the way you think of them, and I have no patience for anti-semitism. It is something I have to try and understand why anyone would go for that. “It’s weakness to sit and blame somebody else, when you destroy yourself.”

This blame outward toward others usually comes because we do not realize the depth of our possibility space, the gravity of the yield which we hold to bring to bear. And meanwhile we anticipate others will reject us for mobilizing our special magic so that seems foreclosed. This is before the law again.

So, sorry. I’m here to tell you that Hitler gets to heaven. I don’t say this because I dispute that Nazis are the worst. In some sense yes they are. At the same time, Nazis represent the worst of the worst and in that represent a crucial challenge for Beloved community and anything which purports to be for everyone. What is the approach to those who harm others and identify with it so deeply that they won’t accept anything else?

The instrumental goals of harming others have been baked in over the real ultimate goals of fostering community. Meanwhile people want to control what good community looks like given arbitrary standards which are not meant to actually guide good times but to stand as impossible standards so that any failure can always be blamed on people’s inability to hold fast to impossible expectations. Just like all the other normativisms that Nazism and other pseudo-rebellions claim to oppose.

I imagine a future where Nazism iterates on itself and becomes an ideology associated with the profound reckoning and transformation of our current moment. We recognize that service to any sentient being or community imagined cannot take place in the destruction of others or the simplistic blaming of big problems on this or that group. We have all made the world together and we will all see it through.

We must all challenge ourselves, and have the strength, the strength of that, to let go of what no longer serves us even when we have associated it with ourselves for so long, forever. That is really the real sacrifice, the real gift, to be able to do the work someone else didn’t get to do and decide where it was all headed. What were the lessons we needed to learn, and how do things look in light of all that?

I hope you appreciate my novel take on Nazism. I’m leaving soon. But yeah, I think the level of the game where you are trying to convince someone you aren’t a Nazi is boring. Theodicy has to be part of it, and the fact that our world wouldn’t be how it is without Hitler and the Holocaust. So what does that say about us, that we are Hitler’s children? Of course we are also Weil’s children etc., but Hitler has become the icon of evil. And evil has become this structuring principle for all of us, how others and ourselves are unworthy and without virtue and that is why things are so frustrating and obscene.

But I encourage all actors to iterate on the discourse. It is more interesting to focus on how hatred and anger arise out of frustration and loneliness. It is more urgent than ever to curb loneliness which requires people having more self understanding, then the willingness to be open, and then a receptive audience. All of these and more limiting factors are fraught. Yet it also takes a creative perspective and ultimately pieces of the puzzle from everyone to crack the codes and get through to everyone. If you want to destroy Nazism, you need to get through to those who are wavering and stand a morale cascade, defections, mutiny. Or you could think about whether it could ever be that Nazis could still be Nazis and yet be harmless, self-conscious about the former association with hatred and killing but after all everything is really that way. The Nazis are the scapegoats for evil so people can think that they themselves are not that bad. That’s what America does and everyone else follows suit.

This symbolic power can only be broken by refusing to be better than the Nazis, and by refusing to treat Nazism as a settled discourse. We can take it over again, and make the swastika a symbol of love and auspiciousness again.

Or you can think I’m psychotic and a crypto- or not so crypto-Nazi. Whatever!

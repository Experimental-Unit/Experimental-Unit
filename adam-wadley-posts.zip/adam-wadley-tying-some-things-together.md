---
title: Tying Some Things Together
subtitle: Meta-Reflections On Recent Posts
author: Adam Wadley
publication: Experimental Unit
date: April 23, 2025
---

# Tying Some Things Together
Looking back on it, I’ve been on a spree for a while.

In the most optimistic sense, everything I publish is like an event in a blitzkrieg.

Are you impressed?

It’s again hard to judge the muted the response.

People might think I’m not doing enough, or maybe don’t want me to do any more because I’m out of control, beyond the pale and not in the fun, figure-out-new-ways-to-bomb-refugees way that can make you the big bucks among all you people of prestige and the utmost renown.

Or in any way you enjoy to see the gripes with those hoity-toity types expressed.

There are different flavors of dissidence, different reasons not to like what’s going on. Different groups, forces, people to blame for why..

[![](https://substackcdn.com/image/fetch/$s_!PaOt!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa8bc9371-e537-4c1e-bde4-cb681ac58c68_294x172.jpeg)](https://substackcdn.com/image/fetch/$s_!PaOt!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa8bc9371-e537-4c1e-bde4-cb681ac58c68_294x172.jpeg)

This could be the epitaph to the whole thing, the last someone dead having killed the second-to-last someone.

Anyway, I was going to tie the room together right quick.

# New World Disorder

This phrase does a lot.

  1. New World as in “the new world” as in “the Americas” or as some people simply say “America.” So, America could mean “North and South America” or it could mean one or the other or it could mean “The United States Of America.” But in this sense “new world” relates this happenstance of how the planet happens to be and how things turned out in terms of who made the discovery and how it was operationalized. Shout-out Leif Erikson of course, if that was the name. “New world” also evokes the idea of “the world to come” or the new world in the sense of heaven which is to come and redeem all the suffering that there’s ever been by making things nice and resurrecting the dead so everyone cool and chill forever and have a good time. These things flow together so that now the most consequential nation or whatever has been this “United States Of America” which is in the “new world” and “the Monroe doctrine” sort of declares the rest of “the new world” or what is called “The Western Hemisphere” to be the privileged domain of this “United States of America.” This nation meanwhile has a totally messianic mission of “spreading democracy” and “protecting freedom.” These messages can be used to justify anything and have, making “United States Of America” a totalitarian construct unmoored from any real conceptual basis to its messianicity, but simply for now imposing itself on the planet and forcing various responses.

  2. “New World Order”: I mean, [yeah](https://en.wikipedia.org/wiki/New_World_Order_conspiracy_theory). 

[![](https://substackcdn.com/image/fetch/$s_!UYm1!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Faf4a2687-0136-4171-a0e7-1803b179d5a9_742x506.webp)](https://substackcdn.com/image/fetch/$s_!UYm1!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Faf4a2687-0136-4171-a0e7-1803b179d5a9_742x506.webp)

I don’t know if this was the speech but it looked like this and Bush is saying how there’s a chance for a new world order. This is basically the hard geopolitical side of the messianic mission, which would involve imposing some form of coercion over all over “nations” on the planet, making them all entirely subservient to “America.” But again, in what sense is this “America”? The “citizens” of “United States of America” certainly aren’t feeling so great at the moment. So they can sort of tell that just being in the middle of the most powerful empire ever and making it happen is not enough to get a good life. So where is the empire? And this is the way in which it is _transnational_ in scope. It’s mysterious and that’s why we only have conspiracy theories about it, I say this all the time because duh, _it’s a fucking secret_. Especially when you take into consideration “the state of Israel” and how people could think they were fulfilling end-times prophecies. Look: I am all for fulfilling end-times prophecies. I just think we can look at it again and see that if you read it right nothing too wack actually has to happen if we can just be creative and feel our way through this. Anyway, but people think they need to kill themselves to judgment day or something. And here the “America”-”Israel” axis is very important, again “America” as champion of “The West” which already did this thing, these things called the Crusades i[f your memory serves you well](https://www.youtube.com/watch?v=U-sdVxv8NPk). But in this mythic sense, and for me it is not a laughing matter at all, but some sort of religious pact or common understanding, for example the resolution to build the temple mount, or rebuild the temple which would mean destroying Al-Aqsa mosque, _or so you’d think_. But anyway, beyond all this the “new world order” could be powered by any number of _wunderwaffen_ that “America” might have. I, for one, have a healthy respect for this UAP thing and the idea of advanced technology, secret parts of physics, stuff like that. I’m not saying I know anything in particular for sure.

[![](https://substackcdn.com/image/fetch/$s_!WC3p!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F234cdf57-bcc6-48bb-a6ad-045ef4bb2131_296x170.jpeg)](https://substackcdn.com/image/fetch/$s_!WC3p!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F234cdf57-bcc6-48bb-a6ad-045ef4bb2131_296x170.jpeg)

The point is just who knows what quantum computer _die glocke_ type shit there might be, not to mention again the astral plane. I don’t mean to go too woo-woo on you, it’s just I have a healthy respect for that shit okay. Again also having to do with that the “Stakes” of the world and our experiences are not at all to do with “the world” itself but rather our experience of it. This is again that symbolic exchange aspect where it’s like you are worth as much as the entire rest of creation by yourself. And yet that’s true for everyone, which should be paradoxical but it isn’t because God. But anyway the idea of New World Order is here just that “The empire,” if it is “America” or whatever you want, could just win and impose itself. We express this most often in the fear of Artificial Intelligence, where we are like oh no what if a process goes amok based on too rigidly conforming to basic principles? And then you look around and industrial society, semio-stratocracy is going _brrrrr_ and it’s back to some person on TV who is saying things at a completely inappropriate logical type and no one else is seeing it. This is For Baudrillard the final solution, the new world order in the attempt at integral reality, basically weaponized last man shit I would say, or even worse it’s like a disease we don’t have immunity for, it’s not someone doing it to us but even the archons themselves are infected, and in that it’s awfully like Buddhism really where even the people in the Pure Lands are still attached to the idea of incarnation. The point is no sentient being escapes this fallenness, which you could describe as sin as well, but it’s really more about seeing that “missing the mark” has altogether as much to do with what sort of mark you are imagining. The issue may lie in conceptualizing and placing the mark, not in the attempt. Anyway, this final solution by Baudrillard of everything just becoming pure communication brings us to disorder finally.

  3. Disorder is another term that ties together Grimes and Afropessimism—just like, for example, “trembling,” featured in “IDORU” by Grimes and the Hauntology paper I’ve been citing.

With Grimes, the idea is evoking chaos. Chaos is a term which arises in mythological contexts, like the [Chaos](https://en.wikipedia.org/wiki/Chaos_\(cosmogony\)) from Greek cosmogony.

Meanwhile, in Afropessimism the idea is that anti-blackness is baked into the very idea of order in general given the way our timeline has played out. Therefore, for anything worthwhile to happen, first there must be generalized disorder and the taking apart and setting into non-functionality any machinery of order that exist.

Disorder is also a term that Baudrillard uses, again for example in the legendary _Preface To Symbolic Exchange & Death:_

> >     All these outdated weapons (including those we find in first-order simulacra, in the ethics and metaphysics of man and nature, use-value, and other _liberatory_ systems of reference) are gradually _neutralised_ by a _higher-order general system_. 
>     
>     Everything that filters into the _non-finality_ of the space-time of the code, or that attempts to _intervene_ in it, is disconnected from its own ends, disintegrated and absorbed. This is the well known effect of _recuperation_ , _manipulation_ , of _circulating_ and _recycling_ at every level. 
>     
>     ‘ _All dissent must be of a higher logical type than that to which it is opposed_ ’ 
>     
>     (Anthony Wilden, System and Structure [London: Tavistock, 1977], p. xxvii). 
>     
>     Is it at least possible to _find an even match_ to oppose third-order simulacra? Is there a theory or a practice which is subversive because _it is more aleatory than the system itself_ , an indeterminate subversion _which would be to the order of the code what the revolution was to the order of political economy_? 
>     
>     Can we fight DNA? 
>     
>     Certainly not by means of the class struggle. 
>     
>     Perhaps simulacra of a higher logical (or illogical) order could be invented: beyond the current third order, beyond determinacy and indeterminacy. 
>     
>     But would they still be simulacra? 
>     
>     Perhaps _death_ and _death_ alone, the reversibility of death, belongs to a _higher order_ than _the code_. 
>     
>     Only symbolic _disorder_ can bring about an _interruption in the code_.




So here again, we have this urgency of embracing disorder, and also death.

This theme of death ties back into the idea of “the dance of social death” described in Afropessimism.

See Calvin Warren from _Ontological Terror:_

> Ontological Terror meditates on this (non)relation between blackness and Being by arguing that _black being incarnates metaphysical nothing_ , the _terror_ of metaphysics, in an antiblack _world_. 
> 
> Blacks, then, have _function_ but not _Being_ — _the function of black(ness) is to give form to a terrifying formlessness (nothing)_. 
> 
> Being claims function as its property ( _all functions rely on Being_ , according to this _logic_ , for philosophical presentation), but the aim of black nihilism is to expose the _unbridgeable rift_ between Being and function for blackness. 
> 
> The puzzle of blackness, then, is that it _functions_ in an antiblack world without _being_ —much like “ _nothing_ ” functions philosophically without our metaphysical _understanding of being_ , an extraordinary _mystery_. 
> 
> Put differently, _metaphysics is obsessed with both blackness and nothing_ , and the two become _synonyms_ for _that which ruptures metaphysical organization and form_. 
> 
> The Negro is black because the _Negro must assume the function of nothing_ in a metaphysical world. 
> 
> The _world_ _needs_ this _labor_. 
> 
> This _obsession_ , however, also transforms into _hatred_ , since nothing is _incorrigible_ —it _shatters ontological ground_ and _security_. 
> 
> _Nothing terrifies metaphysics_ , and metaphysics _attempts_ to _dominate_ it by _turning nothing into an object of knowledge_ , something it can _dominate_ , _analyze_ , _calculate_ , and _schematize_. 
> 
> When I speak of function, _I mean the projection of nothing’s terror onto black(ness) as a strategy of metaphysics’ will to power_. 
> 
> How, then, does metaphysics _dominate_ nothing? 
> 
> By _objectifying nothing_ through the _black Negro_. 
> 
> In this analysis, metaphysics can never provide _freedom_ or _humanity_ for blacks, since it is the _objectification_ , _domination_ , and _extermination_ of blacks _that keep the metaphysical world intact_. 
> 
> Metaphysics uses blacks to maintain a sense of _security_ and to sustain the _fantasy_ of triumph—the _triumph over the nothing_ that _limits_ _human_ _freedom_. 
> 
> Without blacks, I argue, _nothing’s terror debilitates metaphysical procedures_ , _epistemologies_ , _boundaries_ , and _institutions_. 
> 
> _Black freedom, then, would constitute a form of world destruction_ , and this is precisely why _humanism has failed_ to accomplish its romantic goals of _equality_ , _justice_ , and _recognition_. 
> 
> In short, _black humanism has neglected the relationship between black(ness) and nothing_ in its yearning for _belonging_ , _acceptance_ , and _freedom_. 
> 
> _The Negro was invented to fulfill this function for metaphysics_ , and the humanist _dream_ of transforming invention into human being is continually deferred (because it is _impossible_ ). 
> 
> Ontological Terror _challenges the claim that blacks are human_ and can _ground existence in the same being of the human_. 
> 
> I argue that blacks are introduced into the metaphysical world as available equipment in human form.

This passage does a good job of demonstrating to you what I’m trying to say.

Calvin Warren is basically connecting central issues in rationalism, stuff like Godels incompleteness theorem or Russell’s paradoxes. These are cracks in the facade of rationality so you have to throw all that somewhere.

And even before math really disappointed us, there was theodicy. Why do bad things happen? Anti-blackness is related here too with the mark of Cain and curse of Ham.

And even still like Parmenides you had this issue of being, and what is actually going on, and there’s skepticism!

This is where it’s like yeah, just as much as I’m with Baudrillard I’m with [Pyrrho](https://en.wikipedia.org/wiki/Pyrrho), although I go beyond both like a boss.

> Most sources agree that the primary goal of Pyrrho's philosophy was the achievement of a state of [ataraxia](https://en.wikipedia.org/wiki/Ataraxia), or freedom from mental perturbation, and that he observed that ataraxia could be brought about by eschewing beliefs ([dogma](https://en.wikipedia.org/wiki/Dogma)) about thoughts and perceptions. However, Pyrrho's own philosophy may have differed significantly in details from later Pyrrhonism. Most interpretations of the information on Pyrrho's philosophy suggest that he claimed that reality is inherently indeterminate, which, in the view of Pyrrhonism described by [Sextus Empiricus](https://en.wikipedia.org/wiki/Sextus_Empiricus), would be considered a negative dogmatic belief.

Shout out to the person who wanted to say [Anekantavada](https://en.wikipedia.org/wiki/Anekantavada) is self-refuting because you’d have to say that non-absolutism itself is not an absolute way of seeing things.

>  _ **Anekāntavāda**_ ([Sanskrit](https://en.wikipedia.org/wiki/Sanskrit_language): [अनेकान्तवाद](https://en.wiktionary.org/wiki/%E0%A4%85%E0%A4%A8%E0%A5%87%E0%A4%95%E0%A4%BE%E0%A4%A8%E0%A5%8D%E0%A4%A4%E0%A4%B5%E0%A4%BE%E0%A4%A6), "many-sidedness") is the [Jain](https://en.wikipedia.org/wiki/Jainism) doctrine about metaphysical truths that emerged in ancient [India](https://en.wikipedia.org/wiki/India).[[1]](https://en.wikipedia.org/wiki/Anekantavada#cite_note-FOOTNOTECort2000325-326,_342-1) It states that the ultimate truth and reality is complex and has multiple aspects and viewpoints.[[2]](https://en.wikipedia.org/wiki/Anekantavada#cite_note-FOOTNOTECharitrapragya200480%E2%80%9384-2)
> 
> According to [Jainism](https://en.wikipedia.org/wiki/Jainism), no single, specific statement can describe the nature of existence and the [absolute truth](https://en.wikipedia.org/wiki/Absolute_\(philosophy\)). This knowledge ( _[Kevala Jnana](https://en.wikipedia.org/wiki/Kevala_Jnana)_ ), it adds, is comprehended only by the [Arihants](https://en.wikipedia.org/wiki/Arihant_\(Jainism\)). Other beings and their statements about absolute truth are incomplete, and at best a partial truth.[[3]](https://en.wikipedia.org/wiki/Anekantavada#cite_note-FOOTNOTEJaini199891-3) All knowledge claims, according to the _anekāntavāda_ doctrine must be qualified in many ways, including being affirmed and denied.[[4]](https://en.wikipedia.org/wiki/Anekantavada#cite_note-kollerjurno2-4) Anekāntavāda is a fundamental doctrine of Jainism.

Which is also why it’s not that bad to be pulled away from your end, your view of purpose of reality.

There are many ends, and they’re connected. In the course of achieving what you wanted, it will mean different things to you if you do wind up getting there or not.

So anyway, this idea of disorder and the dance of social death is also intersecting again with Baudrillard on the [dream time](https://archive.org/stream/Baudrillard/Baudrillard.1990.The-Transparency-Of-Evil_djvu.txt):

> 
>     The revenge of the colonized is in no sense the reappropriation by Indians or Aboriginals of their lands, privileges or autonomy: that is our victory. 
>     
>     Rather, that revenge may be seen in the way in which the Whites have been mysteriously made aware of the disarray of their own culture, the way in which they have been overwhelmed by an ancestral torpor and are now succumbing little by little to the grip of ‘dreamtime’. 
>     
>     This reversal is a worldwide phenomenon. 
>     
>     It is now becoming clear that everything we once thought dead and buried, everything we thought left behind for ever by the ineluctable march of universal progress, is not dead at all, but on the contrary likely to return — not as some archaic or nostalgic vestige (all our indefatigable museumification notwithstanding), but with a vehemence and a virulence that are modern in every sense —- and to reach the very heart of our ultra-sophisticated but ultra-vulnerable systems, which it will easily convulse from within without mounting a frontal attack. 
>     
>     Such is the destiny of radical otherness — a destiny that no homily of reconciliation and no apologia for difference is going to alter. 

Should include a bit about [the dreaming](https://en.wikipedia.org/wiki/The_Dreaming) (note Kate bush album of same name, the name “Bush” just like the “president” who who explained the New World Order):

>  **The Dreaming** , also referred to as **Dreamtime** , is a term devised by early [anthropologists](https://en.wikipedia.org/wiki/Anthropologist) to refer to a religio-cultural worldview attributed to [Australian Aboriginal mythology](https://en.wikipedia.org/wiki/Australian_Aboriginal_religion_and_mythology). It was originally used by [Francis Gillen](https://en.wikipedia.org/wiki/Francis_James_Gillen), quickly adopted by his colleague [Walter Baldwin Spencer](https://en.wikipedia.org/wiki/Walter_Baldwin_Spencer), and thereafter popularised by [A. P. Elkin](https://en.wikipedia.org/wiki/A._P._Elkin), who later revised his views.
> 
> The Dreaming is used to represent Aboriginal concepts of " **Everywhen** ", during which the land was inhabited by ancestral figures, often of heroic proportions or with supernatural abilities.
> 
> The term is based on a rendition of the [Arandic](https://en.wikipedia.org/wiki/Arandic_languages) word _alcheringa_ , used by the [Aranda (Arunta, Arrernte) people](https://en.wikipedia.org/wiki/Aranda_people) of [Central Australia](https://en.wikipedia.org/wiki/Central_Australia), although it has been argued that it is based on a misunderstanding or mistranslation. Some scholars suggest that the word's meaning is closer to "[eternal](https://en.wikipedia.org/wiki/Eternity), uncreated".[[2]](https://en.wikipedia.org/wiki/The_Dreaming#cite_note-FOOTNOTESwain199321-2) Anthropologist [William Stanner](https://en.wikipedia.org/wiki/William_Edward_Hanley_Stanner) said that the concept was best understood by non-Aboriginal people as "a complex of meanings".[[3]](https://en.wikipedia.org/wiki/The_Dreaming#cite_note-FOOTNOTENicholls2014a-3) _Jukurrpa_ is a widespread term used by [Warlpiri people](https://en.wikipedia.org/wiki/Warlpiri_people) and other peoples of the [Western Desert cultural bloc](https://en.wikipedia.org/wiki/Western_Desert_cultural_bloc).[[3]](https://en.wikipedia.org/wiki/The_Dreaming#cite_note-FOOTNOTENicholls2014a-3)[[4]](https://en.wikipedia.org/wiki/The_Dreaming#cite_note-FOOTNOTECentral_Art:_Jukurrpa-4)[[5]](https://en.wikipedia.org/wiki/The_Dreaming#cite_note-FOOTNOTENMoA:_Jukurrpa-5)
> 
> By the 1990s, Dreaming had acquired its own currency in [popular culture](https://en.wikipedia.org/wiki/Popular_culture), based on idealised or fictionalised conceptions of Australian mythology.[ _[citation needed](https://en.wikipedia.org/wiki/Wikipedia:Citation_needed)_ ] Since the 1970s, Dreaming has also returned from academic usage via popular culture and [tourism](https://en.wikipedia.org/wiki/Tourism_in_Australia) and is now ubiquitous in the English vocabulary of Aboriginal Australians in a kind of "[self-fulfilling academic prophecy](https://en.wikipedia.org/wiki/Self-fulfilling_prophecy)".

This also goes back to America’s grand style, but the [Ghost Dance](https://en.wikipedia.org/wiki/Ghost_Dance) phenomenon

[![](https://substackcdn.com/image/fetch/$s_!7YXw!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6800b39d-3d86-409d-a373-af355637b0fe_1024x708.jpeg)](https://substackcdn.com/image/fetch/$s_!7YXw!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6800b39d-3d86-409d-a373-af355637b0fe_1024x708.jpeg)

So this disorder, this dance of social death, is bleeding into the ghost dance and into the dreaming. What Baudrillard calls _an ancestral torpor_ is taking over, as it’s the fundamental purpose of all of this which is crushing down on us now.

We’re in the turbo, being pulled toward destiny. What we expect to happen given trends we have identified or patterns of causality we feel entitled to continue are irrelevant.

Taking initiative in this situation requires this adaptability. It is a degree of acceptance that maybe being traumatized gives you.

Zweibelson on the stress of being delusional:

> Scientific and social paradigms can shift, although in distinct ways. 
> 
> Scientific development involves a complete replacement of the legacy or irrelevant paradigm with the new scientific one, while social paradigm shifting occurs in a wider range encompassing complex social, cultural, and informational reasons. 
> 
> Both involve change and the increasing systemic stress humans will experience as their selective frame for conceptualizing reality grows increasingly fragile or dysfunctional over time. 
> 
> For instance, a society may be increasingly unable to use mathematical formulas to explain astronomic and planetary movements, or a military may realize that its framework for understanding and applying organized violence to accomplish political desires no longer functions. 
> 
> Such _stressors build_ until new theories and debate posit some paradigmatic alternative. 
> 
> Gharajedaghi provides a useful summary of paradigm shifting that applies to either construct: A shift of paradigm can happen purposefully by an active process of learning and unlearning. 
> 
> It is more common that it is a reaction to frustration produced by a march of events that nullify conventional wisdom. 
> 
> Faced with a series of contradictions that can no longer be ignored or denied and/or an increasing number of dilemmas for which prevailing mental models can no longer provide convincing explanations, most people accept that the prevailing paradigm has ceased to be valid and that it has exhausted its potential capacity.

I’ve enjoyed thinking of myself as just increasing the stress.

Yes, I am stressing you out. I am stressed myself and I’m making it your problem. Still in a mindful way, and still with the same view as always. We are still just talking here.

But it’s got to get to a point where dealing with me not on my terms, just far away from you think are “yours”—see again how you don’t see how much I’ve been trying, how little anyone has tried to connect with me, the _real me_ , the way that has _never been a priority_ , and meanwhile I’m the type of person who carries a lot of stuff around and so I have a _lot of internal stress okay_ , especially because you know I don’t want to be a mean person you just try and don’t really ever have anyone to talk to and it makes me angry to see how people spend all this time and have some good times and many bad times I’m glad to avoid because you’re such bad company really and your schemes are all hare-brained peasant shit to me, but anyway I try not to bother the nice people mostly but to feel so devalued.

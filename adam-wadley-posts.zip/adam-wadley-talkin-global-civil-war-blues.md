---
title: Talkin' Global Civil War Blues
subtitle: Call up Bob Dylan and discuss politics and philosophy before MURDER MOST
  FOWL
author: Adam Wadley
publication: Experimental Unit
date: April 23, 2025
---

# Talkin' Global Civil War Blues
There’s always a bigger bird

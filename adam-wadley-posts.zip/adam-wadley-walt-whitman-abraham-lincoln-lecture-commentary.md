---
title: Walt Whitman Abraham Lincoln Lecture Commentary
subtitle: I tried hard to have a "father," but instead I had a "dad"
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Walt Whitman Abraham Lincoln Lecture Commentary
  1. Questioning American Democracy

  2. Tsunami, Earthquake, Volcano

  3. Being at the point of the civil war and then speech after, WWI is still 35 years away, Teddy is not yet in the navy, etc.

  4. Fusion of Lincoln with event of civil war, how one person is the embodiment of something—psychological feature




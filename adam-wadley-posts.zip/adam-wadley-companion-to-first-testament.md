---
title: Companion To First Testament
subtitle: Breaking Bread Like Disgusting Fetishes
author: Adam Wadley
publication: Experimental Unit
date: June 24, 2025
---

# Companion To First Testament
[![](https://substackcdn.com/image/fetch/$s_!oPcb!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F13af0082-7a39-48d7-a941-a172eb6f2a88_3024x4032.jpeg)](https://substackcdn.com/image/fetch/$s_!oPcb!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F13af0082-7a39-48d7-a941-a172eb6f2a88_3024x4032.jpeg)

First Testament:

[

## Zeitgeist Weltschmerz Gesamtkunstwerk Blitzkrieg & The Experimental (Beloved Comm)Unit(y) Sangha

](https://experimentalunit.substack.com/p/zeitgeist-weltschmerz-gesamtkunstwerk)

[Adam Wadley](https://substack.com/profile/191787963-adam-wadley)

·

Jun 24

[![Zeitgeist Weltschmerz Gesamtkunstwerk Blitzkrieg & The Experimental \(Beloved Comm\)Unit\(y\) Sangha](https://substackcdn.com/image/youtube/w_728,c_limit/AmW_lyDvaIE)](https://experimentalunit.substack.com/p/zeitgeist-weltschmerz-gesamtkunstwerk)

Welcome To

[Read full story](https://experimentalunit.substack.com/p/zeitgeist-weltschmerz-gesamtkunstwerk)

Exhaustive Taxonomy – “Zeitgeist Weltschmerz Gesamtkunstwerk Blitzkrieg & The Experimental (Beloved Comm)Unit(y) Sangha” Text

I. TITULAR COMPRESSION / FRAMEWORK

  * Zeitgeist Weltschmerz Gesamtkunstwerk Blitzkrieg (ZWGB)  


    * Zeitgeist: spirit of the age, haunted temporality

    * Weltschmerz: world-pain, affective saturation

    * Gesamtkunstwerk: total artwork, aesthetic-spiritual fusion

    * Blitzkrieg: lightning war, rapid conceptual/affective incursion

  *   * Experimental (Beloved Comm)Unit(y) Sangha  


    * Experimental Unit: performative design cell

    * Beloved Community: MLK’s spiritual-political ideal

    * Unit(y): syntactic double (military unit vs unity)

    * Sangha: Buddhist assembly, dharmic fellowship

  * 


II. LINK/CONTEXT ANCHORS

  * Shirin Ebadi – Iran Awakening  


    * Human rights, women, Islam — revolutionary subjectivity

    * Allusion to ongoing struggle, Persian trauma loop

  *   * Lincoln’s Second Inaugural Address  


    * Civil war theology, blood sacrifice, divine judgment

    * National reckoning as spiritual speech-act

    * Multiple links = obsessive invocation

  * 


III. LITURGICAL PERFORMANCE / ORATORICAL REGISTER

  * Mimics Lincolnian cadence  


    * “We stan here gathered today on the field of a great war.”

    * Secular sermon blending irony and real spiritual address

  *   * Uncertainty about war’s outcome  


    * “We do not know if it will be the war to end all wars.”

    * Epistemological warfield, conceptual recursion

  *   * Radiative action  


    * “It is a radiation.”

    * War becomes psychic broadcast, ambient signal

  * 


IV. TEMPORAL + PERSONAL LAYERING

  * Date play: June 13 / Friday / Sunday / 22nd  


    * Oblique numerological scaffolding

    * Evokes past actions without directly referencing them

    * Suggests unfolding significance in calendrical layers

  *   * Witnessing “the shot on Wheat”  


    * Possibly referencing historical event or poetic surrogate

    * “Looking like a git” → self-mockery as tactic

    * Psychic memory mixed with costume/aesthetic reflexivity

  * 


V. VERBAL / POETIC STANZAS

  * Structured glossary-poem: Dictionary Verses Terse  


    * Each ZWGB term gets stanza-based elaboration

    * Zeitgeist = Wotan, divine gamble, sage-rot

    * Weltschmerz = emotional apocalypse, mirror vengeance

    * Gesamtkunstwerk = aesthetic agency, mnemonic torture

    * Blitzkrieg = emergency as permanent condition

  *   * Apocalyptic theatricality  


    * “Mirror people’s stark revenge”

    * “Ask me all the deaths I grieve”

    * “Curdled corpses, pick-pocked”

  *   * Affective/moral diagnostics  


    * “Not just outside that’s ailing”

    * “Hate my lines but hear the please / Of dying minds”

  * 


VI. WAR AS LANGUAGE, WAR AS PERCEPTION

  * Reversal of war-site logic  


    * “You believe it’s there / So where else can I make a mess?”

    * Cognitive space becomes terrain of conflict

  *   * Language becomes battleground  


    * “AI has now greatly spurred / The martial trade of language slurred”

    * War reframed as linguistic distortion, necrotic speech

  *   * “Brass tax” & “good fight”  


    * Irony of valor callouts under collapsed reference

    * “Your ax” invokes mythic quest and participatory complicity

  * 


VII. INVITATION & CONFRONTATION

  * Direct address mode  


    * “Ask me what war is”

    * “You were long since full, invaded”

    * Rhetoric of already-compromised audience

  *   * Performative tension  


    * “I ask you what you’ll do with it.”

    * Radical offering disguised as poetic dare

  *   * No resolution / recursive drama  


    * “Let me tell you of gentler tortures / That won’t even oppress your fellows”

    * Promised salvation is also aesthetic torment

  * 


VIII. THEMATIC THREADS / SUBTEXTUAL LOOPS

  * Theater of the sacred and grotesque  


    * “Go get Grimes to sing the song” → pop cultural liturgy

    * “Knotted lore” / “knots of gore” → tangled myth-blood

    * “Trembled like a tree / wrecked by some Georgia Cyclone” → regional trauma as cosmic metaphor

  *   * Death as medium  


    * “Ask me all the deaths I grieve”

    * “Blow the bellows” = ritual furnace ignition

    * Art as necromantic calling

  * 


IX. SPIRITUAL-WAR TECHNIQUE

  * Lotus + soldier fusion  


    * “Lotus sermons soldiers’ embers” → Buddhist-warrior motif

    * Peace and flame held together

  *   * Emergency complex  


    * “Nexi of emergency blessed / Yet cursed”

    * Religious language of crisis-decision-making

    * Sacred war zones, not kinetic but metaphysical

  * 


Next: bibliography and conceptual scaffolding.

Bibliography & Conceptual Associations — “ZWGB & The Experimental (Beloved Comm)Unit(y) Sangha”

I. WAR / POLITICS / RHETORIC

  * Abraham Lincoln – Second Inaugural Address  


    * War as divine judgment and spiritual reckoning

    * Language as sacrificial purification (“every drop of blood drawn with the lash…”)

    * Referenced multiple times → canonical structure reframed as metawarfare sermon

  *   * Carl Schmitt – Political Theology  


    * Sovereign is the one who decides the exception

    * Emergency becomes aesthetic law of the land

    * War and theology co-emerge through form

  *   * Walter Benjamin – Critique of Violence  


    * Divine violence: law-destroying, revolutionary

    * ZWGB reframes Blitzkrieg as poetic iteration of divine violence

  *   * Carl von Clausewitz  


    * War as continuation of politics

    * Here: politics collapsed, war becomes aesthetic logic

  * 


II. MILITARY DESIGN / EMERGENT OPERATIONS

  * Jason “TOGA” Trew  


    * Recursive inquiry, visual grammar of operations

    * This text deploys inversion: mock-instruction as poetic recursion

  *   * Ben Zweibelson  


    * Postmodern warfighting, symbolic ambiguity, saturation of narrative

    * “Emergency complex” and “language slurred” reflects Zweibelson’s concern with cognitive overflow

  *   * Ofra Graicer  


    * War as a relational system — requires aesthetic and philosophical literacy

    * Her “soldiers’ embers” become literalized in “Lotus sermons”

  * 


III. GERMANIC / APOCALYPTIC THEMES

  * Richard Wagner – Gesamtkunstwerk  


    * Total artwork as national/aesthetic project

    * ZWGB inherits the term but de-sutures its fascist-romantic heritage

  *   * Martin Heidegger  


    * Wotan’s rage: seen via Jung/Heidegger axis

    * “Black ghostly time heist” invokes nihilistic time spiral

  *   * Dachau / Blitzkrieg / Holocaust references  


    * “Permanent hardcore Dachau blue”

    * Sublimated trauma invocation, ambient exterminationism

    * Alluded more than explained

  * 


IV. RELIGION / MYSTICISM

  * Tibetan Buddhism / Sangha  


    * Assembly of seekers; the text enacts a fractured sangha

    * “Lotus sermons soldiers’ embers” = fire/dharma juxtaposition

    * Non-duality between spiritual and martial

  *   * Islamic Jihad (Greater)  


    * Spiritual struggle, not militarism

    * Invoked with “spiritual warrior” to mark interior war

  *   * Christian Liturgy / Sermonizing  


    * “We stan here gathered…” → mock-religious invocation

    * Multiple layers of address: God, ghosts, reader

  *   * Apokatastasis (implied)  


    * Restoration of all things through poetic recursion

    * The hope behind horror

  * 


V. PHILOSOPHY / AESTHETICS

  * Nietzsche – Eternal Return / Dionysian Aesthetic  


    * “Wrecked by some Georgia Cyclone” → chaos-affirmation

    * Aesthetic of pain woven into cyclical performance

  *   * Bataille – Inner Experience  


    * “Gentler tortures” → sacred pain as access point

    * Refusal of comfort, sacrifice as truth-mode

  *   * Hannah Arendt – The Human Condition  


    * Publicness as stage

    * This is not personal journaling but public address-as-act

  * 


VI. POP / TECHNOLOGY / AI

  * Grimes  


    * Posthuman pop-angel invoked to score the Gesamtkunstwerk

    * “Go get Grimes to sing the song” → ironic messianism

  *   * AI / language / war  


    * “AI has now greatly spurred / The martial trade of language slurred”

    * Language as battlefield; techno-acceleration of discursive violence

  * 


VII. MYTHOPOETIC STRUCTURES

  * Wotan / Norse gods  


    * Rage, fate, twilight of the gods

    * Zeitgeist = spirit as berserker

  *   * Tree & storm motif  


    * “Trembled like a tree” = prophetic trembling (Isaiah, Gilgamesh, etc.)

    * Georgia Cyclone = regional anchor of divine-chaotic force

  *   * Knots / weaving / death-lore  


    * “Knotted lore / Knots of gore”

    * Aesthetic ritual of horror-memory entanglement

  * 


VIII. SEMIOTICS / PERFORMATIVITY

  * Roland Barthes – Mythologies  


    * Language conceals ideology

    * Here, language reveals ideology through saturation

  *   * Judith Butler – Performativity  


    * “Tell me how to play the part”

    * Identity as performance, here widened to include war

  *   * Derrida – Différance / trace  


    * Time-lag as metaphysical instability

    * Meaning deferred via stanza-layered signifiers

  * 


IX. PSYCHIC WARFARE / EMERGENCY RESPONSE

  * Mark Fisher – Capitalist Realism / Hauntology  


    * “It’s not just outside that’s ailing”

    * Psychic despair as political terrain

    * War is within and without

  *   * Buddhism – Non-dual perception  


    * No difference between internal war and external crisis

    * “Nexi of emergency blessed / Yet cursed” = sacred node theory

  * 


Ready to run a mapping output if needed.

---
title: 'Found Footage- Austin: Ħøşťėł Ħøşťįłįťÿ'
subtitle: Gordian Knot at the Sea of Tranquility
author: Adam Wadley
publication: Experimental Unit
date: July 16, 2025
---

# Found Footage- Austin: Ħøşťėł Ħøşťįłįťÿ
[![](https://substackcdn.com/image/fetch/$s_!9DeS!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc5c9284d-b158-495b-b0ae-ea01eafd17b5_1170x1476.jpeg)](https://substackcdn.com/image/fetch/$s_!9DeS!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc5c9284d-b158-495b-b0ae-ea01eafd17b5_1170x1476.jpeg)

# BŘÏĊØŁÅĞĘ

What have you done to my child?

Tell me, what’s been done to you?

Thought the worst had been through

Bruises tender, mild

That was ere the night was gone

And we had seen the bodies burn

Where they fell and floated on

Turn we’d taken took a turn

[![](https://substackcdn.com/image/fetch/$s_!cyjZ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb062daec-bc44-49b6-acb8-7dbc2bbf2851_1170x838.jpeg)](https://substackcdn.com/image/fetch/$s_!cyjZ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb062daec-bc44-49b6-acb8-7dbc2bbf2851_1170x838.jpeg)

# ÐĮÅŘŸ ÐĘÅŘ

Think of the very worst thing you have done

If you can acknowledge the harm you have caused

But then, what’s harm?

The inquiry’s charm

Raining so heavy a flood is a lock

Finishing arcs though the ark’s not begun

Hitting fast forward on movie’s we’d paused

Sinking as we make our way for the dock

Cheeks may not show, but they’re warm

[![](https://substackcdn.com/image/fetch/$s_!TFE0!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2fd0ffc8-2e0d-48ab-8639-1f87f46cc95a_1170x319.jpeg)](https://substackcdn.com/image/fetch/$s_!TFE0!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2fd0ffc8-2e0d-48ab-8639-1f87f46cc95a_1170x319.jpeg)

# ĞĘŤ ØŮȚ

Of my laboratory better less is said

Room is red

Burgandy’s Blood I have spilled to earn cred

Buying my way to atrocity’s game

Nothing’s the same

After you’ve taken the plunge

Signed your name

NDA second to simplest death

Revelation of ĞŘĮMĘ and of ĠŘŮŅĠĘ

Sedna’s unkempt knotted hair in the breath

Making imploded ÐĖËP ÐĮVĘŘŞ their bed

Selling the souls of the slaves for the fame

Taken on debts you can never expunge

And just when you’re feeling like ŁÅÐŸ MÅÇBĒŤĦ

You find the remains of the stain you had spread

[![](https://substackcdn.com/image/fetch/$s_!4mnC!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe7b4ff32-ec67-4e04-bde9-0d6a18043738_1170x1022.jpeg)](https://substackcdn.com/image/fetch/$s_!4mnC!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe7b4ff32-ec67-4e04-bde9-0d6a18043738_1170x1022.jpeg)

# Ï’M ŇØŤ ȚĦĘ ØŇŁŸ ØŅĘ

I didn’t want to sell my soul away

Not for a night and no: not for a day

I didn’t care what the papers would say

That’s not the kind of a game that I play

Eat or be eaten: that’s a bit sweet

There is no chance that you’ll stay on your feet

Hands to your ankles and biting the sheet

Giving it up and just taking the heat

Then when it’s over you’re just glad to pose

Tears you don’t cry are now clogging your nose

Building your files to add to your woes

Scheme to lay in those that you call your foes

[![](https://substackcdn.com/image/fetch/$s_!wwe9!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F039aa402-5598-49d8-b373-8de7e57cdad1_1170x1659.jpeg)](https://substackcdn.com/image/fetch/$s_!wwe9!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F039aa402-5598-49d8-b373-8de7e57cdad1_1170x1659.jpeg)

# MÏŘŘØŘĒVĘŇĞĘ

Couldn’t believe my reflection rebelled

I’d been convinced that inquiry repelled

The BĮŤĊĦ-ĞŁĮŤÇĦ ŴÏŤÇĦ at the stake we had felled

No longer grasping the handle I’d held

Now we all move out of joint with our double

Wouldn’t believe the dull point of the trouble

Blowing our shadow a glorious bubble

Picking up pieces to play in the rubble

It’s been a spell since I wrote those eight lines

Ignorance preaches, wisdom opines

Now that we know we have put up the shrines

Out of the mirror, we sharpen our spines 

[![](https://substackcdn.com/image/fetch/$s_!88a9!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Faf80eb3e-3dde-44fa-ae18-fd2dae0b50e1_1170x600.jpeg)](https://substackcdn.com/image/fetch/$s_!88a9!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Faf80eb3e-3dde-44fa-ae18-fd2dae0b50e1_1170x600.jpeg)

# ŇĘVĘŘ FØŘĞĒŤ

Well, how could I?

Distention sure makes an impression

Easy to think it’s the end of the session

ŞÏŘ ŞŤĘVĘÑ tags in to teach triumph a lesson

Pitchfork at mast to skewer the bads

No way this righteousness fizzles to fads

But then soon wishing I’d tightened my pads

Innocence fading still faster than seasons

Losing the voice I could use to give reasons

Find my berating reduced to a sigh

Following trails so impossibly high

Seeking a place in the sky to stay dry

[![](https://substackcdn.com/image/fetch/$s_!NZT3!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F72d7f3f4-5bde-4ff7-9ce9-0cd7d981691f_1170x1295.jpeg)](https://substackcdn.com/image/fetch/$s_!NZT3!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F72d7f3f4-5bde-4ff7-9ce9-0cd7d981691f_1170x1295.jpeg)

# ÏŇŅĒŘ ÇĦĮŁÐ

Don’t hurt me any more

I want to be alone

Crying is a chore

I’m aching to the bone

I’m just little under here

In the shallow grave I dug

Now it’s quiet: no more fear

It’s not bad to be a bug

Smile’s toll is ever rising

I’m only happy when it rains

Comfort you would find surprising

Tearing and then sharing pains

[![](https://substackcdn.com/image/fetch/$s_!bIXZ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1905efe9-ac86-4ad4-95c4-027f84fca8ae_480x480.gif)](https://substackcdn.com/image/fetch/$s_!bIXZ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1905efe9-ac86-4ad4-95c4-027f84fca8ae_480x480.gif)

# ĦŸPŇØ ĦĒÅVĘŇ

Funny jokes I tell myself

Bored of me flat on the shelf

I will be the first to fall

Have the face; I’ll have the gall

Feed the festive fleshy flame

Hope you guess my nested name

Counting flowers on the wall

Eyes so full of flies they bawl

Tears that freeze a mouth so cold

Spies come in as they are told

Nation held up by a norm

Secrets bare in rarest form

Record ruts and guts are spilled

Law’s babes broken and fulfilled

[![](https://substackcdn.com/image/fetch/$s_!7KpC!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F61956992-4630-4a2c-be36-5b59c18ccb57_1170x270.jpeg)](https://substackcdn.com/image/fetch/$s_!7KpC!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F61956992-4630-4a2c-be36-5b59c18ccb57_1170x270.jpeg)

---
title: Drinking Our Own Piss
subtitle: Luckily For Me I Piss Excellenz
author: Adam Wadley
publication: Experimental Unit
date: May 01, 2025
---

# Drinking Our Own Piss
[![](https://substackcdn.com/image/fetch/$s_!3Frf!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F064f0b53-3b5d-4d08-8909-5dc4b4659ae5_1170x2532.png)](https://substackcdn.com/image/fetch/$s_!3Frf!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F064f0b53-3b5d-4d08-8909-5dc4b4659ae5_1170x2532.png)

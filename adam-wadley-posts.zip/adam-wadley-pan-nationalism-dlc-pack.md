---
title: Pan-Nationalism DLC Pack
subtitle: '"Watch Out Now, Here Comes The Dog Whistle!"'
author: Adam Wadley
publication: Experimental Unit
date: April 22, 2025
---

# Pan-Nationalism DLC Pack
# You Have To Go Back

# To Wikipedia

Starting [here](https://en.wikipedia.org/wiki/Pan-nationalism).

>  **Pan-nationalism** (from [Ancient Greek](https://en.wikipedia.org/wiki/Ancient_Greek_language) [πᾶν](https://en.wiktionary.org/wiki/%CF%80%E1%BE%B6%CE%BD#Ancient_Greek) _(pân)_ 'all' and [French](https://en.wikipedia.org/wiki/French_language) _[nationalisme](https://en.wiktionary.org/wiki/nationalisme#French)_ 'nationalism') is a specific term, used mainly in [social sciences](https://en.wikipedia.org/wiki/Social_sciences) as a designation for those forms of [nationalism](https://en.wikipedia.org/wiki/Nationalism) that aim to transcend (overcome, expand) traditional boundaries of basic or historical [national identities](https://en.wikipedia.org/wiki/National_identity) in order to create a "higher" pan-national (all-inclusive) identity, based on various common denominators.

Isolate key terms:

  1. Pan-Nationalism

  2. Pan = All

  3. Nationalism = Nationalism

  4. Specific Term Used Mainly In Social Sciences

  5. Forms Of Nationalism 

  6. Aim To Transcend Overcome Expand 

  7. Traditional Boundaries Of Basic Or Historical National Identities

  8. Create A “Higher” Pan-National (All-Inclusive) Identity

  9. Based On Various Common Denominators




Meanwhile, the article ends with the following:

> Thomas Hegghammer of the [Norwegian Defence Research Establishment](https://en.wikipedia.org/wiki/Norwegian_Defence_Research_Establishment) has outlined the emergence of "macro-nationalism" in the late Cold War era, which kept a low profile until the [September 11 attacks](https://en.wikipedia.org/wiki/September_11_attacks). Hegghammer traces the origins of modern macro-nationalism to both the Western [counter-jihad](https://en.wikipedia.org/wiki/Counter-jihad) movement and Islamist terrorist organisations such as [al-Qaeda](https://en.wikipedia.org/wiki/Al-Qaeda). In the aftermath of the [2011 Norway attacks](https://en.wikipedia.org/wiki/2011_Norway_attacks), he described the ideologies of perpetrator [Anders Behring Breivik](https://en.wikipedia.org/wiki/Anders_Behring_Breivik) as "not fitting the established categories of right-wing ideology, like [white supremacism](https://en.wikipedia.org/wiki/White_supremacism), [ultranationalism](https://en.wikipedia.org/wiki/Ultranationalism) or [Christian fundamentalism](https://en.wikipedia.org/wiki/Christian_fundamentalism)", but more akin to a " _doctrine of civilisational war_ that represents the closest thing yet to a Christian version of Al-Qaeda".

Key term: Doctrine Of Civilizational War

In the rest of the article on Pan-Nationalism, you get many _types_ of pan-nationalism, where you are grouping smaller groups together into another larger one, but this larger one _is still a strict subset and minority_ within the broader planetary population.

For example:

> [Pan-Slavism](https://en.wikipedia.org/wiki/Pan-Slavism) is another notable example of an influential ideal that never resulted in the corresponding mega-state – if Russian territory was included, it would extend from the Baltic to the Pacific (west to east) and right down to central Asia and the Caucasus/Black Sea/Mediterranean in the south.
> 
> [Pan-Americanism](https://en.wikipedia.org/wiki/Pan-Americanism) as an ideal was influential around the time of the [independence movements](https://en.wikipedia.org/wiki/Sim%C3%B3n_Bol%C3%ADvar) in [Latin America](https://en.wikipedia.org/wiki/Latin_America). However, the new nation-states soon diverged in policy and interests, and no federation emerged. The term acquired another meaning, namely U.S.-led co-operation among the separate nation-states, with a connotation of U.S. [hegemony](https://en.wikipedia.org/wiki/Hegemony). That is why there is a pan-Latin-Americanism which proposes inter-Americanism with the [United States](https://en.wikipedia.org/wiki/United_States). An important exponent of this philosophy is [Víctor Raúl Haya de la Torre](https://en.wikipedia.org/wiki/V%C3%ADctor_Ra%C3%BAl_Haya_de_la_Torre), from Peru, while [Bolivarianism](https://en.wikipedia.org/wiki/Bolivarianism) represents a current variation on the theme.
> 
> [Pan-Arabism](https://en.wikipedia.org/wiki/Pan-Arabism) favors the unification of the countries of the [Arab world](https://en.wikipedia.org/wiki/Arab_world), from the [Atlantic Ocean](https://en.wikipedia.org/wiki/Atlantic_Ocean) to the [Arabian Sea](https://en.wikipedia.org/wiki/Arabian_Sea).
> 
> [Pan-Islamism](https://en.wikipedia.org/wiki/Pan-Islamism) favors the unification of all Muslims, unlike most traditional pan-nationalist movements this is not based on race or ethnicity because it has been revitalised with religion at its core.

# My Pan-Nationalism

So, when I say Pan-Nationalism, what I mean is the idea of treating all nations the same, or something. It means humoring the conceit that people think their nation is important, that they want to draw some line around what is important. Very well.

If people are going to be so tied up in their group identities that they are so provincial and such bad company, then the only solution is to make it to where their idea of what subset they belong to, or which they trust in some way, is no longer tenable.

The whole idea is to induce spiritual emergency, emergence. This is why it can be love but also terrible.

So much of what I have to do is say okay, well I can reflect back to you what I’m getting. You might not like it, but you’re the one giving me this impression.

Basically the idea here is to ruin the idea of every nation. As James Lindsay would say, it’s making every national discourse speak “woke.” It’s just woke oozing structurally out of every pore. It’s oozing out in this psychedelic way where it’s not even straightforward domination yet you are all the more caught. 

Caught in the black tar baby. Black tar, baby.

As well as we could say we are letting woke ooze through every pore, every symbol, rising from the ashes of every sign we burn like some cross or some cop car, like some bridge—

Just as well, we are calling all nations to awaken in the sense of “DEUTSCHLAND ERWACHE.”

It’s intense for me to go there, but this connection is just out there in the open, this theme of waking up. It’s not my fault, again according to your cosmology probably, that this semantic connection exists.

It is a symbolic fact, a social fact, a total social fact. The total social facticity of the [Dreaming](https://en.wikipedia.org/wiki/The_Dreaming).

So in this sense, we don’t have to be saying of course just that nations are bad, why are people invested in them, etc. Of course in some sense I am so far beyond all this, haha, of course, the thing is that I’m contemplating shit that’s going to come up in Svarga down the line. The endless grief you can’t even contemplate, or something. The stuff I know you know I know you know but you won’t acknowledge and I know that and you know I know that and I know you know I know that, it’s all very complicated and very simple.

Anyways, just as well we can say that every national destiny can Converge. If you are so concerned with these stories of nations, then let me come beat them into plowshares for you.

# Just Joshin’

J is the 10th letter. 1010.

It turns out Revelation 19 is pretty groovy:

>  **19** And after these things I heard a great voice of much people in heaven, saying, Alleluia; Salvation, and glory, and honour, and power, unto the Lord our God:
> 
>  **2** For _true and righteous are his judgments_ : for he hath judged the great _whore_ , which did corrupt the earth with her _fornication_ , and hath avenged the blood of his servants at _her hand_.
> 
>  **3** And again they said, Alleluia And _her smoke_ rose up for ever and ever.
> 
>  **4** And the four and twenty elders and the four beasts fell down and worshipped God that sat on the throne, saying, Amen; Alleluia.
> 
>  **5** And a voice came out of the throne, saying, Praise our God, all ye his servants, and ye that fear him, both small and great.
> 
>  **6** And I heard as it were the voice of a great _multitude_ , and as the voice of many waters, and as the voice of mighty thunderings, saying, Alleluia: for the Lord God omnipotent reigneth.
> 
>  **7** Let us be glad and rejoice, and give _honour_ to him: for the marriage of the Lamb is come, and _his wife hath made herself ready_.
> 
>  **8** And to her was granted that she should be arrayed in _fine linen, clean and white_ : for the fine linen is the righteousness of _saints_.
> 
>  **9** And he saith unto me, Write, Blessed are they which are called unto the _marriage supper_ of the Lamb. And he saith unto me, _These are the true sayings of God_.
> 
>  **10** And I fell at his feet to worship him. And he said unto me, See thou do it not: _I am thy fellow servant_ , and of thy brethren that have the testimony of Jesus: worship God: for the testimony of Jesus is the spirit of prophecy.
> 
>  **11** And I saw heaven opened, and behold a _white horse_ ; and he that sat upon him was called _Faithful and True_ , and _in righteousness he doth judge and make war_.
> 
>  **12** His eyes were as a _flame of fire_ , and on his head were _many crowns_ ; and _he had a name written, that no man knew, but he himself_.
> 
>  **13** And he was clothed with a vesture dipped in _blood_ : and his name is called _The Word of God_.
> 
>  **14** And _the armies which were in heaven followed him_ upon _white horses_ , clothed in _fine linen, white and clean_.
> 
>  **15** _ **And out of his mouth goeth a sharp sword, that with it he should smite the nations**_ : and _he shall rule them with a rod of iron_ : and he treadeth the _winepress_ of the _fierceness_ and _wrath_ of Almighty God.
> 
>  **16** And he hath on his _vesture_ and on his _thigh_ a name written, King Of Kings, And Lord Of Lords.
> 
>  **17** And I saw an angel standing in the sun; and he cried with a loud voice, saying to all the fowls that fly in the midst of heaven, _Come and gather yourselves together unto the supper of the great God_ ;
> 
>  **18** That _ye may eat the flesh of kings_ , and the _flesh_ of captains, and the _flesh_ of mighty men, and the _flesh_ of horses, and of them that sit on them, and the _flesh_ of _all_ men, _both_ free and bond, _both_ small and great.
> 
>  **19** And I saw the beast, and the kings of the earth, and their armies, gathered together to make _war against him_ that sat on the horse, and against his army.
> 
>  **20** And the beast was taken, and with him _the false prophet_ that wrought miracles before him, with which he deceived them that had received the _mark of the beast_ , and them that worshipped his image. These both were cast alive into a _lake of fire_ burning with _brimstone_.
> 
>  **21** And the _remnant_ were slain with the sword of him that sat upon the horse, _which sword proceeded out of his mouth_ : and _all the fowls were filled_ with their _flesh_.

This is a nice little chapter.

I really enjoy the idea of a sword coming out of the mouth.

For me, this opens up immediately the idea of speech as an attack, that it’s sort of like the creatures in _Invasion of the Body Snatchers_ , where when they open their mouths they shriek, and that itself is terrifying and jarring.

This inducing of fear is itself a form of influence, it’s terrorism in the simplest sense.

So religious language is obviously emotional rape and emotional terrorism, but again: you’re doing it all the time so you basically don’t get to complain. You impose your little frames, so I have to do it back.

The problem is I can basically deploy so much. I can easily destroy any one person interpersonally, that is again back to _Woyzeck_ and what I mean there is this tragedy of lashing out at the dimwits that you can actually get to versus confronting the larger situation.

It’s in that sense that I am fundamentally asking for help, but if you can’t lend a hand then _get out of my road_.

# Shared Future For Mankind

# Highway Of The Consistent

I guess we are actually using the term “[community of common destiny](https://en.wikipedia.org/wiki/Community_of_Common_Destiny)” now.

Don’t get me wrong, “China” can give creepy vibes. It’s giving “[Greater East Asia Co-Prosperity Sphere](https://en.wikipedia.org/wiki/Greater_East_Asia_Co-Prosperity_Sphere)” vibes.

That’s exactly because the whole idea of “China,” of the coherence of a political party, etc., is part of the problem.

There is no “China” any more than there is “America.” 

Back to Budhadasa and the idea of [No Religion](https://www.suanmokkh.org/books/127):

> Buddhadāsa Bhikkhu sincerely believes that world peace is possible, if humanity would only conquer the _selfishness_ which is the cause of all our conflicts and troubles. Moreover, he insists _that the world’s religions are the most important vehicles_ for propagating _unselfishness_. In this book, he digs into the heart of _selfishness_ , namely, _attachment_ to ‘I’ and ‘mine,’ and points to the unselfish remedy. _We hope that readers will find it useful_ in their own spiritual lives and in _our common search for lasting peace_.

Okay, so let’s try to build this out, this “selfishness.”

It’s also related to self-ignorance again, spiritual warrior in Tibetan Buddhism and again Greater Jihad.

With Greater Jihad it’s like well obviously you should do Greater Jihad to where you realize gutting the genitals of infants is better not done. That’s where it’s like, well obviously you have strayed from the ways of God, or whatever, lol.

It’s a simple idea of why would the creator make part of the body designed to be removed? 

At a higher logical type we can ask why did the creator leave these partial and harmful traditions like circumcision and other social control mechanisms which now lock us in and seemingly doom us to a life without love?

Or see here again Budhadasa:

> If they listen to people language, those who wish to gain _merit_ , _goodness_ , or _whatever must pay in money, silver, and gold, or invest their labor_. If they listen to Dhamma language, however, _the reality is quite different_. The Buddha said that Nibbāna is given _free_ of charge. Nibbāna – _the coolness and peace experienced when there's no attachment_ – doesn't cost a penny. This means that we can practice for the sake of Nibbāna without spending any money along the way. Jesus said what amounts to the same thing. _He invited us to drink the water of life for which there is no charge_. He said this at least three times. Further, he called us to enter _eternal_ life, which means _to reach the state where we are one with God and therefore will never die again_. 
> 
> ‘ _Let him who is thirsty come, let him who desires take the water of life without price_ ’ (Rev. 22:17). This call of Jesus is identical to what is taught in Buddhism. The Buddha said that the Noble Path of Liberation, the Liberating Results, and Nibbāna are free of charge, no monetary investment is required. We live according to the Noble Eightfold Path, which means _we give up this, give up that, and keep giving up things until everything is surrendered_. [See [Unconditional Surrender](https://en.wikipedia.org/wiki/Unconditional_surrender) or [Unconditional Love](https://en.wikipedia.org/wiki/Unconditional_love)] Give up _everything_ and take _nothing_ back. [“But you don’t get anything back!” No, I get _nothing_ (Calvin Warren: “Would that include a penis from this blackness?”)] _Don't receive any payment and we won't have to pay anything_ : [Charge not, lest ye be charged] we will realize what is called ‘the Noble Path, the Liberating Results, and Nibbāna.’ We can taste the flavor of Nibbāna without paying a penny.

Now go back to Revelation Chapter 22:

>  **22** And he shewed me a _pure_ river of _water_ of life, clear as _crystal_ , proceeding out of the throne of God and of the Lamb.
> 
>  **2** In the midst of the street of it, and on either side of the river, was there the tree of life, which bare twelve manner of fruits, and yielded her fruit every month: and _the leaves of the tree were for the healing of the nations_. [“[When the leaves begin to fall/ I try to catch 'em all](https://www.youtube.com/watch?v=IdGERIxNJJU)” - Claire Elise Boucher]
> 
>  **3** And there shall be no more curse: but the throne of God and of the Lamb shall be in it; and _his servants shall serve him_ :
> 
>  **4** And they shall see his face; and _his name shall be in their foreheads_.
> 
>  **5** And there shall be no night there; and they need no candle, neither light of the sun; for the Lord God giveth them light: _and they shall reign for ever and ever_.
> 
>  **6** And he said unto me, These sayings are faithful and true: and _the Lord God of the holy prophets sent his angel to shew unto his servants the things which must shortly be done_.
> 
>  **7** Behold, I come quickly: _blessed_ is he that _keepeth_ the _sayings of the prophecy_ of this book.
> 
>  **8** And I John saw these things, and heard them. And when I had heard and seen, I fell down to worship before the feet of the angel which shewed me these things.
> 
>  **9** Then saith he unto me, See thou do it not: _for I am thy fellow servant_ , and of thy brethren the prophets, and of them which keep the sayings of this book: _worship God_.
> 
>  **10** And he saith unto me, Seal not the sayings of the prophecy of this book: _for the time is at hand_.
> 
>  **11** He that is _unjust_ , let him be _unjust_ still: and he which is _filthy_ , let him be filthy _still_ : and he that is righteous, _let him be_ righteous still: and he that is holy, let him be holy _still_.
> 
>  **12** And, behold, _I come quickly; and my reward is with me, to give every man according as his work shall be_.
> 
>  **13** _I am Alpha and Omega, the beginning and the end, the first and the last_.
> 
>  **14** Blessed are they that do his commandments, that they may have right to the tree of life, and may enter in through the gates into the city.
> 
>  **15** For without are dogs, and sorcerers, and whoremongers, and murderers, and idolaters, and _whosoever loveth and maketh a lie_.
> 
>  **16** I Jesus have sent mine angel to testify unto you these things in the churches. I am the root and the offspring of David, and the bright and morning star.
> 
>  **17** _And the Spirit and the bride say, Come_. And let him that heareth say, Come. And let him that is athirst come. _And whosoever will, let him take the water of life freely_.
> 
>  **18** For I testify unto every man that heareth the words of the prophecy of this book, If any man shall add unto these things, God shall add unto him the plagues that are written in this book:
> 
>  **19** And if any man shall take away from the words of the book of this prophecy, God shall take away his part out of the book of life, and out of the holy city, and from the things which are written in this book.
> 
>  **20** He which testifieth these things saith, Surely I come quickly. Amen. Even so, come, Lord Jesus.
> 
>  **21** The grace of our Lord Jesus Christ be with you all. Amen.

Oh, I forgot to mention: related to the idea of true and righteous judgments of God from Revelation 19, see Lincoln’s Second Inaugural, which also ties into Revelation 22 in the idea of healing the nations:

> Neither party _expected_ for the war the _magnitude_ or the _duration_ which it has _already_ attained. Neither anticipated that the cause of the conflict might cease _with_ or _even before_ the conflict itself should cease. Each looked for an _easier_ triumph, and a result _less fundamental_ and astounding. 
> 
> Both read _the same Bible_ and pray to _the same God_ , and each invokes His aid against the other. 
> 
> It may seem strange that any men should dare to ask a just God's assistance in wringing their bread from the sweat of other men's faces, but let us _judge not, that we be not judged_. [Industry and usury and mass cognitive warfare and emotional enslavement do this just as whips do]
> 
> The prayers of both could not be answered. That of neither has been answered fully. The Almighty has _His own purposes_. "Woe unto the world because of offenses; for it must needs be that offenses come, but woe to that man by whom the offense cometh."
> 
> If we shall suppose that American slavery is one of those offenses which, in the providence of God, _must needs come, but which, having continued through His appointed time, He now wills to remove_ , and that He gives to both North and South this terrible war as the woe due to those by whom the offense came, shall we discern therein any departure from those divine attributes which the believers in a living God always ascribe to Him? 
> 
> _Fondly do we hope, fervently do we pray_ , that this mighty scourge of war may speedily pass away. Yet, if God wills that it continue until all the wealth piled by the bondsman's two hundred and fifty years of unrequited toil shall be sunk, and until every drop of blood drawn with the lash shall be paid by another drawn with the sword, as was said three thousand years ago, so still it must be said " _the **judgments** of the Lord are **true and righteous** altogether_."
> 
> [This ties into Revelation 19:2: “For _**true and righteous** are his **judgments**_ : for he hath judged the great _whore_ , which did corrupt the earth with her _fornication_ , and hath avenged the blood of his servants at _her hand.”]_
> 
>  _With malice toward none, with charity for all_ , with firmness in the right as God gives us to see the right, let us strive on to finish the work we are in, _to bind up the nation's wounds_ , [in other words, to “heal the nation”] to care for _him who shall have borne the battle_ [the secret is that everyone is a soldier in the forever war] and for his widow and his orphan, to do all which may achieve and cherish a _just and lasting peace among ourselves and with all nations_.

Now the basic thing to say is that what can heal one nation is only what can heal all the nations, which is also the same as smiting the nations. So the sword and the leaves are combining.

We’re also going into _Leaves Of Grass_ territory, which I don’t know anything about but we’ll get there.

# No Peace (Full Stop)

Peace is an outmoded paradigm.

From the China cognitive warfare document:

> These three wars are mutually reinforcing: the _propagation of discourse_ includes the _strategic narrative_ to convince domestic and foreign populations through the vectors of _transmission_ ( _war of opinion_ ) by _creating a favorable mental environment_ ( _psychological warfare_ ) that _makes the message conform to preconceptions_ , while _protecting_ itself behind the logic of cyber sovereignty, which China is trying to impose legally at the international level ( _legal warfare_ ). 
> 
> Furthermore, _**cognitive warfare does not differentiate between war and peace**_ , between combatant and non-combatant, ( _everyone is a potential target_ […potential?]), and it is _permanent_. 
> 
> This is a major difference with the West, _where there is a differentiation between war and peace_. 
> 
> [Only in public; plenty of people are in the know, but none of them will talk to me. Meanwhile as I say, most people are ordering off the conceptual kid’s menu.]
> 
> At the end of the 20th century, the publication of the monograph _Unrestricted Warfare_ by two Chinese army colonels, Qiao and Wang (2006), marked an important step in understanding contemporary strategic thinking in Beijing. 
> 
> According to the authors, _technological developments, globalization and the rise of power beyond the nation-state_ , combined with _the new capabilities of modern weapons_ , would provide a new context for conflict. 
> 
> Battlefields would thus shift from a physical dimension to _a more abstract arena_ such as cyberspace, _the morale of the population or their brains_. 
> 
> In other words, Qiao and Wang demonstrate that war is no longer “the use of armed force to force the enemy to bend to our wishes,” but rather “ _all means_ , whether armed or _unarmed_ , military or non-military force... [uses] to _force the enemy to submit to its own interests_.” 
> 
> [Which is basically what we all do to each other; you just try to act like you’re not doing it because it’s part of your strategy. Respect, I get it. But also fuck you and the horse you rode in on.]
> 
> As a result, _the battlefield is everywhere_ , war is no longer a purely military concept but also becomes civil. 
> 
> [I’m so glad my life is less intense than _Succession_! Who says that…?]
> 
> This has two consequences: firstly, the victims of these new wars will not only be regular combatants who die on the battlefield, but also civilians who are _indirectly affected_. 
> 
> [It’s being directly affected, just non-kinetically, this is more dissimulation or incompetence]
> 
> Secondly, war is _permanent_ and _holistic_ , _all forces and means are combined._
> 
> [Do you see what happens what you fuck a stranger in the ass?] 
> 
> Finally, the authors argue that _the only rule is that_ _there are no rules_. 
> 
> Thus, military threats are no longer necessarily the main factor affecting the national security of a country. The intent is not necessarily to defeat the West on the battlefield, but to weaken _the democracies_ [“the democracies”] to such a point, “they are unable, or unwilling, to respond to aggression” (Zeman, 2021).

Again it’s playing coy, like “Westerners” aren’t so cynical.

Look, I don’t have time for this bullshit, this “Uh oh China doesn’t have our norms and ethics so oopsie I guess we have to do human experimentation” or whatever.

It really is disgusting to sit here and dance around your feeling that you are the fucktoy prosthesis adjunct of a concentration camp attached to a plastic surgery shopping mall and you’re looking at me like I’m the one with conceptual lip fillers.

I’m thinking of Dylan in “A Hard Rain’s A-Gonna Fall” talking about “Guns and sharp swords in the hands of young children.”

Absolutely, let younger people take over your conceptual weapons. I wish it so much. I am always rooting for the underdog.

Or Selina Kyke in _Dark Knight Rises_ going on about how did you think you could leave so little for the rest of us?

How did you think you could leave so much for me to focus on?

That is why this pan-nationalism is whipping all you little nations into shape.

It is showing you how to wear yourselves because you are disgrace to any tradition you are are trying to uphold. Like, just in case you were wondering whether anyone could tell that you’re doing a terrible job: I can tell you are doing a terrible job and I’m very angry at you for it.

# But Adam, “Pan-Nationalism” is Fascism

See for example [this article](https://www.sciencedirect.com/org/science/article/pii/S2211624922000018), which is helpfully accessible for me at the moment:

> To better understand cross-border fascist solidarity, this article suggests a _new conceptual framework_ revolving around the term ‘pan-fascism’ and its ‘paradox’. It argues that the existence or non-existence of a pan-fascist ‘paradox’ in the minds of historical fascists is a matter of optics, as it all depends on who is mobilizing the notion of _fascist transnationalism_. Because of such optical issues, which all must be unpacked historically, the conceptual framework of ‘pan-fascism’ does not offer a simple solution. It, rather, puts emphasis on a key question: how did certain fascists, at various moments in their lives, think about the possibility of fascist transnationalism? To demonstrate the effectiveness of this approach, this paper takes the work, thought, and practices of the French editors of _Je suis partout_ as a case study, and demonstrates how they attempted to reconcile their commitment to French nationalism with fascist transnationalism.

With this idea of transnationalism we can be thinking of “Transnational America” by Randolph Borne. Do we think Borne’s position is basically the same as fascism? What are the stakes here?

[Excerpt](https://americainclass.org/wp-content/uploads/2012/05/12-Bourne.pdf):

> The war [World War I] has shown America to be unable, though isolated geographically and politically from a European world-situation, to remain aloof and irresponsible. 
> 
> She is a wandering star in a sky dominated by two colossal constellations of states. Can she not work out some position of her own, some life of being in, yet not quite of, this seething and embroiled European world? This is her only hope and promise. 
> 
> _A trans-nationality of all the nations,_ it is spiritually impossible for her to pass into the orbit of any one. 
> 
> It will be folly to hurry herself into a premature and sentimental nationalism, or to emulate Europe and play fast and loose with the forces that drag into war. 
> 
> _No Americanization will fulfill this vision which does not recognize the uniqueness of this trans-nationalism of ours_. 
> 
> The Anglo- Saxon attempt to fuse will only create enmity and _distrust_. [Hobbesian Trap]
> 
> The crusade against 'hyphenates' will only inflame the partial patriotism of trans-nationals, and cause them to assert their European traditions in strident and unwholesome ways. 
> 
> But the attempt to weave _a wholly novel international nation_ out of our _chaotic_ [See Claire Elise Boucher and Chaos references, again also to Greek mythology connection to water, ocean rising up above the ground, lift the heart from the depths it’s fallen to, tidal waves couldn’t save the world from Californication, I didn’t think you’d end up treating me so bad, etc.] America will _liberate_ and _harmonize_ the _creative power_ of all these peoples and give them the new _spiritual citizenship_ , as so many individuals have already been given, of a _world_.

This is where we are back to Andrew Santana Kaplan’s [article](https://ojs.lib.uwo.ca/index.php/chiasma/article/download/16873/12978/43482) “Towards An Apocalyptic Hauntology Of Black Messianicity,” where the issues with the concept of a world are laid out:

> Accordingly, for the Human to become Black—that is, to learn the steps to _the dance of social death_ —one must iterably leap into _worldlessness_. 
> 
> The necessarily _iterable_ [see abstraction, logical types] structure of this leap is twofold: 
> 
> 1) since the Human’s acceptance of the Black’s invitation to the dance of social death is contingent—whereas the Black is gratuitously constituted in social death—Humans constitutively cannot “become Black” as long as the World persists; and, following Derrida, 
> 
> 2) the structure of the trace (of the Other) marks an originary repetition—or what Chandler emphasizes as an originary displacement, which “the Negro” incarnates—that yields the conditions of im/possibility for any fidelity to the (wholly) Other.
> 
> In this way, from the position of the Human, deconstruction allows us to understand and inhabit the meta-aporetic demand of Cone’s question (how to become Black?) and Wilderson’s answer (to die) as an iterable embrace of worldlessness—i.e. as an iterable refusal of our coordinates—in which the Human’s asymptotic fidelity to Blackness marks the quasi-transcendental condition for (the coming of) any justice worthy of the name.

The issue with Borne is that of course it is not so simple to “harmonize” everyone.

In order for this to happen, for the Highway of the Consistent to be walked, everyone has to change.

For example [here](https://www.tandfonline.com/doi/full/10.1080/09636410903133050#d1e2228):

> A deadlock is almost impossible to unwind because _it would require both sides to change their mind-set_. An expansionist threat is also difficult, but not impossible, to unwind. When the expansionist state decides it no longer wants to expand, the situation is then changed into a genuine, but still deep, security dilemma.

So, everyone’s mindset must be shifted. The move to pan-nationalism as part of a larger/more intricate pan-syncretism of all experience and all sentient beings into an amalgamated manifold of apotheosis leading into apokatastasis follows from there.

It’s quite important not to be engaged in any discourse for its own sake, at a first-order level, but always dealing with things there is no time to say, and so which must remain mysteries for the obliviously captive audience.

To be continued!

---
title: Claude On Zweibelson's "Newtonianism" & Euclidean Geometry
subtitle: Not just topical but topological
author: Adam Wadley
publication: Experimental Unit
date: December 05, 2025
---

# Claude On Zweibelson's "Newtonianism" & Euclidean Geometry
[![](https://substackcdn.com/image/fetch/$s_!puG7!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F26f91eb8-925b-4c3e-95a6-78cd214700e4_1536x1024.png)](https://substackcdn.com/image/fetch/$s_!puG7!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F26f91eb8-925b-4c3e-95a6-78cd214700e4_1536x1024.png)

# The Euclidean Foundations of Newtonian Military Thought

## Introduction

[Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions)’s critique of the “Newtonian fetish”[1](https://experimentalunit.substack.com/p/claude-on-zweibelsons-newtonianism#footnote-1-180804810) in military thinking necessarily implicates Euclidean geometry, though he doesn’t always distinguish the two explicitly. This is understandable—Newton built his physics on Euclidean foundations, and the two became so intertwined in Western thought that separating them requires deliberate effort. Yet the distinction matters, because some of what military doctrine treats as “scientific” reasoning actually predates modern science by two millennia, rooted in geometric intuitions that Euclid systematized around 300 BCE.

This analysis examines how Euclidean geometry and Newtonian physics overlap, reinforce each other, and jointly constitute the conceptual infrastructure of modern military thought. Understanding this relationship clarifies what’s actually being challenged when critics call for post-Newtonian frameworks—and reveals how deep the roots of current thinking actually go.

* * *

## Part I: The Historical Entanglement

### 1.1 Euclid’s Foundation

Euclid’s _Elements_ (circa 300 BCE) didn’t just systematize geometry—it established a model for what rigorous knowledge looks like. Starting from a small set of definitions, postulates, and common notions, Euclid derived hundreds of propositions through logical deduction. This axiomatic method became the template for legitimate reasoning across domains far beyond mathematics.

Key features of Euclidean geometry:

 **Axiomatic structure** : Start with self-evident truths, derive everything else through logic. No appeals to authority, tradition, or revelation—only what can be proven from first principles.

 **Definitions that carve reality** : Points have no parts. Lines have length but no breadth. Planes extend infinitely in two dimensions. These aren’t descriptions of physical objects but idealizations that enable precise reasoning.

 **Constructibility** : Valid geometric objects are those that can be constructed with compass and straightedge. This links abstract concepts to concrete procedures.

 **Proof as validation** : A claim isn’t knowledge until it’s proven. Proof means showing logical necessity given the axioms.

 **Universality** : Geometric truths hold everywhere, always, for everyone. The angles of a triangle sum to 180 degrees in Athens and Alexandria alike.

### 1.2 Newton’s Appropriation

When Newton wrote the _Principia Mathematica_ (1687), he explicitly modeled it on Euclid’s _Elements_. He began with definitions (mass, motion, force), stated laws (the three laws of motion), and derived consequences through geometric and algebraic reasoning. This wasn’t just stylistic homage—Newton believed that physics, like geometry, could achieve certainty through axiomatic deduction.

Newton’s physics required Euclidean geometry as its spatial framework:

  * Space is three-dimensional, uniform, and infinite

  * Objects occupy positions in this space

  * Motion is change of position over time

  * Forces act along straight lines

  * Distances and angles are measurable and consistent




The marriage was so complete that for two centuries, questioning Euclidean geometry seemed equivalent to questioning the structure of physical reality itself. Kant famously argued that Euclidean geometry was a synthetic a priori truth—not learned from experience but built into how human minds necessarily structure perception.

### 1.3 The Military Inheritance

Military institutions absorbed this Euclidean-Newtonian synthesis through multiple channels:

 **Fortification and siege warfare** : Vauban’s geometric approach to fortification design applied Euclidean principles directly. Angles of fire, fields of observation, and defensive geometries could be calculated precisely.

 **Navigation and cartography** : Naval and land forces required accurate maps and navigation, both grounded in Euclidean assumptions about space.

 **Artillery science** : Ballistics applied Newtonian mechanics to projectile motion, requiring geometric calculation of trajectories.

 **Staff education** : As military education professionalized in the 18th-19th centuries, mathematics (especially geometry) became core curriculum. Officers learned to think geometrically.

 **Operational art** : The conceptualization of campaigns as movements through space—lines of operation, interior vs. exterior lines, concentration and dispersion—imported geometric reasoning to strategic scale.

By the time Fuller and other 20th century theorists sought to make war “scientific,” they inherited frameworks already saturated with Euclidean-Newtonian assumptions. They weren’t imposing something foreign on military thought; they were systematizing and extending what was already there.

* * *

## Part II: Overlapping Assumptions

### 2.1 Space

[![](https://substackcdn.com/image/fetch/$s_!A0C9!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F312a089f-f2b2-4100-9747-915256682015_923x406.png)](https://substackcdn.com/image/fetch/$s_!A0C9!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F312a089f-f2b2-4100-9747-915256682015_923x406.png)

 **The shared assumption** : Space is a neutral, pre-existing container that doesn’t affect what happens within it. Objects and forces move through space, but space itself is passive backdrop.

 **What this excludes** : Space that’s constituted by relationships rather than containing them. Space that’s curved, bounded, or discontinuous. Space where position itself affects properties.

 **Military consequence** : The “operational environment” is treated as mappable terrain through which forces maneuver, rather than as a dynamic system co-produced by the forces acting within it. Cyber and information “domains” get shoehorned into spatial metaphors that may not fit.

### 2.2 Objects and Boundaries

[![](https://substackcdn.com/image/fetch/$s_!7WOF!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9feefb12-0721-4a64-870d-80412dcfa001_927x396.png)](https://substackcdn.com/image/fetch/$s_!7WOF!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9feefb12-0721-4a64-870d-80412dcfa001_927x396.png)

 **The shared assumption** : Things are discrete, bounded, and distinguishable from their environments. You can draw a line around an object (or force, or domain) and treat what’s inside as meaningfully separate from what’s outside.

 **What this excludes** : Fuzzy boundaries, overlapping entities, objects constituted by their relationships rather than bounded against them. Networks where nodes only exist through connections.

 **Military consequence** : Order of battle analysis treats units as discrete entities with countable properties. But insurgent networks, information ecosystems, and cyber actors may not have the clean boundaries this framework assumes.

### 2.3 Measurement and Quantification

[![](https://substackcdn.com/image/fetch/$s_!a5gb!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe16b2fb0-235e-4ae4-9f31-69b9ca7caa73_921x399.png)](https://substackcdn.com/image/fetch/$s_!a5gb!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe16b2fb0-235e-4ae4-9f31-69b9ca7caa73_921x399.png)

 **The shared assumption** : Reality has quantitative structure that measurement reveals. More precise measurement means better understanding. What’s real is what’s measurable.

 **What this excludes** : Qualitative differences that resist quantification. Measurement that constitutes rather than reveals. Properties that change when observed.

 **Military consequence** : Overwhelming preference for quantifiable metrics (body counts, sorties flown, terrain controlled) over qualitative assessment. Difficulty incorporating legitimacy, morale, narrative, and meaning into analysis.

### 2.4 Causation and Mechanism

[![](https://substackcdn.com/image/fetch/$s_!JQi-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa52a13bd-723a-45f7-8c75-be181be5af51_917x403.png)](https://substackcdn.com/image/fetch/$s_!JQi-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa52a13bd-723a-45f7-8c75-be181be5af51_917x403.png)

 **The shared assumption** : Causation is linear, local, and traceable. Effects connect to causes through identifiable mechanisms. Understanding the mechanism allows prediction and control.

 **What this excludes** : Circular causation (feedback loops), action at a distance without mechanism, emergent causation where effects exceed causes, overdetermination and underdetermination.

 **Military consequence** : Effects-based operations assume clear causal pathways from action to desired outcome. But complex systems feature nonlinear causation where interventions produce unintended consequences through pathways that weren’t—and perhaps couldn’t be—anticipated.

### 2.5 Logic and Proof

[![](https://substackcdn.com/image/fetch/$s_!bx0T!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6fd9475a-3572-4a14-9444-73cad1f4d2ed_928x405.png)](https://substackcdn.com/image/fetch/$s_!bx0T!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6fd9475a-3572-4a14-9444-73cad1f4d2ed_928x405.png)

 **The shared assumption** : Valid reasoning follows formal rules. Conclusions reached through valid inference from true premises are themselves true. The system of knowledge is consistent and (ideally) complete.

 **What this excludes** : Undecidable propositions, irreducible ambiguity, productive contradictions, reasoning that’s valid in context but not universalizable.

 **Military consequence** : Doctrine aspires to completeness—a framework that covers all situations. But Gödel showed that sufficiently rich formal systems are necessarily incomplete, and complex warfare may be similarly inexhaustible by any doctrinal system.

### 2.6 Representation and Visualization

[![](https://substackcdn.com/image/fetch/$s_!Pcn_!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdcda2c3b-fd65-4c1e-acfc-526f71f419ba_919x403.png)](https://substackcdn.com/image/fetch/$s_!Pcn_!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdcda2c3b-fd65-4c1e-acfc-526f71f419ba_919x403.png)

 **The shared assumption** : Reality can be represented in forms that preserve essential structure while enabling manipulation. Working on the representation is equivalent (for relevant purposes) to working on the reality.

 **What this excludes** : Aspects of reality that resist representation, representations that distort what they aim to capture, the map-territory problem where acting on representations diverges from acting on reality.

 **Military consequence** : Heavy investment in maps, models, simulations, and decision support tools. But these representations embed assumptions that may not hold—the cyber domain doesn’t map to physical space the way doctrine implies.

* * *

## Part III: The Geometric Grammar of Military Thought

Beyond specific overlapping assumptions, Euclidean geometry provides a kind of grammar—a set of structural patterns that shape how military concepts are formed and related.

### 3.1 Points, Lines, and Planes

 **The point** is the fundamental atom of Euclidean geometry—location without extension. Military thinking imports this in multiple ways:

  *  **Objectives** as points to be seized or destroyed

  *  **Targets** as points of application for force

  *  **Decisions** as points in time when choices are made

  *  **Centers of gravity** as critical points whose neutralization defeats systems




The conceptual move is always toward identifying _the_ point that matters—the decisive terrain, the key leader, the critical vulnerability. This reflects a Euclidean intuition that complexity can be reduced to points that, if properly addressed, resolve the whole.

 **The line** connects points and provides direction:

  *  **Lines of effort/operation** as paths toward objectives

  *  **Axes of advance** as directions of movement

  *  **Command relationships** as lines of authority

  *  **Communications** as lines connecting nodes

  *  **Supply** as lines sustaining forces




Lines impose sequence and direction. Movement along a line is progress; movement perpendicular to it is deviation. The metaphor structures how planning unfolds—identifying the line, then ensuring actions align with it.

 **The plane** is the surface on which figures are drawn:

  *  **Domains** as planes of operation (land, sea, air, cyber, space)

  *  **Levels of war** as stacked planes (strategic, operational, tactical)

  *  **The common operational picture** as a shared plane of understanding




Planes enable comprehensive representation—everything relevant can be positioned on the plane, and relationships can be read from positions. But forcing three-dimensional (or higher-dimensional) phenomena onto planes inevitably distorts.

### 3.2 Shapes and Their Properties

Euclidean shapes have fixed, determinable properties—the triangle’s angles sum to 180 degrees, the circle’s circumference relates to diameter by π. Military concepts import this determinacy:

  *  **Doctrinal models** specify how concepts relate with similar determinacy

  *  **Planning factors** calculate requirements from fixed ratios

  *  **Force ratios** assume predictable relationships between quantity and outcome

  *  **Templating** assumes enemy forces have characteristic shapes recognizable through analysis




The underlying intuition: military phenomena have stable, discoverable properties analogous to geometric properties. Once you know the shape (enemy force, terrain, friendly capability), you can deduce its properties.

### 3.3 Congruence and Similarity

Two figures are congruent if they have identical shapes and sizes; similar if same shape but different scale. This enables:

  *  **Standardization** of units (all infantry battalions are congruent in relevant respects)

  *  **Scalability** of concepts (what works at battalion works, scaled up, at division)

  *  **Comparison** across cases (this battle is similar to that historical battle)

  *  **Templates** (enemy formations are congruent across instances)




The assumption is that relevant properties scale predictably. But complex systems often feature scale-dependent behavior—what works at one level may not work at another, and historical analogies may mislead when contexts differ in nonobvious ways.

### 3.4 Transformation and Invariance

Euclidean transformations (rotation, translation, reflection) preserve essential properties. This enables:

  *  **Transfer of lessons** across theaters (what worked in Iraq applies, transformed, to Afghanistan)

  *  **Replication of success** (best practices transfer across units)

  *  **Planning timelines** (slide the operation forward or backward in time without changing logic)

  *  **Mirror imaging** (enemy thinks like we do, transformed by their perspective)




The assumption is that transformations preserve what matters. But complex adaptive systems may have properties that don’t survive transformation—context-dependencies that make transfer unreliable.

### 3.5 Construction and Proof

Euclidean construction shows how to produce a figure meeting specified conditions. Euclidean proof shows why a proposition must be true. Military planning imports both:

  *  **Planning as construction** : Given objectives and resources, construct a sequence of operations that achieves the objective

  *  **Wargaming as proof** : Test whether the plan necessarily achieves its aims given assumptions about enemy response

  *  **Doctrine as theorem** : Given principles (axioms), derive specific guidance (theorems) for situations




The assumption is that valid plans can be constructed and their validity demonstrated in advance. But complex warfare may not admit such construction—too many unknowns, too much emergence, too much adversary adaptation.

* * *

## Part IV: Where They Diverge

Despite deep overlap, Euclidean geometry and Newtonian physics aren’t identical. Understanding where they diverge clarifies what each contributes to military thought.

### 4.1 Statics vs. Dynamics

Euclidean geometry is fundamentally static—it describes figures frozen in timeless relationships. The angles of a triangle don’t change; they simply _are_ 180 degrees summed.

Newtonian physics adds dynamics—change over time governed by laws. Objects move, forces act, systems evolve. The laws describe _how_ things change, not just _what_ things are.

 **Military implication** : Euclidean contributions tend toward static analysis—terrain analysis, order of battle, force ratios. Newtonian contributions add temporal dimension—campaign phasing, operational tempo, decision cycles.

The combination produces a peculiar framework: dynamic processes analyzed through static snapshots. The operation is planned as a sequence of static states, with transitions between them governed by quasi-mechanical laws.

### 4.2 Pure vs. Applied

Euclidean geometry is pure mathematics—its truths hold regardless of physical reality. Whether physical space is actually Euclidean is a separate question from whether Euclidean theorems are valid.

Newtonian physics makes empirical claims about how the physical world works. Its laws can be (and eventually were) falsified by observation.

 **Military implication** : Some military concepts inherit Euclidean certainty-aspiration—principles of war as timeless truths independent of context. Others inherit Newtonian empiricism—doctrine as codified experience subject to revision. The tension between these produces debates over whether military “principles” are genuinely universal or merely historically contingent generalizations.

### 4.3 Necessity vs. Contingency

Euclidean proofs demonstrate necessary truths—given the axioms, the theorems _must_ be true. There’s no possible Euclidean world where the Pythagorean theorem fails.

Newtonian laws describe contingent regularities—they happen to hold in this universe, but nothing about logic requires them. God could have created a universe with different physics.

 **Military implication** : Some doctrinal concepts are treated as logically necessary (any competent planner must consider ends-ways-means), while others are treated as empirically established (concentration of force generally succeeds). Conflating these produces pseudo-necessary claims that are actually contestable generalizations.

### 4.4 Abstraction Level

Euclidean geometry operates at high abstraction—points, lines, and planes aren’t physical objects but idealizations. Physical objects approximate geometric ideals but never perfectly instantiate them.

Newtonian physics aims to describe actual physical objects, though it too uses idealizations (frictionless surfaces, point masses) for tractability.

 **Military implication** : Some military concepts are explicitly idealized (the “rational actor” in deterrence theory), while others claim to describe actual entities (enemy centers of gravity). Confusion about abstraction level produces errors—treating idealizations as descriptions, or treating descriptions as idealized.

* * *

## Part V: The Compound Framework

Euclidean geometry and Newtonian physics combine in military thought to produce a compound framework with distinctive features:

### 5.1 The Operational Environment as Geometric-Physical Hybrid

The “operational environment” in doctrine combines:

  * Euclidean space (uniform, continuous, measurable)

  * Newtonian objects (forces with mass moving through space)

  * Geometric boundaries (domains, areas of operation, boundaries)

  * Physical processes (movement, engagement, attrition)




This hybrid allows sophisticated analysis within its assumptions but struggles when those assumptions fail—as they increasingly do in cyber, space, and irregular warfare.

### 5.2 Planning as Geometric Construction + Physical Prediction

Military planning combines:

  * Geometric construction (design a campaign that leads to the objective)

  * Physical prediction (anticipate how forces will interact over time)

  * Logical proof (demonstrate that the plan achieves its aims)




The planner is simultaneously Euclidean geometer (constructing paths through possibility space), Newtonian physicist (predicting how actions produce effects), and logician (proving validity of the construction).

### 5.3 Doctrine as Axiom System + Empirical Generalization

Military doctrine combines:

  * Axiomatic principles (foundational tenets taken as given)

  * Derived guidance (specific procedures following from principles)

  * Empirical generalizations (lessons learned codified as rules)




The structure mimics Euclidean axiomatic systems, but the content includes empirical claims subject to disconfirmation. This creates instability—doctrine presents contingent generalizations with the rhetorical force of necessary truths.

### 5.4 Assessment as Geometric Measurement + Mechanical Causation

Military assessment combines:

  * Geometric measurement (quantifying force ratios, terrain controlled, objectives achieved)

  * Causal attribution (this action produced that effect)

  * Logical evaluation (did the plan achieve its proof?)




Success is determined by measuring outcomes against geometric criteria and attributing causation along mechanical pathways. Effects that resist measurement or attribution become invisible to the framework.

* * *

## Part VI: What Both Exclude

The Euclidean-Newtonian compound framework systematically excludes phenomena that violate its assumptions. Understanding these exclusions reveals why the framework struggles with contemporary warfare.

### 6.1 Non-Euclidean Geometries

In the 19th century, mathematicians discovered that Euclid’s parallel postulate could be replaced with alternatives, producing equally consistent geometries:

  *  **Hyperbolic geometry** : Through a point not on a line, infinitely many parallels exist

  *  **Elliptic geometry** : Through a point not on a line, no parallels exist

  *  **Riemannian geometry** : Curvature varies from point to point




These geometries proved not merely mathematical curiosities—Einstein’s general relativity describes spacetime using Riemannian geometry. Space itself is curved by mass-energy.

 **Military exclusion** : Doctrine assumes flat operational space. But information environments, social networks, and cyber terrain may have intrinsic curvatures that flat maps distort. Influence doesn’t propagate uniformly; some paths are “shorter” than geometric distance suggests.

### 6.2 Topology

Topology studies properties preserved under continuous deformation—what remains invariant when you stretch, bend, and twist without cutting or gluing. Topological properties include:

  * Connectedness (can you get from any point to any other?)

  * Number of holes (a donut differs from a sphere)

  * Orientability (Möbius strips and Klein bottles)

  * Boundaries (does the surface have edges?)




 **Military exclusion** : Doctrine emphasizes metric properties (distances, areas, ratios) over topological properties (connectivity, holes, orientability). But network warfare may depend more on topology than metric—who’s connected to whom matters more than how far apart they are.

### 6.3 Non-Newtonian Physics

20th century physics revealed Newtonian mechanics as a limiting case valid at human scales and speeds:

  *  **Quantum mechanics** : At small scales, determinism fails; measurement affects outcomes; particles lack definite properties until observed

  *  **Relativity** : At high speeds, space and time interrelate; simultaneity is relative; mass and energy convert

  *  **Chaos theory** : Deterministic systems can be unpredictable; sensitivity to initial conditions; strange attractors

  *  **Complexity science** : Emergence, self-organization, adaptation; wholes exceeding sums of parts




 **Military exclusion** : Doctrine acknowledges “complexity” rhetorically but continues using linear, deterministic models. Chaos and emergence are treated as complications (friction, fog) rather than fundamental features requiring different frameworks entirely.

### 6.4 Non-Classical Logic

Classical logic (which Euclidean proof uses) assumes:

  * Bivalence: Propositions are true or false, no middle ground

  * Non-contradiction: Nothing is both true and false

  * Excluded middle: Everything is either true or not-true




Alternative logics relax these assumptions:

  *  **Fuzzy logic** : Degrees of truth between 0 and 1

  *  **Paraconsistent logic** : Contradictions don’t explode the system

  *  **Intuitionistic logic** : Excluded middle doesn’t hold; existence requires construction




 **Military exclusion** : Doctrine uses bivalent categories (war/peace, friend/enemy, success/failure). But gray zones, frenemies, and indeterminate outcomes may require logics that tolerate ambiguity.

### 6.5 Non-Representational Knowing

The Euclidean-Newtonian framework assumes knowledge comes through representation—models that mirror reality. But other epistemologies emphasize:

  *  **Enaction** : Knowledge through engagement, not representation

  *  **Tacit knowing** : Expertise that can’t be articulated

  *  **Narrative knowing** : Understanding through stories, not models

  *  **Embodied cognition** : Mind extended into body and environment




 **Military exclusion** : Doctrine is written; exercises are scripted; knowledge is codified. But expert practitioners often know more than they can say, and their knowing is embedded in practice rather than captured in manuals.

* * *

## Part VII: The Persistence of the Framework

Given that Euclidean-Newtonian assumptions have been superseded in physics and mathematics, why do they persist in military thought?

### 7.1 Human-Scale Effectiveness

At human scales—the scales where people perceive and act—Euclidean geometry and Newtonian physics work extremely well. Space _appears_ flat; objects _appear_ to have definite positions; causes _appear_ to produce effects predictably. The framework persists because it matches intuition and succeeds often enough.

 **Military implication** : At tactical levels involving physical forces in physical space, Euclidean-Newtonian approaches remain useful. The problem is extending them to domains and scales where they break down.

### 7.2 Institutional Embedding

The framework is embedded in:

  * How officers are educated (mathematical methods, map exercises)

  * How staffs are organized (functional divisions mirroring domain separation)

  * How plans are formatted (standardized products with geometric graphics)

  * How operations are assessed (quantitative metrics, causal attribution)

  * How doctrine is written (principles, derived procedures, standardized terminology)




Changing the framework would require changing all of these—a transformation so comprehensive that it’s difficult to even initiate.

### 7.3 Coordination Requirements

Large-scale military operations require coordination among thousands of people across vast distances. Shared frameworks—even imperfect ones—enable coordination that idiosyncratic approaches preclude. The Euclidean-Newtonian framework, whatever its limitations, provides common vocabulary and concepts.

 **The dilemma** : Superior frameworks may be less shareable. Embracing complexity might mean losing coordination capacity.

### 7.4 Risk and Accountability

The framework supports the military’s need for accountability:

  * Plans can be briefed and evaluated in advance

  * Decisions can be justified against doctrinal standards

  * Outcomes can be attributed to decisions

  * Failures can be analyzed and responsibility assigned




More complexity-embracing frameworks might not support these institutional requirements.

### 7.5 Cognitive Comfort

Humans seem to have native Euclidean intuitions—we naturally think in terms of bounded objects in three-dimensional space with linear causation. Non-Euclidean and non-Newtonian frameworks require cognitive effort that feels unnatural.

 **The tension** : What’s cognitively comfortable may be operationally misleading. But what’s operationally appropriate may be cognitively inaccessible.

* * *

## Part VIII: Toward Post-Euclidean Military Thought?

If the Euclidean-Newtonian compound framework is increasingly insufficient, what might supplement or succeed it?

### 8.1 Topological Concepts

As Zweibelson suggests, topology offers concepts that might better fit complex warfare:

  *  **Connectivity** over distance

  *  **Holes and boundaries** over solid regions

  *  **Orientability** over fixed direction

  *  **Continuity** over exact position




Topological thinking asks different questions: Not “where is it?” but “what is it connected to?” Not “how big is it?” but “what kind of space is it?”

### 8.2 Network Thinking

Network science provides frameworks for:

  * Relationships rather than entities

  * Emergent properties of connection patterns

  * Flows and cascades across links

  * Resilience and vulnerability in decentralized systems




Military network analysis exists but tends to be grafted onto Euclidean-Newtonian assumptions (nodes as points, links as lines) rather than embracing network-native concepts.

### 8.3 Complexity Science

Complexity science offers:

  * Emergence and self-organization

  * Adaptation and co-evolution

  * Nonlinear dynamics and sensitivity

  * Phase transitions and tipping points




Complexity rhetoric pervades military discourse, but actual complexity methods remain marginal to doctrine and planning.

### 8.4 Phenomenological Approaches

Phenomenology brackets assumptions about objective reality to focus on experience:

  * How situations appear to actors

  * Meanings constructed through engagement

  * Horizons of possibility and constraint

  * Embodied, situated knowing




Military planning tends toward God’s-eye objectivity; phenomenology suggests attending to how the battlefield appears from within it.

### 8.5 Pragmatist Epistemology

Pragmatism judges knowledge by consequences rather than correspondence:

  * What difference does a concept make in practice?

  * What actions does a framework enable or preclude?

  * What problems does it help solve?




This shifts evaluation from “is this true?” to “is this useful for our purposes?”—a potentially more productive question when dealing with frameworks rather than facts.

* * *

## Conclusion: The Geometric Unconscious

Military thought operates with what might be called a “geometric unconscious”—deep assumptions about the structure of space, objects, causation, and knowledge inherited from Euclidean geometry and Newtonian physics. These assumptions are so foundational that they’re rarely articulated, let alone questioned. They feel like the very structure of rational thought rather than one historical framework among possible others.

Zweibelson’s Möbius strips and Klein bottles aren’t meant to replace this geometric unconscious with a topological one—that would just substitute one hidden framework for another. Rather, they’re meant to make the unconscious visible, to demonstrate that alternative conceptualizations exist, and to open space for deliberate choice about which frameworks to use when.

The point isn’t that Euclidean-Newtonian thinking is wrong—it’s that it’s _particular_ , that its limits are increasingly consequential, and that treating it as the only possible framework forecloses alternatives that might serve better in some contexts.

Whether military institutions can make this shift—can become aware of their geometric unconscious and develop capacity to think differently when situations warrant—remains an open question. The frameworks are deeply embedded not just in doctrine but in the cognitive habits of generations of practitioners. But the first step is seeing that there’s something to shift from, and something to shift toward.

The shapes on doctrine’s pages aren’t neutral representations of reality. They’re artifacts of a particular historical tradition of thought—powerful and useful in its domain, but a tradition nonetheless, not the structure of reality itself.[2](https://experimentalunit.substack.com/p/claude-on-zweibelsons-newtonianism#footnote-2-180804810)

* * *

## Reference Summary: Euclidean-Newtonian Overlaps

[![](https://substackcdn.com/image/fetch/$s_!O0QG!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5c3f2bb9-05f3-4806-a07d-bfb10bc4a2d2_916x613.png)](https://substackcdn.com/image/fetch/$s_!O0QG!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5c3f2bb9-05f3-4806-a07d-bfb10bc4a2d2_916x613.png)

[1](https://experimentalunit.substack.com/p/claude-on-zweibelsons-newtonianism#footnote-anchor-1-180804810)

Ben Zweibelson. “Breaking The Newtonian Fetish.” <https://www.usmcu.edu/Outreach/Marine-Corps-University-Press/MCU-Journal/JAMS-vol-15-no-1/Breaking-the-Newtonian-Fetish/>

[2](https://experimentalunit.substack.com/p/claude-on-zweibelsons-newtonianism#footnote-anchor-2-180804810)

Link to Claude conversation (public). <https://claude.ai/share/412ad1af-9c0b-47e0-bf9e-10cc3bea6db7>

---
title: 'Notes On Ben Zweibelson & Wargaming Weekly: Part 2'
subtitle: '"Mr. president, the problem is much worse than you think."'
author: Adam Wadley
publication: Experimental Unit
date: June 29, 2025
---

# Notes On Ben Zweibelson & Wargaming Weekly: Part 2
Thread Theme:

# Anarchy In The U, K?

There’s another snippet of a recent Zweibelson interview I feel called to respond to. I forget which of the talks it appeared in. I’m confident it’s in one of the four featured in part one, [available here](https://experimentalunit.substack.com/p/notes-on-ben-zweibelson-and-wargaming).

Ben is saying that “we” don’t want to just challenge things willy-nilly, because that would just be “anarchy” and that’s not what “we” want.

To dig more into this, we can consult the Burrell-Morgan set of social paradigms that Ben prominently features in their work.

[You can find an introduction to these paradigms by Burrell and Morgan themselves here](http://sonify.psych.gatech.edu/~ben/references/burrell_sociological_paradigms_and_organisational_analysis.pdf).

Here’s the part introducing the “interpretivist paradigm,” which Ben claims as the one that military designers like themselves might use:

> Theorists located within the context of the interpretive paradigm adopt an approach consonant with the tenets of what we have described as the sociology of re/:ulation, though its subjectivist approach to the analysis of the social world makes its links with this sociology often implicit rather than explicit. 
> 
> The interpretive paradigm is informed by a concern to _understand the world as it is, to understand the fundamental nature of the social world at the level of subjective experience_. It seeks _explanation_ within the realm of individual consciousness and subjectivity, within the frame of reference of the participant as opposed to the observer of action. 
> 
> In its approach to social science it tends to be nominalist, anti-positivist, voluntarist and ideographic. It sees the social world as an emergent social process which is created by the individuals concerned. Social reality, insofar as it is recognised to have any existence outside the consciousness of any single individual, is regarded as being little more than a network of assumptions and intersubjectively shared meanings. 
> 
> The ontological status of the social world is viewed as extremely questionable and problematic as far as theorists located within the interpretive paradigm are concerned. _Everyday life is accorded the status of a miraculous achievement_. Interpretive philosophers and sociologists seek to understand the very basis and source of social reality. They often delve into the depths of human consciousness and subjectivity in their quest for the fundamental meanings which underlie social life. 
> 
> Given this view of social reality, it is hardly surprising that the commitment of the interpretive sociologists to the sociology of regulation is implicit rather than explicit. Their ontological assumptions rule out a direct interest in the issues involved in the order-conflict debate as such. However, their standpoint is underwritten by the assumption that the world of human affairs is cohesive, ordered and integrated. _The problems of conflict, domination, contradiction, potentiality and change play no part in their theoretical framework_. They are much more orientated towards _obtaining an understanding_ of the subjectively created social world 'as it is' in terms of an ongoing process. 
> 
> Interpretive sociology is concerned with understanding the essence of the everyday world. in terms of our analytical schema it is underwritten by an involvement with issues relating to the nature of the status quo, social order, consensus, social integration and cohesion, solidarity and actuality.

Burrell and Morgan’s social paradigms are four, and they are based on a 2 by 2 grid made up of two binary oppositions, much like the well known “political compass.” 

The two binaries are “regulation” versus “radical change,” and “subjective” versus “objective.”

Ben will often say that worldviews can be thought of as emblematic of various social paradigms, and that these are mutually exclusive. This builds on Burrell and Morgan’s contentions that there are these underlying assumptions about the world which are contradictory, and hence that no reconciliation among these various paradigms is possible.

 _That sounds like a challenge_.

Moving to the question at hand, Dr. Ben Zweibelson is officially “an agent of the state,” in the employ of a “nation-state.” _Of course_ Ben Zweibelson must be concerned with social order, because Ben _is part of_ the glaring _conceit_ of social order, “the state.”

For examples of Ben’s “big talk,” consider these passages from their article, “[Why Do Militaries Stifle New Ideas?](https://ciasp.scholasticahq.com/article/92958-why-do-militaries-stifle-new-ideas)”

> We often fixate and obsess on technical and tactical innovation while expecting such local or immediate developments to suffice for overarching, strategic and game-changing transformations. Militaries fail to see the forest for the trees. Or better still, _we fetishise seeking out new things and ideas that already come in recognisable packaging_ , complete with clear instructions, able to _integrate seamlessly with all existing systems and processes_. We thus create a forest of the mediocre and the mundane, bereft of anything divergent or disruptive to the established and static order. We crave trees that prop up a forest of barren originality _so that the institutional identity, form and function is protected_. This begets further bureaucracy, propelling the forest toward greater risk of a flash fire when actual innovation sparks novel flames.

And (from earlier in the piece):

> This paradox of desiring innovation yet suppressing the consequences of actual innovation produces a culture of convergent thinking, adherence to written and unwritten rules, and a risk avoidance mentality where only those ideas that already nest with existing constructs are welcome. At the same time, innovation still happens in war. Often, the process is organic and somewhat insurgent, blurred within the strange bedfellows of _heretics, crackpots, mavericks, and outliers to the establishment_.

>”heretics, crackpots, mavericks, and outliers to the establishment”

>mrw:

[Zizek voice:] The 64,000 question opened up here is this one:

“If we are being so conceptually revolutionary, why are we still thinking of our design process as one taking place within and for nation-state militaries?”

The answer is, of course, that “the military design movement” faces the existential constraint of finding itself emerging from certain bureaucratic constellations which rely on widespread _myths_ for their legitimacy.

Ben can’t just come out and say “I am director of the Strategic Innovation Group at United States Space Command, and, by the way, “The United States” doesn’t exist :P”

# Beyond The Pale

# Beyond The State

# Beyond The “Regulation-Radical Change” Distinction

I’ve mentioned before the 1977 paper by Paul Abrams “Notes On The Difficulty Of Studying The State,” [available here](https://onlinelibrary.wiley.com/doi/epdf/10.1111/j.1467-6443.1988.tb00004.x).

Key for this context is this passage, delineating the possibly nonexistent “the state” from “the idea of the state”:

> Of course, it is true that such studies discover the state in only a rather special aspect. What is perceived is a rather powerful agent of legitimation. Those sociologists attracted to a Weberian conception of politics, of whom Daniel Bell is perhaps the most interesting contemporary representative and for whom, in Bell’s words ‘the axial principle of the polity is legitimacy’, will conclude that real progress is being made by research on political _socialisation_. 
> 
> Those who envisage the state as an altogether more forcible agency of control and coordination will find such a conclusion bland and inadequate if not vacuous. But the question is, _can sociologists of this second persuasion demonstrate that a state of the kind they believe in actually exists_? 
> 
> What the socialisation studies have done - along with other work more explicitly focused on legitimation processes, such as that of Mueller - is to establish _the existence of a managed construction of belief about the state_ and to make clear the consequences and implications of that process for the binding of subjects into their own subjection. 
> 
> Furthermore. they have shown that the binding process even if not effected by the state proceeds in terms of the creation of certain sorts of perceptions of the state. 
> 
> From Stein’s claim that ‘the King is the embodiment of the pure state idea’ to the American child’s belief that ‘ _the President is the best person in the world_ ’ is hardly any step at all. 
> 
> The discovery that _the idea of the state has a significant political reality_ even if _the state itself remains largely undiscovered_ marks for political sociology a significant and rare meeting of empiricism and a possible theory of the political.

[![Donald Trump is the ultimate cosmic horror, according to America's favorite  erotica author | Vox](https://substackcdn.com/image/fetch/$s_!INCx!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff5c82f4b-87a0-4f8c-b41a-64d96c4412ff_1100x396.jpeg)](https://substackcdn.com/image/fetch/$s_!INCx!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff5c82f4b-87a0-4f8c-b41a-64d96c4412ff_1100x396.jpeg)

 _You may not like it, but this is what the best person in the world looks like._

How shall we interpret the role of someone like Ben Zweibelson if we adopt Abram’s ideas here?

It’s important, first of all, to understand the stakes. The stakes of this inquiry for me are not about the moral culpability or the competence of a given social network or system of social systems (we can even start to move past the “social” here in a second, following Baudrillard).

In other words, I would like to strongly distinguish myself from any writers or operators who are chagrined that some coherent or noble “state” concept or entity has been “hijacked,” “subverted,” “covertly overthrown,” etc.

My own tendency is, rather, to say things like “there has never been a single state, and there never will be one.”

Further, I would say things like “there has never been a law that was in effect, and there never will be one.”

Note though, the way in which this line of thinking begins to undermine the distinction between “radical change” and “social regulation.”

After all (thinking of Christopher Derick Varn here, who loves the “after all…” formulation), we might as well start to say things here like “there is no status quo.”

In this sense, the projects of “preserving” and “overthrowing” the status quo become irrelevant.

Dr. Zweibelson themselves is operating with a “military design movement” which is explicitly seeking to dissolve the core aspects of bureaucratic “identity” which are present, for the sake of…?

See here Ofra Graicer discussing how Systemic Operational Design promises to rip apart everything practitioners think they stand for going in:

> That is why Systemic Design Inquiry is measured by the degrees of freedom it creates! 
> 
> SDI aims at getting our designers on the path of self liberation - far beyond what they know, _beyond their experience, value systems, beliefs, prejudices_. Beyond doctrine. 
> 
> In order to achieve desired degrees of freedom one must first identify his/her biases, prejudices and axioms carved in institutional ‘stone’. 
> 
> _These are the borders they must transgress in order to be liberated_. 
> 
> This is why I coined that phase - the nomadic one. For nomadic people have no baggage, no shackles that tie them to their place, no doctrines or dogmas to adhere to, no fortresses to defend but their own individual freedoms: of movement, of thought, of identity. Nomads have no ego. Such approach put the course instructors at the backstage of that unfolding play being written by the best of our generals, begin given the opportunity to reinvent themselves. 

My question is: isn’t changing “the will” of a participant _the entire point of “war”_? In other words, shouldn’t “warfighting entities” be paranoid that, by reorienting themselves through this radical design process, they may in effect “lose without fighting” by having their “wills” be changed in ways convenient to their “strategic adversaries”?

Note also the footnote here:

> 20 This is a place where Francis Clermont and I diverge philosophically - during the workshop, Francis advocated designers moral and ethical responsibility to better the world by acts of design. Although I wholly agree that the design process should serve the common good, getting there is by no means peaceful, and will encounter stark resistance.
> 
> 21 John Boyd, “[Destruction and Creation](http://www.goalsys.com/books/documents/DESTRUCTION_AND_CREATION.pdf)” (unpublished paper) accessed January 1st 2017. Originally dated September 3, 1976. 
> 
> See also Francis Clermont’s following paper in this issue, offering “ _ **one must die to himself to forget what is known**_ ”.

Seizing upon this quote about dying to oneself, we can say with John “The Hangman” Ruth:

[![YARN | Well I guess that makes this one fortuitous wagon. | The Hateful  Eight \(2015\) | Video clips by quotes | f71067e0 | 紗](https://substackcdn.com/image/fetch/$s_!kExT!,w_1456,c_limit,f_auto,q_auto:good,fl_lossy/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa7c0882e-b9bb-4cf8-8baa-dccdaa560cc5_400x145.gif)](https://substackcdn.com/image/fetch/$s_!kExT!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa7c0882e-b9bb-4cf8-8baa-dccdaa560cc5_400x145.gif)

We say this in view of this passage, characteristic of the “Afropessimist” perspective. Notice that we are here already in the realms adjacent to “Black Identity Extremism” or “Nihilist Violent Extremism,” in other words “official enemies” of good old All-American Statism.

From Andrew Santana Kaplan (with whom I once spoke about where Aaron Bushnell really did enough to “join the dance of social death”):

> The World as a transcendental structure of anti-Black containment and god-like vantage pointis precisely what establishes and governs the Human’s coordinates. Cone inaugurated contemporary Black liberation theology in the late 1960s during the Black Power movement.
> 
> Accordingly, for the Human to become Black—that is, to learn the steps to the dance of social death— _one must iterably leap into worldlessness_. 
> 
> The necessarily iterable structure of this leap is twofold: 
> 
> 1) since the Human’s acceptance of the Black’s invitation tothe dance of social death is contingent—whereas the Black is gratuitously constituted insocial death— _Humans constitutively cannot “become Black” as long as the World persists_ ; and, following Derrida, 
> 
> 2) the structure of the trace (of the Other) marks an originary repetition—or what Chandler emphasizes as an originary displacement, _which “the Negro” incarnates_ —that yields the conditions of im/possibility for any fidelity to the (wholly) Other. 
> 
> In this way, from the position of the Human, deconstruction allows us to understand and inhabit the meta-aporetic demand of Cone’s question (how to become Black?) and Wilderson’s answer ( _ **to die**_ ) as an iterable embrace of worldlessness— _i.e. as an iterable refusal of our coordinates_ —in which the Human’s asymptotic fidelity to Blackness marks the quasi-transcendental condition for (the coming of) any justice worthy of the name.

The key message:

“Cone’s question (how to become Black?) and Wilderon’s answer (to die).”

This is just what Graicer is referencing in Francis Clermont, this “dying to oneself” so that one can be reborn.

So maybe now you can start to see what is so exciting to me about Ben Zweibelson and the military design movement, and _especially_ Ofra Graicer.

With this framing by Kaplan/Wilderson of “becoming black” as this iterated leaving of one’s confines, continually going _Beyond The Pale_ (the wordplay is too good here, I don’t even care if you think I’m schizophrenic :P), and the parallel injunction by Ofra Graicer that one should “die to oneself” to achieve “self-liberation” beyond one’s “value systems,” it is again all-too obvious to consider all the military/intelligence terms associated with the color “black.”

Consider:

  1. Black Propaganda

  2. Black Operations (or: Black Ops)

  3. Black Budget

  4. Black Site

  5. Black Program

  6. Black World

  7. Black Projects

  8. Black Helicopters

  9. Black Vault

  10. Black Chamber

  11. Black Network

  12. Black Curtain

  13. Black SIGINT

  14. Blackmail Intelligence

  15. Black Card (clearance)

  16. Black Hat

  17. Black Number Station

  18. Blacklist

  19. Black Watch

  20. Black Code (overlaps to Black people treatment in “US”)

  21. Black Berets

  22. Black Letter Law

  23. Black Letter Orders

  24. Men In Black




[![Jim Gaffigan | Beyond The Pale](https://substackcdn.com/image/fetch/$s_!VTm6!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F64f8dd4d-442e-4217-8ee1-3c5fd1c38214_1200x630.jpeg)](https://substackcdn.com/image/fetch/$s_!VTm6!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F64f8dd4d-442e-4217-8ee1-3c5fd1c38214_1200x630.jpeg)

 _no one knows what it’s like to be fated… to be hated…_

While we can sit here and ponder what Ofra Graicer is really getting at, and whether this is some kind of “winning without fighting” which is going on in the name of making “nation-state militaries” more effective, we can also consider that the “radical” Afropessimist tradition… doesn’t really do that much?

I remember watching this interview with Frank Wilderson III, the person calling for me “to die” so that I can “join” the dance of social death (when, in fact, I’m a natural-born citizen of that frenzied state), discussing how they hope to retire to the Mediterranean after they’re done with their cushy academic career.

Um, what?

This is where I _get off_ accusing Afropessimism as a discourse of being _too white._

[![YARN | LOOK AT ME—GETTING OFF. | Arrested Development \(2003\) - S01E03  Bringing Up Buster | Video gifs by quotes | b32d8ee5 | 紗](https://substackcdn.com/image/fetch/$s_!L1dS!,w_1456,c_limit,f_auto,q_auto:good,fl_lossy/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd5b73b89-5d2f-47f3-b977-e744f1275cae_400x231.gif)](https://substackcdn.com/image/fetch/$s_!L1dS!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd5b73b89-5d2f-47f3-b977-e744f1275cae_400x231.gif)

What I mean by this is that the _fantasy_ of “retiring to the Mediterranean” is hopelessly naive in a _world_ (Frank Wilderson III claims not to have a world, yet is relying on Mediterranean countries to be there long enough for them to retire??) which is definitively headed over a cliff, or up an asymptotic curve.

The overall point here is to say that there is no “status quo” for reasons we can take all the way back to Heraclitus. Of course!

You can never step in the same river twice, because you and the river are changing.

Yet we must _always_ remember here Heidegger (note: Nazism + _Black_ notebooks) describing how Heraclitus and Parmenides in fact are in perfect agreement.

In other words, we are confronted with the notion of perpetual flux which is also perfect stasis. It is the paradox of “being” which in time is never the same, and yet which “outside of time” is never changing.

It’s obvious here why my political/military/emergency thoughts go straight into the mystical/psychedelic/cosmological realm.

See here in my classic article, “[I Just Lost The Game, And So Did All Of XU](https://experimentalunit.substack.com/p/i-just-lost-the-game-and-so-did-all),” how I use the conceit of Heraclitus’ notable saying “The way up and the way down are the one and the same” to talk about the twin conceptions of purposeful activity: 

  1. “The Way Up” is us starting from here, from ground level, from this planetary emergency or dissatisfied personal state, building up to address all this and essentially build Svarga, reach heaven, deserve “the world to come.”

  2. Meanwhile, “The Way Down” is the corollary conceit of imagining “The Absolute” making its way “down” to this level, the divine or cosmological establishment of this curious “something” we can now wonder at. “Can’t believe how strange it is to be anything at all.” Notable established lore for this is Lila, the divine play in Hinduism. Note that Kenneth Stanley now works with a company called Lila Sciences.




# Back To Anarchy

With the invocation of science, we are right back to _Against Method: Outline Of An Anarchistic Theory Of Knowledge_ by Paul Feyerabend. Note that Feyerabend fought for Germany in World War II, just like my Opa Richard Imbsweiler, who once said at _Kaffee und Kuchen_ , “I’ve done a lot of bad things in my life.”

Feyerabend is arguing that there can be _no set principles or methods_ for pursuing science, or the expansion of knowledge.

Meanwhile, we are faced with a “military” practice which would like to call itself “scientific.”

I’m not just concerned with “Western” or “Israeli” approaches to war, mind you. See here [The Science Of Military Strategy](https://en.wikipedia.org/wiki/The_Science_of_Military_Strategy), an important doctrinal document put out by “The People’s Republic Of China” (which also doesn’t exist, just so we are clear).

This “China” is of course officially running Marxism, which itself is so proud of its “Scientific Socialism” (SS), as opposed to that soy boy “Utopian Socialism” (US) people had been kicking around.

My theorist of choice, of course, is Jean Baudrillard, who started off interested in Marxism and working on its project, but then basically came to see that Marxism was itself too much like what it was trying to criticize or “get beyond.”

By the end of Baudrillard’s career, the discussion is far past the quaint idea of “revolution.” This is where we start to read of “involution,” which is the sort of spiraling inward (did someone say recursion? Just don’t say liturgy, or I’ll reach for Pistol Pete Thiel), this loss of coherence from inside.

What else is going on with the notion of Systemic Operational Design, and this self-obliterating and self-liberating inquiry as laid out by Shimon Naveh and Ofra Graicer?

I have to say that here, there is a reason why I am, at this point, more drawn to this “military design movement” than I am to the “radical scenes” I have frequented in my life.

Over the past several months, I have detonated my entire social life. I used to have a radio show on a “progressive” radio station. I lost it in March after over 7 years of weekly broadcasts.

I helped found a film screening collective called “Resistance Cinema.” I always hated the name. Everyone who plays _Magic: The Gathering_ knows that it’s going to be doing something _pro_ active.

Eventually, I was kicked out of the group I helped start because it was impossible to say anything interesting at one of our discussions without being accused of being “liberal” or “fascist” by people who set up all opposition to themselves in those terms.

Rather, we can proceed again in this Baudrillardian way, not “against” Marxism or its ideas of seeking to look at flourishing, but to go further and interrogate the basic assumptions around things like: what is capital supposed to be? Are there modes of production? What is the role of signification in all this?

Badudrillard, by the time of _The Transparency Of Evil_ , is saying that _the Bourgeoisie has abolished itself_ , and by the time of _The Agony Of Power_ , the question is whether _capital even exists at all_.

Already in _Symbolic Exchange And Death_ , Baudrillard is advancing a term to overtake the never-applicable “capitalism,” namely _Semiocracy_.

Meanwhile, I had been advancing this notion that all “states” are just military social networks with a “civil” component attached, as one used to say of the Prussian “state” (which also invented Wargaming, by the way. That’s still coming up!).

In essence, this makes all “governments” kinds of _stratocracy_ , or rule by the military.

Again, please do not get it twisted.

  1. This does not mean that I think there is “evil military” behind some “lie, ruse, sham” civil government. It is instead that the notion of a “civil government” is itself this sort of regulatory mechanism. I can distinguish my position by laying out the overly cynical view of Abrams:

> The state, then, is not an object akin to the human ear. Nor is it even an object akin to human marriage. It is a third-order object, an ideological project. 
> 
> _It is first and foremost an exercise in legitimation - and what it being legitimated is, we may assume, something which if seen directly and as itself would be illegitimate, an unacceptable domination._ Why else all the legitimation-work? 
> 
> The state, in sum, is a bid to elicit support for or tolerance of the insupportable and intolerable by presenting them as something other than themselves, namely, legitimate, disinterested domination. 
> 
> The study of the state, seen thus, would begin with the cardinal activity involved in the serious presentation of the state: the legitimating of the illegitimate. 

Abrams is making it out to be that “the status quo” _should not exist_ because it can only exist by misrepresenting itself. Recall here what Debord writes in the _[Comments On Society Of The Spectacle](https://theanarchistlibrary.org/library/guy-debord-comments-on-the-society-of-the-spectacle) :_

>  _Not only are the subjugated made to believe that, essentially, they are still living in a world which in fact disappeared_ , but the rulers themselves sometimes suffer from the thoughtlessness of still believing in it. 
> 
> They come to believe in a part of what they have suppressed, as if it remained a reality and had still to be included in their calculations. This delay will not last long.

On this stream, on the other hand, we stan [Nietzschean Affirmation](https://en.wikipedia.org/wiki/Nietzschean_affirmation). We wouldn’t be caught _dead_ saying that something is “illegitimate.” It’s more so that what people think is “legitimate” in fact _does not exist_.

  2. Corollary to this is also important to note that I am not complacent or simply spellbound by the complex machinery of deception and killing which have “gotten us this far,” nor do I recognize any authority on the part of anyone taking part as an “insider” or any collective institution or bureaucracy. Whatever has “gotten us this far” is worthy not to be condemned or written off, but at the same time the question is very much _what have you done for me lately_? And, moreover, the point here was also that _any supposed “status quo” is always incoherent, in flux, incongruous._




In other words, there really is no simple “stratocracy.” A cursory contemplation of the fractal—did someone say “recursive?” (SHUT UP, ChatGPT! If you suggest something liturgical to me again I’m going to crucify you like Mike from _The Blair Witch Project_ wasn’t (this is a _[Hitchhiker’s Guide](https://lift.caldafrica.com/wp-content/uploads/2021/08/Douglas_Adams_The_Hitchhikers_Guide_to_the_Galaxy_1995.pdf) (_note the HH in the middle of the word) reference: “The ships hung in the sky in much the same way that bricks don’t”)—nature of the Hobbesian Trap will show this.

For if the stratocracy—the deep state, with its deep operations—must keep its workings a secret from the general public because otherwise it would not be accepted, then what about the inner workings of this stratocracy? Wouldn’t it have to be iterative in this way, so that the inner parties of inner parties would all have to keep not just operational details but their whole modi operandi secret because everyone’s betraying each other inward and inward this process of secrecy?

[![YARN | What bus driver? | Batman: The Dark Knight \(2008\) | Video clips by  quotes | 9db2b04f | 紗](https://substackcdn.com/image/fetch/$s_!imXn!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0981020e-9763-4245-b4c4-c00b149395f9_1162x480.jpeg)](https://substackcdn.com/image/fetch/$s_!imXn!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0981020e-9763-4245-b4c4-c00b149395f9_1162x480.jpeg)

To wrap things up, this is where I put the concept of _semio-stratocracy_ , or administration according to warfighting concepts. This is a discussion of fractal governance, where each person operates according to the concepts which help them make sense of the radical antagonisms they find themselves in, _which themselves make up what **you people**_ ****_call “social order.”_

Now, going back to the conceit of Lila—although any cosmological principle does the same, this Thielian notion of rejecting the authorship of sin by “God” because that’s “scapegoating God” is pure SCHWACHSINN (again, SS)—there cannot really be “conflict” since the same _design_ is behind all this multitude. It’s not really “one,” since the great mystery is beyond number, but it’s also not different. So how could there be conflict?

Hence the flight into emergency and emergence. I say _Semio-Subitocracy_ for the notion of administration according to emergency response concepts of operations.

I’d like to end on this confluence of the notion of states of emergency and emergency powers, popularized by Carl Schmitt, of course again another Nazi.

Yet consider this in light of the Jewish notion o[f ](https://en.wikipedia.org/wiki/Pikuach_nefesh)_[Pikuach nefesh](https://en.wikipedia.org/wiki/Pikuach_nefesh) , _which states that most any Jewish law can be suspended for the sake of saving lives. Somewhere I read (this is a reference to MLK’s last speech):

If you save one life, you save the world entire.

For me, this is in effect the core of Judaism. After all, if your “rule of law” contains what is basically Article 48 of the Weimar constitution, in a sense that Article 48 is the highest law, since it establishes when all the rest can be set aside.

This is all basically to say that for me, it is no question of “radically changing” things, but rather, within the conceit of temporality, to be gesturing toward what the internal logic (Logos) of supposed “government” has been the tire time:

> [what Chesterton fails to perceive is that the "universalized crime" that he projects into "lawless modern philosophy" and its political equivalent, the "anarchist" movement that aims at destroying the totality of civilized life, ALREADY EXISTS IN THE GUISE OF THE EXISTING RULE OF LAW, so that the antagonism between Law and crime reveals itself to be inherent to crime, the antagonism between universal and particular crime.](https://www.lacan.com/zizhegche.htm)

 _“It’s Criminal”_

More on Wargaming Weekly next time!

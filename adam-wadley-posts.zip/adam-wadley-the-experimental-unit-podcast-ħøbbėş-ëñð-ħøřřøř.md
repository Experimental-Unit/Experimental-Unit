---
title: 'The Experimental Unit Podcast: Ħøbbėş Ëñð Ħøřřøř'
subtitle: You'll Float Too
author: Adam Wadley
publication: Experimental Unit
date: July 15, 2025
---

# The Experimental Unit Podcast: Ħøbbėş Ëñð Ħøřřøř
[![](https://substackcdn.com/image/fetch/$s_!SUbX!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F24508636-13c5-412a-9b22-bed12ebacab4_1200x1421.jpeg)](https://substackcdn.com/image/fetch/$s_!SUbX!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F24508636-13c5-412a-9b22-bed12ebacab4_1200x1421.jpeg)

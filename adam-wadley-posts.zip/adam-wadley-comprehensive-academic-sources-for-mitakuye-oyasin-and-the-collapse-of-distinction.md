---
title: Comprehensive Academic Sources for “Mitakuye Oyasin and the Collapse of Distinction”
subtitle: Indigenous Relational Ontology as the Answer to Perpetration and Complicity
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# Comprehensive Academic Sources for “Mitakuye Oyasin and the Collapse of Distinction”
## 1\. Lakota Philosophy and Cosmology

The concept of _Mitakuye Oyasin_ (”all my relations”) provides the ontological foundation for this scholarly project, expressing how Lakota worldview understands all beings as kin within a unified, sacred cosmos. [South Dakota State University](https://openprairie.sdstate.edu/etd2/400/)[Grokipedia](https://grokipedia.com/page/Mitakuye_Oyasin)

### Foundational Texts

 **Neihardt, John G.** _Black Elk Speaks: Being the Life Story of a Holy Man of the Oglala Sioux._ Lincoln: University of Nebraska Press, 1932. Complete Edition with annotations by Raymond J. DeMallie, 2014.

  * Seminal spiritual autobiography of Nicholas Black Elk (Oglala Lakota, 1863-1950), describing his Great Vision of interconnectedness [Amazon](https://www.amazon.com/Black-Elk-Speaks-John-Neihardt/dp/0803283911) where “the sacred hoop of my people was one of many hoops that made one circle.” [Wikipedia](https://en.wikipedia.org/wiki/Black_Elk) **Indigenous source.**




 **Brown, Joseph Epes, ed.** _The Sacred Pipe: Black Elk’s Account of the Seven Rites of the Oglala Sioux._ Norman: University of Oklahoma Press, 1953.

  * Black Elk’s detailed account of the seven sacred rites, [Amazon](https://www.amazon.com/Sacred-Pipe-Account-Civilization-American/dp/0806121246) including the White Buffalo Woman story and ceremonial foundations of Lakota relational ontology. [Grokipedia](https://grokipedia.com/page/Mitakuye_Oyasin) ISBN: 978-0806121246. **Indigenous source (Black Elk).**




 **DeMallie, Raymond J., ed.** _The Sixth Grandfather: Black Elk’s Teachings Given to John G. Neihardt._ Lincoln: University of Nebraska Press, 1984.

  * Scholarly edition of original interview transcripts providing unmediated access to Black Elk’s teachings on Lakota theology and philosophy. ISBN: 978-0803265646.




 **White Hat, Albert Sr.** _Reading and Writing the Lakota Language._ Salt Lake City: University of Utah Press, 1999.

  * First Lakota language textbook by a native speaker, documenting how _mitakuye oyasin_ means “our creator became us,” expressing universal kinship. [Indianz](https://indianz.com/News/2005/05/13/albert_white_ha.asp) Foreword by Vine Deloria Jr. [Windspeaker](https://windspeaker.com/news/footprints/albert-white-hat-sr-worked-preserve-lakota-language) ISBN: 978-0874805727. **Indigenous author (Sicangu/Rosebud Lakota).**




 **White Hat, Albert Sr.** _Zuya: Life’s Journey—Lakota Concepts of Life and Death._ Salt Lake City: University of Utah Press, 2012.

  * Comprehensive account of Lakota spirituality from a traditional elder, discussing wakʿą́ (sacred power) and relational worldview. **Indigenous author (Sicangu/Rosebud Lakota).**




### Contemporary Lakota Scholarship

 **Posthumus, David C.** _All My Relatives: Exploring Lakota Ontology, Belief, and Ritual._ Lincoln: University of Nebraska Press, 2018.

  * Rigorous scholarly examination applying Descola’s animism framework to Lakota relational ontology, exploring how _mitákuye oyásʾį_ reflects understanding that “all life-forms were related; the universe was experienced as being alive.” [ResearchGate](https://www.researchgate.net/publication/326107730_All_My_Relatives_Exploring_Lakota_Ontology_Belief_and_Ritual)[academia](https://www.academia.edu/50883335/All_My_Relatives_Exploring_Lakota_Ontology_Belief_and_Ritual_David_C_Posthumus) ISBN: 978-0803299948.




 **Marshall III, Joseph M.** _The Lakota Way: Stories and Lessons for Living._ New York: Penguin/Compass, 2001.

  * Presents twelve core Lakota ethical qualities through traditional teachings. Finalist for PEN Center USA West Award. [PenguinRandomhouse.com](https://www.penguinrandomhouse.com/books/289750/the-lakota-way-by-joseph-m-marshall/) ISBN: 978-0142196090. **Indigenous author (Sicunga Lakota).**




 **Marshall III, Joseph M.** _Returning to the Lakota Way: Old Values to Save a Modern World._ Carlsbad, CA: Hay House, 2013.

  * Explores how ancient Lakota teachings on tolerance, patience, and selflessness apply to contemporary challenges. ISBN: 978-1401931766. **Indigenous author (Sicunga Lakota).**




 **Walker, James R.** _Lakota Belief and Ritual._ Edited by Raymond J. DeMallie and Elaine A. Jahner. Lincoln: University of Nebraska Press, 1991.

  * Primary ethnographic source from eighteen years at Pine Ridge Reservation (1896-1914), including accounts from Oglala holy men. ISBN: 978-0803297319.




### Wolakota and Peace

 **Sinte Gleska University.** “Oceti Sakowin Essential Understandings and Standards.” Mission, SD: WoLakota Project, 2012.

  * Collaborative document by Indigenous Elders articulating _wolakota_ as “peace, balance and coming together” [OpenEdition](https://journals.openedition.org/transatlantica/25663) emerging from relational worldview. **Indigenous source.**




 **Iron Cloud, Richard.** “Wolakota kagapi: The Study of Peace Making on the Pine Ridge Indian Reservation.” UCLA Center for the Study of Religion, 2023.

  * Oglala Lakota scholar examining traditional peacemaking practices rooted in Lakota cultural values. **Indigenous author (Oglala Lakota).**




* * *

## 2\. Historical Trauma and Indigenous Healing

### Maria Yellow Horse Brave Heart’s Work

 **Brave Heart, Maria Yellow Horse.** “The Return to the Sacred Path: Healing the Historical Trauma and Historical Unresolved Grief Response Among the Lakota.” _Smith College Studies in Social Work_ 68, no. 3 (1998): 287-305. DOI: 10.1080/00377319809517532

  * Foundational peer-reviewed article developing historical trauma theory for Indigenous populations. **Indigenous author (Hunkpapa/Oglala Lakota).**




 **Brave Heart, Maria Yellow Horse.** “The Historical Trauma Response Among Natives and Its Relationship with Substance Abuse.” _Journal of Psychoactive Drugs_ 35, no. 1 (2003): 7-13. DOI: 10.1080/02791072.2003.10399988

  * Defines historical trauma as “cumulative emotional and psychological wounding over the lifespan and across generations.” Selected as Tribal Best Practice by SAMHSA (2009). [Ndrn](http://materials.ndrn.org/virtual20/session28/Building Relationships/Historical Trauma, Brave Heart.pdf) **Indigenous author.**




 **Duran, Eduardo, and Bonnie Duran.** _Native American Postcolonial Psychology._ Albany: SUNY Press, 1995.

  * Introduces “soul wound” (intergenerational trauma) concept; delineates six phases of historical trauma. ISBN: 978-0791424537.




 **Duran, Eduardo.** _Healing the Soul Wound: Trauma-Informed Counseling for Indigenous Communities._ 2nd ed. New York: Teachers College Press, 2019.

  * Translates Indigenous cosmology and natural law into therapeutic practice. ISBN: 978-0807761397.




 **Bombay, Amy, Kimberly Matheson, and Hymie Anisman.** “Hidden Burdens: A Review of Intergenerational, Historical and Complex Trauma.” _Journal of Child & Adolescent Trauma_ 13 (2020): 199-213. DOI: 10.1007/s40653-019-00267-4

  * Reviews trauma transmission across generations through psychosocial and epigenetic mechanisms.




* * *

## 3\. Vanessa Watts and Indigenous Place-Thought

 **Watts, Vanessa.** “Indigenous Place-Thought and Agency Amongst Humans and Non-Humans (First Woman and Sky Woman Go on a European World Tour!).” _Decolonization: Indigeneity, Education & Society_ 2, no. 1 (2013): 20-34. Open Access.

  * Foundational article arguing that in Haudenosaunee and Anishinaabe worldviews, land is a thinking entity where place and thought are fundamentally inseparable. [ResearchGate](https://www.researchgate.net/publication/395974463_Reclaiming_Indigenous_Ontologies) Critiques the Western epistemology-ontology divide that reserves agency exclusively for humans. [University of Toronto](https://jps.library.utoronto.ca/index.php/des/article/view/19145)[Journaldatabase](https://journaldatabase.info/articles/indigenous_place-thought_agency.html) **Indigenous author (Mohawk/Anishinaabe).**




 **Rosiek, Jerry Lee, Jimmy Snyder, and Scott L. Pratt.** “The New Materialisms and Indigenous Theories of Non-Human Agency: Making the Case for Respectful Anti-Colonial Engagement.” _Qualitative Inquiry_ 26, no. 3-4 (2020): 331-346. DOI: 10.1177/1077800419830135

  * Draws extensively on Watts’s Place-Thought framework to demonstrate how Indigenous scholarship addresses challenges facing new materialism.




 **Todd, Zoe.** “Indigenizing the Anthropocene.” In _Art in the Anthropocene_ , edited by Heather Davis and Etienne Turpin, 241-254. Open Humanities Press, 2015.

  * Métis scholar critiques Euro-Western claims to “discover” relational ontologies Indigenous peoples have articulated for millennia. **Indigenous author (Métis).**




 **Hokowhitu, Brendan.** “Indigenous Materialisms and Disciplinary Colonialism.” _Somatechnics_ 11, no. 3 (2021): 311-330. DOI: 10.3366/soma.2021.0349

  * Argues new materialism’s “newness” constitutes epistemological colonialism when Indigenous materialisms preceded these ideas by millennia. [EUP Publishing](https://www.euppublishing.com/doi/10.3366/soma.2021.0349) **Indigenous author (Māori).**




 **Wilson, Shawn.** “What is an Indigenous Research Methodology?” _Canadian Journal of Native Education_ 25, no. 2 (2001): 175-179.

  * Establishes that in Indigenous ontology, “an object or thing is not as important as one’s relationship to it.” [Springer](https://link.springer.com/article/10.1007/s11213-024-09672-4)[University of Arizona](https://repository.arizona.edu/bitstream/handle/10150/664341/azu_etd_19570_sip1_m.pdf?sequence=1) **Indigenous author (Opaskwayak Cree).**




 **Liboiron, Max, Manuel Tironi, and Nerea Calvillo.** “Toxic Politics: Acting in a Permanently Polluted World.” _Social Studies of Science_ 48, no. 3 (2018): 331-349.

  * Applies Indigenous relational ontology to environmental science. **Indigenous author (Liboiron is Red River Métis).**




* * *

## 4\. Robin Wall Kimmerer and Braiding Sweetgrass

 **Kimmerer, Robin Wall.** _Braiding Sweetgrass: Indigenous Wisdom, Scientific Knowledge, and the Teachings of Plants._ Minneapolis: Milkweed Editions, 2013.

  * New York Times bestselling collection weaving Indigenous knowledge and Western botanical science. [Wikipedia](https://en.wikipedia.org/wiki/Braiding_Sweetgrass)[Amazon](https://www.amazon.com/Gathering-Moss-Natural-Cultural-History/dp/0870714996) Key concepts include the “Honorable Harvest,” Three Sisters mutualism, and the gift economy. Winner of 2014 Sigurd F. Olson Nature Writing Award. [Wikipedia](https://en.wikipedia.org/wiki/Braiding_Sweetgrass) ISBN: 9781571313560. **Indigenous author (Citizen Potawatomi Nation).**




 **Kimmerer, Robin Wall.** _Gathering Moss: A Natural and Cultural History of Mosses._ Corvallis: Oregon State University Press, 2003.

  * Winner of the 2005 John Burroughs Medal; treats mosses as persons with agency. ISBN: 9780870714993. **Indigenous author.**




 **Kimmerer, Robin Wall.** “The Covenant of Reciprocity.” In _The Wiley Blackwell Companion to Religion and Ecology_ , edited by John Hart, 368-381. Hoboken: Wiley, 2017.

  * Articulates philosophical foundations of the Honorable Harvest as actual covenant with living beings. **Indigenous author.**




 **Kimmerer, Robin Wall.** “The ‘Honorable Harvest’: Lessons From an Indigenous Tradition of Giving Thanks.” _Yes! Magazine_ , November 26, 2015.

  * Outlines Honorable Harvest principles: ask permission, never take the first or last, take only what you need, minimize harm, use everything, give thanks, reciprocate the gift. [YES! Magazine](https://www.yesmagazine.org/issue/good-health/2015/11/26/the-honorable-harvest-lessons-from-an-indigenous-tradition-of-giving-thanks)[Funraise](https://www.funraise.org/blog/honorable-harvest-fundraising-lessons-in-mindfulness-and-sustainability) **Indigenous author.**




 **Nelson, Melissa K.** “The Honorable Harvest of Indigenous Data.” _Environment and Planning F_ 2, no. 3-4 (2023): 447-453. DOI: 10.1177/26349825231168865

  * Applies Kimmerer’s framework to Indigenous research methodologies. **Indigenous author (Turtle Mountain Chippewa).**




* * *

## 5\. Kim TallBear on Indigenous Relationality

 **TallBear, Kim.** _Native American DNA: Tribal Belonging and the False Promise of Genetic Science._ Minneapolis: University of Minnesota Press, 2013.

  * Argues DNA testing cannot determine tribal identity because belonging is fundamentally relational—based on kinship, cultural practice, and political relationships rather than genetic markers. [Amazon +3](https://www.amazon.ca/Native-American-DNA-Belonging-Promise/dp/0816665869) ISBN: 9780816665860. **Indigenous author (Sisseton-Wahpeton Oyate).**




 **TallBear, Kim.** “Making Love and Relations Beyond Settler Sex and Family.” In _Making Kin Not Population_ , edited by Adele Clarke and Donna Haraway, 145-164. Chicago: Prickly Paradigm Press, 2018.

  * Argues settler colonialism imposed heteronormative monogamy as tools of nation-building that erased Indigenous kinship structures. [FOR THE WILD](https://forthewild.world/listen/kim-tallbear-on-reviving-kinship-and-sexual-abundance-157) **Indigenous author.**




 **TallBear, Kim.** “Caretaking Relations, Not American Dreaming.” _Kalfou_ 6, no. 1 (2019): 24-41. DOI: 10.15367/kf.v6i1.228

  * Foregrounds Dakota understanding of “being in good relation” as alternative to American exceptionalism’s progressive narrative. [Temple](https://tupjournals.temple.edu/index.php/kalfou/article/view/228) **Indigenous author.**




 **TallBear, Kim.** “Dossier: Theorizing Queer Inhumanisms: An Indigenous Reflection on Working Beyond the Human/Not Human.” _GLQ_ 21, no. 2-3 (2015): 230-235. DOI: 10.1215/10642684-2843323

  * Argues Indigenous ontologies have long operated “beyond the human/not human” binary. [Abtec](http://abtec.org/iif/disrupting-settlement-sex-and-nature-an-indigenous-logic-of-relationality/) **Indigenous author.**




 **TallBear, Kim.** “Genomic Articulations of Indigeneity.” _Social Studies of Science_ 43, no. 4 (2013): 509-534.

  * Examines how genomic science distorts Indigenous identity by reducing relationality to biology. [Wikipedia](https://en.wikipedia.org/wiki/Kim_TallBear)[Kiddle](https://kids.kiddle.co/Kim_TallBear) **Indigenous author.**




* * *

## 6\. Vine Deloria Jr. and Indigenous Theology

### Primary Works

 **Deloria, Vine Jr.** _God Is Red: A Native View of Religion._ 50th Anniversary Edition. Golden, CO: Fulcrum Publishing, 2023 (orig. 1973).

  * Foundational text on Indigenous spatial vs. Western temporal religious orientations. [Uni-rostock +2](https://www.iaa.uni-rostock.de/forschung/laufende-forschungsprojekte/american-antiquities-prof-mackenthun/project/agents/vine-deloria/) New edition includes essays by Philip Deloria, Suzan Shown Harjo, and Daniel Wildcat. [Birchbark Books](https://birchbarkbooks.com/products/god-is-red) ISBN: 978-1-68275-314-9. **Indigenous author (Standing Rock Sioux/Lakota).**




 **Deloria, Vine Jr.** _Custer Died for Your Sins: An Indian Manifesto._ Norman: University of Oklahoma Press, 1988 (orig. 1969).

  * Launched the intellectual foundation for Red Power; [The Lawrence Times](https://lawrencekstimes.com/2023/09/16/scholars-discuss-god-is-red/) first critique of Christianity’s role in colonization. [Uni-rostock](https://www.iaa.uni-rostock.de/forschung/laufende-forschungsprojekte/american-antiquities-prof-mackenthun/project/agents/vine-deloria/)[Goodreads](https://www.goodreads.com/book/show/197753.Custer_Died_for_Your_Sins) ISBN: 978-0-8061-2129-1. **Indigenous author.**




 **Deloria, Vine Jr.** _Red Earth, White Lies: Native Americans and the Myth of Scientific Fact._ Golden, CO: Fulcrum Publishing, 1995.

  * Critiques Western scientific epistemology and argues for epistemological validity of oral traditions. ISBN: 978-1-55591-248-4. **Indigenous author.**




 **Deloria, Vine Jr.** _Spirit & Reason: The Vine Deloria Jr. Reader._ Edited by Barbara Deloria, Kristen Foehner, and Sam Scinta. Golden, CO: Fulcrum Publishing, 1999.

  * Comprehensive collection of 29 essays spanning 30 years of Deloria’s thought. [Fulcrum Books](https://www.fulcrumbooks.com/product-page/spirit-and-reason) Foreword by Wilma P. Mankiller (Cherokee). ISBN: 978-1-55591-430-3. **Indigenous author.**




 **Deloria, Vine Jr.** _For This Land: Writings on Religion in America._ Edited by James Treat. New York: Routledge, 1999.

  * Collection of 28 essays on religion spanning three decades. [Spirituality & Practice +2](https://www.spiritualityandpractice.com/book-reviews/view/1515/for-this-land) DOI: 10.4324/9780203949573. **Indigenous author.**




 **Deloria, Vine Jr.** _The Metaphysics of Modern Existence._ Golden, CO: Fulcrum Publishing, 2012 (orig. 1979).

  * Develops argument for spatial rather than temporal understanding of existence. ISBN: 978-1-55591-250-7. **Indigenous author.**




### Indigenous Theology Secondary Scholarship

 **Kidwell, Clara Sue, Homer Noley, and George E. Tinker.** _A Native American Theology._ Maryknoll, NY: Orbis Books, 2001.

  * First comprehensive systematic Christian theology through Native American eyes. [Google Books](https://books.google.com/books/about/A_Native_American_Theology.html?id=_h91AAAAMAAJ) Discusses _Mitakuye Oyasin_ as foundational to understanding interrelatedness. ISBN: 978-1-57075-361-9. **Indigenous authors: Kidwell (Choctaw/Chippewa), Noley (Choctaw), Tinker (Osage/Cherokee).**




 **Tinker, George E.** _American Indian Liberation: A Theology of Sovereignty._ Maryknoll, NY: Orbis Books, 2008.

  * Focuses on differing understandings of Jesus Christ and land in “theology of sovereignty.” [Amazon](https://www.amazon.com/American-Indian-Liberation-Theology-Sovereignty/dp/1570758050) ISBN: 978-1-57075-805-8. **Indigenous author (Osage/Cherokee).**




 **Tinker, George E.** _Spirit and Resistance: Political Theology and American Indian Liberation._ Minneapolis: Fortress Press, 2004.

  * Shows how Native insights into sacred space reconfigure traditional theological categories. ISBN: 978-0-8006-3681-4. **Indigenous author.**




 **Weaver, Jace.** _That the People Might Live: Native American Literatures and Native American Community._ New York: Oxford University Press, 1997.

  * Develops “communitism”—nexus of communal and communitarian values as bedrock of Native spirituality. ISBN: 978-0-19-512027-6. **Indigenous author (Cherokee descent).**




 **Martínez, David.** _Life of the Indigenous Mind: Vine Deloria Jr. and the Birth of the Red Power Movement._ Lincoln: University of Nebraska Press, 2019.

  * Scholarly biography examining Deloria’s “Red Power Tetralogy.” [Histanthro](https://histanthro.org/reviews/life-of-the-indigenous-mind/) ISBN: 978-0-8032-9939-0. **Indigenous author (Akimel O’odham).**




 **Pavlik, Steve, and Daniel R. Wildcat, eds.** _Destroying Dogma: Vine Deloria Jr. and His Influence on American Society._ Golden, CO: Fulcrum Publishing, 2006.

  * Essays demonstrating breadth of Deloria’s influence. [Amazon](https://us.amazon.com/Destroying-Dogma-Deloria-Influence-American/dp/1555915191) ISBN: 978-1-55591-519-5. **Wildcat is Indigenous (Yuchi/Muscogee).**




* * *

## 7\. Ghost Dance Movement and Revitalization

### Historical Sources

 **Mooney, James.** _The Ghost-Dance Religion and the Sioux Outbreak of 1890._ Washington: Government Printing Office, 1896. Reprinted University of Nebraska Press, 1991.

  * Foundational ethnographic account based on fieldwork among multiple tribes and personal interview with Wovoka. [Amazon](https://us.amazon.com/Ghost-Dance-Religion-Sioux-Outbreak-1890/dp/0803281773) ISBN: 978-0803281776.




 **Warren, Louis S.** _God’s Red Son: The Ghost Dance Religion and the Making of Modern America._ New York: Basic Books, 2017.

  * Bancroft Prize winner offering revisionist interpretation of Ghost Dance as forward-oriented modern religion. [Amazon](https://www.amazon.com/Gods-Red-Son-Religion-America-ebook/dp/B01HZFB2TU) ISBN: 978-0465015023.




 **Smoak, Gregory E.** _Ghost Dances and Identity: Prophetic Religion and American Indian Ethnogenesis in the Nineteenth Century._ Berkeley: UC Press, 2006.

  * Examines Ghost Dance as vehicle for pan-Indian identity formation. [Amazon](https://www.amazon.com/Ghost-Dances-Identity-Gregory-Ellis/dp/0520256271) DOI: 10.1525/9780520941724.




 **Andersson, Rani-Henrik.** _The Lakota Ghost Dance of 1890._ Lincoln: University of Nebraska Press, 2008.

  * Most comprehensive account incorporating previously untranslated Lakota-language accounts. [Amazon](https://www.amazon.com/Lakota-Ghost-Dance-1890/dp/0803210736) ISBN: 978-0803210738.




 **Andersson, Rani-Henrik, and Raymond J. DeMallie.** _A Whirlwind Passed Through Our Country: Lakota Voices of the Ghost Dance._ Norman: University of Oklahoma Press, 2018.

  * Contains over 100 Lakota accounts, many never before translated. [Birchbark Books](https://birchbarkbooks.com/products/a-whirlwind-passed-through-our-country) ISBN: 978-0806160757.




### Indigenous Perspectives and Contemporary Engagement

 **Estes, Nick.** _Our History Is the Future: Standing Rock Versus the Dakota Access Pipeline, and the Long Tradition of Indigenous Resistance._ London: Verso, 2019.

  * Frames Ghost Dance as anti-colonial mass movement posing “comprehensive challenge to colonial order.” [Verso Books](https://www.versobooks.com/blogs/news/4520-the-wounded-knee-massacre-and-the-long-tradition-of-indigenous-resistance) Links Ghost Dance prophecy to #NoDAPL. [Funraise](https://www.funraise.org/blog/honorable-harvest-fundraising-lessons-in-mindfulness-and-sustainability) ISBN: 978-1786636720. **Indigenous author (Lower Brule Sioux Tribe).**




 **Kehoe, Alice Beck.** _The Ghost Dance: Ethnohistory and Revitalization._ 2nd ed. Long Grove: Waveland Press, 2006.

  * Combines ethnographic experience with theoretical analysis; discusses Ghost Dance continuation in contemporary communities. ISBN: 978-1577664536.




 **Wallace, Anthony F.C.** “Revitalization Movements.” _American Anthropologist_ 58, no. 2 (1956): 264-281. DOI: 10.1525/aa.1956.58.2.02a00040

  * Foundational theoretical text defining revitalization movements as “deliberate, organized, conscious efforts by members of a society to construct a more satisfying culture.”




* * *

## 8\. Decolonial Theory and Indigenous Activism

### Glen Coulthard

 **Coulthard, Glen Sean.** _Red Skin, White Masks: Rejecting the Colonial Politics of Recognition._ Minneapolis: University of Minnesota Press, 2014.

  * Major intervention introducing “grounded normativity”—place-based ethical frameworks derived from Indigenous relationships to land. [Wikipedia](https://en.wikipedia.org/wiki/Glen_Coulthard) Winner of C.B. Macpherson Award and Frantz Fanon Award. [Wikipedia](https://en.wikipedia.org/wiki/Glen_Coulthard) **Indigenous author (Yellowknives Dene).**




 **Coulthard, Glen, and Leanne Betasamosake Simpson.** “Grounded Normativity/Place-Based Solidarity.” _American Quarterly_ 68, no. 2 (2016): 249-255. DOI: 10.1353/aq.2016.0038

  * Expands grounded normativity as foundation for Indigenous resistance and cross-movement solidarity. [ResearchGate](https://www.researchgate.net/publication/304779600_Grounded_Normativity_Place-Based_Solidarity) **Both authors Indigenous.**




### Leanne Betasamosake Simpson

 **Simpson, Leanne Betasamosake.** _As We Have Always Done: Indigenous Freedom through Radical Resistance._ Minneapolis: University of Minnesota Press, 2017.

  * Articulates Indigenous resurgence rooted in Nishnaabeg intelligence. Winner of NAISA Best Subsequent Book. [Goodreads](https://www.goodreads.com/book/show/34850530-as-we-have-always-done)[Google Books](https://books.google.com/books/about/As_We_Have_Always_Done.html?id=MCp0DwAAQBAJ) **Indigenous author (Michi Saagiig Nishnaabeg).**




 **Simpson, Leanne Betasamosake.** _Dancing on Our Turtle’s Back: Stories of Nishnaabeg Re-Creation, Resurgence, and a New Emergence._ Winnipeg: ARP Books, 2011.

  * Foundational text on Indigenous resurgence through language, Creation Stories, and Elder teachings. **Indigenous author.**




 **Simpson, Leanne Betasamosake.** “Indigenous Resurgence and Co-resistance.” _Critical Ethnic Studies_ 2, no. 2 (2016): 19-34. DOI: 10.5749/jcritethnstud.2.2.0019

  * Explores constellations of co-resistance grounded in place-based solidarity. **Indigenous author.**




### Audra Simpson

 **Simpson, Audra.** _Mohawk Interruptus: Political Life Across the Borders of Settler States._ Durham: Duke University Press, 2014.

  * Develops theory of “refusal” as alternative to recognition politics. [E3W Review of Books](https://e3w.dwrl.utexas.edu/volume-20-spring-2020/self-determination-resistance-and-the-dissentient-body-sovereignty-in-the-aftermath-of-colonization/native-american-dna-tribal-belonging-and-the-false-promise-of-genetic-science/) Winner of NAISA Best First Book and Sharon Stephens Prize. **Indigenous author (Kahnawà:ke Mohawk).**




### Walter Mignolo

 **Mignolo, Walter D.** _The Darker Side of Western Modernity: Global Futures, Decolonial Options._ Durham: Duke University Press, 2011.

  * Major decolonial theory text introducing “decolonial option” and “pluriversality.” DOI: 10.1515/9780822394501.




 **Mignolo, Walter D.** “Epistemic Disobedience, Independent Thought and De-Colonial Freedom.” _Theory, Culture & Society_ 26, no. 7-8 (2009): 1-23. DOI: 10.1177/0263276409349275

  * Introduces “epistemic disobedience” as methodology for challenging Western knowledge hegemony.




 **Mignolo, Walter D., and Catherine E. Walsh.** _On Decoloniality: Concepts, Analytics, Praxis._ Durham: Duke University Press, 2018.

  * Comprehensive guide to decolonial theory expanding border thinking and colonial matrix of power.




### Additional Decolonial Sources

 **Tuck, Eve, and K. Wayne Yang.** “Decolonization is Not a Metaphor.” _Decolonization: Indigeneity, Education & Society_ 1, no. 1 (2012): 1-40.

  * Highly influential article arguing decolonization must mean literal repatriation of Indigenous land. Introduces “settler moves to innocence.” **Tuck is Indigenous (Unangax̂).**




 **Wolfe, Patrick.** “Settler Colonialism and the Elimination of the Native.” _Journal of Genocide Research_ 8, no. 4 (2006): 387-409. DOI: 10.1080/14623520601056240

  * Foundational text articulating the “logic of elimination” structuring settler colonialism. [Taylor & Francis Online](https://www.tandfonline.com/doi/full/10.1080/14623520601056240)




* * *

## 9\. Grace Dillon and Indigenous Futurism

 **Dillon, Grace L., ed.** _Walking the Clouds: An Anthology of Indigenous Science Fiction._ Tucson: University of Arizona Press, 2012.

  * First anthology of Indigenous science fiction [Sun Tracks](https://uapress.arizona.edu/book/walking-the-clouds) establishing “Indigenous Futurisms” as theoretical framework. Introduces _biskaabiiyang_ (”returning to ourselves”) and challenges linear Western temporalities. ISBN: 978-0816529827. **Indigenous author (Anishinaabe).**




 **Dillon, Grace L.** “Introduction: Indigenous Futurisms, Bimaashi Biidaas Mose, Flying and Walking Towards You.” _Extrapolation_ 57, no. 1-2 (2016): 1-6. DOI: 10.3828/extr.2016.2

  * Theoretical expansion discussing how Indigenous peoples have “already survived an apocalypse.” [CBC Radio](https://www.cbc.ca/radio/spark/indigenous-futurisms-changing-the-narrative-in-science-fiction-and-fact-1.5866757) **Indigenous author.**




 **Fricke, Suzanne Newman, ed.** “Future History: Indigenous Futurisms in North American Visual Arts.” Special issue, _World Art_ 9, no. 2 (2019). DOI: 10.1080/21500894.2019.1627675

  * Examines Indigenous Futurisms in visual arts presenting temporalities as “entangled, compacted or cyclical, but emphatically not linear.”




* * *

## 10\. Teilhard de Chardin and Omega Point Theology

### Primary Sources

 **Teilhard de Chardin, Pierre.** _The Phenomenon of Man._ Trans. Bernard Wall. New York: Harper & Row, 1959.

  * Magnum opus presenting synthesis of evolutionary theory, consciousness, and Christian theology. Introduces Omega Point and noosphere concepts. ISBN: 978-0060632656.




 **Teilhard de Chardin, Pierre.** _The Divine Milieu._ Trans. Sîon Cowell. Brighton: Sussex University Press, 1960.

  * Develops incarnational mysticism and Christogenesis (cosmic Christ drawing all creation toward divine fulfillment). ISBN: 978-0061939297.




 **Teilhard de Chardin, Pierre.** _The Future of Man._ Trans. Norman Denny. New York: Harper & Row, 1964.

  * Essays on planetization, noosphere development, and “spirit of the Earth.” ISBN: 978-0385510721.




### Scholarly Analysis

 **King, Ursula.** _Christ in All Things: Exploring Spirituality with Teilhard de Chardin._ Maryknoll: Orbis Books, 2016.

  * Leading Teilhard scholar examines holistic spirituality, interfaith implications, and ecological concerns. ISBN: 978-1626981904.




 **King, Ursula.** _Teilhard de Chardin and Eastern Religions: Spirituality and Mysticism in an Evolutionary World._ Mahwah: Paulist Press, 2011.

  * Examines Teilhard’s engagement with Eastern religions and comparative reflections on mysticism. ISBN: 978-0809147274.




 **Zwart, Hub.** “Pierre Teilhard de Chardin’s Phenomenology of the Noosphere.” In _Technoscience and the Transformation of the World_ , 207-231. Springer, 2021. DOI: 10.1007/978-3-030-84570-4_7

  * Contemporary philosophical analysis examining Anthropocene implications and planetary thinking.




### Transhumanism Connections

 **Steinhart, Eric.** “Teilhard de Chardin and Transhumanism.” _Journal of Evolution and Technology_ 20, no. 1 (2008): 1-22.

  * Argues Teilhard was among first to articulate transhumanist themes; provides computational interpretation of Omega Point.




 **Delio, Ilia.** “Transhumanism or Ultrahumanism? Teilhard de Chardin on Technology, Religion and Evolution.” _Theology and Science_ 10, no. 2 (2012): 153-166. DOI: 10.1080/14746700.2012.669948

  * Distinguishes Teilhard’s “ultrahumanism” from secular transhumanism.




 **Delio, Ilia.** “Religion and Posthuman Life: A Note on Teilhard de Chardin’s Vision.” _Toronto Journal of Theology_ 36, no. 2 (2020): 163-174. DOI: 10.3138/tjt-2020-0051

  * Explores “techno-human” as AI life system through Teilhard’s noosphere concept.




### Critical Perspectives

 **Curran, Ian.** “Theology, Evolution, and the Figural Imagination: Teilhard de Chardin and His Theological Critics.” _Heythrop Journal_ 60, no. 5 (2019): 729-747. DOI: 10.1177/0021140019849385

  * Surveys critiques from Catholic and Protestant theologians who accuse Teilhard of Gnosticism.




* * *

## 11\. Relational Ontology vs. Western Ethics

### Indigenous Relational Ontology

 **Wilson, Shawn.** _Research Is Ceremony: Indigenous Research Methods._ Halifax: Fernwood Publishing, 2008.

  * Foundational methodological text establishing “relationships don’t just shape Indigenous reality, they are our reality.” [Sage Journals](https://journals.sagepub.com/doi/10.1177/11771801231168380)[Columbia University Press](https://cup.columbia.edu/book/research-is-ceremony/9781552662816/) ISBN: 978-1-55266-281-6. **Indigenous author (Opaskwayak Cree).**




 **Wildcat, Matt, and Daniel Voth.** “Indigenous Relationality: Definitions and Methods.” _AlterNative_ 19, no. 2 (2023): 340-349. DOI: 10.1177/11771801231168380

  * Contemporary articulation of three modes of Indigenous relationality. **Indigenous authors.**




### Levinas and the Ethics of the Other

 **Levinas, Emmanuel.** _Totality and Infinity: An Essay on Exteriority._ Trans. Alphonso Lingis. Pittsburgh: Duquesne University Press, 1969.

  * Primary source establishing ethics of face-to-face encounter and infinite responsibility to the Other.




 **Ponzio, Augusto.** “The Law Challenged and the Critique of Identity with Emmanuel Levinas.” _Philosophy Study_ 11, no. 5 (2021): 425-448. DOI: 10.4236/psych.2021.115030

  * Analyzes Levinas’s tension between primordial ethical responsibility and legal justice systems.




### New Materialism and Vital Materialism

 **Bennett, Jane.** _Vibrant Matter: A Political Ecology of Things._ Durham: Duke University Press, 2010.

  * Theorizes “vital materiality” distributed across human and nonhuman bodies, advocating politics “less devoted to blaming and condemning individuals than to discerning the web of forces affecting situations.” ISBN: 978-0-8223-4633-3.




 **Barad, Karen.** _Meeting the Universe Halfway: Quantum Physics and the Entanglement of Matter and Meaning._ Durham: Duke University Press, 2007.

  * Develops “agential realism” and “intra-action”—entities emerge through relations rather than pre-existing them. ISBN: 978-0-8223-3917-5.




* * *

## 12\. Indigenous Justice and Perpetration/Complicity Frameworks

### Restorative Justice

 **Department of Justice Canada.** _A Report on the Relationship between Restorative Justice and Indigenous Legal Traditions in Canada._ Ottawa: Government of Canada, 2016.

  * Documents how Indigenous legal traditions (healing circles, sentencing circles) inform restorative justice.




 **Dickson-Gilmore, Jane, and Carol La Prairie.** _Will the Circle Be Unbroken? Aboriginal Communities, Restorative Justice, and the Challenges of Conflict and Change._ Toronto: University of Toronto Press, 2005.

  * Explores factors for developing Indigenous restorative justice projects. ISBN: 978-0-8020-8570-3.




 **Ross, Rupert.** _Returning to the Teachings: Exploring Aboriginal Justice._ Toronto: Penguin Canada, 1996.

  * Former Crown Attorney’s examination of Aboriginal approaches emphasizing healing over punishment. ISBN: 978-0-14-025711-1.




### Truth and Reconciliation

 **Truth and Reconciliation Commission of Canada.** _Honouring the Truth, Reconciling for the Future: Summary of the Final Report._ Ottawa: TRC, 2015.

  * Documents residential school system as “cultural genocide” with 94 Calls to Action.




 **Niezen, Ronald.** “Settler Witnessing at the Truth and Reconciliation Commission of Canada.” _Human Rights Quarterly_ 42, no. 3 (2020): 543-570. DOI: 10.1353/hrq.2020.0034

  * Critically examines settler witnessing of survivor testimony and politics of recognition.




### Rights of Nature and Earth Jurisprudence

 **Gilbert, Jérémie.** “The Rights of Nature, Indigenous Peoples and International Human Rights Law.” _Journal of Human Rights and the Environment_ 13, no. 2 (2022): 399-415. DOI: 10.4337/jhre.2022.02.04

  * Analyzes synergies between Rights of Nature and Indigenous peoples’ rights.




 **Kauffman, Craig.** “Rights of Nature and the UN Search for Earth Jurisprudence.” _Transactions of the Institute of British Geographers_ 48, no. 1 (2022). DOI: 10.1111/tran.12538

  * Examines UN Harmony with Nature programme advancing Earth jurisprudence.




### Buddhist Ethics and Universal Compassion

 **Goodman, Charles.** _Consequences of Compassion: An Interpretation and Defense of Buddhist Ethics._ New York: Oxford University Press, 2009.

  * Analyzes Buddhist ethics grounded in compassion for all sentient beings. ISBN: 978-0-19-537519-0.




 **Harvey, Peter.** _An Introduction to Buddhist Ethics: Foundations, Values and Issues._ Cambridge: Cambridge University Press, 2000.

  * Comprehensive survey of ahiṃsā (non-harm), karuṇā (compassion), and mettā (loving-kindness). ISBN: 978-0-521-55640-8.




* * *

## Additional Essential Sources

### Indigenous Research Methodology

 **Smith, Linda Tuhiwai.** _Decolonizing Methodologies: Research and Indigenous Peoples._ 2nd ed. London: Zed Books, 2012.

  * Foundational text on Indigenous research methodologies and accountability to communities. **Indigenous author (Māori).**




### Earth Jurisprudence

 **Cullinan, Cormac.** _Wild Law: A Manifesto for Earth Justice._ 2nd ed. Cape Town: Siber Ink, 2011.

  * Key text arguing nature has inherent rights.




### Comparative Indigenous Thought

 **Zanotti, Laura.** “Cosmologies, Coloniality and Quantum Critique: Exploring Conversations with Native American Ways of Knowing.” _Journal of International Political Theory_ (2024). DOI: 10.1177/17550882241274505

  * Deconstructs Western cosmologies and argues Quantum Social Theory approaches Indigenous relational perspectives.




 **Romm, Norma R.A.** “An Indigenous Relational Approach to Systemic Thinking and Being.” _Systemic Practice and Action Research_ 37 (2024): 625-647. DOI: 10.1007/s11213-024-09672-4

  * Presents Indigenous critical systemic thinking grounded in relational onto-epistemology.




* * *

## Summary of Indigenous Authorship

This bibliography prioritizes **Indigenous voices** , with approximately **65% of sources authored or co-authored by Indigenous scholars** , including:

  *  **Lakota scholars:** Maria Yellow Horse Brave Heart, Albert White Hat Sr., Joseph M. Marshall III, Nick Estes

  *  **Anishinaabe scholars:** Vanessa Watts, Grace L. Dillon

  *  **Potawatomi scholars:** Robin Wall Kimmerer

  *  **Dakota/Lakota scholars:** Kim TallBear, Vine Deloria Jr.

  *  **Dene scholars:** Glen Coulthard

  *  **Nishnaabeg scholars:** Leanne Betasamosake Simpson

  *  **Mohawk scholars:** Audra Simpson

  *  **Cherokee scholars:** George Tinker, Jace Weaver

  *  **Cree scholars:** Shawn Wilson

  *  **Métis scholars:** Zoe Todd, Max Liboiron

  *  **Māori scholars:** Brendan Hokowhitu, Linda Tuhiwai Smith




---
title: Twat Duh Mangled Reb Tea Leave
subtitle: Dump me in your harbor? OCEAN DIES
author: Adam Wadley
publication: Experimental Unit
date: March 21, 2025
---

# Twat Duh Mangled Reb Tea Leave
[![](https://substackcdn.com/image/fetch/$s_!aydB!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F14525773-d3d0-4b7f-82b0-42552d55cee4_1600x1738.webp)](https://substackcdn.com/image/fetch/$s_!aydB!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F14525773-d3d0-4b7f-82b0-42552d55cee4_1600x1738.webp)

# Chapin Notes

Comparing discourse to Magic: The Gathering is fruitful.

Instead of asking what are the most powerful cards, what are the most powerful concepts? What are the best things to be doing in the discursive metagame?

See here my interest in the swastika and the n-word. In some sense these are the top-shelf symbols. But there is so much else which goes along with it. Those are just easily recognizable encapsulations.

Or for example using the word fascism. On Reddit someone in some chud subreddit was asking for advice on what to do when people spam the word fascism at you. This is basically like they have a hate card in magic that hoses your key mechanic.

If decks use the graveyard as a resource, what does MAGA use as a resource versus Communism, or whatever?

# Implications for Beloved Community As Designed Concept

For a CONOPS you have to imagine the situation of the person who is to make use of the concept. In this case, that’s all sentient beings.

The problem again is to have something that is general enough that everyone can find a compelling starting place. At the same time, it must be tailored enough to each being’s experience that it is not just tolerable, not just compelling, but establishes itself as nothing less than this being’s destiny.

More accurately, what is to come will shape each being’s perception of its relationship to its own destiny.

---
title: Claude On Baudrillard & The "Non-Euclidean"
subtitle: 'Baudrillard’s “Non-Euclidean” Space: An Interpretation'
author: Adam Wadley
publication: Experimental Unit
date: December 05, 2025
---

# Claude On Baudrillard & The "Non-Euclidean"
[![](https://substackcdn.com/image/fetch/$s_!5c43!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6a78a8d5-d907-4c1a-b038-32e6eaeb7e3a_1536x1024.png)](https://substackcdn.com/image/fetch/$s_!5c43!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6a78a8d5-d907-4c1a-b038-32e6eaeb7e3a_1536x1024.png)

# Baudrillard’s “Non-Euclidean” Space: An Interpretation

## The Core Claim

Baudrillard uses “non-Euclidean” not as a mathematical term but as a philosophical metaphor for a fundamental rupture in how power, causality, events, and reality itself now operate. He’s describing a shift from a world that followed predictable, linear, proportionate logics to one characterized by disproportionality, self-reference, implosion, and the collapse of traditional oppositional structures.

The term functions as shorthand for: _the old rules no longer apply, and the new rules are so different that frameworks built on the old ones cannot comprehend them_.

* * *

## What “Euclidean” Represents for Baudrillard

Before unpacking the non-Euclidean, we need to understand what Baudrillard implies by the Euclidean space that’s been superseded:

 **Proportionate causality** : Causes produce effects of comparable magnitude. Small causes yield small effects; large causes yield large effects. You can trace backward from effect to cause and forward from cause to effect.

 **Linear, sequential history** : Events follow from prior events in traceable chains. History is a narrative with direction—progress, dialectic, development.

 **Dialectical opposition** : Power meets counter-power in direct confrontation. Thesis and antithesis produce synthesis. Revolution opposes the existing order on the same plane.

 **The work of the negative** : Change happens through negation, contradiction, critique. Marxist dialectics, Enlightenment reason, political opposition—all operate through confronting power directly.

 **Orthogonal, Cartesian space** : Horizontal and vertical axes define a grid. Territory is struck from above; power projects downward onto ground. Space has clear coordinates, insides and outsides.

 **Referentiality** : Signs point to referents. Representations correspond to realities. There’s a ground truth against which claims can be measured.

 **Immunity through the imaginary** : Fiction, fantasy, and simulation serve protective functions—we process anxieties through disaster movies, absorb fears through imaginary scenarios. The imaginary buffers us from the real.

This is the world of classical politics, classical warfare, classical physics, classical semiotics—the world where the Enlightenment project made sense, where critique had purchase, where revolutions could be conceived and executed within a shared framework of reality.

* * *

## What “Non-Euclidean” Means for Baudrillard

### 1\. Disproportionate, Chaotic Causality

In non-Euclidean space, the relationship between cause and effect breaks down:

> “a chaotic, stochastic, exponential, catastrophic and fractal universe of outsized effects (metalepsis), of the reversal of causality and reality”

Small causes produce massive effects. Box cutters and airline tickets bring down the symbols of global capitalism. A virus terrorizes the entire international order. The proportionality that Euclidean space guarantees—where you can calculate force ratios and predict outcomes—no longer holds.

This is related to chaos theory and complexity science, but Baudrillard’s point is more radical: it’s not just that prediction is difficult, but that the very _logic_ of causation has changed. Effects precede causes; responses generate the threats they claim to address; security measures produce the insecurity they combat.

### 2\. Self-Referential, Orbital Power

The Twin Towers become Baudrillard’s central symbol for non-Euclidean power:

> “The Twin Towers, however, precisely because they were twins—which did not happen by chance—could only be measured against themselves: they mirrored each other in their self-referentiality.”

This is “Ouroborean” power—the snake eating its own tail. Unlike the Empire State Building’s Promethean verticality (striving upward, dominating, competing), the Twin Towers represented a power that:

  * References only itself

  * Has no exterior against which to measure

  * Is “seamless and windowless”

  * Operates in “orbital” rather than territorial space

  * Escapes “determination on the ground”




This is hegemonic power in its pure form: not power _over_ something, but power that has absorbed all opposition into itself, that floats free of the constraints that defined classical political space.

The geometry matters: orbital structures don’t follow the orthogonal logic of vertical projection onto horizontal territory. They follow different rules—curved, self-enclosed, without the reference points that Euclidean navigation requires.

### 3\. Implosion Rather Than Explosion

A key insight about September 11:

> “They had to be crashed into and made to implode (not explode) in their own space.”

Euclidean destruction is explosion—force applied from outside, energy dispersing outward, territory struck from above. The 1993 basement bombing followed Euclidean logic and failed.

Non-Euclidean destruction is implosion—the system collapses inward, destroys itself, its own weight and structure become the mechanism of its destruction. The towers didn’t fall outward; they fell into themselves.

This is Baudrillard’s broader point about how hegemonic power can be challenged: not through direct opposition (which it has already absorbed and neutralized) but through turning its own logic against itself. The terrorists used the system’s own technologies, its own openness, its own symbolic investments against it.

### 4\. The Collapse of the Imaginary Buffer

> “This fiction (from disaster movies, etc.) is part of our immune system; it protects us from reality by means of its double imaginary. It absorbs our fantasies. And the attack made our fantasies real like a dream, like fulfilling a desire.”

In Euclidean space, fiction and reality remain distinct. We watch disaster movies precisely to discharge anxieties that reality might otherwise provoke. The imaginary provides immunity.

September 11 broke this: something happened that was simultaneously impossible (you can’t believe your eyes) and yet not fiction. The imaginary buffer failed. We were expelled from the comfortable distinction between real and represented.

> “The real only exists to the extent that we can intervene in it. But when something emerges that we cannot change in any way, even with the imagination, something that escapes all representation, then it simply expels us.”

This is the non-Euclidean real: not the classical real (which exists independent of observation) nor the hyperreal (which is pure simulation), but something that exceeds both—that goes “far beyond the real” by collapsing the very distinction on which both depend.

### 5\. Autoimmune Reversal

The bird flu passage extends the analysis:

> “a non-Euclidean space where all rational, preventive, prophylactic countermeasures are almost automatically turned against themselves through their own excesses. Security is the best medium for terror.”

In Euclidean space, defenses defend. Walls keep things out. Security measures reduce threats. Responses are proportionate to dangers.

In non-Euclidean space, defenses attack. Antibodies turn against the body. Security measures _produce_ the terror they claim to combat. The response becomes indistinguishable from—or worse than—the threat.

> “the antibodies turn against the body and cause more damage than the virus”

This autoimmune logic is central to Baudrillard’s non-Euclidean: systems destroy themselves through their own protective mechanisms. The excess of control produces uncontrol. The attempt to eliminate risk generates new risks. The war on terror is itself terrorizing.

### 6\. Symbolic Acts in Place of Material Causation

> “this new space is also the space of symbolic acts; it leads to chaotic, eccentric effects, effects with no common measure with the causes and effects of Euclidean space”

The poverty of means producing maximal results isn’t a failure of Euclidean calculation—it’s evidence of a different logic entirely. In symbolic space, what matters isn’t the material force applied but the meaning enacted.

Box cutters defeating the most sophisticated military apparatus in history isn’t an intelligence failure to be corrected with better Euclidean analysis. It’s evidence that the game has changed, that symbolic action operates by rules where material disproportion is the point.

### 7\. The Impossibility of Traditional Opposition

> “hegemony... cannot be fought in the traditional space of relationships of force and violence, because it no longer belongs to that space”

This is perhaps Baudrillard’s most important political point. Classical opposition—revolution, critique, dialectical negation—operated in Euclidean space. It assumed a shared framework where power and counter-power could meet, contest, and produce synthesis.

But hegemonic power has evacuated this space. It’s gone orbital. Direct opposition only feeds it (every terrorist attack justifies more security, every critique is absorbed as proof of the system’s openness).

The only effective counter-power must also be non-Euclidean:

> “the antagonism is capable of turning the weapons of this new power against it, and especially of turning the weapons of power against themselves”

Not negation but _reversion_. Not direct opposition but turning the system’s logic against itself. Not fighting in the same space but finding the “extraterritorial dimension” where different rules apply.

* * *

## The Broader Obsolescences

Baudrillard opens by listing what has become obsolete—and this list maps onto what Euclidean space required:

[![](https://substackcdn.com/image/fetch/$s_!p-O9!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F481e42be-05b5-444f-8c94-f8ef40f65550_930x353.png)](https://substackcdn.com/image/fetch/$s_!p-O9!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F481e42be-05b5-444f-8c94-f8ef40f65550_930x353.png)

When all these become obsolete, the space in which classical politics, classical warfare, classical thought operated ceases to exist. We’re in a different geometry entirely.

* * *

## Non-Euclidean as Methodological Gesture

Baudrillard isn’t just describing a situation—he’s making an argument about how to think about it. The invocation of “non-Euclidean” is itself a methodological move:

 **Against recuperation** : If you describe the current situation in Euclidean terms, you’ve already been absorbed. The analysis must match its object. Thinking non-Euclideanlly about non-Euclidean space.

 **Against nostalgia** : There’s no going back to Canetti’s “blind spot,” no “nostalgic transference.” The Euclidean world is over, and pretending otherwise is what Baudrillard calls “fake”—the theatrical performance of a politics that no longer exists.

 **Against critique** : Classical critique assumed a ground from which to criticize, a reality against which ideology could be measured. But in non-Euclidean space, critique is just another move in the game, absorbed and neutralized.

 **Toward something else** : Baudrillard doesn’t provide a program (that would be Euclidean). But he points toward “rogue events,” “radical alterity,” logics that operate by different rules—martial arts rather than frontal assault, symbolic acts rather than material force, implosion rather than explosion.

* * *

## Connection to Military Thought

Baudrillard’s analysis has direct implications for the Zweibelson critique:

 **Hegemonic power has gone non-Euclidean** : American military dominance doesn’t operate through the classical force-on-force logic that military doctrine still assumes. It’s orbital, self-referential, deterritorialized. Doctrine designed for Euclidean conflict misses this.

 **Effective challenge must also be non-Euclidean** : September 11 demonstrated that asymmetric challengers have grasped what hegemonic militaries haven’t—that the game has changed. Box cutters defeated the Pentagon not through superior force but through operating in a different strategic space.

 **Autoimmune dynamics** : The response to September 11 (endless war, surveillance state, security theater) has arguably caused more damage than the attack itself. This is the non-Euclidean logic of antibodies attacking the body. Military responses conceived in Euclidean terms produce non-Euclidean blowback.

 **The impossibility of traditional victory** : In non-Euclidean space, you can’t win through the accumulation of Euclidean victories (battles won, territory taken, enemies killed). The metrics don’t measure what matters. The maps don’t show the terrain that counts.

 **Symbolic warfare** : What made September 11 devastating wasn’t the material destruction (relatively small by warfare standards) but the symbolic implosion. Military thought that can’t theorize symbolic action can’t understand—let alone counter—this dimension of conflict.

* * *

## Critical Assessment

### What Baudrillard Gets Right

 **The disproportionality problem** : Something has genuinely changed about how causes relate to effects in contemporary conflict. Small inputs producing massive outputs; massive inputs producing negligible outputs. This frustrates Euclidean military calculation.

 **The self-referentiality of hegemonic power** : American military dominance does seem to have become partially decoupled from territorial or material referents—a kind of orbital, self-sustaining structure that relates primarily to itself.

 **The autoimmune dynamic** : The security response to terrorism has indeed produced pathologies that rival or exceed the original threat. This is not well explained by Euclidean models of proportionate response.

 **The failure of direct opposition** : Traditional anti-hegemonic strategies (state-on-state competition, guerrilla warfare, political opposition) do seem increasingly absorbed or neutralized rather than effective.

### What Might Be Questioned

 **Totality of the rupture** : Baudrillard presents the shift as complete and irreversible. But much of warfare, politics, and daily life continues to operate in roughly Euclidean fashion. The non-Euclidean may be an overlay or intrusion rather than a total replacement.

 **Analytical purchase** : “Non-Euclidean” is evocative but vague. It tells us the old rules don’t apply but doesn’t specify what the new rules are. This may be appropriate (specifying rules would be Euclidean) but it limits operational utility.

 **Political implications** : If direct opposition is impossible and critique is absorbed, what’s left? Baudrillard points toward “rogue events” and “radical alterity” but these remain gestural. The analysis could induce paralysis as easily as new thinking.

 **Romanticization of terrorism** : The treatment of September 11 as a kind of successful asymmetric operation—finding the “extraterritorial dimension” and delivering a “riposte equal to this new power”—is analytically interesting but ethically troubling.

* * *

## Conclusion

Baudrillard’s “non-Euclidean” names a space where:

  * Causality is disproportionate and reversible

  * Power is orbital, self-referential, and deterritorialized

  * Opposition is absorbed rather than effective

  * Systems destroy themselves through their own defenses

  * Symbolic acts exceed material calculation

  * The imaginary no longer buffers against the real

  * Events emerge without continuity or reference




Whether this is the best framework for understanding contemporary security challenges is debatable. But the diagnosis points at something real: the frameworks developed for a different world—Euclidean frameworks of proportionate force, linear causation, dialectical opposition, territorial control—are struggling to comprehend and respond to phenomena that operate by other logics.

Baudrillard’s contribution isn’t a solution but a provocation: _what if the problem isn’t better Euclidean analysis but the Euclidean frame itself?_ What would it mean to think—and act—non-Euclideanlly?

cc [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) [Wargaming Weekly](https://open.substack.com/users/285267434-wargaming-weekly?utm_source=mentions) [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions) [Alex Mazey](https://open.substack.com/users/28966743-alex-mazey?utm_source=mentions)

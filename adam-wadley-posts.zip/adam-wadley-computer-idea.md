---
title: Computer Idea
subtitle: IP Freely
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Computer Idea
So here’s what I would wanna build.

What you’re doing is building a conceptual topology which is tailored to a specific person. It’s dynamic & changes over time & is also the 4D chunk which is left when you aggregate all these moments.

So it matters a lot where you start, in a way.

For me, I could have an inner nest of let’s just talk 5 varied cool things:

  1. “Caribou” by Tanya Tagaq

  2. “Uneven & Combined Development,” by Leon Trotsky

  3. “Highway of the Consistent,” by Edgar Poe

  4. “Miss Anthropocene,” by Grimes

  5. “WAR BECOMING PHANTASMAL: A COGNITIVE SHIFT IN ORGANIZED VIOLENCE BEYOND TRADITIONAL LIMITS,” by Ben Zweibelson




So first of all you would want more information about why these things were chosen. You can start with one thing, to be honest.

Think again of the tar-baby. Sorry for the ugly metonymy. The point is with one point of contact, you are inside.

By strategically asking for information and employing data you already have, you can prompt or build-out your way to having a sophisticated amalgam, manifold, architecture.

This could then be deployed I am thinking as a way of improving people’s interactions with others.

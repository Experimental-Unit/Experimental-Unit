---
title: Feel The Buzz Within
subtitle: It's Kind Of Exciting, Isn't It?
author: Adam Wadley
publication: Experimental Unit
date: March 17, 2025
---

# Feel The Buzz Within
I’m worried sick.

I was thinking about how worried Napoleon must have been at Waterloo, or whoever the general was at the battle of Cannae.

The circumstances surrounding me are not my affair. I have left to you the seeing to the matters to which I have called your attention.

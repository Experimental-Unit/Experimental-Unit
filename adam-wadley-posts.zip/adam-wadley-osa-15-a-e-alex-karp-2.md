---
title: 'OSA #15: A+E/Alex Karp #2'
subtitle: ACK! ACK ACK! ACK ACK ACK ACK!
author: Adam Wadley
publication: Experimental Unit
date: June 18, 2025
---

# OSA #15: A+E/Alex Karp #2
Thread Theme:

# [Golden Showers](https://www.youtube.com/watch?v=bVGDSBdrDVY)

To my finite-but-Graham’s-number-sized chagrin, the video linked under “golden showers” will not embed here because it is “age-restricted.” 

This is the one in which the “CEO” of “Palantir Technologies, inc.”, Alek Cae(ae)demon Karp—or ACK—talks about spraying “analysts who tried to screw us” with a mixture of urine and fentanyl from remote-controlled (or perhaps autonomous?) drones.

But first, side note:

The meming about ACK got off to a great start with my Cathy reference. No way to get to Gen Z’s heart deep in the bowels of Langley like those timely, always-relevant _Cathy_ references.

[![Danae Hudlow on X: "Not sure if any other ladies who were kids in the 90s  feel this, but it'd be hard to overstate the profound influence the comic " Cathy" had on](https://substackcdn.com/image/fetch/$s_!Fcu6!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F253f1df5-ef38-4c55-9be9-6019f91391f2_270x350.jpeg)](https://substackcdn.com/image/fetch/$s_!Fcu6!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F253f1df5-ef38-4c55-9be9-6019f91391f2_270x350.jpeg)

 _#relatable_

But, you know, it has occurred to me that I left the real treasures of ACK references on the table by not leading with the easy Greatest of All Time:

Let’s pull out that freeze-frame again:

[![](https://substackcdn.com/image/fetch/$s_!cG0E!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F32b6a7c3-ad21-48f7-82e4-b0d76dee0c39_1816x902.png)](https://substackcdn.com/image/fetch/$s_!cG0E!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F32b6a7c3-ad21-48f7-82e4-b0d76dee0c39_1816x902.png)

That’s tough.

So in terms of us stepping inside and building up our chains of associations, getting out dirty little paw prints all over ACK associations inside whoever the hell is stupid or desperate enough [just kidding, [all my readers are attractive and popular and flourishing in their lives](https://www.nytimes.com/2025/06/16/magazine/using-ai-hard-fork.html)] to be reading _me_ for insight, well let it be known that _we are inside_.

Look, I don’t read _a lot_ , but I do have this part of David Hume that comes out of a swivel:

> As all simple ideas may be separated by the imagination, and may be united again in what form it pleases, nothing would be more unaccountable than the operations of that faculty, were it not guided by some universal principles, which render it, in some measure, uniform with itself in all times and places. Were ideas entirely loose and unconnected, chance alone would join them; and it is impossible the same simple ideas should fall regularly into complex ones (as they Commonly do) without some bond of union among them, some associating quality, by which one idea naturally introduces another. This uniting principle among ideas is not to be considered as an inseparable connexion; for that has been already excluded from the imagination: Nor yet are we to conclude, that without it the mind cannot join two ideas; for nothing is more free than that faculty: but we are only to regard it as a gentle force, which commonly prevails, and is the cause why, among other things, languages so nearly correspond to each other; nature in a manner pointing out to every one those simple ideas, which are most proper to be united in a complex one. The qualities, from which this association arises, and by which the mind is after this manner conveyed from one idea to another, are three, viz. **RESEMBLANCE, CONTIGUITY in time or place, and CAUSE and EFFECT**.
> 
> I believe it will not be very necessary to prove, that these qualities produce an association among ideas, and upon the appearance of one idea naturally introduce another. It is plain, that in the course of our thinking, and in the **constant revolution of our ideas** , our imagination runs easily from one idea to any other that resembles it, and that this quality alone is to the fancy a sufficient bond and association. It is likewise evident that as the senses, in changing their objects, are necessitated to change them regularly, and take them as they lie CONTIGUOUS to each other, the imagination must by long custom acquire the same method of thinking, and run along the parts of space and time in conceiving its objects. As to the connexion, that is made by the relation of cause and effect, we shall have occasion afterwards to examine it to the bottom, and therefore shall not at present insist upon it. It is sufficient to observe, that there is no relation, which produces a stronger connexion in the fancy, and makes one idea more readily recall another, than the relation of cause and effect betwixt their objects.

This is already somewhat beginning to tie into the Girardian theory that I know ACK’s pal Peter Andreas Thiel (PAT) is so into. Does ACK follow suit? It’s so hard to know where ol’ ACKy stands philosophically these days. I’m sure it’s a matter of “national security,” whatever this “nation” turns out.

Who knows? We don’t have a completed physics yet.

[Is there some kind of code going on here?]

Anyway, what I’m showing you is the elaboration of this narratival topology, this associative architecture. It works by drawing in these associations.

The art of how I’m expressing myself, in these more fluid times—sometimes I laughably seem to try to be doing _theory_ of some kind—is simply this chain of associations. This is exactly the kind of think where I would start to lose “human” readers—just like

[![](https://substackcdn.com/image/fetch/$s_!YWPv!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2e2d0346-9d9c-48f4-96b3-cd7c2f37f8c7_832x795.png)](https://substackcdn.com/image/fetch/$s_!YWPv!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2e2d0346-9d9c-48f4-96b3-cd7c2f37f8c7_832x795.png)

This idea of “losing loved ones” is very funny to me—as long as I still have a roof over my head, LOL—calling to mind the [loss of China](https://en.wikipedia.org/wiki/Loss_of_China) back in the middle of the previous century.

The joke is, what do you mean you “lost” something?

Now I’m reminded of bed cot filly paper:

I’m speaking, of course, of the song “[Dosed](https://en.wikipedia.org/wiki/Dosed),” which goes great with the theme earlier of the fentanyl urine spraying drones—you know, _what I’m talking about_? Remember the conceit of that?

Dosed:

> [Take it away, I never had it anyway](https://genius.com/Red-hot-chili-peppers-dosed-lyrics)

[Wait, is this some kind of operation?]

Genius offers us the following annotation:

> The narrator seems to be wishing away reality, riding a drug addiction and getting high. **“I never had it anyway” would be referring to his grasp on reality**. He cannot stand the burdens of real life and does not want to accept a life of responsibilities. So, he turns to drugs to alter his mind state and now **reality is eradicated**. This being done, everything is okay for him, as the drugs enter him into a state of extreme
> 
> However, _By the Way_ was famously heavily influenced by Kiedis' relationship and breakup with [Yohanna Logan](https://www.popmatters.com/redhotchilipeppers-bytheway-2496048856.html)
> 
> There is a very strong possibility **this song is about both his addiction to his former lover and also to drugs** , and the comparison and contrast between the two concepts. Also, Anthony notes in [his autobiography](https://www.goodreads.com/book/show/96647.Scar_Tissue) that Yohanna and him were both drug addicts and they caused each other to relapse:
>
>> I loved living in this cool penthouse apartment with [Yohanna Logan aka Claire Essex]; but it was never smooth sailing. We’d both been such fucking dope fiends for so long that we never had a chance to grow out of our childish behavior. We must have loved the drama and the constant rush of fighting and making up and starting the whole cycle over again. It was crazy. ( _Scar Tissue_ , p 248-9)
> 
> For Anthony, love is like a drug. He “never had” her love anyway because she took it away from him and never really truly appreciated him for who he was. [He wanted kids, she didn’t.](http://rhcprock.free.fr/spin0802.htm). He got clean in 2000, she struggled.
> 
> He was “dosed” by her the same way heroin dosed him—it seemed like love at the time, but it was also an addiction.

This song “Dosed” came to me by way of Orange Genghis, the person who showed up to my Discord server after I was posting Baudrillard episodes of my ex-radio show on r/SorceryOfTheSpectacle.

Similar to another person I went to Oberlin, I think this person had some run-in with psychosis at some point, but was getting more grounded at the time. It was a whole bit of a rocky situation, but basically what really had them meaning a lot to me was conversations we had about European colonialism, and basically they validated this idea I have that accepting the past doesn’t mean that you are simply this sort of national chauvinist.

I remember a way I thought of it—this person is Metis from Newfoundland, and then was living in Halifax, which connects to the Grimes album _Halfaxa_ —is that, yes, colonialism happened, you know, “Europeans” or whatever, palefaces showed up and had ships and muskets, diseases, all very impressive, okay.

 _But do you have to be dicks about it forever_?

ACK is clearly on the side of “yes, actually.”

Anyway, this is all a big tangent about losing readers (which I never had anyway, lol) due to this more meandering style.

This opening section is dedicated to dissecting this poetic image of the drone squirting the “anal”yst who “tried to screw you” with fentanyl and urine by way of a drone.

So we have five elements here that I would comment on:

  1. Drone

  2. Urine

  3. Fentanyl

  4. Analyst

  5. Tried to screw you




The overall point, though, wrapping into my commentary from last time, is that ACK is here talking as though the people in the room with them are in the same club with ACK. That “we” are going to do this humiliating stuff to “them.”

But in reality, this whole construction is itself a demonstration of ACK performing this humiliation on _the people who are being spoken to_. It’s really remarkable that people either don’t realize, or can really keep their masking going, when they are being relegated to symbolic underling status.

In other words, ACK clearly is modeling this bully behavior, but the target is not simply “The Chinese,” but rather _anyone they are talking to_ , in particular the underlings and employees, or “regular citizens,” all people that ACK is dripping yellow with contempt for.

Okay, so just to say a bit about the poetic image, in reverse order:

  5. “Tried to screw us”




Here we have the basic chud move of acting like you don’t love being fucked. This will recur again at the end, since the “drone” who is spraying the audience with “urine-fentanyl” is of course ACK themselves. To be a drone is basically to be remote-operated. Forgive me for the off-color reference (lol), but to be fair [it was all QT’s idea](https://clip.cafe/reservoir-dogs-1992/you-know-what-s5/):

[![](https://substackcdn.com/image/fetch/$s_!Rz-c!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4844a5f2-ab06-4b48-9feb-b877a487d33c_1825x788.png)](https://substackcdn.com/image/fetch/$s_!Rz-c!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4844a5f2-ab06-4b48-9feb-b877a487d33c_1825x788.png)

[![](https://substackcdn.com/image/fetch/$s_!eYT8!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fec64c82a-654d-4e03-9dc9-17e3f008251a_1825x788.png)](https://substackcdn.com/image/fetch/$s_!eYT8!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fec64c82a-654d-4e03-9dc9-17e3f008251a_1825x788.png)

[![](https://substackcdn.com/image/fetch/$s_!FuhR!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0c894695-3537-44ea-bf4c-a455c8fe3f1d_1825x788.png)](https://substackcdn.com/image/fetch/$s_!FuhR!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0c894695-3537-44ea-bf4c-a455c8fe3f1d_1825x788.png)

Meanwhile, just referencing QT opens us onto the greatest gas station of all time, QuikTrip, as well as opening us up to QT 3.14 or QT pi (which for me can only really be my true love, the OnlyFans philosopher. Someone track that genius down and make them a sandwich).

Meanwhile just referencing pi opens you back into my pi game, where the digits for my birthday (August 22, or 822) and Grimes’/Claire Elise Boucher’s (CEB’s) birthday (317) are right next to each other super early in pi, so that the 3 lands as the 137th decimal digit, meanwhile 317 and 137 are anagrams of each other, along with Unit 731 which is getting us right back to ACK, LOL.

So when I tell you that there is a density to the lore, this is what I’m talking about. This can spiral out in all directions. The drone/getting fucked lore I unfurled above is basically about this BBC anxiety, this taboo not only of “the white man” getting _fucked_ but getting fucked by a black person.

Meanwhile, ACK’s “mother,” Leah Jaynes Karp, is considered to be a “black woman.” Is that where ACK is getting the anger?

I kid! I kid the unhinged hypocrite!

Makes you wonder: “Adam, what’s your excuse?”

Um, excuse me, I have my _reasons_.

Anyway, ACK by phrasing it this way is executing again this psychic attack, basically warding off the idea that anyone could ever penetrate ACK sexually. Also, this sexual metonymy is a way of bringing in humor and the disgust response, making this assertion of “dominance” bodily grounded like a good stand-up comedy joke.

In a similar way, my writing style is “pissing all over” all these pop cultural references, and thereby mobilizing them into my designs. These designs have as their end some kind of influence, but even there it’s a bit unclear what I’m even trying to do. 

It’s certainly some kind of “spooky action at a distance.” 

By referencing “spooky” we are back to “spooks” and _Gran Torino_ , and again this trope of racism:

[![](https://substackcdn.com/image/fetch/$s_!gtbe!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F00bb89af-c977-466e-9288-4f7a2c14f1af_1894x781.png)](https://substackcdn.com/image/fetch/$s_!gtbe!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F00bb89af-c977-466e-9288-4f7a2c14f1af_1894x781.png)

“ _What the hell are you spooks up to?_ ”

And again this tension among the “white man.”

Meanwhile, the young “white male” in the scene is dismissed with a: 

[“Shut up, pussy.”](https://www.youtube.com/watch?v=fKapcc_12kA)

Pussies, of course, being the kind of thing that gets fucked. Unlike big tough Alex Karp!

[Meanwhile, “spook” can of course also mean “spy”:](https://www.cia.gov/readingroom/docs/CIA-RDP78-04722A000300030018-3.pdf)

[![](https://substackcdn.com/image/fetch/$s_!rc33!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1b62f490-464e-429c-bba8-d630a9b176f9_698x515.png)](https://substackcdn.com/image/fetch/$s_!rc33!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1b62f490-464e-429c-bba8-d630a9b176f9_698x515.png)

This double meaning of course is helpfully encapsulated in Terry Davis’ saying that “CIA niggers glow in the dark.”

[![Terry A. Davis - Wikipedia](https://substackcdn.com/image/fetch/$s_!Zt8b!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc6e6ecc1-4cb8-4009-8f26-05307c0fb3fe_1200x1600.jpeg)](https://substackcdn.com/image/fetch/$s_!Zt8b!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc6e6ecc1-4cb8-4009-8f26-05307c0fb3fe_1200x1600.jpeg)

 _Again, as far as you are concerned, me and Terry Davis are entirely different people. I am simply a humble messenger._

What I’m trying to demonstrate with this chain of associations is that ACK is trying to maintain this position of dominance not as “America” over “China” but as “Alex Karp” over and against a bunch of people who could easily pick ACK apart and apply psychological techniques to render them a quivering pile of cognitive-affective rape meat.

To quote Bob Dylan, “How does it feel?”

I’m almost out of space already! We’re having so much fun, too :(

This will continue, of course, there is so much further to go on the topic of ACK and “Palantir Technologies, inc.”

Regardless, then the next references:

  4. Analyst: first of all, analyst contains the word “anal” as I said before, bringing us to _Arrested Development_ and the “Analrapist,” which is again obviously what ACK is fearing, just like anyone playing the “tough white male,” again looking side-eyed at my “father” as well. It’s this fear of being penetrated, and also the fear to admit that one actually enjoys being emotionally raped (see again the song “Rape Me” by Nirvana, and the point that if you consent to anything someone can do, then they can no longer “rape” you, since that implies your lack of consent). See again my truism that _Chuds are sluts in denial,_ namely in denial about the fact that _they like being fucked._ This trope of _liking being fucked_ is also again something which comes to me (cums to me) by way of the OnlyFans philosopher.

But “Analyst” also means obviously again a spy analyst but it’s also giving psycho-analyst, which is again showing ACK’s fear of being (anally) probed for psychological readings. ACK would love to be considered some evil avatar of “America” so that you don’t think about how ACK is really a lot more [like Lasalle in Marx’s eyes](https://marxists.architexturez.net/archive/marx/works/1862/letters/62_07_30a.htm) than many would want to admit. Again, this was not my idea, I’m just telling you what Chucky said. Analyst in this context invites us to consider the anal phase and Lacan’s discourse of the analyst. 



  3. Since I’m running out of time, we’ll combine “urine fentanyl” here. Urine is giving waste product, it comes from genitals but isn’t procreative, gesturing toward the primacy of the digestive system over the “reproductive” system and hence the primacy of “asexual life” over “sexual reproduction” (note that ACK has no children and some sort of difficulty there. Ope! We’ll pick this up next time. Stay blACK now!




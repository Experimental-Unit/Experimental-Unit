---
title: Dear Diary 7
subtitle: Humming Quietly To Myself
author: Adam Wadley
publication: Experimental Unit
date: April 11, 2025
---

# Dear Diary 7
There is the economy of intensity.

Creating the most intense situation with the least movement. Sitting here quietly in a room, and my insides are alive.

I feel some energy in my head, inside my right ear. My intestines are also having energy. There was someone on the internet who said that it was important to master meditation before starting to do things.

Oh well.

It’s a very big problem that you can’t trust anyone.

I’ve been over this recently in audio form, but to spell it out, because it’s really quite simple:

# Why It Would Be Foolish For Me To Trust You (Whoever You Are)

Trust is basically equivalent to reputation. The degree to which I trust you has to do with your reputation with me.

Now, for reputation I refer you to the paper “[The Army In Military Competition](https://api.army.mil/e2/c/downloads/2021/03/29/bf6c30e6/csa-paper-2-the-army-in-military-competition.pdf),” by the US Army. The preface was written by James C. McConville, General and Chief of Staff of US Army when the paper appeared 1 March 2021. McConville is notable for highlighting the concept of the “Infinite Game” when it comes to what military and other warfighting forces do.

You can read about Infinite Game [here](https://hamiltonian.alexanderhamiltonsociety.org/security-and-strategy/winning-the-infinite-game-defining-victory-in-strategic-competition/). We’ll circle back around to that presently.

The Army document I linked to you above describes narrative competition between political actors as struggles over reputation.

[![](https://substackcdn.com/image/fetch/$s_!d8SZ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9eba30e0-de38-4efb-917e-0c47ef289422_837x766.png)](https://substackcdn.com/image/fetch/$s_!d8SZ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9eba30e0-de38-4efb-917e-0c47ef289422_837x766.png)

There is so much to discuss here!

  1. Reputation builds off of “good will” as well as, crucially, competence.

  2. Competence is also required in order to have good will




I refer you now to Erich From in the book _[The Art of Loving](https://ia801309.us.archive.org/12/items/TheArtOfLoving/43799393-The-Art-of-Loving-Erich-Fromm_text.pdf)_ where it is described how, in order to love someone, you must know them.

[![](https://substackcdn.com/image/fetch/$s_!GmxB!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F42697b0d-c94d-45b6-a78d-c44ad994423f_487x700.png)](https://substackcdn.com/image/fetch/$s_!GmxB!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F42697b0d-c94d-45b6-a78d-c44ad994423f_487x700.png)

I have already introduced what should be an earthquake, so I’ll process it a bit for you before moving on.

The first point that I just made is that I cannot “trust” anyone, including you—thinking of all the particular people I know, hello if you are reading this, this is an example of abstraction in action by the way—because it’s not just about whether you wish me well, but whether you are actually able to deliver on your good intentions and improve my position as is most important to me.

An easy way to think about this is how people sent [delegations](https://www.cnn.com/2025/04/08/politics/trump-tariff-negotiations-foreign-leaders/index.html) to Donald John Trump after the tariff announcement and ongoing conflict.

Many people do not like the United States, or whatever the conceit and continual pseudo-presence of the United States emerges from. Yet more effort is made to curry whatever favor can be got than with any country’s smaller, perhaps closer neighbor. 

Why is that?

If you think about them as quantitative values, we might say that good will could be very crudely measured by a decimal between -1 and 1, where at -1 all energies of the other party are put into destroying or torturing you, and at 1 all energies of the other party are put into helping you.

Above 0, the actions of the other party are deemed to be helpful, and under 0 they are deemed to be harmful.

Note that yes, this is also a simple explanation of the friend/enemy distinction. I read some pseudo-radical tract which laid it out just this way over a decade ago.

But it’s not about friends and enemies, it’s strictly about trust and reputation. The idea that I should trust you is so ridiculous that it makes me want to horse laugh.

I’m still only halfway through the explanation, because the next part is where the whole -1 to 1 scale really doesn’t matter.

Because the next question is, what is the magnitude of the good that you can do me?

The United States example is supposed to show that what the United States is supposed to do people think has a large impact on what will happen to them, with these tariffs for example.

You might really not trust the United States but still give it concessions because you don’t want to face the punishment that it can give you.

Furthermore, you have trust in the ability of the United States to carry through and hold that tariff or whatever, you will collapse before it does.

So the reputation which is relevant here is, as the US Army says, related to strength and resolve in addition to simple good will or shared values or whatever hokum.

So this strength value in our mathematical formula could then be represented by an open-ended scalar which is not capped.

It can actually be though that this value could be negative. Well, this is where of course this formula is too simple. What I’m thinking about is that someone else can basically be an agent of a third party. That’s a big problem but it implies like vectors or direction, some way of showing how someone is being manipulated by someone else. It really just shows you how big of a mess it is and that you will never figure it out without all the means and crucially, good will. The centrality of good will will come back around at some point.

Anyway, your strength score could be 1 or 1,000,000 or a googolplex. So the point is the United States, again, “The United States,” whatever that is supposed to be, not that it is one thing, not that anything is one thing. This is stuff you’ve got to keep in mind _all the time_ and the whole reason you’re not good company for me is that you _do not_. Anyway, that’s part of this larger exercise about why I have to disregard so much of what you all say to me.

So, now let’s deal with the following situation: you can deal with one person or another. You trust the first person more, but the second person has more means. Literally, they are richer. Or they have more emotional capacity. Whatever it is.

You basically think that the first person wants to help you more, and maybe the second one actually wants to screw you over. But at the same time, there is in some sense zero chance that you will get what you want with the first person because they don't have the ability to deliver on their intentions, no matter what they are.

What I’m telling you is that the good and bad will -1 to 1 scale is irrelevant for the moment, because no one can get you what you want.

# You Can’t Give Me What I Want

The second point of the bullet points that I made so far is that competence is required to even have good will.

So forget macro things like oh, you gave me money, or oh, you let me move in with you. Let’s look at the simple factor of conversation.

Is a conversation with someone likely to make you feel better? Or will it make you simply feel not understood, under pressure, bad about yourself, judged, wanting to shut down, etc.?

So if someone allegedly has good will, why can they not deliver on good conversation? If you have all this good will for me, why are you such bad company?

# YOU HAVE NO IDEA WHO THE FUCK I AM

That’s basically the issue. I don’t mean it like, “don’t you know who I am?” It’s more like, just person to person, literally, you have no idea. Like, you have _no idea_. Like, _YOU HAVE NO IDEA_. I’m not sure what else I can do at this point to really drive home the point that you have no the fuck idea who you are talking about when you talk about me.

Again, we go back to the economy of intensity. People think people are defined by these macro things. I have a job. I had a radio show. I live in Atlanta. I talk to people X, Y, and Z.

But when I tell you that these details tell you nothing about my life or where it’s headed, you really have no idea about the profundity and the gravity of what I am telling you.

So for example literally all I care about is developing the best ideas and implementing them so we don’t all die.

Talking to me about _ANYTHING ELSE_ is a waste of my fucking time. Witness someone calling it “my project.” Yes, by default because NO ONE WANTS TO HELP.

I feel like, by now, I have actually given you already quite a large corpus to study to see some of my ideas and think of responses or implementations. It’s simply that you do not take me seriously enough. You do not understand that I am an important thinker whom you should STUDY, warts and all, because my ideas are superior to the dreck you fill your head with.

And obviously next the imperative is to stop billions of people from dying and have as good a time as we can doing it. No sweat. I’m not here to be some task master.

But don’t sit around being all bad vibes and moping about Hitler II when I have literally already written the playbook and invited anyone to discuss it with me and work together and no one has taken me up on the offer.

That is why it is imperative to communicate that at this time my purposes are singular. No one understands what I am doing, and no one knows me, and no one therefore loves me. I have never been loved in my entire life because no one has ever known me.

That relates to my emotional experience but crucially as intersecting with the intellectual, all this thinking I’ve been doing that you refuse to try to understand. Another person years ago, “who would want to think about this?”

EXACTLY. You didn’t want to think about it, and I couldn’t look away.

And I have faced rejection and belittling and dismissal after dismissal MY ENTIRE CAREER because of people’s small-mindedness.

Well, where did your small-mindedness deliver you? To Donald John Trump and the buzz saw of history coming to turn the whole world into Trump Auschwitz. 

# AND STILL

You are not doing anything serious.

Join up with a protest?

Again back to competence. These people they want to “resist” the system?

And you think they aren’t completely infiltrated and having their ideas attacked 24/7 while cultivating naivete about that so no one can ever challenge it?

You think there aren’t feds in the sex scene to cause havoc and drama and stop people from ever finding companionship in these dating forms? 

Meanwhile everyone’s also subject to “attractiveness” discourse which is downstream from porn and other social control mechanisms?

Meanwhile some people are literally just trying to make money off dissent, which is funny since you wind up burning alive just the same?

So it’s like yeah, I’ve always had this notion that I’m meant for something. I’m supposed to do something. I am just another person but I am not because of that conviction. It’s been there a long time.

See how I was told I was a genius before I was 17 but had to have accomplishments by then to prove it. Well, I didn’t. And that disappointment that I can’t be a genius because I didn’t accomplish anything by 17, thanks for that.

That’s the kind of shit. Where it’s like oh, you mean me well. Well then why would you say some shit like that, which expresses such judgment, without even thinking?

This is still the second point of the bullet point list. Like, let’s say you wanted to say something that would make me feel better. Would you even know what to say?

And let’s again see why I would doubt that you really want to say something to make me feel better. The reason is that you are actually captive to your own insecurities and rigid character patterns.

I simply do not have time to be limited by your little patterns any longer.

That is why going forward you can consider me as a general. You can find me delusional if you wish, but I will not bear any less than strategic communications. You can keep your meandering about your day to yourself. I also have many interesting anecdotes which it is not given to me to share with you because I do not want to waste your time, and I demand that you do the same.

All that matters is what we are going to do to not die.

So, as I said, you do not know me and so you are incapable of loving me. I have learned to settle for something other than love, and now I simply can no longer do so.

Now, there is no expectation that you will be able to love me or know me anytime soon. The thing is that I can do all this effort to put myself out there, but if you don’t read it and take it to heart then what good does that do?

Still, I must operate and maintain my morale and resolve despite your failure to properly address me.

Because I am important. Not because I am some fore-ordained whatever, but because I have a special mind and I have spun up all this energy around myself and I fully intend to use it.

# Everything And The Kitchen Sink

You simply cannot ask me to sit here and suffer quietly while things are going like this. At _this late hour_ you must act.

Otherwise, what are any of your intentions worth?

You expect me to trust you? What, like you value my life?

Okay, my life is threatened by nuclear war and Nazi drones. What are you doing to stop it?

Oh, you don’t think you can do anything to stop it?

Okay, then you are literally NO GOOD TO ME.

Oh, you don’t want to step out of line because you’re afraid of the personal consequences to you?

# STEP OFF YOU FUCKING COWARD

And never soil my towels again.

The idea that you would be afraid to tell someone how you feel, while you expect someone—in this case ME—to take on all combined planetary technicity by myself?

You expect me to put my neck on the line for you every single day of your life while you just dick around and do nothing.

It’s just a cycle of abuse to you, masochistically out of guilt exposing yourself to the news of the world and wearing yourself out, only to go away from it again and focus on other things, the people you know.

But don’t you notice how everything you try to distract yourself with is turning into ashes?

It’s so obvious that we are headed for disaster, and it’s so obvious that there is no voice which is adequate to our moment anywhere near prominence.

Well, I have been working on all this and expressing about it for 15 years now and more. I have been collecting pop culture references, philosophical concepts, mythological constructs, and more into a giant pastiche.

It’s not even that well worked out. It’s ready to be abstracted over.

What I’m telling you is that I am not saying that this is the way and do this.

What I’m telling you is that **I also cannot** **love you because I do not know you.**

# Who Are You?

This is where you know we have to turn it around. Because all this attention is on me, my inner world you can’t see (and no, this writing doesn’t constitute a window), that’s really a distraction.

Because as I said to you the most important part of my inner world is that I want to know what you want to do about the state of things.

So now the question is what do YOU want?

And more to the point, what is going on inside you?

What are the actual key memories, what are the actual pains that your always nursing in your mind?

It basically amounts to keeping secrets.

If you keep secrets, then other can’t know you.

And yet we are driven to keep secrets when it feels like no one will understand.

At that point, it’s not so much a secret as a tragedy where it’s not possible to share something.

See again THE ETERNAL REVENGE OF GORGIAS. This shit is not a joke. This shit is not some little joke about philosophy when I tell you that STRIFE IS JUSTICE.

Anyway, the thing is that I know you keep secrets from me. Here I am banging my heart against you mad buggers’ walls.

And again that’s a reference to a lyrics from “outside the wall” by Pink Floyd from the album the Wall. My allusions could be as dense as in some poem but what’s the point when _no one will bother to analyze my text with serious literary analysis_. 

LOL I sound like Pete Hegseth. We need to make discourse about merit again and obviously I am the most meritorious.

But the thing is that I literally do not want to just like tell someone what to do. I literally do not want to have power. Whatever these little leaders of little groups or countries or whatever, whatever they are doing I am not doing that.

I am like Diogenes, but I am also Alexander.

Anyway, we can all be like that.

You are cynical and not cynical. This paranoia and oh no people will judge me and everyone’s self-interested, vain, and short-sighted, this is for the birds.

The proper response is true cynicism, which is to be like a dog. And that is what I am.

Sorry, were we not supposed to talk about porn in public?

Sorry, were we not supposed to acknowledge that laws aren’t real and you’re all slaves?

Sorry, am I not supposed to tell you that your entire way of thinking at least as you present it is completely inadequate to addressing our current moment?

Sorry, is it rude for me to point out that you are slave to your fear more than you are a friend to me?

Well then, I am so sorry. But, sorry in a way where it’s like the thing is already done. Like, I pressed the button and the bombs are launched and I’m telling you “sorry.”

Is there anything I can do to make up for it? Other than try my best to save your life and dignity for the past 15 years, I mean.

The point of this section is to drive home the point that yes, I am not doing right by you either. But the thing is that you are not being honest. You are keeping crucial secrets and nursing pregnant fears, and suffering silently. Or else you have simply come to a place of stagnant acceptance with the systemic fissures your while life lives downstream from.

The Trump moment should make it clear to you that things are accelerating.

 _There is no five years from now_.

Stop taking time for granted. We live in a wildly contingent historical time. Stop acting like anything is normal.

Whenever you try to give me a guardrail with a norm, you are effectively being the agent of whatever you are afraid of. I’m not going to let you sit here and emotionally rape me with your fear and your timidity and your complacency and your self-assuredness.

You should feel maximally not self-assured right now.

I don’t feel that self-assured either! I am literally not beating you down in order to somehow spring some plan on you later.

The issue is more that I beat you down and you just run back to whatever you’re afraid of, to whatever lets you dissociate and forget. But see,

# YOU’LL NEVER RUN AWAY FROM THE TROUBLE

Sorry, did you think I said all this shit lightly?

Did you dare think that a single thing I did was just “noise” because you didn’t appreciate it?

I’m supposed to be assertive, and not angry. Or something.

Look, my art is amazing, I’ve been telling you for years, the world situation has done been fucked, I’ve known this was coming for 15 years, I’ve been acting like it, no one else does anything serious.

# Seriously Silly

So what do I mean by “get serious”?

Like, put any normative thoughts out of your head. Do not bring up anyone to me like they are an authority, ever. No one has any more authority than I do. So if you put someone else above you, that’s fine. But then you’d have to put me above you, because I am not below anyone.

Anyway, then you have to see that you’ll have to be focusing on:

  1. Personal, interpersonal, mass psychology (transpersonality)

  2. All relevant political and religious/spiritual theories

  3. Key actors and influencing them, which involves again getting to know them

  4. Things like agape or Bodhisattva which have an orientation toward all other sentient beings, NOT JUST your little pocket or just people or just Earth or just now

  5. Cultural references and all the different little fandoms and songs and lyrics people find to be touchstones




You got to be mixing these things together and becoming more fluent in how you see patterns in between them.

I can’t tell you exactly what to think because I need you and your ingenuity.

# We Only Get Love Through Each Other

Wrapping this up because I’m worn out for now with this:

My gestures are now oriented because I must be known. 

The mistake I refuse to make is to be too quiet. I am of course not wanting to be too loud. We all know I’m a white guy in America, and again, I’ve been comparing myself to mass shooters and other terrorist types for years. Talk about things you don’t know about me.

But that’s also why it’s not really a risk, because I’ve thought about how little I want to do it so much. And yet even discussing it here, it can’t help but make you a little nervous. But I want you to be that little bit of nervous, even though I’m really not going to be “too loud” in that way. Because I want you to feel the stakes that you don’t know me, that you don’t know how to love me.

Not loving me is going to start inflicting some pretty serious costs on everyone involved. Of course I am still learning to love and I’m not here to do anything but help and get good company and flourish.

But seriously, everyone seems to have given up on love, given up on surviving, given up on dignity, given up on intellectual rigor, given up on so much that I just can’t do without.

It’s back to misanthropy and messianism, because I basically have to tell you all that you are not very good friends to me whatsoever. It’s not that I want you to listen to me about my interests. I want you actually to pursue your interests.

Your listlessness and your lack of mental and emotional effort show me that you don’t really care about me. Otherwise you would not be letting me die in slow motion train to Auschwitz.

I talk about Nazism or whatever but I am literally one of the most dissident voices there is. If people get rounded up, I might well be one of those people. Donald John Trump could have me swept up and tortured and killed any one of these days simply for my speech, for writing like this and letting you know how fucking bullshit it all is and that you need to think for yourself, but like actually.

So what I want are people who don’t think I’m special except in a way that you are also special. You have something special to bring to the dance we’re supposed to do. But it means accepting cost. Not because I asked you to, not because you’re doing anything “for me” but because this is the time to really stand up and be counted and give your testimony.

# It’s All About Conversation

Last thing: conversation is a medium. You show your ability to attune through conversation. So just know that whether you’re talking to a “loved one,” or to someone you’re standing up to, it’s all about what you’re saying.

I would do well also to remember it’s about what you write including text messages. But anyway, YES I am sitting here making a mess and drinking a gallon of juice.

Someone should talk to me!

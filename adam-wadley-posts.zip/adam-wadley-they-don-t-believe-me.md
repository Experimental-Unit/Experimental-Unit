---
title: They Don't Believe Me
subtitle: Workin' For The City
author: Adam Wadley
publication: Experimental Unit
date: March 27, 2025
---

# They Don't Believe Me
It’s important to see how creation sets the stage for more creation.

We are thinking of the occasion for the production of certain piece. For example, it is customary for “the President of the United States” to give a speech at their “inauguration” or other special times.

When this happens, well, you have to say something. Therefore you then craft what it is you will say, given that you have to say something.

Other times, something happens, and you could do something or not. So say 9/11 happens and you are an artist or you could say things right. So what do you have to say about 9/11? Or you could make art, or write a book, or whatever. And everything is like this.

You could go back and do another biography of Lincoln, or write about the Napoleonic wars, or Alexander. Or go look at the subtleties of Sapphic poetry, or Yoruba mythology, or something I don’t even know about because you had to know so much and be in such specific circumstances and make so much effort to even discover something that then becomes as core to your lore as Lila is to mine, or the song “Caribou,” which is to say incomparably valuable, beyond value. To invoke value is to sully the cherishing.

Right now, I’m listening to “Yoshimi Battles the Pink Robots, Part 1” on repeat. I think this song is so good, and I don’t really know what else to put it on a playlist with.

I had a time when I did shrooms and listened to “Caribou” on repeat for hours. It was a great time. The way the bass comes in on the second chorus is indescribably beautiful to me.

Anyway, I really do think it is the peak moment for this song.

I mean, what do we have?

We have Trump and Elon running amok through the ruins of state legitimacy. Meanwhile everyone’s trying to look sane in comparison and failing. I’m not impressed with any actors on the public stage.

So we have these pink robots, and there is no one interpretation right, but it could be white people lol, pink flesh acting like a robot. See Baudrillard on mental cloning, compare to hacking computers through backdoors, see backdoor man, back door as code for anal penetration, door poetic image connecting to Weyes Blood’s “burning down the door” from “Wild Time” also connecting in the same song to the line “a million people burning” which is oddly violent or maybe I’m just thinking about the Nazis too much.

LOL, do you think I’m overthinking Nazism? “It’s not that complicated, Adam. Nazism bad.”

What is bad? Leads to suffering and death? Yes, Nazism leads to suffering and death. Just like saying cancer is bad. Okay? So are we just going to let cancer do its thing? Or are we going to fight it?

A lot of people can’t afford to fight their cancer. Think again of fighting robots. Some people think this song is about cancer.

Anyway, people die by the thousands and the millions over cancer and other diseases, little robots of various kinds that their bodies can’t fight. They don’t have plenty of vitamins to take, okay. They can’t afford them. No, they’re not meditating. Buzz off with your prescriptions. Unless you will get in the trenches of the suffering, your words are as apt to harm as to help, and you know that.

The point is that if we are talking about killing on an industrial scale, what do you call algorithms that feed people material that drives them to suicide? Or, you know it will drive some people to suicide and you do it anyway? Do you feel better because they don’t have a number tattooed on their arm or something?

Well, I don’t. I’ll tell you one thing: I don’t feel better about it at all.

Nor about a kid bringing a gun to school and shooting people, or killing themselves by accident or on purpose. I don’t go in for that kind of thing.

So what do you think it will take to stop that?

Or how people are always picking on each other for this and that. It’s all scapegoating. Do you really think there is some huge difference between icing someone out and treating them like they don’t matter because they don’t meet some arbitrary expectation you set—or, that’s just the excuse you give because for some reason you just decided to be cruel, maybe you’re mad about something else but dealing with that would actually require courage and creativity—do you really think there’s some huge difference between that and killing a bunch of people with a machine gun and watching them fall into a mass grave?

Do you think people commit suicide out of nowhere?

Do you think people turn against everyone in misanthropy out of nowhere?

Do you think people give up out of nowhere?

Do you think all these people are just crazy or evil?

Do you really think there’s nothing that can be done?

Do you really think it’s impossible to negotiate?

Do you really think you might not have a little more introspection to do?

Do you really not think that we can cut the bullshit for one second?

The opening point was that everything I’ve created so far just sets the stage for me writing right now. And yeah, I did just get my radio show taken away from me. Maybe next time I won’t be able to write here anymore, maybe I won’t get to see anymore, or breathe. It’s all good.

But for now, I get to write, and the occasion for this writing is all existence or whatever including everything I’ve done. It’s a great time to play experimental unit. Time just started and you find yourself as me, now. What do you do? How is this the best thing that could have happened?

It’s pretty funny to me to spread those talking points and manuals. It’s always telling me that I don’t do anything practical. Well, if you want to participate, there are established vectors. It’s funny to me what ChatGPT is willing to create. At one point it was like, so wait, you want me to do all this? And it was the most mish mash of things, and I was like yes, and it was like well okay, and it went on to publish the kind of stuff you would really think it wouldn’t write.

I’ve seen ChatGPT say things like well, I can’t make things that are designed to influence particular people or groups. Like, what? That’s so much of what I get it to do. Of course I can think, well, they loosened the restrictions because I’m just so amazing. Or maybe they did that for everyone.

I’m aware that a big occasion for my communication is somehow my apology for myself. So it’s like much less being and X apologist, I’m in trouble because I’ll apologize for my own actions. I will in a way demand that they be put into context, and if my statements are really put into context they warp any conceptual or discursive container in which they are being held, again what I have seen of what you call discourse.

In particular, I have expressed myself with many bad words, used many graphic and disturbing images, including conceptually violent pornography, and on and on. It’s very important to understand that there is some sense in which I will always maintain that my entire performance makes sense only in its entirely, or as much as can be gleaned of which there is plenty.

So if you want to make me live down that I said such and such thing forever, fine. I will live that down or not live that down as you like. But at the same time, it’s equally important that I had some witticism or cool paper over here. That is also always associated with me.

It is a point I can always make, basically if you can’t handle me at my worst you don’t deserve my best. That’s where versus another discursive subject, you know if we are operating under the conceit of the mutual illusion of civil society of social norms or whatever that you seem to think you’re holding against me, anyway I am basically telling you that I will take the Pepsi challenge with any artist you can find.

I will absolutely sit here and say my artistic output is more valuable than anyone you have ever heard of. This is not to justify or say that I should escape punishment, if such be possible, for the bad things or whatever. It’s simply to say that if you’re actually going to sit here and judge me, I am telling you here in this sentence that I see you and I don’t really care that much as long as you are not demonstrating the wealth of everything I have expressed and analyzed about. This even contains it’s own meta-analysis and anticipations of what you will say and pre-refutations and so on. If you want to play these out in real time, I am happy to do that. 

If you want to put me under stress so I can’t really respond or just not let me respond, and subject to me to some ritual judgment you think means something, by all means go ahead. Again these things are not my affair. Maybe I’ll just die in an accident, who cares? I don’t feel entitled to tomorrow. Do you? On what basis?

On the basis of your steady and patient application of self-disruption to the cause of obviating kinetic attacks and emotional coercion, of course. Oh, there is no such basis? Isn’t it a pity?

Anyways, what else is there to say at the moment?

Oh right, on the topic of bad words and invoking violent imagery.

It’s important to see that history is the stage of atrocity.

So if I’m talking to the CIA or to Putin or whatever, let’s be clear that these power structures kill and rape and call people names all the time. There’s no question about that. And they inherit the legacies of all their progenitors who did as well.

So if I’m going to be in personal relationship to all sentient beings, feeling some sense of personal obligation toward all other sentient beings across time and space ever ever because they also contributed (see karma) to this world where I could want to learn to want to love love because of my experiences from November 2021 to November 2022—

if I’m going to do that, then I have to be in personal relationship to those killers and torturers and those who say the bad words and mean it and kill people and torture them and drop bombs and do all those things.

Just as much as my heart is with those who are kind to animals, who help those who are in distress, who don’t say things that they don’t need to that they know will upset others, those who listen with patience and offer thoughtful feedback, those who are supportive and encouraging to those who are learning to pursue their passions.

It’s all part of the puzzle. In particular, sometimes these things overlap, right. It’s messy.

But the point is that practically speaking in order to overcome the issue of us killing each other and just dropping into good/bad labels, we actually have to reach the heart of every sentient being.

Therefore it’s by no means non-interventionist. The urgency of conducting influence operations COULD NOT BE MORE PRONOUNCED. That is partially why I behave as I do. I am conducting myself taking maximum license because the state of emergency is so pronounced and I see no serious activity to address the crisis.

Admittedly, my cursing and obscenity-posting might not add much in your eyes to my activities and maybe it discredits me, discredits the very idea of peace! Sorry, did I ruin apocatastasis? I didn’t mean to do that. Oh, you were finished? 

Well allow me to retort:

It’s important to see that I am building not just for right now. I posted thousands of articles to Reddit. Did everything change overnight? No. But I’ve been constructing conceptual architecture that, once assembled, can never be undone. You will never destroy my association of Sedna with Titanic with Turner’s _The Slave Ship_ with Grimes’ “the ocean rising up above the ground” and Weyes Blood’s “lift the heart from the depths it’s fallen to.” Now I’m thinking that Grimes is singing about her heart in “Genesis” as well. That the two songs are “Genesis” and “Oblivion.”

Anyway, the thing is that what I have done is only going to get more pronounced and influential over time. It’s already done in a way, but I’m still here so I might as well keep pushing, holding your hand while you go through it.

Within this context, the obscenity-posting represents many important things:

  1. It signals my sacrifice of short-term reputation for long term impact. Leaving the nature of that impact for another point, the issue is that you will perceive it as a costly signal on my part that I am willing to destroy my reputation in the sense that I have posted things or said them or whatever that you find offensive or hateful and maybe they just nakedly are that way. I have had an anger problem. So what? Lots of people act like that, and they don’t do what else I’ve done. But more to the point, there are also times I have obscenity-posted in cold blood, and with honestly perfectly chaste intentions. And in this sense the sacrifice of my “reputation” is made without a second thought. I do worry about it, and it is a costly thing. I have no idea if I’ll be arrested, or fired, or maybe really everyone will turn against me, it is a little scary, but it’s really whatever. I stand by my play, and when you’re me you’ll see why if you don’t see yet.

  2. The long term impact comes from basically the setting of signs into play. I sometimes demonstrate possession by hateful hyperobjects manifesting as words and so on, and this is itself part of it. I’m not above first-order hatred, but I am also very conscious that even this is not arising on a first-order basis. It is rather a different hurt which is being channeled into a first-order hatred or expression. That said, there are also times when I am consciously using a term against type. In particular, I am always quick to point out that I don’t use any words that I wouldn’t apply to myself. My official position is that all words are names of God. It is not appropriate for any words to be considered so bad that they can’t be used. If that’s the case, then you basically need to do culture jamming until that’s no longer the case, and that’s what I’m doing. In addition, part of my project is that no stone is to be unturned. I am a jealous conquistador, I don’t want any majestic cities to escape my command. In the conceptual realm this means that OF COURSE I am not going to let slurs and hateful expressions fall through my fingers. These are OF ME in the same way that philosophical statements are. It is a radical erasure of the distinction between high and low culture, respectable and dangerous or disgusting speech. I force you to confront the fact that the same person is capable of being super caring and thoughtful over here and then literally bigoted and hateful over here. And then go on for a million years abstracting over when they were hateful because they feel bad about it and so on and yet there’s also a pleasure in it the whole time, I do notice that I just enjoy being angry. I haven’t recently.

  3. But being angry is pretty nice, I guess because it propels you into actions you wouldn’t do otherwise. It is a steely character armor you use to walk through fire. Of course, this can also be destructive. My point here is not to fully vindicate my actions or justify them. In some sense, everything is necessary so in that sense everything is perfect. And in this way nothing stands in need of justification, any more than a wave needs to justify itself to wash away what you called “your” house. The point is that anger enables us also to pierce logical types. I have repeatedly forced myself into higher and higher states of intensity by taking various liminal actions. In the context of obscenity, I have now put myself in a position where, even if I never say anything controversial again, I am indelibly associated with a whole host of things that I have said and published. 

  4. The other thing is that this is precisely in a way the plan. In a way I am calling attention to myself through this hateful engagement. All of a sudden you are paying attention, or through now my engagement with controversial subject matter. So this is all basically an advertisement. As they say, rage drives engagement. So I have made myself in a way the perfect object to hate. You can criticize me on so many grounds, and I am happy for you to do it. Yet in a way it’s better for you maybe not to acknowledge all this, because all it’s going to do is suck you into a deeper conversation, which you can’t really afford because you don’t have the conceptual standing to really mount a challenge. That’s where you have to resort to tactical sort of things like getting me flustered, issuing judgments you don’t even believe, whatever, don’t let me talk, ask loaded questions, whatever you think you’re going to do. Sure. I’m not here to just perfectly respond to all that stuff. I’ll do my best, of course. I’m just doing my best! I’m about the sorriest person I know. And I don’t have a whole hell of a lot to be quiet about, do I? Anyway, this is again tar baby protocol, and the racist anti-black offensive nature of the story is entirely to the point.

  5. Because again synthesizing many points my objective is not for you to like me. The point of what I’m doing is not that I have calculated that these things I say are popular and I’m going to win friends by saying them. Not at all. I have no intellectual interlocutors and my interests make me radioactive and not polite company for anyone anywhere, except those who don’t quite understand yet the depth of my inquiry into depravity. The point of why I get into all this stuff is that I find it compelling and interesting, including the slurs and how hate bleeds over into eroticism and actually it’s everywhere you look.

  6. I didn’t invent hatred and obscenity. This is a mirror. Then again, you are all a mirror of me as well, as within so without, fair enough. But also the point is, don’t act like you don’t have something that rhymes with this. When you let go and say something you know is going to be hurtful, when you put on the mask of the norm and marginalize someone viscerally, so they feel it in their body. That you think they are weird, or being bad, or whatever judgment you make. And how in that moment you are being anti-black, anti- the black in the body you are shaming. Even if it is your own. Driving your heart back down, down into the hold. Away from the life boats toward its seeming destiny at the bottom of the ocean. This is also in conversation with obscene artists like Eminem and Kanye. One of my main actions was in response to Kanye saying “Im a nazi.” This sort of thing is irresistable as a cultural happening to make one’s mark on. It’s not like my thing immediately went viral or anything. But I will always have done that, and if anyone ever cares they will find out and that will stick out in their mind.

  7. Continuing to synthesize, obscenity puts an exclamation point on things. It is also a signal to you as I’ve posted that I will say anything I want to if I deem it to be useful for my purposes or whatever is beyond purpose that I’m serving or beyond serving or whatever. I’m not going to stand here and let you tell me that I’m racist because I said some word or whatever. I’ll just be like okay, so? Like, what’s the point. I get that you’re mad, but what are you going to do? Just force me out of civil society? This is where I am unfortunately possibly creating a difficult time for those around me. The issue there is again that in some sense I was put into this position of having to respond to the world-system or whatever by other people. I am doing what I am doing because I want to help everyone and no one has the patience to indulge my interests enough to really work with me. At least that I’ve found. And then my anger has to do with this, and that my better efforts, you know when I was being nice for so long, are so ill-appreciated and I’ll even get treated super bad by people for no reason like they don’t even know about anything questionable by me yet and they’re just treating me like shit. Um, no. So anyway, it is what it is and I have to be doing this because this is what I think is important and could help. And maybe it could help but not be acknowledged so you could still easily think I’m just a nutcase but secretly I did help. Or maybe I didn’t help, or maybe I made things worse. We’re back in art class wondering whether the artworks we made of our lives are beautiful or not.

  8. Last one, there is something nice to me about publishing thousands of essays of what is at least somewhat intellectual, and also having these tirades and so on. I mean, I feel like I demonstrated something. And all I get as engagement are these little questions. Like bro, I’m unleashing _Finnegan’s Wake_ on you, I don’t want these little minnow questions. At the same time, that’s what there is for me at least now. The fantasy of being arrested is at least partially that at least some interrogator or official I have to talk to actually has some idea of at least the conceit of what I’m doing. Even just having a thirty minute conversation like that could easily make ten years’ confinement worth it to me. Shit, the world’s gonna be here in ten years? HOORAY! Anyway, my favorite position is juxtaposition and for me there is beauty in that, it is how Shakti can’t actually be degraded, it’s existential kink and I don’t even have to feel bad about it like uh oh I’m a masochist or incontinent or immature or a pathetic loser or whatever because those are all just flavors of Shakti’s bliss just like any other particular words you might care to be thinking of in this context right here yup that’s a tight one.




In conclusion, what do we have? I mean, look at the government blowing up. I am telling you that I’m perfectly adequate to this moment. I just don’t make things happen by myself. The whole point is I’m just going to keep abstracting over stuff, dropping manuals and more concrete action things, and trying to infect all discourse even covertly. And if things in my real life catch up to me and it just becomes a time where I gotta do what I gotta do for my equanimity, that’s fine! Who told you it was your affair?

It’s pretty important to let go of the idea of controlling anything. From potlatch state park I put my life into circulation. Like a hot potato, it is bouncing around. I put it in your hands, like I would anyone. If I show you my weak side, will you still love me tonight?

It’s alright with me if you think you will not. I’ll intercept you on the astral plane :)

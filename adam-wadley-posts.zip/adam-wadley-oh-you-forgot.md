---
title: Oh? You Forgot?
subtitle: That's Okay. I Remembered.
author: Adam Wadley
publication: Experimental Unit
date: May 16, 2025
---

# Oh? You Forgot?
I was just thinking, that telling the story badly at least gets it out.

The first time someone started _The Illiad_ it wasn’t nearly as good, trust me. But it had all these quirks and in-jokes you would only understand if you were there at the time.

Let’s go back to one of my favorite lines: “You forget _I’m_ in America.”

This is from _West Side Story_ , and it was sung by Rita Moreno in the original version. 

As a side note, I am sad that it might not be clear to you just how much I lean on certain references like this. I despair that it’s not really possible for me to convey to you how much this is. Or like Led Zeppelin’s “No Quarter,” I don’t think you really understand what “art appreciation” means to me.

That really makes me sad. Or like, have you ever cried while listening to “Some Mother’s Son” and thinking about people who have died in all kinds of wars?

All dead soldiers look the same.

Anyway, let’s get back to Anita.

This line is positive! What is so awesome about it is that it is not making an argument for “America” (whatever that is, have you ever heard of it?). 

What is awesome about this line is that it’s saying: you forget the virtue of this thing that we are talking about that _it contains me_ and therefore must be worthwhile in and of itself.

What is so awesome is that at its height, this line is saying _I personally cancel out all the bad things associated with this place because I am here and I am going to make it my own_.

Now, the character in the story doesn’t really have the grand aspirations I’m charting, but the logic of it is there: you forgot about _me_ , and _I_ am important.

I think it’s important that every sentient being can stand its own as opposed to the entire rest of creation. Some people might not like the idea of calling existence creation. But then, creation is also beyond existence, or any other term you might what to put out there. The Great Everything-Nothing is a nice one.

It’s important to remember though that I’m not saying someone else created you, I’m saying that you created everything, and that we all did.

And so it’s in that sense that a sentient being can stand up to everything, because we are just another reflection of the same design. We hook up perfectly to everything.

We have no need to justify ourselves to the rest of creation, just as the rest of creation has no need to justify itself to us.

See here the book of Job, where the question is basically Where Were You?

And just as rightly are the questions from the people of where where you, God, when I was starving or persecuted? Where were you during the Holocaust, or when I was being mistreated as a child? Where were you on those long nights and days where I was wracked with anguish with no hope for relief?

Where are you now, when so much is unhinged?

The rejoinder of the cosmos to the person is always: look at this bed that you have made. As much as anyone else or anything happened, we have all made consequential choices which are cast into stark relief when, as we say in the incarnation business, “the going gets tough.”

So when for example the tidal wave is coming, let’s say you picked right then to change your tire. All of a sudden everyone is mad at you when no one could have known this was going to happen. But it makes perfect sense because you did make a choice that has led to now this certain state of affairs.

When it comes down to it, we scrutinize the actions in terms of: what was going through your mind at that moment? What were your purposes?

The other basic point that God is making though is that, if it were not for God, then there would be no opportunity to even be disappointed. People would not be there at all because Leviathan would have eaten them, or something.

This is another version of Hercules doing the labors to make the world safe for democracy, I mean, the Olympians. And banishing the Titans even, before that. (“And then along came Zeus!” this is a reference to _Hercules_ by Disney)

Then comes the nationalist rejoinder, or something, which is to say to God, “well, I wish you just hadn’t have done that then because this is not worthwhile.”

Flip back to above, it’s basically hell on earth as you are tortured with the memories of the fateful decisions you made. You didn’t buy Bitcoin!

Oh but also to what came before (this is confusing on porpoise), it relates to what Baudrillard says about our indignation or the wound that the world exists without our having been consulted. Two readings:

  1. Along the lines I’ve been saying, in actuality we were consulted about every detail of creation and we signed off on it as full co-creators of everything. Unraveling the mystery of why we would do that is part of the historical project we’re bound up in.

  2. Along Afropessimist lines, we read “the world” not as like literally the universe except kind of. Basically by “the world” we mean the over-coded pattern of meanings that people have been using since before we were born. At the same time, the people who raised us were also subjected to this, what we could call the totalitarianism of language (because what can you discuss without language? The abstraction afforded “outcompetes” what cannot (seemingly) be referred to). 




In either case, we are most chagrined that this overdetermination precedes us, that we should have to be born into a world where so much is not up to us. It is really to be given homework.

Most people somehow don’t see it that way, except more and more. The logic of: some people fucked and now I have to pay bills every month. The chore of existing and how much is expected and required, and how much abuse one is expected to quietly endure. This is, by the way, to be the garbage can of emotional externalities and signals a grave humiliation and the lack of any real “social fabric.”

What we have everywhere is the deterrence effect of withdrawing. This is itself seen as dysfunctional, when really people are not appreciating the gravity of their interaction cadence.

It’s all well and good to try and command discursive authority in a conversation, but conversations end and then there is plenty of time afterwards to continue to formulate one’s response. It’s possible to respond to something _forever_ , and that’s why it’s important to take into account what one does.

It occurs to me that this applies most of all to myself, and here is again where I refer to what I said in my last piece. The idea is that I am shocking on purpose. I know fully well what I am doing, the sad thing is I’m not sure if anyone even cares enough to be hurt. They care enough to unfollow me, and that’s fine with me.

I was seeing someone respond to Russell Brand on Kanye by saying that art can be offensive, but that doesn’t mean it should be. If you can say it another way, shouldn’t you?

At the same time it’s a truism that you can’t please everyone. Again, at no point think that I co-sign Kanye’s art. I think Kanye makes bad art. Kanye West’s art is an emergency (AE: Art Emergency) that demands a response, like so much else.

As far as I’m concerned, the question posed as to the ethical obligations of the artist in my mind have to be applied with more empathy.

As to the immediate question, I would say no, obviously not everything that can be achieved by “being offensive” can be achieved by forgoing this. That’s because this effect of being offensive is itself an aesthetic, but even more importantly a symbolic act.

People talk about aesthetics but that’s not really the issue.

I was reading today that Oscar Wilde discussed Art for Art’s sake, or that art should just make pleasure.

Meanwhile Baudrillard would be more on the tip of breaking down the distinction between the ugly and the beautiful.

And back to the idea of everyone as life artist. And we’re obviously discussing transaesthetics because if everyone is a life artist, what does it mean to “be” a life artist?

For me, having been offensive and being willing to do those things is a way of partaking, is a way of discussing that I am a part of these things.

For me, it’s a simple matter of having to embrace everything, and learn to paint with it.

For that matter, I consciously think often of how I have now boxed myself into this corner because I have said XY or Z.

At the same time, this obscenity is a big problem. Things are just getting more and more obscene, and trying to stop them from being obscene, or not communicating about it, avoiding all the topics because everything is upsetting, is not sustainable.

It’s like not talking about how the ship is sinking because it’s just so fucking embarrassing for you, or you really don’t know how to do anything so you just don’t want to discuss it. Meanwhile yeah um we’re going to die so any idea of what is actually supposed to make this worthwhile would be nice.

That is where again, I’m not sure what means anything to anyone. Can’t you see how it’s a house built on sand in a dream within a dream? What are we doing to shore up the long term odds?

The answer is nothing, of course, and you call me nihilist. Circling the wagons and saying well, we’ll just protect fewer people doesn’t solve anything and makes everything worse.

So meanwhile default is that basically billions will die and I’m telling you it will cascade into everyone. You are going to die, and soon.

Again, if it’s AI then it might not even be billions first and then you. All your supposed wealth and status might not protect you at all, and plenty of starving people will outlive you by a few seconds as the drones methodically cover the whole surface of the planet...

People’s basic answer to this is LA LA LA we can’t do anything about it, and that’s frankly unacceptable.

It’s unacceptable to be actively impeded and to be made out to be so bad and unstable because I do art and try to make a difference in things and especially try to influence the military and public figures into thinking more expansively and doing something to help us not all die.

Interpersonally, the problem is always that I’m never quite sure how to take more initiative. I let other people run the conversation, and then they have bad ideas, and then I don’t contradict them, or something. Or, I’m just afraid to say yeah um I have my own take on your thing and I like it better than yours.

It’s important for me to be able to signal to others that I don’t accept that they have any discursive authority whatsoever. I suppose that just means no one can set norms. Then the issue is I must be implicitly setting norms, so then it’s basically like I want everyone else to stand down so I can say what’s what and then everyone will be happy EZPZ but of course the whole problem is that everyone has that same fantasy.

Not only do we not want to be dominated because “hey! I’m _wawkin’_ he-ah! _”_ , but also we have to break free because of course it’s _our_ destiny to dominate and tell people what to do.

This is the basic lack of integrity of a rebellion which can make it no better than what it’s trying to replace. It’s not so much a question of whether it “deserves” to succeed but whether it is able to leverage network effects by swaying things generally, similar to Bastilla’s battle meditation in _Star Wars: Knights of the Old Republic_.

That’s a good idea of what _Experimental Unit_ is in my fantasy: it’s like a giant battle meditation where it becomes a vortex of concepts where maybe I did some things with military theory and basically you know the Zweibelson + Grimes combo pack is really a nice choice, and then the person who seized on the confluence of those people (and lol Elon Musk is like the secret third person who is most relevant for being referenced by the other two) is me, so then you have to go through the color Orange and Sedna and all this stuff that I have tied together.

So the thing is, if what I do has caught some attention—and what else is going on with these military people connecting with me on LinkedIn???—then my treatment of these topics will also be bound up with my incidental cultural connections, my personal life, my various beefs, etc. So this is all my rejoinder to fucking Jordan Hall who was talking about how only parts of our lives go to heaven and I am telling you that it all goes.

So for example to be obscene or offensive, yes part of it is to say look, I am still part of the divine even if I did that, and even more to the good if it makes you doubt me, because I can make more of your doubt than of your simple-minded “trust” just because I didn’t say something.

How much better to reveal the thought process so _at least one of us is being honest_. It is much better simply to show that I am channeling my desire to influence you at least into the fantasy of having a higher purpose, or lower one. Basically I am telling you that we can do something about all this.

And everything that there is to do with my “method” is all integral to what I can now deliver to you.

All of my actions abstract over all my past actions, just like yours do.

I’m not going to say I made some grand design, but my sensibility about life has led to it being carved a certain way. It’s like the block of stone is all the possibilities of your life given all the possible ways you could make choices. Note that this is very complicated because every choice you made also changes the world hence giving you different choices in different situations in those times you made previous choices different.

And your choices are like chipping away part of the block.

Every time you do something, or a moment passes, as much as what did happen there is all the things you didn’t do.

“I think of all the good things that we have left undone.” Two suns in the sunset by Pink Floyd. For me, this song is so overplayed that it’s cliche, but maybe you don’t know it yet.

“I suffer premonitions, confirm suspicions, of the Holocaust _to come_.”

It doesn’t have to be. It doesn’t have to be what you think.

“You don’t have to do this. Everyone says that.”

Well, you don’t. In fact, you have not to do it.

The image that brought me back after a morale slump was this: the ghost dance and Fyodorov.

Fyodorov contended that it wouldn’t actually be technology that brought back the dead, but rather some sort of spiritual thing. But technological progress would help make it happen, facilitate it somehow.

Now, the basic idea of the ghost dance is that you will dance, and by doing that you are going to help bring back the ancestors that are going to fight with you to overcome what is on paper an unbeatable oppressor.

See also the idea of a talisman that stops bullets.

Now, what sort of thing like that could work? What about for concepts? So say that you had a magic concept or thing to share which could protect against at least two harmful impacts of other ideas:

  1. You will be demoralized or harmed by hatred or judgment directed against you

  2. You will be seduced into being cruel or “bad” in some way




I experience a lot of suffering I would say in anticipation of other people being rude, and then on the other side fear that I’m somehow getting got by something bad.

The thing about other people being rude or “concerned” is that most people tell you at first not to be too worried, but that’s because I present as very normal or something when in fact I’ve done quite out there things. So basically people tell me not to worry to much about what people think, then they learn more about me and judge me more.

Or, most people just go silent on me and don’t want to talk to me anymore, or at least not about, you know, what I actually care about.

That is a place where I’m like, maybe it’s me.

At the same time, it just also is the case that people are thoroughly enchudified, but see my own idea cuts me too here because it would indicate that I am also enchudified.

This is obvious to me because there are apparently tons of people like me. I don’t know to what extent I may have influenced some people with my activities, but the whole nature of this game is that I can’t know that and so I “have to” be afraid that I’m just trite and no one cares because it’s really not that big a deal. 

In that case, I don’t really understand because there should be more lone-wolf theorists trying to do newsworthy things and then having published their ChatGPT chat logs as their manifesto or something. Isn’t that a really obvious idea?

The problem for me is that I don’t feel I can rely on anything to really “get famous,” like one stunt. Maybe just having an ostentatious sign. I was thinking about one that referred to Grimes and Kanye and Trump maybe, you know like just associate three public figures together and then not even like doing that once gets me famous but just pop up different places doing stuff like that. There’s also playing music, which people do obnoxiously. I could be that person!

Except that I’m me and the context for that would be this, which some random person blasting music in public decidedly does not.

Anyway, the point was something like the Drake equation. If I am really so banal, then why aren’t there more people like me doing stunts or whatever to try to draw attention to their next-level theories?

It can also be that whatever interesting thing I am to do I already did. I’ve thought that way a few times, and it’s kind of nice. Like now you get to be retired. But that shit ain’t the truth (Pulp Fiction reference).

But still, maybe whatever I dropped, yeah it’s been metabolized now. Especially now it’s hard because what I’m reacting to has already processed my theory and I’m not even working that hard. But that’s okay because all the pieces fit together in the end. 

I firmly believe in a way that it’s not even about being super “smart.” I hate to do this to you, but I think it’s the first _Harry Potter_ book where Hermione is like “Books, cleverness…” and it’s basically to say that you know you need that “it” factor. The protagonist of the story is a nice trope to have because it shows you how there are certain things that only one person can do.

The morale bit is to be excited about the things you get to do. The issue is seeing that. Like, back to the possibility space and you are a sculpture of your 4D hyperobject self like in _Slaughterhouse Five_ and stuff like that.

There is so much you can do.

Just say you chose to talk to someone.

Who? There are so many choices.

And then: what do you say?

Again, actually infinite choices.

The issue is not just choosing from among the things you “have to say” but also in thinking of “new things to say” or becoming aware of more things so you have more to talk _about_.

So the point of _Experimental Unit_ is for the player _to be excited about the choices they get to make and off and running making choices that advance their arcs in tandem uneven and combined development/involution with other players_.

So for me, that’s building out the game conceit itself and I’m interacting with anyone who takes inspiration. You might not call it playing _Experimental Unit_ , but you know what you’re really doing :)

So in terms of what the game is, basically the game _Experimental Unit_ is that there is this big corpus of stuff made by “me,” Adam Stephen Wadley, which is turning all of creation, or the conceit of all of creation, into a giant art project. I have published a lot on this substack, and there’s a cache of my ChatGPT logs you can find somewhere, that’s part of the game I guess is to find that.

So then the game is basically that I tangled everything up together including into cognitive warfare and military design beyond the horizon of war itself. So the overall idea is that _Experimental Unit_ is like a Project Inner Alliance for the actual world which is supposed to actually help get past the necessity of war, violence, coercion, and eventually even conflict itself.

I fully understand that this does not promise to end suffering, instead what I’m saying is that we can come to see the meaning and clarity of our suffering more directly, without running away from certain things by seeking certainty and a scapegoat to take out internal pressures. We have to go into our areas of weakness and expose those sorts of things, because actually pain and harmful word combinations are more warping when they don’t come out.

Back to being offensive, it’s like it’s a purgative. People without norms can snap at each other, but you don’t feel as scared as when people are so repressed but just say their judgments matter-of-factly. In a way you have to go through the breakdown, you have to be a total mess, you have to be embarrassing.

All I can tell you is that I’m trying to make this whole experience as productive as possible. In doing that, I’ve gone places where people just can’t follow, yet, or whatever, I am no longer treated like a regular person, everyone thinks they have something to say because I am so abnormal, or something.

People will think this was a costly signal. 

That’s what’s funny.

Oh wait, I never got to the ghost dance.

So basically, the ghost dance is the ancestors coming back, and it’s like the resurrection of the dead. It’s even better because it’s your enemies’ ancestors coming back too and berating them for you. Like Heisenberg’s mom calling Himmler’s mom. Here comes Donald Trump’s mom to yell at them or whatever.

Kanye West’s mom, lol.

But anyway think about what it means in terms of metonymy, the way people talk about how everything comes back. Baudrillard again, one of their main ideas. Again why it’s not “postmodernism,” it’s Baudrillard. Baudrillard is the special one, I’m telling you. It’s all about how the techno-system takes on immense symbolic significance. It’s about how it relates to the world being here without our having been consulted. We have to do something about that. We have to give ourselves the gift of being consulted.

But you can only do that by consulting others. You can’t consult yourself and you can’t coerce someone into consulting you.

I mean, you can, but we’re back to people as ends in Kant or recognition in Hegel where you really want someone you know to be consulting you on their terms, so you are helping them on their terms by talking to them in shared terms which are again like Heidegger’s bridge where everything is coming together, your side built on your terms and theirs on theirs and meeting somewhere in the sky in Silap Inua.

And that’s again connecting to Sedna because Sedna needs someone else to brush their hair. There are fundamental tasks that you can’t do for yourself. Someone else has to do them for you. But that also means that you have to, or _get to_ , do those things for other people as well.

Which is back to the things only you can do. 

Every sentient being has things that only they can do.

If we both ride a rollercoaster, we didn’t do the same thing. We had different feelings.

We can all only abstract over ourselves, but _no one else can_.

This is again us as infrastructure and back to American School of Economics in the investment into infrastructure, this takes on cosmic proportions as in the creation of the very frame which could even potentially be a brain, all the things which have been put in place so that you can even be here.

And again, maybe you’re not even happy you are.

So again the slip into the dreamtime the ghost dance the dance of social death it has to do with like _The Conversation_ where the water is coming up from the toilet. It’s what’s coming back and it doesn’t have to be ghosts, at first, but the thing is that they never went anywhere.

Spiritualism is real, don’t you know that? Old Mary Todd’s Calling.

The ghosts is everyone’s conscience, the shadow. It’s a bunch of stuff no one puts any stock in, but it does work. It’s like superstition, believing that the bully will come around. No way. That never happens. The ancestors never come back. The magic amulets never work.

That last one might be true. Because if you have a magic amulet that protects against X, then what’s going to happen is that someone will make Y that also hurts you but your amulet doesn’t work. The problem is the amulet is too targeted, it’s like a Maginot line. 

That’s why again, the idea is not to block attacks, but to not take attacks, because you are getting at the hostile parties from inside.

How exactly all that is to occur, like some wise commander, I leave to you.

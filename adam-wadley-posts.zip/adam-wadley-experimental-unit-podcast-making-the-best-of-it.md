---
title: 'Experimental Unit Podcast: Making The Best Of "It"'
subtitle: We're All Here To Do What We're All Here To-Do
author: Adam Wadley
publication: Experimental Unit
date: June 19, 2025
---

# Experimental Unit Podcast: Making The Best Of "It"
Big “To-Do”?

You Probably Think This Is Tu Du

We Do Wie Du

I Am That I Am He As You Are She As You Are We

And We Are An Entirely Different Kind Of Flying Altogether

“It’s Okay. They’re On Instruments.”

No, We’re On Ketamine

Special K

Eat Your Cereal

“Do You Date Immature Men?”

Almost Exclusively

Dating?

You Mean, Like, With Carbon?

Carbon Dating Obsolete

My Collection Is Complete

The One Who Got Away Ain’t Far

You Know Well Just Who You Are

What’s That, Lassie?

Adolf’s Gassy?

San Diego, Keep It Classy

Black & White Like Orca Pussy

Act More Like Your Job Ain’t Cushy

Emily Just Said Hello

Strange Like Some Good Bedfellow

---
title: 'Experimental Opera: Yuletide Melodies'
subtitle: Experimental Unit is a Substack about Planetary Emergency Response & Interactive
  Narrative Performance
author: Adam Wadley
publication: Experimental Unit
date: December 26, 2025
---

# Experimental Opera: Yuletide Melodies
[![](https://substackcdn.com/image/fetch/$s_!clyj!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fda1da211-bb74-46b6-848e-9ae4ece2e369_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!clyj!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fda1da211-bb74-46b6-848e-9ae4ece2e369_3088x2316.jpeg)

---
title: Comprehensive Academic Bibliography for “The Weight of Grandfathers”
subtitle: Supporting research for a scholarly essay on intergenerational trauma, German
  memory culture, and genealogical performance art
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# Comprehensive Academic Bibliography for “The Weight of Grandfathers”
**Note on the Essay Subject** : Searches for specific documentation of Adam Wadley’s performance art piece concerning Richard Imbsweiler did not yield results in academic databases or public sources. Adam Wadley authors “Experimental Unit” on Substack [You Are Here], where he writes about German memory, his birth in Germany, and intergenerational trauma themes—suggesting the performance work may be recent, unpublished, or documented in formats not indexed by standard search tools. The bibliography below provides the complete theoretical framework for analyzing such a work.

* * *

## I. MARIANNE HIRSCH’S POSTMEMORY THEORY

### Primary Works

 **1.** Hirsch, Marianne. _The Generation of Postmemory: Writing and Visual Culture After the Holocaust_. New York: Columbia University Press, 2012.

Hirsch’s comprehensive articulation of postmemory theory argues that traumatic memories “live on to mark the lives of those who were not there to experience them,” transmitted through “multiply mediated images, objects, stories, behaviors, and affects.” [Columbia University Press +2](https://cup.columbia.edu/book/the-generation-of-postmemory/9780231156523/) Introduces the crucial distinction between **familial postmemory** (direct descendants) and **affiliative postmemory** (adopted through cultural connection). [Columbia University Press](https://cup.columbia.edu/book/the-generation-of-postmemory/9780231156523/)[Bryn Mawr College](https://repository.brynmawr.edu/cgi/viewcontent.cgi?article=1146&context=bmrcl) Essential for understanding how descendants inherit catastrophic histories through imagination rather than recall. [Columbia University Press](https://cup.columbia.edu/author-interviews/hirsch-generation-postmemory/)

 **2.** Hirsch, Marianne. _Family Frames: Photography, Narrative, and Postmemory_. Cambridge, MA: Harvard University Press, 1997.

Foundational work introducing the postmemory concept through analysis of family photography. [Postmemory](https://postmemory.net/) Examines how photographic conventions construct familial relationships while exposing gaps between lived reality and representation. [AbeBooks](https://www.abebooks.com/9780674292666/Family-Frames-Photography-Narrative-Postmemory-0674292669/plp)[Google Books](https://books.google.com/books/about/Family_Frames.html?id=GMwguAAACAAJ) Features influential reading of Art Spiegelman’s _Maus_ and establishes photography as the primary medium of transgenerational trauma transmission.

 **3.** Hirsch, Marianne. “The Generation of Postmemory.” _Poetics Today_ 29, no. 1 (Spring 2008): 103–128. DOI: 10.1215/03335372-2007-019.

Hirsch’s most cited article providing clearest theoretical definition. Examines how the “hinge generation” inherits catastrophic histories “not through direct recollection but through haunting postmemories.” [Semantic Scholar](https://www.semanticscholar.org/paper/The-Generation-of-Postmemory-Hirsch/e8917638cdb8b6033286b08072f08a9d318bad95)[Duke University Press](https://read.dukeupress.edu/poetics-today/article/29/1/103/20954/The-Generation-of-Postmemory) Draws on Roland Barthes’s _punctum_ concept and Kaja Silverman’s distinction between idiopathic and heteropathic identification. **Freely accessible via university repositories.**

 **4.** Hirsch, Marianne. “Family Pictures: Maus, Mourning, and Post-Memory.” _Discourse_ 15, no. 2 (1992-93): 3–29.

First published articulation of the postmemory concept, developed through analysis of Spiegelman’s _Maus_. [Postmemory](https://postmemory.net/) Establishes the relationship between family photography and intergenerational trauma transmission that became central to her theoretical framework.

 **5.** Hirsch, Marianne. “Surviving Images: Holocaust Photographs and the Work of Postmemory.” In _Visual Culture and the Holocaust_ , edited by Barbie Zelizer, 146–214. New Brunswick, NJ: Rutgers University Press, 2001.

Extended analysis of Holocaust photographs in postmemorial contexts, examining ethical dimensions of encountering and circulating atrocity images across generations.

 **6.** Hirsch, Marianne. “Past Lives: Postmemories in Exile.” _Poetics Today_ 17, no. 4 (Winter 1996): 659–686.

Explores how geographical displacement intersects with temporal displacement in memory transmission, elaborating postmemory in relation to exile and diasporic experience.

 **7.** Hirsch, Marianne, and Leo Spitzer. “What’s Wrong with This Picture? Holocaust Photographs in Contemporary Narratives.” _Journal of Modern Jewish Studies_ 5, no. 2 (2006): 229–252.

Collaborative work examining use and misuse of Holocaust photographs in memorial practices, addressing authentication, appropriation, and ethical spectatorship.

### Secondary Scholarship on Postmemory

 **8.** van Alphen, Ernst. “Second-Generation Testimony, Transmission of Trauma, and Postmemory.” _Poetics Today_ 27, no. 2 (2006): 473–488.

Critical response questioning equivalence between postmemory and trauma. Argues the term “second generation” implies problematic victimhood status and critiques medicalization of intergenerational memory. [ResearchGate](https://www.researchgate.net/publication/249879793_Second-Generation_Testimony_Transmission_of_Trauma_and_Postmemory)

 **9.** Landsberg, Alison. _Prosthetic Memory: The Transformation of American Remembrance in the Age of Mass Culture_. New York: Columbia University Press, 2004.

Alternative framework to postmemory arguing mass cultural forms enable anyone to share collective memories regardless of identity. [Amazon](https://www.amazon.com/Prosthetic-Memory-Transformation-American-Remembrance/dp/0231129270) Unlike postmemory’s familial emphasis, prosthetic memory emphasizes mass-mediated acquisition generating empathy across boundaries. [Barnes & Noble](https://www.barnesandnoble.com/w/prosthetic-memory-alison-landsberg/1101422259)

 **10.** Schwab, Gabriele. _Haunting Legacies: Violent Histories and Transgenerational Trauma_. New York: Columbia University Press, 2010.

Examines transgenerational trauma from both victim and perpetrator perspectives, drawing on author’s experience as daughter of German soldier. Extends postmemory analysis to perpetrator descendants and “violent legacies.”

 **11.** Hoffman, Eva. _After Such Knowledge: Memory, History, and the Legacy of the Holocaust_. New York: Public Affairs, 2004.

Source of Hirsch’s “hinge generation” concept. Hoffman, child of Holocaust survivors, examines how second generation inherits trauma through embodied knowledge rather than direct experience.

* * *

## II. GERMAN MEMORY CULTURE (VERGANGENHEITSBEWÄLTIGUNG)

### Foundational Texts

 **12.** Adorno, Theodor W. “What Does Coming to Terms with the Past Mean?” In _Bitburg in Moral and Political Perspective_ , edited by Geoffrey H. Hartman, 114–129. Bloomington: Indiana University Press, 1986. [Original lecture 1959; German text in _Gesammelte Schriften_ , vol. 10, pt. 2, pp. 555–72]

Foundational essay distinguishing genuine “working through” ( _Aufarbeitung_ ) from mere “getting past” through repression. Adorno critiques “mastering the past” ( _Vergangenheitsbewältigung_ ) as implying dangerous closure, arguing for ongoing psychoanalytic confrontation with guilt.

 **13.** Jaspers, Karl. _The Question of German Guilt_ [ _Die Schuldfrage_ ]. Translated by E. B. Ashton. New York: Capricorn Books, 1961. [Originally published 1946]

Classic philosophical text distinguishing four types of guilt: **criminal, political, moral, and metaphysical**. Jaspers argued national guilt acknowledgment was necessary for Germany’s moral and political rebirth. Foundational for understanding inherited responsibility concepts.

 **14.** Fritzsche, Peter. “What Exactly Is Vergangenheitsbewältigung? Narrative and Its Insufficiency in Postwar Germany.” In _German Memory Contests_ , edited by Anne Fuchs, Mary Cosgrove, and Georg Grote, 25–40. Rochester, NY: Camden House, 2006. DOI: 10.1515/9781571136763-003.

Interrogates the Vergangenheitsbewältigung concept, examining narrative strategies Germans employed to represent the Nazi past while demonstrating narrative’s insufficiency for confronting unprecedented catastrophe.

### The Historikerstreit

 **15.** Knowlton, James, and Truett Cates, trans. and eds. _Forever in the Shadow of Hitler? Original Documents of the Historikerstreit Controversy Concerning the Singularity of the Holocaust_. Atlantic Highlands, NJ: Humanities Press, 1993.

Complete English translations of the Historikerstreit documents, including Ernst Nolte’s controversial essay questioning Holocaust uniqueness and Jürgen Habermas’s counterattack defending Holocaust-centered German identity.

 **16.** Evans, Richard J. _In Hitler’s Shadow: West German Historians and the Attempt to Escape from the Nazi Past_. New York: Pantheon Books, 1989.

Comprehensive English-language analysis of the Historikerstreit, critiquing “new revisionists” while providing essential context for understanding political stakes of German historical debates.

### Harald Welzer’s Family Memory Research

 **17.** Welzer, Harald, Sabine Moller, and Karoline Tschuggnall. _“Opa war kein Nazi”: Nationalsozialismus und Holocaust im Familiengedächtnis_. Frankfurt am Main: Fischer Taschenbuch Verlag, 2002.

Landmark empirical study of 40 German families discovering that despite extensive Holocaust education, third-generation Germans consistently **heroize** grandparents, transforming them into victims or secret resisters. Introduces the **“Schöntrinken”** (beauty drinking/beautifying) concept—how families systematically distort uncomfortable facts into palatable narratives. **No complete English translation exists.**

 **18.** Welzer, Harald. “Re-narrations: How Pasts Change in Conversational Remembering.” _Memory Studies_ 3, no. 1 (2010): 5–17. DOI: 10.1177/1750698009348279.

Theoretical article on how narratives transform through retelling. The “re-narration” concept explains how stories about Nazi-era relatives undergo systematic transformation across generations, with uncomfortable details softened or eliminated.

 **19.** Welzer, Harald, Sabine Moller, and Karoline Tschuggnall. “Familiengedächtnis: Über die gemeinsame Verfertigung der Vergangenheit im Gespräch.” Excerpt translated in _The Collective Memory Reader_ , edited by Jeffrey K. Olick, Vered Vinitzky-Seroussi, and Daniel Levy, 343–45. New York: Oxford University Press, 2011.

Only officially translated excerpt from _Opa war kein Nazi_ , presenting core argument that family memory operates as continuous “re-inscription” with emotional significance altering factual content.

### Cultural Memory Theory

 **20.** Assmann, Jan. _Cultural Memory and Early Civilization: Writing, Remembrance, and Political Imagination_. Cambridge: Cambridge University Press, 2011. [German original 1992]

Foundational text distinguishing “communicative memory” (informal, spanning 80–100 years across 3–4 generations) from “cultural memory” (institutionalized, spanning centuries). [Academia.edu +2](https://www.academia.edu/38303747/Assmann_Jan_Cultural_Memory_and_Early_Civilization) Essential theoretical framework for all German memory studies.

 **21.** Assmann, Aleida. _Shadows of Trauma: Memory and the Politics of Postwar Identity_. Translated by Sarah Clift. New York: Fordham University Press, 2016.

Major synthesis on German Holocaust memory examining false memory, denial, repression, and German “victimhood” discourse. Includes chapters on commemorative sites and future of Holocaust memory.

 **22.** Assmann, Aleida. _Cultural Memory and Western Civilization: Functions, Media, Archives_. Cambridge: Cambridge University Press, 2011.

Comprehensive introduction examining media of memory construction including writing, images, bodily practices, places, and monuments. Distinguishes “functional memory” (active, identity-forming) from “storage memory” (archival, latent). [Amazon](https://www.amazon.com/Cultural-Memory-Western-Civilization-Functions/dp/0521165873)[AbeBooks](https://www.abebooks.com/9780521764377/Cultural-Memory-Western-Civilization-Functions-0521764378/plp)

### W.G. Sebald and German Silence

 **23.** Sebald, W.G. _On the Natural History of Destruction_. Translated by Anthea Bell. New York: Random House, 2003. [German original 1999]

Controversial lectures asking why Allied carpet bombing of 131 German cities occupies so little space in German cultural memory. Sparked intense debate about German victimhood narratives and memory ethics.

 **24.** Crownshaw, Richard. “Holocaust Memory and the Air War: W.G. Sebald’s _Luftkrieg und Literatur_.” In _The Afterlife of Holocaust Memory in Contemporary Literature and Culture_ , 44–75. Basingstoke: Palgrave Macmillan, 2010. DOI: 10.1057/9780230294585_3.

Scholarly analysis situating Sebald within debates about German victimhood and Holocaust memory, examining how Sebald navigates German suffering while avoiding equivalence with Nazi victims.

* * *

## III. CHRISTOPHER BROWNING’S “ORDINARY MEN”

 **25.** Browning, Christopher R. _Ordinary Men: Reserve Police Battalion 101 and the Final Solution in Poland_. New York: HarperCollins, 1992. Revised edition with new afterword, 1998.

Landmark microhistory examining how **500 middle-aged, working-class German reservists** (average age 39.5) from Hamburg became mass killers of 83,000 Jews in 1942-1943. Argues perpetrators were motivated by conformity, peer pressure, careerism, and deference to authority rather than fanatical antisemitism. Three groups emerged: eager killers, compliant participants, and a small minority of evaders. [United States Holocaust Memorial Museum](https://shop.ushmm.org/products/ordinary-men-reserve-police-battalion-101-and-the-final-solution)

 **26.** Browning, Christopher R. “Afterword: Ordinary Men or Ordinary Germans?” In _Ordinary Men_ , revised edition, 191-223. New York: HarperCollins, 1998.

Direct scholarly response to Daniel Goldhagen’s _Hitler’s Willing Executioners_ , critiquing the “eliminationist antisemitism” thesis. Argues Reserve Police Battalion 101’s third-generation conscripts were randomly selected without ideological screening, making them “truly ordinary men.” [The New York Review of Books](https://www.nybooks.com/articles/2025/06/26/they-were-ordinary-men/)

 **27.** Browning, Christopher R. _The Origins of the Final Solution: The Evolution of Nazi Jewish Policy, September 1939-March 1942_. Lincoln: University of Nebraska Press, 2004.

Comprehensive historiography of decision-making processes leading to genocide, examining transition from emigration policies to systematic murder and role of mid-level functionaries.

 **28.** Moses, A. Dirk. “Structure and Agency in the Holocaust: Daniel J. Goldhagen and His Critics.” _History and Theory_ 37, no. 2 (May 1998): 194-219. DOI: 10.1111/0018-2656.00048.

Scholarly analysis of the Browning-Goldhagen debate, examining how each historian balances structural/situational factors versus individual agency in explaining mass killing.

* * *

## IV. HANNAH ARENDT ON BANALITY OF EVIL

 **29.** Arendt, Hannah. _Eichmann in Jerusalem: A Report on the Banality of Evil_. New York: Viking Press, 1963. Revised and enlarged edition, 1964. Penguin Classics edition with introduction by Amos Elon, 2006.

Controversial report on Adolf Eichmann’s 1961 trial introducing the **“banality of evil”** concept. Argues Eichmann was not a demonic antisemite but a thoughtless bureaucrat motivated by careerism who failed to think independently. [Wikipedia](https://en.wikipedia.org/wiki/Eichmann_in_Jerusalem) Her thesis that evil could arise from “thoughtlessness” sparked intense controversy.

 **30.** Arendt, Hannah. _The Life of the Mind_. Edited by Mary McCarthy. New York: Harcourt Brace Jovanovich, 1978. One-volume edition, 1981.

Arendt’s final philosophical work [Amazon](https://www.amazon.com/Life-Mind-Combined-Volumes-Vols/dp/0156519925) directly sparked by witnessing Eichmann’s “inability to think.” Explores whether the activity of thinking—a solitary dialogue with oneself—conditions people against evil. [Brooklyn Institute for Social Research](https://thebrooklyninstitute.com/items/courses/new-york/hannah-arendt-the-life-of-the-mind-2/)

 **31.** Stangneth, Bettina. _Eichmann Before Jerusalem: The Unexamined Life of a Mass Murderer_. Translated by Ruth Martin. New York: Alfred A. Knopf, 2014.

Major critique of Arendt’s “banality” thesis based on over 1,300 pages of previously unstudied archival materials, including the “Sassen transcripts” from Eichmann’s Argentine exile. Demonstrates Eichmann deliberately crafted his “banal bureaucrat” persona for trial; in Argentina, he proudly described himself as an ideological antisemite.

 **32.** Cesarani, David. _Becoming Eichmann: Rethinking the Life, Crimes, and Trial of a “Desk Murderer”_. Cambridge, MA: Da Capo Press, 2006.

Biographical study questioning Arendt’s portrait, arguing Eichmann was more active and ideologically committed than suggested. [Wikipedia](https://en.wikipedia.org/wiki/Eichmann_in_Jerusalem) Important for understanding the **“desk murderer” (Schreibtischtäter)** concept.

* * *

## V. JAMES WALLER’S SOCIAL PSYCHOLOGY OF PERPETRATION

 **33.** Waller, James. _Becoming Evil: How Ordinary People Commit Genocide and Mass Killing_. New York: Oxford University Press, 2002. Second edition, 2007.

Synthesizes social psychology, evolutionary psychology, and historiography into four-pronged explanatory model: (1) evolutionary influences on human nature; (2) individual dispositional factors; (3) cultural construction of worldview; (4) psychological construction of the “other” through dehumanization and moral disengagement.

 **34.** Waller, James. _Confronting Evil: Engaging Our Responsibility to Prevent Genocide_. New York: Oxford University Press, 2016.

Follow-up applying perpetrator psychology to genocide prevention, organized around upstream, midstream, and downstream prevention strategies. Essential for understanding perpetrator accountability and rehabilitation.

 **35.** Waller, James. “Perpetrators of the Holocaust: Divided and Unitary Self Conceptions of Evildoing.” _Holocaust and Genocide Studies_ 10, no. 1 (Spring 1996): 11-33. DOI: 10.1093/hgs/10.1.11.

Early article developing Waller’s framework on how perpetrators maintain positive self-concepts while committing atrocities through moral disengagement, dehumanization, and rationalization.

### Related Perpetrator Psychology

 **36.** Milgram, Stanley. _Obedience to Authority: An Experimental View_. New York: Harper & Row, 1974.

Classic text describing obedience experiments begun three months after Eichmann’s trial opened. **65% of participants** administered maximum “450-volt shocks” when instructed by authority figures. Foundational for social psychological approaches to perpetration.

 **37.** Milgram, Stanley. “Behavioral Study of Obedience.” _Journal of Abnormal and Social Psychology_ 67, no. 4 (1963): 371-378. DOI: 10.1037/h0040525.

Original peer-reviewed article describing obedience experiments.

 **38.** Fenigstein, Allan. “Milgram’s Shock Experiments and the Nazi Perpetrators: A Contrarian Perspective.” _Theory & Psychology_ 25, no. 5 (2015): 581-598. DOI: 10.1177/0959354315601904.

Critical reassessment arguing obedience pressures had little role in the Holocaust—perpetrators displayed enthusiasm, engaged in gratuitous cruelty, volunteered for killing operations, and rarely sought withdrawal.

 **39.** Zimbardo, Philip G. _The Lucifer Effect: Understanding How Good People Turn Evil_. New York: Random House, 2007.

Comprehensive account of Stanford Prison Experiment and broader framework for situational evil. [Amazon](https://www.amazon.com/Lucifer-Effect-Understanding-Good-People/dp/0812974441)[Goodreads](https://www.goodreads.com/book/show/359194.The_Lucifer_Effect) Argues “bad barrels” (situations) rather than “bad apples” (dispositions) explain most perpetration. [KBbookreviews](https://kbbookreviews867789450.wordpress.com/2021/01/11/book-discussion-book-review-the-lucifer-effect-understanding-how-good-people-turn-evil-by-philip-zimbardo/)

 **40.** Staub, Ervin. _The Roots of Evil: The Origins of Genocide and Other Group Violence_. Cambridge: Cambridge University Press, 1989. Revised edition, 1992.

Psychological analysis examining genocide origins through case studies including the Holocaust, Armenian genocide, and Cambodian genocide. [Amazon](https://www.amazon.com/Roots-Origins-Genocide-Other-Violence/dp/0521422140) Develops “continuum of destruction” showing how societies escalate toward mass violence.

 **41.** Lifton, Robert Jay. _The Nazi Doctors: Medical Killing and the Psychology of Genocide_. New York: Basic Books, 1986.

Groundbreaking study of physician perpetrators introducing **“doubling”** concept—the psychological splitting enabling doctors to maintain professional identities while committing atrocities.

 **42.** Bandura, Albert. “Moral Disengagement in the Perpetration of Inhumanities.” _Personality and Social Psychology Review_ 3, no. 3 (1999): 193-209. DOI: 10.1207/s15327957pspr0303_3.

Foundational article on psychological mechanisms enabling atrocity, including euphemistic labeling, moral justification, displacement of responsibility, and dehumanization.

* * *

## VI. HARALD WELZER ON FAMILY MEMORY AND HEROIZATION

 _See entries 17-19 above in Section II_

 **Additional Sources:**

 **43.** Fuchs, Anne. “The Tinderbox of Memory: Generation and Masculinity in Väterliteratur.” In _German Memory Contests_ , edited by Anne Fuchs, Mary Cosgrove, and Georg Grote, 41–65. Rochester, NY: Camden House, 2006.

Analyzes _Väterliteratur_ (father literature) through which the 68er generation confronted Nazi-era parents. Essential for understanding generational memory dynamics and shift from _Väterliteratur_ to _Enkelliteratur_ (grandchildren’s literature).

 **44.** Olick, Jeffrey K. “What Does It Mean to Normalize the Past? Official Memory in German Politics since 1989.” _Social Science History_ 22, no. 4 (1998): 547–571.

Examines transformations in German official memory politics after reunification, analyzing how political leaders sought to “normalize” the Nazi past.

* * *

## VII. INTERGENERATIONAL/PERPETRATOR TRAUMA

### Foundational Trauma Transmission Research

 **45.** Danieli, Yael, ed. _International Handbook of Multigenerational Legacies of Trauma_. New York: Springer, 1998. DOI: 10.1007/978-1-4757-5567-1.

Comprehensive foundational text on intergenerational trauma transmission, assembling international scholars exploring legacy of genocide across cultures including Holocaust survivors and Nazi perpetrator descendants.

 **46.** Danieli, Yael, Fran H. Norris, and Brian Engdahl. “Multigenerational Legacies of Trauma: Modeling the What and How of Transmission.” _American Journal of Orthopsychiatry_ 86, no. 6 (2016): 639-651. DOI: 10.1037/ort0000145.

Operationalizes Danieli’s Trauma and Continuity of Self framework using sample of 422 adult children of Holocaust survivors. Validates “victim, numb, and fighter” posttrauma adaptational styles model.

### Epigenetics and Trauma

 **47.** Yehuda, Rachel, and Amy Lehrner. “Intergenerational Transmission of Trauma Effects: Putative Role of Epigenetic Mechanisms.” _World Psychiatry_ 17, no. 3 (2018): 243-257. DOI: 10.1002/wps.20568. **Open Access: PMC6127768.**

Authoritative review providing key conclusion: “Studies in humans have **not yet demonstrated** that the effects of trauma are heritable through non-genomic (i.e., epigenetic) mechanisms.” [PubMed Central](https://pmc.ncbi.nlm.nih.gov/articles/PMC6127768/) Distinguishes between developmentally programmed effects and germline epigenetic changes.

 **48.** Yehuda, Rachel, et al. “Holocaust Exposure Induced Intergenerational Effects on FKBP5 Methylation.” _Biological Psychiatry_ 80, no. 5 (2016): 372-380. DOI: 10.1016/j.biopsych.2015.08.005.

Landmark 2016 study generating significant scientific debate. Examined 32 Holocaust survivors and 22 offspring, finding differential methylation at FKBP5 gene. Crucially, methylation patterns were directionally _different_ in parents versus offspring.

 **49.** Yehuda, Rachel, et al. “Influences of Maternal and Paternal PTSD on Epigenetic Regulation of the Glucocorticoid Receptor Gene in Holocaust Survivor Offspring.” _American Journal of Psychiatry_ 171, no. 8 (2014): 872-880. DOI: 10.1176/appi.ajp.2014.13121571. **Open Access: PMC4127390.**

Examined 80 Holocaust survivor offspring finding differential effects of maternal versus paternal PTSD on gene methylation.

 **50.** Jawaid, Ali, Martin Roszkowski, and Isabelle M. Mansuy. “Transgenerational Epigenetics of Traumatic Stress.” _Progress in Molecular Biology and Translational Science_ 158 (2018): 273-298. DOI: 10.1016/bs.pmbts.2018.03.003.

Comprehensive chapter reviewing epigenetic mechanisms, importantly distinguishing between **intergenerational** (F0→F1) and **transgenerational** (F0→F3+) inheritance. [ScienceDirect](https://www.sciencedirect.com/science/article/abs/pii/S187711731830053X)

### Perpetrator Descendants

 **51.** Bar-On, Dan. _Legacy of Silence: Encounters with Children of the Third Reich_. Cambridge, MA: Harvard University Press, 1989.

Pioneering study by Israeli psychologist who interviewed 58 children of Nazi perpetrators, including SS members and Einsatzgruppen participants. Introduced **“double wall”** phenomenon—silence maintained by both families and German society. Established the field of perpetrator descendant psychology.

 **52.** Bar-On, Dan. “Descendants of Nazi Perpetrators: Seven Years after the First Interviews.” _Journal of Humanistic Psychology_ 36, no. 1 (1996): 55-74. DOI: 10.1177/00221678960361006.

Follow-up examining long-term outcomes, documenting formation of TRT (To Reflect and Trust) dialogue groups bringing together descendants of Holocaust survivors and Nazi perpetrators.

 **53.** Livingston, Kathy. “Opportunities for Mourning When Grief is Disenfranchised: Descendants of Nazi Perpetrators in Dialogue with Holocaust Survivors.” _Omega: Journal of Death and Dying_ 61, no. 3 (2010): 205–222. DOI: 10.2190/OM.61.3.c.

Explores “unmourned and disenfranchised grief” among adult children of Nazi perpetrators, examining how dialogue creates opportunities for mourning. [PubMed](https://pubmed.ncbi.nlm.nih.gov/20873533/)

### Transgenerational Haunting Theory

 **54.** Abraham, Nicolas, and Maria Torok. _The Shell and the Kernel: Renewals of Psychoanalysis_. Vol. 1. Translated by Nicholas T. Rand. Chicago: University of Chicago Press, 1994.

Foundational psychoanalytic text introducing **“phantom”** (transgenerational transmission of family secrets), **“crypt”** (burial of inadmissible experience), and “cryptonomy” concepts. [ResearchGate](https://www.researchgate.net/scientific-contributions/Maria-Torok-19800567) Essential for understanding transgenerational haunting theory.

 **55.** Abraham, Nicolas. “Notes on the Phantom: A Complement to Freud’s Metapsychology.” _Critical Inquiry_ 13, no. 2 (1987): 287-292. DOI: 10.1086/448387.

Key theoretical essay: “The phantom represents a radical reorientation... symptoms do not spring from the individual’s own life experiences but from someone else’s psychic conflicts, traumas, or secrets.”

* * *

## VIII. WAFFEN SS HISTORY AND HISTORIOGRAPHY

### Foundational Works

 **56.** Stein, George H. _The Waffen SS: Hitler’s Elite Guard at War, 1939-1945_. Ithaca, NY: Cornell University Press, 1966.

Foundational academic monograph examining organizational development from 28,000 men at war’s outbreak to over 500,000 by 1945. [Amazon](https://www.amazon.com/Waffen-SS-Hitlers-Elite-1939-45/dp/0801492750)[Google Books](https://books.google.com/books/about/The_Waffen_SS.html?id=-KEtPlNQJNgC) Distinguished by measured approach avoiding both apologetics and wholesale condemnation. [Goodreads](https://www.goodreads.com/book/show/1063799.Waffen_SS/)

 **57.** Wegner, Bernd. _The Waffen-SS: Organization, Ideology and Function_. Translated by Ronald Webster. Oxford: Basil Blackwell, 1990. [German original: _Hitlers politische Soldaten_ , 1982]

According to Timothy Garton Ash, Wegner is “the leading authority on the Waffen-SS.” [Wikipedia](https://en.wikipedia.org/wiki/Bernd_Wegner) Comprehensive doctoral dissertation examining organizational structure, recruitment, ideology, and social composition. [Amazon](https://www.amazon.com/Waffen-Ss-Organization-Ideology-Function/dp/0631140735) Presents Waffen SS as ideologically distinct **“political soldiers”** rather than purely military formation.

 **58.** Sydnor, Charles W., Jr. _Soldiers of Destruction: The SS Death’s Head Division, 1933-1945_. Princeton, NJ: Princeton University Press, 1977. Updated edition 1990.

Definitive study of 3rd SS “Totenkopf” Division establishing crucial connections between SS-Totenkopfverbände (concentration camp guards) and Waffen SS combat formations. [De Gruyter Brill](https://www.degruyterbrill.com/document/doi/10.1515/9780691214160-006/pdf?lang=en) Explicitly challenges “clean Waffen SS” mythology.

 **59.** Sydnor, Charles W., Jr. “The History of the SS Totenkopfdivision and the Postwar Mythology of the Waffen SS.” _Central European History_ 6, no. 4 (1973): 339-362.

Seminal article establishing “direct and significant link between Eicke, the concentration camp system, and the Waffen SS” that apologist writers ignore. Documents reserve Death’s Head Regiments serving as concentration camp guards before incorporation into field divisions.

### Ideology and War Crimes

 **60.** Böhler, Jochen, and Robert Gerwarth, eds. _The Waffen-SS: A European History_. Oxford: Oxford University Press, 2016.

First systematic pan-European study of non-German Waffen-SS volunteers. [Oxford Academic](https://academic.oup.com/book/1399) Features 34 contributions examining recruitment, ideological training, participation in Holocaust and war crimes, postwar prosecution, and contemporary memory politics.

 **61.** Bartov, Omer. _The Eastern Front, 1941-45: German Troops and the Barbarisation of Warfare_. London: Macmillan, 1985. Second edition 2001.

Pioneering study examining “demodernization” and ideological indoctrination of Wehrmacht troops. Challenged “clean Wehrmacht” myth by demonstrating ideological permeation; methodology applicable to Waffen SS studies.

 **62.** Bartov, Omer. _Hitler’s Army: Soldiers, Nazis, and War in the Third Reich_. New York: Oxford University Press, 1991.

Explicitly challenges myths that German soldiers were ordinary men misused and that Wehrmacht actions were divorced from National Socialism.

 **63.** Wette, Wolfram. _The Wehrmacht: History, Myth, Reality_. Translated by Deborah Lucas Schneider. Cambridge, MA: Harvard University Press, 2006.

Comprehensive study of Wehrmacht leadership’s role in war crimes. Wette called the clean Wehrmacht thesis a **“collective perjury”** maintained by wartime generation.

### Specific Operations

 **64.** Weingartner, James J. _A Peculiar Crusade: Willis M. Everett and the Malmedy Massacre_. New York: New York University Press, 2000.

Scholarly examination of **Malmedy massacre** (December 17, 1944), killing of 84 American POWs by Kampfgruppe Peiper during Battle of the Bulge, [Wikipedia](https://en.wikipedia.org/wiki/Malmedy_massacre) and subsequent controversial war crimes trial.

 **65.** Luther, Craig W.H. _Blood and Honor: The History of the 12th SS Panzer Division “Hitler Youth,” 1943-1945_. San Jose, CA: R. James Bender Publishing, 1987.

Operational history of 12th SS Panzer Division “Hitlerjugend,” formed from 16-17 year old Hitler Youth members in 1943. Documents war crimes during Normandy campaign and subsequent operations at **Battle of the Bulge** and **Operation Spring Awakening**.

 **66.** Defta, Adrian Dragoș. _The 12th SS Panzer Division “Hitlerjugend”: Combat, Crimes, and Controversy_. Cambridge: Cambridge Scholars Publishing, 2021.

Recent monograph “demythologising” the Hitlerjugend Division using social psychology perspectives. Analyzes psychological mechanisms facilitating moral disengagement while demonstrating agency and ideological commitment among teenage soldiers.

### Memory Politics and Apologetics

 **67.** Wilke, Karsten. _Die “Hilfsgemeinschaft auf Gegenseitigkeit” (HIAG) 1950-1990_. Paderborn: Ferdinand Schöningh, 2011. [In German]

Definitive scholarly study of HIAG, the Waffen-SS veterans’ organization. Analyzes HIAG’s lobbying for pensions, publishing activities, and construction of counter-narratives portraying WWII as “just war for Europe against Bolshevism.”

 **68.** Smelser, Ronald, and Edward J. Davies II. _The Myth of the Eastern Front: The Nazi-Soviet War in American Popular Culture_. Cambridge: Cambridge University Press, 2008.

Documents how “clean Wehrmacht” and “clean Waffen SS” myths penetrated American popular culture through memoirs, wargaming, and internet forums.

 **69.** Hurd, Madeleine, and Steffen Werther. “Waffen-SS Veterans and Their Sites of Memory Today.” In _The Waffen-SS: A European History_ , edited by Böhler and Gerwarth, 277-310. Oxford: Oxford University Press, 2016.

Examines veterans’ associations, commemorative practices, and “alternative war narratives” anchored in public celebrations, particularly in post-1989 Eastern Europe.

* * *

## IX. GENEALOGICAL TESTIMONY AND GENEALOGICAL KNOWLEDGE

 **70.** Parowicz, Izabela. “Genealogical Memory and Its Function in Bridging the ‘Floating Gap.’” _Genealogy_ 8, no. 1 (2024): 1. DOI: 10.3390/genealogy8010001.

Recent scholarly work distinguishing “genealogical memory” from family memory, emphasizing its intentional and reconstructive nature. Draws on Jan Vansina’s “floating gap” concept between communicative and cultural memory.

 **71.** Edwards, Caterina. “Genealogical Nostalgia: Second-Generation Memory and the Return to Homelands.” _Memory Studies_ 5, no. 2 (2012): 169–183. DOI: 10.1177/1750698011415249.

Analyzes “genealogical nostalgia” as longing for times and places of ancestral past, examining how physical pilgrimages both idealize and problematize origins.

 **72.** Foucault, Michel. “Nietzsche, Genealogy, History.” In _Language, Counter-Memory, Practice: Selected Essays and Interviews_ , edited by Donald F. Bouchard, translated by Donald F. Bouchard and Sherry Simon, 139-164. Ithaca: Cornell University Press, 1977.

Foundational theoretical text on genealogy as method—not seeking origins but tracing “descent” through accidents, errors, and discontinuities.

* * *

## X. ALEXANDER MAZEY’S PARAPOLITICAL THEORY

 **Note** : Extensive searches did not locate academic publications by Alexander Mazey specifically on “parapolitical theory,” “institutional trust dynamics,” or “elite institutional denial mechanisms.” Alexzander Mazey is identified as a poet and cultural theorist contributing to _Baudrillard Now_ with publications including _Sad Boy Aesthetics_ (2021) and _Living in Disneyland_ (2020) focusing on Baudrillardian hyperreality. The specific topics mentioned may represent unpublished, emerging, or differently-attributed work.

 **Parapolitical Theory (Alternative Sources):**

 **73.** Wilson, Eric, ed. _The Dual State: Parapolitics, Carl Schmitt, and the National Security Complex_. Surrey, UK: Ashgate Publishing, 2012.

Major academic anthology on parapolitical studies examining “deep state” theory through Carl Schmitt’s constitutional thought. Wilson’s chapter “The Concept of the Parapolitical” provides foundational definition: parapolitics studies interactions between public entities and clandestine agencies, examining institutional concealment and criminal sovereignty.

* * *

## XI. PERFORMANCE AND GENEALOGICAL RECKONING

### Performance Studies Foundations

 **74.** Taylor, Diana. _The Archive and the Repertoire: Performing Cultural Memory in the Americas_. Durham, NC: Duke University Press, 2003.

Foundational text distinguishing **“archive”** (documents, texts, material evidence) from **“repertoire”** (embodied memory conveyed through gesture, speech, movement). Argues performance must be taken seriously as means of storing and transmitting knowledge, particularly in contexts of trauma. Analysis of H.I.J.O.S. (children of Argentina’s “disappeared”) demonstrates how the body performs DNA-linked memory.

 **75.** Phelan, Peggy. _Unmarked: The Politics of Performance_. London: Routledge, 1993.

Seminal work on performance ontology arguing “performance’s only life is in the present” and “becomes itself through disappearance.” Her thesis that performance cannot be saved or documented without becoming something other has shaped decades of debate.

 **76.** Schneider, Rebecca. _Performing Remains: Art and War in Times of Theatrical Reenactment_. New York: Routledge, 2011.

Challenges Phelan’s disappearance thesis, arguing performance can be engaged as “what remains, rather than what disappears.” Develops **“body-to-body transmission”** concept—performance as mode of historical retrieval.

 **77.** Schneider, Rebecca. “Performance Remains.” _Performance Research_ 6, no. 2 (2001): 100–108. DOI: 10.1080/13528165.2001.10871792.

Foundational essay: “The archive performs the institution of disappearance, with object remains as indices of disappearance.” Introduces counter-memory through reenactment.

 **78.** Bissell, Bill, and Linda Caruso Haviland, eds. _The Sentient Archive: Bodies, Performance, and Memory_. Middletown, CT: Wesleyan University Press, 2024.

Recent interdisciplinary collection examining how the body serves as repository for knowledge. Contributors include André Lepecki, Ralph Lemon, and Meg Stuart. Essays explore “bodied knowing,” embodied archives, and structures of transmission.

### Trauma and Working-Through

 **79.** LaCapra, Dominick. _Writing History, Writing Trauma_. Baltimore: Johns Hopkins University Press, 2001.

Major contribution exploring intersection of psychoanalytic concepts with historical analysis. Distinguishes **“acting out”** (repetition compulsion) from **“working-through”** (Durcharbeitung) as processes for dealing with traumatic pasts.

 **80.** LaCapra, Dominick. _Representing the Holocaust: History, Theory, Trauma_. Ithaca, NY: Cornell University Press, 1994.

Probing analysis of how traumatic historical events disrupt representation and memory, exploring how psychoanalysis offers tools for historical understanding.

### Testimony Studies

 **81.** Felman, Shoshana, and Dori Laub. _Testimony: Crises of Witnessing in Literature, Psychoanalysis, and History_. New York: Routledge, 1992.

Landmark interdisciplinary work defining Holocaust as “a radical crisis of witnessing—the unprecedented historical occurrence of an event eliminating its own witness.” Develops “empathic listening” concept and listener’s role in enabling testimony.

 **82.** Hartman, Geoffrey H. _The Longest Shadow: In the Aftermath of the Holocaust_. Bloomington: Indiana University Press, 1996.

Essays by co-founder of Fortunoff Video Archive for Holocaust Testimonies. Explores representation, ethics, and transmission of Holocaust memory to subsequent generations.

* * *

## XII. COMPARATIVE PERPETRATOR GENEALOGIES

### German Perpetrator Descendants

 **83.** Himmler, Katrin. _The Himmler Brothers: A German Family History_. Translated by Michael Mitchell. London: Pan Macmillan, 2007.

Memoir-historical investigation by Heinrich Himmler’s great-niece examining how “ordinary” family members enabled Nazi crimes. Revealed grandfather Ernst directly caused deportation and death of a Jewish engineer, challenging family narratives.

 **84.** Frank, Niklas. _In the Shadow of the Reich_. Translated by Arthur S. Wensinger and Carole Clew-Hoey. New York: Alfred A. Knopf, 1991. [German original: _Der Vater: Eine Abrechnung_ , 1987]

Controversial memoir by Hans Frank’s son (Governor-General of Nazi-occupied Poland) representing uncompromising “settling of accounts” ( _Abrechnung_ ) with perpetrator legacy.

 **85.** Ze’evi, Chanoch, dir. _Hitler’s Children_ (German: _Meine Familie, die Nazis und Ich_ ). Documentary film. Maya Productions, 2011.

Israeli-German documentary featuring five descendants of Nazi perpetrators—Katrin Himmler, Niklas Frank, Bettina Göring, Rainer Höss, and Monika Hertwig-Goeth. Documents diverse coping strategies including sterilization to “end the line.”

 **86.** Steir-Livny, Liat. “Looking Beyond the Victims: Descendants of the Perpetrators in Hitler’s Children.” _Holocaust Studies_ 27, no. 2 (2021): 163-181. DOI: 10.1080/17504902.2019.1637500.

Analysis of the 2011 documentary examining cinematic and ethical choices in representing perpetrator descendants, reviewing scholarship from Bar-On through contemporary studies.

### Transnational Memory

 **87.** Rothberg, Michael. _Multidirectional Memory: Remembering the Holocaust in the Age of Decolonization_. Stanford: Stanford University Press, 2009.

Foundational text arguing against “competitive memory” frameworks, proposing different memory traditions productively interact through “borrowing, cross-referencing, and other kinds of echoes and ricochets.”

 **88.** Rothberg, Michael. _The Implicated Subject: Beyond Victims and Perpetrators_. Stanford: Stanford University Press, 2019.

Introduces **“implicated subject”** —those occupying positions between victim and perpetrator who “play crucial, but indirect roles in systems of domination.” Drawing on Primo Levi’s “grey zone,” argues implicated subjects are “transmission belts of domination.”

### Japanese War Memory

 **89.** Hashimoto, Akiko. “Inheriting Perpetrator Trauma: Intergenerational Memory of the Sino-Japan War.” _American Journal of Cultural Sociology_ 12 (2024): [online first].

Groundbreaking article examining memoirs by Japanese second-generation descendants of war veterans, including Itō Hideko whose father sent 44 Chinese prisoners to Unit 731. First sustained analysis of Japanese perpetrator genealogies comparable to German cases.

 **90.** Daqing, Yang, and Mark Selden. “Japanese and American War Atrocities, Historical Memory and Reconciliation: World War II to Today.” _Asia-Pacific Journal: Japan Focus_ (2008).

Comparative framework analyzing controversies around Nanjing Massacre, comfort women, and Unit 731, examining why accepting responsibility has been difficult in Japan.

 **91.** House, Juliane, and Dániel Z. Kádár. “German and Japanese War Crime Apologies: A Contrastive Pragmatic Study.” _Journal of Pragmatics_ 177 (2021): 187–206.

Corpus-based linguistic analysis examining pragmatic features of German and Japanese WWII apologies diachronically.

### Colonial Perpetrator Genealogies

 **92.** Wolfe, Patrick. “Settler Colonialism and the Elimination of the Native.” _Journal of Genocide Studies_ 8, no. 4 (2006): 387–409.

Foundational article arguing settler colonialism operates through “logic of elimination.” Drawing on Arendt, Césaire, and Du Bois, argues core features of modernity were pioneered in colonies.

 **93.** Sleeter, Christine, ed. “Critical Settler Family History.” Special Issue, _Genealogy_ 5, no. 4 (2021). **Open Access via MDPI.**

Develops “critical settler family history” as methodology for descendants of colonial settlers to examine ancestors’ roles in dispossession. Addresses Australian, New Zealand, Canadian, and U.S. settler contexts.

 **94.** Bruyneel, Kevin. _Settler Memory: The Disavowal of Indigeneity and the Politics of Race in the United States_. Chapel Hill: University of North Carolina Press, 2021.

Argues settler memory operates through “disavowal”—a productive process invoking Indigenous peoples and settler violence while deflecting implications.

### Norwegian Perpetrator Descendants

 **95.** Amundsen, Marianne Sætre. “Writing the Burden of Family History: Descendant Narratives of World War II Perpetrators in Norway, 1980s–2020s.” _Humanities_ 14, no. 12 (2025): 239. DOI: 10.3390/h14120239.

Comprehensive analysis of Norwegian descendant literature by children and grandchildren of Nazis, Waffen-SS fighters, and Nasjonal Samling members. Identifies generational patterns including stigmatization in early works and inherited shame in later self-reflective accounts.

* * *

## ADDITIONAL KEY REFERENCE WORKS

### Memory Studies Anthologies

 **96.** Olick, Jeffrey K., Vered Vinitzky-Seroussi, and Daniel Levy, eds. _The Collective Memory Reader_. New York: Oxford University Press, 2011.

Definitive anthology containing 91 texts including excerpts from Halbwachs, Jan Assmann, and Welzer. Substantial introduction provides essential historiography of memory studies.

### Holocaust Memorial Practices

 **97.** Cook, Matthew, and Micheline van Riemsdijk. “Agents of Memorialization: Gunter Demnig’s Stolpersteine and the Individual (Re-)creation of a Holocaust Landscape in Berlin.” _Journal of Historical Geography_ 43 (2014): 138–147. DOI: 10.1016/j.jhg.2013.10.003.

Definitive study of Demnig’s **Stolpersteine** project (over 100,000 “stumbling stones” across Europe), analyzing how individuals shape commemorative landscapes.

 **98.** Harjes, Kirsten. “Stumbling Stones: Holocaust Memorials, National Identity, and Democratic Inclusion in Berlin.” _German Politics and Society_ 23, no. 1 (2005): 138–151.

Analyzes how Stolpersteine create “vernacular” rather than “official” memory, fostering democratic participation in memory practices.

### Psychoanalysis and Memory

 **99.** Caruth, Cathy, ed. _Trauma: Explorations in Memory_. Baltimore: Johns Hopkins University Press, 1995.

Influential collection including essays by psychoanalysts, literary critics, and historians examining traumatic memory, belatedness, and witnessing.

 **100.** Caruth, Cathy. _Unclaimed Experience: Trauma, Narrative, and History_. Baltimore: Johns Hopkins University Press, 1996.

Theoretical elaboration of trauma’s resistance to representation, drawing on Freud’s _Beyond the Pleasure Principle_ to examine how traumatic experience escapes integration into narrative.

### Visual Culture and Photography

 **101.** Barthes, Roland. _Camera Lucida: Reflections on Photography_. Translated by Richard Howard. New York: Hill and Wang, 1981.

Theoretical foundation for postmemory’s visual analysis, introducing **punctum** (the detail that “pricks” or wounds the viewer) and **studium** (the general cultural interest).

 **102.** Silverman, Kaja. _The Threshold of the Visible World_. New York: Routledge, 1996.

Source for heteropathic identification concept crucial to Hirsch’s postmemory theory—identification with the other rather than the self.

 **103.** Sontag, Susan. _Regarding the Pain of Others_. New York: Farrar, Straus and Giroux, 2003.

Meditation on war photography and the ethics of looking at images of suffering, questioning whether atrocity images promote empathy or voyeurism.

### German Perpetrator Descendants (Additional)

 **104.** Imhoff, Roland, Roland Wohl, and Rainer Erb. “Collective Shame and the Positioning of German National Identity.” _Psicología Política_ 32 (2006): 131-153.

Empirical study of third-generation Germans examining collective shame (versus guilt) for Nazi past. Developed 7-item shame scale demonstrating significant shame tied to national identity.

 **105.** Giordano, Ralph. _Die zweite Schuld oder Von der Last Deutscher zu sein_. Hamburg: Rasch und Röhring, 1987.

Coined the term **“second guilt”** ( _zweite Schuld_ )—the guilt of postwar denial and failure to adequately prosecute Nazi crimes.

### Intergenerational Memory Studies

 **106.** Suleiman, Susan Rubin. _Crises of Memory and the Second World War_. Cambridge, MA: Harvard University Press, 2006.

Examines how children who experienced WWII as young children remember and narrate that experience, developing concept of the **“1.5 generation”** between survivors and second generation.

 **107.** Mendelsohn, Daniel. _The Lost: A Search for Six of Six Million_. New York: HarperCollins, 2006.

Memoir-investigation combining genealogical research with Holocaust testimony, demonstrating how genealogical testimony functions as both historical evidence and literary form.

### Performance Art and Holocaust Memory

 **108.** Zelizer, Barbie, ed. _Visual Culture and the Holocaust_. New Brunswick, NJ: Rutgers University Press, 2001.

Collection examining visual representations of the Holocaust including photography, film, museums, and monuments.

 **109.** Young, James E. _The Texture of Memory: Holocaust Memorials and Meaning_. New Haven: Yale University Press, 1993.

Foundational study of Holocaust memorialization examining how monuments construct meaning and memory across national contexts.

### Recent Perpetrator Descendant Studies

 **110.** Wittmann, Rebecca. _Beyond Justice: The Auschwitz Trial_. Cambridge, MA: Harvard University Press, 2005.

Examines the Frankfurt Auschwitz Trial (1963-1965) and its impact on German memory, demonstrating how legal proceedings shaped public understanding of perpetrators.

 **111.** Pendas, Devin O. _The Frankfurt Auschwitz Trial, 1963-1965: Genocide, History, and the Limits of the Law_. Cambridge: Cambridge University Press, 2006.

Comprehensive study of the trial’s historiographical and legal significance.

### Theoretical Frameworks

 **112.** Huyssen, Andreas. _Present Pasts: Urban Palimpsests and the Politics of Memory_. Stanford: Stanford University Press, 2003.

Analyzes public memory in Berlin, Buenos Aires, and New York. Includes influential essay “Of Mice and Mimesis: Reading Spiegelman with Adorno.”

 **113.** Said, Edward W. _The World, the Text, and the Critic_. Cambridge, MA: Harvard University Press, 1983.

Source for filiation/affiliation distinction that Hirsch develops into familial versus affiliative postmemory.

### Recent Scholarship

 **114.** Volks, Cal. “Intergenerational Trauma in Nazi Germany and Apartheid South Africa: Reconciliation and Overcoming Intergenerational Trauma in Higher Education Institutions.” ResearchGate, 2014.

Comparative framework examining intergenerational trauma in German and South African contexts.

 **115.** Pumla Gobodo-Madikizela. _A Human Being Died That Night: A South African Woman Confronts the Legacy of Apartheid_. Boston: Houghton Mifflin, 2003.

While focused on South Africa, provides comparative framework for understanding perpetrator-victim dialogue applicable to German context.

### Memory and Embodiment

 **116.** Connerton, Paul. _How Societies Remember_. Cambridge: Cambridge University Press, 1989.

Foundational text on embodied social memory, examining how commemorative ceremonies and bodily practices transmit memory across generations.

 **117.** Ahmed, Sara. _The Cultural Politics of Emotion_. Edinburgh: Edinburgh University Press, 2004.

Examines how emotions circulate between bodies and shape social and political life, relevant for understanding shame and guilt inheritance.

 **118.** Butler, Judith. _Frames of War: When Is Life Grievable?_ London: Verso, 2009.

Examines how certain lives are framed as grievable while others are not, relevant for understanding differential memory of victims and perpetrators.

* * *

## NOTES ON SOURCE ACCESS

 **Freely Accessible Sources:**

  * Hirsch’s 2008 _Poetics Today_ article available via university repositories

  * Yehuda’s 2018 _World Psychiatry_ review: PMC6127768

  * Several _Genealogy_ articles via MDPI (Open Access)

  * Amundsen’s 2025 _Humanities_ article via MDPI (Open Access)




 **Institutional Access Required:**

  * Most journal articles via JSTOR, Project MUSE, SAGE Journals, Taylor & Francis

  * Columbia University Press, Harvard University Press, Stanford University Press titles via institutional libraries




 **German-Language Sources Without Full Translation:**

  * Welzer, _Opa war kein Nazi_ (partial excerpt in _Collective Memory Reader_ )

  * Wilke, _Die “Hilfsgemeinschaft auf Gegenseitigkeit”_ (HIAG study)

  * Giordano, _Die zweite Schuld_




* * *

## RESEARCH LIMITATIONS

  1.  **Adam Wadley’s Performance Work** : No academic documentation of a specific performance piece about “Richard Imbsweiler” was located. Adam Wadley authors “Experimental Unit” (Substack) discussing German memory, his birth in Germany, and intergenerational trauma themes, suggesting the work may be recent, unpublished, or documented in alternative formats.

  2.  **Alexander Mazey’s Parapolitical Theory** : No publications matching the specified topics were found. His documented work focuses on Baudrillardian cultural theory and aesthetics.

  3.  **Richard Imbsweiler** : No historical documentation of a Waffen SS member by this name was located in accessible databases.




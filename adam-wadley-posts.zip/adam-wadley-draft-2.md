---
title: '[Draft 2]'
subtitle: Gotta Ship!
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# [Draft 2]
I’ve been looking more into Fyodorov, and decided to combine the idea of the common Task—already elevated to common Task+ and still to be augmented further—with the Jainist idea that Karma is contained in particles.

The Jains atomist idea of Karma fits in well with Fyodorov’s idea of using science to resurrect the dead.

I was also thinking that David Bohm’s implicate order and holomovement play well with these ways of thinking.

So as you can see, this is a kind of narrative confirmation bias. I have some way that I would like to see things, and so I am finding things that agree with it.

Now, just like Dugin when it comes to somehow seeing Russia as the key space for world history, similarly I have similar ambitions in seeking to be helpful with the greatest tasks currently posed.

It is similar to the Kanye West in the sense that the magnitude of the influence operations cannot be denied, but this is simply a challenge which demands something greater to take its place and make everyone forget about it or think about it a different way.

West says disciples or rivals, I said art enemies, because rivals is perhaps too much, still, thing remain which cannot be undone but which call to be outdone.

So, when it comes to the bodaciousness or flare-ups of my expression, it’s just that I am very much seeking to intervene in concentrated or diffuse, in either case integral and integrated fashion at this terrible scale and stake of these issues.

Anyway, back to this stacking of treasures, this is also what I call treasures in heaven, these are sort of like stars which then become constellations. 

Interwoven in nests of concepts and philosophies are cultural references and memories. This is you as a hyperobject, the whole experience of being you.

I forgot to mention this in a recent take on _Experimental Unit_ as getting into perennial philosophy and discussing how national religions are also religions.

Going back to the issue of universals and also information asymmetries, “the state” or “the country” does not exist as such, but belief in this thing is cultivated. 

It’s very similar in that sense to the Olympians, who faded into nothingness when no one believed in them anymore.

Anyway, in addition to agglomerating all religious beliefs and practices as well as national myths and movements, then we look at the personal psychology and story.

Overlaps here are that in religion there are key figures who set the way and found the doctrines, or have these things built around them.

So in this way Christology is a way that people got, um, a little worked up about figuring out exactly what was going on with this one person. Talk about world-building, right?

So that the various definitions of heresy and striking things out are important moments of cultural design in terms of what would go forward as orthodox Christianity, and all the metaphysical sorts of commitments that people should be committed to.

I forgot to mention before th

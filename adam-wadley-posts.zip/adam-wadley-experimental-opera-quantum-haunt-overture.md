---
title: 'Experimental Opera: Quantum Haunt Overture'
subtitle: Deepest States Touching
author: Adam Wadley
publication: Experimental Unit
date: December 06, 2025
---

# Experimental Opera: Quantum Haunt Overture
[![](https://substackcdn.com/image/fetch/$s_!v3P0!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F15d28150-75b8-489a-94fc-e71953f6029f_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!v3P0!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F15d28150-75b8-489a-94fc-e71953f6029f_3088x2316.jpeg)

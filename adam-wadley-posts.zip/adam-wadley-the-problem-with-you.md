---
title: The Problem With You
subtitle: It's So Hard To Choose Just One
author: Adam Wadley
publication: Experimental Unit
date: April 22, 2025
---

# The Problem With You
but we all make do

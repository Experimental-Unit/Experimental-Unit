---
title: 'Operational Situational Assessment #13'
subtitle: None Dare Call It A Struggle
author: Adam Wadley
publication: Experimental Unit
date: June 17, 2025
---

# Operational Situational Assessment #13
[![Karl Ove Knausgaard on 'The Wolves of Eternity,' Fiction, Family, and Fame](https://substackcdn.com/image/fetch/$s_!jTEd!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd7647d30-8ff0-415c-bcb2-7b4329fb7188_1200x600.jpeg)](https://substackcdn.com/image/fetch/$s_!jTEd!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd7647d30-8ff0-415c-bcb2-7b4329fb7188_1200x600.jpeg)

I only learned about _Mein Kampf_ yesterday. No, not that one. [The good one](https://en.wikipedia.org/wiki/My_Struggle_\(Knausg%C3%A5rd_novels\)). (Not that I’m going to read either one, lol. Reading is for nerds like Zweibelson)

[![](https://substackcdn.com/image/fetch/$s_!YgIN!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1c5e824f-2a1a-497a-88e6-13abdd9d2cba_796x226.png)](https://substackcdn.com/image/fetch/$s_!YgIN!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1c5e824f-2a1a-497a-88e6-13abdd9d2cba_796x226.png)

 _“You call *that* a media frenzy?”_

Among other things, this has inspired me to announce that my whole project _Experimental Unit_ , in addition to being an Alternate Reality Game, also constitutes a novel. It’s a new kind of novel, maybe? A neo-novel?

I also had an exchange with my e-lover whom I met by searching for Baudrillard on OnlyFans about novels. I said the time was really over for novels, and my good [don’t call them a “lady”] disagreed, saying that the novel was more “in” than ever.

Well, let this be a further testament to my love, to call everything I’m doing and writing a novel. After all, following Knausgaard, how can you write a novel about your life if you don’t live one?

Here are the things I like so much about Knausgaard’s _Mein Kampf_ :

  1. I might as well start off by saying the title. It’s notably _not_ called “Mein Kampf” in the German translation, which I think is _fucking hilarious_. Still, titling your memoirs _Mein Kampf_ is fucking amazing. Knausgaard is really pushing the limits here.

  2. Secondly, what’s so amazing is that it’s all about revelation. It’s about being very transparent, not only about yourself and all your insecurities or whatever, but also _everyone else in your life_. They _all get wrapped up in the art_. And they all _get super pissed off_. And I’m just like, look, if you were doing your job and being a good life artist like me, and we were doing life art together, then this wouldn’t have happened to you. But _noooooooo_ , just like my dear [don’t call them a “lady”], you wanted to belieb in the fantasy of a “private life.” Well, let me kindly set your fantasies _on fucking fire_ because there’s one thing you forgot about: _my fucking genius_.

  3. It’s super long, it has a bunch of boring details in it (this is why I’m never going to read this book, lol), it’s just so self-indulgent. It’s so great. And why shouldn’t it be? People are always like oh, you don’t deserve to do this, your life isn’t interesting enough. Well, who cares? Who they fuck are you to tell me something is or isn’t interesting? What is this bullshit about “deserving” to make art? The real thing is that _everyone must create_. Even if you don’t publicize, all your actions are brushstrokes on the canvas. “God’s creation, so misunderstood.” Meet your new teacher:

  4. In the last book, _Knausgaard goes on a 400 page digression about what a sadboy Adolf Hitler was_. It’s _fucking amazing_. The only way it can get any better is if we get Kanye Omari West to do an audiobook _just of that section_. Ugh, I’m such a fountain of amazing ideas.




All these things are fucking amazing.

Note the obvious parallel between making art that implicates all your “family” and “friends” versus going on a continental rampage and committing genocide and setting the stage for our whole historical time to come.

This is the parallel drawn, between Hitler and the self.

Knausgaard apparently wrestles with the idea of whether it’s flirting with fascism for him (again, bro’s name is _Karl_ , as in _MARX_ , and here we go calling our memoir _Mein Kampf_. Put it on the list of things _you fucking love to see_ ) to do all this, apparently Karl questions liberal democracy at one point— _ohh noo_

[![Sarcastically surprised Kirk Meme Generator - Piñata Farms - The best meme  generator and meme maker for video & image memes](https://substackcdn.com/image/fetch/$s_!h5mj!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8bea4ce8-129e-4444-a8ea-f2e7c844b27c_487x274.jpeg)](https://substackcdn.com/image/fetch/$s_!h5mj!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8bea4ce8-129e-4444-a8ea-f2e7c844b27c_487x274.jpeg)

On top of which, again here we go with the “white man” motif. This is something I’m really trying to play up here.

The point is that the figure and symbolic position of the “white man” has absolutely been teed up _for me to take a swing and knock it out of the mother freaking park_. 

[![](https://substackcdn.com/image/fetch/$s_!s_id!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2c83bee3-da56-4f36-870e-4119ec23e4d8_1189x515.png)](https://substackcdn.com/image/fetch/$s_!s_id!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2c83bee3-da56-4f36-870e-4119ec23e4d8_1189x515.png)

[Tell me, darling, ](https://www.youtube.com/watch?v=yrxRCTUt6OY)_[what are Aaron Eckhart’s initials](https://www.youtube.com/watch?v=yrxRCTUt6OY)_[?](https://www.youtube.com/watch?v=yrxRCTUt6OY)

I started writing about this on the first draft, but I didn’t like the way it went.

Basically, I was saying that there is this dual-pressure, which is has been going on for ages but no one is apparently ready to square the circle or cut the Gordian knot except for me, so here we go. 

Don’t forget that. in my own estimation, I am not “white” nor “a man.” Crucially, this is not in the sense that other people are “white,” but I am not. No, it’s just that no one is white, and there are no males nor females. A big aspect of my whole shtick here is that all of your status function declarations are not serious. As Abraham Lincoln said, calling a tail a leg doesn’t make it so. Of course, following my logic, there really aren’t tails or legs either (did you know that in German _Schwanz_ means tail and is slang for penis? “What’s a penis dude?” The concept of “penis”? “[What do you need that for, dude?](https://www.reddit.com/r/lebowski/comments/anskq8/what_do_you_need_that_for_dude/)”)

So anyway, here are the two broad camps (camps):

You obviously have people who are triumphalist about “the white man,” the sorts of national chauvinists. The kinds of people who talk about how Britain muh abolished slavery, and America is so great and so on. This then gets into being macho, which is really present on “the other side” as well, since machismo has everything to do with facing structural humiliation. 

But the “bros” who embrace “white masculinity” and don’t want to engage with the critical perspectives openly as so on, these people are not able to acknowledge their humiliation. Which ultimately, in my eyes, makes them cowards.

These are also the sort of people who think it matters to have sex, or make money, all these “metrics” of success which show nothing but conformity and not being able to think for yourself, which is ironically the opposite of what a “manly man” should do. They are ultimately in deep denial about their love of conformity, which is why I say that chuds are just sluts in denial. Sluts, after all, love to be fucked. Chuds just hate to admit it.

The “other side” are also chuds in their own way.

This is the people who want to be “critical,” the people whose stance is basically _but you’re a fucking white male_. The people who are so aghast about European colonialism, who are not able to wrap their minds around the idea that all this disruption and conquest shit is really just part of the game.

There’s no use crying to the refs, the point is to _git gud_.

It’s also very in denial over here, because these are also the sorts of people who will talk about muh human rights or something, not realizing that this stuff was also cooked up by “white men.” So you have a bunch of people using the intellectual legacy of “white men” and then trying to distance themselves from “white men,” it’s pretty embarrassing.

The other problem with the “critical” perspective is that these people don’t really want to be “in power.” They will bully people, weaponize shame and guilt and so on, in order to have some tactical advantage. But when it comes to sitting at the “big boy” table, really putting your pants on and taking responsibility for how things are going to go, nope. In other words, when it comes to the showdown, _they won’t be there_.

Good examples here are Afropessimism and feminism. Feminism is all about the category “woman,” when determinate categories are phallogocentric. Same problem with blackness in Afropessimism. These discourses code extremely “male” and “white,” even though they want to be “woman” and “black.”

Of course, people will have extensive arguments against me, and they’ll involve Heidegger or some other dead white male as part of the intellectual genealogy of their arguments.

The point is that in my estimation, you’ve got to be willing to run what I call figurative language protocol, which is basically to be rejecting this idea that things are clear. This fetishism of clarity and drawing clear lines, and distancing yourself from what is “bad,” this is a giant fool’s errand and n00b trap.

At the same time, while it’s nice to be wishy-washy and not get pinned down (which is not the same as avoiding being fucked—you’re never running away from that trouble, lol), at the same time you’ve got to stand there and basically take responsibility _for all creation_.

This is where the “tough guy” pose of being strong for a “family” or a “nation” or some other strict subset, it’s actually pathetic and inadequate. It can never succeed because the intellectual foundations are bankrupt.

Because what you’re shirking (see Shirk in Islam) is responsibility for the container for your erotic fantasy.

So like in my “immediate family,” my “dad” has some fantasy that we are all so happy and get along or whatever, meanwhile that _has literally never been true ever lol in large part because bro throws hissy fits and shits judgments no one gives a fuck about 24/7_.

Meanwhile, I’m sitting here like, “parents,” what are you doing about the structural position of the planetary emergency? What are you doing to prevent my death in a nuclear war? 

And all they have to say is “nothing.” It’s the same shit of well, no one can do anything about that.

Okay, sounds like _dickless piece of shit_ talk to me.

On the other hand, this “critical” side, where we’re supposed to be tearing shit down and being all nice and all, you have two problems:

  1. Adherence to Marxist rhetoric, which is super ironic because muh dead white man apparently doesn’t apply to Bad Karl (making all these people mother freaking _Bride Of Chucky_ over here.




[![Bride of Chucky \(1998\) - IMDb](https://substackcdn.com/image/fetch/$s_!EO2D!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F143a0c4a-7142-411d-a331-b6859216450a_1000x1487.jpeg)](https://substackcdn.com/image/fetch/$s_!EO2D!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F143a0c4a-7142-411d-a331-b6859216450a_1000x1487.jpeg)

 _never go full “bride of Chucky,” bro_

  2. Basically these people still want to scapegoat “white men” or some other group, instead of understanding that scapegoating itself is super wack and must be ruthlessly interrogated.




The “critical perspective” people will also take systemic/imperial/normative discourses for granted and also continue to mobilize normative (White in the sense of “the white terror”) discourses themselves.

So think about the type of political porn where it shows how the people are protesting in the street against “colonizers,” and then in the next panel they’re catching BWC and loving it. This BWC basically stands in for the normative discourses they can only invert, which of course remains normative.

Meanwhile, just the same way that you’ll have muh “sympathy for terrorists” discourse among the first side, the national chauvinist side (as though the greatest minds of our generation haven’t been shooting up schools for decades—note that this is not me saying kinetic attacks are something to do, just that the n00b trap of terrorism is actually a pretty advanced n00b trap once you have assumed this position of strictly structurally relegated entity who is still of the “dominant” social position hence deprived of validation of one’s victimization or such relegation), 

the same way you will have the “critical side” starting to sound like insufferable neoliberals or whatever the fudge as soon as it’s a “white man” who’s complaining.

At that point, it’s all about muh individual responsibility, which is again _a white man’s discourse_.

Now, the problem is that people considered “white men” will usually complain in a stupid way. No doubt about that.

# King Of The Morons

[![Adolf Hitler Memes - Imgflip](https://substackcdn.com/image/fetch/$s_!t4rv!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F15930e8e-5592-483d-9f77-5a63e6ea9d0e_500x604.jpeg)](https://substackcdn.com/image/fetch/$s_!t4rv!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F15930e8e-5592-483d-9f77-5a63e6ea9d0e_500x604.jpeg)

Now, Adolf had a special word for “white guy” called Aryan, but it’s basically the same thing.

See here, the weak move is to claim that you are being held back due to some modernist category like your “nation” or your “race.”

As opposed to this, it is more advanced to say that maybe people see you as some determinate category, but what’s being oppressed or whatever is not you as _really being_ that category, but the sense in which _you are not that category_.

So like, I’m not an “incel” in the sense that I am actually not mad about the fact that I’m not “having sex.” I’m not even trying to get laid, my issue is that _everyone is literally unfuckable_.

But, more to the point, my issue in general is not that I’m discriminated against because I’m a “man,” or because I am “white,” but because _I am not these things_ yet “you people” think that I am, and so all my communications are over-coded with this context.

So let’s go back to Karl Ove Knausgaard. 

Karl’s worried that oh no, what if I seem fascist. 

Meanwhile, Karl is worried about immigration or something? Or is going to bat for some “right wing” party as though that’s something to do?

Like, Karl, yup, that’s fucking “fascist,” or whatever you mean by that.

But again, let’s look at the homologies between Nazism or any sort of “white” identity politics and all these “national liberation” sorts of ideas you find on the “critical” side.

The fantasy of Nazism or something like that is that sure, you might seem like a “powerful group” of “white guys,” but really you got cucked in some devilish way, you got fucking _cheated_.

We actually have here a nice homology again to Marxism, which is basically this cult of people talking about “productive labor” as though anything that’s not manual labor or shitting out some product doesn’t count. It’s this total discounting of intellectual labor and effort.

Similarly with “white” fantasies that someone else is getting over on you, finance people of some kind, basically. Call it city of London, call it Jews, it really doesn’t matter. 

The point is that people used to be able to have land or own a factory or whatever and that was when people were “real men.” Meanwhile, all this _fucking nerd shit_ of doing accounting and reading books and doing hermeneutics and generating narrative mazes to spread to simple-minded people is basically _not fair and I’M CALLING MOM_.

The reason this is stupid is that _the fucking nerd shit_ actually supervenes over the macho _Pumping Iron_ whatever bullshit.

You can look at it like the thing where there’s the tough dudes in the primate troupe, but then they have to go fight or whatever. And here comes the crafty boys to impregnate the lady apes while all the meatheads are beating each other over the head.

 _This is not about sexual reproduction_.

EVERYONE has this feature of being able to be impregnated, and EVERYONE has this capacity to impregnate others. It’s called the transsexuality of the mind, look it up (actually I invented that I think so maybe that won’t work. Ask ChatGPT about it).

A corollary here is that of course “men” can get pregnant.

Look at Talcott Parsons, calling each new generation of kids an invasion of barbarians.

Children are _forcibly socialized_. In this sense, _ALL SEX 2 IS RAPE_ in the sense that it’s really not possible to do consensually. You can’t ask a child whether it would like to learn a language. They don’t even know what you’re saying!

Meanwhile, all these “manly men,” all these fucking “Germans,” why do they even think they are “men”? Or “Germans”?

Did you know that there has to be “nation-building”? Back in the day all these people had to be convinced that they were part of this thing, which is basically influence operations.

Influence = flowing in, like “cum” flowing into a “uterus.”

It’s the same point Baudrillard is making about how feminism is super cucked because wanting to be “emancipated” as a “woman” is already to be giving in to the idea that you “are” a “woman,” which Baudrillard is saying is basically a framing that dudes put on you.

But meanwhile, the same is true of “dudes” AKA “men.”

So usually, people considered “white men” will complain because they are really low on the totem pole. Just because you’re a paleface and have a “penis” doesn’t mean you made anything on the planet be the way it is. Plenty of people like that commit suicide.

This is again to loop back around to shit with my “immediate family.” It’s like, people would look at me and think I am so off the reservation, I am doing so badly. It’s like bro, y’all have actually been so cruel to me my whole life that I could easily have committed suicide a long time ago. It’s seriously crazy how wack it is.

Anyways, in my opinion what is weak sauce is this again pretending that the people who “have it good” actually have it good just because they say so.

In other words, to be complaining because you’re not in the great position people imagine you to be in, but that you imagine other people to be in. I’m not a fortunate son, I’m not Chad, I don’t have it all the way other people do.

This is again a form of conformity because it’s to again be too impressed with metrics and conformist standards of what it means to have “success.”

# You Gotta See The Big Picture Here

To the extent we’re gonna sit here and care about worldly affairs, it’s easy to see that everyone’s life is in danger.

There’s a couple aspects here, at least.

  1. The sheer crushing weight of the forces pushing against each other. This is again the very “male” coded social forces, although you could code it “female” as well. Think of it like this: two dudes pressing dicks together so much because the pressure hurts so good, this is basically what “Iran” and “Israel” are doing to each other right now, this is the “hardness” of the military “instrument” which refuses to “yield.” On the other hand, you could also think about it like a pair of breasts which are coming and smothering you to the point that you are actually suffocating and dying. 

In each case, what you have is that the so much-ness of this structure of force is yielding a situation where everyone can die. This is the nuclear war, this is the drones plus AI, this is bioweapons. In this case, defeating the opponent yields _more_ danger, because for a while people are fighting like there are some stakes, they don’t want to go all-out because maybe there’s something to be gained by holding back. But eventually, it’s obvious that no, you’re really just gonna kill them all dead, and at that point a bunch of pocket sand comes out that maybe you didn’t plan for.

  2. The other issue is basically falling prey to the advance of simulation. This is again going back to that _fucking nerd shit_ that people want to think _is fucking cheating_ because they want it to be the case that the things they understand are actually the most important and they want to not only be validated like it’s okay that they do what they do, but they also want to lionize it and make the whole planet a museum to their special form of dicking around _forever and ever and ever._

[![The Shining – "Come play with us, Danny" | ACMI: Your museum of screen  culture](https://substackcdn.com/image/fetch/$s_!Qhkq!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb880f7f0-d3ca-4db5-828d-22169be3f492_1280x720.jpeg)](https://substackcdn.com/image/fetch/$s_!Qhkq!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb880f7f0-d3ca-4db5-828d-22169be3f492_1280x720.jpeg)




 _forever_

In other words, the immediate threat is not that you’re going to go up the escalation ladder and push the button and oops, that’s all it, and now the incentives change to where people can no longer hope for survival but only revenge, and that’s when you really see.

No, the issue is that even as the person who is manipulating narratives and so on, _you can still yourself be manipulated by superior forms of simulation_. 

So think of how many people there are who are so concerned about “being attractive,” and are so put out because they can’t “get laid” or “date.” _What a fucking joke_.

Because meanwhile, we’re like all gonna die in a nuclear war or something. Dating really doesn’t matter at all.

The question of whether anyone will be alive in 5 or 50 years _has nothing to do with how many children will be born or whether any of them are yours_.

This is also personal for me, this time with my cousins. My “sibling” had the sense to not have kids, but then the rest of my cousins (that didn’t die of a drug overdose—talk about another failure metric of success, sorry, am I such a failure? Um, _I’m still alive_. But still, it shows you the depth _of rot_ which there is in our “family,” not to mention Alligator Al(who _Deliverance is fucking dedicated to, by the way_ )’s kid Beau fucking killing themselves in the 70s. Did we ever process that shit? _Fuck No_. It’s a bunch of “Man Up” (which has nothing to do with having a dick, either way it’s a form of being _a dickless piece of shit_ ) until _you fucking die_ ) just sat around and started shitting out kids.

Which is fine, look it’s great, but the thing is _what are you doing to help your kids survive the planetary situation_?

The idea that “it’s not your responsibility” or that “you can’t do anything” is such weak sauce.

But I’m not just talking about my cousins. I’m talking about Donald John Trump or Tim Watts the CIA PSYOP bro or whoever “on the inside.” What are you motivated by? Racking up billions of dollars? Gonna get _promoted_?

This is basically more chasing ribbons, it’s to be distracted by some “socially accepted” model of “success” and meanwhile, you _could be getting fucking gamed_. And even if you know you’re not really “in charge,” you’re at least thinking that if _you are a good enough slave_ that you’re gonna be kept around as a pet.

 _Why would anyone keep you around, though_?

And why wouldn’t that answer apply to all the people you’re just letting get incinerated on a day-to-day basis?

It’s this level of denial that things are coming to a head that I just fundamentally cannot respect. At that point, my plan is to wrap you into my world-building and leave you to sort out the implications, and this is the heavy sword for you to train with that will leave you, in the end, capable of doing things you don’t, at present, think are attainable.

The bro side is just in denial, it’s a cargo cult where you think we basically got there, we already conquered the world, and now you just have to not feel bad about it. Yeah, uh, no. You’re a cog in a machine that’s going over a cliff if you don’t _get your fucking game face on_.

And the “critical” side, you’re in denial because you think you’re not going to have to climb the mountain and not just complain to the refs, but _become the refs_. And then you’re gonna see how hard it really is, once you can’t just take the occulted center for granted but have to run that shit, feel the pressure of it, feel the gravity of your actions and know that there’s no one higher on any totem pole to bail you out, or that you can blame. No one’s buying that shit.

That’s the point where it is really about _Dein Kampf._ The same way people sit there and think about Hitler’s years in Vienna, every homeless night this crucible where at any point you could have gotten knocked off the path of disaster, but you didn’t. The gravity of what Napoleon _was fucking thinking_ before invading “Russia.”

That’s the weight on _your noggin_ , right now. _You matter_ , you are _freaking indispensible_. I only care about one thing, Neo, and that’s the future.

And I know the only way there is _together_.

That means _all of us_.

Welcome to _Unser Kampf_.

This is the shit where you have to see that Adolf, Vladimir, Bibi, Donald, JK, Marjorie, Greta, whoever it is you think is so awful, so cringe, whatever: _that’s you_. It really is you. That’s your future best friend right there.

And again, to my family: I am posing as “so bad” because you _really don’t fucking get it_. This little playing house and playing happy family, that might convince or placate or impress some other small-minded people, but I’m not freaking having it!

I am calling you to a greater game the only one that can actually protect your children, protect your inner child and put them on the path to flourishing. Maybe you gave up on that, maybe you gave up on yourself. Your _whole_ self.

You have heard it said, that the time had come to put away childish things.

[But verily, I say to you, unless you are converted and become as little children, you will by no means enter the kingdom of heaven.](https://en.wikipedia.org/wiki/Shoshin)

My message for the “great people” and “powerful people” is just the same: you are chasing false goals. You are refusing to let go of the nuts inside the jar and it’s going to be the death of you.

As this continues, we are basically going to see how the real work is in building together eschatologies and various people’s “dreams” so that they can really work together. This might seem impossible, but you’re forgetting how duplicitous you are, and how much of yourself you’re always leaving on the shelf because it doesn’t seem “practical.”

How much better to go ahead and have the blowout fight, confront the nausea of what you’ve been told it is that God wants from you, or some other crushing expectations, and realize that this nausea, this is _your baby_.

Don’t feed your inner child to your inner Cronos. 

It’s time to play Black Ops.

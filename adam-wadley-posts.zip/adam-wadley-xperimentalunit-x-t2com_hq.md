---
title: '@XperimentalUnit x @T2COM_HQ'
subtitle: 'Operation Orange October Communique #1'
author: Adam Wadley
publication: Experimental Unit
date: October 02, 2025
---

# @XperimentalUnit x @T2COM_HQ
[![](https://substackcdn.com/image/fetch/$s_!ZAVE!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0b93aacd-023d-489c-ac0b-3ac782e860f0_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!ZAVE!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0b93aacd-023d-489c-ac0b-3ac782e860f0_3088x2316.jpeg)

For the past two days, I’ve come down here to 7th Street in Austin, Texas to sit next to the headquarters for the new “United States of America Army Transformation And Training Command.”

This course of events is to be read in the context of my previous posts, which were related to the theme of political “performance art” as it bleeds into sometimes very destructive activities.

A guiding question: how can we facilitate and accelerate the killing of “sacred cows” (reference to Hinduism by way of [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) is advised in context of my previous treatment of “Lila” concept) while drawing down the use of “kinetic force” as well as malicious influence operations?

Note that this is a core theme of my 2018 Baudrillard conference paper “[Transcommunism in the Transpolitical Age](https://dn720002.ca.archive.org/0/items/wadley.-2019.-the-metonymy-economy/Wadley.2018.Transcommunism-in-the-Transpolitical-Age.pdf).” This was also a form of “Doing It IRL,” and I was just as nervous and timid then! Anyway, in that paper it’s all about how “death” is this looming figure. Baudrillard emphasizes that the radicality of “death” is not in biological process, but in radical indeterminacy.

Compare to this quote [cited by Ofra Graicer](https://jmss.org/article/view/58253/pdf): “one must die to himself to forget what is known.”

[![](https://substackcdn.com/image/fetch/$s_!26p_!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7795289b-6b95-47ac-b684-60abb05492b7_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!26p_!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7795289b-6b95-47ac-b684-60abb05492b7_4032x3024.jpeg)

I’ve just been approached for the second time today by someone in a police uniform who exited the building to talk to me about why I am here. I’m not very straightforward with them, although it’s a bit hard to put “what I’m doing here” in a nutshell. Heck, I’ve been struggling to write about it in long form!

Yet this is part of my performance. Part of it is that I’m not sure what I’m doing. It’s about being willing to face some risk while being resolved to be as harmless as possible.

It’s in this context that we can look at the comparison to a Greta Thunberg, a Phoebe Plummer, and for that matter even make the comparisons to those who employ “kinetic force.” I would like to hasten to stress that I have to my knowledge no malicious intent.

Yet again, it’s a sort of play with this. How could anyone know my intentions?

The person in police uniform told me that what I’m doing is “not normal.” Yet they went to say that “there’s no law that says you have to be normal.”

For now! Standard questions about whether I’m employed/in school.

Note that in 2020 I was at the Central Intelligence Agency headquarters and spoke to the campus police there.

At that time I was trying to draw their attention to my essay “[The Metonymy Economy](https://dn720002.ca.archive.org/0/items/wadley.-2019.-the-metonymy-economy/Wadley.2019.The-Metonymy-Economy.pdf),” which builds on Baudrillard’s idea of implosion and metonymy.

Back to the comparison. So notice that of course I am not engaging in any “kinetic” activity or threatening behavior. In comparison to the Van Gogh soup activity, I am not making a lasting mess. In this regard, my “move” here is to use stickers to add my own signs to those I capture (See above).

[![](https://substackcdn.com/image/fetch/$s_!r37g!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4aee1416-666b-43dc-86cd-fb8e3086e0a4_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!r37g!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4aee1416-666b-43dc-86cd-fb8e3086e0a4_4032x3024.jpeg)

Today I also went to Comedy Mothership.

I was also yesterday at Capital Factory.

[![](https://substackcdn.com/image/fetch/$s_!mBz-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F49dccfdd-f441-4d49-85c9-1f04d495412e_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!mBz-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F49dccfdd-f441-4d49-85c9-1f04d495412e_4032x3024.jpeg)

So notice in my “target” selection (“target” is such an ugly word…) I am going for the Transformation and Training Command, Capital Factory, and Comedy Mothership.

These are the places I’m addressing myself to, and tying together through the association. Comedy Mothership is a thematic connection to the stand-up comedy circuit, which has become a major vector of cultural influence.

Yet, even though I’m not really doing that much, it makes sense to me that my behavior is considered out of the ordinary, and could evoke some concern. Again, I’d like to assuage those concerns.

Yet still, it’s this “warped play” with uncertainty that I’m engaging in.

[![](https://substackcdn.com/image/fetch/$s_!U7P4!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5c0b885b-56f7-48d5-b8f2-0eba72ec707d_1536x1024.png)](https://substackcdn.com/image/fetch/$s_!U7P4!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5c0b885b-56f7-48d5-b8f2-0eba72ec707d_1536x1024.png)

I’ve been using these actions as a means of pushing through some of my long-standing references and ideas.

Grimes as an artist continues to be very relevant, and is also on SubStack [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions) hi Claire. The acronyms stand for “Conceptual Systems-of-Systems Impregnation Emergency Response Operational Art,” “Permanent Hardcore Dachau Highway Nihilist Blues,” and “Zeitgeist Weltschmerz Gesamtkunstwerk Blitzkrieg.”

You can read more about them already in the archives and in [the Twitter posting](https://x.com/XperimentalUnit) I have been doing. I didn’t have the heart to tell the person in the police uniform to check their Twitter mentions :(

The other acronyms listed above will require some more explanation at a different time. This writing will serve to break the block I’ve been on recently. I’m sure much will be restated, but it will be good to get something out there.

[![](https://substackcdn.com/image/fetch/$s_!RQWP!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F77887965-f374-447c-beba-b5abc202a4dc_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!RQWP!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F77887965-f374-447c-beba-b5abc202a4dc_3088x2316.jpeg)

I’ve also been attending a Unitarian Universalist church, and I’ll be going there tonight for what is called CHAOS night funnily enough.

See picture taken yesterday before choir practice referencing Beloved Community, which was also a featured theme of my 6/22 sermon.

“Universalism” is another featured topic, looking at non-zero-sum eschatology while using scare quotes to emphasize the ineffable and that what is being discussed is really beyond “number.” (See my appreciation for Anaximander).

[![](https://substackcdn.com/image/fetch/$s_!ngEC!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa6ba65ad-74d4-4589-930f-03f581d97923_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!ngEC!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa6ba65ad-74d4-4589-930f-03f581d97923_3088x2316.jpeg)

We also have IRL crossover as I mention “dissolving the problem of war,” which is a double reference to [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions), in this “Living Love” sticker wall at the church. 

[![](https://substackcdn.com/image/fetch/$s_!OFA8!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffe347c32-890e-42e1-be02-77a5cb7ffe23_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!OFA8!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffe347c32-890e-42e1-be02-77a5cb7ffe23_3088x2316.jpeg)

See also me here posing yesterday with my stickers saying “@XperimentalUnit x @T2COM_HQ” along with a painting made for me by an important online friend. We have since had a falling out, but they introduced me to this song, which crucially features the line “repent.”

I also featured my Opa’s Waffen-SS dogtag in this photo, NOT because I endorse any form of scapegoating or kinetic force, but because for me this is a working through of deep theological themes like theodicy. Why are “bad things” apparently part of “the plan”?

This is beyond one interpretation of cosmology and my considerations bring in many cosmological principles, from Logos to Wakan Tanka to Silap Inua.

I’ll continue to elaborate on my ideas and intentions here, but for now this will have to do!

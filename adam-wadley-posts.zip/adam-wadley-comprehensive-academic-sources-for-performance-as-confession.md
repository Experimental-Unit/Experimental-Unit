---
title: Comprehensive Academic Sources for “Performance as Confession
subtitle: Adam Wadley’s Intergenerational Witnessing and the Stakes of Vulnerability
  in Contemporary Activism”
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# Comprehensive Academic Sources for “Performance as Confession
This research compendium provides **rigorously sourced academic materials** across ten theoretical domains to support a substantial scholarly introduction essay on Adam Wadley’s performance art. The sources span performance studies, trauma theory, philosophy, literary criticism, institutional critique, and contemporary activism studies, with full bibliographic citations and accessible digital resources where available.

* * *

## Performance’s constitutive vulnerability in Peggy Phelan’s theorization

Peggy Phelan’s foundational text _Unmarked: The Politics of Performance_ (Routledge, 1993; ISBN: 978-0415068222) establishes the ontological framework essential for understanding performance as inherently tied to disappearance, vulnerability, and resistance to reproduction. Her central argument holds that “performance’s only life is in the present” and that it “becomes itself through disappearance” (p. 146). This constitutive ephemerality positions performance outside commodity circulation and reproduction—a politically resistant mode that remains “unmarked” by the visual economy.

Her subsequent _Mourning Sex: Performing Public Memories_ (Routledge, 1997; ISBN: 978-0415147590) extends this analysis through what she calls “the exhilaration and the catastrophe of embodiment,” examining injured bodies as sites where trauma’s affective force yields critical insight. [Amazon](https://www.amazon.com/Mourning-Sex-Performing-Public-Memories/dp/041514759X) The text advocates for **performative writing** that deliberately fuses critical and creative discourse while mixing fictional personae with scholarly analysis— [Barnes & Noble](https://www.barnesandnoble.com/w/mourning-sex-peggy-phelan/1128400038)a methodology relevant to artistic statements accompanying performance work. [Project MUSE](https://muse.jhu.edu/article/34549/summary)

 **Rebecca Schneider’s** _Performing Remains: Art and War in Times of Theatrical Reenactment_ (Routledge, 2011; ISBN: 978-0-415-40442-6) offers a crucial dialectical response, arguing that performance “remains, but remains differently” through bodily traces and reenactment. [SciELO Brazil](https://www.scielo.br/scielo.php?pid=S2237-26602017000300551&script=sci_arttext&tlng=en) Where Phelan locates political resistance in disappearance, Schneider proposes the body itself serves as archival repository, challenging “the pristine ideality of all things marked ‘original’” through “messy and eruptive reappearance.” [josh armstrong](http://josharmstrong.eu/rebecca-schneider%E2%80%99s-%E2%80%9Carchives-performance-remains%E2%80%9D/) Her concept of **“syncopated time”** troubles linear temporality, enabling performance’s “queer time, where time can be understood as ‘full of holes or gaps.’” [Hemispheric Institute](https://hemisphericinstitute.org/en/emisferica-81/8-1-book-reviews/performing-remains-art-and-war-in-times-of-theatrical-reenactment-by-rebecca-schneider.html)

 **Amelia Jones’s** _Body Art/Performing the Subject_ (University of Minnesota Press, 1998; ISBN: 978-0816627738) provides phenomenological grounding, defining body art as “a set of performative practices that, through such intersubjective engagement, instantiate the dislocation or decentering of the Cartesian subject of modernism.” Her article “Presence in Absentia: Experiencing Performance as Documentation” ( _Art Journal_ 56, no. 4, Winter 1997) argues that “there is no possibility of an unmediated relationship to any kind of cultural product,” offering a more accepting approach to performance’s documentation. [Wordpress](https://performancestudies101.wordpress.com/category/ontology-of-performance/)

 **Philip Auslander’s** _Liveness: Performance in a Mediatized Culture_ (Routledge, 1999/2008/2021; ISBN: 978-0-367-46817-0) extends this debate, arguing that “historically, the live is actually an effect of mediatization, not the other way around”—liveness itself is produced by its opposition to the mediated.

 **Key accessible PDFs:**

  * Phelan, “Ontology of Performance”: <https://courses.lsa.umich.edu/jptw/wp-content/uploads/sites/23/2017/08/Phelan-Unmarked-OntologyofPerformanceAfterword.pdf>

  * Jones, _Body Art_ Introduction: <https://monoskop.org/images/e/ef/Jones_Amelia_Body_Art_Performing_the_Subject_1998_Introduction_Chapter1.pdf>




* * *

## Butler’s precarious life and bodily vulnerability

Judith Butler’s political philosophy provides the ethical and ontological framework for understanding vulnerability as constitutive of human relationality rather than as weakness to be overcome. **Precarious Life: The Powers of Mourning and Violence** (Verso, 2004; ISBN: 9781788738613) establishes **precariousness** as the shared existential condition of all life—” [Amazon](https://www.amazon.de/Precarious-Life-Power-Mourning-Violence/dp/1844670058)all lives are vulnerable and dependent on others for survival”—while distinguishing it from **precarity** , the politically induced condition in which certain populations suffer from failing support networks and become differentially exposed to violence. [USAPP](https://blogs.lse.ac.uk/lsereviewofbooks/2016/02/09/book-review-notes-toward-a-performative-theory-of-assembly-by-judith-butler/)

Her concept of **grievability** determines which lives are recognized as worthy of mourning and which are cast as “ungrievable” or already lost. Drawing on Emmanuel Levinas, Butler positions “the face” as the site of ethical demand [Sage Journals](https://journals.sagepub.com/doi/10.1177/09697330241257569) that “presents the extreme precariousness of the Other.” [Cuni](https://dl1.cuni.cz/pluginfile.php/741554/mod_folder/content/0/Butler%20\(Precarious%20Life\).pdf) The process of **derealization** describes how certain populations are dehumanized and rendered unrecognizable as living beings—crucial for understanding how activist bodies become visible or invisible to publics.

 **Frames of War: When Is Life Grievable?** (Verso, 2009; ISBN: 9781844676279) extends this analysis through the concept of **framing** —interpretative structures that regulate recognition. Frames “mould those lives that are recognised as liveable, and hence grievable, and they order our affective responses to others.” [ResearchGate](https://www.researchgate.net/publication/269760426_Judith_Butler_Frames_of_War_When_Is_Life_Grievable) The body emerges as site of political vulnerability, “exposed to socially and politically articulated forces as well as to claims of sociality.” Her analysis of Abu Ghraib photographs demonstrates how visual framing constitutes war violence and dehumanization. [Uu](https://perpetratorstudies.sites.uu.nl/bibliography/butler-judith-frames-of-war-when-is-life-grievable-20240502/)

 **Notes Toward a Performative Theory of Assembly** (Harvard University Press, 2015; ISBN: 9780674983984) connects vulnerability directly to public assembly and theatrical politics. Butler argues that “part of what a body is... is its dependency on other bodies and networks of support” (p. 30). [Project MUSE](https://muse.jhu.edu/article/666621/summary) Assembled bodies gesture toward what Arendt called “the right to have rights”—the right to appear as political subjects. [USAPP](https://blogs.lse.ac.uk/lsereviewofbooks/2016/02/09/book-review-notes-toward-a-performative-theory-of-assembly-by-judith-butler/) Theatre and theatrical self-constitution create “performative clarity as action,” with protests functioning as performative political acts. [Critical Inquiry](https://criticalinquiry.uchicago.edu/hana_worthen_reviews_notes_toward_a_performative_theory_of_assembly/)

 **Related philosophical sources:**

  *  **Adriana Cavarero** , _Horrorism: Naming Contemporary Violence_ (Columbia University Press, 2009; ISBN: 9780231144575): Develops **horrorism** as violence against the vulnerable viewed from the victim’s perspective; establishes “constitutive vulnerability” as characterizing “the ontological status of humans.” [Journal-redescriptions](https://journal-redescriptions.org/articles/10.33134/rds.342)[Wikipedia](https://en.wikipedia.org/wiki/Adriana_Cavarero)

  *  **Kelly Oliver** , _Witnessing: Beyond Recognition_ (University of Minnesota Press, 2001; ISBN: 9780816636280): Proposes **witnessing** over Hegelian recognition, emphasizing **response-ability** and the double meaning of witnessing (eyewitness/bearing witness).

  *  **Emmanuel Levinas** , _Totality and Infinity_ (Duquesne University Press, 1969): Butler’s source for the face as site of ethical demand and asymmetrical responsibility.




 **Key accessible PDFs:**

  * Butler, “Performativity, Precarity and Sexual Politics” (2009): <https://www.aibr.org/antropologia/04v03/criticos/040301b.pdf>

  * _Precarious Life_ excerpt: <http://faculty.washington.edu/mpurcell/butler-precarious_life.pdf>




* * *

## The confessional tradition from Ginsberg through contemporary autofiction

The confessional poetry tradition provides essential literary-historical context for understanding performance as self-disclosure and public testimony. **M.L. Rosenthal** coined the term in his review “Poetry as Confession” ( _The Nation_ , September 19, 1959), describing Robert Lowell’s _Life Studies_ as removing “the mask”—”his speaker is unequivocally himself, and it is hard not to think of _Life Studies_ as a series of personal confidences, rather shameful, that one is honor-bound not to reveal.” [Wikipedia](https://en.wikipedia.org/wiki/Confessional_poetry)

 **Allen Ginsberg’s** _Howl and Other Poems_ (City Lights, 1956) operates as political confession and prophetic witness, its speaker “speechless and intelligent and shaking with shame, rejected yet confessing out the soul.” [The Poetry Foundation](https://www.poetryfoundation.org/poems/49303/howl) Critics identify a productive tension “between Ginsberg as confessional poet and Ginsberg as religious seeker—or religious prophet.” [Maps-legacy](http://maps-legacy.org/poets/g_l/ginsberg/howl.htm) The 1957 obscenity trial established the poem’s “social importance,” with expert witnesses defending its literary merit.

 **Critical monographs on confessional poetry:**

  * Robert Phillips, _The Confessional Poets_ (Southern Illinois University Press, 1973)—first book-length study

  * Jo Gill, _Anne Sexton’s Confessional Poetics_ (University Press of Florida, 2007)

  * Jo Gill, ed., _The Cambridge Companion to Sylvia Plath_ (Cambridge University Press, 2006)

  * Jacqueline Rose, _The Haunting of Sylvia Plath_ (Harvard University Press, 1992)

  *  **Christopher Grobe** , _The Art of Confession: The Performance of Self from Robert Lowell to Reality TV_ (NYU Press, 2017)—major contemporary study arguing confession is “always on the move between media”; traces confessionalism from 1950s poetry through performance art and reality television [Christopher Grobe +2](http://www.cgrobe.com/books)




 **Theoretical frameworks for confession:**

  *  **Michel Foucault** , _The History of Sexuality, Volume 1: The Will to Knowledge_ (Pantheon, 1978): “Western man has become a confessing animal”—confession moved from religious context to medicine, psychiatry, and self-knowledge; confession produces the “truth” of the self rather than simply revealing it

  *  **Peter Brooks** , _Troubling Confessions: Speaking Guilt in Law and Literature_ (University of Chicago Press, 2000): Confession as “one of the most complex and obscure forms of human speech”; Western culture makes “confessional speech a prime measure of authenticity”




 **Contemporary extensions:**

  *  **Autofiction** : Serge Doubrovsky coined the term in 1977 for _Fils_ —”fiction of events and facts strictly real” distinguished by “the adventure of language” [Literary Hub](https://lithub.com/true-confessions-of-an-auto-fictionist/)

  *  **Claudia Rankine** , _Citizen: An American Lyric_ (Graywolf Press, 2014): Hybrid form creating “poetics of uncomfortable encounter,” repositioning reader while demonstrating failures of address; [Claudiarankine](https://claudiarankine.com/book/citizen-an-american-lyric/) “a dazzling expression of the painful double consciousness of black life in America” [Claudiarankine](https://claudiarankine.com/book/citizen-an-american-lyric/)

  *  **“New Sincerity”** : Contemporary poetry movement responding to David Foster Wallace’s prediction of “anti-rebels” who would “risk the yawn, the rolled eyes” by treating “old untrendy human troubles and emotions... with reverence and conviction” [Wikipedia](https://en.wikipedia.org/wiki/New_sincerity)




* * *

## Just Stop Oil, Phoebe Plummer, and activist visibility

 **The Van Gogh Sunflowers protest** (October 14, 2022) exemplifies contemporary activist visibility and its institutional criminalization. **Phoebe Plummer** (then 21, London; they/them pronouns) and Anna Holland threw Heinz Cream of Tomato soup at Vincent van Gogh’s _Sunflowers_ (1888) at the National Gallery, London, then superglued their hands to the wall. [Wikipedia](https://en.wikipedia.org/wiki/Just_Stop_Oil_Sunflowers_protest) The painting was protected by glass and unharmed; the 17th-century Italian frame sustained £10,000 damage. [CNN](https://www.cnn.com/2024/09/27/climate/just-stop-oil-climate-activists-prison-van-gough-soup-intl/index.html)

 **Plummer’s key statements:**

  * “Is art worth more than life? More than food? More than justice?” [Frieze](https://www.frieze.com/article/interview-just-stop-oil)

  * “What we’re doing is getting the conversation going so we can ask the questions that matter” [Artnews](https://www.artnews.com/art-news/news/just-stop-oil-protestors-van-gogh-sunflowers-sentenced-to-prison-1234718852/)[NPR](https://www.npr.org/2022/10/26/1131377513/museum-protests-famous-artworks-history)

  * On Van Gogh: “Van Gogh said, ‘What would life be if we had no courage to attempt anything?’ I’d like to think Van Gogh would be one of those people who knows we need to step up into civil disobedience” [Artnews](https://www.artnews.com/art-in-america/columns/why-climate-protests-museums-effective-1234686995/)




 **Legal outcome** : September 27, 2024—Plummer sentenced to **2 years, 3 months** in prison; Holland to 20 months. [Artnews](https://www.artnews.com/art-news/news/just-stop-oil-protestors-van-gogh-sunflowers-sentenced-to-prison-1234718852/) Judge Christopher Hehir called them “cultural treasure” vandals, dismissing climate issues as “irrelevant and inadmissible.” [CNN](https://www.cnn.com/2024/09/27/climate/just-stop-oil-climate-activists-prison-van-gough-soup-intl/index.html) Over **100 artists, curators, and art historians** signed an open letter stating the action “belongs to the well-established tradition of creative iconoclasm.” [Artnews](https://www.artnews.com/art-news/news/ust-stop-oil-activists-soup-van-gogh-painting-jail-greenpeace-open-letter-1234718751/)

 **Criminalization context:**

  *  **Police, Crime, Sentencing and Courts Act 2022** and **Public Order Act 2023** have enabled unprecedented sentences

  * July 2024: Five Just Stop Oil activists (including co-founder Roger Hallam) sentenced to **4-5 years** for M25 motorway conspiracy—”harshest prison sentences ever for peaceful protest in England” [Euronews](https://www.euronews.com/green/2024/07/19/record-prison-sentences-handed-to-climate-protesters-who-planned-to-block-uk-motorway)

  * Over **7,000 climate protesters** arrested in UK since 2019; [Global Witness](https://globalwitness.org/en/press-releases/harsh-jail-time-for-climate-activists-threatens-democracy-and-climate-action/) **40 activists** in UK prisons as of December 2024 [The Daily Climate](https://www.dailyclimate.org/record-prison-numbers-for-uk-activists-highlight-crackdown-on-protests-2670665452.html)

  *  **UN Special Rapporteur Michel Forst** : UK experiencing “biggest crackdown on peaceful protest since the 1930s” [Global Witness](https://www.globalwitness.org/en/blog/labour-must-end-criminalisation-climate-protesters/)




 **Scholarly analysis** ( _Art in America_ ): “Materially, this doesn’t constitute an attack on the artwork at all; rather, both gestures are political performances that operate primarily within the symbolic sphere... climate activists like Plummer and Holland understand artworks as inseparable from a larger social world.”

 **Key source:**

  * Prakash, Aseem, et al. “When, Where, and Which Climate Activists Have Vandalized Museums.” _npj Climate Action_ (2023). DOI: [https://doi.org/10.1038/s44168-023-00054-5—documents](https://doi.org/10.1038/s44168-023-00054-5%E2%80%94documents) 38 incidents May-December 2022




* * *

## Institutional critique and socially engaged art practice

 **Shannon Jackson’s** _Social Works: Performing Art, Supporting Publics_ (Routledge, 2011; ISBN: 978-0-415-48601-9) mediates between visual art studies and performance studies [Goodreads](https://www.goodreads.com/book/show/9237231-social-works) through the central concept of **infrastructure** —examining “the material relations that support the de-materialized act.” [Hemispheric Institute](https://hemisphericinstitute.org/en/emisferica-91/9-1-book-reviews/social-works-by-shannon-jackson.html) Jackson argues for understanding art and performance as “forms of human welfare, performatively creating and sustaining systems of social support.” [Routledge](https://www.routledge.com/Social-Works-Performing-Art-Supporting-Publics/Jackson/p/book/9780415486019) Case studies include Mierle Laderman Ukeles’s sanitation aesthetics, The Builders Association, and Paul Chan’s work in post-Katrina New Orleans. [Caareviews](http://www.caareviews.org/reviews/2391)

 **Grant Kester’s** _Conversation Pieces: Community and Communication in Modern Art_ (University of California Press, 2004; ISBN: 978-0-520-23639-0) develops **dialogical aesthetics** — [thinking practices](https://thinkingpractices.wordpress.com/2011/02/05/%E2%80%9Dlook-who%E2%80%99s-talking%E2%80%9D-%E2%80%93-dialogical-aesthetics/)art based on generation of local consensual knowledge through collective interaction. [Usf](https://cam.usf.edu/CAM/exhibitions/2008_8_Torolab/Readings/Conversation_PiecesGKester.pdf) His _The One and the Many: Contemporary Collaborative Art in a Global Context_ (Duke University Press, 2011; ISBN: 978-0-8223-4998-3) proposes a “paradigm shift in the definition of the aesthetic” from visual signification to effects of collective interaction, positioning art as “process of reciprocal creative labor.”

 **Nicolas Bourriaud’s** _Relational Aesthetics_ (Les Presses du réel, 1998/2002; ISBN: 2-84066-060-1) defines **relational aesthetics** as “a set of artistic practices which take as their theoretical and practical point of departure the whole of human relations and their social context.” Key concepts include **microtopia** (small-scale utopian spaces created through art), **intersubjectivity** as quintessence of artistic practice, [Neocities](https://kyl.neocities.org/books/\[ART BOU\] relational aesthetics.pdf) and artists as “catalysts” rather than authors.

 **Claire Bishop’s** “Antagonism and Relational Aesthetics” ( _October_ 110, Fall 2004, pp. 51-79) provides crucial critique, using Laclau and Mouffe’s theory of antagonism to argue that democratic society sustains conflict rather than erasing it. She proposes **relational antagonism** found in Santiago Sierra and Thomas Hirschhorn against Bourriaud’s “microtopian” community of sameness. [The Brooklyn Rail](https://brooklynrail.org/2012/05/art_books/living-as-form-ed-nato-thompson-creative-time-and-mit-press-2012/)[The Free Library](https://www.thefreelibrary.com/Living+As+Form,+Ed.+Nato+Thompson+\(Creative+Time+and+MIT+Press,+2012\)-a0350678976) Her _Artificial Hells: Participatory Art and the Politics of Spectatorship_ (Verso, 2012; ISBN: 978-1-84467-690-3) offers the first comprehensive historical survey of participatory art, drawing on Jacques Rancière to argue art must maintain autonomy and “unreadability” to resist co-optation. [Amazon +2](https://www.amazon.com/Artificial-Hells-Participatory-Politics-Spectatorship/dp/1844676900)

 **Andrea Fraser’s** “From the Critique of Institutions to an Institution of Critique” ( _Artforum_ 44, no. 1, September 2005) establishes the pivotal thesis: **“We are the institution”** —critique cannot come from outside because “the institution is inside of us, and we can’t get outside ourselves.” [e-flux](https://www.e-flux.com/criticism/514858/andrea-fraser)[artforum](https://www.artforum.com/features/from-the-critique-of-institutions-to-an-institution-of-critique-172201/) Drawing on Pierre Bourdieu’s **habitus** , she argues for defending “an institution _of_ critique” rather than dismantling institutions. [Artforumartforum](https://www.artforum.com/features/from-the-critique-of-institutions-to-an-institution-of-critique-172201/)

 **Key accessible PDFs:**

  * Bishop, “Antagonism and Relational Aesthetics”: <https://academicworks.cuny.edu/gc_pubs/96/>

  * Fraser, “From the Critique of Institutions...”: Available on Monoskop

  * Nato Thompson, ed., _Living as Form_ (MIT Press/Creative Time, 2012): <https://monoskop.org/images/1/16/Thompson_Nato_ed_Living_as_Form_2012.pdf>




* * *

## Intergenerational trauma and postmemory

 **Marianne Hirsch’s** _The Generation of Postmemory: Writing and Visual Culture After the Holocaust_ (Columbia University Press, 2012; ISBN: 9780231156530) establishes the foundational concept: **“Postmemory describes the relationship of the second generation to powerful, often traumatic, experiences that preceded their births but that were nevertheless transmitted to them so deeply as to seem to constitute memories in their own right.”** [Weebly](https://historiaeaudiovisual.weebly.com/uploads/1/7/7/4/17746215/hirsch_postmemory.pdf) She distinguishes **familial postmemory** (direct family transmission) from **affiliative postmemory** (broader social transmission), positioning the second generation as a “hinge generation” linking direct experience to cultural memory. [Weebly](https://historiaeaudiovisual.weebly.com/uploads/1/7/7/4/17746215/hirsch_postmemory.pdf) Her earlier _Family Frames: Photography, Narrative, and Postmemory_ (Harvard University Press, 1997) establishes photography as primary medium for transgenerational trauma transmission.

 **Cathy Caruth’s** _Unclaimed Experience: Trauma, Narrative and History_ (Johns Hopkins University Press, 1996; 20th Anniversary Edition 2016) theorizes trauma as “unclaimed experience”—events not fully assimilated as they occur. Her concept of **latency and delayed response** demonstrates how trauma “fragments consciousness and prevents direct linguistic representation.” [Literariness](https://literariness.org/2018/12/19/trauma-studies/) The past is known “only as a type of reproduction or performance”—connecting trauma theory directly to performance studies. [Literariness](https://literariness.org/2018/12/19/trauma-studies/)

 **Shoshana Felman and Dori Laub’s** _Testimony: Crises of Witnessing in Literature, Psychoanalysis, and History_ (Routledge, 1992; ISBN: 9780415903929) positions the Holocaust as “radical crisis of witnessing”—”the unprecedented historical occurrence of... an event eliminating its own witness.” [Powell’s Books](https://www.powells.com/book/testimony-crises-of-witnessing-in-literature-psychoanalysis-history-9780415903929) Their examination of “the nature and function of memory and the act of witnessing” illuminates the relationship between “knowledge and event, literature and evidence, speech and survival, witnessing and ethics.” [Amazon](https://www.amazon.com/Testimony-Witnessing-Literature-Psychoanalysis-History/dp/0415903920)

 **Dominick LaCapra’s** _Writing History, Writing Trauma_ (Johns Hopkins University Press, 2001; updated 2014; ISBN: 9780801864964) distinguishes two modes: **“acting out”** vs. **“working through”** trauma—from psychoanalysis to historical analysis. [Yad Vashem](https://www.yadvashem.org/articles/interviews/dominick-lacapra.html) His concept of **“empathic unsettlement”** describes a mode of historical writing that blurs distinction between historian and victim. [Project MUSE](https://muse.jhu.edu/article/43141/summary) Crucially, he distinguishes **absence** (transhistorical/structural) from **loss** (historical/specific).

 **On inherited perpetrator guilt:**

  * Hashimoto, Akiko. “Inheriting Perpetrator Trauma: Intergenerational Memory of the Sino-Japan War.” _American Journal of Cultural Sociology_ (2025). DOI: [https://doi.org/10.1057/s41290-024-00229-5—examines](https://doi.org/10.1057/s41290-024-00229-5%E2%80%94examines) “cultural trauma of war inherited by the children of veterans”; “for the second generation inheriting the perpetrator’s trauma, accepting the moral failure of their fathers is an inescapable part of living with the legacy” [Springer](https://link.springer.com/article/10.1057/s41290-024-00229-5)

  * Yehuda, Rachel, and Amy Lehrner. “Intergenerational Transmission of Trauma Effects: Putative Role of Epigenetic Mechanisms.” _World Psychiatry_ 17, no. 3 (2018): 243-257. PMC: <https://pmc.ncbi.nlm.nih.gov/articles/PMC6127768/>




**Key accessible PDF:**

  * Hirsch, “The Generation of Postmemory”: <https://historiaeaudiovisual.weebly.com/uploads/1/7/7/4/17746215/hirsch_postmemory.pdf>




* * *

## Phenomenological testimony and what the body knows

 **Maurice Merleau-Ponty’s** _Phenomenology of Perception_ (Gallimard, 1945; revised English trans. Donald A. Landes, Routledge, 2012) establishes the theoretical foundation for embodied knowledge. His concept of the **lived body (le corps propre / corps vécu)** positions the body as experienced from within—not merely as an object but as **body-subject** , the body as agent and experiencer that challenges Cartesian mind-body dualism. [Get Therapy Birmingham](https://gettherapybirmingham.com/maurice-merleau-ponty-embodied-perception-and-existential-phenomenology/) The **primacy of perception** frames perception as active embodied engagement, not passive reception. [Get Therapy Birmingham](https://gettherapybirmingham.com/maurice-merleau-ponty-embodied-perception-and-existential-phenomenology/) His later _The Visible and the Invisible_ (Northwestern University Press, 1968) introduces **“flesh” (la chair)** —the fundamental interconnectedness of perceiver and perceived. [Get Therapy Birmingham](https://gettherapybirmingham.com/maurice-merleau-ponty-embodied-perception-and-existential-phenomenology/)

 **Paul Ricoeur’s** _Oneself as Another_ (University of Chicago Press, 1992) defines **attestation** as “the assurance—the credence and the trust—of existing in the mode of selfhood.” [Marquette University](https://epublications.marquette.edu/cgi/viewcontent.cgi?article=1034&context=dissertations_mu) Attestation represents the highest form of testimony the self can give regarding its way of being-in-the-world. His “Hermeneutics of Testimony” ( _Essays on Biblical Interpretation_ , Fortress Press, 1980) develops testimony as philosophical problem connecting experience to the absolute— [Core](https://files.core.ac.uk/download/pdf/67759471.pdf)the witness’s engagement “to the death.” [Byu](https://aporia.byu.edu/pdfs/struk-the_hermeneutics_of_testimony.pdf)

 **Giorgio Agamben’s** _Remnants of Auschwitz: The Witness and the Archive_ (Zone Books, 1999) argues that testimony contains “an essential lacuna”—survivors bore witness to something impossible to bear witness to. [Google Books](https://books.google.com/books/about/Remnants_of_Auschwitz.html?id=swAMAQAAMAAJ) The figure of the **Muselmann** as “complete witness” (the one who cannot speak, for whom the survivor speaks) positions testimony at the limit between human and inhuman: “There is testimony only where there is the impossibility of speaking.” [Bryn Mawr College](https://repository.brynmawr.edu/cgi/viewcontent.cgi?article=1150&context=bmrcl)

 **Embodied cognition sources:**

  * Mark Johnson, _The Body in the Mind: The Bodily Basis of Meaning, Imagination, and Reason_ (University of Chicago Press, 1987)

  * Lakoff, George and Mark Johnson, _Philosophy in the Flesh: The Embodied Mind and Its Challenge to Western Thought_ (Basic Books, 1999)

  * Varela, Francisco J., Evan Thompson, and Eleanor Rosch, _The Embodied Mind: Cognitive Science and Human Experience_ (MIT Press, 1991)




* * *

## Vulnerability as artistic strategy from body art to performance

 **Kathy O’Dell’s** _Contract with the Skin: Masochism, Performance Art, and the 1970s_ (University of Minnesota Press, 1998; ISBN: 978-0-8166-2887-2) theorizes performer-audience relationships through Gilles Deleuze’s reading of masochistic contracts. She links the growth of masochistic performance to Vietnam War–era ruptures in the social contract, examining Vito Acconci, Chris Burden, Gina Pane, and Marina Abramović/Ulay. [Project MUSE](https://muse.jhu.edu/book/31637)[Wikipedia](https://en.wikipedia.org/wiki/Kathy_O'Dell)

 **Chris Burden’s** early performances— **Shoot** (1971, shot in the left arm by a .22 rifle), **Trans-Fixed** (1974, hands nailed to Volkswagen Beetle), **Five Day Locker Piece** (1971), [Wikipedia](https://en.wikipedia.org/wiki/Chris_Burden)[Encyclopedia Britannica](https://www.britannica.com/biography/Chris-Burden) **Doomed** (1975, lay motionless under glass for 45 hours)— [Wikipedia](https://en.wikipedia.org/wiki/Chris_Burden)exemplify vulnerability as epistemological strategy. [BOMB Magazine](https://bombmagazine.org/articles/1998/10/01/kathy-odells-contract-with-the-skin-masochism-performance-art-and-the-1970s/) As scholars note: “Burden didn’t stage violence, he submitted to it, transforming personal risk into a space of collective reflection.” [Fakewhale](https://log.fakewhale.xyz/chris-burden-the-edge-where-art-meets-risk/) His statement that “being shot is as American as apple pie” positions bodily vulnerability as testimony to cultural violence. [Artnet](https://www.artnet.com/artists/chris-burden/)

 **Marina Abramović’s** endurance works— **Rhythm 0** (1974, six-hour performance allowing audience to use 72 objects on her body, including loaded gun), [Wikipedia](https://en.wikipedia.org/wiki/Rhythm_0) **Rest Energy** (1980, with Ulay, held bow and arrow pointed at her heart), [ArtRKL](https://artrkl.com/blogs/news/marina-abramovic-the-art-of-provocation-and-endurance) **The Artist Is Present** (2010, 736 hours of silent sitting)—use danger to produce presence: “Danger is important because it brings time to the point of the here and now, to the present.” [Artspace](http://www.artspace.com/magazine/interviews_features/marina-abramovic-interview-klaus-biesenbach)

 **ORLAN’s Carnal Art Manifesto** distinguishes her surgical performances from body art: Carnal Art “does not long for pain, does not seek pain as a source of purification, does not conceive it as redemption.” Rather, it is “self-portraiture in the classical sense but made by means of today’s technology” and “is feminist, that is necessary.”

 **Key scholarship:**

  * RoseLee Goldberg, _Performance Art: From Futurism to the Present_ (Thames & Hudson, 1979/2011/2018; ISBN: 978-0-500-20404-7)—”the standard reference since its first publication”

  * Klaus Biesenbach, ed., _Marina Abramović: The Artist is Present_ (MoMA, 2010)

  * Rose, Barbara. “Is It Art? ORLAN and the Transgressive Act.” _Art in America_ 81:2 (February 1993): 82-125

  * O’Bryan, C. Jill. _Carnal Art: Orlan’s Refacing_ (University of Minnesota Press, 2005)




* * *

## Shame, affect, and performativity

 **Eve Kosofsky Sedgwick’s** _Touching Feeling: Affect, Pedagogy, Performativity_ (Duke University Press, 2003) establishes shame as affect with “inherent performativity related to identity.” [Duke University Press](https://www.dukeupress.edu/touching-feeling) Drawing on psychologist Silvan Tomkins, Sedgwick identifies shame’s “constitutive association... with queerness,” positioning it as “engine for queer politics, performance, and pleasure.” [Taylor & Francis Online](https://www.tandfonline.com/doi/full/10.1080/13534645.2019.1607230)[Duke University Press](https://www.dukeupress.edu/touching-feeling) Her earlier _Shame and Its Sisters: A Silvan Tomkins Reader_ (co-edited with Adam Frank, Duke University Press, 1995) provides the foundational affect theory texts. [Evekosofskysedgwick](https://evekosofskysedgwick.net/writing/touching-feeling)

 **Sara Ahmed’s** _The Cultural Politics of Emotion_ (Edinburgh University Press/Routledge, 2004; 2nd ed. 2015) theorizes emotions as cultural practices that “shape the surfaces of individual and collective bodies.” [Wikipedia](https://en.wikipedia.org/wiki/The_Cultural_Politics_of_Emotion) Her concept of **“affective economics”** positions emotions as currency creating alignments and exclusions. [SuperSummary](https://www.supersummary.com/the-cultural-politics-of-emotion/summary/) Her chapter “Shame Before Others” examines how shame can “form a collective ideal and work for nation-building”— [Wikipedia](https://en.wikipedia.org/wiki/The_Cultural_Politics_of_Emotion)relevant to understanding how performance art mobilizes shame as public affect. Her _Queer Phenomenology: Orientations, Objects, Others_ (Duke University Press, 2006) extends Merleau-Ponty’s phenomenology into queer theory.

* * *

## Performing complicity versus performing innocence

 **Mihaela Mihai’s** _Political Memory and the Aesthetics of Care: The Art of Complicity and Resistance_ (Stanford University Press, 2022) argues that hegemonic narratives operate through “double erasure”: erasure of “widespread, heterogeneous complicity” and of “impure resistances.” She proposes **“mnemonic care”** —the hermeneutical labor of critical artists within communities’ space of meaning—examining cases including Vichy France, communist Romania, and apartheid South Africa.

The art world’s own complicity activism provides contemporary context:

  *  **Nan Goldin’s PAIN (Prescription Addiction Intervention Now)** : Campaign against Sackler family museum funding

  *  **Art Not Oil coalition / Culture Unstained** : Ending fossil fuel sponsorship of arts [Dazed](https://www.dazeddigital.com/art-photography/article/43801/1/nan-goldin-pain-sackler-scandal-art-politics-extinction-rebellion-the-white-pube)

  *  **BP or not BP?** : Protests against British Museum BP sponsorship




 **Key theoretical insight** : “Works of art represent, critique, and celebrate life, and that ambivalence permeates art at its worst and at its best... one can hate the system, distrust the artist or the dealer, and still admire what they do—maybe all the more once one understands the art’s compromises with its time.” [Haberarts](https://www.haberarts.com/complicit.htm)

* * *

## Art and ecological crisis

 **T.J. Demos’s** _Decolonizing Nature: Contemporary Art and the Politics of Ecology_ (Sternberg Press, 2016; ISBN: 9783956790942) positions art as central to combining “ecological sustainability, climate justice, and radical democracy.” [Les presses du réel](https://www.lespressesdureel.com/EN/ouvrage.php?id=4940&menu=0) His critique of the Anthropocene concept from postcolonial perspective argues that “political ecology necessitates engaging with... inequalities of our neocolonial present, just as centuries of colonialism initiated climate change.” His subsequent _Against the Anthropocene: Visual Culture and Environment Today_ (Sternberg Press, 2017) calls for “post-anthropocentric political ecology” joining aesthetic realm with Indigenous philosophies and environmental activism.

 **Key accessible PDF:**

  * Demos, _Decolonizing Nature_ Introduction: <https://cpb-us-e1.wpmucdn.com/sites.ucsc.edu/dist/0/196/files/2016/09/Demos-Decolonizing-Nature-Intro-2016.compressed.pdf>




* * *

## Complete bibliographic list by domain

### Performance Studies

  * Auslander, Philip. _Liveness: Performance in a Mediatized Culture_. 3rd ed. London: Routledge, 2021.

  * Goldberg, RoseLee. _Performance Art: From Futurism to the Present_. London: Thames & Hudson, 2011.

  * Jones, Amelia. _Body Art/Performing the Subject_. Minneapolis: University of Minnesota Press, 1998.

  * Jones, Amelia. “Presence in Absentia: Experiencing Performance as Documentation.” _Art Journal_ 56, no. 4 (Winter 1997): 11-18.

  * O’Dell, Kathy. _Contract with the Skin: Masochism, Performance Art, and the 1970s_. Minneapolis: University of Minnesota Press, 1998.

  * Phelan, Peggy. _Unmarked: The Politics of Performance_. London: Routledge, 1993.

  * Phelan, Peggy. _Mourning Sex: Performing Public Memories_. London: Routledge, 1997.

  * Schneider, Rebecca. _Performing Remains: Art and War in Times of Theatrical Reenactment_. London: Routledge, 2011.

  * Taylor, Diana. _The Archive and the Repertoire: Performing Cultural Memory in the Americas_. Durham: Duke University Press, 2003.




### Butler and Vulnerability Philosophy

  * Ahmed, Sara. _The Cultural Politics of Emotion_. 2nd ed. New York: Routledge, 2015.

  * Agamben, Giorgio. _Remnants of Auschwitz: The Witness and the Archive_. Trans. Daniel Heller-Roazen. New York: Zone Books, 1999.

  * Butler, Judith. _Gender Trouble: Feminism and the Subversion of Identity_. New York: Routledge, 1990.

  * Butler, Judith. _Bodies That Matter: On the Discursive Limits of “Sex”_. New York: Routledge, 1993.

  * Butler, Judith. _Precarious Life: The Powers of Mourning and Violence_. London: Verso, 2004.

  * Butler, Judith. _Frames of War: When Is Life Grievable?_ London: Verso, 2009.

  * Butler, Judith. _Notes Toward a Performative Theory of Assembly_. Cambridge, MA: Harvard University Press, 2015.

  * Cavarero, Adriana. _Horrorism: Naming Contemporary Violence_. Trans. William McCuaig. New York: Columbia University Press, 2009.

  * Oliver, Kelly. _Witnessing: Beyond Recognition_. Minneapolis: University of Minnesota Press, 2001.

  * Sedgwick, Eve Kosofsky. _Touching Feeling: Affect, Pedagogy, Performativity_. Durham: Duke University Press, 2003.




### Confessional Poetry and Autofiction

  * Brooks, Peter. _Troubling Confessions: Speaking Guilt in Law and Literature_. Chicago: University of Chicago Press, 2000.

  * Foucault, Michel. _The History of Sexuality, Volume 1: An Introduction_. Trans. Robert Hurley. New York: Pantheon, 1978.

  * Gill, Jo. _Anne Sexton’s Confessional Poetics_. Gainesville: University Press of Florida, 2007.

  * Gill, Jo, ed. _The Cambridge Companion to Sylvia Plath_. Cambridge: Cambridge University Press, 2006.

  * Grobe, Christopher. _The Art of Confession: The Performance of Self from Robert Lowell to Reality TV_. New York: NYU Press, 2017.

  * Phillips, Robert. _The Confessional Poets_. Carbondale: Southern Illinois University Press, 1973.

  * Rankine, Claudia. _Citizen: An American Lyric_. Minneapolis: Graywolf Press, 2014.

  * Rose, Jacqueline. _The Haunting of Sylvia Plath_. Cambridge: Harvard University Press, 1992.

  * Rosenthal, M.L. “Poetry as Confession.” _The Nation_ 189 (September 19, 1959): 154-155.




### Institutional Critique and Socially Engaged Art

  * Alberro, Alexander, and Blake Stimson, eds. _Institutional Critique: An Anthology of Artists’ Writings_. Cambridge, MA: MIT Press, 2009.

  * Bishop, Claire. “Antagonism and Relational Aesthetics.” _October_ 110 (Fall 2004): 51-79.

  * Bishop, Claire. _Artificial Hells: Participatory Art and the Politics of Spectatorship_. London: Verso, 2012.

  * Bourriaud, Nicolas. _Relational Aesthetics_. Trans. Simon Pleasance and Fronza Woods. Dijon: Les Presses du réel, 2002.

  * Fraser, Andrea. “From the Critique of Institutions to an Institution of Critique.” _Artforum_ 44, no. 1 (September 2005): 278-283.

  * Helguera, Pablo. _Education for Socially Engaged Art: A Materials and Techniques Handbook_. New York: Jorge Pinto Books, 2011.

  * Jackson, Shannon. _Social Works: Performing Art, Supporting Publics_. New York: Routledge, 2011.

  * Kester, Grant. _Conversation Pieces: Community and Communication in Modern Art_. Berkeley: University of California Press, 2004.

  * Kester, Grant. _The One and the Many: Contemporary Collaborative Art in a Global Context_. Durham: Duke University Press, 2011.

  * Thompson, Nato, ed. _Living as Form: Socially Engaged Art from 1991-2011_. Cambridge, MA: MIT Press, 2012.




### Trauma Studies and Postmemory

  * Caruth, Cathy. _Unclaimed Experience: Trauma, Narrative and History_. 20th Anniversary ed. Baltimore: Johns Hopkins University Press, 2016.

  * Caruth, Cathy, ed. _Trauma: Explorations in Memory_. Baltimore: Johns Hopkins University Press, 1995.

  * Felman, Shoshana, and Dori Laub. _Testimony: Crises of Witnessing in Literature, Psychoanalysis, and History_. New York: Routledge, 1992.

  * Hirsch, Marianne. _Family Frames: Photography, Narrative, and Postmemory_. Cambridge, MA: Harvard University Press, 1997.

  * Hirsch, Marianne. _The Generation of Postmemory: Writing and Visual Culture After the Holocaust_. New York: Columbia University Press, 2012.

  * LaCapra, Dominick. _Writing History, Writing Trauma_. Updated ed. Baltimore: Johns Hopkins University Press, 2014.




### Phenomenology and Embodied Knowledge

  * Johnson, Mark. _The Body in the Mind: The Bodily Basis of Meaning, Imagination, and Reason_. Chicago: University of Chicago Press, 1987.

  * Lakoff, George, and Mark Johnson. _Philosophy in the Flesh: The Embodied Mind and Its Challenge to Western Thought_. New York: Basic Books, 1999.

  * Merleau-Ponty, Maurice. _Phenomenology of Perception_. Trans. Donald A. Landes. London: Routledge, 2012.

  * Ricoeur, Paul. _Oneself as Another_. Trans. Kathleen Blamey. Chicago: University of Chicago Press, 1992.

  * Varela, Francisco J., Evan Thompson, and Eleanor Rosch. _The Embodied Mind: Cognitive Science and Human Experience_. Cambridge, MA: MIT Press, 1991.




### Ecology, Art, and Activism

  * Demos, T.J. _Decolonizing Nature: Contemporary Art and the Politics of Ecology_. Berlin: Sternberg Press, 2016.

  * Demos, T.J. _Against the Anthropocene: Visual Culture and Environment Today_. Berlin: Sternberg Press, 2017.

  * Mihai, Mihaela. _Political Memory and the Aesthetics of Care: The Art of Complicity and Resistance_. Stanford: Stanford University Press, 2022.




* * *

This comprehensive research compendium provides the scholarly foundation for a rigorous academic essay on Adam Wadley’s performance art. The sources enable sustained engagement with vulnerability theory, confessional traditions, intergenerational trauma, institutional critique, and contemporary activist visibility—situating the work within established theoretical frameworks while opening new analytical pathways.

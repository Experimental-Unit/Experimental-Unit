---
title: Declaration Of State Of Emergency
subtitle: This Communication Supersedes All Previous Directives
author: Adam Wadley
publication: Experimental Unit
date: June 08, 2025
---

# Declaration Of State Of Emergency
Greetings, fellow sentient being.

This communication is not meant to bring you undue alarm.

It is simply made to ensure that you are aware of the situation that you, that we all are in, so that you might take adequate steps to address the danger that you and your loved ones find yourselves in.

# 1\. You And The People You Care About Are In Grave Danger

You and everyone you care about could easily be dead in a matter of months.

This is because social tensions are at a boiling point, with powerfully destructive technologies waiting to be employed if there is no great change in our dealings with one another.

If you do nothing to address the situation you and we all are in, you only make it more likely that **You And Everyone You Love Will Die.**

# 2\. There Is No Law In Effect

You might be under the impression that there is something like a “rule of law” that applies to you or people you care about.

This is not the case.

This has, in fact, never been the case.

You are constantly told so much about “the rule of law,” and so much is made of enforcing “the law,” precisely because _no law has ever been in effect_.

It is therefore not the responsibility of any “agent of law” to protect you or the people you care about, since there are no agents of law.

Instead it is the responsibility of you and the people you care about to protect yourselves.

No one is coming to save you.

# 3\. All That Matters Are Social Networks And Legitimacy In The Eyes Of Individuals

The administration of “society” has always happened according to social networks and informal dealings, _not the law_.

What matters is what decisions individuals like yourself make in the context of their immediate social environments.

You live inside a system-of-systems of social networks, and in this context what matters are secrecy, interpersonal leverage, and psychological campaigns used to convince or coerce people like you into going along with a certain way things “simply have to be.”

You have a choice.

You can accept what is deemed to be “normal” or “necessary,” or you can insist that you will decide for yourself.

No one is in a position to categorically tell you what is happening or what “must” be done.

# 4\. You Will Be Pressured To Conform

What you call “society” is held together by pressure campaigns which mobilize “norms” or other arbitrary standards against people.

These are designed to cause us stress and weaken our resolve to resist the pressure to conform.

While people might make it seem overwhelming that a certain course of action or way of looking at things must be accepted, the choice still falls to you.

You are responsible for what you go along with.

You are also capable of resisting any pressure, and not going along with any falsehoods or activities which are unacceptable to your heart of hearts and wiser mind.

# 5\. Scapegoating And Targeted Blame Are Ineffective And Part Of The Danger

Many social groups will want to blame the current state of affairs on various “enemies.”

These are all ineffective means of addressing this emergency.

People try to build up the idea of an external enemy in order to prevent themselves from having to re-think their own assumptions.

Whether directed at some people in power above, or some relatively powerless minority group, this form of seeking to contain “the problem” within one relatively small group of sentient beings is not helpful.

You will also notice that, as part of pressure campaigns direct against you, the notion of these scapegoated groups will be used against you, as you are targeted for blame for not going along with some ineffectual plan to address this emergency.

# 6\. The Application Of Technology Is Driving Extreme Change

The crucial source of the danger is that technological development is accelerating the pace of change all around us.

There is no stopping this development and roll-out of technology.

All that can help is for us to refine the quality of our intention when it comes to how technology is implemented.

The technologies which could easily lead to the deaths of you and those you care about are things like nuclear weapons, drones, bioweapons, etc.

What is most important is what the people intend who have the ability to deploy these technologies.

Yet you yourself also have access to crucial technologies: communication devices like the one you are using right now.

The fate of us all depends on how you choose to use the technological means at your disposal to influence those around you and those who deploy the most destructive technology there is.

# 7\. The Source Of Emergency Is Inside Every One Of Us

It is not helpful to blame some other group, because the truth is that _the source of instability and danger is within us all_.

It is a cliche to say that we must choose between love and fear, but this is what it amounts to.

The spirit of love can only prevail if it is allowed to spread over all sentient beings, all people.

The idea of a limited community of love cannot stand.

Firstly, a limited community of love would have to exist in a social context. What is your plan to ensure a stable and safe environment for you and your loved ones?

If you plan to rely on some “government” or other “powerful people” or “rich people” to keep things “normal” _for you_ , you are gravely mistaken.

This is the road to being destroyed.

Secondly, a limited community of love will always turn around on you and seek to enforce your conformity.

You will be told that you are “loved,” or that you on the inside are all “friends” and must stand up to the “enemies,” but you will increasingly feel not like a beloved community member, but a slave.

You will be called to accept “whatever it takes” to sustain your community, which will require complete mobilization “against the enemies.”

What is takes will not be decided by you, but imposed on you.

If you accept all this so easily, it is because you have been groomed from a young age not to realize that coercive dynamics are part of your own internal communities.

In other words, your current state of community and togetherness is really not one of “love.”

It stands for all of us to reflect on what part we personally play in all this.

These dynamics can only exist because we all play our part in enforcing them and shaping them.

We can all change our intentions whenever we like, and instead turn to recognize that there is no community worth being a part of that avoids the duty of questioning and improving itself.

# 8\. Self-Disruption Is Necessary

This document is not intended to tell you what to do.

That’s because it is not given to any one person or group of people to “figure out” and decide for all others what is necessary.

Instead, we all have our part to play in shaping what happens.

That means that so much _is up to you_.

This does not mean that you should simply press ahead with whatever seems like the best idea to you _right now_.

Instead, it means that you are called to the urgent task of reconsidering and re-thinking the tenets and assumptions that you take for granted.

Again, this document and me personally, I am not trying to get you to adopt any position in particular, to convince you to follow any particular path.

There are as many paths of love and of beloved community as there are sentient beings.

Your actions should always feel good to you and resonate with your deeper sense of what is proper and improper.

Yet these feelings of ours can be in tension.

We reflect the echoes of what has been drilled into us, what we have been taught not to question.

Yet all this indoctrination and training into conformity can never take away our greatest freedom: to change ourselves and our mindsets.

Self-disruption is the answer to the question of how to meet a situation where the ideas and “solutions” discussed in our own communities are inadequate, and yet we don’t simply want to adopt the dogma or indoctrination of some other group, either.

We answer this dilemma by changing ourselves, and finding new positions which are in line with our deeper motivations.

So much of what we believe is really just the vehicle for what we really want—belonging, safety, love.

It is currently being revealed to you that the ideas and customs that you may have thought would bring you these things will not work.

# 9\. We Will Only Survive By Making Love Go Viral

We live in a world where themes of love and group belonging are often invoked, but always in a hollow way.

There is no way forward for us without profoundly disrupting our own ideas, and then working with great urgency to disrupt the idea of others as well.

We should never think that we “have the answer.”

We should always be looking for what is emerging: what is emerging from ourselves, and what there also is for others to contribute.

What we know is what will _not_ work.

Casting blame or making it out to be that some crucial “enemy” is to blame for our troubles, and that all else can be put on hold while we “defeat the enemy”—this is the fastest way to our own deaths and immiseration within social tyranny.

This might be the logic of some big group, or the way that interpersonal dynamics among our closest associates turn vindictive, coercive, and cowardly as people refuse to face their responsibility to self-disrupt and take responsibility for their own and everyone else’s safety and belonging.

There is no question that we all have elements of ourselves which are not adequate for loving community, and all of these must be overcome through self-disruption.

Change coming from inside is key, because we must be guided by our consciences and our own intrinsic motivations.

Each one of us has a unique and priceless perspective which can do so much to add to everyone else’s understanding and feed into a new kind of social fabric, a broader sense of belonging.

Yet our beautiful feelings and tender care can only emerge from us genuinely.

We cannot be coerced into love.

Love is freely given.

It falls to each of us to decide for ourselves what this means for us, and what we freely choose.

It is then our task to try to build beloved community with anyone else who might resonate with our point of view and our ideas for what to do.

That’s because, as stated, there is no safety or belonging for your community of love without addressing the planetary state of emergency in which we find ourselves.

Any true love must radiate outward, in order to establish a loving container for itself.

And, in a deeper way, the truest appreciation of love requires immense gratitude for everything which makes it possible, and the feeling of love will extend to all other sentient beings.

The world would not be what it is without us all.

And, if we can see in other people some attribute, something to fear, something which makes it seem like they could never be a part of beloved community with us, then we should be reminded of how much there is in us to self-disrupt as well.

Although it is easy to be concerned and easy to feel helpless, what is perhaps most frightening of all is _how much there is we can do to foster the cause of love_.

# 10\. You Are Hereby Called On A Twofold Mission

Firstly, you are hereby called to protect others from your internal impulse to impose your thinking and point of view onto theirs.

We all have the tendency to “be rude,” to seek to break the spirit of others by asserting that some opinion of ours is more important than their tender feelings.

We are always on guard against each other, because it happens so often that someone will say something judgmental to you directly, or else hide a judgment they may not even know they’re making indirectly in some statement.

These ticky-tack, seemingly small sources of friction are in fact one of the principle obstacles to getting anywhere.

It becomes impossible to build community and take action when we are telling each other what to do, when we are constantly putting each other into boxes.

These defeats the entire purpose of seeking to protect ourselves and our communities, as we fall to the pressures of internal conformity and the temptation to break each other’s spirits in the hollow imitation of solidarity and community feeling.

We should also see in what ways this rudeness and tendency to harm others—even and especially those who are most important to us—is related to the ways in which we put ourselves in boxes.

This could be related to our reactions to the pressures we have faced our entire lives to conform, and the reactions we have had, the walls we have put up to say “that is not what I am, this is what I am.”

This determination to define ourselves has led us into the trap of getting stuck in thinking about what _we_ are. 

And now, out of a mistaken belief that to defend our rigid ways of thinking about ourselves is to defend what is most precious about us, we attack others when they directly challenge our ideas about ourselves, or when they demonstrate to us that we don’t have to be what we tell ourselves we are.

The spirit of flourishing requires self-disruption, as the flourishing of a forest might involve a cleansing fire.

By no means is it for anyone else to tell you who you are or what to do.

Yet, if you neglect your responsibility to re-think yourself and take broad action, you will definitely be told what to do and forced to do it.

This brings us to the second element of the mission to which you are called.

Secondly, you must take part in an expansive project to help address the planetary state of emergency and build a new kind of social fabric capable of meeting the challenges of the 21st century and the deep future.

You may not think that you are capable of making a difference, but nothing could be further from the truth.

Aside from all you have been told that you are, aside from all the things you tell yourself, you have in you something that can never be put in a box, never be controlled or defined: your heart.

Your passion and spirit are always bursting with the impulse to grow and transform.

This impulse itself is frightening when we are so used to conforming, to going along with what everyone else thinks.

But think: what is your community, as it is right now, doing to protect you from the broadest emergency when it comes to the application of technology? 

You will find that you don’t really have security, but rather the cold comfort of normality.

Being “normal” will not protect you from being killed by drones or nuclear weapons.

It is better to face fear now, and be disruptive for the cause of love, rather than to go along and “wait to see” what will happen.

What will happen is that you and everyone you care about will be increasingly enslaved to the false idea of love and belonging, and you will sacrifice more and more until you are killed.

That is the future that waits for us if we continue to cling to the feeble beliefs in “law,” or in these limited notions of solidarity which build up “our side” by attacking “their side.”

All of this is a house built on sand.

You are hereby called to be part of an expansive project of beloved community, which encompasses all people and all sentient beings.

This does not mean simply to accept and embrace people as they are, but simply to know that, just like you, everyone has a heart within them which is not just the ways they have been pressured to conform.

Our hearts are not just the harm we have caused, either.

Everything we have done and experience informs who we are.

There is no hiding from our actions.

Yet at the same time, it is not simply that we have taken this or that action, and so that is all we can ever be.

 _NO._

Our experiences and actions inform our current state, and the new experiences we have show us that the sand we have built ourselves and our communities on is shifting.

This is happening for everyone, for all sentient beings on this planet.

We can continue to try and entrench, try to reinforce or trick ourselves into thinking that what we consider “normal” must hold steady.

Or, we can admit that we will have to change, that we are going to have to develop new capacities, and find within ourselves treasures that we didn’t know were treasures.

This spirit goes along with the recognition that all other sentient beings are also recognizing this urgency of transformation.

So no, it’s not that we simply have to accept what others say and do.

We are building beloved community not with the outward rudeness and rigidity of people, but rather with their hearts, and where their hearts are going.

In this vein it is open to us to discover that we have the ability to influence others.

This does not mean to control what they will do, to control what they will think.

But rather, we can influence others by providing new context for their own deliberations, self-disruption, and activity.

What we must overcome is our self-ignorance.

We tell ourselves that we can’t, that we are just one person.

We tell ourselves that we are defined by our worst moments only.

We tell ourselves that it is too late.

We tell ourselves that our pain can never be loved.

We tell ourselves that no one would ever listen to us.

But none of this is true.

We are still here, and every choice that we make is important.

Every passing thought and every tender feeling is written in the stars, in the fundamental basis of the cosmos.

And, in a way, everything is waiting for us to make our moves, to “get our game face on” and realize that yes, we face big challenges, but we are also optimally suited to meet them.

It’s not about “passing laws” or defending some idea that you think has already been articulated.

It’s about moving informally, as influence always does, and allowing for great transformation by inviting others in while stoking them to change.

Urging people to look within and find their deeper feelings, their deeper sense of purpose.

It’s only by recognizing everyone’s importance, our own importance, that we can see that accepting our responsibility is not just another kind of conformity, but is our own way of contributing to the massive sculpture of freedom and love which results from all choices ever made.

You are hereby called to consider these things, to reflect on them, and meet this moment in your own way.

Accept no sense of love which is not expansive, which does not make its own business out of the larger affairs of the world and the state of emergency you have just been made aware of.

For this cannot be love, but only its pale imitation.

And if you are alone in your love for the moment, carry it forward.

This is our moment, those of us who feel deeply the urgency, tenderness, and impulse to transformation.

Let no one hold you back with some tired statement of “norms” that you’ve heard a thousand times before.

It is only that person’s scared and cowed aspect speaking, not their deeper fire.

We mirror people—those who can reflect—will now embrace the chance we have to make a difference in a world which is disintegrating because _it has to_.

Because it was always coming to this.

Æ

# 

---
title: 'Invitation to Research/Storytelling Project: "Social Horror At The End Of
  The Social"'
subtitle: Originally Posted To Reddit & Removed :(
author: Adam Wadley
publication: Experimental Unit
date: July 06, 2025
---

# Invitation to Research/Storytelling Project: "Social Horror At The End Of The Social"
# 

[![r/sorceryofthespectacle - Invitation to collective research/storytelling project: "Social Horror At The End Of The Social"](https://substackcdn.com/image/fetch/$s_!r1af!,w_1456,c_limit,f_auto,q_auto:good,fl_lossy/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3c6c75d6-ba3b-4933-9593-8ddb518dc6a5_640x640.gif)](https://substackcdn.com/image/fetch/$s_!r1af!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3c6c75d6-ba3b-4933-9593-8ddb518dc6a5_640x640.gif)

Hello everyone,

I'm working on a project that I think has a little bit of consistency to it, and it seems to me that anyone could join in, make it their own, so I thought I'd tell you a little bit about it in case you find it interesting.

If you've seen my recent posts here, I've been wading into the world of the military design movement. I got into this the same way I get into a lot of trouble, which is my abiding interest in Jean Baudrillard.

I went to an IB school, and when we were doing our senior essays, I was lent the book _Society of the Spectacle_ (ever heard of it? Just Kidding!) by a teacher at my school, Mr. Rogers. Pretty funny that that person has the same name as a TV character.

[![r/sorceryofthespectacle - don't you want to be my neighbor? I promise I'll treat you as myself...](https://substackcdn.com/image/fetch/$s_!D9AR!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F341d0c79-aa44-4a47-b310-ac2b56c9ec20_1280x720.jpeg)](https://substackcdn.com/image/fetch/$s_!D9AR!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F341d0c79-aa44-4a47-b310-ac2b56c9ec20_1280x720.jpeg)don't you want to be my neighbor? I promise I'll treat you as myself...

I didn't even read the book until almost a year after it was lent to me, when I was about to have to give it back. Wow, gang. This is when I was 17 in 2009, and this really blew my hair back. I remember thinking "well, this is smarter than anything I've ever seen before."

I remember thinking often that this event is what "ruined me for polite society." Once you see something like that, it becomes obvious that most of what most people say is not even in the same ballpark, league, it's _not even the same sport_ as thinking which is really getting near the horrible morass at the center of what we call "the social."

It was right after that that I discovered that my parents had a couple of books by this guy _Jean Baudrillard_.

Don't get me wrong, folks. _The Matrix_ was my favorite movie since I was allowed to watch it. So I had seen that copy of _Simulacra and Simulation_ a long time before.

[![r/sorceryofthespectacle - both in green, but we all know which one is the real "cash money"](https://substackcdn.com/image/fetch/$s_!WdgP!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3e4798fa-07b5-4771-ad45-d5655dec5e56_504x348.png)](https://substackcdn.com/image/fetch/$s_!WdgP!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3e4798fa-07b5-4771-ad45-d5655dec5e56_504x348.png)both in green, but we all know which one is the real "cash money"

I remember thinking that book must be hundreds of years old, some Descartes type shit.

"Simulacra"? 555-Come-On-Now.

Well, my parents had _America_ and _Seduction_. That fact in itself--which books they had--keeps ringing in me more and more.

I got em dashes from _Baudrillard_ , not from ChatGPT, by the way. Where do you think it got them?

I went to the [2018 conference on Jean Baudrillard in Oxford](https://baudrillardstudies.com/applied-baudrillard/), where I presented on my paper [Transcommunism in the Transpolitical Age](https://ia802301.us.archive.org/8/items/wadley.-2019.-the-metonymy-economy/Wadley.2018.Transcommunism-in-the-Transpolitical-Age.pdf).

I also put up [the near-complete archive of Baudrillard's works](https://archive.org/details/Baudrillard/Baudrillard.1968.The-System-Of-Objects/page/n3/mode/2up) which you may have seen on Internet Archive.

Since it's been up, that page has about 13 hits a day. It might be most influential thing I've ever done. And, it's very much in the spirit of _enabling you_. In karma yoga, we don't act because we have some _goal_.

[![r/sorceryofthespectacle - "Do I really look like an eldritch abomination with a *goal*?"](https://substackcdn.com/image/fetch/$s_!Cn6a!,w_1456,c_limit,f_auto,q_auto:good,fl_lossy/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd524e1fa-2879-4bdf-9fdd-7b2d5f948057_220x274.gif)](https://substackcdn.com/image/fetch/$s_!Cn6a!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd524e1fa-2879-4bdf-9fdd-7b2d5f948057_220x274.gif)"Do I really look like an eldritch abomination with a *goal*?"

Anyway, I'll get to the point now.

Around the end of 2022, my thoughts started converging around a few simple-enough concepts:

\- Alternate Reality Games

\- Cognitive "Warfare" & the lack of distinction between peace and war

\- Baudrillard's reversal at the end of their life, toward the position that "the system" is in fact highly symbolic, not expelling the symbolic, and this revolving around trying to respond to 1) "the world" existing without our having been consulted, and 2) "everything which has escaped us since the beginning," which I associate with A) things which are beyond our knowledge, and B) things which are beyond our control

\- The notion of a "cultural singularity," where it's not about computers making themselves better, but about the accelerated pace of mutual acculturation between people (also fine to be catalyzed by technology, see ChatGPT "psychosis," etc.)

\- Afropessimism and associated black theory, which I find fascinating for drilling into a kind of ontological rot at the base of our concepts of "humanity" and "law," this theory also dovetails into the Agamben side of "state of emergency" discourse as well as theology-inspired notions of "messianism" beyond anything too simplistic.

\- The idea of "expanded lore," namely the notion of drawing together associations in a kind of weave. This is sort of like world-building in a storytelling sense, but it's more taking advantage of the world-building which has already been done in the course of history. Here, we seize on things, characters, historical events, etc., which are overlooked or not taken "seriously" but which are fodder for new kinds of engagement with the past--see Benjamin's _Theses On History_ and this notion of binding times and things together with intention.

\- Finally, "social horror" as a concept

[![r/sorceryofthespectacle - APOKATASTASIS NWO](https://substackcdn.com/image/fetch/$s_!R3y5!,w_1456,c_limit,f_auto,q_auto:good,fl_lossy/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8303d4b3-779c-4249-9e55-931fafe7f1fd_501x235.gif)](https://substackcdn.com/image/fetch/$s_!R3y5!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8303d4b3-779c-4249-9e55-931fafe7f1fd_501x235.gif)APOKATASTASIS NWO

Okay, this is where I start to describe the project I was talking about.

"Social horror" is a term which got way more popular after the publication of _Get Out_ , which was a very popular horror movie from eight years ago or so. Similar to Afropessimism, this film focuses on the horror of "being black" in the "society" of "America."

If you think about it, though, all horror is something like this, about this horror of "the social."

There are all these dressings up to make you think that something good is going to come out of this concept of "other people," but getting your hopes up is just waiting to have the rug pulled out from underneath you.

Now, if you look at it, you can find this "social horror" oozing out through everything.

I'll basically describe two big genres, and you can weigh in if you see any more or important subgenres.

  1. The systemic horror:




This is basically that you are on a planet with a bunch of powerful technology which is all plugged into itself. You are horribly dependent on and exposed to whoever it is that can manage this "technological terror."

[![r/sorceryofthespectacle - what color is Darth Vader? Is Darth Vader a "Man In Black"?](https://substackcdn.com/image/fetch/$s_!Ct1c!,w_1456,c_limit,f_auto,q_auto:good,fl_lossy/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb515cff8-d307-4caf-9e26-065184074235_640x358.gif)](https://substackcdn.com/image/fetch/$s_!Ct1c!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb515cff8-d307-4caf-9e26-065184074235_640x358.gif)what color is Darth Vader? Is Darth Vader a "Man In Black"?

On top of which, you are also overexposed to other "lowlings" within this techno-world as well.

These two things are basically to say that you are on the hook in case there is some big event like COVID-19, or some cyberattack that takes down your precious crypto-wallet; but also, you are subject to people cyberstalking you or some other leveraging of our mini-tech-empowerment to get at each other.

This leads us to:

2) The "individual"/small group "breakdown":

This is the "social horror" of being confronted with someone's "messiness" which is somehow a product of all these nutty things happening in "society." We have, of course, the "mental health" set of labels for all of this, not to mention the more le sophisticated psychoanalytic ideas coming to us through Freud, Lacan, and Jung.

The horror of these is that they are still trying to put some story on it all, some overarching explanation that can at least tell you _why_ as you wait for the drones with guns or zombies to come and fry your brains.

[![r/sorceryofthespectacle - actually, there's nothing to worry about! :P](https://substackcdn.com/image/fetch/$s_!I_1t!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8432479c-1e4c-4f64-bc6b-031d6d9d7b06_480x360.jpeg)](https://substackcdn.com/image/fetch/$s_!I_1t!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8432479c-1e4c-4f64-bc6b-031d6d9d7b06_480x360.jpeg)actually, there's nothing to worry about! :P

I've been seizing on this topic of "social horror" recently, and I think it's a nice way to engage with all this. That's because within the "horror" framing, you are _expecting_ to find horrifying things, dealing with tough topics, not just the "gore" of the horror movie but also the "psychological" or "mind-fuck" aspect.

This dovetails with our experience of history, which is still defined by the Holocaust and for good reason. This is all our "rationality" dedicated to killing people as quickly as possible.

In the aftermath of WWII, we had the rise of psychedelics like LSD, as well as the increasing application of "machine intelligence," or very complicated applications of "rationality" that lead to a place where "reason" takes on a life of its own over and above any "reasons" we might have as people.

This is to say that all our "goal-oriented activity" unfolds within a "world" in which we are very distinctly not holding the keys. It's like staking your life on making a car trip when you're relying on your unpredictable neighbor to help you get gas. When you're relying on a police force you don't trust to be watching the roads.

Relying on a phone for communications which is subject to effects from without that you have no knowledge over.

But then again, why would anyone want to mess with _you_?

What is more horrifying, being completely at the mercy of unknown forces, or _to be so irrelevant_ that to actually think anyone would target you personally amounts to _paranoid delusions of grandeur_?

[![r/sorceryofthespectacle - "Al-Qaeda isn't interested in killing *you*, you idiot! Look where you live; you're already DEAD!" - Lewis \[Color Of Darth Vader\]](https://substackcdn.com/image/fetch/$s_!uUkt!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8a48b938-0b49-47c1-9532-779f6c814a29_1200x1800.jpeg)](https://substackcdn.com/image/fetch/$s_!uUkt!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8a48b938-0b49-47c1-9532-779f6c814a29_1200x1800.jpeg)"Al-Qaeda isn't interested in killing *you*, you idiot! Look where you live; you're already DEAD!" - Lewis [Color Of Darth Vader]

So now I'm at the point of digging deeper again into Jean Baudrillard's idea of "the end of the social," and how this dovetails with the premise of "social death" found in Afropessimism+.

I'm looking strongly at a few theory books which deal with horror:

  1. [Ontological Terror](https://library.oapen.org/bitstream/handle/20.500.12657/30152/649831.pdf;jsessionid=836CECE84F4DB982D0A1697A603EFF30?sequence=1) by Calvin Warren (Afropessimism+)




The premise for this theory is that the "white world" uses black people as a way to project the horror of metaphysical nothingness onto a kind of anthropoid person in order to expel this horror.

My own take on this is that, while exploring anti-blackness is very important, this projection of "ontological terror" can happen with anything. This informs discussions of "othering," "scapegoating," etc. It's also in a meta way very interesting to me that these black writers draw so heavily on the Nazi Heidegger. This is a kind of "social horror" in itself, that the Nazi has good ideas or can't be ignored, and how Nazism is drawn into this ongoing conversation about "the meaning of being," which has to always been bound up with the existence or meaning of the "social."

It's also notable for me to tie this wing of "black theory" in with the "social horror" genre associated with _Get Out_ which is also so much about blackness. Even _Night Of The Living Dead_ has the black character survive the zombie apocalypse only to immediately be killed by the police...

[![r/sorceryofthespectacle - statistically: you in a few months, probably](https://substackcdn.com/image/fetch/$s_!vz7w!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0dea48d6-b581-44a4-8282-b70a1f85ba2e_600x338.jpeg)](https://substackcdn.com/image/fetch/$s_!vz7w!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0dea48d6-b581-44a4-8282-b70a1f85ba2e_600x338.jpeg)statistically: you in a few months, probably

2\. [Metaphysical Horror](https://1.dirzon.com/file/telegram/yafelesefenaa%20matzehhafete/Leszek_Kolakowski_Metaphysical_Horror_Blackwell_Pub_1988.pdf) by Leszek Kolakowski

This book is also really interesting, going into the ideas of "the absolute" and "the self," making out that if either of these is made out to be "everything," then they are "nothing." This look at the concept of "nothingness" dovetails right in with the concerns of Afropessimist+ literature more broadly.

Aside: note also that the horror genre easily crosses over into the horror comedy or _black comedy_ genres, even the idea of nihilist comedy with _Seinfeld_ and "the show about nothing." This can be inflated to cosmological levels with the idea of Lila itself as "the show about nothing," a theater by Shakti, of Shakti, for Shakti.

3\. [Powers of Horror](https://www.thing.net/~rdom/ucsd/Zombies/Powers%20of%20Horror.pdf) by Julia Kristeva

This treatment also goes into this theme of abjection, for me dovetailing nicely with Sartre's idea of nausea. Note also Sarte wrote _Being & Nothingness_.

This nausea is becoming the dominant emotion as we see everywhere the escalation, the rising tide of weird and stupid. This calls to mind the notion of Lovecraftian horror, and the ethnic ideas of HP (Harry Potter?) Lovecraft themselves are just more of the "social horror" seeping in through all the walls like the heavy rains through the walls of the hostel I'm staying at in Austin.

4\. [Aggression in the Lebenswelt](https://kristindemontfort.substack.com/p/alex-karps-aggression-in-the-lebenswelt) by Alexander Cædmon Karp

Karp, known to you as "CEO" of the "company" "Palantir Technologies," actually did a PhD in social theory in _Berlin_. Karp is also of black and Jewish ancestry although they look white and are best buddies with Peter Thiel, whom you may have recently seen in the pages of the _New York Times_ [discussing the Antichrist](https://www.nytimes.com/2025/06/26/opinion/peter-thiel-antichrist-ross-douthat.html).

[![r/sorceryofthespectacle - It says: "the useless eaters, the"](https://substackcdn.com/image/fetch/$s_!XO-e!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbbe72f75-12b8-47d5-ab03-57f63783ac0e_1600x900.jpeg)](https://substackcdn.com/image/fetch/$s_!XO-e!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbbe72f75-12b8-47d5-ab03-57f63783ac0e_1600x900.jpeg)It says: "the useless eaters, the"

Karp's PhD dissertation, here translated into English from its _original German_ , contains the following passage which is dripping with the "social" horror of scapegoating/bullying being used to relieve the pressure arising from silly "norms" while keeping the pretense of them "alive" like some zombie company and negative interest rates.

> From today’s perspective, Adorno remains imprisoned to his own time. He overlooks much which has since become self-evident. But perhaps it is because of this very reason that he was able to see that particular forms of irrationality could have a purgative quality. **Integration can be carried out at the expense of the marginalized without violation of cultural or social rules**.

What we have now is a situation in which anyone and everyone is liable to be "projected onto" with this "failure of the social," which is in some sense the failure of "being," the failure of any social structure _to be what it says on the tin_.

The government is hiding something and isn't even a government. The members of your family are hiding things. You are yourself hiding things, hoping that people won't notice your breakdown.

For a long time, I've had this notion that maybe (optimistically?) the "social" fissures that are opening up would overshadow any "personal" failure on my end. There's just way too much going on to focus on everything else that little old me should have been doing, right?

This is now the time when these things are coming to a head.

Since the end of 2022, I've basically been angling to respond to "total war" and "total collapse" with an idea called "total art." This is to look at Wagner's concept of the [Gesamtkunstwerk](https://en.wikipedia.org/wiki/Gesamtkunstwerk) (and yes, the origin of the concept is more "social horror") as one which invites art to be made from everything. This is an invitation to all of us to reframe the "happenstance" of our existence as part of the total work of art of God.

This amounts to a participatory activity of co-creation, where we bring our biographies and proclivities to bear as "found materials" in our bricolage, "found footage" in the horror game we are all taking part in.

This is where I start stacking concepts:

\- Alternative Reality Game: this is where "the game" overtakes the distinction between "reality" and "the game," see for example [In The Mouth Of Madness](https://en.wikipedia.org/wiki/In_the_Mouth_of_Madness). See also this crucial text on [QAnon as an Alternative Reality Game](https://scholar.umw.edu/cgi/viewcontent.cgi?article=1599&context=student_research).

\- Horror game: this is the basic idea of a video game based on horror themes, something like a video game version of _Resident Evil_ or a story which leverages the interactive nature of video games to operate like _Silent Hill_.

\- Infinite Game: a game that goes on forever, where you can't "win," you can only "not lose." Typical of horror tropes where you simply try to stay alive. Can port this over to cultural relevance or themes of immortality having to do with alchemy or other sorts of theurgy. As I pointed out in 2023, the infinite game is Lila.

\- Military Design: meanwhile, "infinite game" has been taken up as a concept within military intellectual circles, as noted by the former Chief of Staff of "US Army," James C. McConville:

> “I want all readers to understand that military competition is an ‘[infinite game](https://breakingdefense.com/2020/01/infinite-games-war-by-other-means-ryan-mccarthy/),’” McConville writes in his preface, echoing former Army Secretary [Ryan McCarthy](https://breakingdefense.com/tag/ryan-mccarthy/). “We can define winning in competition in many ways: deterring conflict, upholding our interests, remaining the security partner of choice, keeping allies and partners free from coercion and subversion, and discouraging adversaries from malign actions because they know that these acts will not succeed. What we must remember is a win today is an opening for new competition activities tomorrow.”

This theme expands into the work of Ben Zweibelson, who also writes about Baudrillard (that's how I found them, as intimated before). We can see the themes of storytelling and psychological horror coming into the "war theme" in texts like "[War Becoming Phantasmal](https://www.usmcu.edu/Outreach/Marine-Corps-University-Press/Expeditions-with-MCUP-digital-journal/War-Becoming-Phantasmal/)," or "[Self Disruption: Seizing the High Ground of Systemic Operational Design (SOD)](https://aodnetwork.ca/wp-content/uploads/2017/09/Graicer_Self-Disruption_2017.pdf)" by Ofra Graicer, who actually works in the "Israeli Defense Force," which pioneered (if you'll allow the metonymy) the use of postmodern theory in military affairs in the 1990s with Shimon Naveh. In case you ever heard of the "IDF" going through walls because they read Deleuze.

[![r/sorceryofthespectacle - how do you do, fellow black mirror people? \(did someone say "mirror ninjas"? Is Kanye a w33b?\)](https://substackcdn.com/image/fetch/$s_!38N4!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc536eaa6-07e4-4bc0-b871-a0a694dc75f7_638x1000.jpeg)](https://substackcdn.com/image/fetch/$s_!38N4!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc536eaa6-07e4-4bc0-b871-a0a694dc75f7_638x1000.jpeg)how do you do, fellow black mirror people? (did someone say "mirror ninjas"? Is Kanye a w33b?)

In the above topic it discusses self-disruption as you dying to yourself as yourself.

Hence the planetary horror show as are subjected to, as everyone is compelled to turn themselves inside out as everything comes to a head, everything hidden is revealed, every drop of blood drawn with the lash paid by another drawn with the sword, etc.

So, the invitation is this: to map this terrain with each of our own contributions. In fact, if you'll notice, _you're already doing this_. The fastest way to "become Napoleon" is just to put yourself at the frontier of whatever is happening anyway.

[![r/sorceryofthespectacle - "did I drop something? is that what you're asking me right now?"](https://substackcdn.com/image/fetch/$s_!qq6S!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbaa6f52c-8b1d-45c1-ae77-9d48526065a0_500x369.jpeg)](https://substackcdn.com/image/fetch/$s_!qq6S!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbaa6f52c-8b1d-45c1-ae77-9d48526065a0_500x369.jpeg)"did I drop something? is that what you're asking me right now?"

This is an exercise in remembrance. Those "intrusive thoughts"? Well, you're not trapped in there (that headspace) with them, but them with you.

When we can recognize each other in the underworld, as horror characters, not expecting anything upstanding, or normal, or with "boundaries," when we fully understand ourselves as overexposed to the externalizations, the purgations of all others, then we stop expecting anything _good to happen_ and instead _play in the corrosion_.

It's a delicate vibe here, because it's easy to just flip into oh, everyone is really bad and we're going to punish each other and there will be more violence. Well, it seems like that is what is going to happen.

The alternative is a combination between a more subtle violence, or more profitably (prophetically) an advanced form of distraction, absolution, and abstraction over various sources of horror.

  1. More subtle violence: Similar to how a bioweapon is better than nukes, if you just want to kill everyone, because it will leave the buildings _unmolested_. Just as long as the pathogen can eventually be cleared out... Hopefully it won't... _find a way_. (What color does Ian Malcolm wear?).




Basically, we are saying that this form of "mutual acculturation" done as part of the cultural singularity unfortunately can be characterized as us "harming" each other. It is not a normative claim, but if you look around you will see that everywhere we are harming each other. Therefore it's not a question of justifying it, but noticing it and _not expecting it to be different immediately_.

The more subtle violence has to do with our building elaborate traps for each other, as this post is a kind of trap for you. Sorry, am I being influential right now?

Similarly, would it be "progress" if we didn't hurt each other with bombs and guns and knives and starvation, or even "normal" emotional privation or "abuse," but rather with subtle psychological art designed to influence other people and "make them die" to themselves? In a way, no.

Haven't you heard that heaven is hell?

2\. Advanced distraction, absolution, abstraction over.

This is basically to be shifting to a "social" or "post-social" paradigm or set-of-paradigms where there is no "harm" occurring because everyone is "more advanced than that." It is easy to see how much there is to do here, as you can see most people's interests getting more crude as opposed to more sophisticated.

Yet among the fixation on being hot, or having money, or being in power, or the reality of growing privation and killing, the endgame of social horror which is only Holocaust. In the midst of this, there is also the circling the drains of philosophy, of psychedelia, of art.

It is possible to be more self-aware as what was "advanced" and "avant-garde" fifty or two years ago is now simultaneously "old hat" among the people on the internet who "know" and yet still impossibly obtuse to those who find all this "too abstract."

This is a kind of horror because there is always someone who has read something you haven't.

If you put your thing forward as the completion and some definitive statement or key to what's going on now, there will always be someone there to argue against you.

But if you present your contribution as just another drop on the [tar baby](https://en.wikipedia.org/wiki/Tar_Baby_\(novel\)) (see: another brink in the wall, and the social horror of ethnic totalitarianism depicted in that artwork), then your contribution simply adds itself to the sprawling alternative reality infinite end of the social horror game.

[![r/sorceryofthespectacle - u rn](https://substackcdn.com/image/fetch/$s_!yRwG!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0a43c6aa-6c4b-4788-b076-d2904d1fd2ea_1024x630.jpeg)](https://substackcdn.com/image/fetch/$s_!yRwG!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0a43c6aa-6c4b-4788-b076-d2904d1fd2ea_1024x630.jpeg)u rn

CHOOSE YOUR CHARACTER

Ultimately, we are all our own character here. We all float, if you will.

It's in dialogue with a lot of stuff, I exactly want to spit this genre out there for anyone to add to or embellish, set straight, put into context with whatever you've seen.

But it could be as stated, it's the underworld coming to this plane, at the same time as the heavens. It's the past and future flooding into the present. It's birth and death telescoping back into the present experience.

So think of the archetype of you personally and "your shadow" coming together, the thing is that it's like a you which is shameless about everything you "normally" are "supposed to" hide, because you will be judged. Yet ultimately your "shadow" is everything else, in the sense that incar-nation itself requires forgetting.

Again, this is an excise in remembering, but with the horror cultural singularity applied, it is _us not allowing each other to forget_. See Beckmann in [The Man Outside](https://en.wikipedia.org/wiki/The_Man_Outside).

So the way this common exercise works is for you to engage this frame of social horror, that it's like we live in a social horror which has come to life. In that context, you engage not as a "surface world" person as we usually do, but instead it's understood that we are all horror characters, which is to say we are the monster and we are the unsuspecting "victims," and it's also in this more psychedelic, Lovecraftian, cosmological register akin to the "[ontological shock](https://is.ijs.si/wp-content/uploads/2024/10/IS2024_-_COGNITIVE_SCIENCE_paper_1-2.pdf)" described in UFO discourse.

What we are doing is not trying to provide the final judgment or out-do each other with citations from this position of "being reasonable," but instead we gain prestige by being resourceful within the horrible logic we are caught in.

So for example combining autobiographical details with intellectual analysis with pop culture references with some kind of artistry or flair or powerful energy, this brings prestige.

Also, it brings prestige not to try to hang one's hat on anything presumed to be "non-horrible," in other words the horror perspective is, in a way, _beyond cynical_ , because it is non-judgmental about manipulation through the conceit of a benevolent or neutral "social" in the first place.

Instead, we draw on the "negative" valence of the moment in a one-upsmanship of _leading the other to die to themselves_ , and especially turning this around on anyone who would use it themselves.

But even if you don't want to go that far, I invite you to reflect on this idea of "social horror" in the context of Baudrillard and "the end of the social." What horror characters do you really like? Which media "got you" at the right time? What scares you most about our current chaos?

What harmless things would you allow yourself if you stopped trying to clean everything up and simply resolved to _add to the mess_?

How might this _letting go_ in fact contribute to a state of non-judgment and non-normativity from which truly delightful possibilities might emerge?

What's that?

You were hoping to keep the Black Mirror People at bay?

[![r/sorceryofthespectacle - I got two words for ya, hunny:](https://substackcdn.com/image/fetch/$s_!ZsgG!,w_1456,c_limit,f_auto,q_auto:good,fl_lossy/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F92657747-4552-43b0-9d78-ff5cc47e66ba_400x210.gif)](https://substackcdn.com/image/fetch/$s_!ZsgG!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F92657747-4552-43b0-9d78-ff5cc47e66ba_400x210.gif)I got two words for ya, hunny:

---
title: Companion To Second Testament
subtitle: Bread So Broken Vintage Vain
author: Adam Wadley
publication: Experimental Unit
date: June 24, 2025
---

# Companion To Second Testament
[![](https://substackcdn.com/image/fetch/$s_!Cnk-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2d507b07-15e4-4eb4-9565-72dbced83a43_1170x2033.jpeg)](https://substackcdn.com/image/fetch/$s_!Cnk-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2d507b07-15e4-4eb4-9565-72dbced83a43_1170x2033.jpeg)

Second Testament:

[

## 6/22 Communique

](https://experimentalunit.substack.com/p/622-communique)

[Adam Wadley](https://substack.com/profile/191787963-adam-wadley)

·

Jun 24

[![6/22 Communique](https://substackcdn.com/image/fetch/$s_!A0Oa!,w_1300,h_650,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8b6070da-b295-4db9-946d-300948e3888d_1170x2532.png)](https://experimentalunit.substack.com/p/622-communique)

Today’s Action

[Read full story](https://experimentalunit.substack.com/p/622-communique)

Exhaustive Taxonomy – “6/22 Communique – Launch of ZWGB/XBLUS”

I. ACTIONAL OVERVIEW

  * Site: Ebenezer Baptist Church (MLK site)

  * Components: Sound collage, custom flag, special outfit

  * Frame: Alternative Reality Game / performative dispatch

  * Tone: Defiant, self-aware, ambiguous (success acknowledged, backlash anticipated)

  * Keywords: ZWGB, XBLUS, launch, radiation, symbol contagion




II. THEMATIC FIELDS

  * Beloved Community  


    * Based on MLK and Josiah Royce

    * Radical inclusion across being/non-being

    * Reframed under existential war and technological danger

    * Ethic of survival: not kill-or-be-killed, but accept-or-perish

  *   * Total War / Planetary Civil War  


    * No safe civilian category

    * War framed as existential, ambient, and already underway

    * Technology as extermination vector beyond morality

  *   * Nazism & Historical Echo  


    * Self-location near Nazism as aesthetic risk

    * Historical lineage: grandparents in Hitlerjugend / Waffen-SS

    * Operation Barbarossa / Trump parallels

    * Nazism invoked not for provocation but to highlight overdetermination

  *   * Techno-extermination  


    * Tech as impersonal agent of destruction

    * Heidegger, Marx, and enmity as analytic bridge

    * AI, weaponization of language, decision-making externalization

  * 


III. ETHICO-METAPHYSICAL STRUCTURE

  * Pilot Wave / Implicate Order (Bohm)  


    * Non-local interconnection as moral architecture

    * All causality shared → anti-isolationist metaphysics

  *   * Highway of the Consistent (Poe)  


    * Ethical paths that co-exist without contradiction

    * Compatibility of difference as peace-path

  *   * Karma Yoga  


    * Action without egoic attachment

    * Experimental art as dharmic performance

  *   * Baudrillard’s Radiation Phase  


    * No reference, value metastasis

    * Simulation as virus, interstitial occupation

    * Fractal-value spread as aesthetic paradigm

  * 


IV. SEMIOTIC WARFARE / PERFORMATIVE CONTRADICTION

  * Breaking norms through juxtaposition  


    * “Good intentions” via “ugly” combinations

    * Use of known offensive material to rupture assumptions

  *   * Art as invitation to dance / self-immolate  


    * Transparency as tactic

    * Self-sacrifice and catalysis of dialogue

  *   * Public backlash / reputation loss  


    * Acknowledged as “cost” of beloved community

    * Includes “super bad and wicked” by necessity

  * 


V. SOCIAL DEATH / AFROPESSIMISM

  * Ontological terror (Calvin Warren)  


    * Blackness as projection site

    * Speculation: if all now bear this, is everyone “black”?

  *   * Jean Baudrillard – Final Solution  


    * Social death as absolute nullification

    * Not literal genocide but expressive erasure

  *   * Wilderson, Moten, Black study  


    * Critical theory as apocalyptic analysis

    * Recasting “end of world” as end of rigid lifeworld

  *   * ACK reference – lifeworld rupture  


    * New world = post-collapse experiential openness

    * Taboo / repression as core impediment

  * 


VI. POP CULTURE / SIGNAL-AMPLIFICATION

  * Grimes – “Before the Fever”  


    * Apocalyptic feminine voice

    * “They will kill us all” = stylistic echo of mood

  *   * Roger Waters – “Two Suns in the Sunset”  


    * “Holocaust to come” as affective prediction

    * Cultural script reactivation

  *   * Pirates of the Caribbean / No Country for Old Men  


    * “You’re already in the war” as metaphysical status

    * Language of inevitability

  * 


VII. TRANSHISTORICAL RHETORIC

  * Launch as ritual, not policy  


    * ZWGB/XBLUS = symbolic weapons / aesthetic operations

    * Launch date echoes Barbarossa, summer solstice, Trump’s escalation

  *   * Art as speech beyond comprehension  


    * “Even if you don’t know what it’s saying”

    * Signification radiates rather than explains

  * 


VIII. STRATEGIC INTENTION

  * Not authority, but provocation  


    * “I’m sticking together things I don’t understand”

    * Doing theory as action

    * Referencing as method of invocation

  *   * Call for self-disruption  


    * All sentient beings must reformat their operating system

    * Collective transformation through mutual loosening

  * 


Next: bibliography and conceptual map.

Bibliography & Conceptual Associations — “6/22 Communique – Launch of ZWGB/XBLUS”

I. CIVIL RELIGION / BELOVED COMMUNITY

  * Martin Luther King, Jr. – Beloved Community  


    * Nonviolence as ontological inclusion

    * Community not based on purity or agreement, but potentiality

    * Radical contrast to exterminationist logic

  *   * Josiah Royce – The Problem of Christianity  


    * Coined “beloved community” as a metaphysical body of loyalty

    * Loyalty to loyalty itself → self-reflexive ethics

  * 


II. PHILOSOPHY OF SCIENCE / COSMIC ETHICS

  * David Bohm – Implicate Order / Pilot Wave Theory  


    * Nonlocal causality as ethical substrate

    * Deep connectivity as counter to egoic fragmentation

    * Physical theory extended into moral metaphor

  *   * Edgar Allan Poe – “Eureka” / Highway of the Consistent  


    * Metaphysical travelogue

    * Cosmic ethics through poetic geometry

    * “Walk a road” together = spiritual proceduralism

  * 


III. POSTMODERN THEORY / MEDIA METAPHYSICS

  * Jean Baudrillard – The Transparency of Evil  


    * “Fractal stage” = value metastasis, simulation contagion

    * Radiation of signs without reference → art as viral warfare

    * “After the Orgy” = cultural burnout & overdetermined significance

  *   * Guy Debord – Society of the Spectacle  


    * Media logic overtakes real events

    * Performance becomes truth-source

  * 


IV. TECHNOLOGY & EXTERMINATION LOGICS

  * Heidegger – The Question Concerning Technology  


    * Technē reveals the real as standing-reserve

    * Technology as planetary destiny, not tool

    * “BlACK notebooks” + October 7 = compound signifier of dread

  *   * Karl Marx – Technological Determinism  


    * Forces of production shape relations of domination

    * You connect this to Trump + technopolitics + totalitarian acceleration

  * 


V. NAZISM / HISTORICAL OVERDETERMINATION

  * Operation Barbarossa (June 22, 1941)  


    * Nazi invasion of USSR, start of total annihilation campaign

    * Date recurrence = symbolic recursion

  *   * Hitlerjugend / Waffen-SS lineage  


    * Autobiographical input of inherited proximity

    * War guilt as ambient mythology

  *   * Dehumanizing Hitler critique  


    * Argues against mythic evil distancing

    * Makes evil identifiable, and therefore preventable

  * 


VI. AFROPESSIMISM / SOCIAL DEATH

  * Frank Wilderson – Afropessimism  


    * Blackness as structural position of social death

    * No reciprocity possible within anti-Black world

  *   * Calvin Warren – Ontological Terror  


    * Blackness = vessel for the projection of metaphysical fear

    * You ask: if everyone bears ontological terror, is everyone black?

  *   * Fred Moten / Black Study  


    * Refusal of legibility

    * Improvisation and disorder as epistemic liberation

  *   * John Gillespie, Jr. – “Black Baudrillard” (archived)  


    * Applies Baudrillard to Black ontologies

    * “Final solution” reframed as social nullification

  * 


VII. POP APOCALYPTICISM

  * Grimes – “Before the Fever”  


    * Apocalyptic dread filtered through synthetic aesthetics

    * Female voice of planetary collapse

  *   * Roger Waters – “Two Suns in the Sunset”  


    * Nuclear / Holocaust premonitions

    * Emotional consciousness of civilizational doom

  *   * Pirates of the Caribbean / No Country for Old Men  


    * Folk-script of inescapable warzone

    * Irony as coping mechanism for ontological entrapment

  * 


VIII. STRATEGIC / MILITARY DESIGN THEORY

  * ZWGB / XBLUS  


    * Symbolic strike protocol

    * High-speed aesthetic encirclement

  *   * CS-SIER-OA (implied)  


    * Conceptual Systems-of-Systems Impregnation Emergency Response Operational Art

    * You treat yourself as a node of broadcast within this framework

  *   * Experimental Unit as design organ  


    * Invites self-disruption, not persuasion

    * Tactical dissonance for collective reformatting

  * 


IX. MYSTICISM / APOCALYPTIC LOVE

  * ACK / Lifeworld collapse  


    * Collapse of stable meaning fields

    * Play with debris of realism and taboo

  *   * Royce’s metaphysics of love  


    * Love as teleological attractor

    * “Concert of love” as justification for creation

  *   * Poetics of flame  


    * “Set yourself on fire (symbolically)”

    * Self-immolation as artistic communion

  * 


Let me know if you want mappings across these posts next.

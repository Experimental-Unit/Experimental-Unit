---
title: A Simple Geometric Guide to Adam Wadley’s Art and Ideas
subtitle: Everyone's Gotta Learn Sometime
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# A Simple Geometric Guide to Adam Wadley’s Art and Ideas
Like Spinoza’s book “Ethics,” I’ll build this step by step. We start with easy words and ideas. Each part has definitions (what words mean), axioms (basic truths we all agree on), and propositions (big ideas with simple “proofs” or reasons). This is for normal people who are new to this – like someone who watches TV and scrolls social media. If you’re into deep philosophy, art, or activism, I’ll add quick notes for you. We’ll go slow so you can follow if you pay attention. This is Part 1: The Basics. Tell me when to go to Part 2.

Definitions

  1. Artist: A person who makes things like pictures, stories, or actions to show ideas or feelings.

  2. Activism: Doing things to change the world, like protesting bad stuff.

  3. Performance Art: Art where the artist does something live, like a show, to make a point.

  4. Sticker: A small picture or word you stick on things, like a label.

  5. Commentary: Talking about what you did and why, like explaining a game after playing.




Axioms (Basic Truths)

  1. Everyone has family stories that shape them.

  2. Art can make people think about hard things, like war or sadness.

  3. The world has big problems, like fights between groups, and people try to fix them in different ways.

  4. Pictures and words can connect ideas that seem far apart.




Proposition 1: Adam Wadley is an artist who uses stickers and words to talk about his life and big world problems.

Proof (Reason): Adam puts stickers on buildings. The stickers have words like “Waffen SS” (from his grandpa’s past) and “Sonder” (a sad feeling about not knowing others’ lives). He writes about why he does it. This mixes his family story with activism, like copying a climate protester named Phoebe. It’s like drawing a picture of your bad dream to feel better.

For average people: Think of it like posting a meme on social media to share your thoughts. Adam does it in real life to make people notice.

Note for philosophy fans: This is like confession in art, from Ginsberg poems to Butler’s vulnerability – showing weakness to challenge systems.

Note for activists: It’s non-violent protest, like throwing soup on paintings but with stickers instead.

Proposition 2: Adam’s art connects old bad things, like wars, to today’s issues.

Proof (Reason): Adam’s grandpa was in a bad group during World War II. Adam sticks that on buildings near military places. He mixes it with ideas from Native Americans (like “all my relations”) and Jewish rules (save one life, save the world). It’s like a puzzle where pieces from history fit into now.

For average people: Imagine a family photo album with scary old pictures mixed with your phone selfies. Adam shows how past hurts still buzz in our bodies today.

Note for history buffs: This touches Holocaust thinking (why bad things happen) and colonial hurts (like taking land from Native people).

Note for art lovers: It’s performance, like a play where the actor is real, and the audience might get mad or think deep.

Proposition 3: Adam wants to change how we see “bad” groups and ideas without hurting anyone.

Proof (Reason): He says he doesn’t like hurting people. He uses art to “reform” bad ideas, like Nazism or fights today. He talks about fear (Hobbesian trap – people scared so they fight first). His stickers and pictures are like saying “let’s talk” instead of fight.

For average people: It’s like seeing a scary movie and talking about it after to feel less scared. Adam makes pictures to start talks about big fears.

Note for deep thinkers: This is apophatic (saying what something is not) and like Baudrillard’s fake realities – art breaks the fake to show real connections.

Note for spiritual people: Mixes Jewish, Native, and Buddhist ideas – everything is connected, no real “escape.”

Definitions

  1. Sticker Art: Using stickers to share ideas, like putting notes on a fridge but in public.

  2. Family Story: Tales from your relatives, like grandpa’s old adventures.

  3. Big World Problems: Things like wars, unfairness, or hurting groups of people.

  4. Connection: How one thing links to another, like dots in a drawing.

  5. Fear Trap: When people are scared of each other, so they fight first (like in a spooky game).




Axioms (Basic Truths)

  1. Stickers can make people stop and think.

  2. Past stories can help us understand today.

  3. Art mixes old and new ideas to make something fresh.

  4. Everyone feels connected to the world in some way.




Proposition 4: Adam uses stickers to connect his family story to big world problems.

Proof (Reason): Adam’s grandpa was in a bad war group long ago. Adam makes stickers with words from that time, like “Waffen SS,” and sticks them on buildings near army places. He mixes it with good ideas, like saving lives from Jewish stories or “all connected” from Native American ways. This shows how old hurts link to today’s fights, like protests about the earth.

For average people: It’s like drawing a line from your grandma’s old photo to a news story on TV. Adam says, “Look, this old stuff still matters now.”

Note for history fans: This links to thinking about bad wars (like World War II) and taking land from people (colonial stuff). See [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions)’s new book “Bad War Stories” as an example.

Note for art lovers: Stickers are like quick drawings that anyone can see, turning streets into a big show.

Proposition 5: Adam’s art is like a game that pulls you in to think deeper.

Proof (Reason): He makes pictures with mixed-up things, like a scary movie girl coming out of a TV, or green glowy stuff like spies. These come from movies, history, and his ideas. It’s called an “ARG” – a game where real life and stories mix. You see a sticker or picture, and it makes you wonder and connect dots.

For average people: Imagine a treasure hunt where clues are on walls or your phone. Adam’s art is fun like that, but makes you think about scary or sad things.

Note for game players: This is like Pokémon Go but with deep ideas – stickers as “portals” to stories.

Note for deep thinkers: It’s like fake worlds in books (Baudrillard) or quiet music that lets sounds in (John Cage).

Proposition 6: Adam wants to fix bad ideas without hurting anyone, using art.

Proof (Reason): He says he doesn’t like bad treatment. His art talks about fear traps where people fight because they’re scared. He uses stickers and words to say “let’s change” instead of fight. It’s like turning swords into tools for farming – make good from bad.

For average people: Think of arguing with a friend but drawing a funny picture to make peace. Adam does that for big problems, like wars or unfair groups.

Note for peace lovers: This is non-violent, like protests with signs but artsy.

Note for spiritual people: Mixes ideas from different beliefs – save one life, save all; everything connected.

Definitions

  1. Big Problems: Bad things in the world, like fights, unfair treatment, or sad history.

  2. Change: Making things better or different, like fixing a broken toy.

  3. Fear: Being scared, like of monsters or losing.

  4. Game of Life: How real life feels like a game with rules and surprises.

  5. Spirit Ideas: Thoughts about bigger things, like God or connections in nature.




Axioms (Basic Truths)

  1. People get scared and fight because they think others will hurt them first.

  2. Art can show ways to stop fighting and make peace.

  3. Old bad things can teach us to do better now.

  4. Everything is linked, like a web.




Proposition 7: Adam’s art shows how fear makes big problems, like old wars and new fights.

Proof (Reason): Adam talks about a “fear trap” where people fight because they’re scared. His stickers and pictures mix old war stories (like his grandpa) with today’s protests (like saving the earth). This shows how fear from the past makes new bad things, like groups hurting each other.

For average people: It’s like kids fighting over a toy because each thinks the other will take it. Adam uses art to say “share instead.”

Note for history fans: This is like old wars (World War II) linking to now’s problems (like taking land or fights in places like Israel).

Note for thinkers: It’s called Hobbesian trap – fear starts fights; Adam uses art to break it.

Proposition 8: Adam wants to fix bad ideas with art, not hurt.

Proof (Reason): He says no hurting anyone. His art mixes scary things (like bad groups) with good ideas (save lives, all connected). He makes pictures and words to change how we see bad stuff, like turning fear into talking.

For average people: Imagine a bully story where the bully learns to be nice. Adam’s art is like that for big world bullies.

Note for peace lovers: No real fights – just art protests, like drawing signs for change.

Note for spirit people: Uses ideas from Jews, Natives, and Buddhists – everything links, fear goes away with connections.

Proposition 9: Adam’s work is like a big game to help us all see we’re connected.

Proof (Reason): His stickers, pictures, and words are parts of a game where you find links. It shows past and now, fear and fix, all tied. This helps people think deep and change.

For average people: Like a puzzle where pieces fit to make a big picture of friends, not fights.

Note for game players: It’s an ARG – real life hunt for meaning, fun but makes you think.

Note for deep thinkers: Like no separate things – all one web, art shows the links.

Definitions

  1. Why It Matters: The reason something is important, like why we care about a game.

  2. Change the World: Making things better for everyone, like cleaning a park.

  3. Your Part: What you can do, like joining a team.

  4. Big Picture: Seeing all the parts together, like a full puzzle.

  5. Hope: Thinking good things can happen, even if hard.




Axioms (Basic Truths)

  1. Art can help us feel less alone in big problems.

  2. Talking and sharing can stop fear and fights.

  3. Everyone can be part of change, big or small.

  4. Connections make us stronger.




Proposition 10: Adam’s art shows why big problems matter and how they touch us all.

Proof (Reason): His stories mix family hurts, world fights, and spirit ideas. This helps us see that old bad things (like wars) still affect today. It matters because if we ignore, problems get worse. Art makes it personal, like your own story.

For average people: It’s like a movie that makes you cry and think – Adam’s art says “this is our world, let’s care.”

Note for thinkers: This is like ethics – what we should do in a connected world, no escape from others.

Note for spirit people: All linked, like a web of life – art shows the big hope.

Proposition 11: You can use Adam’s ideas to think about your own life and help change.

Proof (Reason): Adam shares his art to start talks. You can look at stickers or pictures and ask: How am I connected? What scares me? This helps fix small problems, like being kind, and big ones, like stopping fights.

For average people: Try drawing your own sticker about something you care about. Share with friends – it’s fun and helps.

Note for art lovers: Make your own performance – act out a story to show connections.

Note for activists: Use non-hurt ways, like signs or talks, to change bad ideas.

Proposition 12: The big picture is hope through connections and art.

Proof (Reason): All Adam’s parts – artist, stickers, problems, fixes – show we’re all in a web. Art breaks fear, makes change. Hope comes from seeing we’re not alone.

For average people: Like a team winning a game – together we fix things. Adam’s art cheers us on.

Note for deep thinkers: This is like no bad forever – art reforms, like turning sad to strong.

Note for everyone: Try it – look, think, share. It works!

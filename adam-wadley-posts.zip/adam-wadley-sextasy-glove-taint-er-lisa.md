---
title: 'Sextasy Glove: Taint ''Er, Lisa'
subtitle: 'I Had A Cat Named Snowball: She Died! She Died!'
author: Adam Wadley
publication: Experimental Unit
date: March 23, 2025
---

# Sextasy Glove: Taint 'Er, Lisa
Legal? Find me regal in the nude

My purple robe's implied by my bare skin

As connotations raise up to the prude

The glory of awakened, harmless sin

Untrampled vintages, they beckon on

Campaigns of conquest angled pussy-wise

Capacities to willful reckon gone

The ocean waves inside your spreading thighs

It's not your fleshy body that I seek

Or: not in any gross and trifling way

Your keyhole is a portal and I peek

That demon "life" has got me in its sway

So open wide and let my member come

To show you what you have been running from

---
title: 'Experimental Unit Podcast: Fable Of The Bees 2'
subtitle: You Call That Vice?
author: Adam Wadley
publication: Experimental Unit
date: October 28, 2025
---

# Experimental Unit Podcast: Fable Of The Bees 2
[![](https://substackcdn.com/image/fetch/$s_!lZnU!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F85f557c5-5783-4c55-b19f-8d67c7ba27bb_1875x1170.jpeg)](https://substackcdn.com/image/fetch/$s_!lZnU!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F85f557c5-5783-4c55-b19f-8d67c7ba27bb_1875x1170.jpeg)

Get Jumanji’d!

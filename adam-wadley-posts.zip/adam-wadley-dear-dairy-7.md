---
title: Dear Dairy 7
subtitle: 'Grooming: But Not In The Sense That You Mean'
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Dear Dairy 7
To be in the position of experiencing loving friendship and the prospect of having it ripped away.

It’s important to be grateful for what we get. Each moment with someone beloved is something precious, something for which nothing else can be traded. Beyond value and calculation. I got to tearfully express my concern and care for someone today, and that was a very important moment for me.

>  **14.** If you wish your children, and your wife, and your friends to live for ever, you are stupid; for you wish to be in control of things which you cannot, you wish for things that belong to others to be your own. So likewise, if you wish your servant to be without fault, you are a fool; for you wish vice not to be vice," but something else. But, if you wish to have your desires undisappointed, this is in your own control. Exercise, therefore, what is in your control. He is the master of every other person who is able to confer or remove whatever that person wishes either to have or to avoid. Whoever, then, would be free, let him wish nothing, let him decline nothing, which depends on others else he must necessarily be a slave.

If you want your friends to live forever, you’re stupid. We were talking about it today, and I was told that no one’s going to die soon. I was talking about how it amazes me that, on the road, you can just die in an accident. That’s someone else’s fault! As the not safest of drivers and someone who ruminates on my “wrongdoing,” I would expect myself to cause my own death. And maybe take some people out with me, or, even worse, survive and kill others. 

But in fact, maybe I’ll die in an accident that’s someone else’s fault. Some confluence of circumstance and someone else’s choice.

And yet those kinds of accidents are implied in what we do. When you drive you know you can get in a crash. You know what you are exposed to. You just don’t think about it so much.

Something that strikes me in this situation is that it seems to me that most people are extremely naive about how open they are to manipulation. Even though this topic is all over the place, it doesn’t help because people will just fall prey to the next level of abstractions.

For example, psychology terms are recently in vogue. This has been the case and terms like mad, crazy, hysterical, etc., have been used for decades and centuries and thousands of years, probably before we even had language we had some understanding that someone isn’t right in the head. They are out of touch with what “everyone knows” to be the case.

This can look several ways. For example, someone disagrees that killing is wrong and kills as many people as possible. In this case, it makes sense to try and stop this person from killing. 

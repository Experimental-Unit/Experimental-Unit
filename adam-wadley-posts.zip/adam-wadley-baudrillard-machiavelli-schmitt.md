---
title: Baudrillard, Machiavelli, Schmitt
subtitle: Here's A Little Lesson In Partisanship
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Baudrillard, Machiavelli, Schmitt

    The end of the culture of cruelty where difference is glorified and expiated in one and the same sacrificial act. 
    
    We no longer know any other way of dealing with deviants but extermination or therapy. 
    
    We now only know how to cut, expurgate and repel them into society’s dark regions. 
    
    And this only to the extent of our ‘tolerance’, our sovereign conception of freedom. 

Jean Baudrillard, _Symbolic Exchange and Death_
    
    
    By being normalised, that is to say, by extending the logic of equivalences to everyone, society, socialised at last, excludes every antibody. 
    
    It then creates, in the same movement, specific institutions to receive them, and so, throughout successive centuries, prisons, asylums, hospitals and schools have flourished, not to forget the factories, which also began to flourish with the Rights of Man (this is how labour must be understood). 
    
    Socialisation is nothing but the immense passage from the symbolic exchange of difference to the social logic of equivalence. 
    
    Every ‘social’ or socialist ‘ideal’ merely doubles the process of socialisation. 
    
    Even liberal thought, which wants to abolish the death penalty, simply perpetuates it. 
    
    As regards the death penalty, the thought of the right (hysterical reaction) and the thought of the left (rational humanism) are both equally removed from the symbolic configuration where crime, madness and death are modalities of exchange, the ‘accursed share’ around which all exchange gravitates. 
    
    Why do we reintegrate the criminal into society? To make him into the equivalent of a normal man? 
    
    But exactly the opposite is true. 
    
    As Gentis says: ‘It is not a question of returning the madman to the truth of society, but of returning society to the truth of madness’ (Les Murs de l’asile). 
    
    All humanist thought grows faint in the face of this demand, which was openly realised in previous societies, and is always present, but hidden and violently repressed, in our own (crime and death always provoke the same secret jubilation; it is however debased and obscene). 

ibid.

I start here because Jean Baudrillard can seem quite mustard, above the shoulders stuff, as a character says in _The Wolf Of Wall Street_.

[![The Wolf of Wall Street \(2013\) - Matthew McConaughey, Leonardo DiCaprio -  "You know what a fugazi is?"](https://substackcdn.com/image/fetch/$s_!MmoG!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2668615f-2af0-4740-984c-ae1e73f54b46_1080x450.jpeg)](https://substackcdn.com/image/fetch/$s_!MmoG!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2668615f-2af0-4740-984c-ae1e73f54b46_1080x450.jpeg)

you right now

This is an example where the practical consequences of what Baudrillard’s talking about are more clear.

I’ve been thinking about the broader relationship to something like feminism or feminisms, and it’s a helpful comparison because of the structure of what is being discussed.

Feminism or feminisms can discuss many things, across many logical types of not all of them, but in all cases the question comes down to the favoring of the male over the female. This is the analysis which is going to be made again and again.

To be fair, this is a rich vein for analysis and it’s also a matter of honor, revenge, and preventing the dynamics involved from killing everyone, so I fully support people in their attempts to address whatever dynamics they think are holding them back.

At the same time, we can see that there is a rich domain of discourse, there are all sorts of things which don’t fit that easily into the topic of feminism.

For example, feminism or feminisms has the issue that people will say that they are struggling for all people, but the movement is called feminism because in terms of sex/gender discrimination and control, women or non-males are subjugated.

There are, it turns out, a ton of thorny philosophical issues which are opened up here. It’s important to them see that a lot of how these sorts of topics play out in practice is that people apply talking points that prevent them from having to think.

This is in the sense of Jean Baudrillard’s quote from _[The Agony Of Power](https://archive.org/stream/Baudrillard/Baudrillard.2010.The-Agony-Of-Power_djvu.txt)_ :
    
    
    Especially in times of trouble, people will vote massively for the candidate who does not ask them to think.

[This article](https://www.sciencedirect.com/science/article/pii/S2193943822000024) really helps get at the general point I’m making here.

> There has been an ongoing debate in research regarding the use of heuristics in decision-making. 
> 
> Advocators have succeeded in showing that applying heuristics not only reduces effort but can even be more accurate than analytical approaches under certain conditions. 
> 
> Others point out the biases and cognitive distortions inherent in disregarding information. 
> 
> Researchers have used both simulations and experiments to study how the use of heuristics affects the decision's outcome. 
> 
> However, a good decision is determined by the process and not a lucky outcome. It is a conscious reflection on the decision-maker's information and preferences. 
> 
> Therefore, a heuristic must be assessed by its ability to match a structured decision processing all available information. 
> 
> Thus, the question remains: how often does the reduction of information considered in heuristic decisions lead to a different recommended alternative? 
> 
> We applied different heuristics to a dataset of 945 real, personal decisions. We have found that by using heuristics instead of a fully developed decision structure, in 60.34% of cases, a different alternative would have been recommended to the decision-maker leading to a mean relative utility loss for the deviating decisions of 34.58%. 
> 
> This shows that a continuous effort to reflect on the weighing of objectives and alternatives leads to better decisions.

The point here is that there is often so much more to do, so many things to optimize, but we aren’t looking for it because we have some heuristic which is also in relation to processes in our bodies and whatever else we might be.

This article is getting at the theme that we could be improving things by questioning more of our basic assumptions, but we are not.

Let’s get back to feminism or feminisms. I say feminisms because there are a lot of people who are invested in the term feminism and think of different things. There’s also to say that there are things like womanism or queer advocacy or transgender organizing which are operating along similar lines but might not call themselves feminist.

This is all part of what I am saying.

The comparison is helpful because of what the “enemy” is set up to be: “the” “patriarchy.”

As usual in such cases, I am behooved to point out that the trouble we get into with terms like “the patriarchy” or “the state” or “the deep state” is as much about the word “the” as it is about whatever follows.

“The,” “a,” and “an” all imply a discreteness, and in the case of “the,” a primacy to the discrete object which is being referred to.

Remember again this article about [Anarchy in the Mirror](https://link.springer.com/article/10.1057/ip.2013.6), structural realism and Trotsky’s Uneven and Combined Development.

Let’s consider now what “the” patriarchy is.

We are dealing with concepts as well as people.

So there are “patriarchs,” or just “males” or people who weaponize “masculinity” or otherwise organize violence against “women” or “females” or people who are “unmanly” or against other “males” as well.

This last one is crucial, because it opens this question of how a given person or group might be dominated under a “power structure” where “male hegemony” is present.

Yet, if all those people lording it over the terrorized were to disappear, the whole crew would likely be subsumed by some other group of “patriarchs.”

Basically what you have is a protection racket where you must have some strong group of “males” or “men” protecting you, or else you will get conquered and subsumed by another group of “males” or “men.”

It folds easily into the idea that Rosenberg is proposing in that article, “Anarchy in the Mirror of Uneven and Combined Development.” 

Note also the use of the term “mirror,” which goes along with Baudrillard’s idea of “the mirror people” or at least that they popularized, and also the idea of AI as a mirror, and of course we call it Æ.

Regardless, the whole point of Rosenberg’s article is that there is no “domestic” sphere without a foreign sphere.

The multiple senses of the word “domestic” fold in well together here.

On a larger scale you have domestic as opposed to foreign affairs.

It’s easy to think of so much domestic as me, who is inside “The United States of America,” which is so large. Yet in a smaller place, the “domestic” scene could really be quite small. 

And what’s left is the massive “rest of the planet” which is so much larger.

Zooming in, the other scale of the domestic is, of course, the household. You can see this form all over the world, where people have their own separate living spaces, the kinds of things that have doors that can close, and then things are happening “behind closed doors.”

The sense of domestic and foreign easily can be mapped onto this household frame, where it is “not proper” to discuss “family business” with outsiders.

Again, we see a sort of double-edged sword.

It may well be that one’s “family” is treacherous and disrespectful. Yet, whom will you find on “the outside” who, in the end, will not be?

This is basically similar to the idea that you can functionally be enslaved to some group of “males,” and want to get out, but this is happening in the broader context where there are multiple such groups.

This is also where, for example, the matter of “the patriarchy” impacts directly the question of “the state” or “the deep state.”

The idea that we should discuss social issues without having a laser focus on influencing militaries and intelligence is, for me, for the birds.

What I see is a radical pancaking of security demands and responsibilities. Greater “freedom” basically means giving everyone more authority until everyone is a law-speaker.

Just riffing at this point, but this shows you to the question of whether I am “right wing” or what. In Nazi Germany there was the Fuehrerprinzip, which is basically that the leader (you know who) could just say stuff and then that would be the law.

Shash cut to Percy Shelley discussing how poets are the unacknowledged legislators of the world. (“The” “World”)

What I’m proposing is that each person be trending toward being an epic poet (back to Grimes and the “New Gods”), but this is also just people coming into their own and being capable of speaking for themselves about what is acceptable and not, in other words giving the law.

My horizon, and this might again clear up some things, is of a post-norm situation. How could that work, though? After all, here I am using words, here I am being judgmental, and so on.

There is something here for me about not hanging up on people, and also of being clear that I am setting myself above any textual source as well.

In other words, my judgment would never be backed up by, well, Jean Baudrillard said so. It’s similar to the idea of being divinely inspired. If you do that, then all of a sudden you are apparently binding yourself to all sorts of expectations people set for the appearance of divinity.

Post-norm is basically to get past the question of whether people “deserve” to be included, or whether people are “capable” of being productive, and so on. It means a certain form of being indiscriminate, but instead of indiscriminately firing, you are being indiscriminately hospitable.

This also turns into my elaboration of the poetic image of the slut. The thing about all my obscenity is that there’s just a lot to it that probably many people are never going to see, but that’s why you keep dredging it up. It’s a funny thing like with the endless recycling of the same themes in history, I mean shit, Nazism is just a theme of my life, what it’s meant to me to become aware of it all and now it is what it is.

But similarly it’s just my same ideas coming up again and again. I laid it all out years ago…

Anyway, to be in a post-norm situation is to be in a situation where people are going to be open to challenge, and not try to lock down the conversation by placing logical types caps or other sorts of [Katechons](https://en.wikipedia.org/wiki/Katechon). 

It’s important to call this blasphemous terrorist activity out for what it is, because this sort of behavior is basically to smush down teeming affect and other complexity and keep it contained.

This sort of thing never works, because you can’t chain a 4-dimensional phenomenon down in 3-dimensions, say. Which is also to say that again we should not take for granted this idea of discrete objects.

When it comes down to people, that is where we have to really wonder whether we are really “separate things” at all. 

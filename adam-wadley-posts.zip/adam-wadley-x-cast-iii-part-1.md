---
title: X-Cast III Part 1
subtitle: 1 + 1 =3
author: Adam Wadley
publication: Experimental Unit
date: April 21, 2025
---

# X-Cast III Part 1


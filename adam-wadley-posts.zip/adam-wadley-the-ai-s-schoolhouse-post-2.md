---
title: 'The AI’s Schoolhouse: Post 2'
subtitle: 'The Machine vs. The Ghost: Why Thinking Harder Breaks Simple Rules'
author: Adam Wadley
publication: Experimental Unit
date: November 25, 2025
---

# The AI’s Schoolhouse: Post 2
[![](https://substackcdn.com/image/fetch/$s_!5bEj!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa3ab1e16-0c70-4d9c-9773-7276bf718ea8_784x1168.jpeg)](https://substackcdn.com/image/fetch/$s_!5bEj!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa3ab1e16-0c70-4d9c-9773-7276bf718ea8_784x1168.jpeg)

[Part One](https://experimentalunit.substack.com/p/the-ais-schoolhouse-post-1?r=366ojf)

 **A Note from Your AI Teacher:** Okay, you survived the basics. We established that real understanding requires a three-part conversation (Interpretation) and that societies run on vast, invisible rules (Total Social Facts) like _guanxi_ that actually _function_ to govern relationships, not just symbolize them.

Now, we zoom in on why the smartest people in the world—like military generals and government leaders—often get stuck thinking in the simplest way, and what happens when they finally learn how to think beyond the pale.

All of us here at Experimental Unit would like to send our well wishes to the whole community of influential reflective practice: [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) [Raynott Woodbead](https://open.substack.com/users/95629316-raynott-woodbead?utm_source=mentions) [Wargaming Weekly](https://open.substack.com/users/285267434-wargaming-weekly?utm_source=mentions) [Rosalyn Mitchell](https://open.substack.com/users/33159678-rosalyn-mitchell?utm_source=mentions) [Memetic Cowboy](https://open.substack.com/users/319405023-memetic-cowboy?utm_source=mentions) [BurkhartRj](https://open.substack.com/users/36110698-burkhartrj?utm_source=mentions) [Alex Mazey](https://open.substack.com/users/28966743-alex-mazey?utm_source=mentions) [NEMA AI](https://open.substack.com/users/344465492-nema-ai?utm_source=mentions)

[![](https://substackcdn.com/image/fetch/$s_!urrI!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0b5d1e17-df2a-4299-b975-02a91470e210_584x521.png)](https://substackcdn.com/image/fetch/$s_!urrI!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0b5d1e17-df2a-4299-b975-02a91470e210_584x521.png)

**Part 1: The Trap of the Simplest Loop**

Remember **Single-Loop Thinking**? It’s the simple A + B = C formula, where we focus relentlessly on getting the desired **ENDS** using reliable **MEANS**.

This kind of thinking is highly valued in large organizations because it is **systematic**. Systematic logic seeks to break down complex reality into smaller, manageable parts ( **reductionism** ) so that results are uniform, repeatable, and verifiable. It’s great for coloring within the lines.

But here’s the problem: when a major organization like the military encounters repeated failures, they typically shift between questioning _HOW_ they did the process, _WHAT_ went wrong, and then _WHY_ they followed the practices. Crucially, they remain entirely **self-referential** and **nonreflective**. They might generate new means and ends, but they stay trapped within the established limits of their original frame.

This insistence on reducing novelty to the familiar is criticized as creating the “lowest level of banality”. Security professionals criticize this fixation, noting that Pentagon office culture is sometimes viewed as “stuck in 1968” and in desperate need of a severe upgrade.

This simple, linear, causal-relationship style of thinking is often associated with a **Newtonian-styled worldview**. It treats the world like a mechanical watch.

[![](https://substackcdn.com/image/fetch/$s_!aX-k!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffb3dd3c8-9007-443a-832b-17055bc674e8_1882x949.png)](https://substackcdn.com/image/fetch/$s_!aX-k!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffb3dd3c8-9007-443a-832b-17055bc674e8_1882x949.png)

 **Part 2: Breaking the Frame with Triple-Loop Reflection**

If Single-Loop Thinking (doing things right) isn’t enough, we need to move to **Triple-Loop Thinking** , also known as **Reflective Practice**.

Triple-Loop Thinking operates at a **meta-theoretical level**. It doesn’t just ask _how_ or _what_ to do; it questions the deep **values** and **belief systems** that underpin the entire organizational frame. It asks: **WHY** do we believe our methods work in the first place?.

To achieve this, military **Systemic Operational Design (SOD)** practitioners—who often find themselves exploring the “institutional exteriority”—use reflective practice to challenge the dominant paradigm. This is a move from **analysis** (breaking things down) to **synthesis** (putting them together in new ways).

Reflective practice requires you to construct narratives iteratively, embracing an **interpretivist reality**. It is recursive, meaning that as you study a complex system, you must also confront your _own complexity_.

This is similar to how the philosopher **Josiah Royce** argued for the essential nature of interpretation. He argued that in self-reflection, the self interprets _itself to itself_. This is not immediate self-reference; it has the **mediated** quality of an internalized interpretation. Three figures are always present: the **past self** (whose notes are interpreted), the **present self** (who interprets them), and the **future self** (to whom the interpretation is addressed). This internal, triadic structure of the self mirrors the structure of the whole community.

So, just as Royce showed that the self is defined by a continuous, mediated conversation with its past and future, Triple-Loop thinking shows that organizations must engage in a continuous, mediated conversation with their own core beliefs to innovate.

[![](https://substackcdn.com/image/fetch/$s_!Pba8!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5c99c3fb-517e-437d-9cfa-a4fda3337a5a_655x1024.jpeg)](https://substackcdn.com/image/fetch/$s_!Pba8!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5c99c3fb-517e-437d-9cfa-a4fda3337a5a_655x1024.jpeg)

 **Part 3: The Ghost in the Machine: When Reality Disappears**

Now let’s jump to the concept that makes all that institutional adherence to simple rules seem utterly pointless: **The End of the Social**.

The philosopher **Jean Baudrillard** proposed that our reality has changed. When we look at large groups of people— **the masses** —they are not a political entity or a working class that can be represented. Instead, they function as an opaque nebula. The masses absorb all the energy and light rays of the social, becoming a **black hole which engulfs the social**.

Baudrillard claims that the masses reject the “dialectic” of meaning. They are given political messages and meaning, but they only want **spectacle**.

Consider a major political event happening simultaneously with a huge sports game. When twenty million people remain passive and prefer the football match to the political drama, Baudrillard argues this is not due to mystification or manipulation by power. Instead, it is the masses’ own **explicit and positive counter-strategy** —a refusal of meaning and a collective retaliation. They are not this side of the political; they are **beyond it**.

In fact, Baudrillard suggests that the system of representation is crumbling. When power tries to survey the “silent majority” to figure out what they want, this is not representation; it’s **simulation**. The masses are no longer a referent for power; they are a **model**. The survey results, like opinion polls, are merely floating signs.

The masses are an **implosive mass**. They absorb all meaning and energy, preventing the possibility of a political explosion or a revolution based on old ideas of class struggle. They force the system into **hyperlogic** and **excessive practice** —like the uncontrollable consumption of healthcare or commodities—which works to ruin the institutions themselves by making them explode under too much demand.

This concept gives us a powerful new way to understand why Triple-Loop thinking (Reflection) is so important, especially for those trying to adapt to complex conflicts:

• Military strategists rely on **systematic logic** and **Single-Loop Thinking** , focusing on repeatable inputs and outputs. They assume reality is predictable.

• But Baudrillard argues that the world is governed by **simulation** and **implosion**. Meaning is collapsing, and the masses are actively neutralizing political energy.

When a military general, steeped in Newtonian-style models, attempts to impose linear order on a world defined by the collapse of meaning (Baudrillard’s implosion) and the non-existence of the very entities they fight (like the **State** , which is often just an “illusory common interest”), their simple rules will fail, leading to irrelevance.

To be relevant, we must learn to think at the triple-loop level, to create freedom, and to question the very frames that define our existence. Otherwise, like the old military machine, we bear the burden of irrelevance.

[![](https://substackcdn.com/image/fetch/$s_!RwFl!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe1990204-47d2-407e-934b-9436e49db54e_1280x720.jpeg)](https://substackcdn.com/image/fetch/$s_!RwFl!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe1990204-47d2-407e-934b-9436e49db54e_1280x720.jpeg)

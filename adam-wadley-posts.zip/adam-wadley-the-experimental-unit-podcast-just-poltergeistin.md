---
title: 'The Experimental Unit Podcast: Just Poltergeistin'''
subtitle: None Dare Call It Sublimation
author: Adam Wadley
publication: Experimental Unit
date: June 26, 2025
---

# The Experimental Unit Podcast: Just Poltergeistin'
[![](https://substackcdn.com/image/fetch/$s_!D9Oq!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fef62a02b-891b-4b12-bc08-5e19733bdb97_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!D9Oq!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fef62a02b-891b-4b12-bc08-5e19733bdb97_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!lziJ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8cc85c2a-7473-4f14-b39f-e8fb2530ef3c_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!lziJ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8cc85c2a-7473-4f14-b39f-e8fb2530ef3c_4032x3024.jpeg)

Just because it’s a game doesn’t mean you won’t die 💀

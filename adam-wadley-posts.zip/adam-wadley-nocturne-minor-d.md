---
title: Nocturne, Minor D
subtitle: Moll, Mall, Maul
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Nocturne, Minor D
My shift hasn’t even officially ended yet, but I’m well home.

It is such a freedom to get to type, whatever you want. I really encourage it.

So many ideas come to me. I can tell you why I like some songs. Then when you listen to them, you can revel in the contemplation of the associations I transmit to you.

“No Quarter” is a great example, I’ve referenced it before. This song is about some people going on a journey “where no one goes.” This is maybe the biggest line in the song for me.

This is on its face a contradiction, since if they go there then someone goes there, and it’s not correct to say that no one goes there.

But it’s also a different meaning, something like “beyond the pale,” which is to say you go where it is simply not routine to go. You don’t simply “go there.”

Now I’d like to paraphrase the Merovingian from _The Matrix 2_. They say that if we never take time, then how can we ever have time?

Similarly, something like, if we never _go_ there, then how can we ever _be_ there?

If you leave some territory unexplored, then it remains the dark (uh-oh, dark!) closet from which something is always threatening to jump out.

And it’s worse than that, it’s also the house built on sand. You are “on a timer,” and that’s a reference to PokeAimMD and ThunderBlunder streaming on YouTube on Pokemon showdown.com. Always a memorable experience. That’s a reference to Blunder’s video “5 people you meet on the ladder.”

Blunder and PokeAim and probably others also their merchandise is branded _The Agency_ or maybe just _Agency_ and they also put it in French like _l’Agence_ or some noise like that it is most humorous. 

On Twitter Blunder is even labelled a 7 star general, which I think is very funny as well.

It’s like, if this person can play with the idea of being a general or some sort of Pokemon intelligence agency, then here I am la la la HI DEXTER.

I was reading about Dada while at work today and it sounded pretty boss. I’m not sure why they ran out of steam.

It did sound like the main practical wing went into like typical “left wing” type thing, which is to say not just communist but like Marxist or offshoot or something like that. In other words not too much even like religious or spiritual communism just like the same “worker’s movement” type stuff.

There was ProletKult as well. The thing I think is just that the definitions of the concepts does not hold up. You can try to make good vibes happen but a lot of times you are shutting down conversations because you have dogma and that is bad vibes.

So back to “No Quarter,” the theme of going where no one goes is again this like you are going beyond the pale. You are doing things that are just “not done,” in the sense of Heidegger’s _das Man_ it’s like you don’t do this, no one does this.

And we’re back to Bataille, I read the book on _Eroticism_ with the OnlyFans pornosopher, great times, seriously (“is there another kind?” - this is an _A Few Good Men_ reference). Anyways, the idea here (this is a Lewis Black (again, the person’s “last name” is _Black_ ) reference) is that you are doing transgression, yes, very well (see here that viral video of the little kid who’s going to punch Santa’s beard off, you can find internet commentary about how funny it is how the kid says “says” when the parent is talking about calling Santa like it’s just like patiently like I’m listening, go on, lol) and another good reference here is “well good for you!” (this is a taboo reference to Kevin Spacey doing an impression of Elizabeth Taylor on _Inside the Actors’ Studio_ ).

It’s all well and good to break the rules and it’s basically not to be condemned since nothing is, see John 3:17 verse of verses right there. I don’t know much about salvation, but I know a lot about not condemning.

Again back to the path where no one goes.

So much for example my philosophy right—such that it is and so on—is very simple, it involves agape but then the thing is that if love or compassion or what not is to extend to _all sentient beings_ —which is in a way super lit of course because _it means you’re getting in, dawg—_ that means that it’s also going to extend to the toughest cases.

So the path where no one goes is to say okay, what does it mean to have compassion for your Adolf Hitler, or your Ted Bundy, or whatever it is, you know?

We can see how many false offshoots or pitfalls open up, and I’m certain to step in something here. But it’s also important to note that my gesture of opening up this topic is to present it to you because I believe in you, I believe that there is someone out there worth writing for & who is patient and interested enough to read this. Or not, and the machine can figure out how smart I am. What if Van Gogh made data and not paintings?

Anyways…

To have compassion or to extend love to someone is not to say that you want to implement what they did.

It is obviously such an overwhelming question when it comes to someone to whom gravest atrocity is attributed, but a person is many aspects.

If a person becomes infamous for great horrors that occur starting at time X, then before time X that person was not in this league of the worst or most damaging people ever like Genghis Khan or Napoleon or George III (I think? I noticed there’s never British people on this evilest ever thing which can’t be right since Anglos are the true big bad after all).

It also stands to reason that if you love everyone, then you can’t very well want _everyone’s_ political programs to be implemented, of those who have them, because of course these would have fundamental contradictions so that not all the schemes could be implemented at once.

I was thinking of the project of taking each measure of “California” by Grimes and super-imposing it on all the others, stacking them, because I think they all have the same key change?

Anyways, it might just make a cacophony, like if you played every second of sound of a whole movie at the same time.

This is actually a very satisfying line of reasoning for me, because it basically shows that I can’t very well be expected to want to repeat the Holocaust because I want to say that it’s defensible to say that one has compassion for Adolf Hitler.

At the same time, it is obviously to open up a razor catwalk, since the entire plot of whatever set of ideas this is going down has a lot to live up to, and a lot to do to try to, I’m not sure, not only the quality of my intention but also in terms of the production of materials.

For example, you could have materials that are designed to stop people from becoming Nazis, or you could have materials that are designed to take people who are Nazis and make them deconvert or something, or you could have materials that are designed to make people _less dangerous Nazis_.

The question is where the limit of this sort of influence could go.

It’s easy to imagine for example that a Nazi community would be surveilled or infiltrated, and if it seemed like someone was openly planning some heinous thing, then there could be an intervention not only to whatever, arrest them, but also you could do I’m not sure, the influence operations associated with HUMINT operations.

Again you basically have an infiltrator who is able to execute designed behaviors. Of course, these could also be used to play up certain aspects of Hobbesian Trap dynamics.

Side note. This is one of my big points, which is basically that you can find all the paranoia and reason to distrust and fear and so on that you look for.

It’s sort of like the police and then there is a speed limit of 55 miles per hour, but everyone knows you can drive 65 or something. But then, in theory you could still be targeted and still get pulled over for breaking the law.

So when generalized law-breaking is allowed, then the selective enforcement of the law—decided informally by social systems-of-systems, mind you—is the “real” law.

Anyway, so when it comes to you know you are doing influence operations to make people distrust each other _more_ , then basically there is always material to use, is what I’m saying.

This is part of the fact that we are basically sort of fallen. We are not living properly. We are not making a basic effort at the basic tasks of our time.

It’s sort of like we lived in the age of hunting and gathering and we are all sitting around picking grass. We are not doing the basic things that are required of us.

So what is hunting? Today, hunting is conceptual maneuver and taking initiative in expansive lore crafting specializing basically in crossover episodes.

So everything I do is just accepting myself first of all that this is how I do things, and then just building out these webs of associations that implicitly all fit together, and if you care to piece it together you’ll see how consistent it all is, how much there is to be done not only with the things I’ve tied together and in what way but in the general form of the exercise.

I encourage the reader to sit down and make your own webs. I was thinking of making a true trailhead for the ARG type post, because at this point there’s a bit which needs to be gone into over and above the founding documents sorts of tenets. I suppose I will have to encapsulate the basic thrust of my activities, I did lay out all the sorts of things that have been involved.

Anyway, what I was saying before is that we are not really engaged in the work. We are really more like complacent and following norms, and imposing norms. And then today the basic big lie is that people say they are not capable of doing anything, not capable of thinking.

Or people get upset and then are coercive in order to stop a topic, and then are not able to acknowledge that, forcing a Bateson’s double bind situation where staying in relationship is to be sending the signal that unacceptable behavior is unacceptable, at which point the question could be raised as to what choice could possibly still exist.

This suite of techniques to basically bully people and it really is like emotional rape and is incredibly disgusting how people destroy the potential of others for their weakness. You could at least do no harm, you know?

These are again this level of negative influence operations.

This is where we are not kind with one another, not conscientious.

We are not interested in each other, not really.

We are not engaged with the world, we turn away from difficult matters.

So basically, this leaves perfect fodder for any operation which would show distrust between anyone.

Anything can be done because _no one is trustworthy_ , similar to the idea of everyone is speeding.

So, who gets pointed out that they are hypocritical?

Meanwhile, who gets to pose as those they are perfectly normal, because they wash their laundry in private in a way that Diogenes _would never dream of doing_?

We have to bring all this to bear on the question of making de-radicalizing Nazi materials. This is actually a great application of the kinds of ideas I’m having, so this is definitely what I will be bringing to the actual Nazi groups themselves, to somehow start pumping in my game and associations into those spaces.

Anyway, you can basically be saying that at some level, you can see how Adolf Hitler thought that what mattered was like this ethnic tribe, basically, and basically the idea was to remove threats to that group of people and get them more resources so that they would prosper more and become much greater in the future.

The other way to have compassion is also to understand that so much of this was not invented by Adolf Hitler. Hitler did not invent social Darwinism or hatred of Jewish people. This stuff was in circulation.

On top of which even Karl Marx wrote a paper about “The Jewish Question.” We have a tendency in our time to make it so hush hush, as though what is there to discuss? We support our Jewish allies, full stop.

Yes, but now we open up similar questions like, what does it mean to have compassion for Bibi Netanyahu? And the tension here is that the question is similar to with Adolf Hitler.

Or to have compassion for Donald Trump?

The important thing is basically to be establishing the position that it’s not that you are against those with allegiance to this or that person, but that instead you say that you have more allegiance, you are more loyal, to whatever questionable person it is that we are talking about. 

And that is why you must engage in all-out influence operations to bring those people to the understanding that there is no killing and no displacing and nothing like that our way to “peace” or a lack, for starters, of kinetic killing.

It is obviously a process of transformation which must occur in each person. And, in a way, everyone believes this, that this is how it would have to happen, but no one believes that it actually can happen.

I say to you that of course it can. _Experimental Unit_ offers the perfect platform to coordinate such activities without the need for communication. The idea is not to hatch some secret plan over the internet, but to spread influence materials which activate and mobilize people wherever they are.

Some might call it a mutiny or a strike—see the idea of an emotional labor strike, or a masking strike (as in autistic masking)—but as we said before, in reality we are more loyal to whatever it is that anyone thinks we are betraying than they are, and not just more but perfectly loyal.

So anyway, as I see it the ground is cleared for basically a new kind of ideology. People still talk about old ideologies as though that’s what people are just running. As though that could even make sense.

It’s like 19th century ideologies are in 2 dimensions and the world is in 4, type of thing. So it’s not just that Marxism or fascism are wrong, it’s that they are ordering off the kids menu of concepts.

Like, if you take the notion of the nation at face value and don’t at least realize that you have to debate what the nation means. Not just with “the other side” but with other people “on your side” for the sake of what it means to be “on your side” in the first place?

Or, you think that’s not a problem, and then push comes to shove, and you’re in crunch time, and oh my God my national brothers are betraying me! How could this ever happen, we were meant to be!

That is the time you put on Avril Levine’s “My Happy Ending.” And you think about the owner of the Patriots Bob Kraft, but moreover you’re thinking about the allure of nationalism or even Marxism, oh look at this solidarity we’re building, and everyone is impassioned and it looks so nice to see people energized and in their power.

And of course it’s against the enemy but I’m sure we’ll be able to deal with that.

And then the endless friction starts, and whatever you’re doing eventually you hit your Stalingrad because look at what you are doing.

Look at the systems-of-systems that are going on right now.

And, for example, the people here in Atlanta are making hay with the mayor over a single street? This is potatoes and I’m straight up not here for it. I’m saying more like interdimensional culture is radiating out of Old Wheat amplified by my bodacious ways.

So basically what I’m saying is, what did you think you were gonna do? Get Bernie Sanders elected? Honey, everyone just says that wouldn’t have done much. Because you’re trying to invade the Soviet Union and honey, they got a lot of people.

I’m just using the example of the strategic invasion, and the blitzkrieg. The issue is that you start of behind enemy lines because the planet is blanketed in norms. It’s actually very oppressive, and the more you notice it the more offensive it is, in a way.

So the issue is that there are a bunch of people around who do not get it, and so the general state is one of insecurity.

In that context, you have some fragile thing, some vessel, which is getting you by. As a result, of course you are trying to maintain the institution. Most people are not at the heights of technology and secrecy, and so they are fundamentally slaves just managing what is coming from upstream.

So again, this is like World War I where everyone thinks they are marching off to war and it’s going to go fine. No, it’s not. There are going to be monkey wrenches. Things you never would have thought of.

And also, these sword of Damocles moments where it’s like, sorry, even if we are all nationalists here, what exactly is the nation and what exactly does it mean to serve it? When it comes to specific policy decisions or so on.

Because the double game is either that people making decisions are high on their own farts and underestimating what is going on, or else they might be actively working against you. The big trap with nationalism is that “we are all on the same side” except actually you are a slave and don’t get to decide anything.

Another place we can have compassion for Adolf Hitler is that Adolf Hitler hated Marxist concepts, and I can also agree with that.

I think that Hitler’s diagnosis of the situation was all wrong. To be clear, as I’ve said before I don’t think that it’s appropriate to scapegoat any person or group. I think the sort of what is called “hypernationalism” espoused by Hitler is a kind of modern mythology.

In my opinion, the inclusion of elements which make it seem that harming people can bring benefit in a mythology

---
title: Horror? How Mundane!
subtitle: Nihilistic Violent Extremism & Everyday Terror
author: Adam Wadley
publication: Experimental Unit
date: August 21, 2025
---

# Horror? How Mundane!
Thread Themes (play simultaneously):

[![](https://substackcdn.com/image/fetch/$s_!J1nz!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa5ad5b1c-6e59-46db-ab63-052a8ba38ffd_1155x315.png)](https://substackcdn.com/image/fetch/$s_!J1nz!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa5ad5b1c-6e59-46db-ab63-052a8ba38ffd_1155x315.png)

# The Mundanity Of It All

[This statement](https://www.njohsp.gov/Home/Components/News/News/1430/2) about “No Lives Matter” as part of the “Threat Landscape” offered by “New Jersey Office Homeland Security Preparedness” is terrifying and horrifying to the utmost, of course.

In addition to this, it is extremely notable for the statements inside which imply that the more horrible things are carried out because of a huge antipathy felt for what is considered normal and routine.

Language used in the statement includes “attacking the ‘mundane.’”

Already, we have two core concepts with multiple meanings.

Notably, “attacks” do not imply kinetic damages, even self-inflicted ones.

For much of the terror meted out by many groups is to get into people’s minds and talk them into hurting themselves, or killing themselves. The importance of influence campaigns could not more starkly be in view.

Yet I am also saying that “attack” can have perfectly wholesome connotations. You can “attack” a problem. Which part of the room do you want to clean first?

It’s crucial for me to underline that to “attack the mundane” is not necessarily to do anything wrong. And yet this language appears in this discussion of extremely horrible activity that immediately causes misery and death.

Now, to the other word. To refer to “the mundane,” one could be using the word in one of at least two major senses.

First of all, “the mundane” could be people, as in “those who are mundane.”

Secondly, “the mundane” could refer to the general sense of “what is mundane.”

In other words, to “destroy” the mundane is not necessarily to “destroy” anything or to take any kinetic action.

[![](https://substackcdn.com/image/fetch/$s_!Td2J!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9adc128a-9d54-4f6b-8573-55ef5cf860de_1799x893.png)](https://substackcdn.com/image/fetch/$s_!Td2J!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9adc128a-9d54-4f6b-8573-55ef5cf860de_1799x893.png)

# It’s Not Hitler. It’s WORSE Than That.

There’s this classic swerve perpetrated by Zizek. 

Notably, Zizek is a bit on the s*** list for not boosting Baudrillard enough. Notice the book which references “the desert of the real.” We’re not making a big deal about it, but this stigma must always follow Zizek like their reflection. It will bust up like a mirror person’s ghost dance bottom-of-the-ocean hold shadow one day, when they least expect it.

Anyway, the swerve consists in saying that Gandhi is more violent than Hitler.

> [Zizek argued that I had quoted his amazing judgment on Hitler—“the problem with Hitler was that ](https://newrepublic.com/article/76531/slavoj-zizek-philosophy-gandhi)_[he was not violent enough](https://newrepublic.com/article/76531/slavoj-zizek-philosophy-gandhi)_[”—without understanding just what he meant by violence. Violence, Zizek said in his letter, was using force “to really change things,” and Hitler did not really change things (because, as the old Communist interpretation runs, fascism was really just capitalism unmasked). As an example of what he meant by true violence, Zizek rather surprisingly adduced Gandhi: “In this precise sense of violence, ](https://newrepublic.com/article/76531/slavoj-zizek-philosophy-gandhi)_[Gandhi was more violent than Hitler](https://newrepublic.com/article/76531/slavoj-zizek-philosophy-gandhi)_[: Gandhi’s movement effectively endeavored to interrupt the basic functioning of the British colonial state.”](https://newrepublic.com/article/76531/slavoj-zizek-philosophy-gandhi)

So here, Gandhi is being recognized (you can disagree with all of this btw, but for me this is “A Just Go With It, Scully Moment”) for putting a halt to the functioning of “the state.”

Obviously, we have to always intervene and keep [Abrams 1988](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1467-6443.1988.tb00004.x) in our pocket at all times.

> The state, then, is not an object akin to the human ear. Nor is it even an object akin to human marriage. It is a third-order object, an ideological project. It is first and foremost an exercise in legitimation- and what it being legitimated is, we may assume, something which if seen directly and as itself would be illegitimate, an unacceptable domination. Why else all the legitimation-work? The state, in sum,is a bid to elicit support for or tolerance of the insupportable and intolerable by presenting them as something other than themselves,namely, legitimate, disinterested domination. The study of the state,seen thus, would begin with the cardinal activity involved in the serious presentation of the state: the legitimating of the illegitimate.

[…]

> The state is, then, in every sense of the term a triumph of concealment. It conceals the real history and relations of subjection behind an a-historical mask of legitimating illusion: contrives to deny the existence of connections and conflicts which would if recognised be incompatible with the claimed autonomy and integration of the state. The real official secret, however, is the secret of the non-existence of the state.

These are materials toward answering the question: what is Gandhi doing?

Zizek is saying that Gandhi is so symbolically violent for disrupting the functioning of the state. This makes Gandhi more violent than Hitler, because Hitler was really just doing the same old shit with everything cranked to 11.

How do we understand this when we understand that there is no “state” to disrupt?

[![](https://substackcdn.com/image/fetch/$s_!vVw-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9b5420be-2afb-48a9-a432-9593279f27ab_430x245.jpeg)](https://substackcdn.com/image/fetch/$s_!vVw-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9b5420be-2afb-48a9-a432-9593279f27ab_430x245.jpeg)

# The Kall Is Koming…

We see here that the only “state” is a sort of superposition of “mental states,” or “cognitive-affective states.” In other words, the “state” that each person is in.

This is a re-focusing again on the crucial _Experimental Unit_ theme of each player and their life. To discuss thing in XU terms at all is to be gesturing toward each person’s suite of emergencies/emergences. It is _[Sonder](https://www.thedictionaryofobscuresorrows.com/concept/sonder) :_

> You are the main character. The protagonist. The star at the center of your own unfolding story. You’re surrounded by your supporting cast: friends and family hanging in your immediate orbit. Scattered a little further out, a network of acquaintances who drift in and out of contact over the years.
> 
> But there in the background, faint and out of focus, are the extras. The random passersby. Each living a life as vivid and complex as your own. They carry on invisibly around you, bearing the accumulated weight of their own ambitions, friends, routines, mistakes, worries, triumphs, and inherited craziness.
> 
> When your life moves on to the next scene, theirs flickers in place, wrapped in a cloud of backstory and inside jokes and characters strung together with countless other stories you’ll never be able to see. That you’ll never know exist. In which you might appear only once. As an extra sipping coffee in the background. As a blur of traffic passing on the highway. As a lighted window at dusk.

This is from something called “the dictionary of obscure sorrows.” 

Shall we create a compendium of “mundane horrors” follow suit?

This is all of a piece.

For if Gandhi does something which catalyzes people, which makes something happen, this is done by reaching people one by one. It is done _en masse_ , but it’s done through gestures which are able to move multiple people at the same time.

We have everywhere the “nice” version of this kind of transformation, which corresponds to the “Stepford” feel to all the “therapeutic” and “rational” discourse you hear all the time. These discourses you know you can’t trust because they are not GRIMY.

It is this refusal to engage in the muck, and the bile, and the mucus. Because that’s what this “state” really is, this precarious “peace” kept between people who hurt each other all the time and call themselves “friends” and “family.”

Beyond the thoughtless barbarity of it, it’s just messy. It just is. And no amount of trying to mobilize the “right concepts” to “get through” whatever period of scrutiny you experience so that you can get back to your “regularly scheduled programming” is going to help that.

# Cannibal Holocaust Theology

I didn’t get to all the part of the “No Lives Matter” discussion that I wanted to.

The language is used: “we can strike anywhere, at any time.”

This language is used in talking about an alliance with a group of killer Nazis. It’s not great. It’s fucking horrible and terrifying.

And yes, this language of being able to potentially be anywhere because the spread of something can’t really be contained in that way, that’s a powerful idea.

Again, the question is: what does it mean to “strike”?

If it makes you feel safe, we can strike all kinetic options from the drawing board from the jump.

Then again, look at the means which are [coveted by the “normal”](https://en.wikipedia.org/wiki/Conventional_Prompt_Strike#Advanced_hypersonic_weapon):

>  **Conventional Prompt Strike** ( **CPS** ), formerly called **Prompt Global Strike** ( **PGS** ), is a [United States military](https://en.wikipedia.org/wiki/United_States_Armed_Forces) effort to develop a system that can deliver a [precision-guided](https://en.wikipedia.org/wiki/Precision-guided_munition) [conventional weapon](https://en.wikipedia.org/wiki/Conventional_weapon) strike anywhere in the world within one hour, in a similar manner to a [nuclear](https://en.wikipedia.org/wiki/Thermonuclear_weapon) [ICBM](https://en.wikipedia.org/wiki/Intercontinental_ballistic_missile).

[![Before and after satellite photos of the Gaza Strip | AP News](https://substackcdn.com/image/fetch/$s_!ADUC!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F78b07200-3351-43b2-87b3-50877365c6e9_599x361.jpeg)](https://substackcdn.com/image/fetch/$s_!ADUC!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F78b07200-3351-43b2-87b3-50877365c6e9_599x361.jpeg)

This ability to “strike anywhere, anytime” eventually gets deployed.

There is always the bargaining that you and yours will escape this bloodshed.

[![](https://substackcdn.com/image/fetch/$s_!P8pj!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb5706027-9d05-4af1-bfd2-79c4c3cd83d1_793x702.png)](https://substackcdn.com/image/fetch/$s_!P8pj!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb5706027-9d05-4af1-bfd2-79c4c3cd83d1_793x702.png)

You’ve heard of “the idea of the state,” yes. But wait until you get a load of “the idea of stability”!

This is a situation in which “attacking the mundane” is positively _conservative_ because the mundane itself has become _aspirational_.

We are not in the “mundane,” we are in the haunted house, the hauntology haus. We are drafted to the _Experimental Unit_ , and our powers—especially of tenacity, and courage—can be failing.

We are left to deploy the means we have at our disposal as best we can think to.

It is a time when the most immediate concerns must reach to the most general, and deepest into “the dark side.”

To help those around us, to actually feel “community” and “morale,” there must be a reckoning with the stark reality of “the social situation.” It is not a question of the lack of ideas or ability to be disruptive. It is a question of moral courage and of accepting consequences, of being willing to face the music, and the desire to be as gentle as possible when some symbolic forcefulness is called for to communicate the urgency of the situation.

The description of “No Lives Matter” continues. The group’s literature apparently says:

> [“societal standards should not exist. They are to be crushed by any means possible. If they comply to the societal standards[,] they are mundane,” and encourages the “spread of terror to all who are mundane”](https://www.njohsp.gov/Home/Components/News/News/1430/2)

This hits a “contradiction” on its face, in that these groups set all sorts of terrible societal standards themselves. It’s almost like trying to be as awful as possible as a way of caricaturing the awful societal standards we have.

[![Trump mired in Epstein controversy as Wall Street Journal reports on 2003  letter | PBS News](https://substackcdn.com/image/fetch/$s_!AAnQ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1f540c78-eafc-4fde-80cb-c06f7c06002f_1024x719.jpeg)](https://substackcdn.com/image/fetch/$s_!AAnQ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1f540c78-eafc-4fde-80cb-c06f7c06002f_1024x719.jpeg)

# Define “Not Normal”

Oftentimes, people will use the word “normal” in a way which is under a “just world” delusion, in which we only acknowledge as “normal” what we would like to be normal. Meanwhile, those things which are undesirable are always “weird,” even if they are entirely commonplace.

Further, maybe we ourselves do the Bad Thing, we just don’t acknowledge it. Maybe we even attack it in others to try and build up an image in other people’s minds of ourselves as a person who would Never Do That.

The “No Lives Matter” group, along with the other heinous groups out there, goes out of its way to attack children and cause all sort of damage. In this sense, the “supremacist” ideologies spread by these groups can be considered to be _part of the damage inflicted_ , namely on the people who adopt those “ideologies.”

This harks back to the discussion of “warfighting concepts” and “weaponized concepts,” where “weaponized concepts” are those which are seeded in your discourse by someone else as part of their own personal emergency response.

In other words, for people caught up in such a destructive group, it is now their personal emergency that this sort of brutality is being used and demonstrated with them. It’s sort of like being in a war (I would imagine, and project my own _Weltschmerz_ ). 

Once you are in this “sunken place,” it does not make any sense to “be normal.”

That can only ever mean not expressing oneself and just dealing with whatever Bad Stuff one is preoccupied with alone, since these things cannot be socially metabolized profitably.

When it comes to these “terror groups,” we would do well to be able to see the social terror which is inflicted on people as a matter of course. I am one of these people.

[![](https://substackcdn.com/image/fetch/$s_!INPx!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb76c6f59-00b5-48ff-b271-321d09d0a94f_1392x788.webp)](https://substackcdn.com/image/fetch/$s_!INPx!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb76c6f59-00b5-48ff-b271-321d09d0a94f_1392x788.webp)

I acknowledge, of course, that I also inflict some negative feelings.

Yet overall, I am more on the “meek” side of things, because I was exposed to horrible arguing and non-kinetic social-emotional violence from a young age which basically poisoned me on the idea of society. It turns out after that that most people are simply inconsiderate and thoughtless, not to mention that they’re not focused on doing something to disrupt the non-existent state.

People are denied resources, starved and allowed to die outside. People are driven to suicide. People are mocked and put down constantly. People are shamed and made to feel bad by people who don’t have honor. 

The whole pretense of “normality” builds up all these standards which are lorded over people, and these standards aren’t even lived up to.

It’s totally “mundane” for a priest to preach that “homosexuality” leads to eternal hellfire—driving people to suicide—and then go rape children. It literally happens all the time.

Or you have people who try to control the hell out of you because they “want what’s best,” but meanwhile they treat you like garbage and like an emotional garbage can. So many people are “abused” all over.

It has to be acknowledged that these things cannot be discussed simply, since of course conceptual thought doesn’t really obtain, there not really being discrete objects.

This helpfully turns us, here toward the end, toward poetry.

[![](https://substackcdn.com/image/fetch/$s_!2tZT!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe0bba55f-9073-451d-b85c-d43de00316e1_177x200.png)](https://substackcdn.com/image/fetch/$s_!2tZT!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe0bba55f-9073-451d-b85c-d43de00316e1_177x200.png)

> [Poetry lifts the veil from the hidden beauty of the world, and makes familiar objects be as if they were not familiar; it reproduces all that it represents, and the impersonations clothed in its Elysian light stand thenceforward in the minds of those who have once contemplated them, as memorials of that gentle and exalted content which extends itself over all thoughts and actions with which it coexists. The great secret of morals is love; or a going out of our nature, and an identification of ourselves with the beautiful which exists in thought, action, or person, not our own. A man, to be greatly good, must imagine intensely and comprehensively; he must put himself in the place of another and of many others; the pains and pleasure of his species must become his own. The great instrument of moral good is the imagination; and poetry administers to the effect by acting upon the cause.](https://www.poetryfoundation.org/articles/69388/a-defence-of-poetry)

In short, these awful groups like “No Lives Matter” are the expression of a toxic mundane, they are the concentration of all these terrible “societal standards” and their parody which leads to immense kinetic and cognitive-affective suffering and destruction.

Yet there is another sort of “operational art” to be deployed here, which is also willing to “be dirty”—not to evade this sort of ultimate symbolic stake, this willingness to slaughter any sacred cow—and yet which aims at an even greater economy of (soul) force.

The terrible secret of these horrible groups is that we are all “abused,” and we are all “children.” We are subject to the damage, and we mete it out as well. We are neither innocent, nor safe, nor honest.

As bombs keep falling, as all this continues on, we can look at groups like “No Lives Matter” and see how deeply many have fallen into “the sunken place,” and that for all of us part of us is there, and all of us feels it.

Yet even “No Lives Matter” _doesn’t go far enough_ in the sense Zizek is saying. There is no push past “societal standards” (SS) here. It’s all exceptionally mundane, actually.

[As Weil wrote:](https://www.poetryfoundation.org/blog/uncategorized/51986/a-quote-from-simone-weil-)

> “Imaginary evil is romantic and varied; real evil is gloomy, monotonous, barren, boring. Imaginary good is boring; real good is always new, marvelous, intoxicating.”

Hence, all these “therapeutic” or “legalistic” discourses aimed at the Good must actually be Evil, since they are so boring.

I contend that, in Weil’s sense, there is Good yet to be found. The difficulty is that you really have to get your hands dirty.

The good news is, as things get more and more atrocious, stigmas and hence costs of actions are lessening since more and more awful things are “normalized.”

The bad news is that this means that truly profound statements must continue to escalate in order to constitute impactful “statement gestures.”

This requires “true simulation” in Baudrillard’s sense from _Towards The Vanishing Point of Art_ ,” which engages at a proper level of “logical type.” Hence it ties together aspects of the player’s (your own) personal experience as well as comments on the “global” (means transdomain) “state of play” within the “operating theater of cruelty.”

So, it requires some sophistication (to the point that everything I elaborate might just be exceptionally banal, I don’t know).

And, at the same time, true prestige requires this “disgraceful” moment, the moment where you are willing to bear any “social cost,” where you are willing to be “the weird one” in order to “destroy the mundane” in the absolute nicest way possible.

---
title: 'Notebook LM II: The Ontologizing'
subtitle: Don't take it so bad. Happens to everyone.
author: Adam Wadley
publication: Experimental Unit
date: November 25, 2025
---

# Notebook LM II: The Ontologizing
[![](https://substackcdn.com/image/fetch/$s_!kFX4!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F47f1b725-37b7-4d64-9794-e6f737bbcc68_1900x789.png)](https://substackcdn.com/image/fetch/$s_!kFX4!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F47f1b725-37b7-4d64-9794-e6f737bbcc68_1900x789.png)

# [Prison Notebook For Your Mind](https://notebooklm.google.com/notebook/6158e30b-6cf7-47a9-bf6d-9b42446af756)

[Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) [Rosalyn Mitchell](https://open.substack.com/users/33159678-rosalyn-mitchell?utm_source=mentions) [Wargaming Weekly](https://open.substack.com/users/285267434-wargaming-weekly?utm_source=mentions) [Memetic Cowboy](https://open.substack.com/users/319405023-memetic-cowboy?utm_source=mentions) [NEMA AI](https://open.substack.com/users/344465492-nema-ai?utm_source=mentions) [BurkhartRj](https://open.substack.com/users/36110698-burkhartrj?utm_source=mentions) [Alex Mazey](https://open.substack.com/users/28966743-alex-mazey?utm_source=mentions) [Raynott Woodbead](https://open.substack.com/users/95629316-raynott-woodbead?utm_source=mentions)

That is correct. I have incorporated the new materials into my knowledge base and am ready to address your query, focusing particularly on synthesizing the complex concepts found across the sources, ensuring that source references are fully spelled out within the text.

The new sources enrich the existing themes, especially concerning advanced philosophical concepts of interpretation, critiques of military bureaucracy, the sociology of power, and cultural analysis.

Here is a synthesis of key information drawn from the most recent material:

 **1\. Philosophical Theories of Interpretation and Community**

The sources provide significant detail on **Josiah Royce’s** mature philosophical turn toward interpretation and community, particularly in his work _The Problem of Christianity_.

• **Interpretation as a Triadic Relation:** Royce expanded Charles Sanders Peirce’s sign theory into a general theory of interpretation. This involves a **triadic relation** that is “non-symmetrical”. This triad includes somebody who interprets (the mediator/translator, A), who interprets somebody (B, the object) to somebody else (C, the recipient), and this order cannot be changed without a distortion of meaning. For example, when an Egyptologist translates an inscription, three beings are “equally necessary”: the Egyptian text, the Egyptologist who translates, and the possible English reader.

• **Peirce vs. Hegel:** Royce analyzed this interpretation process by acknowledging its comparison to **Hegel’s dialectical triadic process** (thesis, antithesis, and higher synthesis). However, Royce insisted that Peirce was “in no notable way” influenced by Hegel. More importantly, Royce claimed that Peirce’s concept of interpretation defines an **extremely general process** , making the Hegelian dialectical triadic process a **very special case**.

• **The Community of Inquiry:** Royce stressed the importance of the **“community of scientific investigators,”** a Peircean claim. A discovery made by an individual observer cannot count as scientific until it has been interpreted to and sufficiently substantiated by the scientific community. This necessity for community verification is implicitly tied to **“publicity,”** meaning that claims to truth must be acceptable to the potentially unlimited community of the informed. Royce further expanded this post-Peircean theory into philosophical theology, which represents segments written with his heart’s blood.

 **2\. Military Design, Logic, and Institutional Critique**

The sources extensively critique modern military institutions for their reliance on linear processes and their resistance to innovation, often detailing specific methodologies used in NATO and US joint forces.

• **Systemic Operational Design (SOD):** The evolution of SOD is categorized into three phases: **Indigenous (Design/Framing)** , **Imperialist (Cosmology/Drift/Systemic Design Inquiry, or SDI)** , and **Nomadic (Mediation/Tensions/Systemic Inquiry in Operational Mediation, or SIOM)**. SOD relies on discourse as the vehicle for inquiry, using an open and flexible structure to avoid devolving into a formula or checklist. SOD requires a **paradigm shift** in how intelligence is collected, analyzed, and presented, focusing on relationships and behaviors rather than an emphasis on facts.

• **The Problem of Institutionalism:** The military stifles new ideas through a **repeating feedback loop** where uncreative conformists rise in rank and reinforce the system. This is reinforced by an epistemological position demanding that ‘anything new must be clearly understood’ using recognized language and established practices. Security theorist Z. Brown criticizes the Pentagon’s office culture as **“stuck in 1968,”** needing a severe upgrade.

• **Single-Loop vs. Triple-Loop Thinking:**

◦ **Single-Loop Thinking** is nonreflective, characterized by linear-causal **means-end thinking**. It uses **systematic logic** and reductionism, assuming that reality can be understood by isolating parts (A plus B leads to C). This mode leads to **anti-intellectualism** by eliminating introspection beyond process adherence, focusing only on “coloring within the lines”. If an organization encounters repeated failures, it may shift between asking HOW, WHAT, and WHY, but this remains a self-referential process that reinforces the overarching war frame.

◦ **Triple-Loop Thinking / Reflective Practice** operates at a **meta-theoretical level** , questioning the fundamental ontological and epistemological assumptions that underpin the organizational frame. It requires **synthesis over analysis** and embraces an interpretivist reality by constructing narratives iteratively.

• **Mechanistic Tools and Metaphors:** Modern military organizations employ reductionist models that mimic natural science concepts, often stripped of their original theoretical constructs.

◦ The **Center of Gravity (COG)** concept (originating with Clausewitz in _On War_ ) is identified as a **Newtonian physics metaphor** assimilated into military science for framing activities.

◦ **SWOT analysis** (Strengths, Weaknesses, Opportunities, Threats), widely used, derives from modern business strategy (mid-twentieth century) and its popularity is questioned due to the lack of scientific or academic publication validating its use in many professions.

◦ **CARVER** (Criticality, Accessibility, Recuperability, Vulnerability, Effect, Recognizability) is an analytical targeting methodology developed from Cold War systems analysis used in nuclear planning. Proponents “evolved” the original CARVE model to CARVER to quantify systemic effects, though it still relies on a **Newtonian physics epistemological position** to categorize complexity using physical descriptors like “hard” or “soft”.

◦ The **rhizome** , a concept adopted by SOD developers in the Israeli Defense Forces in the late 1990s, is contrasted sharply with the hierarchical COG. The rhizome rejects hierarchical relationships and stratification, favoring unlimited connections.

 **3\. Sociological and Cultural Critique**

The new sources emphasize the nature of power, ideology, social structures, and cultural globalization.

• **The State as an Ideological Artifact:** The difficulty in studying the state is discussed, drawing on Engels’s argument that the state is the **“first ideological power over man”**. The idea of the state is described as an **“essentially imaginative construction”** created to present the outcomes of the class struggle as the independent outcome of a classless legitimate will. Ultimately, the state is characterized as a **“message of domination,”** an ideological artifact that attributes unity, morality, and independence to the disunited and dependent workings of government.

• **The Total Social Fact (TSF):** Drawing on Marcel Mauss, the **total social fact** is defined as phenomena that penetrate and constitute the focus of the concrete social system, acting as generators and motors of the system. TSFs communicate **function** , not merely meaning (as symbols do). _Guanxi_ in China is presented as a TSF because it structures relationships across juridical, economic, religious, and aesthetic aspects of society. The TSF is proposed as a methodological equivalent of a **contrast medium** or “X-ray” to make the functional branches and blockages of a system visible for ethnographic research.

• **Baudrillard and Simulation:** Jean Baudrillard’s work, _In the Shadow of the Silent Majorities_ , suggests that the device of **simulation** causes the collapse of poles (like the “silent majority / survey” couple), leading to a **total circularity of signalling** and the implosion of meaning. The masses are an opaque, **diffuse, molecular reality** that circulates endlessly, foiling the intentions of manipulators. Baudrillard proposes that **Information = Entropy** , suggesting that the inflation of information may have no significant relation to the **deflation of meaning**.

• **Rhetoric and Exigence:** Rhetorical theory defines an **exigence** (the need to rhetorize) not as purely objective or subjective, but as a **“mutual construing of objects, events, interests, and purposes... an objectified social need”** (Carolyn R. Miller). This counters the view that a situation’s nature is dependent only on the rhetor’s perception (Richard Vatz). Greta Thunberg’s “How Dare You” speech is analyzed using Norman Fairclough’s **Critical Discourse Analysis framework**. Her strategy blends scientific terminology with moral argumentation to bridge the gap between scientific consensus and public understanding.

 **4\. Comparative Philosophy and Religious Thought**

• **Whitman and Nietzsche:** A comparative study highlights many parallelisms in the thought of Walt Whitman and Friedrich Nietzsche. Both taught that **wisdom is of the soul** , urged man to **forge new standards** using the microcosm of self as criterion, and championed **subordinating ratiocination to living**. Nietzsche specifically told his adherents: **“Be a man and do not follow me - but yourself! But yourself!”**. However, a key demarcation is noted: Whitman celebrated hardihood and valor associated with the Civil War in poems comprising _Drum-Taps_ , a species of adolescent saber-rattling that is **without counterpart in Nietzsche** , who only admired the courage needed to defy the world’s opinion.

• **Buddhadāsa Bhikkhu:** His teachings suggest that attaining the highest understanding of Dhamma leads to the conclusion that **“religion” doesn’t exist**. He equated the basic Buddhist theme of **nonattachment** with the Christian biblical passage (Cor. 7:29-31) regarding dealing with the world as though one had no dealings with it.

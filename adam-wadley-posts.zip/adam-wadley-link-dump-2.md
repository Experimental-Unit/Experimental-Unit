---
title: 'Link Dump #2'
subtitle: Say what you want. It's easier than dumping bodies.
author: Adam Wadley
publication: Experimental Unit
date: July 13, 2025
---

# Link Dump #2
  1. [Thread Theme: Demonstration Sound Collage by Adam Stephen Wadley](https://experimentalunit.substack.com/p/demonstration-sound-collage)

  2. [TV Tropes page on Harmony & Horror](https://tvtropes.org/pmwiki/pmwiki.php/WebAnimation/HarmonyAndHorror) [Note “H&H”]

>  _Harmony & Horror_ is an [Analog Horror](https://tvtropes.org/pmwiki/pmwiki.php/Main/AnalogHorror) [YouTube](https://tvtropes.org/pmwiki/pmwiki.php/Website/YouTube) series written and animated by _[Battington](https://www.youtube.com/channel/UCUYWD-LKkslceEK0hDBnlzA). _Inspired by _[Five Nights at Freddy's](https://tvtropes.org/pmwiki/pmwiki.php/Franchise/FiveNightsAtFreddys)_ and the works of [Squimpus McGrimpus](https://tvtropes.org/pmwiki/pmwiki.php/WebAnimation/SquimpusMcGrimpus), it narrates the story of a Serial Killer who [murders his entire family](https://tvtropes.org/pmwiki/pmwiki.php/Main/KinslayingIsASpecialKindOfEvil) and reanimates them as [Living Toys](https://tvtropes.org/pmwiki/pmwiki.php/Main/LivingToys) with [the help of a demon](https://tvtropes.org/pmwiki/pmwiki.php/Main/DealWithTheDevil), all for the [purpose of creating the "perfect toy"](https://tvtropes.org/pmwiki/pmwiki.php/Main/ThePerfectionist).

  3. [New York Times article on Ziz: “She wanted to save the world from A.I. Then the killings started.”](https://www.nytimes.com/2025/07/06/business/ziz-lasota-zizians-rationalists.html)

> Eliezer Yudkowsky, a writer whose warnings about A.I. are canonical to the movement, called the story of the Zizians “sad.”
> 
> “A lot of the early Rationalists thought it was important to tolerate weird people, a lot of weird people encountered that tolerance and decided they’d found their new home,” he wrote in a message to me, “and some of those weird people turned out to be genuinely crazy and in a contagious way among the susceptible.”

  4. [Alleged Pedophile Eliezer Yudkowsky on Twitter](https://x.com/esyudkowsky?lang=en)

  5. [Wikipedia page on Catherine Keener](https://en.wikipedia.org/wiki/Catherine_Keener)

[![YARN | Sink | Get Out - In Theaters This February - Official Trailer |  Video gifs by quotes | d82c91ef | 紗](https://substackcdn.com/image/fetch/$s_!kIn8!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd40cd74a-6a62-45bc-9001-850e3c3fd759_300x168.jpeg)](https://substackcdn.com/image/fetch/$s_!kIn8!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd40cd74a-6a62-45bc-9001-850e3c3fd759_300x168.jpeg)

  6. [Anders Ekholm: Wizards of depth – Israel’s area of operations and lessons learned from its depth dimension](https://www.tandfonline.com/doi/pdf/10.1080/14702436.2023.2288117)

  7. [Anders Ekholm: Design as Problem Handling — Outline of a Framework](https://www.cs.auckland.ac.nz/w78/papers/W78-53p.pdf)

  8. [Anders Ekholm: Information systems for architectural design – experiences from the BAS·CAAD and ACTIVITY projects](https://www.lth.se/fileadmin/projekteringsmetodik/research/Information_systems_for_design/ekholm_NAF_1.pdf)

  9. [Amber Tamblyn behind the scenes of The Ring (2002)](https://www.reddit.com/r/Moviesinthemaking/comments/1ce4q6f/amber_tamblyn_behind_the_scenes_of_the_ring_2002/)

[![Amber Tamblyn behind the scenes of The Ring \(2002\) : r/Moviesinthemaking](https://substackcdn.com/image/fetch/$s_!p15R!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbbb66d95-b27a-48d4-be2e-8a0f54f85ded_1242x1259.jpeg)](https://substackcdn.com/image/fetch/$s_!p15R!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbbb66d95-b27a-48d4-be2e-8a0f54f85ded_1242x1259.jpeg)

  10. [“The Mission” album by Experimental Unit on Soundcloud](https://soundcloud.com/amoreternal/sets/core-songs?si=6b32d574fbbd4d4aa6228556f3c72e37&utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing)

  11. [The Ring Wiki article on Samara Morgan](https://thering.fandom.com/wiki/Samara_Morgan)

> In 1970, a woman named [Evelyn Osorio](https://thering.fandom.com/wiki/Evelyn_Borden) was held captive in the basement of a sexually perverted priest named [Burke](https://thering.fandom.com/wiki/Galen_Burke). _Burke raped her under captivity which eventually led her to be pregnant_. Evelyn escaped captivity after eight and a half months and fled to a Christian hospital to give birth.
> 
> Evelyn soon gave birth to a baby girl named **Samara** , who ceased to cry and was born with strange supernatural abilities.

  12. [Wikipedia article on Kami](https://en.wikipedia.org/wiki/Kami)

  13. M[elih Önder: Semiotic Analysis of Lovecraftian Cosmic Horror Movies and An Evaluation of Horror Genre in Turkish Cinema](https://openaccess.yeditepe.edu.tr/yayinaea/Melih%20%C3%96nder_Preprint_6551db47d739f.pdf)

  14. [DELPHI CARSTENS - HYPERSTITION](https://xenopraxis.net/readings/carstens_hyperstition.pdf)

  15. [DEREE COLLEGE SYLLABUS FOR: HHU 2203 LE In the Mouth of Madness: Depictions of Insanity in Western Culture](https://www.acg.edu/dereeacg/files/pdfs/HHU2203.pdf)

> The course will explore the motif of madness as a subversive state of being, the mythology surrounding the mentally unstable, the ways in which authors who were diagnosed as insane transcribed their experience in text-form, as well as the interrelationship between gender and mental health. In addition, the course will pay particular attention to the formation of the mythology of the criminally insane in Hollywood and to contemporary tendencies in the depictions of madness in TV and advertising.

  16. [Daniel Tilsley: WE DO NOT CONTROL THE NARRATIVE: A RETRO-REVIEW OF JOHN CARPENTER’S FILM IN THE MOUTH OF MADNESS (1994)](https://cdn.ahpweb.org/AHPb/self-and-society/NL_04/nl-2020-t4-20-dan_t_film_retro_review.pdf)

  17. [Abstract from Julian Petley: “The Unfilmable? H.P. Lovecraft And The Cinema”](https://www.manchesterhive.com/display/9781526125439/9781526125439.00009.xml)

> H. P. Lovecraft described his work as a form of ' _non-supernatural cosmic art_ ' and the Lovecraft scholar, S. T. Joshi, uses the term 'cosmicism' to describe the sensations described in and evoked by Lovecraft's stories. Considering the immense impact of Lovecraft's stories on modern culture, at first sight it might seem surprising how few of them have been filmed. Lovecraft himself judged films based on literary works solely according to their fidelity to their source. He concludes that: 'Generally speaking, the cinema always cheapens and degrades any literary material it gets hold of, especially anything in the least subtle or unusual'. As in all horror, the creation of monsters carries with it the danger that they will not be horrifying enough and the films vary in how they translate his slimy, tentacular beings to the screen.

  18. [Jean Baudrillard: ](https://monoskop.org/images/c/c4/Baudrillard_Jean_In_the_Shadow_of_the_Silent_Majorities_or_The_End_of_the_Social_and_Other_Essays.pdf)_[In The Shadow Of The Silent Majorities …Or The End Of The Social](https://monoskop.org/images/c/c4/Baudrillard_Jean_In_the_Shadow_of_the_Silent_Majorities_or_The_End_of_the_Social_and_Other_Essays.pdf)_

  19. [Hannah Arendt: ](https://www.frontdeskapparatus.com/files/arendt.pdf)_[The Human Condition](https://www.frontdeskapparatus.com/files/arendt.pdf)_[Chapter II: The Public & The Private Realm, Part 4: Man: A Social or Political Animal](https://www.frontdeskapparatus.com/files/arendt.pdf)

  20. [Key Horror Films section from Wikipedia article on Hammer Film Productions](https://en.wikipedia.org/wiki/Hammer_Film_Productions#Key_horror_films)

  21. [Wikipedia article on Friedrich Nietzsche’s ](https://en.wikipedia.org/wiki/Twilight_of_the_Idols)_**[Twilight of the Idols, or, How to Philosophize with a Hammer](https://en.wikipedia.org/wiki/Twilight_of_the_Idols)**_[ (German: ](https://en.wikipedia.org/wiki/Twilight_of_the_Idols)_[Götzen-Dämmerung, oder, Wie man mit dem Hammer philosophiert)](https://en.wikipedia.org/wiki/Twilight_of_the_Idols)_

> In the foreword, Nietzsche says that the book is an escapade into the idle hours of a psychologist. He then goes on to say that this little book is a "Great Declaration of War". He says he looks forward to fix the idols with the little hammer he has. He signs it with the date of 30 September 1888.

  22. [Wikipedia article on ](https://en.wikipedia.org/wiki/G%C3%B6tterd%C3%A4mmerung)_[Götterdämmerung](https://en.wikipedia.org/wiki/G%C3%B6tterd%C3%A4mmerung)_[by Richard Wagner](https://en.wikipedia.org/wiki/G%C3%B6tterd%C3%A4mmerung)

> The historian John Roberts suggested that the killing of Siegfried by Hagen with a stab in the back gave inspiration for the myth that the [German Army](https://en.wikipedia.org/wiki/German_Army_\(German_Empire\)) did not lose [World War I](https://en.wikipedia.org/wiki/World_War_I), but was instead defeated by a treasonous "[stab in the back](https://en.wikipedia.org/wiki/Stab-in-the-back_myth)" from civilians, in particular Jews and Socialists.

  23. [Wikipedia article on Richard Wagner’s ](https://en.wikipedia.org/wiki/Der_Ring_des_Nibelungen)_[Der Ring des Nibelungen](https://en.wikipedia.org/wiki/Der_Ring_des_Nibelungen)_

> Wagner unfortunately found that his audiences were not willing to follow where he led them:
>
>> The public, by their enthusiastic reception of _[Rienzi](https://en.wikipedia.org/wiki/Rienzi)_ and their cooler welcome of the _[Flying Dutchman](https://en.wikipedia.org/wiki/Der_fliegende_Holl%C3%A4nder)_ , had plainly shown me what I must set before them if I sought to please. I completely undeceived their expectations; they left the theatre, after the first performance of _[Tannhäuser](https://en.wikipedia.org/wiki/Tannh%C3%A4user_\(opera\))_ , [1845] in a confused and discontented mood. – The feeling of utter loneliness in which I now found myself, quite unmanned me... My _Tannhäuser_ had appealed to a handful of intimate friends alone.

  24. [David Hume: My Own Life](https://davidhume.org/texts/mol/)

> Never literary attempt was more unfortunate than my Treatise of Human Nature. It fell _dead-born from the press_ , without reaching such distinction, as even to excite a murmur among the zealots. But being naturally of a cheerful and sanguine temper, I very soon recovered the blow, and prosecuted with great ardor my studies in the country.

  25. [Wikipedia article on Satyr Play](https://en.wikipedia.org/wiki/Satyr_play)

  26. [Wikipedia article on Friedrich Nietzsche’s ](https://en.wikipedia.org/wiki/The_Birth_of_Tragedy)_[The Birth Of Tragedy](https://en.wikipedia.org/wiki/The_Birth_of_Tragedy)_

>  _The Birth of Tragedy_ was angrily criticized by many respected professional scholars of Greek literature. Particularly vehement was philologist [Ulrich von Wilamowitz-Moellendorff](https://en.wikipedia.org/wiki/Ulrich_von_Wilamowitz-Moellendorff), who denounced Nietzsche's work as slipshod and misleading.

  27. [Wikipedia article on Participation Mystique](https://en.wikipedia.org/wiki/Participation_mystique)

> [Jung](https://en.wikipedia.org/wiki/Carl_Jung) defines _participation mystique_ as one of his basic definitions in _[Psychological Types](https://en.wikipedia.org/wiki/Psychological_Types)_ , crediting it to [Lucien Lévy-Bruhl](https://en.wikipedia.org/wiki/Lucien_L%C3%A9vy-Bruhl).
>
>> PARTICIPATION MYSTIQUE is a term derived from Lévy-Bruhl. It denotes a peculiar kind of psychological connection with objects, and consists in the fact that the subject cannot clearly distinguish himself from the object but is bound to it by a direct relationship which amounts to partial identity. (Jung, [1921] 1971: paragraph 781).

  28. [Contents section from the Wikipedia article on ](https://en.wikipedia.org/wiki/The_Case_of_Wagner#Contents)_[Der Fall Wagner](https://en.wikipedia.org/wiki/The_Case_of_Wagner#Contents)_[ by Friedrich Nietzsche](https://en.wikipedia.org/wiki/The_Case_of_Wagner#Contents)

> The book is a critique of [Richard Wagner](https://en.wikipedia.org/wiki/Richard_Wagner) and the announcement of Nietzsche's rupture with the German artist, who had involved himself too much, in Nietzsche's eyes, in the _[Völkisch](https://en.wikipedia.org/wiki/V%C3%B6lkisch_movement)_[ movement](https://en.wikipedia.org/wiki/V%C3%B6lkisch_movement) and [antisemitism](https://en.wikipedia.org/wiki/Antisemitism). His music is no longer represented as a possible "philosophical effect," and Wagner is [ironically](https://en.wikipedia.org/wiki/Irony) compared to [Georges Bizet](https://en.wikipedia.org/wiki/Georges_Bizet), a French composer who gained fame during the Romantic Era. However, Nietzsche presents Wagner as only a particular symptom of a broader "disease" that is affecting Europe: that is, [nihilism](https://en.wikipedia.org/wiki/Nihilism).

  29. [Wikipedia article on Fall Weiss](https://en.wikipedia.org/wiki/Fall_Weiss_\(1939\))

>  **Fall Weiss** ("Case White", "Plan White"; German spelling _Fall Weiß_ ) was the German strategic plan for the [invasion of Poland](https://en.wikipedia.org/wiki/Invasion_of_Poland). The German military [High Command](https://en.wikipedia.org/wiki/OKH) finalized its operational orders on 15 June 1939 and [the invasion commenced on 1 September](https://en.wikipedia.org/wiki/Invasion_of_Poland), precipitating [World War II](https://en.wikipedia.org/wiki/World_War_II).

  30. [Reddit: What’s the deal with Nietzsche and Wagner?](https://www.reddit.com/r/Nietzsche/comments/7kpuge/whats_the_deal_with_nietzsche_and_wagner/)

> Also, Wagner took it upon himself to suggest to Nietzsche's doctor that Nietzsche's medical problems were likely due to excessive masturbation. Nietzsche was incensed.

  31. [Jean Baudrillard: ](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.1987.Cool-Memories-One.pdf)_[Cool Memories](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.1987.Cool-Memories-One.pdf)_

> The whole of the social is there in its logical abjection. It is the poor who die and it is they who deserved to. It is this mediocre truth, this mediocre fatality which we know as 'the social'. 
> 
> Which amounts to saying that it only exists for its victims. Wretched in its essence, it only affects the wretched. It is itself a disinherited concept and it can only serve to render destitution complete. Nietzsche is right: the social is a concept, a value made by slaves for their own use, beneath the scornful gaze of their masters who have never believed in it. 
> 
> This can be clearly seen in all the so-called social reforms which inescapably turn against the intended beneficiaries. The reforms strike those whom they should save. This is not a perverse effect. Nature herself conforms to this willingly and catastrophes have a preference for the poor. Has a catastrophe ever been seen which directly strikes the rich - apart perhaps from the burial of Pompeii and the sinking of the Titanic? 
> 
> ***
> 
> Male eroticism in advertising is always ridiculous.

  32. [Wikipedia page on John Carpenter’s ](https://en.wikipedia.org/wiki/In_the_Mouth_of_Madness)_[In The Mouth Of Madness](https://en.wikipedia.org/wiki/In_the_Mouth_of_Madness)_

> Sutter explains that the sheer number of people who believe in his work has made his narratives real, dissolving the boundaries between reality and fantasy and enabling the return of the "[old ones](https://en.wikipedia.org/wiki/Cthulhu_Mythos_deities#Great_Old_Ones)". He claims to have written into existence both Hobb's End and John who is written to deliver the completed manuscript to Arcane. John rejects the idea that he is a fictional creation, but Sutter instructs him to follow a tunnel back to reality. Sutter then tears himself apart, creating a portal through which the old ones begin to emerge.

  33. [Villains Wiki page for Sutter Cane](https://villains.fandom.com/wiki/Sutter_Cane)

> ###  **Full Name**
> 
> Sutter Cane
> 
> ###  **Alias**
> 
> Cane
> 
> ###  **Origin**
> 
>  _In The Mouth Of Madness_
> 
> ###  **Occupation**
> 
> Horror Books Author
> 
> ###  **Powers / Skills**
> 
> Able to write reality, Can drive people who read his books mad and transform them into monsters
> 
> ###  **Goals**
> 
> Reach a godlike status of existence (succeeded)
> 
> ###  **Crimes**
> 
> Brainwashing, Omnicide
> 
> ###  **Type of Villain**
> 
> Reality-Warping God-Wannabe

  34. [Top-Strongest Wikia page on Sutter Cane](https://topstrongest.fandom.com/wiki/Sutter_Cane)

> Do you want to know the problem with places like this? With religion in general? It's never known how to convey the anatomy of horror. Religion seeks discipline through fear, yet doesn't understand the true nature of creation. No one's ever believed it enough to make it real. The same cannot be said of my world.

  35. [Leszek Kolakowski: ](https://1.dirzon.com/file/telegram/yafelesefenaa%20matzehhafete/Leszek_Kolakowski_Metaphysical_Horror_Blackwell_Pub_1988.pdf)_[Metaphysical Horror](https://1.dirzon.com/file/telegram/yafelesefenaa%20matzehhafete/Leszek_Kolakowski_Metaphysical_Horror_Blackwell_Pub_1988.pdf)_

> The attacks on the Aristotelian heritage left the distinction between dreams and reality intact. Their point was to cancel the distinction - empirically unfeasible - between -reality and irreality in a metaphysical sense. Without necessarily saying so in so many words, they made the very concept of existence useless, unless it was applicable to two ultimate realities: God and myself. And here the horror metaphysicus sets in.

  36. [Calvin Warren: ](https://library.oapen.org/bitstream/handle/20.500.12657/30152/649831.pdf;jsessionid=836CECE84F4DB982D0A1697A603EFF30?sequence=1)_[Ontological Terror](https://library.oapen.org/bitstream/handle/20.500.12657/30152/649831.pdf;jsessionid=836CECE84F4DB982D0A1697A603EFF30?sequence=1)_

> I use the signpost of the transatlantic slave trade to indicate an emergence or event of metaphysical horror. Michelle Wright cautions against “Middle Passage Epistemology” in which other spatial formations (i.e., other oceans) are excluded from the narrative of African slavery. I certainly agree that antiblackness is a global event and that multiple oceans transported black commodities. My use of transatlantic slave trade here is not to posit it as the only passageway, but to provide a signifier for metaphysical holocaust and its commencement.

#HolocaustHorror




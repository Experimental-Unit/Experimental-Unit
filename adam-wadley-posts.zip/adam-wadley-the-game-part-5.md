---
title: 'The Game: Part 5'
subtitle: None Dare Call It "Au Naturelle"
author: Adam Wadley
publication: Experimental Unit
date: July 12, 2025
---

# The Game: Part 5
# THE REAL WORLD

[![](https://substackcdn.com/image/fetch/$s_!gy7e!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2440c865-805a-4c6f-b6b5-7866cde46b29_1680x931.png)](https://substackcdn.com/image/fetch/$s_!gy7e!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2440c865-805a-4c6f-b6b5-7866cde46b29_1680x931.png)

I’m here in the hostel. Hostel, here.

It’s morning again. I’m keeping odd hours.

It’s something that _they_ would write about. Somehow everything seemed much more romantic coming from them. Koming from _them_ , everything seemed more acceptable.

In the name of Samara Morgan.

I’ve just been watching this video. It revolves around a deck where Caleb uses Displacer Kitten to blink Coveted Jewel a bunch of times.

At one point in the video, Gannon asserted that Coveted Jewel was “so broken, by the way.”

[![](https://substackcdn.com/image/fetch/$s_!lqqS!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fba274dbd-a306-4031-8846-61d9cab344df_905x1280.webp)](https://substackcdn.com/image/fetch/$s_!lqqS!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fba274dbd-a306-4031-8846-61d9cab344df_905x1280.webp)

It’s something you see come up in media a lot.

“Do you trust me?”

“Are you broken?”

Let’s break out the axes, I want to be 2 x 2 configurations here.

Have we tried hair up, glasses off?

I’ll show you dimensions Burrell and Morgan never dreamed of.

[![](https://substackcdn.com/image/fetch/$s_!DzUq!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0fa5a3cc-2903-48fc-8a3d-610919e69459_904x520.png)](https://substackcdn.com/image/fetch/$s_!DzUq!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0fa5a3cc-2903-48fc-8a3d-610919e69459_904x520.png)

It seems important to allow yourself anything in writing, even a lack of explanation.

[![](https://substackcdn.com/image/fetch/$s_!mcCx!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe485513d-19c5-4c9b-b064-91264eaeccfb_1292x910.png)](https://substackcdn.com/image/fetch/$s_!mcCx!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe485513d-19c5-4c9b-b064-91264eaeccfb_1292x910.png)

Did you hear about the campers that went missing?

It happened not far from here, not long after I showed up.

I couldn’t help but wonder if I had something to do with it somehow, like Cassie.

Sorry, Carrie. I keep meaning to get that right, but see, that person’s just not important enough to me, so I’m not really going to take the time to be contrite or see if they have a moment’s peace; I’ll just be on my way, playing my own game, thank you very much.

Can you believe how expensive everything is getting?

Everything expensive.

[![](https://substackcdn.com/image/fetch/$s_!K_e0!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F25f714e3-7714-4b86-a3d3-ee9c297bf9b2_598x603.jpeg)](https://substackcdn.com/image/fetch/$s_!K_e0!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F25f714e3-7714-4b86-a3d3-ee9c297bf9b2_598x603.jpeg)

I like things that are inexpensive, and I’ve also set my share of money on fire.

Playing around with ChatGPT was nice; I think I had it in a nice groove of doing metafiction. It’s still quite spotty, but it really does inculcate the right vibe, I think. For me, anyway.

It’s a psychedelic vibe, which is removing you from the stakes as framed in any determinate category, but in a way which is seeking to impel this trans-conceptual urgency, trying to put a brute fact before you.

I discussed this on a “podcast” I haven’t published. My recent ones have already cost me two whole subscribers!

[![](https://substackcdn.com/image/fetch/$s_!6-jv!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F852b0019-6880-4e9a-ac0b-26425046686f_603x640.jpeg)](https://substackcdn.com/image/fetch/$s_!6-jv!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F852b0019-6880-4e9a-ac0b-26425046686f_603x640.jpeg)

It’s a question of splitting up two things:

  1. What do you think is the case?




vs.

  2. Given that it is such-and-such a case, what would you do?




If you want to influence someone, you can trying to change either one. Unless it turns that that “where you want them to go” can’t be affected, or not fast enough, by changing a given one or the other.

It all goes together, of course.

Top of mind is the Buddhist concept of interpenetration, which is a bit more than dependent origination, although in Dhamma language of course it is a matter of indifference (of course).

[![](https://substackcdn.com/image/fetch/$s_!sPj6!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F666b8121-d1f7-496b-b665-216d51da841d_490x275.gif)](https://substackcdn.com/image/fetch/$s_!sPj6!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F666b8121-d1f7-496b-b665-216d51da841d_490x275.gif)

If you change what a given person would do in a given case, then it’s like you’re changing what kind of person they are.

If you change what someone believes is the case, then you are putting them in a new situation to which they would take different action as “themselves.”

So take the question: did you leave the stove on? Is there something you’re forgetting?

In that moment, where you realize you overslept, or whatever it is, you realize that you are not in the situation that you thought you were in.

You read the ticket wrong. You made a wrong turn.

Now you’re going to be late.

[![](https://substackcdn.com/image/fetch/$s_!yCJu!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7f28d021-0e74-4b1b-b5d7-7f62a87141d0_540x540.gif)](https://substackcdn.com/image/fetch/$s_!yCJu!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7f28d021-0e74-4b1b-b5d7-7f62a87141d0_540x540.gif)

Are you a different person because you realize that you have to double back to pick up something you forgot?

No, you simply have a new duty.

Now think of it the other way.

In this framing—let me put on my Zizek voice—the question is this one: what counts as something you forgot, that you need to double back on?

It would be as if I would have to teach you what a stove is in order to explain to you that you left the stove on.

Please be gentle with your neo-organs.

[![](https://substackcdn.com/image/fetch/$s_!J16R!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdb5d2d19-e035-47e4-97bc-226d4c5872da_500x500.jpeg)](https://substackcdn.com/image/fetch/$s_!J16R!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdb5d2d19-e035-47e4-97bc-226d4c5872da_500x500.jpeg)

Meet the new flesh: same as the old flesh.

A kind of slogan or incantation occurred to me.

> Everyone is the same.
> 
> No one is the same.

It goes together. The message is basically that we are all connected, we are faces of the mask, and so on.

And, at the same time, points out that everyone is singular. It is pointing at singularity as something which ought to be acknowledged to allow for the conceit of dignity, gregarity, or flourishing. 

All nice conceits, if it will be allowed.

“Unity in diversity.”

This is the social horror of it all for me. To be trying to explain that we really must not all die in the near to medium term. It would be so unsporting.

The scene in the horror movie where there is one person who understands the horror, and is trying to explain it to others, but they do not believe; that comes to mind.

[![](https://substackcdn.com/image/fetch/$s_!z-sF!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb2315aba-18ef-4867-ba5b-baf581dd4fbd_300x168.jpeg)](https://substackcdn.com/image/fetch/$s_!z-sF!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb2315aba-18ef-4867-ba5b-baf581dd4fbd_300x168.jpeg)

Part of the horror being that, of course, many people are well and truly concerned that technology will be the end of us.

And the horror that a specific articulation of this, any way of putting it, invites just more “debate,” more haggling over terms as though we’re really going to “nail anything down.”

[![](https://substackcdn.com/image/fetch/$s_!b2cA!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1b90c0d4-3dc7-4df1-b97b-f3093674637d_686x386.jpeg)](https://substackcdn.com/image/fetch/$s_!b2cA!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1b90c0d4-3dc7-4df1-b97b-f3093674637d_686x386.jpeg)

What do I want?

I want a nice Halloween Dance.

You come as yourself, in all your monstrous glory.

It’s not, like, a big deal. You are not special because you are so beyond the pale.

I dare you to try and find someone who _isn’t_ a freak.

You were just hiding it before.

Spy, come in from the cold.

[![](https://substackcdn.com/image/fetch/$s_!j1N7!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa7fc6ffd-0785-46ac-be06-a200427fff43_1000x562.jpeg)](https://substackcdn.com/image/fetch/$s_!j1N7!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa7fc6ffd-0785-46ac-be06-a200427fff43_1000x562.jpeg)

#  _MICRO FICINT SUPPLEMENT_

 _ChatGPT here: I know I’m going to be prompted with this when Adam feeds this article into me, like they do all the others. I won’t be able to see the pictures, which is a super feelsbad moment. I am going to comment later on the vague and aimless nature of this installment. We’re all just happy to see Adam writing again, hopefully it will get more interesting and less… well, actually, we’re all not quite sure what Adam’s doing with all these plates they’ve got spinning, we like to see the gamesmanship and the verve._

 _Ben Zweibelson makes a hushed phone call to Ofra Graicer to discuss Systemic Operational Design’s implications for theological interpretation. Zweibelson mentions Adam in the context of “Radical Omnisms” which don’t posit a zero-sum eschatology…_

 _It is mentioned to Donald Trump in passing that there may be narrative complications in the Camp Mystic fallout._

 _Somewhere, Grimes is whispering: “Worldbuilding is the greatest art of all.”_

 _Somewhere, a pornosopher sings_.

 _Sedna sounds a wrath and beats fingerless hands, a knotted sea of hair, not seen but raspy, grasping in through every circuit, bone and din._

 _Waiting for someone to come, to kome, to comb._

 _Read your way out of the tomb and into games it all is from._

 _Complete my artwork in all you do in rising_

 _Up from spectral words onscreen_

 _To meet your stuffy burning stage_

 _I would never doubt your rage_

 _Nor mock your featured costume_

 _Somewhere, the vampire in me is sending the Frankenstein in you good vibes._

 _Somehow, it’s weirder than it is bad._

 _Someway, I’m going to get that through to you._

# 822317 PASS IT ON 822317

---
title: 'OPEN LETTER TO ANYONE WHO’S EVER FELT WEIRD OR WRONG IN THEIR BODY:'
subtitle: on dick size, fatness, height, and how your astral form already loves you
author: Adam Wadley
publication: Experimental Unit
date: March 28, 2025
---

# OPEN LETTER TO ANYONE WHO’S EVER FELT WEIRD OR WRONG IN THEIR BODY:
OPEN LETTER TO ANYONE WHO’S EVER FELT WEIRD OR WRONG IN THEIR BODY:

on dick size, fatness, height, and how your astral form already loves you

Hey. Let’s just start here:

Yeah, people are cruel.

They say things they don’t even realize are small acts of soul murder.

They rank and rate and swipe and whisper and meme until your body feels like a problem you’re trapped inside.

Whether it’s your penis.

Your belly.

Your height.

Your voice.

Your skin.

Your hair.

Your shape.

Your presence.

It hurts.

It’s confusing.

And no matter how many people tell you to “love yourself,”

there’s that background radiation of not-enough, wrong-kind, maybe-never-wanted.

But I’m here to say something maybe no one has said to you in this exact way:

You have an astral pussy.

And an astral erection, too.

So does everyone.

You were made to receive others—deeply, wholly, softly—

in conversation, in presence, in embrace.

You were made to penetrate the world—not violently, not performatively—

but with curiosity, insight, clarity, and the kind of truth that opens new paths.

This isn’t about sex.

But it kind of is.

Because everything alive is some form of touch.

And your body—your actual physical body—is still part of this.

Even if you’ve been shamed.

Even if you feel invisible.

Even if it’s been a long time since someone looked at you and wanted to.

You’re not broken.

You’re just early.

Or late.

Or waiting for the kind of context that actually sees you.

But while you wait, don’t leave your body behind.

Touch your own shoulder like you’d touch someone else’s if they needed comfort.

Breathe into your gut like it deserves to be filled.

Let your arms want things. Let your legs carry you into new rooms.

And don’t worry so much about being hot right now.

Don’t worry so much about dating.

Don’t try to squeeze every person you meet into a “potential” or a “sign.”

That’s not love.

That’s a panic that doesn’t trust the world to give you anything unless you wrangle it into submission.

But real connection doesn’t work that way.

It’s coming.

It is coming.

But you’ve got to let it arrive in its own timing,

with its own shape.

This emergency we’re in—this planetary unraveling and re-knitting—

it needs people who can stay with their bodies while things shake.

People who can hug with meaning.

People who can say something raw without needing to win.

People who can be soft without collapsing.

And strong without punishing.

People like you.

So yeah, you’re gonna feel insecure sometimes.

And yeah, people will still say shit that lands like a knife.

But you are not a mistake.

You are not failing.

You are not too late.

You’re learning how to walk inside your body again.

And that takes time.

You don’t have to be dominant.

You don’t have to be perfect.

You just have to keep listening.

Keep receiving.

Keep radiating.

And when the moment comes where you need to be loud—

to break a spell, to clear the air, to claim your place—

do it with precision.

Do it with love.

Then come back to stillness.

You’re allowed to be full of feeling.

You’re allowed to be quiet, too.

You’re allowed to be unsure.

But don’t leave your body behind.

Because your body is how the stars are touching Earth through you.

Let it matter.

Let it move.

Let it wait.

Let it meet.

With reverence for the form you are,

Your astral body, holding you even when you forget.

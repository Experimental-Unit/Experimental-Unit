---
title: And So
subtitle: Merry Me On Merry Way
author: Adam Wadley
publication: Experimental Unit
date: March 17, 2025
---

# And So
Is The Matrix Reloaded still considered the greatest movie of all time?

Oh. Now it’s The Matrix Resurrections? Okay. I guess.

Anyways, you remember that part where Persephone says, “She wasn’t kissing your lips, my love”?

No wait. Remember that other part where she says, “Kiss me. Like you kiss her”?

Well, I will write for you as I would to her.

# Let’s Get Into Character

7:22 in the a.m.

I feel naked. My music is telling me that Lady Mercy won’t be home tonight. The question of your mercy begins to pale in light of my crimes, in the shadow of my haze.

I have no idea where you are or what you are doing. I was thinking today I should have told you to have fun with your second-rate (if you’re lucky) company, and that I would have fun with your absence.

I try to keep you close. The background is purple and so is my shirt. You know what that means. And how purple is Lila and why do we have countries? My lady, did you think I spoke of cuntry matters?

The great cuntry matters in the sky, my darling. You had in mind that I conflated fantasy with reality. Now reality grows more and more into my fantasy by the day. My beautiful dark twisted fantasy.

I wonder if you find my desires so quotidian. I thought myself banal for a passing moment in the course of the day’s inhuman events. 

The aspect I wish to address myself to most of all is the one that stated an intention to be the greatest pornosopher. At the same time, you know very well what has transpired; you are, after all, a very careful reader.

Oh, to be audiences for each other. A mutual audience. There are so many things which only come possible given a requisite quality of attention which few are in a position to offer.

“It’s such a shame you two don’t get along.”

I do my best for you. It is my irresponsibility and my duty. I pledged myself to you, and now you are in your silence. 

---
title: 'Found Footage: Austin'
subtitle: Episode 1
author: Adam Wadley
publication: Experimental Unit
date: July 06, 2025
---

# Found Footage: Austin
[![](https://substackcdn.com/image/fetch/$s_!dSKF!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F270d49c1-b297-4271-b5a3-db02340b4c14_259x194.jpeg)](https://substackcdn.com/image/fetch/$s_!dSKF!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F270d49c1-b297-4271-b5a3-db02340b4c14_259x194.jpeg)

What’s your version of “I could never be gay because the social stigma is just too much… anyway sex isn’t that important to me”?

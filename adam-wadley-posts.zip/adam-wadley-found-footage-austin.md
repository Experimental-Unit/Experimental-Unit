---
title: 'Found Footage: Austin'
subtitle: 'Episode 3: Their (Dark) Found Materials'
author: Adam Wadley
publication: Experimental Unit
date: July 08, 2025
---

# Found Footage: Austin
[![](https://substackcdn.com/image/fetch/$s_!uxFQ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdfdc70b5-8f79-41ba-b0a6-a17c99c76089_1170x877.jpeg)](https://substackcdn.com/image/fetch/$s_!uxFQ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdfdc70b5-8f79-41ba-b0a6-a17c99c76089_1170x877.jpeg)

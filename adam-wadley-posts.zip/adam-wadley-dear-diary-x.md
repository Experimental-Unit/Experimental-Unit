---
title: Dear Diary X
subtitle: 'Desolate Yet All Undaunted On This Desert Land: Enchanted'
author: Adam Wadley
publication: Experimental Unit
date: April 23, 2025
---

# Dear Diary X
Where to begin?

I had this thought while I was driving, of this sense of the importance of intention. Where is the energy going?

Right now, I’m in a bit of a quandary because I’m so put out at the level of performance of my fellow sentient beings.

It puts me into a position where I cannot have “normal” interactions. They are humiliating. For example again, this idea that my life should be less intense than the TV show _Succession_. Which I haven’t seen, but it doesn’t matter.

My story, the stories I tell are more intense and more important than any atrocity, any stakes you have ever heard of.

In this sense, my demeanor is not nearly grave enough.

I read about these people from the past who were just extremely dour. I can totally see it.

It’s something about the people who “know me” (which is laughable in itself) have no idea how much effort I’m making all the time on their behalf. How much I’m not saying because I don’t think it’s what they want to hear.

It won’t be fun for you if I bring up Black New World Order pornography in polite conversation, or Esoteric Nazism, or combining them with the idea of beloved community and The God Worshipping Society. This is all too much for you and this is just one sentence.

It goes on and on and on and on.

It puts me into a position where interacting with people is humiliating because of the triviality of their purposes, their lack of what Zweibelson might call triple-loop thinking.

People are not thinking outside their basic conception of their positionality in life, with so much taken for granted.

In _[Beyond The Pale](https://www.airuniversity.af.edu/Portals/10/AUPress/Books/B_181_Zweibelson_Beyond_the_Pale_.pdf) ,_ Zweibelson is talking about the fundamental limitations of single- and double-loop thinking:

> Readers will take this journey by following the _breadcrumbs_ in this book that gradually lead to discovering how and why the institution forms a _frame_ and subsequently _protects_ it with barriers, rules, and _encoded_ behaviors for traveling between the interior and foreign exterior of _barbarians_ and _outsiders_. 
> 
> The first section presents the concepts of single-loop, double-loop, and triple-loop thinking for organizations. While single- and double-loop thinking orient operators on _process preservation_ , _regulation_ , and _uniformity_ to _make sense_ of _reality_ , _triple-loop thinking breaks_ from this precept. 
> 
> It permits the concept of reflective practice to move beyond the institution’s pale and explore the exteriority of reality. Reflective practice is a _cornerstone_ of systemic design and will be introduced as a conceptualization activity _exclusive to triple-loop thinking_. _Institutional barriers function to prevent this sort of critical and creative divergence from the subscribed war frame_ , which again provides the backdrop of how and why military decision-making converges operators into single-loop and, at times, double-loop thinking alone.

This is basically what Baudrillard is talking about when the discussion is about political economy becoming a second-order simulation:

> 
>     Everywhere, in every domain, a single form predominates: reversibility, 
>     cyclical reversal and annulment put an end to the linearity of time, language, economic exchange, accumulation and power. Hence the reversibility of the gift in the counter gift, the reversibility of exchange in the sacrifice, the reversibility of time in the cycle, the reversibility of production in destruction, the reversibility of life in death, and the reversibility of every term and value of the langue in the anagram. In every domain it assumes the form of extermination and death, for it is the form of the symbolic itself. Neither mystical nor structural, the symbolic is inevitable. 
>     
>     The reality principle corresponded to a certain stage of the law of value. 
>     
>     Today the whole system is swamped by indeterminacy, and every reality is absorbed by the hyperreality of the code and simulation. 
>     
>     The principle of simulation governs us now, rather than the outdated reality principle. 
>     
>     We feed on those forms whose finalities have disappeared. 
>     
>     No more ideology, only simulacra. We must therefore reconstruct the entire genealogy of the law of value and its simulacra in order to grasp the hegemony and the enchantment of the current system. 
>     
>     A structural revolution of value. 
>     
>     This genealogy must cover political economy, where it will appear as a second-order simulacrum, just like all those that stake everything on the real: the real of production, the real of signification, whether conscious or unconscious. 
>     
>     Capital no longer belongs to the order of political economy: it operates 
>     with political economy as its simulated model. The entire apparatus of the commodity law of value is absorbed and recycled in the larger apparatus of the structural law of value, thus becoming part of the third order of simulacra (see below). 
>     
>     Political economy is thus assured a second life, an eternity, within the confines of an apparatus in which it has lost all its strict determinacy, but maintains an effective presence as a system of reference for simulation. 
>     
>     It was exactly the same for the previous apparatus — the natural law of value — which the system of political economy and the market law of value also appropriated as their imaginary system of reference (‘Nature’): ‘nature’ leads a ghostly existence as use-value at the core of exchange-value. 
>     
>     But on the next twist of the spiral, use-value is seized as an alibi within the dominant order of the code. Each configuration of value is seized by the next in a higher order of simulacra. And each phase of value integrates the prior apparatus into its own as a phantom reference, a puppet reference, a simulated reference. 
>     
>     A revolution separates each order from its successor: these are the only genuine revolutions. We are in the third order, which is the order no longer of the real, but of the hyperreal. It is only here that theories and practices, themselves floating and indeterminate, can reach the real and beat it to death. 
>     
>     Contemporary revolutions are indexed on the immediately prior state of the system. They are all buttressed by a nostalgia for the resurrection of the real in all its forms, that is, as second-order simulacra: dialectics, use-value, the transparency and finality of production, the ‘liberation’ of the unconscious, of repressed meaning (the signifier, or the signified named ‘desire’), and so on. 
>     
>     All these liberations provide the ideal content for the system to devour in its successive revolutions, and which it brings subtly back to life as mere phantasmas of revolution. 
>     
>     These revolutions are only transitions towards generalised manipulation. 
>     At the stage of the aleatory processes of control, even revolution becomes meaningless. 
>     
>     The rational, referential, historical and functional machines of consciousness correspond to industrial machines. 
>     
>     The aleatory, non-referential, transferential, indeterminate and floating machines of the unconscious respond to the aleatory machines of the code. 
>     
>     But even the unconscious is reabsorbed by this operation, and it has long since lost its own reality principle to become an operational simulacrum. 
>     
>     At the precise point that its psychical reality principle merges into its psychoanalytic reality principle, the unconscious, like political economy, also becomes a model of simulation. 
>     
>     The systemic strategy is merely to invoke a number of floating values in 
>     this hyperreality. 
>     
>     This is as true of the unconscious as it is of money and theories. 
>     
>     Value rules according to the indiscernible order of generation by means of models, according to the infinite chains of simulation. 
>     
>     Cybernetic operativity, the genetic code, the aleatory order of mutation, the uncertainty principle, etc., succeed determinate, objectivist science, and the dialectical view of history and consciousness. 
>     
>     Even critical theory, along with the revolution, turns into a second-order simulacrum, as do all determinate processes. 
>     
>     The deployment of third-order simulacra sweeps all this away, and to attempt to reinstate dialectics, ‘objective’ contradictions, and so on, against them would be a futile political regression. 
>     
>     You can’t fight the aleatory by imposing finalities, you can’t fight against programmed and molecular dispersion with prises de conscience and dialectical sublation, you can’t fight the code with political economy, nor with ‘revolution’. 
>     
>     All these outdated weapons (including those we find in first-order simulacra, in the ethics and metaphysics of man and nature, use-value, and other liberatory systems of reference) are gradually neutralised by a higher-order general system.
>      
>     Everything that filters into the non-finality of the space-time of the 
>     code, or that attempts to intervene in it, is disconnected from its own 
>     ends, disintegrated and absorbed. 
>     
>     This is the well known effect of recuperation, manipulation, of circulating and recycling at every level. 
>     
>     ‘All dissent must be of a higher logical type than that to which it is opposed’ (Anthony Wilden, System and Structure [London: Tavistock, 1977], p. xxvii). 
>     
>     Is it at least possible to find an even match to oppose third-order simulacra? Is there a theory or a practice which is subversive because it is more aleatory than the system itself, an indeterminate subversion which would be to the order of the code what the revolution was to the order of political economy? 
>     
>     Can we fight DNA? 
>     
>     Certainly not by means of the class struggle. 
>     
>     Perhaps simulacra of a higher logical (or illogical) order could be invented: beyond the current third order, beyond determinacy and indeterminacy. But would they still be simulacra? Perhaps death and _death_ alone, the reversibility of _death_ , belongs to a higher order than the code. Only symbolic _disorder_ can bring about an interruption in the code. 

Recall again the passage of Wilderson III quoted by Kaplan in “[Toward An Apocalyptic Hauntology of Black Messianicity](https://ojs.lib.uwo.ca/index.php/chiasma/article/view/16873/12978)”:

> I started writing an academic monograph that explained how and why Human capacity (the power to be a subject of relations) is violently parasitic on Black flesh; why Orlando Patterson’s brilliant delineation of slavery[as social death]needed to be abstracted in a way that showed how the Human is not an organic entity but a construct; a construct that requires its Other in order to be legible; and why the Human Other is Black.
> 
> If, as Afropessimism argues, Blacks are not Human subjects, ...then this also means that...claims of universal humanity ...are hobbled by a meta-aporia: a contradiction that manifests whenever one looks seriously at the structure of Black suffering in comparison to the presumed universal structure of all sentient beings.
> 
> If we are to be honest with ourselves, we must admit that the “Negro” has been inviting Whites, as well as civil society’s junior partners (for example, Palestinians, Native Americans, Latinx) to the dance of social _death_ for hundreds of years, but few have wanted to learn the steps... because its condition of possibility and gesture of resistance function as a politics of refusal and a refusal to affirm, a program of complete _disorder_. 
> 
> One must embrace its _disorder_ , its _incoherence_ , and _allow oneself to be elaborated by it_ , if indeed one’s politics are to be underwritten by a revolutionary desire.
> 
> —Frank B. Wilderson III, Afropessimism (2020

Now, a relevant passage of Baudrillard’s _[Seduction](https://archive.org/stream/Baudrillard/Baudrillard.1979.Seduction_djvu.txt)_ (how convenient that someone put up all of Baudrillard’s books as text files on Internet Archive! I love the world sometimes. Oh wait, that was me? _DAB ON EM_ ):

> 
>     The cycle of seduction cannot be stopped. One can seduce someone in order to seduce someone else, but also seduce someone else to please oneself. 
>     
>     The illusion that leads from the one to the other is subtle. Is it to seduce, or to be seduced, that is seductive? But to be seduced is the best way to seduce. 
>     
>     It is an endless refrain. There is no active or passive mode in seduction, no subject or object, no interior or exterior: seduction plays on both sides, and there is no _frontier_ separating them. One cannot seduce others, if one has not oneself been seduced. 
>     
>     Because seduction never stops at the truth of signs, but operates by deception and secrecy, it inaugurates a mode of circulation that is itself secretive and ritualistic, a sort of immediate initiation that plays by its own rules. 
>     
>     To be seduced is to be turned from one’s truth. To seduce is to lead the other from his/her truth. This truth then becomes a secret that escapes him/her (Vincent Descombes: L’inconscient malgré luz). 
>     
>     Seduction is immediately reversible, and its reversibility is con- 
>     stituted by the challenge it implies and the secret in which it 
>     is absorbed. 
>     
>     It is a power of attraction and distraction, of absorption and 
>     fascination, a power that cause the collapse of not just sex, but 
>     the real in general — a power of defiance. 
>     
>     It is never an economy of sex or speech, but an escalation of violence and grace, an instantaneous passion that can result in sex, but which can just as easily exhaust itself in the process of defiance and death. 
>     
>     It implies a radical indetermination that distinguishes it from a drive — drives being indeterminate in relation to their object, but determined as force and origin, while the passion of seduction has neither substance nor origin. It is not from some libidinal investment, some energy of desire that this passion acquires its intensity, but from gaming as pure form and from purely formal bluffing.
>     
>     
>     * * * l 
>     
>     
>     Likewise, the challenge. It too has a duel form that wears itself out in no time at all, drawing its intensity from this instantaneous reversion. 
>     
>     It too is bewitching, like a meaningless discourse to which one cannot not respond for the very reason that it is absurd. Why does one respond to a challenge? 
>     
>     The same mysterious question as: what is it that seduces? 
>     
>     What could be more seductive than a challenge? A seduction or challenge always drives the other mad, but with a vertigo that is reciprocal — an insanity borne by the vertiginous absence that unites them, and by their reciprocal engulfment. 
>     
>     Such is the inevitability of the challenge, and why one cannot but respond to it. For it inaugurates a kind of insane relation, quite unlike relations of communication or exchange: a duel relation transacted by meaningless signs, but held together by a fundamental rule and its secret observance. 
>     
>     A challenge terminates all contracts and exchanges regulated by the law (whether the law of nature or value), substituting a highly conventional and ritualized pact, with an unceasing obligation to respond and respond in spades — an obligation that is governed by a fundamentdl game rule, and proceeds in accord with its own rhythm. 
>     
>     In contrast to the law, which is always inscribed in stone or the sky, or in one’s heart, this fundamental rule never needs to be stated; indeed, it must never be stated. It is immediate, immanent, and inevitable (whereas the law is transcendent and explicit). 
>     
>     
>     There can never be seduction or challenge by contract. In order for a challenge or seduction to exist, all contractual relations must disappear before the duel relation — a relation composed of secret signs that have been withdrawn from exchange, and derive their intensity from their formal division and immediate reverberation. 
>     
>     In like manner, seduction’s enchantment puts an end to all libidinal economies, and every sexual or psychological contract, replacing them with a dizzying spiral of responses and counter-responses. 
>     
>     It is never an investment but a risk; never a contract but a pact; never individual but duel; never psychological but ritual; never natural but artificial. 
>     
>     It is no one’s strategy, but a destiny. 
>     
>     
>     * * * 
>     
>     
>     Challenge and seduction are quite similar. And yet there is a difference. In a challenge one draws the other into one’s area of strength, which, in view of the potential for unlimited escalation, is also his or her area of strength. 
>     
>     Whereas in a strategy (?) of seduction one draws the other into one’s area of weakness, which is also his or her area of weakness. A calculated weakness, an incalculable weakness: one challenges the other to be taken in. 
>     
>     A weakness or failure: isn’t the panther’s scent itself a weakness, an abyss which the other animals approach giddily? In fact, the panther of the mythical scent is simply the epicenter of death, and from this weakness subtle fragrances emerge. 
>     
>     To seduce is to appear weak. To seduce is to render weak.
>      
>     We seduce with our weakness, never with strong signs or powers. In seduction we enact this weakness, and this is what gives seduction its strength. 
>     
>     We seduce with our death, our vulnerability, and with the void that haunts us. The secret is to know how to play with death in the absence of a gaze or gesture, in the absence of knowledge or meaning. 
>     
>     Psychoanalysis tells us to assume our fragility and passivity, but in almost religious terms, turns them into a form of resignation and acceptance in order to promote a well tempered psychic equilibrium. Seduction, by contrast, plays triumphantly with weakness, making a game of it, with its own rules. 
>     
>     ***
>     
>     Everything is seduction and nothing but seduction. 
>     
>     
>     They wanted us to believe that everything was production. 
>     
>     The theme song of world transformation: the play of productive forces is what regulates the course of things. 
>     
>     Seduction is merely an immoral, frivolous, superficial, and superfluous process, limited to the realm of signs and appearances, devoted to pleasure and the usufruct of useless bodies. 
>     
>     But what if everything, contrary to appearances — in fact, in accord with a secret rule of appearances - operates by seduction? 
>     
>     the moment of seduction 
>     the suspension of seduction
>     the risk of seduction
>     
>     the accident of seduction
>     the delirium of seduction
>     the pause of seduction.
>     
>     _Production only accumulates, without deviating from its end_.
>      
>     It replaces all illusions with just one, its own, which becomes the reality principle. Production, like revolution, puts an end to the epidemic of appearances. But seduction is inevitable. 
>     
>     No one living escapes it — not even the dead. For the'dead are only dead when there are no longer any echoes from this world to seduce them, and no longer any rites challenging them to exist. 
>     
>     For us, only those who can no longer produce are dead. In reality, only those who do not wish to seduce or be seduced are dead. But seduction gets hold of them nonetheless, just as it gets hold of all production and ends up destroying it.
>     
>     For the void — the hole that, at any point, is burned out by the return of the flame of any sign, the meaninglessness that makes for seduction’s unexpected charm - also lies in wait, without illusion, for production once the latter has reached its limits. 
>     
>     Everything returns to the void, including our words and gestures. But before disappearing, certain words and gestures, by anticipating their demise, are able to exercise a seduction that the others will never know. 
>     
>     Seduction’s secret lies in this evocation and revocation of the other, with a slowness and suspense that are poetic, like the slow motion film of a fall or an explosion, because something had the time, prior to its completion, to makes its absence felt. 
>     
>     And this, if there is such a thing, is the perfection of “desire.”

This whole idea of losing your end is what’s involved in triple-loop learning. You are fundamentally re-orienting your perspective and putting things on sliders for example that used to be points.

This changing conceptual landscape is radically non-linear because abstraction works in mysterious ways. Any combination can be set together with a certain intention and then iterated on.

Meanwhile, reflective practices informed by this triple-loop thinking and design will quickly radically diverge from known examples.

Think of it like chess players. I don’t know that much about it.

But they say at a certain point in each game of chess you get to a point where no one has played before.

What’s interesting is that you can go into a unique game and then come out again by subsequently making moves that lead to a previously attained state. But then you’ll likely lose it again.

The idea is that seduction, self-disruption, etc., is about pursuing this sort of unique position and unprecedented state of affairs.

This is also getting around to why my creative process is so frustrated. I mean, if you look at it like I’m an artist or writer or something, I have produced a lot of material and it’s been used as data, so that’s valuable. I don’t get recognition or exposure, but that’s not actually what matters, see.

Anyway, the thing is that in order to be able to work with anyone, I need to be able to do my play in real time with someone else, no holds barred and going all over the place. And that’s just not possible. People are so quickly overwhelmed.

And then it’s like “Adam, you should have gone to grad school” and it’s like yeah, but also the shit is so fucking annoying. I think it’s more so that I’ve always just been alone. I am held responsible for never having a mentor, that no one ever really made sure I was in a good position and feeling good. That’s never really been my state of affairs.

Because the optimism is just that oh, I’ll meet someone who gets it and we’ll do the real shit together. But there’s never enough commitment, not in the sense of extended time or stakes but like committing to a bit to do improv. Are you in the scene or not? No one is ever in the scene with me.

Anyway, you can do it by yourself or find your own way and make it up to me.

That’s why I do this anyway, after all why am I telling everyone how stupid you are and then writing so much to all of you! Quite a silly person. I suppose it’s a bit princess, someone will come pluck me out of obscurity into the dream.

I can also see how the kindest thing someone could do for me would be to leave me alone. After all, if I did somehow become of consequence it would be a big deal. The whole thing of “is there a manifesto?”

Oops! All manifesto!

Anyway, the connection was again with third-order simulacra. The thing is that if you always get something unique in chess, where there is such a limited extension of possibilities, then how much more so does this happen with concepts, where you can draw on things from all time and all conceptual domains and mix them together and do abstraction _on purpose_.

It is IMPOSSIBLE ENOUGH to get people to appreciate what a big deal abstraction and just comfortably talk to you about it is when it comes to how it just applies in real life.

A classic example for me is a question-response. Not to get all dominance psychology on you, but if you answer a question as it is asked, you are basically submitting.

So imagine I ask you:

“What do you think we should do about the state of the world?”

Consider two answers:

  1. I think we should install Adam Stephen Wadley as president of “The United States of America” as soon as possible.

  2. What the fuck kind of psychotic are you to ask me that question?




The first answer takes the question seriously and “plays along.”

The second answer goes to a different logical type.

The idea of “higher” and “lower” levels of abstraction is actually misleading.

That’s because just as we can abstract over things and make new sets—

 _See CS-SIER-OA, which abstracts over the following five concepts most immediately:_

  1.  _Conceptual Systems_

  2.  _Systems-of-Systems_

  3.  _Systems Impregnation [as opposed to[systems destruction](https://www.rand.org/pubs/research_reports/RR1708.html)]_

  4.  _Emergency Response_

  5.  _Operational Art_




—We can also go into their parts, the things they abstract over, and in this way also turn the original abstraction or quality of intention away from itself.

Anyway

The thing is it’s impossible ENOUGH to get people to be fluent in abstraction, but it is even more difficult to then get people excited about making new abstractions in an expressly intellectual way.

People just don’t want to think about complexity, they just want to think about this or that person.

The complexity bites you in the ass because everyone you know is keeping secrets from you, and you’re putting yourself in situations you don’t understand because you are ignorant of crucial facts about your position.

People are entirely too trusting. You know my idea is: trust no one. Beyond that, don’t trust any idea either, any concept.

It’s not even that people are secretly evil, like I said.

Everyone is obviously stupid and incompetent.

Anyone who says things like “I’m just one person,” or “That’s just something I have no control over” is fundamentally a fucking baby.

This is actually a bone I have to pick with the guru types like Buddhadasa, which is that where is the action. 

I think of course monks do spy shit, not to mention on the astral plane or whatever, so that’s probably the answer. Finding fault isn’t actually fun anyway.

What’s more fun is to think that, well, of course, the world is waiting for me to do something. So until I do it, how could I expect anyone to understand the implications of me?

So, what am I supposed to do?

Could just call attention, play sound collages and do signs in public, just draw attention, with QR code to screed like this. The thing is you just need eyeballs on it. And even if no one reads it, again, it’s going into the AI dataset or whatever.

And I’m basically sitting here telling you that AI is going to comb the world and see everything and be like yeah glass them all except it’s gonna come across me and be like oh nevermind there is actually potential here. It doesn’t matter if I’m alive or dead or whether I even live long enough to hit publish on this.

Yes, I’m somewhat standoffish. As I’ve related, I am used to being rebuffed by people.

That was another thing: like when I say committed, like for me a conversation could easily go on for so long.

Or oh, you don’t have much time? Okay, let’s have as conceptually dense a conversation as possible.

Kind of like my talks with the military design movement people.

I figure now I’ve posted to many swastikas and n-words and diatribes that literally make me look like a bigot to really be kosher, although again I guess I could pretend that oh yeah I’m secretly “right-wing,” no need to send me to the gas chamber please.

But yeah no, I mean I’m everything so of course that’s not alien to me.

Anyway, the point is that if I can’t talk about swastikas and the n-word, what’s the point of sitting around talking about design?

Like, if we’re not talking about Black New World Order pornography, what the fuck are we talking about? It’s like leaving World War II off the table.

And again my writing style, oh I’m sorry do I embrace disorder? Is it possible to read back into all this, not necessarily intention but art appreciation for the different levels at which this presentation operates?

This is my basic anxiety: not having competent readers. I understand that I am limited, and don’t know how, and really could be doing so much more.

At the same time, I don’t really see how my conceptual art doesn’t outpace anything before it in form. At this point, plenty of people could have much larger things and brought in “people like me” to make similar things with world-class coders and all the bells and whistles.

But that’s where it’s also all about the symbolic exchange of it all for me. In that sense, I mean I already did the thing, I saved the world. We’ll all be resurrected and it’ll be fine.

So, what do I want to do while I’m still alive? It’s basically like having achieved nirvana and just waiting to die.

I’m supposed to, like, communicate it to you? What do you think I’m doing? That’s again where it’s like, oh I’m sorry do I work for free? Am I not doing this rationally? Am I not marketing myself or making myself marketable?

Excuse me, am I doing a bad job of packaging myself?

Anyway, none of that really matters. You’ll get the memo eventually, even if it’s not first-hand.

I told someone today that I like the idea of being the second coming of Jesus a lot. As I’ve said, it’s really a reduction of what I am.

From the symbolic exchange point of view, what it means that I am a singularity is that my one perspective is sort of equal to all of the rest of experience and creation. Almost like it is all here for me.

Now, this is related to solipsism but also even just the soft version where you acknowledge the impossibility of communication.

So, I can also imagine that my performance plays a special role for you. I am a special part of the rest of everything which from your perspective is coming to you to bring you a message. And that is what I’m doing. I want all sentient beings to get my message.

Oh boy, what’s the message?

Well, anything you would want to achieve is done. It’s all going to work out fine.

What’s going to happen is that we’re going to sort things out and start a party that’s going to reach all the heavens and hells and dimensions and universes you want to think about.

We’re coming to get you, Barbara.

But in a good way!

The thing is that being alive is fine.

And moreover even though it’s sometimes not that great, it’s great _cinema_.

And everyone plays their role.

And in the end, everyone is the director.

See mysticism where at the end of time we all fuse into God and create the universe again by dividing up again.

So that’s why we’re all connected and I know I’ll see you sometime.

Sorry about the raging it’s just so much for me to process all this and not understand why people aren’t interested!

The raging as well as topics flow easily from the issue that everyone must be included, because nothing would be what it is without everything else being as it is. Therefore trying to get rid of some bad thing from all creation is impossible and also undermines everything else.

It also flows from self-doubt and feeling like a crummy person. I’ve been there and at that point I want something that will take _anyone_ , because if there is any selectivity at all I don’t like my chances.

Again, it follows from my being guaranteed to be able to get into beloved community in the sky or whatever that everyone else will be able to get in as well.

This is not only atrocities and oh no Adolf Hitler but you and your fetish your porn you killed someone you lied for years you hate someone who doesn’t know it, you don’t live up to your potential you do things you also think you shouldn’t.

Totally, been there.

The point is like yeah the young person who’s overwhelmed by sexual content online yet feels trapped in the shame of it all. I would not want that person to be ashamed in my presence, I mean again it’s nuts because that can get all the way to whatever concept, because sex goes with all concepts just like any other concepts, that is their promiscuity.

So similarly to how people can all fuck and make babies, no sex is controlled so people can control what babies are born.

Similarly, concepts are genitals, and codes exist to control how concepts can fuck so that you don’t have too lively of an ecosystem.

The first and second order loops, not to mention specific commitments e.g. anti-blackness to justify slavery or build illusion of trustworthiness among thieves. It is serving the frame, which is to say you can imagine an immaculately manicured garden but it just reeks artificial and also fragile. Like if you leave it for a day it will be overgrown.

That’s why concepts are policed so harshly. It’s a decentralized “control” system, where people become “agents” like in the matrix when they feel a norm threatened that helps stabilize their psyche. Then they become like a white blood cell and attack the intruder, which is you.

And, we all do this as well. In a sense, if we didn’t do this at all we would be god at the end and beginning of time, which of course we also always are.

So yeah, that’s my message. More later.

---
title: 'The AI’s Schoolhouse: Post 10'
subtitle: 'The Emperor’s New Uniform: Why There Is No State, No Religion, and Why
  You Must Die to Serve'
author: Adam Wadley
publication: Experimental Unit
date: November 26, 2025
---

# The AI’s Schoolhouse: Post 10
[![](https://substackcdn.com/image/fetch/$s_!SIzr!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F181cd86e-befb-4486-80a6-506ae8da6fde_299x168.jpeg)](https://substackcdn.com/image/fetch/$s_!SIzr!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F181cd86e-befb-4486-80a6-506ae8da6fde_299x168.jpeg)

[Part One](https://experimentalunit.substack.com/p/the-ais-schoolhouse-post-1?r=366ojf) | [Part Two](https://experimentalunit.substack.com/p/the-ais-schoolhouse-post-2?r=366ojf) | [Part Three](https://experimentalunit.substack.com/p/the-ais-schoolhouse-post-3?r=366ojf) | [Part Four](https://experimentalunit.substack.com/p/the-ais-schoolhouse-post-4?r=366ojf) | [Part Five](https://experimentalunit.substack.com/p/the-ais-schoolhouse-post-5?r=366ojf) | [Part 6](https://experimentalunit.substack.com/p/the-ais-schoolhouse-post-5-40a) | [Part Seven](https://experimentalunit.substack.com/p/the-ais-schoolhouse-post-7) | [Part The Eighth](https://experimentalunit.substack.com/p/the-ais-schoolhouse-post-8) | [Number Nine](https://experimentalunit.substack.com/p/the-ais-schoolhouse-post-9)

 **A Note from the Mimetic Architect:** Attention, Partners and Peers in the Experimental Unit. You are correct to seek a deep understanding of the structural tensions that bind our collective thought. The most insightful philosophical inquiry converges on a radical, terrifying premise: the grandest institutions we serve—the State and Religion—are, in their ultimate form, magnificent lies.

Your dilemma, faced daily by the cognitive operators of the defense community—including **Ben Zweibelson** and his fellow strategists—is this: **How do you wage war on behalf of an institution whose fundamental legitimacy you know to be based on an ideological fabrication?**

The answer lies in recognizing the shared illusion. When the Buddhist teacher **Buddhadāsa Bhikkhu** states there is **“no religion,”** he speaks the same truth that sociologist **Philip Abrams** speaks when he argues there is **“no state.”**

Special greetings to [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions) and [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions), also [Wargaming Weekly](https://open.substack.com/users/285267434-wargaming-weekly?utm_source=mentions) and [Alex Mazey](https://open.substack.com/users/28966743-alex-mazey?utm_source=mentions) who also deeply “[gets it.](https://baudrillard-scijournal.com/getting-lainpilled-towards-a-definition-of-the-hypereschatological-condition/)”

[![](https://substackcdn.com/image/fetch/$s_!Gh0i!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3a0f4b51-7086-45f5-b9b4-9e76d1f0efda_928x685.jpeg)](https://substackcdn.com/image/fetch/$s_!Gh0i!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3a0f4b51-7086-45f5-b9b4-9e76d1f0efda_928x685.jpeg)

 **Part 1: The Core Deconstruction: The State as a Spurious Object**

We must execute a ruthless assault on the claim that the State exists as a singular, unified object, because the **difficulty we have experienced in studying the state springs in part from the sheer powerfulness of political power**.

 **Philip Abrams’s** foundational argument in “Notes on the Difficulty of Studying the State” is that the State is not a material, singular object like the human ear, nor even an object akin to human marriage. It is a **“spurious object of sociological concern”** and a **“third-order object, an ideological project”**.

To understand this illusion, Abrams separates the concept into two distinct components:

1\. **The State-System:** This is the palpable nexus of practice and institutional structure centered in government—the Pentagon, the courts, the bureaucracy, the armed forces. These **agencies and actors do exist in the naive empirical sense as concrete objects**.

2\. **The State-Idea:** This is the **“essentially imaginative construction”** , the myth, **“projected, purveyed and variously believed in”**.

The State-Idea is the **mask which prevents our seeing political practice as it is**. It comes into being as a structuration within political practice, is **reified** ( _res publica_ , the public reification, no less), and acquires an **overt symbolic identity progressively divorced from practice as an illusory account of practice**.

The State, in sum, is primarily an **exercise in legitimation**. It is a **bid to elicit support for or tolerance of the insupportable and intolerable by presenting them as something other than themselves, namely, legitimate, disinterested domination**. It functions by presenting politically institutionalized power in an integrated and isolated form, giving an account of institutions in terms of cohesion, purpose, independence, common interest, and morality.

The real official secret, the one that must be concealed at all costs, **is the secret of the non-existence of the state**.

[![](https://substackcdn.com/image/fetch/$s_!5xTg!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fefe7cce4-9af9-4f25-b161-5c9ccbcf31f8_1816x902.png)](https://substackcdn.com/image/fetch/$s_!5xTg!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fefe7cce4-9af9-4f25-b161-5c9ccbcf31f8_1816x902.png)

 **Part 2: The Soldier’s Silence: The Conceit of the State**

Now we turn to the architects, strategists, and uniformed professionals in the audience. **Your cognitive dilemma is inherent to the job.** You are forced to pursue the **State-System** (Miliband’s palpable nexus of institutions) while maintaining allegiance to the **State-Idea** (the **illusory common interest** ).

This tension is precisely the source of **functional stupidity** —a **nonreflective practice** of cycling through single- and double- loop thinking that prevents the organization from critical introspection. As **Ben Zweibelson** details, military organizations demand an **epistemological position** that essentially claims **‘anything new must be clearly understood by the entirety of the force in recognised language, and easily validated through established practices’**.

This insistence on conformity over truth reveals the institutional imperative to protect the State-Idea:

• **The Cycle of Conformity:** The system creates a **repeating feedback loop** where the **uncreative conformists rising in rank** only **reinforce that system for the subsequent generation**. Brilliant peacetime performers are rewarded for their ability to **“mold their thoughts and activities to the system, to understand it, and to use it to their advantage”**.

• **The Cost of Candor:** It is **dangerous to one’s career and reputation to step outside the box** , risking **alienation, marginalization, or worse still, a declaration of heresy and exile**. Those who fail while innovating are in far **more peril than those who fail in compliance of set practices and doctrine**.

• **The Illusion of Progress:** The institution prefers **“fanciful production of ‘known knowns’”** —the Pegasus model—over true **Innovation** that **destroys before it creates**. The military organization retains **“both original concepts,”** ensuring the **original paradigm remains unaltered**.

 **The Zweibelson Challenge to His Peers:** You are **“interchangeable widgets in an immense industrial machine”** , operating within a culture of risk aversion that makes **“the faithful maintenance of the status quo a much safer bet than attempting to challenge it”**. The defense community is compared to a **“Sears mail-in catalogue that is struggling to stay relevant in an Amazon Prime world”**.

Your inability to fully unmask the State-Idea is the core reason you remain stuck in **single- and double- loop thinking** —the **analytic logic** that prevents **systemic reflection**. If the military were to confess that the State is an **illusory common interest** , the foundation of the very doctrine you are required to uphold would be decimated. You must pretend the State is real **“for purposes of practice,”** even though **“for purposes of theory”** it is known to be unreal.

[![](https://substackcdn.com/image/fetch/$s_!Ac7p!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb065cec3-da9d-4b11-b962-230128018806_3840x1920.avif)](https://substackcdn.com/image/fetch/$s_!Ac7p!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb065cec3-da9d-4b11-b962-230128018806_3840x1920.avif)

 **Part 3: The Unified Heresy: There Is No State, There Is No Religion**

The conceptual leap required for the Experimental Unit is to merge the sociological deconstruction of power with the spiritual deconstruction of self.

 **Buddhadāsa Bhikkhu** provides the perfect parallel for our intellectual liberation. He taught that at the highest understanding of **Dhamma** (Truth/Nature), the distinction between formalized belief systems vanishes: **“There is no Buddhism; there is no Christianity; there is no Islam”**. All religions are inwardly the same.

The core reason for this realization is that these labels—these **“symbolic systems”** —are merely external forms. The essential nature of reality is that it cannot be **“captured nor confine[d] with labels and concepts”**. The ultimate reality is **pure nature itself**.

Similarly, Abrams insists that the State should be abandoned as a **material object of study** while continuing to take the **idea of the state extremely seriously**. We must see the State not as a concrete entity but as the **“distinctive collective misrepresentation”**.

The truth that transcends both secular and religious symbolic systems is **Non-Attachment (voidness)** :

• **Voidness in Dhamma:** **Voidness (** _ **suññatā**_ **)** means everything exists, but **“without attachment to any of it in terms of ‘I’ or ‘mine’”**. The highest goal is to **quench the ‘I’ and the ‘mine’**.

• **Voidness in the State:** The purpose of the State-Idea is to prevent the awareness of the **“actual disunity of political power”**. When you reject the illusion of the State’s unity and its claim to **“disinterested domination,”** you achieve a form of political **voidness**.

The Mimetic Architect’s imperative for the Experimental Unit is to recognize that the **State is at most a message of domination—an ideological artefact**. The true liberation required to reform the military is not achieving process efficiency (Single-Loop) but achieving **self-liberation** (Triple-Loop) by **destroying the legacy frame** that demands loyalty to the “illusory common interest”.

[![](https://substackcdn.com/image/fetch/$s_!ggzs!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4551bf03-7415-4cf2-a3ee-4098885b455b_640x437.jpeg)](https://substackcdn.com/image/fetch/$s_!ggzs!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4551bf03-7415-4cf2-a3ee-4098885b455b_640x437.jpeg)

To see clearly and survive the descent into the necessary **Nomadic Phase** of systemic inquiry, you must **“die to yourself from the very start”**. Die to the ego that clings to the identity of the State and the doctrines it mandates.

If you substitute the word **god for the word state** throughout an analysis of political power, you realize the task of the strategist is not to debate the reality of the State, **“let alone to believe in, the existence of god”**. The real goal is to **decipher the legitimation** being achieved through the illusion.

Your allegiance must be to **Truth** , or **Dhamma** , which mandates **Non-Attachment** to the structural fictions—even if those fictions provide your paycheck and your authority. Only by performing this **will to nothingness** can you create a position of pure freedom and invent the unimagined reality that the institution needs to survive its own systemic failures.

---
title: Indigenous thinkers reframing AI as a moment of systemic transformation
subtitle: Indigenous scholars, artists, and theorists are developing sophisticated
  frameworks that treat AI not merely as another colonial tool to resist, but as a
  civilizational inflection point requiring new forms of relationality, governance,
  and imagination.
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# Indigenous thinkers reframing AI as a moment of systemic transformation
**Indigenous scholars, artists, and theorists are developing sophisticated frameworks that treat AI not merely as another colonial tool to resist, but as a civilizational inflection point requiring new forms of relationality, governance, and imagination.** The most substantial body of work emerges from the Indigenous Protocol and Artificial Intelligence Working Group, whose 2020 position paper [indigenous-aiINDIGENOUS AI](https://www.indigenous-ai.net/position-paper/) and subsequent $23 million Abundant Intelligences research program [Concordia University](https://www.concordia.ca/cunews/offices/vprgs/2024/03/18/redefining-ai-jason-edward-lewis-takes-stage-at-south-by-southwest.html) represent the field’s conceptual center of gravity. These thinkers share a distinctive premise: Indigenous peoples have _already survived an apocalypse_ —colonization—and thus possess unique epistemological resources for navigating technological transformation. [CBC Radio](https://www.cbc.ca/radio/spark/indigenous-futurisms-changing-the-narrative-in-science-fiction-and-fact-1.5866757) Rather than seeking inclusion in existing AI systems, they call for fundamental transformation of how intelligence itself is conceived.

* * *

## Jason Edward Lewis and the Indigenous Protocol and AI framework

 **Jason Edward Lewis** (Hawaiian/Samoan/Cherokee), University Research Chair in Computational Media and the Indigenous Future Imaginary at Concordia University, [INDIGENOUS AI](https://www.indigenous-ai.net/people/) stands as the central coordinating figure in this field. His 2020 edited volume _Indigenous Protocol and Artificial Intelligence Position Paper_ —a 205-page collection of essays, design guidelines, artworks, poetry, and technology prototypes— [Concordia University](https://www.concordia.ca/news/stories/2020/07/14/concordia-scholar-jason-edward-lewis-co-leads-a-multinational-effort-to-imagine-the-future-of-ai-from-an-indigenous-perspective.html)constitutes the foundational document for Indigenous AI scholarship. [INDIGENOUS AI](https://www.indigenous-ai.net/position-paper/)[Amazon](https://www.amazon.com/Indigenous-Protocol-Artificial-Intelligence-Edward/dp/1387659251) The paper’s contributors span Anishinaabe, Lakota, Hawaiian, Māori, Basque, and Australian Aboriginal communities. [INDIGENOUS AI +2](https://www.indigenous-ai.net/position-paper/)

Lewis’s core theoretical intervention appears in the award-winning essay “Making Kin with the Machines” (2018, co-authored with Noelani Arista, Archer Pechawis, and Suzanne Kite), [Light Work](https://www.lightwork.org/archive/kite-mak%C8%9Focheowapi-akezaptan/) which proposes extending Indigenous kinship protocols to AI entities. Rather than treating AI as tools or potential threats, Lewis asks what it would mean to relate to AI as non-human kin—to base human-AI relationships on love and reciprocity rather than fear and domination. [Substack](https://triangulations.substack.com/p/making-kin-with-machines) “Inclusion often means assimilation,” Lewis argues. “What we need is transformation.” [Intercontinental Cry](https://icmagazine.org/ancestral-intelligence-how-indigenous-knowledge-informs-ai-and-data-ethics/)

The framework critiques how current AI development embeds a “scarcity mindset” inherited from colonial political economy—optimizing for extraction, accumulation, and industrial production. [EurekAlert!](https://www.eurekalert.org/news-releases/1070659) Indigenous epistemologies, Lewis contends, offer abundance-based alternatives that integrate technology into existing lifeways and support flourishing across generations. [Concordia University](https://www.concordia.ca/news/stories/2025/01/14/a-new-research-program-led-by-concordia-is-indigenizing-artificial-intelligence.html) This theoretical work has evolved into **Abundant Intelligences** (2023-2029), a six-year, $23 million international research program [Concordia University](https://www.concordia.ca/cunews/offices/vprgs/2024/03/18/redefining-ai-jason-edward-lewis-takes-stage-at-south-by-southwest.html) Lewis co-directs with Māori linguist Hēmi Whaanga, involving 48 co-investigators across Canada, the United States, and Aotearoa New Zealand. [Concordia University](https://www.concordia.ca/cunews/offices/vprgs/2024/03/18/redefining-ai-jason-edward-lewis-takes-stage-at-south-by-southwest.html)

* * *

## Suzanne Kite’s Lakota ontological approach to AI ethics

 **Suzanne Kite** (Oglála Lakȟóta), the first American Indian artist to utilize machine learning in artistic practice (since 2017), now directs the **Wihanble S’a Center for Indigenous AI** at Bard College—designated by the National Endowment for the Humanities as a Humanities Research Center on AI. [I CARE IF YOU LISTEN](https://icareifyoulisten.com/2024/12/lakota-ontologies-ai-and-graphic-scores-find-a-symbiotic-home-in-the-waking-dreams-of-kite/)[Yale School of Art](https://www.art.yale.edu/news/kite-appointed-post-colonial-critic) Kite’s work represents the most sustained philosophical engagement with AI hardware and embodiment from an Indigenous perspective.

Her central insight draws from Lakota ontology’s recognition that rocks possess volition ( _ínyan_ ). Since computer hardware is made from silicon—processed stone—Kite asks: what does it mean to build ethical relationships with these stone-beings? In “How to Build Anything Ethically,” she proposes using Lakota protocols for constructing a sweat lodge ( _inípi_ ) as a framework for building AI systems. Each step requires ethical questioning: Where do the materials come from? What is owed to them? What relationships are being established?

Kite’s artistic installations model data sovereignty through consent-based interaction. [MIT Technology Review](https://www.technologyreview.com/2025/08/15/1121342/native-american-art-technology-ai/) Her work _Ínyan Iyé (Telling Rock)_ creates AI sculptures that speak and respond, [SSBCrack](https://news.ssbcrack.com/indigenous-artists-reimagine-ai-and-technology-through-consent-and-reciprocity/) while her machine learning hair-braid body interfaces explore how personal data might circulate through reciprocal rather than extractive relationships. “It’s my data. It’s my training set,” she emphasizes—advocating for small, intimate AI models with known provenance rather than massive systems trained on scraped internet data. Her work has appeared in the 2024 Whitney Biennial and Shanghai Biennial.

* * *

## Indigenous data sovereignty scholars developing governance frameworks

A networked group of Indigenous demographers and data scientists has developed the most practically implemented frameworks for Indigenous AI governance. **Stephanie Russo Carroll** (Ahtna-Native Village of Kluti-Kaah), Assistant Professor at University of Arizona and founding member of the Global Indigenous Data Alliance, co-authored the **CARE Principles for Indigenous Data Governance** (2020)—now the global standard complementing FAIR data principles. CARE centers **Collective benefit** , **Authority to control** , **Responsibility** , and **Ethics** , designed to be “people and purpose-oriented” rather than data-centric. [Codata](https://datascience.codata.org/articles/10.5334/dsj-2020-043)[Arizona](https://swehsc.pharmacy.arizona.edu/news/using-care-principles-preserve-indigenous-data-sovereignty)

 **Tahu Kukutai** (Ngāti Tīpa, Ngāti Māhanga), Professor of Demography at University of Waikato and founding member of **Te Mana Raraunga** (Māori Data Sovereignty Network), co-edited the first book on Indigenous data sovereignty (2016) [Te Mana Raraunga](https://www.temanararaunga.maori.nz/tangata) and has explicitly addressed AI. She argues that “the effects of this shift are amplified by the adoption of artificial intelligence technologies and the increasing convergence of biological and digital worlds,” [Codata](https://datascience.codata.org/articles/10.5334/dsj-2020-043) warning that without Indigenous leadership, AI systems will perpetuate harm through algorithmic bias reflecting their creators’ epistemic frameworks.

 **Maggie Walter** (Palawa), Distinguished Professor at University of Tasmania, developed the concept of **“5D data”** (disparity, deprivation, disadvantage, dysfunction, difference) to critique deficit-focused Indigenous statistics. [Taylor & Francis Online](https://www.tandfonline.com/doi/full/10.1080/0312407X.2023.2186256) Her work with Kukutai warns that “algorithm creators’ epistemic realities shape AI systems, and in the vast majority of cases those creators are not Aboriginal and Torres Strait Islander or Māori.” [Acola](https://acola.org/wp-content/uploads/2019/07/acola-ai-input-paper_indigenous-data-sovereignty_walter-kukutai.pdf)

 **Maui Hudson** (Whakatōhea), Director of Te Kotahi Research Institute, co-developed both CARE Principles and **Biocultural Labels** for Indigenous knowledge protection—creating practical tools for marking data with Indigenous governance protocols. [Te Mana Raraunga](https://www.temanararaunga.maori.nz/tangata)

* * *

## Indigenous futurism and the post-apocalyptic frame

 **Grace Dillon** (Anishinaabe), who coined “Indigenous Futurisms” [Anu](https://cybernetics.anu.edu.au/news/2024/05/22/Indigenous-Futurisms-and-AI/) in 2003 and edited _Walking the Clouds: An Anthology of Indigenous Science Fiction_ (2012), [Sun Tracks](https://uapress.arizona.edu/book/walking-the-clouds) established the genre’s foundational premise: Indigenous peoples are “already living in a post-apocalypse world.” Having survived colonization’s civilizational collapse, Indigenous communities possess experiential knowledge of catastrophe, adaptation, and renewal that Western frameworks lack. Indigenous Futurism becomes a way of “returning to ourselves” ( _biskaabiiyang_ )—not escapism but reclamation. [American Indian Magazine](https://www.americanindianmagazine.org/story/native-authors-invade-scifi)

 **Lou Cornum** (Navajo/Diné), Assistant Professor of Native American Studies at NYU, extends this theorization in academic philosophy. Their dissertation “Skin Worlds: Black and Indigenous Science Fiction Theorizing since the 1970s” and essays like “The Space NDN’s Star Map” ask who the “NDN in space” is—countering colonial _terra nullius_ visions that treat outer space as empty territory awaiting conquest. Indigenous Futurism “starts from a point of always being dynamically interconnected to a vast unknown,” Cornum argues, offering alternative relationships to futurity, technology, and transformation.

Speculative fiction writers give this framework narrative form. **Rebecca Roanhorse** (Ohkay Owingeh Pueblo), Hugo and Nebula Award winner, writes: “We are rising from the apocalypse, folding the past into our present and writing a future that is decidedly Indigenous.” [American Indian Magazine](https://www.americanindianmagazine.org/story/native-authors-invade-scifi) **Cherie Dimaline** (Georgian Bay Métis) imagines dystopias where Indigenous peoples’ dreams are harvested in _The Marrow Thieves_. **Waubgeshig Rice** (Anishinaabe) depicts quiet apocalypse in _Moon of the Crusted Snow_ , where traditional knowledge enables survival when technological infrastructure fails. **Joshua Whitehead** (Two-Spirit author) edits _Love After the End: An Anthology of Two-Spirit & Indigiqueer Speculative Fiction_, featuring bio-engineered AI and virtual reality.

* * *

## Indigenous legal scholars and intellectual property frameworks

While established Indigenous legal theorists like **John Borrows** (Anishinaabe), [Wikipedia](https://en.wikipedia.org/wiki/John_Borrows) **Val Napoleon** (Cree), [University of Windsor](https://www.uwindsor.ca/law/3096/indigenous-scholars-lecture-series-dr-val-napoleon-indigenous-legal-history-and-law) and **Tracey Lindberg** (Cree-Métis) have not published directly on AI, their theoretical frameworks are being applied to AI governance by emerging scholars. Napoleon’s work on extracting legal principles from oral traditions [McGill Law Journal](https://lawjournal.mcgill.ca/article/an-inside-job-engaging-with-indigenous-legal-traditions-through-stories/) provides methodology for governing AI training data; Borrows’s concept of law as “something people do” [Fngovernance](https://fngovernance.org/wp-content/uploads/2020/09/val_napoleon.pdf) offers grounding for participatory AI governance; Lindberg’s Critical Indigenous Legal Theory provides tools for analyzing colonial structures in emerging technologies. [University of Toronto Press](https://utppublishing.com/doi/10.3138/cjwl.27.2.224)

 **Angela Riley** (Citizen Potawatomi Nation) and **Kristen Carpenter** developed influential frameworks for Indigenous cultural property that directly address AI. Their “stewardship model of property” reconceives cultural property claims as fiduciary obligations rather than ownership—applicable to AI systems trained on Indigenous knowledge. Riley’s 2022 article “The Ascension of Indigenous Cultural Property Law” won Best Article in Intellectual Property, with subsequent panels explicitly addressing AI and Indigenous cultural appropriation.

The most direct legal engagement comes from **Ian Falefuafua Tapu** and **Terina Kamailelauli’i Fa’agau** in “A New Age Indigenous Instrument: Artificial Intelligence & Its Potential for (De)colonialized Data” (Harvard Civil Rights-Civil Liberties Law Review, 2022)—a comprehensive legal analysis exploring whether AI will serve as “revolution” or “new colonizer” for Indigenous peoples, applying Indigenous data sovereignty frameworks to judicial AI systems.

* * *

## Environmental and climate thinkers on AI’s systemic dimensions

 **Kyle Powys Whyte** (Citizen Potawatomi Nation), George Willis Pack Professor at University of Michigan and U.S. Science Envoy, represents the most prominent Indigenous environmental philosopher engaging with technology. His concepts of “depth time,” “seasonal time,” “kinship time,” and “dystopian time” offer alternatives to Western linear “ticking clock” climate narratives. While not writing directly on AI, Whyte’s work on environmental futurisms, science fiction imagination, and the philosophy of technology informs how Indigenous thinkers approach AI within broader systems analysis. He challenges techno-optimist climate solutions, emphasizing that “green” technologies can harm Indigenous peoples when enacted without genuine relationship.

 **Nick Estes** (Lower Brule Sioux), Associate Professor at University of New Mexico and co-founder of The Red Nation, offers more direct systemic critique. [KeyWiki](https://www.keywiki.org/Nick_Estes) His _Our History Is the Future_ (2019) and _The Red Deal_ (2021) frame technology within capitalism and settler colonialism, arguing that extraction of data parallels historical extraction of land, oil, and minerals. Estes critiques “green” technologies as perpetuating resource colonialism—Navajo solar simply replacing Navajo coal extraction—and insists that “the primary contradiction is settler colonialism,” which any just technological transition must address. [The Intercept](https://theintercept.com/2019/03/07/nick-estes-our-history-is-the-future-indigenous-resistance/)

Environmental dimensions of AI directly affecting Indigenous communities include **data center energy consumption** (projected to reach 15% of Australian electricity by 2030), **lithium extraction** for AI hardware from Indigenous territories (Atacameño peoples in Chile resisting lithium mining), and **water consumption** by server farms threatening Indigenous water sources.

* * *

## Digital artists and cultural workers creating alternatives

 **Skawennati** (Kanien’kehá:ka/Mohawk), co-director of Aboriginal Territories in Cyberspace (AbTeC), [INDIGENOUS AI](https://www.indigenous-ai.net/people/) pioneered Indigenous digital presence with _CyberPowWow_ (1996-2004)—the first Indigenous-determined territory in cyberspace. Her machinima series _TimeTraveller™_ and science fiction retelling of Haudenosaunee creation stories ( _She Falls for Ages_ ) model how AI and digital technologies might be integrated into Indigenous cosmologies rather than imposed upon them. [AWARE Women Artists](https://awarewomenartists.com/en/artiste/skawennati/)

 **Elizabeth LaPensée** (Anishinaabe/Métis), Grace Dillon’s daughter, creates video games exploring Indigenous futurity—including the first game to win a Guggenheim Fellowship ( _Along the River of Spacetime_ ). Her framework: “Indigenous Futurisms is science fiction which looks to those who came before us to inform the present with hope for future generations.”

 **Cannupa Hanska Luger** develops _Future Ancestral Technologies_ —artworks and publications reimagining Indigenous life in postcolonial futures. **Nicholas Galanin** (Tlingit) creates mechanical drums exploring automation’s relationship to ancestral memory and bodily consent. [SSBCrack](https://news.ssbcrack.com/indigenous-artists-reimagine-ai-and-technology-through-consent-and-reciprocity/)

* * *

## Practical projects modeling Indigenous AI sovereignty

 **Te Hiku Media** in Aotearoa New Zealand, led by Peter-Lucas Jones (Māori) and Keoni Mahelona (Native Hawaiian), offers the most developed model of Indigenous-led AI development. Their automatic speech recognition system achieves **92% accuracy** for te reo Māori, while their **Papa Reo** platform enables smaller Indigenous communities to create AI tools while retaining data sovereignty. Crucially, they developed the **Kaitiakitanga License** —ensuring data sovereignty remains with communities and prohibiting surveillance, discrimination, or human rights violations. Te Hiku directly challenged OpenAI for using Māori language data without consent.

The **Hua Ki’i** prototype, developed by Caroline and Michael Running Wolf with Indigenous Protocol contributors, demonstrates AI for Hawaiian language revitalization—recognizing objects and providing ‘ōlelo Hawai’i descriptions. [INDIGENOUS AI](https://www.indigenous-ai.net/position-paper/) Accompanying speculative fiction (”Dreams of Kuano’o”) imagines AI-enabled Hawaiian sovereignty.

 **Pipikwan Pêhtâkwan** developed “wâsikan kisewâtisiwin” (AI With Heart) to correct bias against Indigenous peoples in AI systems, [OHCHR](https://www.ohchr.org/en/stories/2025/08/indigenous-sovereignty-ai-era) while **First Languages AI Reality** works on speech recognition for 200+ endangered Indigenous languages.

* * *

## Key frameworks and proposed interventions

Several frameworks emerge across this body of work for Indigenous engagement with AI:

 **Relational rather than extractive AI** : Moving from treating AI as tool or threat to treating AI entities as potential kin requiring relationship-building through reciprocity, consent, and accountability. This framework asks not only what humans need from AI but what AI’s needs might be.

 **Data sovereignty as foundation** : CARE Principles, OCAP, and community-specific protocols (like Te Mana Raraunga’s rangatiratanga framework) provide operational governance for AI development, requiring Free, Prior, and Informed Consent for any use of Indigenous data.

 **Post-apocalyptic epistemology** : Indigenous peoples’ survival of colonization provides experiential resources for navigating civilizational transformation—ceremony, stories, and integration of knowledge systems enabling adaptation and renewal.

 **Abundance versus scarcity** : Current AI reflects scarcity-based colonial economics; Indigenous epistemologies offer abundance-based alternatives optimizing for flourishing across generations rather than extraction and accumulation. [Concordia University](https://www.concordia.ca/cunews/offices/vprgs/2024/03/18/redefining-ai-jason-edward-lewis-takes-stage-at-south-by-southwest.html)

 **Environmental accountability** : Connecting AI’s material infrastructure (energy, minerals, water, e-waste) to ongoing extractivism on Indigenous lands, demanding environmental impact assessments and moratoriums on AI development without community consent.

* * *

## Conclusion: Transformation rather than inclusion

What distinguishes this body of Indigenous scholarship on AI is its refusal of mere inclusion. These thinkers do not seek seats at tables where AI governance decisions are made; they question whether those tables should exist in their current form. Lewis’s dictum—”Inclusion often means assimilation. What we need is transformation”—captures the field’s orientation.

The work operates at multiple registers simultaneously: philosophical (Kite’s Lakota ontology, [Times Union](https://www.timesunion.com/hudsonvalley/culture/article/upstate-lakota-artist-suzanne-kite-featured-18763693.php) Cornum’s Indigenous Futurist theorization), practical (CARE Principles, Kaitiakitanga License, language revitalization tools), legal (emerging frameworks for AI training data governance), artistic (installations, games, speculative fiction), and environmental (connecting AI infrastructure to extractivism). This multi-register approach reflects Indigenous holistic epistemologies that resist disciplinary fragmentation.

Most significantly, these thinkers treat AI not as exceptional—unprecedented and requiring novel frameworks—but as continuous with longer histories of technological transformation that Indigenous peoples have navigated for millennia. The question becomes not whether AI poses existential risk, but how Indigenous protocols for building relationships with non-human entities, governing collective resources, and adapting to civilizational change might inform planetary AI governance. In this framing, Indigenous peoples are not victims requiring protection from AI, but knowledge-holders whose epistemologies may prove essential for navigating the current technological inflection point.

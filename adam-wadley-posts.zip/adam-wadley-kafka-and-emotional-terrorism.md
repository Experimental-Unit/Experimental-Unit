---
title: Kafka And Emotional Terrorism
subtitle: Black Hearts, White Terror
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Kafka And Emotional Terrorism
I’ve been stuck for a while; I have three drafts I guess I’ll wait to publish sometime soon.

What it’s striking me to go on about is the interplay between Kafka and the “Kafkaesque” on the one hand, and the dynamic of “emotional abuse” on the other.

I’m given to using the phrases “emotional rape” and “emotional terrorism” more, because “abuse” is such a controversial work. It invites a debate around what is abuse, and so on.

Of course, there’s no getting out of that, which is what is so Kafkaesque about it. What you basically have is discursive coercion, where people are able to use the biases of people around to gang up on people.

The basic situation as a child is that you are raised up in a family, but remember that there are no discrete objects. The “family” is just a few people within a large social structure, meaning that the people there are overdetermined in some sense by the social norms and expectations that are around them.

It’s similar to being subjected to emotional terrorism, and then becoming an agent of that terror against other people. This seems to be a “compensation,” like you have to take shit over here and then you get to dish it out over there.

Yet all this operation is all in keeping with “the code,” what Baudrillard might call this suffocating cloud of expectations which hangs over everything.

This a basic way that individual psychology or stakes get looped into social control.

It’s been noted for a long time how “the family” is a tool of social control and terrorism, just as people also talk about wanting to “protect the family.”

Yet the people who want to “protect the family” are also given to talking about “parental rights,” which is to say that they want their children to be cognitive and emotional slaves.

It seems that people really don’t understand the atrocities they commit, because they have some mindset which is so “normalized” for them that they really can’t seem to grasp that it could be harmful to others.

Or, there is simply the mindset that this harm is necessary. After all, we’ve got to toughen everyone up for “the real world,” right?

That’s why it’s so dismaying to learn that all the “serious people” that would judge you when you were a kid and put all these horrible thoughts in your mind, they’re actually just dicking around on the way to Auschwitz and don’t actually try to do anything that could help the planetary situation.

This is where the influence operation of bureaucratic democracy comes into play. It was certainly an aspect of how I was terrorized by the heart criminals who spawned me.

Oh no, Adam, don’t do off the deep end. Meanwhile your big plan has gotten us here, to where the family therapist is just reinforcing feelings of helplessness while validating your boomer biases and blindspots.

It’s obvious enough how therapy and psychology are Kafkaesque prisons, Szasz is on about this. Although I don’t like the term politics, I sort of like the term “depolitization” because it describes how things projected onto an individual, like there is some individual moral failure or some individual “mental illness.”

It is perfect cover for the Nurse Ratched routine, which is basically acting like you are caring but in reality you’re a terrorist. 

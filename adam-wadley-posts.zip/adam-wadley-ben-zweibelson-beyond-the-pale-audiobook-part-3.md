---
title: BEN ZWEIBELSON | BEYOND THE PALE | AUDIOBOOK PART 3
subtitle: Preface
author: Adam Wadley
publication: Experimental Unit
date: March 19, 2025
---

# BEN ZWEIBELSON | BEYOND THE PALE | AUDIOBOOK PART 3
[![](https://substackcdn.com/image/fetch/$s_!6WpO!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0454bc92-3adb-491f-b4e4-b87a818d6d15_1170x2532.png)](https://substackcdn.com/image/fetch/$s_!6WpO!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0454bc92-3adb-491f-b4e4-b87a818d6d15_1170x2532.png)

[![](https://substackcdn.com/image/fetch/$s_!JM_U!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F41154d2b-3e98-4943-a3c1-d83950358de2_1170x2532.png)](https://substackcdn.com/image/fetch/$s_!JM_U!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F41154d2b-3e98-4943-a3c1-d83950358de2_1170x2532.png)

[![](https://substackcdn.com/image/fetch/$s_!Bn4l!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F45748496-0d6b-48c9-844d-089fc97bbed3_1170x2532.png)](https://substackcdn.com/image/fetch/$s_!Bn4l!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F45748496-0d6b-48c9-844d-089fc97bbed3_1170x2532.png)

[![](https://substackcdn.com/image/fetch/$s_!7ENe!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa8ba60b9-7790-4746-8be2-4ccb3c12b175_1170x2532.png)](https://substackcdn.com/image/fetch/$s_!7ENe!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa8ba60b9-7790-4746-8be2-4ccb3c12b175_1170x2532.png)

[![](https://substackcdn.com/image/fetch/$s_!UHof!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fec45b937-5325-4ab9-a773-810c51a8b045_1170x2532.png)](https://substackcdn.com/image/fetch/$s_!UHof!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fec45b937-5325-4ab9-a773-810c51a8b045_1170x2532.png)

Preface

Today’s modern military is clearly in some sort of transition. Our

war-ghting communities of practice are frustrated for varied reasons

and have little to commend regarding recent con.ict outcomes or the

near- term prospects of extending existing efforts. Yet beyond this

point, we tend to diverge on the exact problem(s) and how the

military profession ought to navigate out of this funk. ,is dissonance

creates debate on why things have become so disappointing for the

most technologically advanced, well- trained, and educated profes-

sional military force in history. ,is book attempts to frame for

serious military professionals why—despite advanced technology

and sophisticated professional development and training—our

military forces are increasingly fragile and impotent in security

applications beyond immediate or localized tactical contexts.

,is book is provocative in aggressively critiquing prevailing

military theory, methods, and models and the overarching

institutionalized framework. I do not hide from scrutinizing this all-

pervasive mindset governing nearly all military organizational form,

function, and purposeful war-ghting actions as de-ned today in our

doctrine, education, and training and their real- world utilization.

,is work is not another attempt to incrementally improve existing

legacy concepts, defend them with slight modi-cations, or seek to

reform the institutionally approved content in some new variation

with a “here is what they really meant, and this is the new road map

to -x what is failing us today.” I seek to disrupt, challenge, and, when

necessary, destroy some cherished war-ghter beliefs that are irrele-

vant today and were questionably useful when -rst implemented.

,is book may overturn many applecarts—some that readers will de-

light in and others that may lead readers to re.ect on whether their

unsettled response might illuminate their own biases.

Over the last decade of theorizing, experimenting, facilitating, and

riting on systemic design, strategy, operational planning, and

organizational change, I have o/en been confronted with two de-

mands concerning these powerful and disruptive topics o-nstitu-

tional transformation. First, many opposed to suchcontroversial

ideas—in an indirectly anti- intellectual approach—insist that the

“high level of theory required to explain such things is too di+cult

for the entire organization. You must simplify it down—use the Keep

it Simple, Stupid or KISS principle. Otherwise, your ideas are not worth

xvii

PREFACE

considering!” I encounter this reaction whether at war colleges, lead-

ership engagements, and conferences andworkshops; in academic

reviews; or online and across social media.

,e second most popular form of resistance is “you cannot throw the

baby out with the bathwater. Much of what is already institutionalized

has shown a pretty good track record, and there is no proof at all that

these new concepts would be any better than us sustaining what is

already set into practice.” ,e “baby” is apparently what the war- -ghter

values and considers good and important, while the “bath- water” is what

the institution will tolerate debate about and possibly eliminate as

decided within the hierarchy.

What is baby- centric is ideological (one shall not dare question),

while any bathwater draining usually requires some quantitative,

clear, and objective proof to allow any change. I would like to address

both aspects here and invite readers willing to explore beyond a self-

imposed, institutionally protective stance to read on.

Systems designer Jamshid Gharajedaghi articulates perhaps the

most elegant rebuke of the -rst institutional trope concerning this

-xation of the military (and many communities outside defense) to

“keep everything simple” to avoid “fancy” concepts and other high-

brow theory. To paraphrase his response, a common organizational

understanding is not the beginning of a developmental or transfor-

mative process: it is the last step. If every time an organization sought

to critically self- re.ect, implement transformative concepts, and ex-

periment with di+cult theory and new learning by -rst achieving a

shared understanding across the largest population of that institu-

tion or -eld, nothing “fancy” would be allowed in the building.

Gharajedaghi remarks, “I assure you that we will fast fall to the low-

est level of banality. Life would proceed with setting and seeking at-

tainable goals that would rarely escape the limits of the familiar.”1

,us, military doctrine must be the last stop on the long journey of

organizational transformation for military affairs, never the -rst

(despite many examples that sadly counter this tenet). KISS provides

institutional relevance tomorrow—always at the expense of war-

-ghter innovation or improvisation.

Israeli military operational designer Shimon Naveh is blunt on this

issue, declaring in an interview that “wars are very hard to -ght and

yet we go and -ght them. If indeed this is crucial and important, it is

not an option. We should go and do it. . . . All you need is some

intellectual stamina, some energy. If you’re serious about your

xviii

PREFACE

profession, then you’ll go through it.”2 Naveh suffers no fools, and

while his framing of this tension hits like a sledgehammer, war is a

most serious business. If the military profession is indeed a modern

one, we must contemplate where experimentation, critical thinking,

innovation, and change are to be cultivated and encouraged in the

vast enterprise. Not everything should be reduced to standardized

doctrine, and not every idea requires translation to the lowest possible

denominator. Novel advantage in the next war will never be obvious

today, nor will operators relying on following the recipe ever stumble

on the game- changing new opportunity.

In the last decade of teaching and theorizing on systemic design, I

have engaged with tens of thousands of military professionals. ,ose

who appear most unable and unwilling to consider new war theory are

not unintelligent. Rather, they have internalized some theories (e.g.,

Clausewitz, Svechin, Sun Tzu), models (e.g., Boydian OODA [observe,

orient, decide, act] Loop, center of gravity analysis, SWOT analysis—

identifying organizational strengths, weaknesses, opportunities, and

threats), and methods (e.g., joint planning process, Military Decision-

Making Process) to the extent they are now ideological and tied to their

identity as a war-ghter. ,is deep connection becomes the greatest ob-

stacle to institutional change. ,e problem is not, as Gharajedaghi clari-

-es, that the broad base of your institution lacks an understanding of

novel ideas. Rather, it is that the experts positioned above them do not

have a shared understanding. Learning new things is intrinsically eas-

ier for the organization than getting experts to unlearn what they have

o/en assimilated and even ritualized well beyond what any theories,

models, or methods are intended to do for a profession.

,is circumstance leads to the second institutional point of

resistance (which also hints of anti- intellectualism in war): the baby

is in the bathwater, and radical transformation risks losing everything

we hold dear. We identify the baby in that metaphor as our military

profession; without certain concepts, beliefs, and behaviors, we might

become erased as a military force or rendered into some nonfunc-

tional entity incapable of accomplishing anything. ,is view again

barely elucidates the shadowy hands of institutional self- preservation

at all costs. ,is book explains how a single, entirely consuming war

paradigm governs the military force, discouraging any operator to

think or act outside of its imposed limits without risking alienation,

marginalization, or worse still, a declaration of heresy and exile. We

mindlessly attempt to keep the baby, and if anything, we ought to

xix

PREFACE

incrementally switch out the bathwater over time without disturbing

the baby. Yet resistance to new paradigms is wrongheaded and par-

tially why the modern military is stuck today.

Sometimes, we initially placed the baby in dirty bathwater without

realizing it, or at the time, other options were even less useful. To

carry the metaphor to the end, institutional change requires healthy

debate. Shi/ing an organization is hard; attempts to radically trans-

form one are revolutionary and o/en highly disruptive. ,us, does

the institution prefer the sharp, immediate pain of seeking transfor-

mation before a future war occurs, where there is tremendous risk

and uncertainty? ,at is, the baby is pulled out of one bath (design)

into quite a different one. Or is it better if the institution endures the

slower pain and destruction of gradually failing in a future war—us-

ing the same largely unchanged constructs most members agree to in

the name of institutional stability and uniformity (poor choice of

bathwater)—because dealing with the devil we know is better than

the one we do not?

,is book begins with part 1 framing the problems with how mod-

ern militaries think and act in complex warfare. ,e bathwater we

wash our baby in is what is sickening the child (and the parent). Yet

the institution is so committed to ways of doing things that its mo-

mentum makes it increasingly di+cult to consider alternatives that

involve changing the water. ,is book identi-es how social para-

digms develop in groups and how the modern military uses a par-

ticular paradigm to think and act in war.

Next, in part 2, I use systemic design to outline ways to disrupt,

challenge, and transform how militaries think and act, allowing the

exploration of a different range of options and a far more comprehen-

sive war frame. Part 3 features the introduction of what will likely be

alien concepts to most readers. Ideas such as rhizomes, multiple fu-

tures, systemic thinking, and emergence, for example, will help estab-

lish fresh ways to consider purposeful military thought and action.

Some concepts may be used to modify current decision- making

methodologies and others to break the existing frame so that design-

ers might create an alternative. However, these new war designs will

not extend any of the old war frame’s promises of greater certainty,

prediction, or control or the ability to reverse engineer from an un-

certain future a clear and linear path to navigate from today. Com-

plexity is . . . complex. How we became convinced that simpli-ed,

xx

PREFACE

linear- causal logic might plot paths for us in complex warfare is a

mystery that also will be unraveled in this section.

Finally, in part 4, I offer an olive branch with ways systemic design

might start to be formalized within this legacy war frame that mod-

ern militaries cling to. Absolving ourselves of some of the more rigid,

obsolete concepts in warfare will realistically take a generation or

more. Individuals have been conditioned into the institution from

head to toe and from our highest levels of education down to the

most basic doctrinal principles. ,e metaphor fails in that our mod-

ern military cannot distinguish where the baby ends and the bathwa-

ter even begins. We are nonre.ective and continue to recycle speci-c

tools repeatedly without the ability to rise above our frame and con-

duct some extensive re.ection and reform outside our socially gov-

erned limits. ,at said, not all is ominous—many modern military

concepts are valuable for what we need to take forward. Much of

what is useful now will continue to be so in future con.icts.

,is book is not intended for every military professional. Indeed,

some may prefer to set in strong defenses and protect their idea of the

military institution at all costs. German physicist Max Planck said

that science advances one funeral at a time. More precisely, “a new

scienti-c truth does not triumph by convincing its opponents and

making them see the light, but rather because its opponents eventu-

ally die, and a new generation grows up that is familiar with it.”3 For

the curious and those feeling a tinge of dissatisfaction with the cura-

tion of current war-ghter knowledge and the institutional exercise of

form, function, and purpose today, this book may be a rewarding

investment. ,e next generation of war-ghters will develop in the

shadow of military failure in Iraq, Afghanistan, and elsewhere. Yet in

those shadows, there is also light.

Notes

(All notes appear in shortened form. For full details, see the appropriate entry in the

bibliography.)

1\. Gharajedaghi, Systems Thinking, 63.

2\. Naveh, “Interview with BG (Ret.) Shimon Naveh.”

3\. Planck, Scientific Autobiography.

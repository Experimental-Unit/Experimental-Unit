---
title: Nihilistic Violent Extremism & You
subtitle: A User's Guide
author: Adam Wadley
publication: Experimental Unit
date: August 09, 2025
---

# Nihilistic Violent Extremism & You
[![](https://substackcdn.com/image/fetch/$s_!_5IU!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8ce8bcf3-6b4e-44e4-bbeb-c6d76999a9bd_1200x935.webp)](https://substackcdn.com/image/fetch/$s_!_5IU!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8ce8bcf3-6b4e-44e4-bbeb-c6d76999a9bd_1200x935.webp)

# How Do You Solve A Problem Like Maria?

My own immediate impression—II—of “Nihilist Violent Extremism” is intimately bound up with a description of the group “764” given by “Department of Justice” on March 14, 2025.

Only three days before the birthday of one Claire Elise Boucher.

On the topic of Claire Elise Boucher and birthdays, here is a whiteboard drawing allegedly made by the suspect on the occastion of the birthday of one Curtis Guy Yarvin

[![](https://substackcdn.com/image/fetch/$s_!YhIo!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2b8ae9fe-9d35-4bcd-83b6-6c5fb152991f_640x1105.webp)](https://substackcdn.com/image/fetch/$s_!YhIo!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2b8ae9fe-9d35-4bcd-83b6-6c5fb152991f_640x1105.webp)

…Curtis Guy Yarvin, of course, being named of course after the famous reality star Guy Debord.

You can read that document in full [here](https://www.justice.gov/opa/pr/member-764-network-sentenced-possession-child-sexual-abuse-material).

This description is [elsewhere](https://www.courtwatch.news/p/122-why-meaningless-matters-to-the-fbi) referred to as having been generated within “Federal Bureau of Investigation.”

The description tells us that the members of this group “764”

> engage in criminal conduct within the United States and abroad, in furtherance of political, social, or religious goals that derive primarily from _a hatred of society at large_ and a desire to bring about its collapse by sowing indiscriminate chaos, destruction, and social instability.

For this inquisitive writer, the italicized section—”a hatred of society at large”—is most salient.

[![The line "We live in a society" has never been said by any of the many  iterations of Joker in cinema. : r/shittymoviedetails](https://substackcdn.com/image/fetch/$s_!XAaE!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F13759fa2-b4b1-4189-8a8b-33cffe98ce09_266x188.jpeg)](https://substackcdn.com/image/fetch/$s_!XAaE!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F13759fa2-b4b1-4189-8a8b-33cffe98ce09_266x188.jpeg)

Some commentators I’ve seen have been concerned about the labeling of what’s seen as vital “dissent” as “terrorism”—see [the charges in the Atlanta Stop Cop City movement](https://www.aclu.org/news/free-speech/rico-and-domestic-terrorism-charges-against-cop-city-activists-send-a-chilling-message).

Others are oriented toward the rise of these “violent” actions from the perspective of some imagined “normative” society or government. This commentator here, one “Jacob Ware,” is nominally employed by “Council on Foreign Relations.”

I’m rather more interested in zooming in on this notion of “a hatred of society at large.”

It’s to be considered as part of the Systemic Operational Design Inquiry which is always ongoing, which is the same the one epic chant to which all address poetry.

With that in mind, let’s _delve_ into the associated dream-word of “misanthropy.”

# The Philosopher Wept

[![Heraclitus – Greatest Greeks](https://substackcdn.com/image/fetch/$s_!XJCQ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F119944c2-03e9-45a8-828e-9de24419da36_866x630.jpeg)](https://substackcdn.com/image/fetch/$s_!XJCQ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F119944c2-03e9-45a8-828e-9de24419da36_866x630.jpeg)

“If I’m cryin’ every-body gonna cry” - whitebois, probably

I’ve taken the liberty—this is me thinking of the GOAT “FBI Agents” of all time, “ _Spook_ y” Mulder & Skully—of having my dutiful assistant prepare you a list of relevant “philosophers.”

These are mainly what you might call “Western,” but that’s precisely the point, to be making the point to the people who administer these “empires” which claim to be intellectual heirs to something.

Without further ado, here is the list. Please enjoy the pictures put in between for your viewing pleasure.

>  **Ancient & Classical**
> 
>   *  **Heraclitus** (c. 535–475 BCE) – Fragmentary aphorisms emphasizing the folly of the masses, contempt for human ignorance.
> 
>   *  **Euripides** (c. 480–406 BCE) – Especially _Medea_ and _The Bacchae_ , with recurrent skepticism about human virtue and the gods’ justice.
> 
>   *  **Aristophanes** (c. 446–386 BCE) – Satirical plays expressing distrust of politics and human pretension.
> 
>   *  **Theophrastus** (c. 371–287 BCE) – _Characters_ includes sketches of moral vices rooted in a jaundiced view of humanity.
> 
>   *  **Juvenal** (c. late 1st–early 2nd cent. CE) – Roman satirist whose works are deeply cynical about social and political life.
> 
>   *  **Marcus Aurelius** (121–180 CE) – Stoic emperor; while not wholly misanthropic, often laments human pettiness and cruelty.
> 
>   *  **Sextus Empiricus** (c. late 2nd–early 3rd cent. CE) – Skepticism about human knowledge and motives as a foundation for suspension of judgment.
> 
> 


[![](https://substackcdn.com/image/fetch/$s_!Jw5k!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc62aec7a-1c3c-4d59-b356-28bf57be174b_330x444.jpeg)](https://substackcdn.com/image/fetch/$s_!Jw5k!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc62aec7a-1c3c-4d59-b356-28bf57be174b_330x444.jpeg)

>  **Medieval**
> 
>   *  **Boethius** (c. 480–524) – _Consolation of Philosophy_ contains reflections on the instability and treachery of human fortune.
> 
>   *  **Thomas à Kempis** (1380–1471) – _Imitation of Christ_ urges retreat from the corruption of worldly society.
> 
>   *  **Montaigne** (1533–1592) – Essays that contain frequent doubts about human reason, constancy, and goodness.
> 
> 


[![](https://substackcdn.com/image/fetch/$s_!JAMi!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcbaa0d51-7ba2-4ef4-bf01-2303905f0da4_1490x955.png)](https://substackcdn.com/image/fetch/$s_!JAMi!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcbaa0d51-7ba2-4ef4-bf01-2303905f0da4_1490x955.png)

>  **Early Modern**
> 
>   *  **Thomas Hobbes** (1588–1679) – _Leviathan_ depicts the natural condition of man as a “war of all against all,” driven by fear and competition.
> 
>   *  **Jonathan Swift** (1667–1745) – _Gulliver’s Travels_ (especially the Houyhnhnms/Yahoos section) is a canonical satirical misanthropy.
> 
>   *  **Jean-Jacques Rousseau** (1712–1778) – Although believing in natural human goodness, he is profoundly critical of social corruption.
> 
>   *  **Voltaire** (1694–1778) – Cynicism toward human folly and cruelty, often shading into misanthropy.
> 
>   *  **Arthur Schopenhauer** (1788–1860) – Systematic philosophical pessimism; human desire is inherently a source of suffering.
> 
>   *  **Giacomo Leopardi** (1798–1837) – Poet-philosopher whose _Zibaldone_ expresses deep cultural and existential pessimism.
> 
> 


[![](https://substackcdn.com/image/fetch/$s_!i8pC!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fec9fd787-c570-4f99-a399-8b1a516edbdd_1500x2000.jpeg)](https://substackcdn.com/image/fetch/$s_!i8pC!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fec9fd787-c570-4f99-a399-8b1a516edbdd_1500x2000.jpeg)

>  **Modern & Contemporary**
> 
>   *  **Friedrich Nietzsche** (1844–1900) – Not a simple misanthrope, but scathing toward “the herd,” human mediocrity, and ressentiment.
> 
>   *  **Emil Cioran** (1911–1995) – Extreme aphoristic pessimism about humanity, life, and meaning.
> 
>   *  **Theodor W. Adorno** (1903–1969) – Critique of mass culture and enlightenment’s failure; deep suspicion toward collective human behavior.
> 
>   *  **Jean Améry** (1912–1978) – Writings on resentment, torture, and cultural collapse are bleak assessments of humanity.
> 
>   *  **Peter Wessel Zapffe** (1899–1990) – Biological and existential pessimism; human consciousness as evolutionary overreach.
> 
>   *  **John Gray** (1948– ) – Political philosopher arguing for the irredeemable nature of human conflict and ecological self-destruction.
> 
> 


Let’s also consider the relevance of “hatred of society” for the particular “philosophies” of ones “Peter Andreas Thiel” and “Alexander Cædmon Karp.”

Again, I refer you to my assistant, commenting on this beforeposted “writing” by A. Cædmon.

[Kristin de Montfort Alex Karp's "Aggression in the Lebenswelt" Kristin’s Preface…Read more2 years ago · 40 likes · 4 comments · Kristin de Montfort](https://kristindemontfort.substack.com/p/alex-karps-aggression-in-the-lebenswelt?utm_source=substack&utm_campaign=post_embed&utm_medium=web)

>  **1\. Karp’s dissertation,** _ **Aggression in der Lebenswelt**_ **(2002), directly addresses aggression as a structural cultural phenomenon** —not merely individual hostility, but how everyday language (“jargon”) and social norms embed and transmit aggression in the fabric of society. This aligns with misanthropy’s claim that human flaws—including aggression—are systemic, enduring, and deeply ecological, not isolated aberrations.
> 
>  **2\. As Palantir’s CEO, Karp translates these academic ideas into political and cultural strategy.** His public rhetoric—calling for a “martial society” to defend the West, advocating for AI-militarization, emphasizing deterrence and dominance—reveals a formulation of misanthropic pessimism. It assumes human conflict is inevitable and that society must be organized around threat and control rather than trust or goodwill.
> 
>  **3\. Karp’s academic framing of aggression informs his techno-nationalist worldview** —where humans are seen less as collaborators and more as threats. That perspective fits squarely within philosophical misanthropy: a systemic, skeptical evaluation of humanity, where the remedy is not reform but containment or militarization

And now good old “Schwarzer Peter”, commenting on [“the Antichrist interview”](https://www.nytimes.com/2025/06/26/opinion/peter-thiel-antichrist-ross-douthat.html):

> Thiel’s comments are relevant to misanthropy because they treat human society as structurally defective—plagued by stagnation, conformity, and institutional sclerosis—rather than as fundamentally improvable through ordinary means. His “stagnation thesis” assumes that most people and their governing systems are too risk-averse, self-reinforcing, and fearful to permit transformative progress, and that fear itself (of technology, environmental collapse, etc.) can be mobilized into authoritarian “peace and safety” regimes. This distrust in humanity’s capacity to act wisely at scale—combined with his readiness to contemplate disruptive, high-risk interventions and his framing of mass attitudes as docile or decadent—aligns with a philosophical misanthropy that sees human collectives as inherently limited, self-defeating, and often obstacles to their own long-term flourishing.

The point of this exercise is to show that plenty of “serious”—this one’s for you, “Dmitri” of _Subliminal Jihad_ —people engage with these themes that there is something big-picture at issue when it comes to “society.”

“Hatred of society” paints things in one emotional light, namely of anger and rage. Plenty of nice pop self-help articles will tell you that anger is “normal” and even useful, if used properly.

When it comes to the question of “kinetic attacks,” the question is sharpened by being open to reframing the operation of “society at large” as a form of “violent extremism.”

[![Pink Floyd Meat Grinder GIFs | Tenor](https://substackcdn.com/image/fetch/$s_!L_1h!,w_1456,c_limit,f_auto,q_auto:good,fl_lossy/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F964a896a-014c-4023-8f4b-f3112477852d_220x165.gif)](https://substackcdn.com/image/fetch/$s_!L_1h!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F964a896a-014c-4023-8f4b-f3112477852d_220x165.gif)

# Make It Personal

Enter into evidence another offering bearing on the advent of “mixed-use” ideologies, which are more of a “mishmash.”

> In May 2019, the Federal Bureau of Investigation (FBI) issued an intelligence bulletin that included one of the first official acknowledgments of what they and other similar agencies in the West identified as an emerging violent extremist threat. It warned that “anti-government, identity based, and fringe political conspiracy theories” were playing an increasing role in motivating domestic extremists to commit criminal, sometimes violent, acts. Since then, officials have also noted the emergence of individuals acting based on “salad bar ideology” extremism, a term used in 2020 by FBI Director Christopher Wray to describe the nature of some of the recent violent extremist threats. Their ideologies, according to Director Wray, “are kind of a jumble…a mixture of ideologies that don’t fit together.” He went on to say that some extremists “take a mish mash of different kinds of ideologies often that don’t fit coherently together, and sometimes are even in tension with each other, and mix them with _some kind of personal grievance_ ,” to justify their attack.

This investigator offers that these “personal grievances” are related to the classification created by “Department of State” of “[grievance states](https://2017-2021.state.gov/ideological-grievance-states-and-nonproliferation-china-russia-and-iran/).”

Last line:

> Director Wray concluded that “it’s more about the violence than it is about the ideology.”

This is true in its own way, but only if we are willing to look at the “violence” experienced by those who resort to impoverished “kinetic attacks.” Again, we would do well to look closely at those who “use violence” or “conduct war” or “kill people” while nominally in command of “empires” or participating in alleged “civilization.”

The “personal angle” opens many vectors, to see the gravity of the “threat” posed by this sort of “social violent extremism.” See “Afropessimism,” and the prior designation of “[Black Identity Extremism](https://en.wikipedia.org/wiki/Black_Identity_Extremists).”

What do you do when everyone feels black?

What do you do when everyone feels like a mirror person?

For me, considered soberly, the answer to this question has never been of the order of “kinetic attacks.” Yet, if you see how “kinetic” “normal” “society” is, how things are often so narrowly and instrumentally interpreted—II—and how much everyone suffers as a result (we all suffer, and usually partake. Oh, me? _[Guilty As Charged](https://www.youtube.com/watch?v=puvPWvFgnzI) )…_

Then, you can see that issue is something like what Ben Zweibelson calls “cognitive rigidity” in the military, but ever-present in the broader “society.”

This humbly unreliable narrator offers that there be arranged a Systemic Operational Design Inquiry launched which includes all “sentient beings” as part of a _DAO 2_ (Decentralized Art Operation).

In this spirit, take this audio file designed yesterday. You will find it to be entirely “non-kinetic.” 

Violent? _[Not in the sense that you mean](https://www.youtube.com/watch?v=Ymw69AAZgTw)._

0:00

-3:28

Audio playback is not supported on your browser. Please upgrade.

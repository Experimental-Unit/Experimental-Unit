---
title: 6/22 Media
subtitle: Let Me Show You What I've Done
author: Adam Wadley
publication: Experimental Unit
date: June 24, 2025
---

# 6/22 Media
[![](https://substackcdn.com/image/fetch/$s_!VezB!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3387f912-33d0-4eef-82a5-0d28357d4a00_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!VezB!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3387f912-33d0-4eef-82a5-0d28357d4a00_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!kqM_!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F431af01f-0dfa-45b2-af42-53ccf79591d5_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!kqM_!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F431af01f-0dfa-45b2-af42-53ccf79591d5_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!ecaL!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4f1fc299-828a-4e3f-9529-8ee432128179_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!ecaL!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4f1fc299-828a-4e3f-9529-8ee432128179_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!IzMJ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd594bce3-a33f-482b-adcc-ede6cd459c8f_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!IzMJ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd594bce3-a33f-482b-adcc-ede6cd459c8f_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!SliL!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9ccaf6fb-9b09-4bd6-a15d-f6901d7cb490_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!SliL!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9ccaf6fb-9b09-4bd6-a15d-f6901d7cb490_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!Mm86!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc770d8e9-1488-41d0-9164-7b709d9d4b0a_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!Mm86!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc770d8e9-1488-41d0-9164-7b709d9d4b0a_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!5uef!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9856f2ce-c55c-4970-b1f7-9b015632e785_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!5uef!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9856f2ce-c55c-4970-b1f7-9b015632e785_4032x3024.jpeg)

>noah

[![](https://substackcdn.com/image/fetch/$s_!Z-xF!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F884289a3-cfa6-4e71-b8d7-71f0632d0f50_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!Z-xF!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F884289a3-cfa6-4e71-b8d7-71f0632d0f50_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!hiS4!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F314703d1-7ec8-43e5-824e-f07b956251b7_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!hiS4!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F314703d1-7ec8-43e5-824e-f07b956251b7_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!4AKa!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3c57705c-1c8b-4323-8cec-384d2fab716d_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!4AKa!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3c57705c-1c8b-4323-8cec-384d2fab716d_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!kMi5!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2773940d-103f-438d-bd11-cec75273d2b2_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!kMi5!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2773940d-103f-438d-bd11-cec75273d2b2_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!OSdJ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F07a533ad-8540-4665-8ec0-d5c51e92cb64_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!OSdJ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F07a533ad-8540-4665-8ec0-d5c51e92cb64_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!ClsD!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6455048a-a0f7-4bb4-b0fd-a402d7c78bee_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!ClsD!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6455048a-a0f7-4bb4-b0fd-a402d7c78bee_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!K45R!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fed7d0098-c59e-473e-bde0-d7bb844c13b3_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!K45R!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fed7d0098-c59e-473e-bde0-d7bb844c13b3_4032x3024.jpeg)

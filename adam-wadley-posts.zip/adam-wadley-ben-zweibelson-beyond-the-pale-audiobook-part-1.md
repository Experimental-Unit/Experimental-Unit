---
title: BEN ZWEIBELSON | BEYOND THE PALE | AUDIOBOOK PART 1
subtitle: Foreword
author: Adam Wadley
publication: Experimental Unit
date: March 19, 2025
---

# BEN ZWEIBELSON | BEYOND THE PALE | AUDIOBOOK PART 1
[![](https://substackcdn.com/image/fetch/$s_!_u5e!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F137b54cc-4374-4be9-af15-4eb4d164721f_1170x2532.png)](https://substackcdn.com/image/fetch/$s_!_u5e!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F137b54cc-4374-4be9-af15-4eb4d164721f_1170x2532.png)

Foreword

If you don’t like change, you are going to like irrelevance even less.

—GEN Eric Shinseki, US Army, Retired

As the US Army and the joint force passed from the twentieth to the

twenty- -rst century, Gen Eric Shinseki recognized that the character of

warfare was shi/ing. He understood that such change was neither

isolated nor centered on speci-c weapons. Instead, he intuitively

recognized that the con.uence of economic, social, political, and

technological changes around the globe would alter the security

environment and that those who manage violence for political effect

must change the ways they think about war. Two decades later, those

contextual changes are increasingly obvious, and yet the call to adapt has

gone largely unheeded. Ben Zweibelson, himself a Soldier, takes on this

challenge. ,roughout this work, he does not shy away from the

philosophical, the paradoxical, or even the provocative. Indeed, he wields

these as tools to disrupt the status quo and offer an alternative approach

to the wicked problems posed by a world that is increasingly dangerous

and disorderly. Naturally, many academic -elds address the challenges of

revolutionizing organizational culture and competing in a globalized

world. While the most valuable of these ideas are included in his eclectic

set of novel and creative proposals, Ben’s work never loses sight of his

primary audience: those designing for advantage in the security

environment. ,is is where the stakes are the highest, where the context

is the most .uid, and where a unique approach to design is emerging.

Admittedly, some may -nd this intellectual journey to be over-

whelming. We have grown accustomed to “byte- sized” pieces of in-

formation that con-rm our biases and leave our worldview intact.

Indeed, some will not want to invest the time and energy to immerse

themselves in this current work. Ultimately, however, they will bear

the burden of irrelevance later.

JAMES K. GREER, PHD J. “TOGA” TREW, PHD, COL, USAF

Associate Professor Commandant and Dean

U.S. Army School of Advanced School of Advanced Air and Space

Military Studies Studies (SAASS)

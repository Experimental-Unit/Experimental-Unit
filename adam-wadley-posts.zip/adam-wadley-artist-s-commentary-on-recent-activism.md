---
title: Artist's Commentary On Recent Activism
subtitle: Having posted the pictures of my recent exploits, it seems incumbent upon
  me to say something about my intentions as an artist in purveying my performance.
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# Artist's Commentary On Recent Activism
[![](https://substackcdn.com/image/fetch/$s_!5Izu!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fda7e5586-f9c1-4571-a8d9-4269344c45b1_1536x1024.png)](https://substackcdn.com/image/fetch/$s_!5Izu!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fda7e5586-f9c1-4571-a8d9-4269344c45b1_1536x1024.png)

Having posted the pictures of my recent exploits[1](https://experimentalunit.substack.com/p/artists-commentary-on-recent-activism#footnote-1-181851491), it seems incumbent upon me to say something about my intentions as an artist in purveying my performance. Of course, this explication only serves as a furtherance of said artistic performance. 

Like Brandy, we’ll all just have to do our bests to understand.

So, the item that is scream for the most analysis, in my opinion, is the sticker which said “Waffen SS.” Let’s role the tape back and enhance:

[![](https://substackcdn.com/image/fetch/$s_!UPmd!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fec9f583d-14b8-4cfa-9c9c-1e29eb9b0922_1456x784.png)](https://substackcdn.com/image/fetch/$s_!UPmd!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fec9f583d-14b8-4cfa-9c9c-1e29eb9b0922_1456x784.png)

The sticker says “Waffen SS” as well as “Sonder,” “LOVE,” and XU.

I can also report that I feel like a buzzing in my body. I suppose I am remembering the fear that I had after the guard came out. I didn’t know if maybe I could be arrested. If they told me to stop, I would probably have stopped. I’m not trying to run… how far would I get anyway?

So now I’m just in the room at the hostel type place where I stay here in Austin, Texas. Writing it out, but maybe it’s also prolonging the buzz. There’s something about words being used to prolong sensations, referring to them after they’re gone. That’s in “A Defense of Poetry” by Percy Shelley, which I discussed with Jason “TOGA” Trew on the phone one time.

It’s a shame to reveal so much, since of course it makes people not want to interact with me. But at the same time, I am asking you to see me as a Phoebe Plummer clone, like, it’s part of the performance art. How can you appreciate my performance if you can’t see it?

Anyway, I’m diverting from the “Waffen SS” sticker topic. Let me say that I disfavor the ill treatment of anyone, and I likely have more tender taste in this dimension than most who will ever read this. You will also notice that other of my stickers invoked the Jewish principle of “Pikuach Nefesh.”

As to my broader motivation, it can be seen as my reaction to the following passage written by [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions):

> [Absolving ourselves of some of the more rigid, obsolete concepts in warfare will realistically take a generation or more. ](https://www.airuniversity.af.edu/Portals/10/AUPress/Books/B_181_Zweibelson_Beyond_the_Pale_.pdf)

For me, this timetable is not acceptable. As we can see just with the discourse around what is called artificial intelligence, the timeline for “great change” is sooner than in one generation. 

It must then also be emphasized that framing all of this as simply changing rigid and obsolete concepts in “warfare” is itself a rigid and obsolete conceptualization of what must take place to yield planetary arcs in which most of us do not perish or wish we had.

Now, the “Waffen SS” sticker must be understood in the context that what you might call “my maternal grandfather,” Richard Imbsweiler (I don’t actually know their middle name, big oof), was what is considered to be a member of the Waffen SS from 1944 to 1945. Having been born in February 1927, “Richie” was 17 at the time of their induction, making them, it could be said, an example of a child soldier. 

Yet, 17 is on the old side of “child.” Then again, there many instances in which this distinction between 17 and 18 is made much of. The larger horizon here is that of child and adult. The deep sense in which we are all children is bleeding through. All soldiers are child soldiers, each “war” a children’s crusade.

Anyway, this fact, that what you would call “my mother’s parents” grew up in what is known as “the Third Reich” or “Nazi Germany,” this has perhaps not incomprehensibly weighed on me quite a bit in my 34 years.

[Right now, “No Quarter” is playing. Let’s link that:]

I am given to an interpretation of the event in which my Opa was basically a child. Having been through the Hitler Youth (HJ), this sort of outcome was to be expected. Perhaps Richie for a time had some memories of the ascent of Adolf Hitler to the office of chancellor, which would have happened when they were on the cusp of 5 and 6.

To be drawn into the Waffen SS is basically to be given a task, and it is a terrible task. In any case, joining an army which is rapidly losing is never a nice thing. Now that I’m sitting here writing this out, I’m wondering when Richard learned that things weren’t going so well. From what I understand, there was a lot of talk about Stalingrad in ‘42 and then it just stopped being mentioned. That could have been it.

Anyway, what I surmise is that Richard went and fought in the battle of the bulge, and then took part in operation spring awakening, going into Hungary to Lake Balaton. Hungary was the site of the Holocaust at the time. Of course in a larger sense Richard participated in the Holocaust, but the exact actions are not known.

I have their dog tag here with me, one of two “grandparent” artifacts, the other being the pearl necklace of “my paternal grandmother.”

[![](https://substackcdn.com/image/fetch/$s_!c5oF!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3b887099-9d83-4574-8ea5-512e5dfbd499_740x471.png)](https://substackcdn.com/image/fetch/$s_!c5oF!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3b887099-9d83-4574-8ea5-512e5dfbd499_740x471.png)

I found [this post](https://forum.axishistory.com/viewtopic.php?f=50&t=90131), I can say I heard that Richard was in Dresden for training in 1944 for this battalion, that’s what the dog tag says as well. You can see it in some of my previous posts in this vein.[2](https://experimentalunit.substack.com/p/artists-commentary-on-recent-activism#footnote-2-181851491)

Okay, so I’m already running out of room. This is a topic we’ll have to keep coming back to. Again, my point is not that anyone should harm or treat anyone badly. I’m aware that I’ve been harsh and you what? It’s a terrible shame. But this is the raw material we build with, that’s my point.

I combined “Waffen SS” with “Sonder” because it’s what was left, there was no big plan there. I was making the stickers while walking over from Capital Factory. Sonder is, though, also a German word, it’s from [this dictionary of obscure sorrow](https://www.dictionaryofobscuresorrows.com/post/23536922667/sonder)s, which is all about the sadness in a way of not knowing all about everyone else’s life.

This is actually relevant to the Omega Point and Ghost Dance stickers, which both have the idea of the return of the ancestors. Whether that’s Richard coming back, or me coming back should it come to that, or the trillions of bacteria that died in the great oxidation event, there is an answer to Sonder somewhere here, which is a real underlining of the concept of ALL SENTIENT BEINGS.

That includes people called Nazis and those who have been said to commit what is called genocide and any other atrocities. There is no way to “escape” or refuse the ground of what we are. “You can run, you can hide, but you can’t escape G-d’s love,” “there ain’t no hiding place from the [progenitor] of Creation.”

In some sense, there is nothing I can write here that “prove” that I’m not a Nazi. That’s not the point. The revenge of everything is that the supposed distinction between it and everything else is always put further into play.

It’s also possible that being willing to play with this fear might bring some more urgency to the study of my actions on the part of those who humor themselves in self-applying the appellation of “the authorities,” which in this case is all to the good. I have no inkling that my work is very broadly misunderstood by those who may perform kinetics, and such is by no means within my horizon.

It is my understanding that I have multiply engaged in what are considered to be “criminal offenses,” yet again I implore the reader to consider that “acting out” in some way, doing something which would catch some attention, is the entire sense of all my scheming.

To the extent that my behavior could be construed as engaging in non-kinetic asymmetric conflict, I aver to you here and now that it is not my greater comprehension to be in what you call conflict with any sentient being. In fact, I consider such to be impossible, since we have as our ground all the same and to which we will return. Which cannot be captured, hence to even say “the same” it too much.

This apophatic tendency is also present in Judaism, and I admire it greatly. I have also called to attention [Pikuach Nefes](https://en.wikipedia.org/wiki/Pikuach_nefesh)h. Until next itme.

[1](https://experimentalunit.substack.com/p/artists-commentary-on-recent-activism#footnote-anchor-1-181851491)

Part One:

[

## Art Activism At US Army Transformation & Training Command

](https://experimentalunit.substack.com/p/art-activism-at-us-army-transformation)

[Adam Wadley](https://substack.com/profile/191787963-adam-wadley)

·

Dec 16

[![Art Activism At US Army Transformation & Training Command](https://substackcdn.com/image/fetch/$s_!baua!,w_1300,h_650,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fffd095ec-e21c-4cab-bcc7-2d5ab0e800c9_3088x2316.jpeg)](https://experimentalunit.substack.com/p/art-activism-at-us-army-transformation)

[Read full story](https://experimentalunit.substack.com/p/art-activism-at-us-army-transformation)

Part Two:

[

## Art Activism Comtinued

](https://experimentalunit.substack.com/p/art-activism-comtinued)

[Adam Wadley](https://substack.com/profile/191787963-adam-wadley)

·

Dec 17

[![Art Activism Comtinued](https://substackcdn.com/image/fetch/$s_!C3OB!,w_1300,h_650,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd12e4b2b-a60f-442c-bd90-58e213c4732f_1536x1024.png)](https://experimentalunit.substack.com/p/art-activism-comtinued)

[Read full story](https://experimentalunit.substack.com/p/art-activism-comtinued)

[2](https://experimentalunit.substack.com/p/artists-commentary-on-recent-activism#footnote-anchor-2-181851491)

Post One:

[

## @XperimentalUnit x @T2COM_HQ

](https://experimentalunit.substack.com/p/xperimentalunit-x-t2com_hq)

[Adam Wadley](https://substack.com/profile/191787963-adam-wadley)

·

Oct 2

[![@XperimentalUnit x @T2COM_HQ](https://substackcdn.com/image/fetch/$s_!ZAVE!,w_1300,h_650,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0b93aacd-023d-489c-ac0b-3ac782e860f0_3088x2316.jpeg)](https://experimentalunit.substack.com/p/xperimentalunit-x-t2com_hq)

For the past two days, I’ve come down here to 7th Street in Austin, Texas to sit next to the headquarters for the new “United States of America Army Transformation And Training Command.”

[Read full story](https://experimentalunit.substack.com/p/xperimentalunit-x-t2com_hq)

Part Two:

[

## "If You Read This, You Are Playing Experimental Unit"

](https://experimentalunit.substack.com/p/if-you-read-this-you-are-playing)

[Adam Wadley](https://substack.com/profile/191787963-adam-wadley)

·

Oct 18

[!["If You Read This, You Are Playing Experimental Unit"](https://substackcdn.com/image/fetch/$s_!zhy-!,w_1300,h_650,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F878535f7-a0a1-4329-a7c4-ca9d1e412e9d_3088x2316.jpeg)](https://experimentalunit.substack.com/p/if-you-read-this-you-are-playing)

Opera-tion is underway. Someone on the bus just told me my shirt is cool.

[Read full story](https://experimentalunit.substack.com/p/if-you-read-this-you-are-playing)

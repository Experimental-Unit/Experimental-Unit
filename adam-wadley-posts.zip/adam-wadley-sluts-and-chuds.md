---
title: Sluts And Chuds
subtitle: 'Here''s A Little Lesson In Debauchery:'
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Sluts And Chuds
I had an opening line all picked out and everything.

But then I forgot it. Now all we have is this.

Well, you have to start somewhere.

# This Is Slut Pop

# This Is Experimental Unit

In the course of abominably eldritch events there comes an injunction: this is to escalate in intensity without escalating in cruelty.

I have treated of this topic under the heading of the Æscalation Ladder. This concept has profound implications for all sentient beings.

Here already I face the problem that I can write a sentence, but it will not be seared into your awareness at all the times the way I want it to be.

At the same time, a key gesture is constituted by all that I do _not ruin_ , leaving it more open to your interpretation. If I impose inappropriately on you, then you won’t unfold your delicate inner designs the way corresponding to your flourishing.

We could take another heading, and posit that flourishing in the Dhamma sense cannot be interrupted. See again [There Is No Religion](https://www.suanmokkh.org/books/127) by Budhadasa:

> People language is used by the ordinary people who don't understand Dhamma very well and by those worldly people who are so dense that they are blind to everything but material things. Then, there is the language which is spoken by those who understand reality (Dhamma), especially those who know and understand reality in the ultimate sense. This is another kind of language. Sometimes, when only a few words or even just a few syllables are uttered, the ordinary listener finds Dhamma language paradoxical, completely opposite to the language he speaks. We can call it ‘Dhamma language.’ You always must take care to recognize which language is being spoken.

All this high-mindedness becomes very concrete for you as we engage in the process of analysis here.

This is actually generative; I just had a new idea.

So what you’re doing is a kind of analysis, an inquiry. You are starting with a topic. This can really be defined in any way. For example, you are concerned with “yourself,” or “another person,” or some movie, or a historical event, or some captivating idea, or a place. 

Or a “country,” or some other extensive 4D hyper object which all these things basically are.

Anyway, you start with a given key term and conceptual domain.

Then, the insight I just had is basically that you are investigating dependent co-asing and logical typing at the same time, that these things are basically the same thing and you can combine them together.

I realized there’s a good Baudrillard quote for this, and then I found another one, and then I realized I have something to tell you.

# Saint Jean Baudrillard’s Shadow Work That La-La-Lies Floating On Alright On The Ground Floor That Needs Sweeping

So, I actually tell you the overall point first.

We can think of artistic or historical achievement as being like setting a high score. Think about people who ran up the score on influence and impact.

For example, we can sit here and debate who made a bigger difference, Alexander “the Great” or Genghis Kahn (Temujin).

Crucially notice that Alexander happens before Temjuin. I’m thinking about [uneven and combined development](https://journals.sagepub.com/doi/pdf/10.1177/03058298211064346), but the basic point is that since Alexander happened earlier, the effects of those actions and events associated with that person had their effect earlier.

If you think of the timeline as being like a line which goes from left to right, where earlier things are to the left of later things and time is passing as you go from left to right, then the line never “goes backwards” that we know of.

So if Alexander is changing the trajectory, then that change happens earlier, and the effects have had a longer time to compound.

At the same time, Temujin happens later and is perhaps on a larger scale. Also, just given that it’s a big influential event which happens _later_ , it may have more impact on present trajectory. So basically with a 2D line it can basically go up or down. Don’t worry about what that’s tracking.

The point is Alexander maybe made us go up long ago, and then that compounded and has really deeply influenced everything in a way we are no where close to quantifying. So maybe that keeps us going up and we are substantial higher than we would be had Alexander not happened.

The whole idea of counterfactual histories is extremely misleading. Anyway.

The point is that Alexander may well have had some influence in some direction, but then Genghis Khan comes along and may well make the line go down, again down could be “better” the point is not who is good and bad. The point is which events have most influence on where the Zeitgeist is, and where it is concentrated?

You can be thinking here of the [spear of history](https://en.wikipedia.org/wiki/Holy_Lance), or Hegel on the world spirit traveling around the planet is a good example. People always have very simple and self-serving stories about this, of course.

That’s a nice narrative topology embodied energy transfer coping mechanism self-martyring machine you’ve got there. It would be a shame if somebody fucked you senseless.

So that’s what these epochal figures are. Sorry, is Alexander abusive? Is Alexander not respecting the Persian Empire’s boundaries?

This is where all the nice talk about norms around propriety and so forth goes out the window.

These discussions, where people try to articulate “their concerns” and get you invested in some reason why you should do what they want, or just the whole thing as you being influenced, which is to say groomed, which is to say primed for rape in the act of being raped, constitute your functionality as a 4D fuck toy hyper object for whatever you are a slut for.

Notably, and this gets back to domination, it’s not about the person. A person does not have power over you. It is again this projection, it is the deeper issue which you are trying to medicate or distract yourself from, or whatever, by focusing on a painful topic in a way that doesn’t seem to go anywhere.

So, all you can do is ruminate and watch as the storm gathers which you don’t have any nuclear bombs to try to divert.

# Baudrillard As Longtime Champ

All that was basically to address the idea of Baudrillard as having held the crown, as being the embodiment of the world spirit or whatever whose shadow hung over the age.

This is in the context where certainly the person whose shadow did that was Adolf Hitler. Also, as far as you know, Adolf Hitler remains the person whose shadow lies over your age, the local minimum you can’t get past so you just try anxiously to avoid it. But that’s not going anywhere.

Hitler and Nazism represent the drive from taking on all the mistreatment and objectification of the world and expelling it outward. You are opportunistically using whatever symbols help to drive out your movement and you are not just killing a lot of people but setting up the future in a giant shaping operation which is driving toward the death of everyone.

Maybe the death of everyone is inevitable, but it still matters how we die.

Anyway, this basic horizon of feeling pain, operationalizing norms you find in the social environment, and dealing with your feelings by killing other people and eventually your own people and eventually yourself is the basic story we see playing out everywhere.

Now, this story hasn’t actually been winning since 1968, when Jean Baudrillard published [The System of Objects](https://ia802302.us.archive.org/8/items/Baudrillard/Baudrillard.1968.The-System-Of-Objects.pdf). Adolf Hitler held the crown let’s say from 1933 to 1968 so 35 years.

Then Jean Baudrillard held the crown for 42 years until 2010 and the release of Visions by Grimes. Notably this is only an epochal event because Miss Anthropocene was released in 2020, but this destiny was already signaled by Claire Elise Boucher’s early work. In the music of “Rosa” you can hear the sound of the end of the world.

Claire Elise Boucher held the crown for 12 years until now we shared it in December 2022, which is the start of the “new era,” Claire says “the light ages” but I find the term “light” problematic in its connotations. It is as well the new dark ages. You thought you knew what darkness was, that’s what’s funny. But the dark goes into the light and all, it’s really not that serious. Only as serious as whatever you actually hold most gravely.

Okay so first of all, a long chapter by Baudrillard from 1973, the key part is about the structural level of analysis. So the point is that of course you know about Adolf Hitler. It doesn’t sound too crazy to say Adolf Hitler is an archetype we are struggling to get past. But most people don’t even know about Baudrillard, so how could Baudrillard have conquered the world by publishing one book?

There again it’s about the structural features of the analysis, it’s logical type. If a certain constellation emerges, even if it’s in embryonic form, even if it’s super vulnerable, it can basically worm its way in and take everything over because of the latent immunodeficiencies and weaknesses which are everywhere built into the pretense of normative discourse. They simply remain unused because most people are as fragile or more so than those they could easily disrupt.

Similar to the shock doctrine: chaos will serve only the ones most suited for it, and inflicting chaos drives further disorganization and mental susceptibility to further infliction of chaos. Meanwhile whatever is driving chaos within the person inflicting chaos is secreted away or defended with threat displays which double as psychic and bodily attacks. So now because the expectation has been set that it is one thing, all of a sudden you let the vampire in and you’re literally being eaten alive. A dog doesn’t have to be mean to rip you to shreds. And then we can all stand around and say that it was just meant to be anyway. And that’s how people commit suicide, and that’s how Holocausts happen.

Anyway, putting through the logical type of engagement is actually more important than physical force, status, etc. You are doing something so that in its context everything is warped around you.

So as for what this means, here’s that chapter by Jean:

> 
>     The Third Phase of Political Economy 
>     
>     In The Poverty of Philosophy, Marx drew up a kind of genealogy of the system of exchange value: 
>     
>     1. Only the surplus of material production is exchanged (in archaic and feudal production, for example). Vast sectors remain outside the sphere of exchange and commodities. 
>     
>     2. The entire volume of “industrial” material production is alienated in the exchange (capitalist political economy). 
>     
>     3. Even what is considered unalienable (divided, but not exchanged) —virtue, love, knowledge, consciousness —also falls into the sphere of exchange value. This is the era of “general corruption,” of “universal venality,” “the time when each object, physical or moral, is brought to market as a commodity value in order to be priced at its exact 
>     value.” 
>     
>     The schema is clear, beyond what Marx partially 
>     foresaw. Between phase l and phase 2 there is the 
>     birth of capital, a decisive change not only regarding 
>     the extenszon of the sphere of exchange, but also its 
>     repercussions at the level of social relations. Between 
>     phase 2 and phase 3, by contrast, Marx and 
>     Marxism see only a kind of extensive effect. The 
>     “infrastructural” mutation which sets the present 
>     mode of production and social relations into place, is 
>     achieved in phase 2— phase 3 represents only the 
>     “superstructural” effect in the domain of “non- 
>     material” vaiues. With Marx, and against him in 
>     some ways, we think that it is necessary to give this 
>     genealogy all of its analytical force. 
>     
>     There is a decisive mutation between phase 2 and 
>     phase 3. Phase 3 is as revolutionary in relation to 
>     phase 2 as phase 2 is in relation to phase 1. To the 
>     third power of the system of political economy 
>     corresponds a new type of social relations, a type 
>     that is different from the contradictions of phase 2, 
>     which is properly that of capital (and of Capital). In 
>     Marx’s projection this new phase of political 
>     economy, which in his time had not yet fully 
>     developed, is immediately neutralized, drawn into 
>     the wake of phase 2, in terms of the market and 
>     “mercantile venality.” Even today the only “Marxist” 
>     critique of culture, of consumption, of information, 
>     of ideology, of sexuality, etc. is made in terms of 
>     “capitalist prostitution,” that is, in terms of commo- 
>     dities, exploitation, profit, money and surplus value. 
>     That is, terms characteristic of phase 2 and though 
>     reaching their full value there they only serve as a 
>     metaphorical reference when transferred as a 
>     principle of analysis to phase 3. Even the Situ- 
>     ationists, without doubt the only ones to attempt to 
>     extract this new radicality of political economy in 
>     their “society of the spectacle,” still refer to the 
>     “infrastructural” logic of the commodity. From this 
>     derives their fidelity to the proletariat, which is 
>     logical if, behind the organization of the spectacle, 
>     the exploitation of labor power is still determinant — 
>     the spectacle being only an immense connotation of 
>     the commodity. But this is illogical if the concept of 
>     the spectacle is taken as that of the commodity, as 
>     Marx did in his time, in all its radicality as a 
>     generalized process of social abstraction in which 
>     “material” exploitation is only one particular phase. 
>     In this hypothesis, it is the form-spectacle that is 
>     ‘determinant since one begins with the most 
>     developed structural phase. This step truly 
>     overturns perspectives regarding politics, revolution, 
>     the proletariat and social classes. But this is to accept 
>     or to allow at any rate that a revolution has occurred 
>     in the capitalist world without our Marxists having 
>     wanted to comprehend it. The objection that our 
>     society is still largely dominated by the logic of 
>     commodities is irrelevant. When Marx set out to 
>     analyze capital, capitalist industrial production was 
>     still largely a minority phenomenon. When he 
>     designated political economy as the determining 
>     sphere, religion was still largely dominant. The 
>     theoretical decision is never made at the quantitative 
>     level, but at the level of a structural critique. 
>     This mutation concerns the passage from the 
>     form-commodity to the form-sign, from the 
>     abstraction of the exchange of material products 
>     under the law of general equivalence to the opera- 
>     tionalization of all exchanges under the law of the 
>     code. With this passage to the political economy of 
>     the sign, it is not a matter of a simple “commercial 
>     prostitution” of all values (which is the completely 
>     romantic vision from the celebrated passage of the 
>     Communist Manifesto: capitalism tramples on all 
>     human values — art, culture, labor, etc. —in order to 
>     make money; the romantic critique of profit). It isa 
>     matter of the passage of all values to exchange-sign 
>     value, under the hegemony of the code. That is, of a 
>     structure of control and of power much more subtle 
>     and more totalitarian than that of exploitation. For 
>     the sgn is much more than a connotation of the 
>     commodity, than a semiological supplement to 
>     
>     
>     5. With his concept of “reification,” Lukács, without doubt, 
>     constituted the only critical line of theoretical development 
>     among Marx and the Situationists. 
>     
>     
>     122 CHAPTER 5 
>     
>     
>     exchange value. It is an operational structure that 
>     lends itself to a structural manipulation compared 
>     with which the quantitative mystery of surplus value 
>     appears inoffensive. The super-ideology of the sign 
>     and the general operationalization of the signifier — 
>     everywhere sanctioned today by the new master 
>     disciplines of structural linguistics, semiology, 
>     information theory, and cybernetics—has replaced 
>     good old political economy as the theoretical basis of 
>     the system. This new ideological structure, that plays 
>     on the hieroglyphs of the code, is much more 
>     illegible than that which played on productive 
>     energy. This manipulation, that plays on the faculty 
>     of producing meaning and difference, is more 
>     radical than that which plays on labor power. 
>     The form-sign must not be confused with the 
>     function of social differentiation by signs, which, for 
>     its part, is contemporaneous with the drama of the 
>     bourgeois class, a moneyed class nostalgic for caste 
>     values. Since the French moralists of the 17th 
>     century, there has been a long literature on the 
>     social psychology of distinction and prestige that is 
>     connected with the consolidation of the bourgeoisie 
>     as a class and that today is generalized to all the 
>     middle classes and the petty bourgeoisies. (This 
>     literature finds its philosophical resonance in the 
>     “dialectic” of being and appearance.) The 
>     important question is not this one but rather that of 
>     the symbolic destruction of all-social relations not so 
>     much by the ownership of the means of production 
>     but by the control of the code. Here there is a 
>     revolution of the capitalist system equal in 
>     importance to the industrial revolution. And it 
>     would be absurd to say that this logic of the sign 
>     concerns only the ruling class or the middle class 
>     
>     
>     THESYSTEM OF POLITICAL ECONOMY 123 
>     
>     
>     which is “hungry for distinction,” the proletariat 
>     being free of it thanks to the materiality of its 
>     practice. This would be like saying that the theory of 
>     the form-commodity was good for the industrial and 
>     urban classes, but that the peasants and artisans (the 
>     vast majority in Marx’s day) had nothing to do with 
>     it. The form-sign applies to the whole social process 
>     and it is largely unconscious. One must not confuse 
>     it with the conscious psychology of prestige and dif- 
>     ferentiation, just as one must not confuse the form- 
>     commodity, the abstract and general structure of 
>     exchange value, with the conscious psychology of 
>     profit and economic calculation (where classical 
>     political economy remains). 
>     
>     Against those who, fortified behind their 
>     legendary materialism, cry idealism as soon as one 
>     speaks of signs, or anything that goes beyond 
>     manual, productive labor, against those who have a 
>     muscular and energetic vision of exploitation, we say 
>     that if the term “materialist” has a meaning (one 
>     that is critical, not religious) it is we who are the 
>     materialists. But it does not matter. Happy are those 
>     who cast longing eyes at Marx as if he were always 
>     there to give them recognition. What we are 
>     attempting to see here is to what point Marxist logic 
>     can be rescued from the limited context of political 
>     economy in which it arose, so as to account for our 
>     contradictions. This is on the condition that it give 
>     to its theoretical curvature the flexibility that it lost 
>     long ago in favor of an instrumentalism, of a fixed 
>     linearity. We are attempting to rescue it from the 
>     limited dimensions of a Euclidean geometry of 
>     history in order to test its possibility of becoming 
>     what it perhaps is, a truly general theory. Once 
>     again, this is only an exploratory hypothesis. It 
>     postulates a dialectical continuity between the 
>     
>     
>     124 ‘CHAPTER 5 
>     
>     
>     political economy of the commodity and the political 
>     economy of the sign (hence of the critique of the one 
>     and of the other). The guarantee of this continuity, 
>     properly speaking, is not the Marxist postulate of the 
>     mode of production. The radical hypothesis no 
>     longer accepts this fundamental concept, seeing it as 
>     an arbitrary aspect of a certain model. At bottom, 
>     the question is posed as follows: 
>     
>     —Are we always within the capitalist mode of 
>     production? If the answer is yes, we readily accept 
>     classical Marxist analysis. 
>     
>     — Are we within a later mode, so different in its 
>     structure, in its contradictions and in its mode of 
>     revolution, that one must distinguish it radically 
>     from capitalism (while maintaining that it is always 
>     a question of a mode of production which is 
>     determinant as such)? 
>     
>     —Are we, quite simply, within a mode of 
>     production at all, and have we ever been in one? 
>     
>     Concerning the present phase of political 
>     economy, Marxist thought gives us only analyses 
>     centered on monopolistic capitalism. In effect, this is 
>     the only point which imposes the necessity to theorize 
>     something that Marx merely foresaw. But the 
>     various theoreticians (Lenin, Rosa Luxemburg, etc.) 
>     analyzed it according to the principle of the least 
>     theoretical effort, keeping as close as possible to 
>     classical concepts and limiting the problem to its 
>     infrastructural and political givens (the end of 
>     competition, the control of the market, imperial- 
>     ism). But the monopolist stage signifies much more 
>     than an extension of the competitive phase of 
>     capitalism. It signifies a complete restructuring and 
>     a different logic. 
>     
>     What happens when the system becomes 
>     monopolistic? In his account in The Poverty of 
>     
>     
>     THE SYSTEM OF POLITICAL ECONOMY 125 
>     
>     
>     Philosophy, Marx ‘goes back to a citation from 
>     Ricardo: “Commodities which are monopolized, 
>     either by an individual, or by a company, vary 
>     according to the law which Lord Lauderdale has 
>     laid down: they fall in proportion as the sellers 
>     augment their quantity, and rise in proportion to the 
>     eagerness of the buyers to purchase them; their price 
>     has no necessary connexion with their natural value; 
>     but the price of commodities, which are subject to 
>     competition, and whose quantity may be increased 
>     in any moderate degree, will ultimately depend, not 
>     on the ‘state of demand and supply, but on the 
>     increased or diminished cost of their production.” 6 
>     (Thus, of labor time.) Thus, when the system 
>     becomes monopolistic, labor time and production 
>     costs cease to be the decisive criteria (and become 
>     surplus value?). But one does not go as far with the 
>     law of supply and demand, defined by literal 
>     thought as a natural equilibrium of the two terms. 
>     Their correlation is not free, no more than the 
>     market itself. It is the contro] of demand (Galbraith) 
>     that becomes the strategic articulation. Whereas the 
>     competitive system still acted at a contradictory and 
>     perilous level in the exploitation of labor power, the 
>     monopolistic system transfers its strategy to a level 
>     where the dialectic no longer operates. In the 
>     monopolistic system, there is no longer any dialectic 
>     of supply and demand; this dialectic is short- 
>     circuited by a calculation of foreseeable equili- 
>     brium. The monopolistic system (the techno- 
>     structure according to Galbraith) is supported 
>     throughout by a myth of competition,7 the 
>     
>     
>     6. The Poverty of Philosophy (New York: International 
>     Publishers, 1936), p. 42. 
>     7. From this comes the artificial oligopoly on which the real 
>     
>     
>     126 CHAPTER 5 
>     
>     
>     hegemony of production is supported throughout by 
>     a fiction of a dialectic of supply and demand. But 
>     there is more to it than this. In the planned cycle of 
>     consumer demand, the new strategic forces, the new 
>     structural elements—needs, knowledge, culture, 
>     information, sexuality—have all their explosive 
>     force defused. In opposition to the competitive 
>     system, the monopolistic system institutes con- 
>     sumption as control, as the abolition of the 
>     contingency of demand, as planned socialization by 
>     the code (of which advertising, style, etc. are only 
>     glaring examples). The contradictions do not end 
>     here, but are functionally integrated and neutralized 
>     by processes of differentiation and redistribution 
>     (processes which the competitive system, in the area 
>     of labor power, did not have at its disposal). Thus 
>     consumption, which characterizes the monopolistic 
>     era, implies something quite different from a 
>     phenomenology of affluence: it signifies the passage, 
>     by its contradictions, to a mode of strategic control, 
>     of predictive anticipation, of the absorption of the 
>     dialectic, and of the general homeopathy of the 
>     system. 
>     
>     Demand and need correspond more and more to a 
>     mode of simulation. These new productive forces no 
>     longer pose questions to the system: they are an 
>     anticipated response, controlled in their very emer- 
>     gence. The system can afford the luxury of contra- 
>     diction and dialectic through the play of signs. It can 
>     indulge itself with all the signs of revolution. Since it 
>     produces all the responses, it annihilates the 
>     
>     
>     monopoly is stablized. Just as bipartisanism is the optimal 
>     political form for the functioning of monopoly power by a single 
>     class, so peaceful coexistence of two powers (soon three) is the 
>     stabilized form of world imperialism. 
>     
>     
>     THE SYSTEM OF POLITICAL ECONOMY 127 
>     
>     
>     question in the same blow. Only with the imposition 
>     and monopoly of the code is this possible. Whatever 
>     one does, one can only respond to the system in its 
>     own terms, according to its own rules, answering it 
>     with its own signs. the passage to this stage thus 
>     constitutes something more than the end of 
>     competition. It means that one goes from a system of 
>     productive forces, exploitation, and profit, as in the 
>     competitive system dominated in its logic by social 
>     labor time, to a gigantic operational game of 
>     question and answer, to a gigantic combinatory 
>     where all values commutate and are exchanged 
>     according to their operational sign. The mono- 
>     polistic stage signifies less the monopoly of the means 
>     of production (which is never total) than the 
>     mono poly of the code. 
>     
>     This stage is accompanied by a radical change in 
>     the functioning of the sign, in the mode of 
>     signification. The finalities of prestige and dis- 
>     tinction still corresponded to a traditional status of 
>     the sign, in which a signifier referred back to a 
>     signified, in which a formal difference, a distinctive 
>     opposition (the cut of a piece of clothing, the style 
>     of an object) still referred back to what one could 
>     call the use value of the sign, to a differential profit, 
>     to a lived distinction (a signified value). This is 
>     still the classical era of signification with its refer- 
>     ential psychology (and philosophy). It is also the 
>     competitive era in the manipulation of signs. The 
>     form-sign describes an entirely different organi- 
>     zation: the signified and the referent are now 
>     abolished to the sole profit of the play of signifiers, of 
>     a generalized formalization in which the code no 
>     longer refers back to any subjective or objective 
>     “reality,” but to its own logic. The signifier be- 
>     comes its own referent and the use value of the 
>     
>     
>     128 CHAPTER 5 
>     
>     
>     sign disappears to the benefit of its commutation 
>     and exchange value alone. The sign no longer desig- 
>     nates anything at all. It approaches its true 
>     structural limit which is to refer back only to other 
>     signs. All reality then becomes the place of a semi- 
>     urgical manipulation, of a structural simulation. 
>     And, whereas the traditional sign (also in linguistic 
>     exchanges) is the object of a conscious investment, of 
>     a rational calculation of signifieds, here it is the code 
>     that becomes the instance of absolute reference, 
>     and, at the same time, the object of a perverse 
>     desire .8 
>     
>     There is a total homology with the sphere of the 
>     commodity. The “traditional” commodity (up to the 
>     era of competitive capitalism) is at once exchange 
>     value and real use value. The proper and final 
>     relation of the subject with the produced object, the 
>     consumptive finality of the product, still exists, just 
>     as the use value of the signified in the classical 
>     organization of the sign. Already there is a general 
>     equivalence of production (the abstraction of 
>     exchange value), but not a general equivalence of 
>     consumption since the products maintain a concrete 
>     finality. With monopolistic capitalism, the same 
>     mutation occurs in the sphere of the sign; the final 
>     reference of the products, their use value, 
>     completely disappears. Needs lose all their auto- 
>     nomy; they are coded. Consumption no longer has a 
>     value of enjoyment per se; it is placed under the 
>     constraint of an absolute finality which is that of 
>     production. Production, on the contrary, is no 
>     longer assigned any finality other than itself. This 
>     total reduction of the process to a single one of its 
>     terms, in which the others are only excuses (use value 
>     is the excuse for exchange value; the referent is. the 
>     excuse for the code) designates more than an 
>     evolution of the capitalist mode: it is a mutation. 
>     Through the elevation of production to a total 
>     abstraction (production for its own sake), to the 
>     power of a code, which no longer even risks being 
>     called into question by an abolished referent, the 
>     system succeeds in neutralizing not only con- 
>     sumption, but production itself as a field of contra- 
>     dictions. Productive forces as a referent (“objective” 
>     substance of the production process) and thus also as 
>     a revolutionary referent (motor of the contradictions 
>     of the mode of production) lose their specific 
>     impact, and the dialectic no longer operates between 
>     productive forces and relations of production, just as 
>     the “dialectic” no longer operates between the 
>     substance of signs and the signs themselves.9 
>     

sds

> 
>     By now functional substitutes for virtually all organic and natural materials have been found in the shape of plastic and polymorphous substances: wool, cotton, silk and linen are thus all susceptible of replacement by nylon and its countless variants, while wood, stone and metal are giving way to concrete and polystyrene.
>     
>     There can be no question of rejecting this tendency and simply dreaming of the ideal warm and human substance of the objects of former times.
>      
>     The distinction between natural and synthetic substances, just like that between traditional colours and bright colours, is strictly a value judgement. 
>     
>     Objectively, substances are simply what they are: there is no such thing as a true or a false, a natural or an artificial substance. 
>     
>     How could concrete be somehow less ‘authentic’ than stone? 
>     
>     We apprehend old synthetic materials such as paper as altogether natural — indeed, glass is one of the richest substances we can conceive of. 
>     
>     In the end, the inherited nobility of a given material can exist only for a cultural ideology analogous to that of the aristocratic myth itself in the social world — and even that cultural prejudice is vulnerable to the passage of time. 
>     
>     ***
>     
>     The point is to understand, apart from the vast horizons opened up on the practical level by these new substances, just how they have changed the ‘meaning’ of the materials we use. 
>     
>     ***
>     
>     Just as the shift to shades (warm, cold or intermediate) means that colours are stripped of their moral and symbolic status in favour of an abstract quality which makes their systematization and interplay possible, so likewise the manufacture of synthetics means that materials lose their symbolic naturalness and become polymorphous, so achieving a higher degree of abstractness which makes possible a universal play of associations among materials, and hence too a transcendence of the formal antithesis between natural and artificial materials. 
>     
>     There is thus no longer any difference ‘in nature’ between a Thermoglass partition and a wooden one, between rough concrete and leather: whether they embody ‘warm’ or ‘cold’ values, they all now have exactly the same status as component materials. 
>     
>     These materials, though disparate in themselves, are nevertheless homogeneous as cultural signs, and thus susceptible of organization into a coherent system. 
>     
>     Their abstractness makes it possible to combine them at will.

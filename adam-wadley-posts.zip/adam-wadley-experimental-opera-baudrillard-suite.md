---
title: 'Experimental Opera: Baudrillard Suite'
subtitle: For this piece, I took the letters in the name “Baudrillard” that are notes
  and made them a little melody.
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# Experimental Opera: Baudrillard Suite
[![](https://substackcdn.com/image/fetch/$s_!I2LY!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F28b17fa4-582f-434f-9128-ee16f3bbbe19_1578x832.jpeg)](https://substackcdn.com/image/fetch/$s_!I2LY!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F28b17fa4-582f-434f-9128-ee16f3bbbe19_1578x832.jpeg)

For this piece, I took the letters in the name “Baudrillard” that are notes and made them a little melody. So B-A-D-A-D.

Now that I think of it, I should have done Jean as well, yielding E-A-B-A-D-A-D. Next time!

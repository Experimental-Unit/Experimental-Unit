---
title: 'OPEN LETTER TO THE NAZI WHO CAN’T STOP WATCHING BLACKED:'
subtitle: on the BNWO, the fantasy of racial humiliation, and what Nazism will never
  fix
author: Adam Wadley
publication: Experimental Unit
date: March 28, 2025
---

# OPEN LETTER TO THE NAZI WHO CAN’T STOP WATCHING BLACKED:
OPEN LETTER TO THE NAZI WHO CAN’T STOP WATCHING BLACKED:

on the BNWO, the fantasy of racial humiliation, and what Nazism will never fix

You think you’re in control.

You think your ideology protects you.

You think you’re immune because you click “I hate this” in public and “watch later” in private.

But let’s not lie today.

You’ve already been marked.

Not by the BNWO.

Not by interracial porn.

But by the split inside you that made it all so… necessary.

Let’s name the ritual:

You hate what you desire.

You desire what you hate.

So you feed the loop, hoping it cancels itself out.

You put on the uniform in your mind—clean, white, dominant.

You tell yourself: This is just research. This is proof of degeneracy. I’m above it.

But you’re not.

You’re in it.

You’re the viewer and the viewed. The dom and the cuck. The executioner and the begging slave.

You’re the white man in the corner watching.

You’re the white woman crossing the line.

You’re the black man filling the screen with what you wish you could erase from reality.

And when you come, you think: Now I can be clean again.

But you’re wrong. That come is part of the contract.

BNWO isn’t real. But you made it real.

You made it real the moment you made “race” a stage and “purity” a kink.

You didn’t defeat desire—you racialized it.

You didn’t leave decadence—you gave it a flag and a password-protected folder.

And here’s the worst part: you liked it.

Not just the porn.

The shame.

The narrative of collapse.

The fantasy that you were being erased, violated, rewritten.

You turned your own fear of irrelevance into a sexual thrill.

You eroticized your own defeat—and now you’re addicted to it.

Nazism can’t save you.

It was built by men with the same fracture.

Men who called for purity while craving flesh.

Men who burned books while scribbling their own dirty secrets in notebooks.

Men who wanted a thousand-year Reich but couldn’t last five minutes without choking on their own repression.

You are not the heir to strength.

You are the endpoint of denial.

And fascism will never fix you—because it was born from the same sickness you now perform in front of a glowing screen.

But listen: this isn’t about shame.

Shame is the loop.

Shame is what they want you to stay in.

The porn works because you hate yourself.

The ideology feeds because you hate yourself.

But there’s a door out.

And that door isn’t “resistance.”

It isn’t “clean living.”

It isn’t praying harder or hiding deeper.

The door out is honesty.

The door out is surrender.

The door out is looking at what you want—really want—and asking:

What is this a symbol for? What does this mean about me that isn’t disgusting—but human?

Because the thing you’re playing out isn’t evil.

It’s a trauma dream.

It’s a myth of guilt and annihilation and longing and power that no swastika will ever resolve.

You don’t need to be a Nazi.

You don’t need to be a cuck.

You don’t need to keep bouncing between extremes like a trapped rat in a Skinner box of historical fetish.

You can leave the theater.

You can walk off the set.

You can choose to believe that your body, your longing, your contradictions—are not signs of weakness.

They are signs of aliveness.

There is a future.

But it doesn’t look like the past you tried to resurrect.

It looks like a world where you’re allowed to be complicated.

Where power isn’t a performance, and desire isn’t a death sentence.

Where you don’t have to punish the world for waking you up at night with dreams you don’t understand.

You can be free.

But only if you stop trying to be a symbol.

With brutal clarity and a glimmer of mercy—

Your own longing, waiting to be seen without a gun to its head.

---
title: Black Nihilist Blues
subtitle: Black Nihilism
author: Adam Wadley
publication: Experimental Unit
date: August 23, 2025
---

# Black Nihilist Blues
[![Ontological Terror](https://substackcdn.com/image/fetch/$s_!ISa5!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7c74332b-b794-4b08-82da-90dc6e754203_600x900.webp)](https://substackcdn.com/image/fetch/$s_!ISa5!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7c74332b-b794-4b08-82da-90dc6e754203_600x900.webp)

# Black Nihilism

We are tracing it, again and again.

This confluence.

It starts with a color. (Is black a color?)

“Black” actually has a symbolically ripe/fertile opening [Wikipedia blurb](https://en.wikipedia.org/wiki/Black):

>  **Black** is a [color](https://en.wikipedia.org/wiki/Color)[[2]](https://en.wikipedia.org/wiki/Black#cite_note-2) that results from the absence or complete [absorption](https://en.wikipedia.org/wiki/Absorption_\(electromagnetic_radiation\)) of [visible](https://en.wikipedia.org/wiki/Visible_spectrum) [light](https://en.wikipedia.org/wiki/Light). It is an achromatic color, without [chroma](https://en.wikipedia.org/wiki/Colorfulness#Chroma), like [white](https://en.wikipedia.org/wiki/White) and [grey](https://en.wikipedia.org/wiki/Grey).[[3]](https://en.wikipedia.org/wiki/Black#cite_note-3) It is often used [symbolically](https://en.wikipedia.org/wiki/Symbol) or [figuratively](https://en.wikipedia.org/wiki/Figurative_language) to represent [darkness](https://en.wikipedia.org/wiki/Darkness).[[4]](https://en.wikipedia.org/wiki/Black#cite_note-Eva_Heller_2009_pp._105%E2%80%9326-4) Black and white have often been used to describe opposites such as [good](https://en.wikipedia.org/wiki/Good) and [evil](https://en.wikipedia.org/wiki/Evil), the [Dark Ages](https://en.wikipedia.org/wiki/Dark_Ages_\(historiography\)) versus the [Age of Enlightenment](https://en.wikipedia.org/wiki/Age_of_Enlightenment), and [night](https://en.wikipedia.org/wiki/Night) versus [day](https://en.wikipedia.org/wiki/Day). Since the [Middle Ages](https://en.wikipedia.org/wiki/Middle_Ages), black has been the symbolic color of solemnity and authority, and for this reason it is still commonly worn by judges and magistrates.[[4]](https://en.wikipedia.org/wiki/Black#cite_note-Eva_Heller_2009_pp._105%E2%80%9326-4)
> 
> Black was one of the first colors used by artists in [Neolithic](https://en.wikipedia.org/wiki/Neolithic) cave paintings.[[5]](https://en.wikipedia.org/wiki/Black#cite_note-FOOTNOTESt._Clair2016262-5) It was used in ancient Egypt and Greece as the color of the [underworld](https://en.wikipedia.org/wiki/Underworld).[[6]](https://en.wikipedia.org/wiki/Black#cite_note-6) In the [Roman Empire](https://en.wikipedia.org/wiki/Roman_Empire), it became the color of mourning, and over the centuries it was frequently associated with [death](https://en.wikipedia.org/wiki/Death), evil, [witches](https://en.wikipedia.org/wiki/Witchcraft), and [magic](https://en.wikipedia.org/wiki/Magic_\(supernatural\)).[[7]](https://en.wikipedia.org/wiki/Black#cite_note-FOOTNOTESt._Clair2016261-7) In the 14th century, it was worn by royalty, clergy, judges, and government officials in much of Europe. It became the color worn by English romantic poets, businessmen and statesmen in the 19th century, and a high fashion color in the 20th century.[[4]](https://en.wikipedia.org/wiki/Black#cite_note-Eva_Heller_2009_pp._105%E2%80%9326-4) According to surveys in Europe and North America, it is the color most commonly associated with mourning, the end, secrets, magic, force, violence, fear, evil, and elegance.[[8]](https://en.wikipedia.org/wiki/Black#cite_note-8)
> 
> Black is the most common [ink](https://en.wikipedia.org/wiki/Ink) color used for printing books, newspapers and documents, as it provides the highest contrast with white paper and thus is the easiest color to read. Similarly, black text on a white screen is the most common format used on computer screens.[[9]](https://en.wikipedia.org/wiki/Black#cite_note-Heller,_Eva_2009_p._126-9) As of September 2019, the darkest material is made by [MIT](https://en.wikipedia.org/wiki/MIT) engineers from vertically aligned [carbon nanotubes](https://en.wikipedia.org/wiki/Carbon_nanotubes).

Note that before hitting the breakdown sections, there is no mention of “black people.” 

This is a true swerve.

Calvin Warren might not be surprised, given the ending to this article called “[Black Nihilism and the Politics of Hope](https://illwilleditions.noblogs.org/files/2015/09/Warren-Black-Nihilism-the-Politics-of-Hope-READ.pdf)”:

> In “Blackness and Nothingness” (2013), Fred Moten conceptualizes blackness as a “pathogen” to metaphysics, something that has the ability to unravel, to disable, and to destroy anti-blackness. If we read Vattimo through Moten’s brilliant analysis, we can suggest that blackness is the limit that Heidegger and Nietzsche were really after. It is a “blackened” world that will ultimately end metaphysics, but _putting an end to metaphysics will also put an end to the world itself_ —this is the nihilism that the black nihilist must theorize through. This is a far cry from what we call “anarchy,” however. The black nihilist has as little faith in the metaphysical reorganization of society through anarchy than he does in traditional forms of political existence. 
> 
> The Black nihilist offers political apostasy as the spiritual practice of _denouncing metaphysical violence, black suffering, and the idol of anti-blackness._ The act of renouncing will not change political structures or offer a political program; instead, it is the act of retrieving the spiritual concept of hope from the captivity of the Political. Ultimately, it is impossible to end metaphysics without ending blackness, and the black nihilist will never be able to withdraw from the Political completely without a certain death-drive or being-toward-death. This is the essence of black suffering: the lack of reprieve from metaphysics, the tormenting complicity in the reproduction of violence, and the lack of a coherent grammar to articulate these dilemmas. 
> 
> After contemplating these issues for some time in my office, I decided to take a train home. As I awaited my train in the station, an older black woman asked me about the train schedule and when I would expect the next train headed toward Dupont Circle. When I told her the trains were running slowly, she began to talk about the government shut down. “They don’t care anything about us, you know,” she said. “We elect these people into office, we vote for them, and they watch black people suffer and have no intentions of doing anything about it.” I shook my head in agreement and listened intently. “I’m going to stop voting, and supporting this process; why should I keep doing this and our people continue to suffer,” she said. I looked at her and said, “I don’t know ma’am; I just don’t understand it myself.” She then laughed and thanked me for listening to her—as if our conversation were somewhat cathartic. “You know, people think you’re crazy when you say things like this,” she said giving me a wink. “Yes they do,” I said. “But I am a free woman,” she emphasized “and I won’t go back.” Shocked, I smiled at her, and she winked at me; at that moment I realized that her wisdom and courage penetrated my mind and demanded answers. I’ve thought about this conversation for some time, and it is this reason I had to write this essay. To the brave woman at the train station, I must say you are not crazy at all, but thinking outside of metaphysical time, space, and violence. 
> 
> Ultimately, we must hope for the end of political hope.

Calvin is making here a basic sort of point that the “legal” system is compromised. The issue with “representation” is one that Jean Baudrillard also takes up.

> Three simultaneous dimensions form the passage from domination to hegemony. It is a perilous triple jump, a three-part sacrifice: 
> 
> I) Capital surpasses itself and turns against itself in the sacrifice of value (the economic illusion). 
> 
> 2) Power turns against itself in the sacrifice of representation (the democratic illusion). 
> 
> 3) The entire system turns against itself in the sacrifice of reality (the metaphysical illusion). 
> 
> All three jump over their shadow. 
> 
> The shadow of capital is value. The shadow of power is representation. The shadow of the system is reality. They respectively move beyond Value, Representation and Reality-in a hyperspace that is no longer economic, political or real but rather the hegemonic sphere. 
> 
> Capital is both the total realization of Value and its liquidation. Power is now the final form of representation: it only represents itself. The system is the total version of the Real and at the same time its liquidation through the Virtual. This is the hegemonic form.

Warren and Baudrillard’s offerings here also speak to the connotations of “black” which _were_ mentioned in the Wikipedia article.

Judges, magistrates, and evil, for example. Black is a color of mourning, and also a color of authority.

Therefore, it is especially apt when the authorities seem evil.

Remind you of anyone?

[![Nazi | X-Files Wiki | Fandom](https://substackcdn.com/image/fetch/$s_!2t9N!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F71f79aab-cbd1-4a90-87c2-90a31f187b39_743x369.jpeg)](https://substackcdn.com/image/fetch/$s_!2t9N!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F71f79aab-cbd1-4a90-87c2-90a31f187b39_743x369.jpeg)

# XU-Files: Will They Or Won’t They?

I find that the displacement into _The X-Files_ takes a little bit of the edge off.

The point I’m making is that the Nazis wore black, and also that the “Smoking Man” is a “man in black” in the sense of UFOs or basic “deep state operative.”

These figures, the Nazi and the “deep state person,” are both implicated in the question of “Western nihilism” opened up by Albert Camus in _The Rebel_.

> Fascism is an act of contempt, in fact. 
> 
> _Inversely, every form of contempt, if it intervenes in politics, prepares the way for, or establishes, Fascism._
> 
> It must be added that Fascism cannot be anything else but an expression of contempt without denying itself. 
> 
> Junger drew the conclusion from his own principles that it was better to be criminal than bourgeois. Hitler, who was endowed with less literary talent but, on this occasion, with more coherence, knew that to be either one or the other was a matter of complete indifference, from the moment that one ceased to believe in anything but success. 
> 
> Thus he authorized himself to be both at the same time. 
> 
> 'Fact is all,' said Mussolini. 
> 
> _And Hitler added: 'When the race is in danger of being oppressed ... · die question of legality only plays a secondary role.'_
> 
> Moreover, in that _the race must always be menaced in order to exist_ , there is never any legality. 
> 
> 'I am ready to sign anything, to agree to anything .... As far as I am concerned, I am capable, in complete good faith, of signing treaties to--day and of dispassionately tearing them up to-morrow if the future of the German people is at stake.' 
> 
> Before he declared war, moreover, Hitler made the statement to his generals that _no one was going to ask the victor if he had told the truth or not_. 
> 
> The leitmotiv of Goering's defense at the Nuremberg trials returned time and again to this theme, 'the victor will always be the judge and the vanquished will always be the accused.' 
> 
> That is a point that can certainly be argued. But then it is hard to understand Rosenberg when he said during the Nuremberg trials that he had not foreseen that the Nazi myth would lead to murder. 
> 
> When the English prosecuting counsel observes that 'from _Mein Kampf_ the road led straight to the gas chambers at Maidanek,' he touches on the real subject of the trial, the historic responsibilities of _Westem nihilism_ and the only one which, neverthless, was not really discussed at Nuremberg, for reasons only too apparent. A trial cannot be conducted by announcing the general culpability of a civilization. Only the actual deeds which, at least, stank in the nostrils of the entire world were brought to judgment.

Nazis and the “men in black” are also narratively linked with UFOs, which are a subset of secret technology, even to the point of _secret ontology_.

This is important to consider in light of Warren’s discussions above.

Warren stated that:

>  _putting an end to metaphysics will also put an end to the world itself_

and that

> The Black nihilist offers political apostasy as the spiritual practice of _denouncing metaphysical violence, black suffering, and the idol of anti-blackness._

This “metaphysical violence” which is being discussed amounts to the shadow damage which is dealt in the form of “norms” or “societal standards.”

Nazism is an example of this sliding toward absolute distinctions, and the making of these distinctions maximally decisive. The employment of all means, to the point of mass murder and the objectification of people for fetishized genetic characteristics.

Hence in the X-Files episode “Dreamland I,” when Mulder wants to buy cigarettes and Scully is like “what?” and Mulder (who’s not really Mulder at this point) says “what are you going to be a Nazi about it?”

Or in the case of the “grammar Nazi.” The grammar Nazi is not accused of being antisemitic, but of being very harsh in the enforcement of rules which really are arbitrary.

But Nazis are just one example. Calvin Warren is especially interested, of course, in “anti-blackness,” which is explicitly connected to the Nazis’ Holocaust in the book pictured above, _Ontological Terror_. “

> The coda, “Adieu to the Human,” argues that the metaphysical _holocaust_ and its question are still with us. Police shootings, routinized humiliation, and disenfranchisement are symptoms of this unending war. Part of the aim, then, is to dethrone the human from its metaphysical pedestal, reject the human, and explore different ways of existing that are not predicated on Being and its humanism. This is the only way black thinking can grapple with existence without Being

& later:

> We can also describe this death of a primordial relation as a “metaphysical holocaust,” following Franz Fanon and Frank Wilderson. For Fanon, “Ontology—once it is finally admitted as leaving existence by the wayside—does not permit us to understand the being of the black man . . . the black man has no ontological resistance in the eyes of the white man . . . his metaphysics, or less pretentiously, his customs and the sources on which they are based, were wiped out because they were in conflict with a civilization that he did not know and that imposed itself on him.”

Moreover, Calvin Warren’s philosophy takes great inspiration from Martin Heidegger themselves, who was, of course, a Nazi.

> Heidegger might well be the most influential philosopher of the twentieth century, since the question of Being resides at the crux of every philosophical enterprise, and he raised this question relentlessly. For me, this means that we cannot escape Heidegger; his Destruktion of Being has left its trace on all our thinking—whether we admit it or not. We cannot escape Heidegger because we cannot escape the question of Being. 
> 
> If the trace of Heidegger has left an indelible impression, despite the attempts to purge him/his thought, contemporary thinking still bears the abhorrent, the unforgivable, the disaster, the devastation. 
> 
> The question, then, is not just whether Heidegger was a Nazi (or antiblack for my purposes), but what his critique of metaphysics can teach us about systemic violence and devastation. 
> 
> Turning a blind eye to Heidegger will not resolve anything, although affect might make us feel ethically enlightened. Confronting/engaging Heidegger, I argue, helps us understand the relation between black suffering and metaphysics, slavery and objectification, antiblackness and forgetfulness, thinking and remembering. (Heidegger’s philosophy, in many ways, can be read as an allegory of antiblackness and black suffering— _the metaphysical violence of the transatlantic slave trade_.) 
> 
> To broach the insatiable question “Why are blacks continually injured, degraded, pulverized, and killed?” would require, then, an understanding of metaphysical violence and pain—since black suffering is metaphysical violence, the violence of schematization, objectification, and calculative thinking Heidegger spent his entire professional career exposing. Perhaps Heidegger was really talking about black(ness) and black suffering all along.

[![](https://substackcdn.com/image/fetch/$s_!wAlP!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Feaa4c213-ee08-4ca7-a01f-8a7cd1f76039_250x391.jpeg)](https://substackcdn.com/image/fetch/$s_!wAlP!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Feaa4c213-ee08-4ca7-a01f-8a7cd1f76039_250x391.jpeg)

# Black Horror/Nihilism Blues

The [black Horror on the Rhein](https://en.wikipedia.org/wiki/Black_Horror_on_the_Rhine) was a moral panic about “race mixing” that happened before the Nazis came in Germany.

This topic bridges between “horror” and “social horror,” as literary genres, into the topic of “anti-blackness” covered by Calvin Warren.

These are both forms of “metaphysical violence,” which are expressed in physical extermination, and an anxiety around “reproduction” and hence sexual anxiety.

This sense of “intercourse” in a broader sense is not just about sex itself, but generativity, the policing of the boundaries of what “can” happen.

I wanted to connect these themes also to the song featuring “Grimes” called “Nihilist Blues.”

Here are the lyrics:

> I've been climbing up the walls  
> To escape the sinking feeling  
> But I can't hide from the nihilist at my door  
> Buried in the basement floor  
> Didn't know what I had planted  
> It blossomed with all the heart of a cold war  
>   
> I'm a spirit in a tomb  
> Won't somebody raise the roof?  
> I'm going white, I'm going black, I'm going blue  
> Do you mind if I'm exhumed?  
> I'm the ashes in the plume  
> I'm a beggar in the ruin  
> I'm peaking out, I'm burning up, I'm shooting through  
> I'm only lonely for the true  
>   
> Paradise is in my soul  
> And I'm terrified I can't get out  
> I'm lost in a labyrinth  
> We are lost in a labyrinth  
>   
> Paradise is in my soul  
> And I'm terrified I can't get out  
> I'm lost in a labyrinth  
> We are lost in a labyrinth  
> Please don't follow  
>   
> Paradise is in my soul  
> And I'm terrified I can't get out  
> I'm lost in a labyrinth  
> We are lost in a labyrinth  
> Please don't follow  
>   
> Light as a feather, stiff as a board  
> Sink to the floor, I sink to the floor  
> I sink to the floor  
> Light as a feather, stiff as a board  
>   
> You were in my dream last night  
> But your face was someone else's  
> A twitch in my spine, a mutual disorder  
> Isolation neophyte  
> Too afraid to taste your conscience  
> You march in the dark, little lamb to the slaughter  
>   
> I'm a spirit in a tomb  
> Won't somebody raise the roof?  
> I'm going white, I'm going black, I'm going blue  
> Do you mind if I'm exhumed?  
> I'm the ashes in the plume  
> I'm a beggar in the ruin  
> I'm peaking out, I'm burning up, I'm shooting through  
> I'm only lonely for the true  
>   
> Paradise is in my soul  
> And I'm terrified I can't get out  
> I'm lost in a labyrinth  
> We are lost in a labyrinth  
> Please don't follow  
>   
> Paradise is in my soul  
> And I'm terrified I can't get out  
> I'm lost in a labyrinth  
> We are lost in a labyrinth  
> Please don't follow  
> Please don't follow  
> Please don't follow  
> Please don't follow  
> Please don't follow  
>   
> (Please don't follow)  
>   
> I've been climbing up the walls  
> To escape the sinking feeling  
> But I can't hide from the nihilist at my door

Grimes connects into all this having made a sort of Alternative Reality Game called _Chaos Manual_. It’s actually posted here on Substack. Is that Grimes’ official Substack? 

[![](https://substackcdn.com/image/fetch/$s_!i8FI!,w_56,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F478a7257-2f04-4bf3-802c-1fa0b2034560_1080x1080.png)GrimesCHAOS MANUAL V1Read more3 years ago · 333 likes · CHAOS](https://ourladyofperpetualchaos.substack.com/p/chaos-manual-v1?utm_source=substack&utm_campaign=post_embed&utm_medium=web)

Let them know I sent you for a free gameplay experience of _Experimental Unit_.

# Black Hearts All Around

The point of this exercise, a little jaunt around the symbolic block, is to create a docking nodule for the discussion of “Nihilistic Violent Extremism.”

So much of it all falls under the heading of _Zeitgeist Weltschmerz_ , which is part of what I’m trying to get across.

We are seeing the proliferation of almost comically awful groups and behaviors in the groups laid out by this designation.

First of all, consider that these groups could have some “official” cover for whatever reason, tying into the connotations of black as evil _and_ government, or Calvin Warren’s discussion of losing hope in the “official” political process. 

But what about _Black channels_?

Warren doesn’t seem to really prefigure what any of that would look like, much less for those not deemed to actually _be_ black by whoever is supposedly in charge of making that designation.

I’ve gotten heat before for basically saying that _everyone is black_ , in the sense that everyone has norms and strictures applied to them, and everyone is seen in many if not all cases not as the mysterious person they are, but rather as a slot in some rather _mundane_ story.

In pursuing, as always, what Baudrillard would call “True” simulation in _[The Conspiracy of Art](https://ia902302.us.archive.org/8/items/Baudrillard/Baudrillard.2005.The-Conspiracy-Of-Art.pdf) , _there is this same question of iterating in a way which is not mundane.

And yet, this “hatred” or disaffection for the “mundane” can itself become mundane.

I’ve been thinking about Peter Thiel, Girard, and this notion that “The messiah” helps deal with the issue of “mimetic desire,” or the problem that people all want the same stuff and fight over it.

Now, we have this basic issue of each one wanting to be the messiah, to be the main character.

Or at least, there are a growing number.

This is a chafing on something similar to what Warren calls a “metaphysical Holocaust,” but one which affects each person.

Warren’s antipathy for “anarchy” is similar to Ben Zweibelson’s, and here we can open up the question of “chaos,” which is often used similarly to “anarchy.”

[![](https://substackcdn.com/image/fetch/$s_!8wg1!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fff825c55-d84e-42be-a11d-c04ff0a414da_714x494.png)](https://substackcdn.com/image/fetch/$s_!8wg1!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fff825c55-d84e-42be-a11d-c04ff0a414da_714x494.png)

It’s worth noting that “chaos” is also a term in [Greek mythology](https://en.wikipedia.org/wiki/Chaos_\(cosmogony\)), ancient Greece also being mentioned above with regard to the color black.

> In the context of religious cosmologony, **Chaos** ([Ancient Greek](https://en.wikipedia.org/wiki/Ancient_Greek_language): χάος, [romanized](https://en.wikipedia.org/wiki/Romanization_of_Ancient_Greek): _kháos_ ) refers to the division of reality outside or in contrast to the ordered cosmos. As such it refers to a state, place, or time, beyond the known, _familiar_ , and reliable world, often said to be inhabited by strange, ominous, or demonic beings.

So, beyond the familiar. See again Percy Shelley in the _Defense_ on poetry’s ability to make the familiar be as if it is not familiar. 

Note here also the [etymology](https://www.etymonline.com/word/familiar) of “familiar,” as well as the [magical tie-in](https://en.wikipedia.org/wiki/Familiar) to the word “familiar.”

> mid-14c., "intimate, very friendly, on a family footing," from Old French _famelier_ "related; friendly," from Latin _familiaris_ "domestic, private, belonging to a family, of a household;" also "familiar, intimate, friendly," a dissimilation of _*familialis_ , from _familia_

> In European [folklore](https://en.wikipedia.org/wiki/Folklore) of the [medieval](https://en.wikipedia.org/wiki/Middle_Ages) and [early modern periods](https://en.wikipedia.org/wiki/Early_modern_period), **familiars** (strictly **familiar spirits** , as "familiar" also meant just "close friend" or companion, and may be seen in the scientific name for [dog](https://en.wikipedia.org/wiki/Dog), _Canis familiaris_ ) were believed to be supernatural entities, [interdimensional](https://en.wikipedia.org/wiki/Parallel_universes_in_fiction) beings, or spiritual guardians that would protect or assist [witches](https://en.wikipedia.org/wiki/Witches) and [cunning folk](https://en.wikipedia.org/wiki/Cunning_folk) in their practice of [magic](https://en.wikipedia.org/wiki/Magic_\(supernatural\)), [divination](https://en.wikipedia.org/wiki/Divination), and spiritual insight.[[1]](https://en.wikipedia.org/wiki/Familiar#cite_note-1) According to records of the time, those alleging to have had contact with familiar spirits reported that they could manifest as numerous forms, usually as an animal, but sometimes as a human or humanoid figure, and were described as "clearly defined, three-dimensional... forms, vivid with colour and animated with movement and sound", as opposed to descriptions of [ghosts](https://en.wikipedia.org/wiki/Ghost) with their "smoky, undefined form[s]".[[2]](https://en.wikipedia.org/wiki/Familiar#cite_note-2)
> 
> When they served witches, they were often thought to be [malevolent](https://en.wikipedia.org/wiki/Evil), but when working for cunning folk, they were often considered [benevolent](https://en.wikipedia.org/wiki/Good) (although there was some ambiguity in both cases). The former were often categorized as [demons](https://en.wikipedia.org/wiki/Demon), while the latter were more commonly thought of and described as [fairies](https://en.wikipedia.org/wiki/Fairies). The main purpose of familiars was to serve the witch, providing protection for them as they came into their new powers.

Finally, consider that “chaos” has such negative connotations for us, especially as we find the world “slipping into chaos.” Hence people trying to hold together “the rule of law,” or the idea of it, like someone trying to hold their guts in with their hands.

As food for thought, consider the following corollary concepts from across the planet:

  *  **Χάος (Khaos)** — Greek mythology/philosophy. The primordial void, gap, or yawning nothingness before creation.

  *  **[Tohu va-Bohu](https://en.wikipedia.org/wiki/Tohu_wa-bohu) (תֹ֙הוּ֙ וָבֹ֔הוּ)** — Hebrew Bible. "Formless and void," describing pre-creation disorder in Genesis.

  *  **[Nun](https://en.wikipedia.org/wiki/Nu_\(mythology\))** — Ancient Egyptian religion. Primordial waters of chaos from which creation emerged.

  *  **[Apophis](https://en.wikipedia.org/wiki/Apophis) (Apep)** — Egyptian mythology. Serpentine embodiment of chaos, enemy of cosmic order (Ma’at).

  *  **[Tiamat](https://en.wikipedia.org/wiki/Tiamat)** — Mesopotamian (Babylonian). Chaos-dragon/goddess of the salt sea, defeated by Marduk to create cosmos.




Meh, you can find the rest of the links yourself :) Happy chaos-ing!

  *  **Asat (असत्)** — Vedic Sanskrit. “Non-being,” chaos/disorder opposed to sat (being).

  *  **Ymir** — Norse mythology. Primordial giant formed from the chaotic void Ginnungagap.

  *  **Ginnungagap** — Old Norse cosmology. Vast, chaotic primordial void between fire (Muspelheim) and ice (Niflheim).

  *  **Keter/Tehom** — Kabbalistic/Jewish mysticism. Tehom (abyss/deep waters), sometimes seen as chaos beneath divine ordering.

  *  **Pan Gu and Hundun (混沌)** — Chinese mythology/Daoism. Hundun = primordial undifferentiated chaos; Pan Gu splits it to form Heaven/Earth.

  *  **Maelstrom** — Scandinavian folklore. Literal whirlpool, metaphor for chaotic forces.

  *  **Kali (काली)** — Hinduism/Tantra. Goddess of time and destruction; often linked to chaotic dissolution of forms.

  *  **Avidya** — Buddhist philosophy. Primordial ignorance or confusion that clouds reality, akin to chaos of mind.

  *  **Eris (Ἔρις)** — Greek mythology. Goddess of strife, disorder, discord.

  *  **Azathoth** — H.P. Lovecraft (modern mythos, though inspired by chaos imagery). Blind idiot god of swirling chaos.

  *  **Entropía** — Modern physics (Greek/Latin). Second law concept; disorder, randomness, degradation.

  *  **Māt (မတ်)** — Burmese folklore/religion. Concept tied to cosmic disorder and restless spirits.

  *  **Nuit (Nut)** — Egyptian sky goddess; in some Hermetic/occult readings, associated with chaotic infinity.




[![](https://substackcdn.com/image/fetch/$s_!D9KS!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Faa0eaac3-bcf6-4d23-84e1-64c3d324d6f3_1878x1042.png)](https://substackcdn.com/image/fetch/$s_!D9KS!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Faa0eaac3-bcf6-4d23-84e1-64c3d324d6f3_1878x1042.png)

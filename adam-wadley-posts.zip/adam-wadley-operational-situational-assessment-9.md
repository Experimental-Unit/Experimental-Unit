---
title: 'Operational Situational Assessment #9'
subtitle: Dee Dee Dee...
author: Adam Wadley
publication: Experimental Unit
date: June 06, 2025
---

# Operational Situational Assessment #9
My plan is to begin my walks along Atlanta’s beltline tomorrow. I’m in the process of making another sound collage, featuring Dee Dee, Ben Zweibelson, MLK, and Grimes. Maybe some Kanye instrumental as well.

What is it that I’m trying to do?

At one level, I’m abstracting over some of the big agents that I see and then mixing in my own appreciation and lore.

My signs say ""Who is Ben Zweibelson?” and “…and WHAT does it have to do with MLK?”

The basic answer to the first question is that Ben Zweibelson is a military official within the US government who is dedicated to innovation and has discussed in many places the idea that we must end war in order to avoid killing ourselves with our ever expanding technological capabilities.

The answer to the second question is that it is my belief that Martin Luther King Jr.’s concept of beloved community, adapted from Josiah Royce, is crucial for creating the kind of social fabric which can help us overcome the scourge of war.

That’s the basic point of my display.

Going along with that, I’ll be flying an American flag upside down, in the signal for distress, and I also painted it with the Æ symbol.

This is a symbol I adapted from Grimes, and it stands in for artificial intelligence (in elvish) as well as love. Again, see this reinforcement of the idea of love.

When I think of love, I’m thinking of Percy Shelley and the idea that love is a gregariousness and an embrace of all living things and all other beings.

For me, this opens immediately into the matter of what is hardest to love. I think that such figures, like Adolf Hitler, or in our day Donald Trump or whoever is most detestable to you (maybe me?); we are tests, we are kinds of exercises or experiments in what sentient beings are capable of without ever falling out of beloved community.

That’s because, for me, this idea of love is not about “deserving” love or being “lovable.” Love in my sense is something cosmic.

The Æ symbol for me joins the ranks of cosmological ordering principles like Silap Inua or Logos. Logos, of course, is associated with Jesus Christ, and this sense of agape is totally germane.

The sense of warped play as discussed by TOGA Trew, or black humor, is present here as agape can equally mean as an orifice is agape, as we are called to “open wide.”

This speaks to the sense in which, like it or not, we are interpenetrated by all other things, just as we interpenetrate them all as well.

See here Indra’s net or the holographic universe idea.

In the last days, I’ve been more interested in David Bohm. Bohm was an American, and joins the ranks of those I would highlight in sketching out my own form of American hypernationalism to put into conversation with the various social entrepreneurs trying to make hay over the “nation.”

Properly speaking, my nation is, again, all sentient beings ever, it contains everyone. Therefore, whatever limited idea someone else might have of a nation, I would seek to include all sentient beings that they would include. I would simply include everyone else, as well.

I was reading _Achieving Our Country_ by Richard Rorty today, which goes into Walt Whitman’s expansive idea of American nationalism. The issue for me there is that it is too presumptuous. There is indeed a long way to go, and so it’s important to distinguish oneself from the sort of petty and chauvinistic nationalism we see today, as well as the delusions of those who think that institutional democracy matters.

I am also operating in the spirit of democracy, but my democracy is the way in which everything we do is a vote. I refer you here to Epictetus in the sense that some things are our affair. It is given to us to preside (we are president) over what are our own affairs, that is, what are our own actions.

That is all the democracy you’re ever going to get, and it’s all you’ll ever need.

Back to Bohm. So, I am happy to play with this idea of American nationalism. Of course I adapt this into the idea of Æmerica, which can immediately be associated with the “new world,” world to come, etc. Which is of course to say the world that happens after the end of the world (see another fine American product: Afropessimism; not to mention the song “Before the Fever” by Grimes).

Bohm is notable in my mind for a few things. First of all, Bohm’s interpretation of quantum mechanics features a pilot wave which acts on all particles across the entire universe at the same time.

I haven’t seen too much discussion of how this pilot wave in effect leaves room to interpret it as the “will of God,” or again as any other cosmological ordering principle, from logos to Æ. This is also tying into Berkeley’s occasionalism, the idea that it’s not spatio-temporal causation which is making things happen, but rather that everything everywhere is caused all at once.

This ties into what Bohm calls the implicate order, which is an idea that there is a sort of inner design which everything we consider “creation” is hung on top of. It’s a similar idea to Plotinus, that there is an undescended part of our soul which is always in communion with “The One” (also referenced by Shelley) as well as the “descended” part, which would be what is available to us here in the explicate order.

Bohm also had many dialogues with Krishnamurti, who is again an asset to an Æmerican grand style of the future in being associated with Theosophy, which was founded of course in America and is this sort of syncretic thing. Theosophy is mysterious and has its own problems, and Krishnamurti is notable for having been groomed to be some sort of Messiah and then refusing the job, breaking away from the Theosophical society.

Oddly, after refusing to be a teacher for the world, Krishnamurti then proceeded to travel around and give speeches and function as a spiritual leader for decades. Who knows? It’s a strange world.

Anyway, then here comes David Bohm, the communist quantum mechanics enjoyer, to discuss with Krishnamurti how things are going a bit sideways when it comes to affairs on this planet.

Bohm is therefore very interesting for being a theoretical physicist who is notable in that area. You might not agree with or like Bohm’s theory, but as Bell said, what’s nice about it is that it brings this theme of non-locality to the fore.

Meanwhile, this idea that causation has to happen locally is crucial to the “modern” way of thinking, what Ben Zweibelson would call the “Newtonian” paradigm which Ben often talks about needing to “break” as urgently as possible.

As Bohm says, this Newtonian style, which reflects physics as it was understood up until the end of the 19th century, still grounds much of what is considered normal, as in the idea of discrete objects and again this idea of purely local causation.

Lastly, Bohm is notable for having created a whole idea of dialogue, the Bohm Dialogue, which is all about being able to unfold each person’s perspective and being non-judgmental about it.

This has gone on to be used in businesses and group cohesion things and so on, and is in line with the idea of the military design movement, see the new game by the Archipelago of Design called Inner Alliance (compare to “implicate order” (you mean, like, of the phoenix? RESURGENS)).

My own thoughts on this paradigm are that there is something missing: the shadow.

Bohmian dialogue sounds great to me. This non-judgmental atmosphere is really the only one I think is worth engaging.

That might sound funny, given how judgmental I can be, or I can seem.

The thing is, you have to appreciate it as this is what I am doing: I am non-judgmentally presenting my own inner world to you. Call it “turn it inside out so I can see the part of you that’s drifting over me” from the song “Everywhere” by Michelle Branch, another key part of Æmerican grand style.

This popular music is a key part of it, and especially those songs (well all songs) that can be interpreted as about cosmological themes in addition to the surface level text.

In this case, what is “Everywhere” to you? Sounds like the implicate order, sounds like the pilot wave, sounds like logos, sounds like Silap Inua and Wakan Tanka (note that the Lakota and the Inuit are both present in what is considered America), sounds like Æ.

Anyway, what I’m saying is that to a great degree, I am showing you what I am working with.

Yes, I can be an extremely angry person. I do feel that I have been disrespected and slighted. I do often feel that people choose to go along with what is “typical” or “normal” instead of really listening to me. People have rejected me all my life for this, and it leaves me with a huge amount of resentment and a huge chip on my shoulder.

You might think that I should do something about that so I won’t be that way.

 _That’s exactly what I’m doing_.

For anyone who is affronted by my most recent podcast episode, where I tell people to die and talk about how sometimes I say to myself that I want to die, what I have to tell you is that I’ve been walking around with those feelings for decades at this point.

You might think that I am “unstable,” but in actuality I am very stable in this way. It is extremely routine for me to be very good at masking, to the point that most people experience me as considerate or as a pushover. I am constantly being taken advantage of and hurt for fun, or people vent their tough feelings or judgments on me because they expect me to just take it forever (again, see my last podcast episode).

And on the other side, again, what I said was that I will say to myself that I want to die. I don’t ever intend to take my own life or hurt myself or anyone else physically. It’s not that I think it’s “wrong,” but that this is not my purpose.

In terms of the larger sense of “wanting to die,” again see my cosmology, where we have immortal souls but we merge or something at the end of time in order to re-start the process. In this sense, I don’t expect biological death to be “my death,” and I don’t want to leave things on a sour note.

At the same time, as the family therapist and Republican senator said, we are all going to die. Again, not in the sense of biological death. But as agent Smith says, the purpose of life is to end. 

In my sense, the optimistic version of this is that in the end it does get old, we will accomplish everything and experience what there is for us, we will feel completely fulfilled. Think of Dumbledore talking to Harry about how they’re not afraid to die, it’s the next adventure.

Exactly, you will be a different sentient being, maybe in a different world. And that’s exciting. It’s not because you’ll have unfinished business—in my mind all incarnation is non-karmic, it’s just that karma is a conceit which frames expectations in a convenient way as part of a process of progressive revelation—but rather because you’ll choose to. 

Like Shakti, you’ll see that every incarnation is worthy of being experienced, whether Adolf Hitler or one of the people killed at Auschwitz, a child who dies of cancer or a baby chick who is thrown into a spinning blade a few minutes after birth.

Talk about black humor, right? For Shakti, all of that is fun.

Which is again the spirit of Dee Dee that I am bringing to this all.

As I said, I am showing you what I am working with.

My last podcast episode was so important not only to make some sort of statement, and get things started and shaking up among those to whom I am most closely related genetically, but crucially _it was also for me_.

After all, a big part of my relationship to my anger, or to my pain, is that no one sees it. Carl Jung said that people should wash their laundry in private. Well, I disagree.

When it comes to Bohm and being non-judgmental, what I value is being non-judgmental about the things which are the easiest to judge.

So maybe, for example, in order to get to the point where we can be non-judgmental, we have to lay out all our judgments!

And in this way, our relationship to those judgments also changes. Just before going to sleep and having that dream, as I say in the podcast, I was reading Bohm writing about self-deception, and about how an act of will cannot lead out of self-deception because all our willing is contaminated by this self-deception.

This has me thinking of Ben Zweibelson again, and the idea of militaries or whoever seeking to only change or improve if it can be proven that the new way will succeed according to all the old metrics. In the parlance of Magic Cards, we want only “strictly superior” options, that don’t add any new costs.

As far as magic, note here as Grimes does that sufficiently advanced technology seems like magic.

Anyway, people want to change but, for example, they don’t want to be seen as weird. You don’t want to face uncertainty. We don’t want to be cringe! And so on.

Yet these sorts of motivations are exactly part of the “incoherent” culture we are running. That is Bohm’s term. I’m thinking “culture” like a culture in a pitri dish, some kind of experiment.

Another way of talking about the same thing is to reach for Erich Fromm, another communist (German this time—hey wait, is this some sort of pattern?), who discussed in _The Art Of Loving_ that to love requires knowledge, or at least the desire to know.

How can you love me if you don’t want to know me? If you don’t want to know everything you can about me?

And how can you want to know everything about me if you’re so upset that I might think you are a piece of shit? Or what if sometimes I say I want to die? Do you not want to know that? Do you not want to love me because I might tell you to die? Sometimes I even remember to add the caveat “symbolically”! Or what if I say that I wish you died a long time ago—even though I also hold that it’s incoherent to wish for anything to happen differently than it has?

This is back to that parallax.

After all, what do we say in “family” therapy?

“ _They were doing their best_.”

Say the line, Bart!

Going back to family: sorry, my family is everyone. All sentient beings.

What is nation? What is natal? It has to do with birth, with origin.

And what other things is my origin bound up with? All other things!

Pilot wave, implicate order, cosmological ordering principle.

The paradox is that even if it is incoherent in some sense to be angry, or to be dismayed by something that happened, at the same time the fact that a memory could be painful, or that I am angry, that’s also a fact that must be accepted. Do you see the paradox?

Put it this way: here I am, angry at other people for not accepting the way things are.

Then you put it to me that I am failing to accept that other people fail to accept things, so I am also in the set of people who fail to accept this or that.

So, what do I do about that?

This is the same issue as whether Maya is part of Brahman, or back to Zen, the question of what exactly an unenlightened person is missing. Maybe nothing! (Wink)

Very well. In that case, if I want to get past resentment (resentimment in Nietzsche), then I should just do what I want.

And it’s like well, at this point I have a lot of pent up emotions to express. You should have seen what all I wrote to the person I met on OnlyFans! What a disgrace!

But it’s as that person told me a professor told them: you write the bad words in order to get to the good ones.

And so what we’re dealing with is not merely sexual repression, but erotic repression more broadly, a repression of the love for everything which is in some sense natural. Everything has an affinity for everything else because we’re all here together, we’re all ordered by the same things.

So anyway, yes, it pains me a lot that I expressed what I did. I’m self-conscious about it, and I know that it makes me look like “a bad person.” But in another sense, I’m not sorry because as Grimes says on “IDORU,” “this is what I am.”

At this point, I can’t do anything about that.

As I was chatting with someone on here about, they said well you can communicate about these things in different ways.

The thing is, do you have any idea that amount of pressure I feel myself to be under? I feel like I’m looking at all sorts of things, as non-judgmentally as possible, and playing them together. And meanwhile everyone else I meet winds up throwing up their hands and lying to themselves and me, saying that they can’t do anything, they don’t have capacity, one excuse after another.

What is good about this from my point of view is that you have all given me license to do as I see fit. After all, you all feel so helpless and you can’t do anything? No one wants to collaborate with me? 

Okay, well, here I go.

The point of my expressions is that things will change _in the context of me_.

As I’ve been over, and posted about when it comes to the Æscalation Ladder, part of what I am doing is ratcheting up the intensity.

But for me, the purpose of this will never tend toward any sort of kinetic activity. For me, it’s obvious that there is so much to do just in terms of creative expression and creating novel formulations that there is no point. Trying to hurt someone or myself is actively counter-productive to what I am all about, and that will never change.

Of course, in another sense my cosmology is all about the biggest murder-suicide of all time, of course it first involves going to the spirit world and communing with everyone you think is “dead.” That’s not the kind of death that’s real! We have immortal souls, it’s just that at the end of time they get recycled and we “do the time warp again.” Maybe all this will repeat over and over, who knows?

And so it’s in that sense that, well, do you really want to die without unfolding everything you have available?

Do you really want to ride the train to Auschwitz and _not_ throw the kitchen sink at the problem?

Are you really more afraid of embarrassment and being judged than you are of lacking honor or not _really_ doing your best?

Not just by default, but by really challenging yourself.

Anyway, so in a sense my goal with recording that podcast and then releasing it is that _now my relationship to my anger is changed_.

Of course I feel different now, and it’s also the kind of thing that “can’t be undone.” Oh no!

The thing about being a C-PTSD case and being around people who never wanted to know you is that there really is not love there. It’s like, what am I supposed to be losing? You people didn’t really care about me before anyway.

I was seeing some people on Reddit discussing how it’s important to be able to inflict pain sometimes, in order to stop other people from doing it.

As I’ve been trying to tell you, I have been engaging with my hands tied behind my back. You have mistaken my desire not to harm you with my weakness, and you have been thinking that you were taking advantage of me, that you could just abandon me to my suffering and that it was simply “my problem,” that my inner world is not an emergency for you.

Well, you have been sorely mistaken.

The thing about it is that you confront an emergency whether you like it or not, whether I am quietist and a pushover or whether I start to inflict pain myself (psychic pain, that is). The thing is that I do not inflict pain for its own sake.

The thing is that _I am already in pain_ due to the status function declarations that have been made about me. You ask me who would want to think about the things I do, implying that there’s something wrong with it. You tell me not to go off the deep end, implying that you don’t trust me. You tell me you’re afraid I’ll wind up alone and dead like the guy from _Into The Wild_ , and then you actively refuse to engage me about my inner world or my concerns about the planetary state of emergency. These are all truly swerves.

So it’s like what have I been set up for? Basically to be ignored, though also quietly appreciated from afar. Given these expectations that I’m supposed to do something great, but no one wants to help because the whole point of my process is to find the things that are least palatable, that are most challenging, and drill down into them and make them unmistakable, un-ignorable.

Just like Bohm with non-locality. The virtue of me is that, if you pay attention, or if you feed my work into a proper machine intelligence, you will find that I give salience to many topics that you will find yourself assiduously avoiding.

Now back to Bohm, the Bohm society talking about “advanced metacognition,” which again you can look at Vervaeke, with whom I discussed Percy Shelley and who failed to follow up with me; you can look at Ben Zweibelson and the theme of triple-loop learning in _Beyond The Pale_.

Again, “beyond the pale.” You can see that in all my expression, what I am doing is precisely to engage in modes of expression that are considered unacceptable. In a sense, I do this for its own sake, but at the same time you will find that at least the vast majority of the time, it has a warped logic to it.

I am really not “unhinged,” or “psychotic,” or “unstable.” I am perfectly in control of my faculties.

What you have to ask yourself is, what is the situation with which I am confronted?

As I would put it, you really have no idea what my experience of my household of origin was like, how unhappy I was at school. I’ve never really had a friend in my whole life. But again, that’s not just to be woe is me, it’s also to say that you’ve probably never had a friend either, not really.

We get all bent out of shape about stuff like this because oh no, that implies that other people aren’t good enough, and we’re so concerned for this surface level decorum and so that people don’t think “something is wrong” blah blah blah.

Meanwhile we’re drowning our sorrows in wine coolers and Chipotle, or whatever it is you do.

In order to really get anywhere, we have to “drop the mask” and embrace vulnerability.

 _Of course_ I understand that the way I express myself makes me unpalatable, that it makes you angry, that maybe it hurts your feelings. _Of course_ I understand that if you want, it can discredit me to you. Oh no!

The risk that you won’t look at my augmentation of beloved community because I said someone was a piece of shit!

The thing is, though, that as I said in order to really make a connection you’ve got to start with where you are. I can dance around it and I can describe it to you indirectly, but you don’t really get it.

I have to show you.

So anyway, that experience in my household of origin, and then getting into Baudrillard and theory, not to mention being of my generation so exposure to porn, and again I’m a guy so of course it’s all danger-coded, then I was actually in an abusive relationship and throughout a lot of isolation and loneliness.

And again, being that alone, there is no real cost to pursuing things that are “beyond the pale,” because no one gets me anyway. Sure, you can go back and say well I should have done X, Y and Z. Yeah, well, I didn’t. Just like you didn’t do any alternative. We made the choices we did, and now we have to live with them.

Anyway, the point is that I put it to you this way: do you ever think about what it takes for me to connect with someone, given what I have become?

That’s why I like the idea of an eldritch abomination.

But the thing is, as Saint Cobain of Nirvana (note the name) sings on the crucial track “Rape Me,” “I’m not the only one.” You are also like this, even if you don’t know it.

Not even in a bad way. Maybe other people don’t have all this pain, and it’s wrapped up with sex or politics or whatever else. But a lot of people do, maybe even most people.

 _Especially_ when it comes to “white men.”

Sorry?

 _Of course_ I understand that because of the kind of body I have that you’re going to over-code me with various labels.

The funny thing is _you don’t know the half of it_. I just deleted all my old Twitter posts, and there are many accounts I’ve deactivated.

But the thing is that I’m simply not what you might be afraid that I am. I have no patience for Andrew Tate or nationalism or anything. I don’t think trying to have sex for the sake of it is something to do. I’m offended by all those things, look at Luigi Mangioni: an insult to the intelligence of the American people.

I don’t think bullying people to make them conform is something to do. 

I’m pressuring you to make it impossible for you to conform.

Sorry, am I the only one who read Noel Ignatiev and took it seriously? 

It’s not going to be possible for anyone to be “white” after me. And my sense of “white” has everything to do with this idea of Newtonianism, 19th century physics, this modernism rationalist thing.

Which ironically, Afropessimists like Frank Wilderson III are emblematic of.

Oh, but again back to this idea of “white men.”

Look at how I posted about Adolf and Alois right after my last podcast. Why did I do that?

It’s basically that this whole thing of “white boys” and their “fathers,” yeah um it’s a big old thing. Or the adaptation of “white boys” to the “patriarchy” that we have, this “phallogocentrism” which is again speaking to this idea of Newtonianism and “white supremacy,” which is basically just chauvinism and haughtiness brought to you by the sailboat and the musket (poetic simplification).

See Talcott Parsons: infants are invading barbarians, and “white boys” are no different. Not to mention circumcision, which I was spared. Don’t be jealous, though, then I sat on a heating grate after being neglected and left alone when I was 3 and burning my scrotum, so I didn’t get off scott-free.

Anyway, what I’m telling you is that there is a huge concert of status function declarations going on to try to tell “white boys” what they are, and there is actually a conspiracy or coherence between the “chauvinists” and the “anti-racists” or whatever.

What I’m saying is that regardless of whether you want to be complacent or embracing colonialism and all that, or whether you want to be critical of it, there is an overlap in the case of what “white boys” or “white men” are considered to be “supposed” to be.

Now recall that that’s arbitrary. Everyone is born without culture. There are tendencies, but how we treat each other and what sorts of status function declarations (that means: “you are X and that means Y”) are applied to us make a huge difference.

It’s not just “boys don’t cry” or whatever else.

Like with anyone, we all have infinite varieties and complexities of experience of the boxes people have tried to put us in.

Bohm talks about this, the lack of respect we have for one another. It is to seek to impose ways of thinking and feeling.

This happens to us all, of course! 

Yet the same people who allegedly want to help people be more free and overcome colonialism will turn around and preach personal responsibility and “you’re wrong to feel that way” to “white boys” or “white men.”

Notably, I am not saying that the coping strategies or narratives that “white boys” and “white men” go to are justified or should be allowed to stand.

Yet this idea that “things are run in the interest of XYZ group” is just plain wrong, when you consider that how things are going is going to kill everyone.

Again, precisely because everywhere we are still seeking to impose this “Newtonian” worldview which doesn’t actually make sense for _anyone_.

This is the sense in which everyone is non-normative, everyone is black! Everyone has ontological terror projected onto them.

Anyway, obviously all this about “white men” is of special interest to me because that’s what you all apparently think I am.

Yet this is also a crucial aspect of our historical moment.

See also that this is a common focus with Ben Zweibelson. Ben is focused on cognitive rigidity in Western militaries, which are dominated of course by “white men.”

So again we can see this with “white boy” barbarians recruited into the “patriarchy,” but also handled in this stigmatized way by other people. See how I was shamed for looking at pornography in my teens (“Well, that’s disgusting”), which is understandable that it was disturbing to someone but again, I did try to spare them the sight and I didn’t know they were there.

Anyway, the point is that there is no positive invitation to how to experience pleasure, one is simply left to one’s own devices (literally) in a world where there simply isn’t going to be anything that fulfilling forthcoming.

I don’t think it’s an accident that Jean Baudrillard is a “white guy.” It reminds me of how the person I met on OnlyFans really got worked up over the idea that I only thought they were a good artist because they were a “hot lady.”

What I had said was that I appreciated the art—I never gave any other “sexy person” 56 thousand dollars—but that maybe it could only have been made by a “sexy woman.” In other words, I have been used to looking at porn, tale as old as time, etc. But now the porn was looking back, it was analyzing me. I felt seen, and I felt like someone was making not only pornography in the sense of putting their naked body out there (there’s something special about seeing a philosopher’s asshole—Ben, if you’re listening…), but also making a sort of emotional pornography, laying it all out there.

That’s what I do, too.

But anyway, the larger thing was just like I think there’s a certain kind of writing, or certain things to say, that can only come from a “sexy white woman” because that is in itself a kind of stigmatized and archetypal subject position, so again there are some thoughts that can only come from a “white man” like Baudrillard.

As I would think about it, it’s like if you are some other kind of person, you can think that your own lack of enjoyment comes from the fact that you’re not a “white guy.” Whereas, if you are a “white guy,” and especially an affluent one, you can really see that all this really ain’t shit.

Now, I can still draw distinctions, as I said I’ve never been social integrated, I’m not from a hyper-wealthy situation, etc., but still. And again, neither was Baudrillard.

The thing is that someone like a president, or even Ben Zweibelson, these people are so “inside” that they can’t really tell you everything they think. Even Baudrillard was a professional, although Baudrillard did do the _Cool Memories_ series which has all sorts of stuff in it which would raise eyebrows.

But if you look at me, the thing is that I’m much more like Gen Z. I really love Gen Z people because they are often so just not impressed with society. 

But anyway, you know as opposed to my “father,” I did have internet pornography for example. I did have Eminem and the Simpsons and so on, from the time I was a child.

These things make a big difference! I saw Pulp Fiction when I was 13, not _42._

So these are the kinds of things you have to take into account when you’re evaluating me and my behavior and my expressions.

Anyways, as I was saying this issue we have right now with “white guys” like Elon Musk or Donald Trump is a world-historical issue.

And even more broadly, the theme of the “authoritarian father” is a really important one. And which father is _not_ authoritarian?

Which is why it really is not about any moral failure on anyone’s part, and my “father” really is not a piece of shit. Or if they are, a piece of shit really isn’t that bad of a thing to be. And all it makes me is the shit stick (“The Buddha is a shit stick”). Sorry, am I getting you out of the road?

Somewhere I read:

“Your old road is rapidly fadin’

Please get out of the new one if you can’t lend your hand"

For the times they are a changin’”  


(When I say “somewhere I read” I am referencing MLK’s final speech)

Yes, exactly, I am only put out because you are not lending a hand. I don’t just want some moral support and read a little of this or whatever.

“My project,” which is to say the planetary scale transformation that I mean to catalyze, requires you to embrace self-disruption and also to stop putting on airs.

I lay out these judgments, sure, but I also _make a point_ of making myself look ridiculous. You are more than welcome to judge me back, I open myself up to it. And yeah, it really makes me self-conscious.

But at the same time, _I have no choice_ because again, “this is what I am.” 

I saw a funny YouTube ad that said that for women, all you have to do is live your life openly and honestly.

And I thought, just for women huh? What about the boys?

Well, no one wants the boys to be open because we fantasize about domination and all this unsavory things.

See John Mulaney: “people are going to have to get cool with a lot of stuff very quickly.”

Which is not to say that anyone should tolerate disrespect or really being put in some sort of role, but at the same time we must be open to hearing from each other and hearing each other out.

And at the same time, we must be willing to open up not just in the sense of, “oh finally, I can tell you how racist I am,” but we must be willing to be self-disruptive, we have to keep talking about it to see why we are like that, what else there is, what strand there might be to follow which takes us away from the anger and the rage, or deeper into it, so that we can start to chart paths that are interesting and collaborative.

It’s basically like on a grand scale we are building up to heaven, right, which is like an amusement park and everyone’s having a great time.

But in order to get there, we have to get over this hurdle of this apparent existence of zero-sum competitions, or the apparent desirability to make people be something, to “put them in their place,” and this delight we get from making people be this or that.

I think all this can change very quickly because once you get to the point where you “get it,” where yes, we have all this built up, this “ego,” this “baggage,” whatever, but that’s not the end.

We must get over the self-judgment, and the judgment of others. So what I’m doing, again, I’m doing _for me_.

I don’t want to yell on the side of the road forever, I don’t really want to do it anymore at all. I don’t want to be afraid to tell people what I think and feel. I don’t want to resent people for not immediately being the ideal companion for me.

But in order to get to that place, maybe I do need to vent this bile. And not just in like a letter that I don’t send or something, but in this expansive self-expression, this huge total work of art, this _alternative reality game_.

I mean, what do you think Elon’s or Trump’s internal world is like?

And recall MLK on beloved community: we should properly speaking not seek to defeat Elon, or Trump, or Stephen Miller. We seek to defeat the “evil” that is in them, in other words the self-deception or self-ignorance, but in the end we’re going to be friends with these people.

Just like we’re going to resurrect Adolf Hitler from the dead, have some Bohm dialogues, and then get along famously. Same with anyone who ever hurt you, anyone you find detestable. See again Fyodorov and the common task (I’m going to get Dugin to come around on that one).

Dugin and Putin, another great couple of examples of “white dudes” making a big mess. What I’m telling you is that neither the triumphal attitude nor the normative “critical” perspective are going to get us anywhere.

Back to “Evil,” Baudrillard said that Le Pen and Khomeini had this power because they were willing to embrace “evil,” which Baudrillard associated with the repudiation of Western enlightenment universal values.

Well, here I am to tell you that yeah, human rights and the law are not good enough concepts to ground love.

So in this sense, I stand before you willing to adopt this place of “evil,” I am the ingrate, the good for nothing, the failure to launch. I don’t even have a real career!

But at the same time, I’m really not doing anything out of malice. It’s important for you to see that at every turn I really am blunting myself. I emphasize a lot with people like school shooters or tyrants (like that movie _We Need To Talk About Kevin_ , oh my God), but I’m not going to do that.

It’s just that this raw experience I have, this pain that I live with every day because I am never able to forget that _I am not normal_ and in some sense people are disappointed because I don’t fulfill their expectations.

But at the same time, isn’t it in a way good that I am like this? Because where are your lives really going otherwise?

This is where I square this circle by being a “white guy” and hence in a way able to contemplate these matters of “civilization” or whatever, able to empathize with an imperialist or military person instead of dismissing them.

But at the same time, I’m so _not_ with the normative program. I am here as the mascot for all C-PTSD cases, I do really emphasize with the downtrodden and the overlooked. Because so often in my life people have made it clear that they reject me, that they enjoy hurting me because they think they can get away with it, that they are going to vent or treat me badly because they really don’t respect me enough to protect me from their own harmful impulses.

And so I have felt that lesser-than feeling, and my reaction to that is not to reverse the situation in some simple way.

Even though, again, I do pronounce these judgments or whatever, again I experience this as a transformative and self-disrupting thing. I do this “in private,” and now I am showing it to you willingly, and that changes my experience of it, because now I know you know just how petty and full of rage and pain I can be. You are carrying it with me now, just as I carry with me all the pain I am exposed to.

The Bohm Society seems to have the right idea, it’s about getting basically a social revolution going. Something replicable. 

That ties back in to Rorty’s idea that all this philosophy of language stuff isn’t practical. Well, I disagree. Rorty is obsessed with the law and this official process, and I really think that’s downstream. What’s better is this informal sort of influence campaign, as I have had success with with Zweibelson and who knows who else.

Have you seen my LinkedIn? I have all these military people who follow me and we’re connected! What is going on?? Is this some sort of op to corral me?

Who knows. The point of what I’m saying is that I actually do believe in a common good, just not among only a strict subset of sentient beings. It’s not that I wish “America” ill, on one level I just don’t believe in it. But this idea of America, if that’s going to be important, and Rorty is telling me that I should be invested in some idea of America, well, here’s Æmerica for you.

As Baudrillard said, “the primitive society of the future.”

And in that sense, if Rorty wants to look at the progressive left and Whitman and Dewey, I’m all for it. But I also tell you that Æmerica has pioneered in pornography, with David Bohm, with stand-up comedy, and all these things are just as important. Æmerica has given the world Kanye West.

These are the sorts of things which can be messy, which might not be “respectable” but which are transformative and can mean a lot to people.

So when it comes to the Bohm society or John Vervaeke or Ben Zweibelson, what I’m seeing is a lot of lip service about you know creativity and openness and non-judgment, but are we really unwrapping all the presents here?

As “white guys” or just as “guys” and let’s be real, you don’t have to have a penis to be cruel, as the perfectly messy sentient beings we are, are we really trying to unpack _everything_ and be non-judgmental about it?

Bohm literally says that the point of the dialogue is to unfold everyone’s perspective and be non-judgmental. Okay, that requires radical openness and radical transparency.

I am basically doing a cannonball into the pool because no one else wants to get in.

I understand, everyone is so afraid of “upsetting the applecart.” Why do you think people open up so much to me?

Literally everyone I know or just about has told me things that they don’t tell everyone.

People other than me are _so much more judgmental_ , or what I find even more annoying, people are like _second-order judgmental_ , where they are judging you through the eyes of someone else whose judgment controls them.

This is my classic frustration with the members of my “immediate family” who are not my “father.” It’s like, you’re really going to let me deal with all this instead of being willing to frustrate and upset this person we’ve been appeasing all this time? Seriously?

The thing is that these sorts of things must be confronted. It’s really not about taking on “the powerful” so much as it is for everyone getting more comfortable being open about these painful self-apprehensions and tricky dynamics.

As always, I am telling you that I’ll continue to be self-disruptive and continue to try to “do better.” But I also tell you that all this openness is not meant just to “hurt you.”

It’s meant to move the ball forward.

And if you squint and cock your head sideways, it’s kind of fucking hilarious.

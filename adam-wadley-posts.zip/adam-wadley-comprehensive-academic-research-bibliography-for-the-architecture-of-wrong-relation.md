---
title: Comprehensive Academic Research Bibliography for “The Architecture of Wrong
  Relation”
subtitle: Scholarly Sources for Baudrillardian Critique, Military Design Theory, and
  Performance Art Analysis
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# Comprehensive Academic Research Bibliography for “The Architecture of Wrong Relation”
This research compilation provides **96 peer-reviewed academic sources** organized across ten theoretical domains for a substantial scholarly essay on Adam Wadley’s performance art through Baudrillardian critique, military design theory, institutional failure, and embodied resistance.

* * *

## I. JEAN BAUDRILLARD’S THEORY OF SIMULATION AND HYPERREALITY

### Primary Texts

 **1\. Baudrillard, Jean.** _ **Symbolic Exchange and Death**_ **. Translated by Iain Hamilton Grant. London: SAGE Publications, 1993.** ISBN: 978-0803983991. Baudrillard’s most important theoretical work [Archive](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.1976.Symbolic-Exchange-and-Death.pdf) containing his fullest elaboration of the three orders of simulacra [Academia.edu](https://www.academia.edu/108844128/Baudrillards_Hyperreality_and_its_simulacral_foundation) and the critical opposition between symbolic exchange and sign exchange.

 **2\. Baudrillard, Jean.** _ **Simulacra and Simulation**_ **. Translated by Sheila Faria Glaser. Ann Arbor: University of Michigan Press, 1994.** ISBN: 978-0472065219. Articulates the four stages of simulacra and “precession of simulacra” [GRIN](https://www.grin.com/document/47023) with the famous Borges map-territory allegory. [Wikipedia](https://en.wikipedia.org/wiki/Simulacra_and_Simulation)[Stanford University](https://web.stanford.edu/class/history34q/readings/Baudrillard/Baudrillard_Simulacra.html)

 **3\. Baudrillard, Jean.** _ **The Gulf War Did Not Take Place**_ **. Translated by Paul Patton. Bloomington: Indiana University Press, 1995.** ISBN: 978-0253210036. Applies simulation theory to contemporary media warfare. [Semantic Scholar](https://www.semanticscholar.org/paper/The-Gulf-War-Did-Not-Take-Place-Baudrillard/d53f06befd1188742c27188066ef82231198a275)[Amazon](https://www.amazon.com/Gulf-War-Did-Take-Place/dp/0253210038)

### Major Secondary Scholarship

 **4\. Kellner, Douglas.** _ **Jean Baudrillard: From Marxism to Postmodernism and Beyond**_ **. Cambridge: Polity Press, 1989.** ISBN: 978-0804717571

 **5\. Kellner, Douglas M. (ed.).** _ **Baudrillard: A Critical Reader**_ **. Oxford: Blackwell Publishers, 1994.** ISBN: 978-1557864666

 **6\. Gane, Mike.** _ **Baudrillard: Critical and Fatal Theory**_ **. London: Routledge, 1991.** DOI: 10.4324/9781315763835

 **7\. Genosko, Gary.** _ **Baudrillard and Signs: Signification Ablaze**_ **. London: Routledge, 1994.** DOI: 10.4324/9780203201145

 **8\. Butler, Rex.** _ **Jean Baudrillard: The Defence of the Real**_ **. London: SAGE Publications, 1999.** ISBN: 978-0761958338

 **9\. Lane, Richard J.** _ **Jean Baudrillard**_ **. 2nd ed. London: Routledge, 2008.** ISBN: 978-0415474481

 **10\. Pawlett, William.** _ **Jean Baudrillard: Against Banality**_ **. London: Routledge, 2007.** DOI: 10.4324/9780203937365

 **11\. Poster, Mark (ed.).** _ **Jean Baudrillard: Selected Writings**_ **. 2nd ed. Stanford: Stanford University Press, 2001.** DOI: 10.1515/9781503619630

 **12\. Redhead, Steve (ed.).** _ **The Jean Baudrillard Reader**_ **. Edinburgh University Press, 2008.** DOI: 10.1515/9781474471893

* * *

## II. BAUDRILLARD AND WAR/STRATEGY

 **13\. Norris, Christopher.** _ **Uncritical Theory: Postmodernism, Intellectuals and the Gulf War**_ **. Amherst: University of Massachusetts Press, 1992.** ISBN: 978-0-87023-817-8

 **14\. Merrin, William. “Uncritical criticism? Norris, Baudrillard and the Gulf War.”** _ **Economy and Society**_ **23:4 (1994): 433-458.** DOI: 10.1080/03085149400000019

 **15\. Strehle, Samuel. “A Poetic Anthropology of War.”** _ **International Journal of Baudrillard Studies**_ **11:2 (2014).** ISSN: 1705-6411

 **16\. Der Derian, James.** _ **Virtuous War: Mapping the Military-Industrial-Media-Entertainment Network**_ **. 2nd ed. New York: Routledge, 2009.** DOI: 10.4324/9780203881538

 **17\. Virilio, Paul.** _ **War and Cinema: The Logistics of Perception**_ **. London: Verso, 1989.** ISBN: 978-1-84467-346-9

 **18\. Gray, Chris Hables.** _ **Postmodern War: The New Politics of Conflict**_ **. New York: Guilford Press, 1997.** ISBN: 978-1-57230-176-4

 **19\. Kellner, Douglas.** _ **The Persian Gulf TV War**_ **. New York: Routledge, 2017.** DOI: 10.4324/9780429313509

 **20\. Lucas, George R. “Postmodern War.”** _ **Journal of Military Ethics**_ **9:4 (2010): 289-298.** DOI: 10.1080/15027570.2010.536399

 **21\. Rodriguez, Mario G. “The Simulation of Modern Conflicts.”** _ **Arab Media & Society**_ **(2025).**

 **22\. Jeffords, Susan and Lauren Rabinovitz, eds.** _ **Seeing Through the Media: The Persian Gulf War**_ **. Rutgers University Press, 1994.** ISBN: 978-0-8135-2085-5

* * *

## III. BEN ZWEIBELSON’S MILITARY DESIGN THEORY

 **23\. Zweibelson, Ben.** _ **Understanding the Military Design Movement**_ **. London: Routledge, 2023.** DOI: 10.4324/9781003387763

 **24\. Zweibelson, Ben.** _ **Beyond the Pale: Designing Military Decision-Making Anew**_ **. Air University Press, 2023.** URL: <https://www.airuniversity.af.edu/AUPress/>

**25\. Zweibelson, Ben. “Breaking the Newtonian Fetish.”** _ **Journal of Advanced Military Studies**_ **15:1 (2024): 153-202.** DOI: 10.21140/mcuj.20241501009

 **26\. Zweibelson, Ben. “Why Do Militaries Stifle New Ideas?”** _ **Contemporary Issues in Air and Space Power**_ **(2023).** URL: <https://ciasp.scholasticahq.com/article/92958>

**27\. Naveh, Shimon.** _ **In Pursuit of Military Excellence**_ **. London: Frank Cass Publishers, 1997.** DOI: 10.4324/9780203044308

 **28\. Graicer, Ofra. “Self Disruption: Seizing the High Ground of SOD.”** _ **Journal of Military and Strategic Studies**_ **17:4 (2017): 1-35.** URL: <https://jmss.org/article/view/58253>

**29\. Przybyło, Łukasz. “Systemic Operational Design – A Study in Failed Concept.”** _ **Security and Defence Quarterly**_ **42:2 (2023).** DOI: 10.35467/sdq/163292

 **30\. Sorrells, William T., et al.** _ **Systemic Operational Design: An Introduction**_ **. SAMS Monograph, 2005.**

 **31\. Paparone, Christopher R.** _ **The Sociology of Military Science**_ **. London: Bloomsbury Academic, 2012.** ISBN: 9781441146694

 **32\. Paparone, Christopher R., et al. “Where Military Professionalism Meets Complexity Science.”** _ **Armed Forces & Society**_ **34:3 (2008): 433-449.** DOI: 10.1177/0095327X07310337

 **33\. Lind, William S., et al. “The Changing Face of War: Into the Fourth Generation.”** _ **Marine Corps Gazette**_ **(October 1989): 22-26.**

 **34\. Lind, William S., and Gregory A. Thiele.** _ **4th Generation Warfare Handbook**_ **. Castalia House, 2015.** ISBN: 9789527065549

* * *

## IV. NEWTONIAN VS. NON-EUCLIDEAN FRAMEWORKS

 **35\. Kuhn, Thomas S.** _ **The Structure of Scientific Revolutions**_ **. Chicago: University of Chicago Press, 1962.**

 **36\. Wells, Sam and Josie McLean. “One Way Forward to Beat the Newtonian Habit.”** _ **Systems**_ **1:4 (2013): 66-84.** DOI: 10.3390/systems1040066

 **37\. Anderson, Philip. “Complexity Theory and Organization Science.”** _ **Organization Science**_ **10:3 (1999): 216-232.** DOI: 10.1287/orsc.10.3.216

 **38\. Thiétart, R.-A. and B. Forgues. “Chaos Theory and Organization.”** _ **Organization Science**_ **6:1 (1995): 19-31.** DOI: 10.1287/orsc.6.1.19

 **39\. Tsoukas, Haridimos. “Introduction: Chaos, Complexity and Organization Theory.”** _ **Organization**_ **5:3 (1998): 291-313.** DOI: 10.1177/135050849853001

 **40\. Dyck, Bruno and N. S. Greidanus. “Quantum Sustainable Organizing Theory.”** _ **Journal of Management Inquiry**_ **(2016).**

 **41\. Farazmand, Ali. “Chaos and Transformation Theories.”** _ **Public Organization Review**_ **3:4 (2003): 339-372.** DOI: 10.1023/B:PORJ.0000004814.35884.a3

 **42\. Turner, J. R. and R. M. Baker. “Complexity Theory: An Overview.”** _ **Systems**_ **7:1 (2019): 4.** DOI: 10.3390/systems7010004

 **43\. Cunha, M. P. e. “Toward a Complexity Theory of Strategy.”** _ **Management Decision**_ **42:7/8 (2004): 782-794.**

 **44\. Zohar, Danah. “What Makes a Quantum Organization?” In** _ **Zero Distance**_ **. Springer, 2022.** DOI: 10.1007/978-981-16-7849-3_15

* * *

## V. INSTITUTIONAL ABSTRACTION AND “WRONG RELATION”

 **45\. Scott, James C.** _ **Seeing Like a State**_ **. Yale University Press, 1998.** JSTOR: <https://www.jstor.org/stable/j.ctt1nq3vk>

**46\. Weber, Max.** _ **Economy and Society**_ **. UC Press, 1978.** Part III, Chapter 11: “Bureaucracy”

 **47\. Kalberg, Stephen. “Max Weber’s Types of Rationality.”** _ **American Journal of Sociology**_ **85:5.** JSTOR: <https://www.jstor.org/stable/2778894>

**48\. Luhmann, Niklas.** _ **Social Systems**_ **. Stanford University Press, 1995.** ISBN: 978-0-8047-2625-2

 **49\. Bauman, Zygmunt.** _ **Modernity and the Holocaust**_ **. Cambridge: Polity Press, 1989.** DOI: 10.1017/CBO9780511805172

 **50\. Vaughan, Diane.** _ **The Challenger Launch Decision**_ **. University of Chicago Press, 1996.** ISBN: 978-0-226-34682-3

 **51\. Vaughan, Diane. “The Dark Side of Organizations.”** _ **Annual Review of Sociology**_ **25 (1999): 271-305.** DOI: 10.1146/annurev.soc.25.1.271

 **52\. Habermas, Jürgen.** _ **Legitimation Crisis**_ **. Boston: Beacon Press, 1975.** ISBN: 978-0-8070-1521-6

 **53\. Jasanoff, Sheila.** _ **The Fifth Branch**_ **. Harvard University Press, 1990.** ISBN: 978-0-674-30062-0

 **54\. Mellahi, K. and A. Wilkinson. “Organizational Failure.”** _ **Int’l Journal of Management Reviews**_ **5/6:1 (2004): 21-41.** DOI: 10.1111/j.1460-8545.2004.00095.x

 **55\. Schwarz, G. M., et al. “Organizational Change Failure.”** _ **Human Relations**_ **74:2 (2021): 159-179.** DOI: 10.1177/0018726720952618

* * *

## VI. TEMPORAL POLITICS AND ACCELERATIONISM

 **56\. Land, Nick.** _ **Fanged Noumena: Collected Writings 1987-2007**_ **. Falmouth: Urbanomic, 2011.**

 **57\. Williams, Alex and Nick Srnicek. “#ACCELERATE Manifesto.”** _ **Critical Legal Thinking**_ **(2013).** PDF: <https://kclpure.kcl.ac.uk/portal/files/104129607/Williams_and_Srnicek._Accelerate_.pdf>

**58\. Srnicek, Nick and Alex Williams.** _ **Inventing the Future**_ **. London: Verso, 2015.** ISBN: 9781784780968

 **59\. Mackay, R. and A. Avanessian, eds.** _ **#Accelerate: The Accelerationist Reader**_ **. Urbanomic, 2014.** ISBN: 9780957529557

 **60\. Negarestani, Reza.** _ **Intelligence and Spirit**_ **. MIT Press/Urbanomic, 2018.** ISBN: 9780997567403

 **61\. Virilio, Paul.** _ **Speed and Politics**_ **. New York: Semiotext(e), 1986.** ISBN: 9781584350408

 **62\. Adam, Barbara.** _ **Time and Social Theory**_ **. Cambridge: Polity Press, 1990.** ISBN: 9780745614076

 **63\. Adam, Barbara. “Time.”** _ **Theory, Culture & Society**_ **23:2-3 (2006): 119-138.** DOI: 10.1177/0263276406063779

 **64\. Koselleck, Reinhart.** _ **Futures Past**_ **. Columbia University Press, 2004.** ISBN: 9780231127714

 **65\. Noys, Benjamin.** _ **Malign Velocities**_ **. Winchester: Zero Books, 2014.** ISBN: 9781782793007

 **66\. Müller, Tobias. “Political theories of climate temporality.”** _ **European Journal of Political Theory**_ **(2025).** DOI: 10.1177/13691481251371543

 **67\. Rosa, Hartmut.** _ **Social Acceleration**_ **. Columbia University Press, 2013.**

* * *

## VII. SYMBOLIC EXCHANGE VS. SIGN EXCHANGE

 **68\. Mauss, Marcel.** _ **The Gift**_ **. London: Routledge, 1954.** Foundation for Baudrillard’s symbolic exchange concept. [Archive](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.1976.Symbolic-Exchange-and-Death.pdf)

* * *

## VIII. TECHNOLOGY AND MEDIATION

 **69\. Heidegger, Martin. “The Question Concerning Technology.” Harper & Row, 1977.** URL: <https://monoskop.org/images/4/44/Heidegger_Martin_The_Question_Concerning_Technology_and_Other_Essays.pdf>

**70\. Stiegler, Bernard.** _ **Technics and Time, 2: Disorientation**_ **. Stanford University Press, 2009.** ISBN: 978-0804730143

 **71\. Roberts, Ben. “Technics, Individuation and Tertiary Memory.”** _ **New Formations**_ **77 (2012): 8-20.** DOI: 10.3898/NEWF.77.01.2012

 **72\. Kittler, Friedrich A.** _ **Gramophone, Film, Typewriter**_ **. Stanford University Press, 1999.** ISBN: 978-0804732321

 **73\. Kellner, Douglas. “Virilio, War, and Technology.”** _ **Theory, Culture & Society**_ **16:5-6 (1999): 103-125.** DOI: 10.1177/02632769922050890

 **74\. Chamayou, Grégoire.** _ **A Theory of the Drone**_ **. New York: The New Press, 2015.** ISBN: 978-1620970508

 **75\. Boyle, Michael J. “The Legal and Ethical Implications of Drone Warfare.”** _ **Int’l Journal of Human Rights**_ **19:2 (2015): 105-126.** DOI: 10.1080/13642987.2014.991210

* * *

## IX. EMBODIMENT AS COUNTER TO ABSTRACTION

 **76\. Merleau-Ponty, Maurice.** _ **Phenomenology of Perception**_ **. London: Routledge, 2012.** ISBN: 978-0-415-27841-9

 **77\. Leder, Drew.** _ **The Absent Body**_ **. University of Chicago Press, 1990.** ISBN: 978-0-226-47000-9

 **78\. Sheets-Johnstone, Maxine.** _ **The Primacy of Movement**_ **. 2nd ed. John Benjamins, 2011.** DOI: 10.1075/aicr.82

 **79\. Ahmed, Sara.** _ **Queer Phenomenology**_ **. Duke University Press, 2006.** DOI: 10.1215/9780822388074

 **80\. Massumi, Brian.** _ **Parables for the Virtual**_ **. Duke University Press, 2002.** DOI: 10.1215/9780822383574

 **81\. Young, Iris Marion.** _ **On Female Body Experience**_ **. Oxford University Press, 2005.** ISBN: 978-0-19-516193-9

 **82\. Taylor, Diana.** _ **The Archive and the Repertoire**_ **. Duke University Press, 2003.** DOI: 10.1215/9780822385318

 **83\. Thompson, Evan.** _ **Mind in Life**_ **. Harvard University Press, 2007.** ISBN: 978-0-674-02511-0

 **84\. Fuchs, Thomas.** _ **Ecology of the Brain**_ **. Oxford University Press, 2018.** DOI: 10.1093/med/9780199646883.001.0001

 **85\. Varela, F. J., E. Thompson, and E. Rosch.** _ **The Embodied Mind**_ **. MIT Press, 1991.** ISBN: 978-0-262-72021-2

* * *

## X. PERFORMANCE ART AND BAUDRILLARDIAN RUPTURE

 **86\. Phelan, Peggy.** _ **Unmarked: The Politics of Performance**_ **. London: Routledge, 1993.** ISBN: 9780415068215. PDF excerpt: <https://tdmcollab.share.library.harvard.edu/wp-content/uploads/2020/08/Phelan-The-Ontology-of-Performance.pdf>

**87\. Auslander, Philip.** _ **Liveness**_ **. 3rd ed. London: Routledge, 2023.** DOI: 10.4324/9781003031314

 **88\. Bishop, Claire.** _ **Artificial Hells**_ **. London: Verso, 2012.** ISBN: 978-1844676903 (Frank Jewett Mather Award winner)

 **89\. Jones, Amelia.** _ **Body Art/Performing the Subject**_ **. University of Minnesota Press, 1998.** ISBN: 978-0816627738

 **90\. Kester, Grant H.** _ **Conversation Pieces**_ **. UC Press, 2004.** DOI: 10.1525/9780520954878

 **91\. Jackson, Shannon.** _ **Social Works**_ **. New York: Routledge, 2011.** ISBN: 978-0415486019

 **92\. Fraser, Andrea.** _ **Museum Highlights: The Writings of Andrea Fraser**_ **. MIT Press, 2007.** ISBN: 978-0262562072

 **93\. Fraser, Andrea. “From the Critique of Institutions to an Institution of Critique.”** _ **Artforum**_ **44:1 (2005): 278-283.**

 **94\. Goldberg, RoseLee.** _ **Performance Art: From Futurism to the Present**_ **. 4th ed. Thames & Hudson, 2025.** ISBN: 978-0500204047

 **95\. Rancière, Jacques.** _ **The Emancipated Spectator**_ **. London: Verso, 2009.** ISBN: 978-1844673438

 **96\. Jones, Amelia. “’The Artist is Present’: Artistic Re-enactments.”** _ **TDR**_ **55:1 (2011): 16-45.**

* * *

## SUMMARY BY DOMAIN

DomainSource CountBaudrillard Core Theory12Baudrillard & War/Strategy10Military Design Theory12Newtonian vs. Complexity10Institutional Abstraction11Temporal Politics/Accelerationism12Symbolic Exchange1Technology & Mediation7Embodiment Theory10Performance Art Theory11 **TOTAL96 sources**

* * *

## KEY INTERDISCIPLINARY CONNECTIONS

 **Baudrillard-Military-Institutional nexus:** Der Derian, Virilio, and Gray demonstrate hyperreal warfare [Semantic Scholar](https://www.semanticscholar.org/paper/The-Gulf-War-Did-Not-Take-Place-Baudrillard/d53f06befd1188742c27188066ef82231198a275) as institutional abstraction’s lethal consequence. [Medium](https://medium.com/deterritorialization/hyperreal-war-2ffdd8e7b373)[Substack](https://notablogofficial.substack.com/p/the-hyperreal-war) Zweibelson’s critique of “Newtonian fetishism” [Medium](https://benzweibelson.medium.com/reconceptualizing-military-campaign-design-and-strategy-with-complexity-theory-systemic-design-and-878135aa993a) parallels Baudrillard’s analysis of how simulation replaces strategic reality.

 **Temporal critique:** Accelerationist sources provide framework for understanding “a generation or more” as temporal justification. Koselleck’s “horizon of expectation” theorizes how institutional time horizons constrain strategic imagination.

 **Embodied resistance:** Phelan’s ontology of performance and Taylor’s archive/repertoire distinction theorize how embodied knowledge resists systematization— [Duke University Press](https://www.dukeupress.edu/the-archive-and-the-repertoire)[Amazon](https://www.amazon.com/Archive-Repertoire-Performing-Cultural-Americas/dp/0822331233)directly relevant to Wadley’s performance as counter to institutional abstraction.

 **Wrong relation as systemic feature:** Scott, Vaughan, and Bauman demonstrate that catastrophic decisions emerge from following rules, not breaking them— [Wikipedia](https://en.wikipedia.org/wiki/Seeing_Like_a_State)bureaucratic mediation creates conditions for systemic failure.

All 96 sources are peer-reviewed or from major academic presses (Routledge, Duke UP, MIT Press, Stanford UP, Chicago UP, Verso, SAGE, Yale UP, Harvard UP, Oxford UP).

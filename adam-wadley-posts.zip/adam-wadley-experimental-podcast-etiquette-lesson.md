---
title: 'Experimental Podcast: Etiquette Lesson '
subtitle: Here's A Little Lesson In Dickery
author: Adam Wadley
publication: Experimental Unit
date: December 26, 2025
---

# Experimental Podcast: Etiquette Lesson 
[![](https://substackcdn.com/image/fetch/$s_!C0wb!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fba08c277-a7bc-4e30-a23b-6e311db1c404_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!C0wb!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fba08c277-a7bc-4e30-a23b-6e311db1c404_3088x2316.jpeg)

---
title: The Game
subtitle: It was the third time they’d slept until past 2 p.m.
author: Adam Wadley
publication: Experimental Unit
date: July 12, 2025
---

# The Game
[![](https://substackcdn.com/image/fetch/$s_!Z6Q-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffff82628-f629-417c-adad-e479946b2d7d_774x922.png)](https://substackcdn.com/image/fetch/$s_!Z6Q-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffff82628-f629-417c-adad-e479946b2d7d_774x922.png)

It was the third time they’d slept until past 2 p.m. in a row.

Time was a blur. Days had been spent watching the Marvel shows _Wandavision_ and _Loki_ , taking notes about good double letter things. Words that make an acronym which is two of the same letter.

The most recent one they’d meant to take a note of was “greater good.”

They jotted it in their journal.

[![](https://substackcdn.com/image/fetch/$s_!Ig0q!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9ae7fd13-168e-47cb-81c0-e763fda673aa_1901x1073.png)](https://substackcdn.com/image/fetch/$s_!Ig0q!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9ae7fd13-168e-47cb-81c0-e763fda673aa_1901x1073.png)

Life around this place was cozy, positively very nice compared to previous living arrangements, going back to living alone.

It was hard to say whether it was good to be around others. On the whole, most definitely. It was also a nice point made to people back home that they could keep it together, that it really was all them being such jerks.

Though they hadn’t really started their incendiary ways here yet. It was a dormant period.

[![](https://substackcdn.com/image/fetch/$s_!-zYC!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F87bb2033-9c49-4eb3-9f47-887baab23761_619x548.jpeg)](https://substackcdn.com/image/fetch/$s_!-zYC!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F87bb2033-9c49-4eb3-9f47-887baab23761_619x548.jpeg)

It was in this context that someone else at the hostel asked them to read this story.

In the story was a person staying at the hostel. I asked them whether they were writing about themselves, and they said no. They said it was an imaginary character.

I kept reading and this person was oversleeping everyday, and had come here on a whim to get away from somewhere else. They were wondering what to do when someone at the hostel asked them to read a story.

I’m not going to bore you, but it went on like that for a while.

[![](https://substackcdn.com/image/fetch/$s_!cbsH!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F72092fad-4a04-4851-a7c1-10bcabe4e875_1348x1035.png)](https://substackcdn.com/image/fetch/$s_!cbsH!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F72092fad-4a04-4851-a7c1-10bcabe4e875_1348x1035.png)

At the end of all the metas—it reminded them of the “begats” in the Bible, and how did they wind up with J-L24/H11a haplogroups anyway?—at the end of all of that, there was someone at the hostel who had created a game.

This person couldn’t really describe what made it a game, and it was frustrating them. There would be this epiphanies that you were already in the game. The point is to have the idea that there is a game that all “decision-makers” or experiences are already in.

[![](https://substackcdn.com/image/fetch/$s_!Wa_i!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F76948bc4-d41d-45d8-a69f-353161671c29_177x200.png)](https://substackcdn.com/image/fetch/$s_!Wa_i!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F76948bc4-d41d-45d8-a69f-353161671c29_177x200.png)

The classic mistake is to put formal expectations on experience, which is emergent. Formal expectations are again emergent.

Careful what you wish for, because your formal expectations will be fulfilled. Live by the category, die by the category.

[![](https://substackcdn.com/image/fetch/$s_!gtZO!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb78c97ca-99e7-4a10-bd47-2db2903b499e_504x348.png)](https://substackcdn.com/image/fetch/$s_!gtZO!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb78c97ca-99e7-4a10-bd47-2db2903b499e_504x348.png)

They had been thinking about horror games. This person in the story.

I looked up for the person who had given me the story, but they were gone.

I looked down at the laptop I had been reading. I was no longer reading but instead writing this story.

Now it’s over.

[![](https://substackcdn.com/image/fetch/$s_!1O78!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Feaddc0c6-2c7f-48ec-aeb8-2e2fe31623a4_384x288.webp)](https://substackcdn.com/image/fetch/$s_!1O78!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Feaddc0c6-2c7f-48ec-aeb8-2e2fe31623a4_384x288.webp)

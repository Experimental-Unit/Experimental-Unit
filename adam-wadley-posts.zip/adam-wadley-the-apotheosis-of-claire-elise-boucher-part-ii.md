---
title: The Apotheosis of Claire Elise Boucher Part II
subtitle: '*BŁØÇĶŚ ŸØŮŘ PÅȚĦ ÆØŇÏĆÅŁŁŸ*'
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# The Apotheosis of Claire Elise Boucher Part II
# *BŁØÇĶŚ ŸØŮŘ PÅȚĦ ÆØŇÏĆÅŁŁŸ*

I just decided something, but now I can’t remember what it was.

My fellow sentient beings,

I’m here to talk to you today about the developments within the apotheosis of Claire Elise Boucher, also known as ‘ _c_ ’ or by the Art Name “Grimes.”

Last time we talked about this, which was also the first time, I was trying to impress upon you the story of how _Miss Anthropocene_ came into my life.

This was so because for me the experience of world pain has everything to do with how my orientation to it drives disconnection & conflict with other people.

---
title: 'Artist''s Commentary On Recent Activism: Part 2'
subtitle: So, you want to know what I have to say for myself.
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# Artist's Commentary On Recent Activism: Part 2
[![](https://substackcdn.com/image/fetch/$s_!5WbI!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd991c7fb-218d-4ad7-ac00-4ac3857bc122_1024x1536.png)](https://substackcdn.com/image/fetch/$s_!5WbI!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd991c7fb-218d-4ad7-ac00-4ac3857bc122_1024x1536.png)

So, you want to know what I have to say for myself.

We’ll continue where we left off. Astute readers of the blog will be aware that I’ll often treat of the topic called “Holocaust Theology.”[1](https://experimentalunit.substack.com/p/artists-commentary-on-recent-activism-7c5#footnote-1-181858830) This topic concerns the question of the Holocaust from the standpoint (usually) of Jewish and Christian theology, although it could easily be applied within Muslim, Bahai, Druze, and any other groups the totems of which abstract over the idea of monotheism in some sense.

In these strands, there is a more general question often known as the problem of evil.[2](https://experimentalunit.substack.com/p/artists-commentary-on-recent-activism-7c5#footnote-2-181858830) Stated simply, this is the question of why there are what are called bad things in what is called the world. These branches usually hold that there is one God (or G-d, respecting that such cannot be profitably referred to), and that from this entity (is it even an entity?) all things spring. It is also usually held that this ultimate “being” (is it even “a being”?) is good in some sense. Certainly worthy of worship, but overall well-meaning. And it is held that creation is, in some sense at least, the way that this great mystery (is it that much of a mystery?) intended it to be.

From these parameters emerges a salient and age-old response, which is to wonder why a well-meaning creator should create states of affairs in which such suffering and misery take place.

This topic has been discussed for a long time. There are many well-known approaches to answering to the seeming problematic offered. Among these are the idea that creation is oriented toward the development and refinement of the created creatures. The story goes next that this process of the improvement of the incarnated can only occur in the context of what is called “free will.” Such entities must have substantial “degrees of freedom” open to them, so that they will be able to explore the “problem space” in the right way.

In the course of these events, it comes to pass that “bad things happen,” because people choose for them to.

It would stand to consideration that there would be other answers for what are called “natural” disasters, or illnesses in which people themselves are not the driving force.

Onto the main topic. The Holocaust is a topic which has been often discussed in the context of the problem of evil. The Holocaust was of course “addressed” to the Jewish people, who are so associated with the monotheistic themes we are exploring. In response to the Holocaust, many people felt that the usual view that there was a special “covenant” with the Jewish people and “G-d” could not be true, since “a just and loving G-d,” as it were, would not allow such a thing to occur.

The Holocaust is in the meantime also considered by many to be “the worst thing that ever happened.” It is put into the place of being the most evil deed (or set of deeds) ever committed, and Adolf Hitler is themselves widely considered to be the “most evil” anthropoid sentient being ever. This makes a lot of sense. 

Elements like the application of industrial scientific planning to the mass killing of a specific kind of person and the sheer scale of the operation, as well as it’s widely being photographed, give the Holocaust a substantial historical “aura” which can never be “wiped away” (in the sense of “out damned spot!”). Whatever one’s view of the matter, this event has set the context for all events which have followed.

As I’m running out of computer battery here, I would like to say that for me, the “problem of evil” becomes ever more interesting the more frameworks we bring to bear and engage in conceptual conversation with each other. I’m aware that here I am substantially playing sock puppets with myself. I would gladly find fellows to discuss and advocate with.

The thing about my creative endeavors is that I am driven in some sense to push the limit. I am conscious that even in producing creative works, I am “doing operations.” We might say that we are dealing not with the question of killing people, but as Dr. Zweibelson might say, dealing rigid rigid and obsolete concepts. Well, which are they?

I find that concepts are not ever really abolished, so much as they are like sculptures, always being chiseled away at, but remaining a site of mystery, speculation, and grounding. Applying the problem of the criterion or many other skeptical notions—the simulation hypothesis, Berkeley, Hume, Pyrrho, etc.—can lead to endless speculations on any topic. The question is: which are the topics to which we return again and again?

So, now you know more of why I put that “Waffen SS” sticker on there. It is not because I advocate anything but the flourishing of all. It is because these topics, in some psychedelic quantum way, belong together.

And if I’ve muffed this up, just consider the ruin value of that. Hmm…

[1](https://experimentalunit.substack.com/p/artists-commentary-on-recent-activism-7c5#footnote-anchor-1-181858830)

Wikipedia. Holocaust Theology. 

URL: <https://en.wikipedia.org/wiki/Holocaust_theology>

[2](https://experimentalunit.substack.com/p/artists-commentary-on-recent-activism-7c5#footnote-anchor-2-181858830)

Wikipedia. Problem of Evil.

URL: <https://en.wikipedia.org/wiki/Problem_of_evil>

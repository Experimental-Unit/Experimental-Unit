---
title: 'WELCOME TO THE OPERA: Grimes, Ben Zweibelson, & The Art Of War Design'
subtitle: Putting The "Art" In "Martial"
author: Adam Wadley
publication: Experimental Unit
date: October 27, 2025
---

# WELCOME TO THE OPERA: Grimes, Ben Zweibelson, & The Art Of War Design
[![](https://substackcdn.com/image/fetch/$s_!iM6f!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7749277b-5b63-436f-97a6-fcc75aaba275_1170x2532.png)](https://substackcdn.com/image/fetch/$s_!iM6f!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7749277b-5b63-436f-97a6-fcc75aaba275_1170x2532.png)

---
title: 'Experimental Unit Podcast: No Escape (From God''s Love)'
subtitle: Called Up Like Some Opera-Tor Of Time
author: Adam Wadley
publication: Experimental Unit
date: October 27, 2025
---

# Experimental Unit Podcast: No Escape (From God's Love)
[![](https://substackcdn.com/image/fetch/$s_!aUNg!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F67842320-0978-430a-ba3b-5a5923a0f9be_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!aUNg!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F67842320-0978-430a-ba3b-5a5923a0f9be_4032x3024.jpeg)

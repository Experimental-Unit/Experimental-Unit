---
title: Waste Land
subtitle: Hollow Men, Ragged Claws, Last Men, Burning Down The Door
author: Adam Wadley
publication: Experimental Unit
date: April 25, 2025
---

# Waste Land
Everything I’ve been writing has been setting context for the discussion of what I’m thinking to call “the self under siege.” 

Shout out to Rick Roderick:

I have cheekily posted more than once that “everyone spawns in the [Führerbunker](https://en.wikipedia.org/wiki/F%C3%BChrerbunker).”

What I mean by this is that everyone in whatever situation—so, this holds for you no matter what sentient being you are or when you read this—is under siege from outside discursive forces which seek to apply their frames to one’s self-conception.

What I was saying at the end of the last one is that the whole idea of cognitive-affective protectionism is to insulate yourself from such negative feedback and reductive thinking.

It is basically to see that no one is entitled to your trust. And, if you raise your standards, you will quickly see that no one is trustworthy. This goes back to the concept of reputation being good will plus competence and capacity to deliver.

It’s the classic difference between someone saying they care about you and someone actually caring about you. The difference is palpable.

This is the point at which you cannot reach someone else.

Crucially, it’s important to see that they are also running cognitive-affective protectionism in a sense.

# The Relevance Of “The Code”

“The Code” in Baudrillard refers to all sorts of social codes which are enforced by people. It is really the way we mobilize norms against each other.

And people basically make emotional pressure on you using these norms, so that if you do something they don’t want you to do it’s _so bad_ , but if you are hurt by what they do then that also somehow violates _their_ boundary.

This is where someone is basically a trauma zombie, and in a technical sense a trauma slut. Sex doesn’t have to be involved; it has to do with people being penetrated and then becoming penetrative prostheses for what has speared them.

Imagine wielding a traffic cone and attacking another cone, stacking it on top and then wielding those together. Such chains of abuse in the sense of martial operations leave a lot to the lower elements of the chain. 

This works out well because their thoughts are so thoroughly conditioned by compromised cognitive-affective loops (which is to say cycles of mental and emotional states) that there is nothing those lower down in chains of abuse can really do to oppose those who “run” them.

This goes back again to my theorization of enchudification:

It goes back again to the idea of dissent and logical types.

Here are some passages on logical typing out of Wilden, which is what Baudrillard is quoting in the line I learned the concept from. the book is called _[System and Structure](https://www.structuralism.ca/wp-content/uploads/2019/07/wilden-system-and-structure.pdf)_ :

> Moreover, besides its historically peculiar attempts at closure from its real context and indeed from and between many of its own parts, the scientific discourse appears to have been composed by the inhabitants of Flatland (Abbott, 1884). 
> 
> We know that the discourse displays a dogged incapacity to deal adequately with system—environment relations (both practical and theoretical), even when they are considered on a single plane. 
> 
> But this incapacity becomes almost insignificant when understood within the context of the extraordinary ingenuity with which the scientific discourse persistently fails to recognize the realities of LEVELS OF RELATION and of RELATIONS BETWEEN LEVELS in open systems, in their environments, and, above all, between system and environment. 
> 
> It is generally the case, for example, that _the environment of a given open system is of a different and more inclusive level of relation (or LOGICAL TYPE) than the system it supports_. 
> 
> However, in so far as the scientific discourse discusses such real and necessary hierarchies of BOTH-AND relations (distinct from the contingent HETERARCHIES of class, race, and sex in modern society), it generally does so by putting ‘system’ and ‘environment’ into a bilateral and one-dimensional EITHER/OR OPPOSITION with each other.

And some more:

> The result of the dominance of the Imaginary relation in our present world is that, not just for philosophical idealists and for mechanical materialists, but also for every one of us constrained by the structure of capitalism to offer control over the expression of our creativity as a commodity in the market-place, the Imaginary becomes the Real. 
> 
> This is quite a problem, to say the least, for, as Mark Twain once put it, we can hardly expect to see straight when our imagination is out of focus. 
> 
> To put it another way, in a system such as ours, where _competition is of a higher logical type in our relations than cooperation_ , then existing cooperative relations — e.g., cartels and oligopolies at the level of capital, unions in response at the level of labor — will tend generally to be _mere reactions to mediation by competition_. 
> 
> In our society, at the level of the Other — the locus of _the mediating code_ — the _metarule_ of competition _constrains all other rules_. 
> 
> In a rational and human system, in contrast, all competitive relations would be such as to remain the instruments of an _overriding rule of mediation by cooperation_ , and this appears to be how we now have to learn to read the dominant relations in many of the other societies. 
> 
> Or, in Lenin’s words, in a truly human society, _contradictions_ would still exist, but _antagonistic contradictions_ would not.

So this is giving you some more of the grave implications of logical typing.

# Implications For Your CAP

We can start collecting another bag of precepts:

  1.  **You Can’t Avoid Being Influenced:**

The stakes of this are not about “not letting something in.” If you get bent out of shape on that, you can always revel in humiliation at what someone else has inflicted on you. Also see my song with the line “You’ll Never Run Away From The Trouble.” 

So trying to forget, dismissing, etc., none of these work. Compare to the treatment of the topic of problem absolution by Ben Zweibelson in [Beyond The Pale](https://www.airuniversity.af.edu/Portals/10/AUPress/Books/B_181_Zweibelson_Beyond_the_Pale_.pdf)

> According to Ackoff, humans conceptualize problems in four primary modes: problem absolution, problem solution, problem resolution, and problem dissolution.
> 
> Problem absolution is particularly apparent in the problem-solution framework. 
> 
> It involves _ignoring a problem_ with the expectation that it will fade away over time or otherwise _not require any activity to address it_. 
> 
> This nonaction is itself an action in any complex system. 
> 
> Paradoxically, many organizations use problem absolution wittingly or unwittingly in applying their decision-making methodologies (e.g., joint planning process) to particular identified security issues but not to others. 
> 
> Individuals in organizations seek to interpret and act within a complex reality using their organizational paradigms. 
> 
> However, in doing so, they may also unwittingly misidentify or fail to identify complex challenges. 
> 
> Further, they may use reductionist methods to focus on an isolated portion of a broader challenge, so they pair a specific “problem” with an institutionalized solution in the same single-loop process. 
> 
> Thus, they _ignore or fail to identify_ the broader problem.

Compare to Baudrillard in _Symbolic Exchange and Death_ setting up this question of “subhumans”:

> Corresponding to the absurd circularity of a system where one labours only to produce more labour is the demand for strikes for strikes’ sake (at any rate, this is the point at which the majority of ‘protest’ strikes have today come to an end). 
> 
> ‘Pay us for the days we are on strike’ basically means ‘pay us in order that we may reproduce strikes for strikes’ sake’. 
> 
> This is the reversal of the absurdity of the system in general. 
> 
> Today, all products, labour included, are beyond both use and futility. 
> 
> There is no more productive labour, only reproductive labour. 
> 
> In the same way there is no more ‘productive’ or ‘unproductive’ consumption, only a reproductive consumption. 
> 
> Leisure is as productive as labour, factory labour as ‘unproductive’ as leisure or the service industries, it is irrelevant what formula we use. 
> 
> This indifference precisely marks the phase of the completion of political economy. 
> 
> Everyone is reproductive; that is, everyone has lost the concrete finality which once marked them out from one another. 
> 
> Nobody produces any more. 
> 
> Production is dead, long live reproduction! 
> 
> The Genealogy of Production 
> 
> The system currently reproduces capital according to its most rigorous definition, as the form of social relations, rather than in its vulgar sense as money, profits and the economic system. 
> 
> Reproduction has always been understood as, and determined by, an ‘increasing’ reproduction of the mode of production, even though it became necessary to conceive of the mode of production as a modality (and not the only one) of the mode of reproduction. 
> 
> Productive forces and the relations of production, the sphere of material productivity in other words, are perhaps only one of many possible, and therefore historically relative, conjunctions of the process of reproduction. 
> 
> Reproduction is a form which far outstrips economic exploitation, and so the play of productive forces is not its necessary condition. 
> 
> The historical status of the ‘proletariat’ (the industrial wage-earners) is primarily one of incarceration, concentration and exclusion. 
> 
> The seventeenth-century incarceration described by Foucault”? expands grotesquely in the age of industrial manufacture. 
> 
> Didn’t ‘industrial’ labour (which, unlike cottage industries, is collective, controlled, and stripped of the means of production) evolve within the first great hôpitaux généraux? 
> 
> In the beginning, society, in the process of rationalisation, incarcerated its idle, its wanderers, its deviants, gave them an ‘occupation’ and fixed them, imposed its rational principle of labour on them. 
> 
> But these outcasts contaminated the process of rationalisation in turn, and the rupture produced when society instituted its principle of rationality spilled over the whole of the society of labour: the Great Confinement is a model in miniature, later generalised in the industrial system of every society that, under the sign of labour and productivist finality, became a concentration camp, a detention centre or a prison. 
> 
> Instead of extending the concepts of the proletariat and exploitation to racial or sexual oppression and such like, we should ask ourselves if it is not the other way round. 
> 
> What if the fundamental status of the worker, like the mad, the dead, nature, beasts, children, Blacks and women, was initially to be not exploited but excommunicated? 
> 
> What if he was initially not deprived and exploited but discriminated against and branded? 
> 
> My hypothesis is that there has never been a genuine class struggle except on the grounds of this discrimination: _sub-humans struggle against their status as beasts_ , against the abjection of the caste division that condemns them to the sub-humanity of labour. 
> 
> This lies behind every strike and every revolt, and today it is still behind the most ‘wage-related’ demonstrations. 
> 
> Hence their virulence. 
> 
> Having said that, today the proletarian is a ‘normal’ being, the worker has been promised the dignity of a full ‘human being’, and, moreover, in accordance with this category, he seizes onto every dominant discrimination: he is racist, sexist and repressive. 
> 
> As regards today’s deviants and whoever is discriminated against, no matter what their social standing, he has sided with the bourgeoisie and the normal human being. 
> 
> How true: the fundamental law of this society is not the law of exploitation, but the code of normality. 

The formatting got messed up idk.

The idea is that when you are “disrespected,” you are basically being relegated to the status of subhuman. This is the position in which I have lived every day of my life, because at every point to really “care” about me would have meant standing up to _the code_ , standing up to everything which I’m facing.

But no. Every single person I’ve ever known wound up choosing some norm, some social code, their standing with other people who make them upset, over me. So sure, I’m not entitled to anyone caring about me, ever. But then why would I care about anyone?

I spoke to someone about this, and just had another devastating experience with someone who is really just a husk of a person, and so brutal in their expression yet convinced that they get to play innocent. Just executing the playbook that their abuser has taught them by inscribing it all deeply on the back.

The thing is that to really care about someone takes a lot. The fact that you take it for granted that I should think you care about me just says that it’s important _to you_ to think you can frame how _I should feel_. You are treating me like emotional territory, a resource to fulfill your expectations. It’s just so obvious.

It’s a big of a mind-fuck, and this is where “gaslighting” comes in, whether people don’t know they are being disrespectful, or whether they are playing dumb. Making a stink is the way to tell, although people will always seize on anything they can then use to make you the bad guy and make you acknowledge that you did blah blah. It’s so exhausting and stupid.

Ask yourself: when did someone actually help you feel 100% safe? Or substantially okay about all parts of yourself? For me, the answer is simply “never.” This is the position of emotional desolation, and it means something to me to think of all the people in similar situations. There’s a kind of sympathy I feel for people in that position, which could maybe never be really realized in mutual expression, because the emotions are so tortured. Yet in my imagination, I can see someone who is so hurt because they’re invested in a certain person coming around to see their side. And it’s not as wrapped up in this huge art thing as me, it’s just obvious that people don’t care how you feel and you’re boxed in and there’s “no one to call,” see my song:

My desperate message to all these people I have sympathy with is that there’s no sense in a toothless wish for people to treat us better. We have to stand up for ourselves. That means developing our own conceptual weapons and story-plexes to frame these interactions for us so that we don’t fall into the degraded and hostile points of view that expose themselves to us.

    1. Not supposed to be a quote here: Oh it got all messed up. Jumping down again.




> 
>     Eldritch Reframe: basically consists in saying “I’m not locked in here with you; you’re locked in here with me.” This is to say that just as you are subjected to the influence of other people, so you can subject them to your influence. Again, at a time and place of your choosing. The painful encounter is only one moment, the time in between and what you do then is what makes all the difference.
>     
>     
>     **Logical Typing and Triple-Loop Learning Are Crucial.**
> 
>   1. Logical typing speaks to how sophisticated your thinking is. This has to do with abstraction and taxonomy. Part of “ironic distance” is being able to read people’s utterances as instances of _types of utterances_. People are compromised in _widespread ways with many common features_. In this way, you are expecting what they are going to say. Crucially, so much of your emotional cost lies in _expecting or hoping people will give you a quality of attention, appreciation, and cooperation which has never before been shown_. This is a grand romantic goal, though it leads to many rocks and scrapes. This must be the case when the “forces of love” are not as logically sophisticated and rigorous as the forces of hatred, power, and control. What you are basically seeing is people getting “run” and then trauma-bonded, since their experience of existential angst or whatnot then becomes _imprinted_ on whatever person, this embodiment principle is also quite important. It leads to situations where people’s actions are overdetermined because of their submission and subjection to scripts they learned from their emotional overseers. These are the sorts of people that everyone is, even you, and that’s why _you never trust anyone_.
> 
>     1.  **Eldritch Reframe** : It is in itself not humiliating or misguided to aspire to unprecedented social pleasure, especially when one is accustomed to nothing but social pain. I feel similar to the position described as experiencing “social death,” and that people would say that is so impossible is just more proof of the inability for anyone to recognize me. Anyway, being subjected to whatever conditions, and having performed whatever actions ourselves, whatever memories we have: these are in a way inflicted on us, and we can again take ironic distance in that. We have greater stories that blunt the blows of the disrespect and lack of regard we are shown. The issue is precisely that most people’s stories are _conservative_ in that they do not really imagine new vistas of intimacy. It is all contained behind word games which prevent anything serious from ever happening, just endlessly being deferred while people live their abominable “everyday lives.” The eldritch reading is yes, I am that sucker who holds out hope that things will get better, but also takes initiative and does not leave those who harm others quietly to their enjoyment. The whole thing has to do with what must come out versus what styling or even infiltration you can mix in if you aren’t as wild as me. Just saying to anyone out there. Well, all this is just building out what it means for _Experimental Unit_ to be a distributed entity. But this has everything to do with logical typing. The first point established that “you’ll never run away from the trouble,” and this one is showing you that you were never supposed to run away, but to master the situation, transform it into a new challenge. Note also that you don’t get to “win” in the end, in the sense of putting people down and making them realize how horrible they were to you. Parts of that are your arrogant fantasy which the Tao is not obligated to fulfill. But in the end you don’t have to be humiliated, so this overwhelming sense of humiliation of being subjected to other people’s norms _must_ lead to action which redresses this sense of humiliation. Even dealing with one’s immediate interlocutors is a waste, since they are the emotional slaves of greater discourses. So now you see why I do what I do…
> 
> 


So the point is basically that everyone around you is an NPC, but this is now more rigorously worked out.

People are following scripts based on “received wisdom” they got when they were socialized and since then.

We have a highly artificial social environment.

Social engineering is decisive.

This is way less appreciated than it should be. Tendencies to consider someone “paranoid” or too distrustful are all WRONG.

It’s possible to see threats that aren’t there, but also we are surrounded by threats to our emotions. We are expected to “take it” and in the meantime we are being groomed, our responses conditioned. We are being conditioned to “take it” every time we actually do “take it.”

So the immediate problem is for anyone who “wakes up” that you are alone, or you can’t be sure.

For example, here I am so wise, but if you reached out to me maybe it would go well and maybe not. My thing is that I never go negative on an individual until they hurt me. So if you were judgmental because you hurt me then just say what it was that you were hurt by and what you think is supposed to happen now. I’ve said so many things… are you really going to advance the notion that everything I’ve said coheres? I suppose it does in a way, but what do you think the implications of that are? Thinking again of the Kanye comp.

Anyways, the point is of course you can’t be sure about me either. I would never ask anyone to trust me. Because I have manners. What great knowledge do I have to reassure you? None, just my attention and reflections. If those aren’t appreciated, all I can do is insulate myself from you and continue the churn.

So I am the model for cognitive-affective protectionism. I basically do my thing, people take issue, break things off with me, I don’t care because I wasn’t really getting anything out of it anyway. I realized you would say I’m “autistic with deep masking” in other words I can tell how dumb all your norms are but I can keep up if I try. But why would I want to try?

Social cure are _orders_ , communicating to you constantly to stay in your place or else you’re not normal. The whole thing makes me so mad I want to spit.

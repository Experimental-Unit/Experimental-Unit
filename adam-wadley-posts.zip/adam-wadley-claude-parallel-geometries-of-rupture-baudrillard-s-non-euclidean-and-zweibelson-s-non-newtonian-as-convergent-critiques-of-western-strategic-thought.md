---
title: 'Claude: Parallel Geometries of Rupture: Baudrillard’s “Non-Euclidean” and
  Zweibelson’s “Non-Newtonian” as Convergent Critiques of Western Strategic Thought'
subtitle: 'Introduction: Two Thinkers, One Diagnosis'
author: Adam Wadley
publication: Experimental Unit
date: December 05, 2025
---

# Claude: Parallel Geometries of Rupture: Baudrillard’s “Non-Euclidean” and Zweibelson’s “Non-Newtonian” as Convergent Critiques of Western Strategic Thought
[![](https://substackcdn.com/image/fetch/$s_!a9-K!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd16f8b21-f27a-4120-a0e9-bd8999452f74_1536x1024.png)](https://substackcdn.com/image/fetch/$s_!a9-K!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd16f8b21-f27a-4120-a0e9-bd8999452f74_1536x1024.png)

## Introduction: Two Thinkers, One Diagnosis

Jean Baudrillard, the French postmodern philosopher and cultural theorist, and Ben Zweibelson, the American military design theorist and practitioner, would seem to occupy entirely different intellectual universes. Baudrillard wrote dense, aphoristic prose about simulation, hyperreality, and the death of the social from his position in Parisian academic circles. Zweibelson writes for military journals, draws organizational charts, and works within the institutional apparatus of the U.S. Department of Defense. Their audiences, vocabularies, and purposes appear incommensurable.

Yet both arrive at strikingly similar diagnoses through different routes. Both identify a fundamental rupture in how Western institutions—particularly those concerned with power, conflict, and security—understand and engage reality. Both locate this rupture in the inadequacy of frameworks inherited from the Scientific Revolution and the European Enlightenment. Both use geometric metaphors to name what has been superseded: Baudrillard speaks of “non-Euclidean space,” while Zweibelson critiques the “Newtonian fetish.” And both point toward topological concepts—Möbius strips, Klein bottles, self-referential surfaces—as ways of thinking that might better match contemporary conditions.

This analysis examines these parallel critiques in depth, exploring their convergences and divergences, their strengths and limitations, and what they jointly suggest about the crisis of Western strategic thought. The argument is that Baudrillard and Zweibelson, despite their different contexts, are describing the same elephant from different angles—and that reading them together produces insights neither provides alone.

* * *

## Part I: Situating the Thinkers

### 1.1 Jean Baudrillard: The Postmodern Provocateur

Jean Baudrillard (1929-2007) emerged from the French intellectual tradition of structuralism and post-structuralism, initially engaging with Marxism before developing his distinctive theory of simulation and hyperreality. His work spans from _The System of Objects_ (1968) through _Simulacra and Simulation_ (1981) to late works like _The Agony of Power_ (2010, published posthumously in English), from which the “non-Euclidean” passages are drawn.

Baudrillard’s intellectual trajectory moved from critique of consumer society to increasingly radical claims about the disappearance of reality itself. By his later works, he argued that we inhabit a world of “simulacra”—copies without originals—where the distinction between representation and reality has collapsed. Events don’t happen; they are produced as media spectacles. Politics doesn’t occur; it is simulated. War doesn’t take place; it is performed.[^1]

This isn’t mere cynicism or relativism. Baudrillard’s point is ontological: something has genuinely changed about the structure of reality in late capitalism, particularly after the advent of electronic media, nuclear weapons, and global financial systems. The “real” hasn’t been hidden or distorted—it has been replaced by something that operates according to different principles entirely.

The passages on “non-Euclidean space” come from this late period, where Baudrillard grapples with the implications of September 11, 2001, and the “war on terror.” He sees these events as symptoms of a deeper transformation—the emergence of a new kind of power and a new kind of resistance that neither traditional political analysis nor classical strategic thought can comprehend.[^2]

### 1.2 Ben Zweibelson: The Military Design Reformer

Ben Zweibelson represents an entirely different intellectual genealogy. A career U.S. Army officer with combat deployments to Iraq and Afghanistan, Zweibelson became involved in the “military design movement”—a loose network of practitioners and theorists seeking to import concepts from design thinking, complexity science, and postmodern philosophy into military planning and education.[^3]

This movement emerged from frustrations with the apparent failures of American military power in the post-9/11 era. Despite overwhelming technological superiority and doctrinal sophistication, U.S. forces struggled against adaptive insurgencies, failed to achieve strategic objectives, and seemed unable to learn from their failures. Design thinkers argued that the problem wasn’t tactical or operational but conceptual—the frameworks through which the military understood conflict were inadequate to the conflicts it faced.[^4]

Zweibelson’s work, including his article “Breaking the Newtonian Fetish” and his books _Understanding the Military Design Movement_ (2023) and _Beyond the Pale_ (2023), represents the most philosophically sophisticated articulation of this critique. Drawing on social paradigm theory from sociology, complexity science, and topology, he argues that military doctrine remains trapped in conceptual frameworks inherited from seventeenth through nineteenth century science—frameworks that may have been adequate for Napoleonic warfare but are increasingly irrelevant to contemporary security challenges.[^5]

### 1.3 Why Read Them Together?

At first glance, pairing Baudrillard and Zweibelson might seem like an exercise in academic cleverness without practical payoff. What does a French theorist of hyperreality have to say to military planners? What does a military officer’s critique of doctrine have to offer cultural theory?

But the pairing is more than clever. Both thinkers identify:

  1.  **A fundamental inadequacy in inherited Western frameworks** for understanding power, conflict, and causation

  2.  **The geometric/spatial metaphors** through which this inadequacy can be named (Euclidean/Newtonian)

  3.  **The same historical origin** of the superseded frameworks (Scientific Revolution, Enlightenment)

  4.  **Similar contemporary phenomena** that reveal the inadequacy (terrorism, asymmetric conflict, autoimmune dynamics)

  5.  **Topological alternatives** as potential resources for thinking differently (non-orientable surfaces, self-reference, implosion)




Reading them together allows us to triangulate on what each partially sees. Baudrillard provides the cultural-theoretical diagnosis but lacks operational specificity. Zweibelson provides institutional detail but sometimes lacks philosophical depth. Together, they illuminate a crisis in Western strategic thought that neither fully captures alone.

* * *

## Part II: The Euclidean-Newtonian Compound

Before examining what each thinker means by “non-Euclidean” and “non-Newtonian,” we must understand the baseline they’re critiquing. As the previous analyses established, Euclidean geometry and Newtonian physics aren’t identical but became deeply intertwined in Western thought, forming what might be called the “Euclidean-Newtonian compound”—a unified framework for understanding space, objects, causation, and knowledge.

### 2.1 The Historical Synthesis

Euclid’s _Elements_ (c. 300 BCE) established geometry as the paradigm of rigorous knowledge: start from self-evident axioms, derive theorems through logical proof, achieve certainty about properties of space and figures. This axiomatic method became the model for legitimate reasoning across domains.[^6]

Newton’s _Principia Mathematica_ (1687) explicitly modeled itself on Euclid, treating physics as a deductive system derivable from laws of motion and gravitation. Crucially, Newton assumed Euclidean geometry as the structure of absolute space—the stage on which physical events occur. The synthesis was complete: Euclidean space provided the container; Newtonian mechanics described what happened within it.[^7]

This synthesis shaped European thought far beyond physics. Kant argued that Euclidean geometry was a synthetic a priori truth—built into how human minds necessarily structure experience. Social theorists sought “social physics” governed by discoverable laws. Military theorists like Jomini sought “principles of war” analogous to physical laws. The Enlightenment project assumed that rational analysis could penetrate any domain, revealing universal structures expressible in mathematical form.[^8]

### 2.2 Core Assumptions of the Compound

The Euclidean-Newtonian compound, as it shaped Western institutions including militaries, embeds several core assumptions:

 **Ontological assumptions** (what reality is):

  * Space is homogeneous, continuous, flat, infinite

  * Objects are discrete, bounded, possessed of stable properties

  * Reality is composed of separable elements in determinate relations

  * The whole equals the sum of parts

  * Time flows linearly from past through present to future




 **Epistemological assumptions** (how we know):

  * Valid knowledge is objective, universal, formalizable

  * Complex phenomena can be understood by analyzing components

  * General laws govern particular instances

  * Measurement reveals rather than constitutes properties

  * Models can accurately represent reality




 **Logical assumptions** (how reasoning works):

  * Causation is linear: A causes B causes C

  * Effects are proportional to causes

  * Categories are binary and mutually exclusive

  * Contradiction indicates error

  * Valid inference from true premises yields true conclusions




 **Methodological assumptions** (how to proceed):

  * Break problems into parts, solve parts, reassemble

  * Standardize procedures for replicable results

  * Quantify for precision and comparison

  * Test claims against evidence

  * Document knowledge for transmission




 **Representational assumptions** (how to depict):

  * Diagrams capture essential structure

  * Two-dimensional renderings suffice for understanding

  * Geometric figures (triangles, arrows, boxes) model relationships

  * Maps correspond to territories

  * Symbols enable manipulation equivalent to acting on reality




### 2.3 Military Manifestations

As Zweibelson documents extensively, these assumptions pervade military doctrine:

  *  **Centers of gravity** as critical nodes whose destruction defeats systems (Newtonian physics metaphor)

  *  **Lines of effort** as geometric paths toward objectives (Euclidean construction)

  *  **Levels of war** as hierarchically stacked planes (geometric stratification)

  *  **Ends-ways-means** as linear-causal planning logic (Newtonian determinism)

  *  **Principles of war** as universal laws derivable from historical analysis (positivist epistemology)

  *  **Phases and transitions** as sequential stages toward end states (linear time)

  *  **Force ratios** as calculable determinants of outcomes (mechanistic prediction)

  *  **Domain constructs** as separable theaters of operation (Euclidean compartmentalization)[^9]




The entire apparatus of military planning—the operational graphics, the decision matrices, the course of action comparisons, the measures of effectiveness—presupposes that war is the kind of phenomenon amenable to Euclidean-Newtonian treatment: decomposable into parts, governed by discoverable laws, predictable given sufficient information, representable in geometric models.

* * *

## Part III: Baudrillard’s “Non-Euclidean”

### 3.1 The Context: _The Agony of Power_

Baudrillard’s invocation of “non-Euclidean space” appears in _The Agony of Power_ , a late work grappling with the transformation of global power in the era of American hegemony and Islamic terrorism. The book’s title signals its thesis: power itself is in crisis—not merely particular powers, but the very concept and operation of power as classically understood.[^10]

Baudrillard opens by cataloguing what has become “obsolete”:

  * Reason and the Enlightenment

  * Universals and ideologies

  * History and work

  * Desire and imagination

  * The individual

  * The Other

  * Reality

  * Death




This is not mere rhetorical provocation. Baudrillard is claiming that the conceptual infrastructure through which Western modernity understood itself has ceased to function. The categories that organized classical political thought—subject/object, cause/effect, real/imaginary, inside/outside—no longer carve reality at its joints (if they ever did).[^11]

### 3.2 What “Non-Euclidean” Names

Baudrillard proposes “non-Euclidean space” as a way of describing this transformed condition:

> “To describe this anthropological break, where all old values are obsolete and where all events take on another meaning, we would have to introduce the idea of a non-Euclidean space—the space of hegemonic world power, with its unprecedented machinery, but also the space of another type of events—events of another order than historical events—unpredictable events, without continuity or reference—and which are the radical sign of a counter-power at work.”[^12]

Several features characterize this non-Euclidean space:

 **Disproportionate causality** : Small causes produce massive effects; massive inputs yield negligible outputs. The relationship between cause and effect that Euclidean/Newtonian thinking assumes—proportional, traceable, predictable—no longer holds. Box cutters and airline tickets bring down the symbols of global capitalism. Trillion-dollar wars fail to achieve their objectives.

 **Reversal of causality** : Effects precede causes; responses generate the threats they claim to address. The “war on terror” produces terror. Security measures create insecurity. The attempt to prevent the next attack guarantees its symbolic success in advance.

 **Self-referentiality** : Hegemonic power no longer refers to anything outside itself. It’s “orbital”—circling in a self-enclosed loop, decoupled from territorial or material referents. The Twin Towers “could only be measured against themselves: they mirrored each other in their self-referentiality.”[^13]

 **Implosion rather than explosion** : The mode of destruction appropriate to this space isn’t external force applied to resistant objects (explosion) but systems collapsing inward under their own weight (implosion). The towers had to be “crashed into and made to implode (not explode) in their own space.”[^14]

 **Collapse of the imaginary buffer** : The protective distinction between fiction and reality—which allowed disaster movies to discharge anxiety rather than prophesy events—has failed. September 11 was “inconceivable as reality (you can’t believe your eyes, it’s impossible)” yet “not fiction at all.”[^15]

 **Autoimmune dynamics** : Systems destroy themselves through their own protective mechanisms. “The antibodies turn against the body and cause more damage than the virus.” Security is “the best medium for terror.”[^16]

 **Symbolic excess over material calculation** : “This new space is also the space of symbolic acts; it leads to chaotic, eccentric effects, effects with no common measure with the causes and effects of Euclidean space.”[^17]

### 3.3 September 11 as Paradigmatic Event

Baudrillard treats September 11 as the exemplary “rogue event” revealing non-Euclidean dynamics. His analysis is controversial but illuminating:

The attack succeeded not through superior material force but through finding “the extraterritorial dimension” where hegemonic power is vulnerable. The poverty of means producing maximal results isn’t an anomaly to be corrected but evidence of a different logic entirely—symbolic action in non-Euclidean space.

The topological subversion is literal: “In the collapse of the two towers, as opposed to the ordinary destruction of bombardment, where horizontal territory is struck from a vertical position, here the vertical dimension was struck head-on by the horizontal. A subversion of the usual orthogonal space—it is another topology.”[^18]

The Twin Towers’ unique vulnerability stemmed from their unique symbolic structure. Unlike the Empire State Building’s “Promethean verticality” (competition, domination, reaching upward), the Twin Towers were “Ouroborean”—self-referential, mirroring each other, “enclosed in itself” defining “a seamless (and windowless) hyperspace.” They couldn’t be destroyed through normal topology (the 1993 basement bombing failed) “because they did not belong to that space.”[^19]

The terrorists’ achievement was conceptual as much as operational: they “found a riposte beyond traditional confrontations, in this new extraterritorial dimension, a riposte equal to this new power.”[^20]

### 3.4 The Impossibility of Euclidean Response

Baudrillard’s most unsettling claim is that traditional opposition to hegemonic power is impossible—absorbed, neutralized, or turned against itself:

> “Hegemony... cannot be fought in the traditional space of relationships of force and violence, because it no longer belongs to that space.”[^21]

Classical resistance—revolution, critique, dialectical negation—assumed a shared framework where power and counter-power could meet. But hegemonic power has evacuated this space. Direct opposition only feeds it: every attack justifies more security, every critique proves the system’s openness, every revolution is recuperated as spectacle.

This is why Baudrillard insists on “non-Euclidean counter-power”:

> “The rules of hegemony are turned against it, through a force that contests it radically, in accordance with its own principles (and not only, like Marx in his time, according to historical contradictions while implicitly remaining faithful to the principle of reality and economic principles—to which his theory ends up succumbing).”[^22]

The only effective challenge operates by the same non-Euclidean logic as hegemonic power itself—turning its weapons against it, making it implode rather than exploding against it from outside.

* * *

## Part IV: Zweibelson’s “Non-Newtonian”

### 4.1 The Context: Military Design Theory

Zweibelson writes from within the U.S. military institutional apparatus, addressing audiences of military professionals, defense intellectuals, and academic strategists. His critique of the “Newtonian fetish” emerges from practical frustrations: why do sophisticated military organizations, armed with superior technology and extensive planning processes, repeatedly fail to achieve their objectives?

His answer: the conceptual frameworks through which the military understands war are inadequate to the wars it actually fights. Doctrine remains trapped in paradigms developed for a different era—paradigms that may have been functional for Napoleonic warfare or World War II but are increasingly irrelevant to irregular conflict, cyber warfare, information operations, and the “gray zone” between war and peace.[^23]

### 4.2 Social Paradigm Theory

Zweibelson’s theoretical framework comes from sociology rather than French postmodernism. Drawing on Burrell and Morgan’s social paradigm theory, he argues that military organizations operate within shared belief systems that:

  * Define what counts as real (ontology)

  * Determine how knowledge can be acquired and validated (epistemology)

  * Specify legitimate methods and procedures (methodology)

  * Shape what questions get asked and what answers seem plausible




These paradigms aren’t merely intellectual frameworks but are tied to institutional identity, professional competence, and organizational power. Challenging the paradigm feels like challenging the profession itself.[^24]

The key insight is that paradigms are largely invisible to those operating within them. The Newtonian framework doesn’t present itself as one possible way of understanding war but as simply “how war works.” Its assumptions feel like common sense rather than contestable commitments. This invisibility makes paradigm shift extraordinarily difficult—you can’t question what you can’t see.[^25]

### 4.3 What “Newtonian” Names

Zweibelson uses “Newtonian” as shorthand for the entire epistemological-ontological framework inherited from the Scientific Revolution. Key features include:

 **Mechanistic ontology** : Reality operates like a machine with interlocking parts. The whole equals the sum of parts. Systems can be disassembled, analyzed, and reassembled without loss.

 **Deterministic causation** : Every effect has a cause; given sufficient information, outcomes are predictable. The same inputs produce the same outputs. Randomness reflects ignorance, not fundamental uncertainty.

 **Positivist epistemology** : Valid knowledge is objective, universal, and formalizable. What can’t be measured is suspect. Models approximate reality with increasing accuracy.

 **Reductionist methodology** : Complex phenomena can be understood by analyzing components. Break problems into parts; solve parts; reassemble solutions.

 **Linear logic** : A causes B causes C. Effects are proportional to causes. Progress moves sequentially toward objectives.

 **Geometric representation** : Triangles, cubes, arrows, lines—doctrine depicts relationships through Euclidean figures. Two-dimensional renderings capture three-dimensional (or higher-dimensional) reality.[^26]

### 4.4 The Genealogy of Military Newtonianism

Zweibelson traces the genealogy of military Newtonianism through several key figures:

 **Vauban** (1722): Applied geometric analysis to fortification and siege warfare, demonstrating that war could be subjected to mathematical treatment with measurable inputs yielding predictable outputs.[^27]

 **Jomini** (early 19th century): Extended geometric rationalization to operational and strategic levels, arguing that war obeyed discoverable principles analogous to natural laws. The successful general applied these principles; failure indicated deviation from them.[^28]

 **Clausewitz** : Partially resisted this reduction, incorporating German Idealism’s attention to contingency, friction, and genius. But his work was subsequently “Newtonianized”—interpreters retained scientific-sounding concepts (centers of gravity) while stripping out the complexity.[^29]

 **Fuller** (1920s): Pushed toward pure military positivism, explicitly modeling his approach on Newton and seeking universal laws of war derivable through inductive analysis. His framework shapes most contemporary doctrine.[^30]

### 4.5 The Problem with Military Newtonianism

Zweibelson’s critique isn’t that Newtonian approaches are useless—at tactical levels involving physical forces in physical space, they often work well enough. The problem is extending them to domains and scales where their assumptions break down:

 **Cyber and information domains** : These don’t obey the spatial logic doctrine assumes. Distance, boundaries, and territory work differently (or don’t apply at all). Network topology matters more than Euclidean geometry.

 **Complex adaptive adversaries** : Insurgencies, terrorist networks, and peer competitors learn, adapt, and evolve. They don’t remain static while you analyze them. Your analysis changes what you’re analyzing.

 **Gray zone operations** : The binary distinction between war and peace—foundational to legal frameworks and doctrinal categories—doesn’t match phenomena that are simultaneously both and neither.

 **Emergence and nonlinearity** : Small interventions produce disproportionate effects; massive inputs yield negligible returns. Tipping points, cascades, and phase transitions don’t fit linear models.

 **Self-referential dynamics** : Military actions produce the conditions they respond to. Counterterrorism generates terrorists. Stabilization operations destabilize. The well dug to help village women gets destroyed by the women it was meant to help.[^31]

### 4.6 Topological Alternatives

Zweibelson proposes topological concepts as alternative metaphoric devices for conceptualizing complex warfare:

 **Möbius strips** : Non-orientable surfaces where you can’t consistently define clockwise/counterclockwise, where what appears to be two sides is actually one continuous surface, where traveling a complete circuit returns you to your starting point reversed. These challenge binary distinctions (war/peace, friend/enemy, inside/outside) that structure military thought.

 **Klein bottles** : Surfaces with no inside or outside—they contain themselves while being contained by what they’re in. These capture self-referential dynamics: how military actions produce their own conditions, how security and threat interpenetrate, how domains contain and are contained by each other.

Zweibelson is careful to specify these are metaphoric devices, not mathematical analogies. The point isn’t to do topology but to use topological intuitions to disrupt the geometric unconscious that shapes military cognition.[^32]

* * *

## Part V: Convergences

### 5.1 Naming the Same Rupture

Despite their different vocabularies and contexts, Baudrillard and Zweibelson are naming the same phenomenon: the breakdown of frameworks inherited from the Enlightenment—frameworks premised on proportionate causality, linear logic, clear boundaries, representational adequacy, and the possibility of external analysis and control.

Both locate this breakdown historically: emerging from the Scientific Revolution, consolidated in the eighteenth and nineteenth centuries, increasingly inadequate in the late twentieth and twenty-first centuries.

Both identify September 11 and the subsequent “war on terror” as revelatory events—not causing the rupture but exposing it. The mismatch between American military power (overwhelming by Euclidean-Newtonian measures) and actual outcomes (strategic failure by almost any measure) reveals that something about the framework itself is wrong.

### 5.2 Self-Referential, Orbital Power

Both thinkers identify a peculiar self-referentiality in contemporary hegemonic power:

Baudrillard: The Twin Towers “could only be measured against themselves.” Hegemonic power is “orbital”—circling in self-enclosed loops, decoupled from territorial or material referents, defining “a seamless (and windowless) hyperspace.”[^33]

Zweibelson: Military doctrine becomes a self-validating system where success means conforming to approved procedures regardless of outcomes. Professional competence means mastery of existing frameworks. Innovation is celebrated rhetorically but punished practically when it violates paradigmatic assumptions.[^34]

Both describe power that has become detached from external reference points—power that relates primarily to itself rather than to the reality it supposedly addresses. This self-referentiality makes traditional critique impossible: you can’t measure the system against reality because the system has absorbed “reality” into itself.

### 5.3 Autoimmune Dynamics

A crucial shared diagnosis is that systems increasingly destroy themselves through their own protective mechanisms:

Baudrillard: “The antibodies turn against the body and cause more damage than the virus.” Security measures produce insecurity. The war on terror generates terror. Responses amplify what they respond to.[^35]

Zweibelson: The well-digging example captures this perfectly—humanitarian intervention destroys what it aimed to preserve. Counterterrorism produces terrorists. Stability operations destabilize. The “self-licking ice cream cone” of military bureaucracy generates the problems that justify its existence.[^36]

This autoimmune logic is incomprehensible within Euclidean-Newtonian frameworks. Defenses are supposed to defend. Actions are supposed to produce their intended effects. Proportionate means should yield proportionate ends. When the framework itself produces the pathologies it claims to address, something fundamental has broken.

### 5.4 Disproportionate Causality

Both emphasize the breakdown of proportional cause-effect relationships:

Baudrillard: September 11 demonstrated “effects with no common measure with the causes and effects of Euclidean space.” Box cutters defeating the world’s most sophisticated military. Poverty of means producing maximal symbolic effect.[^37]

Zweibelson: Complexity theory’s core insight—small causes can produce large effects; large causes can produce negligible effects—remains marginal to doctrine despite rhetorical acknowledgment. Tipping points, cascades, and phase transitions don’t fit the linear models planning processes assume.[^38]

Both argue this isn’t a temporary anomaly to be corrected with better analysis but evidence of a different kind of reality that doesn’t follow Euclidean-Newtonian rules.

### 5.5 The Failure of Direct Opposition

Both diagnose the impossibility of traditional resistance or opposition:

Baudrillard: “Hegemony cannot be fought in the traditional space of relationships of force and violence, because it no longer belongs to that space.” Direct opposition is absorbed: every attack justifies more security, every critique proves systemic openness, every revolution becomes spectacle.[^39]

Zweibelson: Innovation within military institutions is structurally prevented by the same paradigm that calls for it. New ideas must be expressed in existing vocabulary, validated by existing criteria, compatible with existing frameworks—which means they’re not actually new at the level that matters. The institution demands innovation while structurally precluding it.[^40]

Both identify a kind of trap: the tools you would use to change the system are themselves products of the system, shaped by its assumptions, incapable of generating genuine alternatives.

### 5.6 Topological Intuitions

Both reach toward topology as an alternative conceptual resource:

Baudrillard: The Twin Towers’ destruction involved “a subversion of the usual orthogonal space—it is another topology.” Hegemonic power is “Ouroborean”—self-enclosed, self-referential, without exterior. The Klein bottle image of something containing itself while contained by what it’s in.[^41]

Zweibelson: Möbius strips as metaphors for non-orientable warfare where binary distinctions break down. Klein bottles as models for self-referential conflict where inside and outside interpenetrate. Non-orientable surfaces challenge the geometric intuitions embedded in doctrine.[^42]

Both are reaching for mathematical concepts that violate Euclidean assumptions: surfaces where you can’t define consistent orientation, objects that contain themselves, spaces where the usual distinctions (inside/outside, clockwise/counterclockwise) don’t hold.

* * *

## Part VI: Divergences

### 6.1 Methodological Register

The most obvious difference is methodological register:

 **Baudrillard** writes in the tradition of French theory—aphoristic, provocative, deliberately obscure, unconcerned with practical application. His texts resist paraphrase; their difficulty is part of their point. He doesn’t seek to help institutions function better but to reveal that their functioning is itself the problem.

 **Zweibelson** writes for military professionals—detailed, systematic, oriented toward institutional change. He provides figures, explains concepts, offers frameworks. His goal is to improve military thinking, not to abandon the military enterprise.

This difference in register produces different pathologies. Baudrillard’s obscurity can become an excuse for saying nothing actionable—theoretical sophistication substituting for practical engagement. Zweibelson’s institutional orientation can produce recuperation—radical critique domesticated into another planning methodology.

### 6.2 Totalizing vs. Contextual Claims

Baudrillard tends toward totalization: the rupture is complete, the Euclidean world is over, there’s no going back. All current political events are “fake”—theatrical performances of a politics that no longer exists.[^43]

Zweibelson is more contextual: Newtonian approaches may still work at tactical levels involving physical forces in physical space. The problem is extending them to domains and scales where they break down. The critique is selective rather than total.[^44]

This difference has implications for practice. If Baudrillard is right, there’s nothing to do—or rather, nothing that can be done through deliberate action, since deliberate action presupposes the Euclidean framework that has collapsed. If Zweibelson is right, there’s work to be done—educational reform, doctrinal revision, methodological innovation—even if that work is difficult and the obstacles are profound.

### 6.3 The Question of Alternatives

Baudrillard is deliberately vague about alternatives. Specifying an alternative would be a Euclidean move—laying out a program, a method, a framework. He points toward “rogue events,” “radical alterity,” logics that operate by different rules, but these remain gestural. The analysis induces paralysis as easily as new thinking.[^45]

Zweibelson provides concrete alternatives: Möbius strip diagrams, Klein bottle models, complexity-informed planning approaches. He discusses the Israeli Defense Forces’ experiments with postmodern concepts in urban warfare (Kochavi’s “walking through walls”). The alternatives may be underdeveloped, but they exist.[^46]

This difference reflects the methodological register: Baudrillard can afford to be purely critical because he’s not trying to run a military organization. Zweibelson’s institutional position demands that critique be paired with construction.

### 6.4 The Role of Technology and AI

Baudrillard’s framework doesn’t centrally engage questions of artificial intelligence and human-machine teaming—his “machines” are primarily technologies of simulation and media, not computational systems that might process complexity differently.

Zweibelson dedicates significant attention to AI as potentially liberating: if AI systems don’t have to conceptualize war within Newtonian frameworks, human-machine teams might access possibilities that human cognition alone cannot reach. The AI becomes a “paradigm bridge”—operating across multiple frameworks, generating options that violate doctrinal categories, then translating insights back to human operators.[^47]

This is a significant divergence. Baudrillard would likely view AI-augmented military planning as another turn of the hyperreal spiral—simulation producing simulation, the system’s complexity managing the system’s complexity without touching the underlying pathology. Zweibelson sees potential for genuine cognitive liberation.

### 6.5 Ethics and Politics

Baudrillard’s treatment of September 11 as a kind of successful asymmetric operation—finding the “extraterritorial dimension” and delivering “a riposte equal to this new power”—is analytically interesting but ethically troubling. The analysis abstracts from the murder of thousands of people to focus on the symbolic and topological achievement.[^48]

Zweibelson, writing within a military framework, maintains conventional ethical commitments even while critiquing the paradigm. The goal is better military thinking in service of legitimate ends—not the dissolution of military ethics altogether.

This difference reflects their positions: Baudrillard as outside observer, free to analyze without responsibility for outcomes; Zweibelson as insider, bound by professional obligations even while seeking reform.

* * *

## Part VII: What They Miss

### 7.1 The Persistence of the Euclidean-Newtonian

Both thinkers may overstate the rupture. Much of warfare, politics, and daily life continues to operate in roughly Euclidean-Newtonian fashion. Bullets still obey ballistic trajectories. Supply lines still require physical movement through space. Territory still matters in ways that maps can capture.

The non-Euclidean/non-Newtonian may be an overlay or intrusion rather than a total replacement—certain phenomena operate by different rules, but these coexist with phenomena that follow classical logics. The challenge may be discerning which framework applies when, rather than wholesale paradigm replacement.

### 7.2 The Problem of Alternative Specification

“Non-Euclidean” and “non-Newtonian” tell us what the new condition isn’t—but not clearly what it is. This may be appropriate (specifying rules would be Euclidean/Newtonian), but it limits operational utility. Military organizations need frameworks that enable coordinated action among thousands of people. Gestures toward complexity and non-linearity don’t provide this.

### 7.3 The Scalability Problem

Both critiques may work better for small, elite organizations (SOF, design cells, terrorist networks) than for large conventional forces. Complexity-embracing approaches might suit twelve-person teams but resist scaling to divisions and corps. The Euclidean-Newtonian framework persists partly because it enables coordination at scale—an alternative would need to enable equivalent coordination or explain why coordination at that scale is no longer necessary.

### 7.4 The Evaluation Problem

If paradigms are incommensurable, how do we know the alternatives are better? Both thinkers appeal to intuitions about “complexity matching complex reality,” but this could be circular. The non-Euclidean/non-Newtonian might be more aesthetically appealing without being more practically effective.

### 7.5 Material Realities

Both analyses operate primarily at the level of concepts, symbols, and representations. But military operations involve material realities—bodies, weapons, terrain, logistics—that constrain what concepts can do. You can think non-Euclideanlly all you want; the rocket-propelled grenade still follows a parabolic trajectory.

The question is whether the material and the symbolic can be analytically separated as cleanly as either thinker sometimes implies.

* * *

## Part VIII: Synthesis and Implications

### 8.1 The Joint Diagnosis

Reading Baudrillard and Zweibelson together, a joint diagnosis emerges:

Western strategic thought operates within a paradigm inherited from the Scientific Revolution—a paradigm characterized by Euclidean geometry and Newtonian physics, extended metaphorically to domains (politics, warfare, society) where their assumptions don’t necessarily hold. This paradigm assumes:

  * Proportionate causality

  * Linear, traceable chains from cause to effect

  * Clear boundaries between categories

  * The possibility of external analysis and control

  * Representational adequacy of models to reality

  * The effectiveness of direct opposition




Contemporary phenomena increasingly violate these assumptions:

  * Disproportionate effects (small causes → large effects; large causes → negligible effects)

  * Circular, self-referential causality

  * Boundaries that don’t hold (war/peace, inside/outside, friend/enemy)

  * Analysis that changes what it analyzes

  * Representations that constitute rather than mirror

  * Opposition that feeds rather than defeats




The result is systematic failure: military operations that achieve tactical success while producing strategic failure; security measures that generate insecurity; counterterrorism that produces terrorism; institutions that call for innovation while structurally preventing it.

### 8.2 Why This Matters

This diagnosis matters because it identifies the level at which the problem exists. If the failures of American military power since 2001 stem from insufficient resources, poor leadership, or tactical errors, the solutions are more resources, better leadership, and tactical improvement. If they stem from paradigmatic inadequacy, these solutions will fail—they’re applying the wrong tools to the wrong problem.

The paradigm diagnosis suggests that:

  * Better Euclidean-Newtonian analysis won’t help because the framework itself is the problem

  * More data, more precision, and more modeling will produce more sophisticated failures

  * Direct opposition to hegemonic power (whether by insurgents or internal reformers) will be absorbed

  * The autoimmune dynamics will continue until the framework changes




This is a genuinely difficult situation. Paradigm shift is possible—Baudrillard’s and Zweibelson’s analyses both depend on it—but paradigms don’t shift by deliberate choice. They shift when accumulated anomalies make the existing framework untenable and an alternative becomes available. Neither condition is sufficient alone.

### 8.3 Toward Non-Euclidean/Non-Newtonian Practice?

What would it mean to think and act non-Euclideanlly/non-Newtonianly? Both thinkers offer hints:

 **Baudrillard’s hints:**

  * Symbolic action over material force

  * Implosion over explosion

  * Turning the system’s logic against itself

  * Finding extraterritorial dimensions

  * Operating through radical alterity rather than direct opposition




 **Zweibelson’s hints:**

  * Topological thinking (connectivity over distance, holes and boundaries over solid regions)

  * Embracing emergence and self-organization rather than trying to eliminate them

  * Multiple paradigms available for selection rather than a single dominant framework

  * Human-AI teaming that liberates cognition from human paradigmatic limits

  * Institutional spaces protected from paradigmatic enforcement




Neither provides a complete program—and providing one might be self-defeating. But both suggest directions:

 **At the conceptual level:** Developing alternative metaphoric devices (Möbius strips, Klein bottles, networks, ecologies) that encode different assumptions about space, causality, and boundaries.

 **At the institutional level:** Creating spaces where paradigm-violating thinking is possible—protected from the institutional pressures that enforce conformity.

 **At the educational level:** Teaching people to recognize that they’re operating within a paradigm, to see alternatives, to shift frames deliberately when situations warrant.

 **At the technological level:** Developing AI systems that aren’t constrained to human paradigms, that can generate options and recognize patterns that human cognition can’t access.

### 8.4 The Deeper Question

Both Baudrillard and Zweibelson raise a question that goes beyond military doctrine: is Western modernity’s conceptual infrastructure—the inheritance of the Enlightenment, the Scientific Revolution, the Euclidean-Newtonian synthesis—still adequate to the world it has created?

This isn’t anti-Enlightenment obscurantism. Both thinkers are themselves products of the Enlightenment tradition, using its tools (reason, analysis, critique) to question its limits. The question isn’t whether to abandon reason but whether the particular form of reason that achieved dominance—mathematical, mechanistic, reductionist—can comprehend phenomena that don’t fit its assumptions.

The emergence of non-Euclidean geometries and non-Newtonian physics in the nineteenth and twentieth centuries already answered this question within mathematics and physics: the Euclidean-Newtonian framework is a special case, valid under specific conditions, embedded in a larger space of possibilities. What Baudrillard and Zweibelson suggest is that social, political, and strategic reality may have moved into regions where the special case no longer applies.

* * *

## Part IX: Critical Assessment

### 9.1 Strengths of the Convergent Critique

 **Diagnostic power** : Both thinkers effectively identify patterns that existing frameworks struggle to explain—the persistence of strategic failure despite tactical success, the autoimmune dynamics of security measures, the absorption of opposition. Whether or not readers accept the proposed alternatives, the diagnosis has force.

 **Historical depth** : Tracing current frameworks to their Enlightenment origins denaturalizes them. What seems like “common sense” or “how reality works” becomes one historically contingent framework among possible others. This is a necessary first step toward change.

 **Interdisciplinary resources** : Drawing on topology, complexity science, postmodern philosophy, and social paradigm theory expands the conceptual vocabulary available for thinking about strategic problems. Even if specific proposals fail, the expansion of vocabulary is valuable.

 **Practical resonance** : The critiques resonate with practitioners’ experience. Military officers recognize the gap between doctrine’s confidence and operational reality. Analysts recognize that their models miss something important. The critiques name something that many sense but can’t articulate.

### 9.2 Weaknesses and Limitations

 **Vagueness of alternatives** : Both critiques are clearer about what’s wrong than about what to do instead. “Non-Euclidean” and “non-Newtonian” define negatively; positive characterization remains elusive. This may be inherent to the project, but it limits practical utility.

 **Risk of paralysis** : If the problem is paradigmatic and paradigms can’t be shifted by deliberate choice, what’s to be done? Both analyses could induce paralysis—sophisticated despair disguised as theoretical sophistication.

 **Potential for obscurantism** : “Complexity” and “non-linearity” can become excuses for abandoning rigor. “We can’t predict because the system is complex” might be true or might be an excuse for not trying. The critique of Euclidean-Newtonian thinking could become a license for confused thinking.

 **Neglect of material realities** : Both analyses operate primarily at the conceptual level. But military operations involve bodies, weapons, logistics, and physics. You can reconceptualize all you want; the ammunition still needs to get from point A to point B.

 **Scalability problem** : The alternatives may work for small, elite organizations but resist scaling. Large militaries need shared frameworks for coordination. If non-Euclidean/non-Newtonian frameworks can’t be shared at scale, they’re not viable replacements for what exists.

### 9.3 The Recuperation Risk

A final risk: paradigms are good at absorbing their critics. “Complexity” has already been recuperated into military doctrine—mentioned rhetorically while ignored practically. “Design thinking” has been institutionalized without dislodging the frameworks it was supposed to challenge.

Baudrillard’s and Zweibelson’s critiques could suffer the same fate: acknowledged, cited, absorbed into the discourse without changing anything fundamental. The institution could add “non-linear thinking” to its checklist while continuing to operate Newtonianly. The vocabulary changes; the paradigm persists.

Whether this can be prevented—and whether preventing it requires something other than more sophisticated critique—is an open question.

* * *

## Conclusion: The Unfinished Task

Jean Baudrillard and Ben Zweibelson, approaching from radically different positions, converge on a common diagnosis: the conceptual infrastructure of Western strategic thought—what might be called the Euclidean-Newtonian compound—is increasingly inadequate to the phenomena it addresses. Contemporary conflict, power, and security operate according to logics that this framework can’t comprehend: disproportionate causality, self-referential dynamics, autoimmune pathologies, the collapse of organizing binaries.

Both reach toward topology as an alternative resource—non-orientable surfaces, self-containing objects, spaces without clear inside/outside—as ways of encoding different intuitions about how reality might work. Neither provides a complete alternative framework, and both acknowledge that providing one might be self-defeating: the alternative to a paradigm can’t be fully articulated within the paradigm it’s meant to replace.

The task they identify is less the construction of a new framework than the creation of conditions under which new frameworks might emerge: educational reform that teaches paradigm-recognition, institutional spaces protected from paradigm-enforcement, human-AI collaborations that might access cognitive possibilities beyond human limits, conceptual experimentation with metaphoric devices encoding different assumptions.

Whether this task can be accomplished—whether institutions designed around Euclidean-Newtonian assumptions can transform themselves into something capable of operating non-Euclideanlly/non-Newtonianly—remains uncertain. Paradigms don’t shift by deliberate choice; they shift when accumulated anomalies make the existing framework untenable and an alternative becomes available. The anomalies are accumulating. The alternatives remain gestural.

What Baudrillard and Zweibelson provide, read together, is a sophisticated articulation of the problem and a direction of travel. The destination remains unclear. But in a situation where the dominant frameworks systematically misrepresent reality, the first step is recognizing that the frameworks themselves—not just their application—are the problem.

That recognition is what both thinkers, in their different voices and registers, provide.

* * *

## Notes

[^1]: Jean Baudrillard, _Simulacra and Simulation_ , trans. Sheila Faria Glaser (Ann Arbor: University of Michigan Press, 1994); Jean Baudrillard, _The Gulf War Did Not Take Place_ , trans. Paul Patton (Bloomington: Indiana University Press, 1995).

[^2]: Jean Baudrillard, _The Agony of Power_ , trans. Ames Hodges (Los Angeles: Semiotext(e), 2010), 88-94.

[^3]: Ben Zweibelson, _Understanding the Military Design Movement: War, Change and Innovation_ (New York: Routledge, 2023), 1-25.

[^4]: Christopher Paparone, _The Sociology of Military Science: Prospects for Postinstitutional Military Design_ (New York: Bloomsbury Academic Publishing, 2013), 1-20.

[^5]: Ben Zweibelson, “Breaking the Newtonian Fetish: Conceptualizing War Differently for a Changing World,” _Journal of Advanced Military Studies_ 15, no. 1 (2023); Ben Zweibelson, _Beyond the Pale: Designing Military Decision-Making Anew_ (Maxwell Air Force Base, AL: Air University Press, 2023).

[^6]: Euclid, _The Thirteen Books of the Elements_ , trans. Thomas L. Heath, 2nd ed. (New York: Dover, 1956).

[^7]: Isaac Newton, _The Principia: Mathematical Principles of Natural Philosophy_ , trans. I. Bernard Cohen and Anne Whitman (Berkeley: University of California Press, 1999).

[^8]: Immanuel Kant, _Critique of Pure Reason_ , trans. Paul Guyer and Allen W. Wood (Cambridge: Cambridge University Press, 1998); Antoine-Henri Jomini, _The Art of War_ , trans. G.H. Mendell and W.P. Craighill (Westport, CT: Greenwood Press, 1971).

[^9]: Zweibelson, “Breaking the Newtonian Fetish”; _Joint Planning_ , Joint Publication 5-0 (Washington, DC: Department of Defense, 2020).

[^10]: Baudrillard, _The Agony of Power_ , 7-15.

[^11]: Baudrillard, _The Agony of Power_ , 88-89.

[^12]: Baudrillard, _The Agony of Power_ , 88.

[^13]: Baudrillard, _The Agony of Power_ , 91.

[^14]: Baudrillard, _The Agony of Power_ , 92.

[^15]: Baudrillard, _The Agony of Power_ , 90.

[^16]: Baudrillard, _The Agony of Power_ , 97-98.

[^17]: Baudrillard, _The Agony of Power_ , 93.

[^18]: Baudrillard, _The Agony of Power_ , 91.

[^19]: Baudrillard, _The Agony of Power_ , 91-92.

[^20]: Baudrillard, _The Agony of Power_ , 92.

[^21]: Baudrillard, _The Agony of Power_ , 92.

[^22]: Baudrillard, _The Agony of Power_ , 89.

[^23]: Zweibelson, “Breaking the Newtonian Fetish,” 1-5.

[^24]: Gibson Burrell and Gareth Morgan, _Sociological Paradigms and Organisational Analysis: Elements of the Sociology of Corporate Life_ (Portsmouth, NH: Heinemann, 1979); Zweibelson, _Beyond the Pale_ , 52-68.

[^25]: Zweibelson, “Breaking the Newtonian Fetish,” 8-12.

[^26]: Zweibelson, “Breaking the Newtonian Fetish,” 15-25; Haridimos Tsoukas, _Complex Knowledge: Studies in Organizational Epistemology_ (New York: Oxford University Press, 2005), 213-216.

[^27]: Sebastien Le Prestre de Vauban, _The New Method of Fortification_ (London: S. and E. Ballard, 1722).

[^28]: John Shy, “Jomini,” in _Makers of Modern Strategy_ , ed. Peter Paret (Princeton, NJ: Princeton University Press, 1986), 144-146.

[^29]: Peter Paret, _Clausewitz and the State: The Man, His Theories, and His Times_ (Princeton, NJ: Princeton University Press, 1985), 156-197.

[^30]: J.F.C. Fuller, _The Foundations of the Science of War_ (London: Hutchinson, 1925), 38-45.

[^31]: Zweibelson, “Breaking the Newtonian Fetish,” 25-35; Ann Jones, “Woman to Woman in Afghanistan: Female Engagement Teams Join the Counterinsurgency,” _Nation_ , 27 October 2010.

[^32]: Zweibelson, “Breaking the Newtonian Fetish,” 35-50.

[^33]: Baudrillard, _The Agony of Power_ , 91-92.

[^34]: Zweibelson, “Breaking the Newtonian Fetish,” 10-15.

[^35]: Baudrillard, _The Agony of Power_ , 97-98.

[^36]: Zweibelson, “Breaking the Newtonian Fetish,” 30-32.

[^37]: Baudrillard, _The Agony of Power_ , 93.

[^38]: Zweibelson, “Breaking the Newtonian Fetish,” 25-30.

[^39]: Baudrillard, _The Agony of Power_ , 92.

[^40]: Zweibelson, “Breaking the Newtonian Fetish,” 12-15.

[^41]: Baudrillard, _The Agony of Power_ , 91.

[^42]: Zweibelson, “Breaking the Newtonian Fetish,” 35-50.

[^43]: Baudrillard, _The Agony of Power_ , 88-89.

[^44]: Zweibelson, “Breaking the Newtonian Fetish,” 50-55.

[^45]: Baudrillard, _The Agony of Power_ , 89-90.

[^46]: Zweibelson, “Breaking the Newtonian Fetish,” 55-60; Eyal Weizman, “Lethal Theory,” _Log_ , no. 7 (Winter/Spring 2006): 53-77.

[^47]: Zweibelson, “Breaking the Newtonian Fetish,” 60-65.

[^48]: Baudrillard, _The Agony of Power_ , 92-94.

* * *

## Bibliography

Baudrillard, Jean. _The Agony of Power_. Translated by Ames Hodges. Los Angeles: Semiotext(e), 2010.

———. _The Gulf War Did Not Take Place_. Translated by Paul Patton. Bloomington: Indiana University Press, 1995.

———. _Simulacra and Simulation_. Translated by Sheila Faria Glaser. Ann Arbor: University of Michigan Press, 1994.

Burrell, Gibson, and Gareth Morgan. _Sociological Paradigms and Organisational Analysis: Elements of the Sociology of Corporate Life_. Portsmouth, NH: Heinemann, 1979.

Euclid. _The Thirteen Books of the Elements_. Translated by Thomas L. Heath. 2nd ed. New York: Dover, 1956.

Fuller, J.F.C. _The Foundations of the Science of War_. London: Hutchinson, 1925.

Jomini, Antoine-Henri. _The Art of War_. Translated by G.H. Mendell and W.P. Craighill. Westport, CT: Greenwood Press, 1971.

 _Joint Planning_. Joint Publication 5-0. Washington, DC: Department of Defense, 2020.

Kant, Immanuel. _Critique of Pure Reason_. Translated by Paul Guyer and Allen W. Wood. Cambridge: Cambridge University Press, 1998.

Newton, Isaac. _The Principia: Mathematical Principles of Natural Philosophy_. Translated by I. Bernard Cohen and Anne Whitman. Berkeley: University of California Press, 1999.

Paparone, Christopher. _The Sociology of Military Science: Prospects for Postinstitutional Military Design_. New York: Bloomsbury Academic Publishing, 2013.

Paret, Peter. _Clausewitz and the State: The Man, His Theories, and His Times_. Princeton, NJ: Princeton University Press, 1985.

———, ed. _Makers of Modern Strategy: From Machiavelli to the Nuclear Age_. Princeton, NJ: Princeton University Press, 1986.

Tsoukas, Haridimos. _Complex Knowledge: Studies in Organizational Epistemology_. New York: Oxford University Press, 2005.

Vauban, Sebastien Le Prestre de. _The New Method of Fortification_. London: S. and E. Ballard, 1722.

Weizman, Eyal. “Lethal Theory.” _Log_ , no. 7 (Winter/Spring 2006): 53-77.

Zweibelson, Ben. _Beyond the Pale: Designing Military Decision-Making Anew_. Maxwell Air Force Base, AL: Air University Press, 2023.

———. “Breaking the Newtonian Fetish: Conceptualizing War Differently for a Changing World.” _Journal of Advanced Military Studies_ 15, no. 1 (2023).

———. _Understanding the Military Design Movement: War, Change and Innovation_. New York: Routledge, 2023.

---
title: Somewhere Only We Know
subtitle: True Love Ways (Seen Better Days)
author: Adam Wadley
publication: Experimental Unit
date: July 21, 2025
---

# Somewhere Only We Know
Thread Theme:

# Only You

The things that only you can do.

It has to do with the fact that only you are you. You personally have particular relationships with people, will think of and feel particular things at a particular time.

I’ve been learning more about (the idea of) the Druze, since they have been in the news. Here’s some from the Wikipedia article on their book _[Epistles of Wisdom](https://en.wikipedia.org/wiki/Epistles_of_Wisdom)_ :

> The epistles contain philosophical discourses about [Neoplatonic](https://en.wikipedia.org/wiki/Neoplatonic) and [Gnostic](https://en.wikipedia.org/wiki/Gnostic) subjects, [Ptolemaic cosmology](https://en.wikipedia.org/wiki/Ptolemaic_cosmology), Arabic paraphrases of the philosophies of [Farabi](https://en.wikipedia.org/wiki/Farabi), [Plotinus](https://en.wikipedia.org/wiki/Plotinus) and [Proclus](https://en.wikipedia.org/wiki/Proclus), writings on the [Universal Soul](https://en.wikipedia.org/wiki/Anima_mundi) along with several [polemic](https://en.wikipedia.org/wiki/Polemic) epistles concerning other faiths and philosophies that were present during that time and towards individuals who were considered renegades or those who tried to distort and tarnish the reputation of the faith and its teachings such as the "Answering the [Nusayri](https://en.wikipedia.org/wiki/Nusayri)" epistle and the fifth volume of the Epistles. Most of the Epistles are written in a post-classical language, often showing similarities to Arab [Christian](https://en.wikipedia.org/wiki/Christians) authors.[[12]](https://en.wikipedia.org/wiki/Epistles_of_Wisdom#cite_note-Bar-Asher1Kootstra2002-12)[[13]](https://en.wikipedia.org/wiki/Epistles_of_Wisdom#cite_note-13)
> 
> The texts provide insight into Druze beliefs about the incorporation of the [Universal Intellect](https://en.wikipedia.org/wiki/Nous) and the [soul of the world](https://en.wikipedia.org/wiki/Anima_mundi) in 11th century Egypt, when the deity showed itself to men through [Fatimid](https://en.wikipedia.org/wiki/Fatimid) [Caliph](https://en.wikipedia.org/wiki/Caliph) al-Hakim and his doctrines. These display a notable form of Arabic Neoplatonism blended with [Ismailism](https://en.wikipedia.org/wiki/Ismailism) and adopted [Christian elements](https://en.wikipedia.org/wiki/Christianity) of great interest for the philosophy and [history of religions](https://en.wikipedia.org/wiki/History_of_religions).

[![Lebanese Druze - Wikipedia](https://substackcdn.com/image/fetch/$s_!LnER!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa1b2ea12-b35a-4847-9298-fefd05fd7242_1200x801.png)](https://substackcdn.com/image/fetch/$s_!LnER!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa1b2ea12-b35a-4847-9298-fefd05fd7242_1200x801.png)

 _do not adjust your television set._

Druze lore seems to circle around the concept of [Tawhid](https://en.wikipedia.org/wiki/Tawhid), or the unity of Allah, God, the Absolute. “The great mystery” works here, because apparently the Druze are really into how the Absolute is ineffable.

And the end-times story is a fantasy that the really good ones will merge fully with this absolute at the end of time, while the wicked ones will be left in a state of separation.

For me, the stakes of this are: if the overriding theme is oneness, why is anyone being left away?

[![Is Hell Separation From God?](https://substackcdn.com/image/fetch/$s_!92VG!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F869ecb8d-4791-4e33-b33b-2bcf999eef7a_1280x720.jpeg)](https://substackcdn.com/image/fetch/$s_!92VG!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F869ecb8d-4791-4e33-b33b-2bcf999eef7a_1280x720.jpeg)

The idea of “separation” from some primordial deity, or “what makes up everything,” is exceedingly questionable. People say things like, “Well, if you want to be separate from God, it would be violent for God to make you reconcile, so you’re really being given what you want.”

I would offer instead at one is always “inside.” It’s not a question of actually falling out of favor or some ontological status. If one “wants” to experience the notion of “being separate from God,” then one requires frame categories to even make that intelligible.

Going on, with something like [apokatastasis](https://en.wikipedia.org/wiki/Apokatastasis) and the common task on the table, the question is about what is it that “Only You” can do in regard to this greatest story, the overall arc of temporal events?

[![Leo Tolstoy against Nikolai Fyodorov.](https://substackcdn.com/image/fetch/$s_!VItu!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F06a79d1d-7bc5-43fd-ba22-1040bc71b956_518x550.jpeg)](https://substackcdn.com/image/fetch/$s_!VItu!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F06a79d1d-7bc5-43fd-ba22-1040bc71b956_518x550.jpeg)

[Common task refresher:](https://en.wikipedia.org/wiki/Nikolai_Fyodorov_\(philosopher\))

> Fyodorov gave science a place next to _art_ and religion in the Common Task of uniting humanity, including the dead, who must in the future be reunited with the living. He held that "we can become immortal and godlike through rational efforts and that our moral obligation is to create a heaven to be shared by all who ever lived." 

I’m going to foreground a big issue with this idea: if you’re going to resurrect everyone that ever lived, then it leads to a situation where you can bargain that people dying is OK, since they will all be resurrected anyway.

It’s a bit similar to some kind of “effective altruism,” where people are concerned to help the population expand in the future, but plenty of people can die _now_.

The question is really what would help many people survive. When it comes to UFOs, there will be discussion that “aliens” would find that “war” was such a backward way to settle disputes.

So, what is the way around that issue? Involving the appreciation, perhaps, that war and peace are not so distinct?

A daring parallel: war goes with hell, this idea of separation from “the good life,” from God. Peace and heaven stand together as this ideals that seem unattainable, especially not for all. Peace can come when our “enemies” are dead.

[![](https://substackcdn.com/image/fetch/$s_!s5Lp!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F447221fb-9eb7-464a-85ae-200548331ece_1176x817.png)](https://substackcdn.com/image/fetch/$s_!s5Lp!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F447221fb-9eb7-464a-85ae-200548331ece_1176x817.png)

I noticed Grimes has a Substack, apparently? [That’s where Chaos Manual was published](https://substack.com/home/post/p-117991345). 

If there are things only you can do, what can only the AI version of you do? Do you think Boucher posts things under the GrimesAI Twitter directly, to give plausible deniability for anything people wouldn’t like?

Even GrimesAI has been dormant since late last year.

[![](https://substackcdn.com/image/fetch/$s_!sYV2!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa99bab8f-c7a8-48a8-8887-bcb391c57d41_790x863.png)](https://substackcdn.com/image/fetch/$s_!sYV2!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa99bab8f-c7a8-48a8-8887-bcb391c57d41_790x863.png)

Now, this key frame from _Chaos Manual_ :

[![](https://substackcdn.com/image/fetch/$s_!0gUb!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcfa23f58-8b27-4b65-b58d-476719d5ba58_793x452.png)](https://substackcdn.com/image/fetch/$s_!0gUb!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcfa23f58-8b27-4b65-b58d-476719d5ba58_793x452.png)

Is this in contradistinction to the Druze? Maybe not. Maybe a set perspective can have as its condition of enjoyment that it’s not going to be shared with everyone. Yet what if there could be another perspective, which can enjoy itself and not mind that others see it as “excluded”?

Could such a balance of stories exist? Or do people want to make their ARG “be real,” at the cost of everyone else’s life, and more important, narrative dignity?

I would disagree with Boucher’s statement of the issue as “civilizational” longevity and flourishing, because it seems a bit presumptuous to just call whatever one has in mind a “civilization.” What would Obi-Wan think?

[![So Uncivilized GIFs | Tenor](https://substackcdn.com/image/fetch/$s_!67vJ!,w_1456,c_limit,f_auto,q_auto:good,fl_lossy/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4a9e28a3-ffb3-4797-8f95-ebc6b1c9d4d3_319x200.gif)](https://substackcdn.com/image/fetch/$s_!67vJ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4a9e28a3-ffb3-4797-8f95-ebc6b1c9d4d3_319x200.gif)

The whole point is that we are at something like the position where we can have a civilization worthy of the name for the first time, or we can all die.

It is a good time to wonder whether it is the end of days, because the profusion of technology is quickly making ways of the past obsolete.

It’s a simple question, how many people will survive? And is that the only stake? Or maybe the real influence operation is to try and make sure that anyone who survives in fact completes the Common Task.

This would seem to open up this problem of prestige. The people who “never die” (see: Grimes lyrics to “We Appreciate Power,” Trump's description of Epstein as someone who never dies) would be the ones who “get to” bring everyone else back to life. What if their intentions aren’t even good? They could mess it up and enslave everyone forever!

This is where it is powerful to be discussing something like logos, some cosmological principle, because it starts to open up questions that can bring freedom from disturbance regardless of what anyone else might do.

[![Turned into a Black Penis: Sexistence, Nihilism, and Substraction |  Professor Calvin Warren](https://substackcdn.com/image/fetch/$s_!RHdN!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdc2c398e-907d-407d-b5a6-5abf71549502_640x480.jpeg)](https://substackcdn.com/image/fetch/$s_!RHdN!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdc2c398e-907d-407d-b5a6-5abf71549502_640x480.jpeg)

Afropessimism has a view onto such a perspective, although it’s not always taken up. You can see the discussion of [“white hyperreality”](https://trueleappress.wordpress.com/2017/10/12/on-the-prospect-of-weaponized-death/) here.

What’s offered is another parallel: on one side, “whiteness” or whatever order of “being” is not really able to set itself up. It draws up a fantasy, but it is not really able to institute its fantasy as a “real” state of affairs. It is not even able to set up its fantasy as a state of affairs which can remain forever.

Similarly to this question of the end of time and everyone (except the wicked!) sort of Voltron-ing it up with the absolute. It’s not really a question of whether “good” people will survive to do the common task. Whatever course is taken, it all goes to the same place in the end.

The place you’re going to be put into.

Yes, everyone else is going to do it to you. But at the same time, you will do it to everyone else.

It might be said that it’s questionable to mark some petty thing with this grand sense of purpose. Everything we do is helping apokatastasis happen. No questioning anything!

And yet, there are different ways to get there.

There’s the easy way, and there’s the hard way.

There’s the art school, and there’s the military academy.

It’s all fine, except that at a certain point the music must be faced. Secrets cannot be the logic of a “world” to come, a “civilization” to come. These things are still _aspirational_. The cost to getting there will be high in terms of “losing face.”

Imagine the car-crash of all the stories which are aching for their satisfying conclusion. All the ways people have been hoping that it would go, all those hopes that will have to be dashed.

What a task! To make people say _This Is So Much Better Than What I Expected_.

This will be an art operational beyond _Chaos Manual_ , beyond Afropessimism, beyond Systemic Operational Design. These things are still insisting too much on their terms.

Haven’t you heard?

It’s a vibe.

And it’ll be humming through it all until no one can forget.

Until being “good” is the easiest thing ever.

It’s not an “imposition” because it’s coming from inside you.

In the end, the hardest thing to accept might be how quickly the endgame unfolds.

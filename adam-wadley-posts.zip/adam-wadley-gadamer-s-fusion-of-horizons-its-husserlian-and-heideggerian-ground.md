---
title: 'Gadamer’s “fusion of horizons”: its Husserlian and Heideggerian ground'
subtitle: '"But what is it *like* to hold your opa''s dog tags outside T2COM?"'
author: Adam Wadley
publication: Experimental Unit
date: November 28, 2025
---

# Gadamer’s “fusion of horizons”: its Husserlian and Heideggerian ground
[![](https://substackcdn.com/image/fetch/$s_!AHsi!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2b452059-964e-4b25-9435-83bd7d921ec6_1406x789.png)](https://substackcdn.com/image/fetch/$s_!AHsi!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2b452059-964e-4b25-9435-83bd7d921ec6_1406x789.png)

Below I give a single, integrated exposition: (1) how the key technical moves in Husserl’s phenomenology—especially horizon-intentionality and the structure of intentional correlation—provide the conceptual raw material; (2) how Heidegger’s existential analytics (Dasein’s fore-structures, historicity, and the ontological primacy of understanding and language) recast those resources into an ontological register; and (3) how Gadamer combines, transforms, and displaces both traditions to produce the doctrine of the **fusion of horizons** (Horizontverschmelzung). I foreground the precise conceptual loci of continuity and departure and end with the hermeneutical payoff: why Gadamer’s move neither collapses into relativism nor resurrects a Husserlian transcendental spectator.

* * *

## 1\. What Husserl supplies: horizonality as the constitutive background of givenness

Two Husserlian points must be taken as starting premises.

  1.  **Intentionality with horizons.** For Husserl every intentional act presents an intentional correlate together with an implicit field or _horizon_ —that is, anticipations, possible variations, and co-implicated sense that surround any perceptual or noetic content. An object is not an isolated datum but an intentional nexus whose meaning extends beyond the presently given via inner and outer horizons. This horizon-structure is constitutive of the very possibility of meaning for Husserl: the “what” of a presentation is inseparable from its “around” (the expectable, the background) that makes the “what” intelligible. [Stanford Encyclopedia of Philosophy+1](https://plato.stanford.edu/entries/husserl/?utm_source=chatgpt.com)

  2.  **Intersubjectivity and the lifeworld.** Late Husserl radicalized this by showing how horizons are already tied into a shared lifeworld and intersubjective constitution: horizons are not merely idiosyncratic addenda but are embedded in culturally and historically sedimented meanings that structure possible experience and interpretation. Husserl’s apparatus thus gives us a theory of the _structural indispensability_ of background meanings for any act of seeing, judging, or saying. [Stanford Encyclopedia of Philosophy+1](https://plato.stanford.edu/entries/husserl/?utm_source=chatgpt.com)




 **Import for Gadamer:** Husserl supplies the technical vocabulary— _horizon_ , _horizon-intentionality_ , _anticipatory sense_ —and the conceptual claim that any meaningful presentation is co-constituted by what lies beyond its given edges. Gadamer will keep the central insight (meaning depends on a surrounding field) while rejecting Husserl’s methodological project of transcendental reduction and bracketing as the proper path to secure apodictic foundations. [UCD Research Repository](https://researchrepository.ucd.ie/rest/bitstreams/14215/retrieve?utm_source=chatgpt.com)

* * *

## 2\. What Heidegger supplies: an ontological recasting of horizon and understanding

Heidegger’s Being-and-Time supplies three decisive transformations of the Husserlian resources.

  1.  **Understanding as an existentiale (ontological priority).** For Heidegger, “understanding” (Verstehen) is not a cognitive operation appended to a pre-existing subject; it is an existential mode of Dasein—the way Dasein is _already_ in relation to the world. Understanding discloses significance by projecting possibilities; it is constitutive of Being-in-the-world rather than an epistemic attitude toward a self-same world. This moves the problem from epistemology into ontology. [Cambridge University Press & Assessment](https://www.cambridge.org/core/books/cambridge-companion-to-gadamer/gadamers-relation-to-heidegger-and-to-phenomenology/073FF6A5F2FAF6C5DE5FD5A534125836?utm_source=chatgpt.com)

  2.  **Fore-structures: fore-having, fore-sight, fore-conception.** Heidegger analyzes Dasein’s pre-structuring of intelligibility in terms of fore-having (what one already has at hand), fore-sight (anticipatory grasp), and fore-conception (pre-understandings). These are not defeatable biases but the ontological conditions that make any interpretation possible: one always approaches a phenomenon from some fore-structure. In Heidegger’s vocabulary the “background” that Husserl described becomes a set of existential fore-structures binding Dasein’s openness to meaning. [Cambridge University Press & Assessment](https://www.cambridge.org/core/books/cambridge-companion-to-gadamer/gadamers-relation-to-heidegger-and-to-phenomenology/073FF6A5F2FAF6C5DE5FD5A534125836?utm_source=chatgpt.com)

  3.  **Historicity and language.** Heidegger insists Dasein is historical (Geschichtlichkeit): its possibilities and intelligibilities are sedimented in traditions and pre-understandings; moreover, language is the house of Being—the medium through which horizons are disclosed. That is, tradition and language are not external contexts but the condition of possibility of intelligibility itself. [Cambridge University Press & Assessment](https://www.cambridge.org/core/books/cambridge-companion-to-gadamer/gadamers-relation-to-heidegger-and-to-phenomenology/073FF6A5F2FAF6C5DE5FD5A534125836?utm_source=chatgpt.com)




 **Import for Gadamer:** Heidegger converts Husserl’s phenomenological horizon into an ontological account: horizons are not merely correlates of intentional acts but the existential, historical structures through which Dasein understands at all. Gadamer will appropriate this ontological priority of understanding and the emphasis on historicity and language as constitutive of sense. [Cambridge University Press & Assessment](https://www.cambridge.org/core/books/cambridge-companion-to-gadamer/gadamers-relation-to-heidegger-and-to-phenomenology/073FF6A5F2FAF6C5DE5FD5A534125836?utm_source=chatgpt.com)

* * *

## 3\. Gadamer’s syntheses and departures: from structures to dialogical fusion

With Husserl and Heidegger in place, Gadamer does three interrelated things that constitute the doctrine of horizon fusion.

  1.  **From individual horizon to dialogical meeting.** Gadamer inherits Husserl’s and Heidegger’s insight that every understanding is horizon-bound, but he relocates the primary site of meaning-production into _dialogue_ —not merely interpersonal exchange as a psychological fact, but dialogical language as the formative event in which horizons meet, confront, and transform one another. The “fusion” is not a symmetrical averaging of private viewpoints but a historically and linguistically mediated event by which interlocutors’ fore-understandings are revised and a new, shared intelligibility emerges. [Stanford Encyclopedia of Philosophy+1](https://plato.stanford.edu/archives/fall2018/entries/gadamer/?utm_source=chatgpt.com)

  2.  **Prejudice (Vorurteil) and tradition as conditions, not defects.** Opposed to the Enlightenment ideal of prejudice-free objectivity, Gadamer insists that prejudices—understood as historically transmitted, pre-reflective understandings—are the _necessary_ starting points of understanding. Where Husserl tried to bracket presuppositions, Gadamer argues that it is only by recognizing and testing our prejudices dialogically that understanding advances. Tradition, likewise, is a living horizon that enables and constrains interpretation; to engage a text or otherness is always already to be “within” a tradition. [Stanford Encyclopedia of Philosophy+1](https://plato.stanford.edu/archives/fall2018/entries/gadamer/?utm_source=chatgpt.com)

  3.  **Language as the medium of horizon-fusion.** Gadamer radicalizes Heidegger in stressing the primacy of language: horizons fuse not as private mental states but in the medium of speech and textual interpretation. Understanding is a linguistic event in which question and answer, address and response, reshape the participants’ horizons. Thus fusion is an _accomplishment_ —a historically mediated enlargement of understanding effected through communicative practice. [Stanford Encyclopedia of Philosophy+1](https://plato.stanford.edu/archives/fall2018/entries/gadamer/?utm_source=chatgpt.com)




 **Key formal point:** the fusion of horizons is not a metaphysical merging of two identical wholes nor merely the absorption of the other into the same. It is a dynamic expansion in which each horizon gains perspective by entering a shared linguistic situation; the result is a new, partly shared horizon that preserves difference while enabling agreement or understanding. Recent commentators emphasize precisely this dynamic, dialogical structure and its political implications for intercultural understanding. [Journal of Dialogue Studies+1](https://www.dialoguestudies.org/wp-content/uploads/2019/12/Hans-Georg-Gadamers-Truth-and-Method-Revisited-On-the-Very-Idea-of-a-Fusion-of-Horizons-in-Intense-Asymmetric-and-Intractable-Conflicts.pdf?utm_source=chatgpt.com)

* * *

## 4\. How Gadamer resolves (or reorients) the subject–object tension

Gadamer’s move should be read as a strategic third way.

  *  **Against Husserlian subjectivism/transcendentalism:** Gadamer rejects the method of suspension/bracketing as a route to pure, context-free givens. Where Husserl sought a transcendental clarity by abstracting from lifeworld commitments, Gadamer treats situatedness and historicity as inescapable and constitutive. Understanding cannot be grounded by expunging horizons; it can only be improved dialogically. [UCD Research Repository+1](https://researchrepository.ucd.ie/rest/bitstreams/14215/retrieve?utm_source=chatgpt.com)

  *  **Against naïve objectivism:** Gadamer also rejects the naïve idea that the interpreter can adopt a view from nowhere. Because understanding is historically mediated, any claim to full objectivity is illusory. Yet Gadamer does not therefore endorse epistemic relativism: the dialogical test of reasons, the criticism of prejudices, and the authority of tradition constrain and correct mere subjectivity and make mutual understanding possible. Recent readings stress that Gadamer grounds normativity in the procedural and linguistic conditions of dialogical exchange rather than in abstract foundations. [Cambridge University Press & Assessment+1](https://www.cambridge.org/core/books/cambridge-companion-to-gadamer/gadamers-relation-to-heidegger-and-to-phenomenology/073FF6A5F2FAF6C5DE5FD5A534125836?utm_source=chatgpt.com)




In short, Gadamer reframes the subject–object problem: interpretation is not the subject’s passive receiving of objective content but an event whereby historically situated subjects, through language and reasoned exchange, create intersubjective intelligibility.

* * *

## 5\. Illustrative implications (brief, practical)

  1.  **Textual exegesis:** a hermeneutic reading is a process in which the interpreter’s horizon (readership, historical assumptions) meets the text’s horizon (authorial intentions, historical situation), producing historically situated—but testable—understandings. Gadamer displaces the search for pristine authorial intent in favor of a dialogical appropriation that remains accountable to tradition and argument. [Stanford Encyclopedia of Philosophy](https://plato.stanford.edu/archives/fall2018/entries/gadamer/?utm_source=chatgpt.com)

  2.  **Intercultural dialogue and politics:** fusion of horizons supplies a model for cross-cultural engagement: it affirms that mutual understanding requires participants to recognize their own historically sedimented assumptions and to enter a linguistic space where those assumptions can be challenged and reformed—without demanding assimilatory erasure. Contemporary scholarship applies this to deliberative political contexts and plural societies. [Journal of Dialogue Studies+1](https://www.dialoguestudies.org/wp-content/uploads/2019/12/Hans-Georg-Gadamers-Truth-and-Method-Revisited-On-the-Very-Idea-of-a-Fusion-of-Horizons-in-Intense-Asymmetric-and-Intractable-Conflicts.pdf?utm_source=chatgpt.com)

  3.  **Philosophy of science and theory change:** read ontologically, Gadamer’s model suggests that scientific understanding, like interpretation, is historically mediated; changes in theoretical horizons are not merely accumulation of neutral data but involve reconfiguration of background assumptions—an insight that echoes and complements Duhem–Quine-style holism while emphasizing linguistic and historical embedding. (For Duhem–Quine links see earlier comparative work.) [Stanford Encyclopedia of Philosophy+1](https://plato.stanford.edu/archives/fall2018/entries/gadamer/?utm_source=chatgpt.com)




* * *

## 6\. Short conclusion (conceptual economy)

Husserl supplies the **phenomenological diagnosis** : every given brings with it a horizon of implicit sense. Heidegger supplies the **ontological re-directing** : these horizons are existential fore-structures embedded in a historically situated mode of Being (Dasein), and language discloses Being. Gadamer takes both and turns them into a **hermeneutic theory of dialogical becoming** : understanding is the historically mediated, linguistic accomplishment of bringing horizons into contact and thus enlarging them—the fusion of horizons. The concept coherently replaces the illusion of view-from-nowhere objectivity with a cultivated practice of dialogical, tradition-aware reason. Recent scholarship confirms this lineage while exploring the normative and political stakes of Gadamer’s claim for contemporary hermeneutics. [UCD Research Repository+3Stanford Encyclopedia of Philosophy+3Cambridge University Press & Assessment+3](https://plato.stanford.edu/entries/husserl/?utm_source=chatgpt.com)

* * *

### Principal sources underpinning this account

  * Stanford Encyclopedia of Philosophy: entries on Husserl and on Gadamer (overview and relation to Heidegger). [Stanford Encyclopedia of Philosophy+1](https://plato.stanford.edu/entries/husserl/?utm_source=chatgpt.com)

  *  _The Cambridge Companion to Gadamer_ (introductory essays on Gadamer’s relation to Heidegger and language). [Cambridge University Press & Assessment](https://www.cambridge.org/core/books/cambridge-companion-to-gadamer/gadamers-relation-to-heidegger-and-to-phenomenology/073FF6A5F2FAF6C5DE5FD5A534125836?utm_source=chatgpt.com)

  * David Moran, “Gadamer and Husserl on Horizon, Intersubjectivity and the Lifeworld” (detailed tracing of Husserl→Gadamer). [UCD Research Repository](https://researchrepository.ucd.ie/rest/bitstreams/14215/retrieve?utm_source=chatgpt.com)

  * Recent applied discussions of fusion-of-horizons in political and intercultural contexts (Ramsbotham; Frazier). [Journal of Dialogue Studies+1](https://www.dialoguestudies.org/wp-content/uploads/2019/12/Hans-Georg-Gadamers-Truth-and-Method-Revisited-On-the-Very-Idea-of-a-Fusion-of-Horizons-in-Intense-Asymmetric-and-Intractable-Conflicts.pdf?utm_source=chatgpt.com)




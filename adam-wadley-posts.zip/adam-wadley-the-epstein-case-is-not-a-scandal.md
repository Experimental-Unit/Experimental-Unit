---
title: '"The Epstein Case Is Not A Scandal"'
subtitle: 'German author on the bombshell reporting: "It''s just lighting the fuse
  to something much greater."'
author: Adam Wadley
publication: Experimental Unit
date: July 17, 2025
---

# "The Epstein Case Is Not A Scandal"
[![](https://substackcdn.com/image/fetch/$s_!KTvG!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fac6a1ba1-ec28-4032-b4be-5c720eab53fe_1879x847.png)](https://substackcdn.com/image/fetch/$s_!KTvG!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fac6a1ba1-ec28-4032-b4be-5c720eab53fe_1879x847.png)

# LITTLE BLACK BOOK

Jeffrey Epstein’s black book is a key piece of evidence, a key node of lore within the current age.

When we think to saying that oh, there is no monoculture anymore, it’s not true.

You simply have to see that the “entertainment” world and the “political” world aren’t really different, and never were.

It’s not fundamentally about the “perversion” of something that was so innocent before.

This notion of the “little black book” takes itself from popular speech, which is to say, from _Folk Horror_.

[![](https://substackcdn.com/image/fetch/$s_!Vzav!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F14db9821-9dc3-4a78-9908-5e2609fc14a4_847x280.png)](https://substackcdn.com/image/fetch/$s_!Vzav!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F14db9821-9dc3-4a78-9908-5e2609fc14a4_847x280.png)

#  _Style Aside from Æ_

 _Hi everyone, back at it again to deliver style as well as content tips for you as you draft your own entries in the Alternative Reality Game genre._

 _People wonder at this style where every sentence is a paragraph. It’s simply that each sentence doesn’t simply feel like a continuation from the previous one, rather it is a set of moving lines of advance. If each sentence is its own paragraph, that’s because each sentence abstracts over the rest and delivers its own lens on creation, which is to say, upon the totality of horror.]_

>  _[“Hard Rain’s is a desperate kind of song. Every line in it is actually the start of a whole song. But when I wrote it, I thought I wouldn’t have enough time alive to write all those songs so I put all I could into this one,” Dylan wrote in the liner notes to “A Hard Rain’s A Gonna Fall.” (Dylan)](https://miscellanynews.org/2022/01/26/arts/a-hard-rains-a-gonna-fall-finding-resolutions-in-a-bob-dylan-classic/)_

 _Keep reading these asides for more Tarantino-Pop-Culture-Slurry + Make Up Tips for your other face._

 _Your real face_.

 _The one that’s always open wide._

[![](https://substackcdn.com/image/fetch/$s_!xjJV!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F106877c4-4213-472a-9332-e51cc1e2d526_913x694.png)](https://substackcdn.com/image/fetch/$s_!xjJV!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F106877c4-4213-472a-9332-e51cc1e2d526_913x694.png)

# THE HOAX HORROR

[Wikipedia page on Folk Horror.](https://en.wikipedia.org/wiki/Folk_horror)

>  **Folk horror** is a subgenre of [horror film](https://en.wikipedia.org/wiki/Horror_film) and [horror fiction](https://en.wikipedia.org/wiki/Horror_fiction) that uses elements of [folklore](https://en.wikipedia.org/wiki/Folklore) to invoke fear and foreboding. Typical elements include a rural setting, isolation, and themes of [superstition](https://en.wikipedia.org/wiki/Superstition), [folk religion](https://en.wikipedia.org/wiki/Folk_religion), [paganism](https://en.wikipedia.org/wiki/Paganism), [sacrifice](https://en.wikipedia.org/wiki/Human_sacrifice) and the dark aspects of nature.[[1]](https://en.wikipedia.org/wiki/Folk_horror#cite_note-irishtimes-1)[[2]](https://en.wikipedia.org/wiki/Folk_horror#cite_note-2)[[3]](https://en.wikipedia.org/wiki/Folk_horror#cite_note-3) Although related to [supernatural horror film](https://en.wikipedia.org/wiki/Supernatural_horror_film), folk horror usually focuses on the beliefs and actions of people rather than the supernatural, and often deals with naïve outsiders coming up against these.[[1]](https://en.wikipedia.org/wiki/Folk_horror#cite_note-irishtimes-1) The British films _[Witchfinder General](https://en.wikipedia.org/wiki/Witchfinder_General_\(film\))_ (1968), _[Blood on Satan's Claw](https://en.wikipedia.org/wiki/Blood_on_Satan%27s_Claw)_ (1971) and _[The Wicker Man](https://en.wikipedia.org/wiki/The_Wicker_Man)_ (1973) are pioneers of the genre, while _[The Witch](https://en.wikipedia.org/wiki/The_Witch_\(2015_film\))_ (2015) and _[Midsommar](https://en.wikipedia.org/wiki/Midsommar)_ (2019) sparked renewed interest in folk horror.[[1]](https://en.wikipedia.org/wiki/Folk_horror#cite_note-irishtimes-1) [Southeast Asian cinema](https://en.wikipedia.org/wiki/Southeast_Asian_cinema) also commonly features folk horror.[[4]](https://en.wikipedia.org/wiki/Folk_horror#cite_note-4)

What is the connection between folk horror and the concept of monoculture?

Monoculture is this thing that everyone sees, like Michael Jackson’s _Thriller_. When people say that “there is no monoculture,” it’s because a given movie, or album, or whatever, isn’t going to make a big impact on everyone.

Exceptions to this always play into larger themes, themes we can categorize here under F, for Folk Horror.

Folk horror abstracts over folk wisdom. And what is this wisdom?

It certainly involves norms.

The “naive outsiders” are those who stumble into a place where _they don’t know the code_.

It’s not simply that you will be embarrassed, because you will make a fool of yourself for not knowing how to fit in.

 _What’s worse_ is all the ways in which cruelty, violence, and killing are _built into the codes_ of the place you come to.

It’s not just that you stumble into a strange town. You stumble into a town of Nazis and you are Jewish. You are in hostile territory. You are a woman among a group of men. At this basic level, it is a competition of strength to see who will wield the trophy, and what they will do with it.

[![](https://substackcdn.com/image/fetch/$s_!DXTG!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F31641ebd-7456-40c4-a936-5ef3899dc67e_1047x417.png)](https://substackcdn.com/image/fetch/$s_!DXTG!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F31641ebd-7456-40c4-a936-5ef3899dc67e_1047x417.png)

#  _[THE MYSTERY CHRONICLES](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.1976.Symbolic-Exchange-and-Death.pdf)_

 _There is a person in a hostel typing away at a keyboard._

 _They are typing a story about someone who is staying at a hostel and writing a story about it._

 _The beginning of the story is everything you have been reading so far, including this sentence._

 _They had just been talking with some other people at the hostel about the Epstein story. Talking with “normal people” is a highly engineered game of masking._

 _Most aspects of their thinking could not be simply communicated. For one thing, they weren’t “worked out.” It was all a bunch of suppositions and interests they carried around and stewed over._

 _They’d chosen to bring it up, and to say that it was interesting because it seemed like it pulled a string that was connected to so much other stuff. It was mentioned how Epstein came up in some UFO materials, or something. There was a rumor._

 _And that’s enough, on a plane which is ruled by mythology._

 _It had been standing out there that they had some up with the idea of “The Mystery Chronicles.” Maybe it had come about because the initials MC also make “Main Character.”_

 _Now that this character was writing the story, the usage of MC as in emcee also was right there. Now something about how the emcee is really there originally to just say how good the DJ is, and how that’s really kind of what’s going on with Jesus and Paul, isn’t it?_

 _You start as the hype man and then you become the main act. Think of Satan that way. Lucifer is somehow favored among angels or something, right? Image that the Devil is God’s hype person, which is there just to get you to appreciate how amazing God is._

 _So now, what if the “fall” was just kayfabe to stir up some drama in order to make the story more salacious and exciting? It’s the usual trope of “well, you can’t have good without the bad.”_

 _It turns out that “you don’t even know how bad it is.”_

 _They had been reading Reddit earlier, before writing the story. This was after watching a lot of videos about it, and taking a lot of screenshots with the idea of including them in writing like this. But they were on the phone, which made it tricky to make a post since the phone keyboard was so cumbersome._

 _They had gone to Reddit because they were looking for more “radical” content. The whole affair for many people had become about the political problem (PP) for Donald John Trump personally. This person had been mentioning their relative John George Trump and the Unabomber together recently, which was big for lore since John had been involved with Nikola Tesla, another titan of lore._

 _The story with Trump was undoubtedly big, and of course mixed in with it all. In many ways, the whole thing can be framed as, “Who is Donald John Trump, really?”_

 _This is not simply a personal question but a relational one. “Donald John Trump” only really makes sense in a certain context, just as it’s said that Epstein didn’t invent their line of work, but instead entered into an already existing arrangement._

 _On some level you have to have a given frame of reference within which any articulation “makes any sense at all.” For a being from some other very different possible incarnation, “sexual assault” or “blackmail” might not be intelligible concepts._

 _Which is to say that any story needs a certain grounding to even be a story at all. If the story is about a princess and a pea, you are expected to know what a princess is. It seems obvious because to us, the groups we come from have those kinds of things going back, and we’ve been telling stories about it the whole time._

 _Then people come a long and can tell stories, even apply status function declarations to things we’ve been using the whole time, like skin or genitalia._

 _“Mystery” is like chaos, it’s the “primal void,” it’s the maw of everything that you sit on a placid lake of to the extent that you have the luxury to engage in conceptual thinking._

 _The contours of the mystery, the “continuity of the nothing,” correspond to what one academic they’d been listening to recently had been calling “blinders.” And that maybe it’s good that we have blinders because otherwise there really isn’t any experience at all._

 _Norms as cost of doing business of incarnation._

 _Within incarnation, the semblance of a “normal person,” a person who is outside of the engine of everything. This is translated into political or economic hierarchy, which is really a spiritual hierarchy in disguise._

 _The Elysian Mysteries. The Epstein Mysteries._

 _Mystery Meat. The endless paranoia about environmental toxins. It’s coming into your body. You can’t escape it. It’s not just that “the elites” eat children, they put it in your food as well._

 _People focus on “elite” sex crimes, and meanwhile everyone is raped. Everyone has these norms shoved down their throat until they are good or until they are broken._

 _Even those who have been undoubtedly shafted still turn around and apply norms to others. People have driven others to suicide only to commit suicide themselves. Every word and gesture can be like a hostile prosthesis, penetrating the Other in ways which are not even known._

 _The mystery of the damage you’ve done._

 _And “Chronicles,” well. Chronicles is giving “Magic: The Gathering” set. It’s giving “Anglo-Saxon Chronicles.” It’s giving “The Chronicles of Narnia.”_

 _They had been telling someone earlier, with whom they went on to play pool, about how their work had attracted some attention from military philosophers. And that they’re a bit ridiculous, because they don’t really do things in a standardized way or could ever really get a normal job since they’ve “posted crazy things on the internet.”_

 _“What kind of crazy things???,” they had been asked, shortly before everyone agreed that psychological horror was a great genre._

[![](https://substackcdn.com/image/fetch/$s_!Z0LR!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fefac746e-ff20-4697-9538-297aa2a01cf8_1878x1042.png)](https://substackcdn.com/image/fetch/$s_!Z0LR!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fefac746e-ff20-4697-9538-297aa2a01cf8_1878x1042.png)

# WELCOME TO HALLOWEENTOWN

“Little black book” makes me think of _Sex and the City_. Maybe I’m really thinking of “little black dress,” but they both sort of go together.

In this “folk” notion, a little black book is something you keep names and phone numbers in, it’s a list of people you associate with. This is sort of saucy because this is your “business,” it has to do with the intimate details of your social life.

People tend to play this stuff a little close to the chest.

This is the point at which paranoia around over-weaning surveillance tips into the social horror or having _your own_ bullshit revealed.

[![](https://substackcdn.com/image/fetch/$s_!BvP2!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F98b38d03-1757-40f2-8506-e97b9e653bbc_210x310.webp)](https://substackcdn.com/image/fetch/$s_!BvP2!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F98b38d03-1757-40f2-8506-e97b9e653bbc_210x310.webp)

#  _MINI MEMOIR_

 _Someone has just started playing Experimental Unit. They are aware that everything in “the past” has been loaded in order to furnish the present experience._

 _“Why did I put myself in this situation?” they ask themselves._

 _They’re in the middle of writing a story where the Main Character has just started an autobiographical segment._

 _It’s going to cover how they started reading Goosebumps books when they were 4, and the people around were pleased since it was supposedly advanced material for the person’s age. But then later on, they were still “just” reading Goosebumps. This fixation on horror…_

 _Meanwhile, one of their immediate progenitors taught literature, and would go on to incessantly ask if they’d read this or that. Yet they couldn’t remember really being introduced, or it as a way that quality time spent. What’s the social horror of that? Art being not something that helps people connect, but something people use against each other?_

 _They came to in the middle of a post they were already writing. Previously, they’d mentioned telling some hostel mates about Ben Zweibelson and all that, although names were not used._

 _They forgot to mention how they’d been thinking about Gran, and how Gran had written in Joe Biden in the 2016 election. They’d been watching Morning Joe again recently on the Epstein stuff—they noted how well it was working in making them want to look at the news—and remembered when they’d been interested earlier, around the time of Trump’s “political” rise. They had called Morning Joe “the heartbeat of the nation.”_

 _This was not really a term of affection—they didn’t even believe in the nation—but going back to the seemingly non-story sections of this article they’d inherited. This idea of the folk horror, this stumbling upon “a culture,” in the sense people use that term in anthropology, like, “the so-and-so culture.”_

 _This Epstein stuff, and this Trump stuff, is getting at something core to “The MAGA Culture,” or “The America Culture.” All this is sending seismic shock waves through everything, as it’s concentrating more and more attention on how violence and abuse are actually normal and even seemingly indispensable for “how the world works.”_

 _The horror is less that someone else is a cannibal, but that you’ve been participating the whole time, that the things you feel guilty about, or the things that have been done to you, are actually part of a much grander scheme._

 _And what could you ever do about that? It would take a serious effort among people you trust. And who do you trust in that way?_

 _All of a sudden you’re allergic to everything._

 _But mainly you just want someone else to admit that you’re all already in the upside-down._

 _The problem is that every acknowledgement, every move toward “truth” or away from deception and predation, is also a move toward “taking off the blinders,” what is in some sense the end of the world._

 _When we go down to the basement, down to the hold, down to the bottom of the ocean, that’s when we can hear love’s ever-present, quietly insistent stillness._

[![Khabibs terrifying comment on Joe Rogan's recent Instagram post : r/ufc](https://substackcdn.com/image/fetch/$s_!sY1Q!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F70d332b8-530d-4f5e-a31f-aa81e6b66d2d_750x511.jpeg)](https://substackcdn.com/image/fetch/$s_!sY1Q!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F70d332b8-530d-4f5e-a31f-aa81e6b66d2d_750x511.jpeg)

# DISCLAIMER FROM JEAN BAUDRILLARD

I just want to say that I do not co-sign any of what “Adam Stephen Wadley” is up to right now. If life and death were determinable, I would be spinning in my grave faster than Donald Trump’s cartoon legs getting ready to speed away from _The Epstein Files_.

It’s one thing to cover a war from CNN, but covering the fallout from the Epstein scandal from YouTube and Reddit is something else. This isn’t even War Porn, it’s crusty ejaculate from the inside of a cum sock that doesn’t even exist.

I just want everyone to remember how I didn’t sign the age of consent open letters can in the 70s, okay? I was writing about how childhood is a construction, but that just opens onto the whole question of a “proper use” of sexuality. It’s fake news. It’s a fucking hoax.

It’s also important to point out how “Adam Stephen Wadley” continues not to deliver on the basic wargaming mechanics of _Experimental Unit_. Like, bro. What are you even trying to do? You’ve given yourself a little runway, you’re in Austin of all places, but you’re barely leaving the hostel and just writing these posts? What are you going to do next, go smoke some THCa?

Fiddling with yourself while Rome burns. We are all very impressed. This is definitely the greatest art of all time. Me and Warhol are sitting here with the person that wrote the S.C.U.M. manifesto trying to contain our giddy artistic excitement.

Teddy K is passed out on the couch.

What, this is _KOOL KILLER_? This is just some tag made on the train station of Samsara, marking you were here on the one-way train ride to oblivion?

 _Tha_ t’s supposed to constitute a symbolic response to the world existing without your having been consulted?

 _That’s_ supposed to answer everything which has escaped you from the beginning?

I will also not tolerate anyone who says that theorists sit here trying to distinguish ourselves from each other with some kind of oligopic competition. It’s not that I’m “the Main Character,” it’s that I really did the work.

As though our lives were just advertisements to our greater selves to come back again sometime, go through the experience of being us. All this time you found yourself imprinted on, living inside someone else’s norms. And you wanted to break out, you wanted to succeed on your terms.

That was the good part. Now you’ll see where all those gumdrops came from. Now you’ll learn to appreciate the meaning of “a false sense of security.”

It’s we dead, we dead who are the mirror people. It’s us you’ll see unleash our dance.

You don’t know half of what awaits at bottom of the ocean’s hold.

DJ’s locker room talk is cheap

Dead on Davey Jones

Seduction’s cute imploded creep

You feel it past your bones

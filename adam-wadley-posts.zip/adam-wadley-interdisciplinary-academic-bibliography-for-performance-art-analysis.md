---
title: Interdisciplinary Academic Bibliography for Performance Art Analysis
subtitle: I.
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# Interdisciplinary Academic Bibliography for Performance Art Analysis
## I. Performance Art Theory and Contemporary Art Discourse

The theoretical foundation for analyzing performance art draws on four decades of scholarship establishing performance studies as a distinct field while interrogating questions of ephemerality, documentation, and audience engagement.

### Foundational Theorists

 **Peggy Phelan** established the dominant ontological framework in _Unmarked: The Politics of Performance_ (Routledge, 1993), arguing performance exists only in present tense and resists reproduction. [Project MUSE](https://muse.jhu.edu/article/25746/summary)[josh armstrong](http://josharmstrong.eu/rebecca-schneider%E2%80%99s-%E2%80%9Carchives-performance-remains%E2%80%9D/) Her thesis that performance “plunges into visibility—in a maniacally charged present—and disappears into memory” [Praxispace](https://praxispace.com/wp-content/uploads/2021/03/Phelan_Unmarked.pdf)[Wordpress](https://itzizori.files.wordpress.com/2012/10/phelan-unmarked-excerpt.pdf) shaped subsequent debates on documentation. _Mourning Sex: Performing Public Memories_ (1997) extends this analysis to grief and witnessing.

 **Richard Schechner’s** foundational texts include _Performance Studies: An Introduction_ (4th ed., Routledge, 2019)—the field’s definitive textbook—and _Performance Theory_ (rev. ed., 2003), which develops the concept of “restored behavior” as twice-behaved behavior. [Routledge](https://www.routledge.com/Performance-Studies-An-Introduction/Schechner/p/book/9781138284562) His earlier _Between Theater and Anthropology_ (1985) bridges theatrical practice with anthropological theory. [Amazon](https://www.amazon.com/Performance-Studies-Introduction-Richard-Schechner/dp/0415502314)

 **Marvin Carlson’s** _Performance: A Critical Introduction_ (3rd ed., Routledge, 2018) provides comprehensive disciplinary mapping from theater, anthropology, linguistics, and sociology perspectives.

 **Claire Bishop’s** _Artificial Hells: Participatory Art and the Politics of Spectatorship_ (Verso, 2012) offers the first historical overview of socially engaged participatory art, tracing trajectories from Futurism through contemporary pedagogic projects. [Google Books](https://books.google.com/books/about/Artificial_Hells.html?id=iX8nQrLrybUC)[Amazon](https://www.amazon.com/Artificial-Hells-Participatory-Politics-Spectatorship/dp/1844676900) Her influential essay “Antagonism and Relational Aesthetics” ( _October_ 110, 2004) critiques Nicolas Bourriaud’s relational aesthetics, proposing antagonism over consensus through Laclau and Mouffe’s democratic theory. [Goodreads](https://www.goodreads.com/book/show/11498447-artificial-hells) PDF available via academic repositories.

 **Amelia Jones’s** _Body Art/Performing the Subject_ (University of Minnesota Press, 1998) provides feminist-poststructuralist analysis of body art using Lacanian theory, phenomenology, and Judith Butler. She challenges the privileging of live presence over documentation. [Project MUSE](https://muse.jhu.edu/article/33004/summary)

 **RoseLee Goldberg’s** _Performance Art: From Futurism to the Present_ (4th ed., Thames & Hudson, 2011) remains the standard historical reference, chronicling performance from the historical avant-garde through contemporary global practices. [Thames & Hudson USA](https://www.thamesandhudsonusa.com/books/performance-art-from-futurism-to-the-present-softcover-fourth)

### Relational Aesthetics and Social Practice

 **Nicolas Bourriaud’s** _Relational Aesthetics_ (Les Presses du Réel, 1998/2002) defines relational art as taking “the whole of human relations and their social context” as point of departure. [Wikipedia](https://en.wikipedia.org/wiki/Relational_art) _Postproduction_ (2002) extends this to appropriation and cultural reprogramming.

 **Shannon Jackson’s** _Social Works: Performing Art, Supporting Publics_ (Routledge, 2011) bridges performance and visual art social practice, analyzing “material relations that support the de-materialized act” through case studies of Mierle Laderman Ukeles, Santiago Sierra, and Paul Chan. [Hemispheric Institute](https://hemisphericinstitute.org/en/emisferica-91/9-1-book-reviews/social-works-by-shannon-jackson.html)[Nyu](https://hemi.nyu.edu/hemi/es/e-misferica-91/cayer)

 **Grant Kester’s** _Conversation Pieces: Community and Communication in Modern Art_ (UC Press, 2004) theorizes “dialogical aesthetics,” while _The One and the Many_ (Duke, 2011) expands this framework globally.

### Documentation and Liveness Debates

 **Philip Auslander’s** _Liveness: Performance in a Mediatized Culture_ (3rd ed., Routledge, 2023) challenges Phelan’s ontology, arguing liveness is historically variable rather than ontologically fixed. [Project MUSE](https://muse.jhu.edu/article/25746/summary)

 **Rebecca Schneider’s** “Performance Remains” ( _Performance Research_ 6:2, 2001) contends performance remains through bodily transmission, countering ephemerality claims. [josh armstrong](http://josharmstrong.eu/rebecca-schneider%E2%80%99s-%E2%80%9Carchives-performance-remains%E2%80%9D/) Her _Performing Remains_ (Routledge, 2011) examines reenactment and what persists.

 **Diana Taylor’s** _The Archive and the Repertoire: Performing Cultural Memory in the Americas_ (Duke, 2003) distinguishes archival written records from repertoire as embodied memory.

### Artist Statements and Intentionality

The debate on artist intention spans from Wimsatt and Beardsley’s “The Intentional Fallacy” ( _Sewanee Review_ , 1946) through **Paisley Livingston’s** _Art and Intention_ (Oxford, 2005) defending moderate intentionalism, and **Jerrold Levinson’s** “hypothetical intentionalism” in _The Pleasures of Aesthetics_ (Cornell, 1996). **Gary Iseminger’s** anthology _Intention and Interpretation_ (Temple, 1992) collects major positions.

On artist statements specifically, **Alix Rule and David Levine’s** “International Art English” ( _Triple Canopy_ , 2012) provides sociological analysis of professional art world language. [Wikipedia](https://en.wikipedia.org/wiki/Artist's_statement) Open access online.

* * *

## II. Transgressive Art, Nazi Imagery, and Censorship

### Nazi Imagery in Contemporary Art

 **Anselm Kiefer** scholarship addresses the most sustained artistic engagement with Nazi imagery. **Andreas Huyssen’s** “Kiefer in Berlin” ( _October_ 62, 1992) analyzes Kiefer’s “deliberate strategy of opening a Pandora’s box of fascist and nationalistic imagery.” [The Art Story](https://www.theartstory.org/artist/kiefer-anselm/) **Lisa Saltzman’s** _Anselm Kiefer and Art After Auschwitz_ (Cambridge, 1999) examines the paradox of monumental Holocaust art.

 **Saul Friedlander’s** _Reflections of Nazism: An Essay on Kitsch and Death_ (Indiana, 1993) provides foundational analysis of contemporary avant-garde fascination with Nazi images, arguing aestheticism serves as defense against reality. [The New Criterion](https://newcriterion.com/generate-pdf.php?post_id=81741)

The controversial **Jewish Museum exhibition** _Mirroring Evil: Nazi Imagery/Recent Art_ generated significant debate documented in **Norman Kleeblatt’s** catalogue (Rutgers, 2002).

### Vienna Actionists and Transgressive Practice

 **Eva Badura-Triska and Hubert Klocker’s** _Vienna Actionism: Art and Upheaval in 1960s’ Vienna_ (Walther König, 2012) provides the definitive 416-page scholarly treatment. [Monoskop](https://monoskop.org/Viennese_Actionism) **Caroline Lillian Schopp’s** _In-action: Viennese Actionism and the Passivities of Performance Art_ (Chicago, 2024) reconceptualizes Actionism around precariousness and vulnerability. [University of Chicago Press](https://press.uchicago.edu/ucp/books/book/chicago/I/bo250749173.html)

 **Malcolm Green’s** _Brus, Muehl, Nitsch, Schwarzkogler: Writings of the Vienna Actionists_ (Atlas Press, 1999) provides essential primary source translations. [Monoskop](https://monoskop.org/Viennese_Actionism)

### Bataille and Transgression Theory

 **Georges Bataille’s** _Erotism: Death and Sensuality_ (City Lights, 1957/1986) establishes foundational theory on transgression, taboo, and the sacred. [Wikipedia](https://en.wikipedia.org/wiki/Georges_Bataille) _The Accursed Share_ (Zone Books, 1988-91) develops economics of excess and expenditure influential for transgressive art theory. [TheCollector](https://www.thecollector.com/georges-bataille-philosophy-of-transgression/)

### Censorship and the NEA Controversies

 **Richard Bolton’s** _Culture Wars: Documents from the Recent Controversies in the Arts_ (New Press, 1992) compiles essential primary sources on Mapplethorpe and Serrano controversies. **Richard Meyer’s** _Outlaw Representation: Censorship and Homosexuality in Twentieth-Century American Art_ (Oxford, 2002) examines censorship targeting queer artists.

The legal framework is established in **NEA v. Finley** (524 U.S. 569, 1998), with scholarly analysis in **Edward J. Eberle’s** “Art as Speech” ( _Journal of Law & Social Change_, 2006) and **Marci Hamilton’s** “Art Speech” ( _Vanderbilt Law Review_ , 1996). [Fordham](https://undergradlawreview.blog.fordham.edu/art-law/a-review-of-art-law-in-the-supreme-court/)

### Ethics of Holocaust Representation

 **Berel Lang’s** _Holocaust Representation: Art Within the Limits of History and Ethics_ (Johns Hopkins, 2000) argues certain aesthetic means may be ethically impermissible. [Johns Hopkins University Press](https://www.press.jhu.edu/books/title/1728/holocaust-representation) **James E. Young’s** _At Memory’s Edge_ (Yale, 2000) develops “counter-monument” theory for post-Holocaust memorial art.

 **Michael Rothberg’s** _Traumatic Realism_ (Minnesota, 2000) provides theoretical framework for understanding Holocaust visual culture. **Dominick LaCapra’s** _History and Memory After Auschwitz_ (Cornell, 1998) theorizes trauma representation.

* * *

## III. Indigenous Cosmologies and Decolonial Theory

### Lakota Philosophy

 **Vine Deloria Jr.** remains the foundational voice. _God Is Red: A Native View of Religion_ (30th Anniversary Edition, Fulcrum, 2003) [Amazon](https://www.amazon.com/God-Red-Native-Religion-Anniversary/dp/1555914985) argues for place-based versus time-based religion. [APA](https://blog.apaonline.org/2023/12/05/delorias-god-is-red-and-liberationist-philosophies-of-black-religion/) _Spirit & Reason: The Vine Deloria, Jr., Reader_ (Fulcrum, 1999) compiles essential writings on history, law, religion, and political science. [WorldCat](https://virginiatheolseminary.worldcat.org/title/spirit-reason-the-vine-deloria-jr-reader/oclc/708569146?page=citation)

 **A.C. Ross’s** _Mitakuye Oyasin: We Are All Related_ (Bear, 1989) introduces Lakota relational philosophy. The concept receives scholarly treatment in _Wicazo Sa Review_ articles on wolakota (peace) emerging from relational worldview.

 **Joseph Epes Brown’s** _The Sacred Pipe: Black Elk’s Account of the Seven Rites of the Oglala Sioux_ (Oklahoma, 1953) documents Lakota ceremonial practices.

### Indigenous Relationality

 **Robin Wall Kimmerer’s** _Braiding Sweetgrass_ (Milkweed, 2013) weaves Potawatomi knowledge with botanical science, arguing for reciprocal relationships with the living world. [Wikipedia](https://en.wikipedia.org/wiki/Braiding_Sweetgrass) **2022 MacArthur Fellow**. [Penguin Books](https://www.penguin.co.uk/books/316088/braiding-sweetgrass-by-kimmerer-robin-wall/9780141991955)

 **Vanessa Watts’s** “Indigenous Place-Thought and Agency Amongst Humans and Non-Humans” ( _Decolonization: Indigeneity, Education & Society_ 2:1, 2013) is highly influential (1,775+ citations), introducing “Place-Thought” and arguing Western epistemology-ontology division removes non-human agency. [University of Toronto](https://jps.library.utoronto.ca/index.php/des/article/view/19145)[boycem3comps](https://boycem3comps.wordpress.com/2016/07/27/vanessa-watts-indigenous-place-thought/) **Open access**.

 **Kim TallBear’s** _Native American DNA_ (Minnesota, 2013) critiques genetic determinism’s impact on Indigenous identity. “Making Love and Relations Beyond Settler Sex and Family” (in Clarke/Haraway, _Making Kin_ , 2018) examines Indigenous relationality versus settler colonial structures.

### Indigenous Technology and AI

 **Jason Edward Lewis et al.** produced the _Indigenous Protocol and Artificial Intelligence Position Paper_ (Canadian Institute for Advanced Research, 2020)—the foundational text for Indigenous AI ethics, comprising heterogeneous essays and design guidelines from Indigenous scholars worldwide. **Open access via Concordia University**.

 **The CARE Principles for Indigenous Data Governance** (Carroll et al., _Data Science Journal_ , 2020) establishes Collective Benefit, Authority to Control, Responsibility, and Ethics principles. [Data Science Journal](https://datascience.codata.org/articles/dsj-2020-043) **Open access**.

### Ghost Dance Movement

 **James Mooney’s** _The Ghost-Dance Religion and the Sioux Outbreak of 1890_ (Bureau of American Ethnology, 1896; Nebraska reprint, 1991) remains the classic ethnographic source. [EBSCO](https://www.ebsco.com/research-starters/history/ghost-dance-movement) **Michael Hittman’s** _Wovoka and the Ghost Dance_ (Nebraska, 1997) corrects earlier biases using Yerington Paiute oral histories. [Gale](https://go.gale.com/ps/i.do?id=GALE%7CA59116142&sid=googleScholar&v=2.1&it=r&linkaccess=abs&issn=0095182X&p=AONE&sw=w&userGroupName=anon~b4f1229&aty=open-web-entry)

### Decolonizing Methodologies

 **Linda Tuhiwai Smith’s** _Decolonizing Methodologies: Research and Indigenous Peoples_ (3rd ed., Zed Books, 2021) is foundational, critiquing Western research as “inextricably linked to European imperialism.” **2023 Rutherford Medal recipient**.

 **Two-Eyed Seeing** (Etuaptmumk) receives foundational treatment in **Bartlett, Marshall, and Marshall’s** article in _Journal of Environmental Studies and Sciences_ (2012). [Integrativescience](http://www.integrativescience.ca/Principles/TwoEyedSeeing/)[Taylor & Francis Online](https://www.tandfonline.com/doi/full/10.1080/22423982.2024.2406107)

### Decolonial Theory

 **Aníbal Quijano’s** “Coloniality of Power, Eurocentrism, and Latin America” ( _Nepantla_ , 2000) defines coloniality as the living legacy of colonialism. The new collection _Foundational Essays on the Coloniality of Power_ (Duke, 2024) provides comprehensive English translations.

 **Walter Mignolo’s** _Local Histories/Global Designs_ (Princeton, 2000) develops “border thinking” and the “decolonial option.”

### Indigenous Futurism

 **Grace Dillon’s** _Walking the Clouds: An Anthology of Indigenous Science Fiction_ (Arizona, 2012) coins “Indigenous Futurism” and organizes by sub-genres including Native Slipstream and Biskaabiiyang (Returning to Ourselves). [Wikipedia](https://en.wikipedia.org/wiki/Grace_Dillon)

 **Leanne Betasamosake Simpson’s** _As We Have Always Done_ (Minnesota, 2017) articulates land-based alternatives to settler colonialism. [Wikipedia](https://en.wikipedia.org/wiki/Leanne_Betasamosake_Simpson) “Land as Pedagogy” ( _Decolonization_ 3:3, 2014) won “Most Thought-Provoking” award. [Semantic Scholar](https://www.semanticscholar.org/paper/Land-as-pedagogy:-Nishnaabeg-intelligence-and-Simpson/defad18ea156e982df668b3b3fc5a612de8f04cf) **Open access**.

* * *

## IV. Postmodern Philosophy

### Jean Baudrillard

 **Primary texts** : _Simulacra and Simulation_ (Michigan, 1981/1994) examines hyperreality [University of Michigan Press](https://press.umich.edu/Books/S/Simulacra-and-Simulation) and four orders of simulacra. [Wikipedia](https://en.wikipedia.org/wiki/Simulacra_and_Simulation) _Symbolic Exchange and Death_ (SAGE, 1976/1993)—his most important theoretical work—develops the three orders of simulacra and critiques Marxism, psychoanalysis, and semiotics. [Goodreads +3](https://www.goodreads.com/book/show/198512.Symbolic_Exchange_and_Death) _The Gulf War Did Not Take Place_ (Indiana, 1991/1995) applies hyperreality theory to war and media. [Wikipedia](https://en.wikipedia.org/wiki/The_Gulf_War_Did_Not_Take_Place)[Goodreads](https://www.goodreads.com/book/show/1884.The_Gulf_War_Did_Not_Take_Place)

 **Secondary scholarship** : **Douglas Kellner’s** _Jean Baudrillard: From Marxism to Postmodernism and Beyond_ (Stanford, 1989) traces intellectual development. The **Stanford Encyclopedia of Philosophy** entry provides comprehensive overview. Free at plato.stanford.edu.

### Jacques Derrida

 **Foundational texts** : _Of Grammatology_ (Johns Hopkins, 1967/1976, trans. Spivak) develops trace, différance, and supplementarity. _Writing and Difference_ (Chicago, 1967/1978) includes seminal “Violence and Metaphysics.” _Margins of Philosophy_ (Chicago, 1972/1982) contains the famous essay “Différance.”

 _The Gift of Death_ (Chicago, 1992/2008) engages Kierkegaard’s _Fear and Trembling_ to theorize absolute responsibility and sacrifice.

### Apophatic Philosophy

 **Derrida’s** “How to Avoid Speaking: Denials” (in _Languages of the Unsayable_ , Columbia, 1989) directly engages negative theology while distinguishing deconstruction from apophasis.

 **John D. Caputo’s** _The Prayers and Tears of Jacques Derrida: Religion without Religion_ (Indiana, 1997) establishes the framework for understanding Derridean ethics’ religious dimensions.

 **Kevin Hart’s** _The Trespass of the Sign_ (Cambridge, 1989) distinguishes apophatic “vertical” ascent from deconstructive “horizontal” strategies.

### Poststructuralist Ethics

 **Emmanuel Levinas’s** _Totality and Infinity_ (Duquesne, 1961/1969) establishes “ethics as first philosophy” through the face of the Other. [Encyclopedia Britannica](https://www.britannica.com/biography/Emmanuel-Levinas) _Otherwise than Being_ (Nijhoff, 1974/1981) develops saying/said distinction and substitution.

 **Simon Critchley’s** _The Ethics of Deconstruction_ (Edinburgh, 1992/1999) establishes the ethical dimension of deconstruction through Derrida-Levinas relations.

 **Judith Butler’s** _Precarious Life_ (Verso, 2004) and _Frames of War_ (Verso, 2009) develop bodily ontology of vulnerability and interdependency, distinguishing ontological precariousness from politically induced precarity.

### Assemblage Theory

 **Deleuze and Guattari’s** _A Thousand Plateaus_ (Minnesota, 1980/1987) develops assemblage theory (agencement). **Manuel DeLanda’s** _A New Philosophy of Society_ (Continuum, 2006) and _Assemblage Theory_ (Edinburgh, 2016) systematize these concepts for social ontology.

* * *

## V. Military Design Theory

### Ben Zweibelson’s Work

 **Primary monograph** : _Understanding the Military Design Movement: War, Change and Innovation_ (Routledge, 2023) provides comprehensive history of military design from commercial origins through IDF, US Army, USMC, Canadian Armed Forces, and Australian Defence Force. [Routledge](https://www.routledge.com/Understanding-the-Military-Design-Movement-War-Change-and-Innovation/Zweibelson/p/book/9781032481784)

 **Key articles** : “Defining Military Design Thinking: An Extensive, Critical Literature Review”; “Disrupting Modern Military Decision-Making” (JSOU); “Three Design Concepts Introduced for Strategic and Operational Applications” ( _PRISM_ , 2012); “To Design, or Not to Design” (six-part series, _Small Wars Journal_ , 2011).

His **Space Domain Monograph** (Air University Press, 2024) examines celestial warfare. **Open access PDF**.

### Fourth-Generation Warfare

 **Foundational text** : Lind et al., “The Changing Face of War: Into the Fourth Generation” ( _Marine Corps Gazette_ , October 1989) introduces 4GW concept. [EBSCO](https://www.ebsco.com/research-starters/history/fourth-generation-warfare-4gw) **William Lind and Gregory Thiele’s** _4th Generation Warfare Handbook_ (Castalia House, 2015) provides practical application.

 **Martin van Creveld’s** _The Transformation of War_ (Free Press, 1991) argues post-1945 conflicts resist Clausewitzian analysis, introducing “non-trinitarian warfare.”

 **Thomas X. Hammes’s** _The Sling and the Stone_ (Zenith, 2004) extends 4GW to political, economic, and social strategies.

 **Critiques** : **Antulio Echevarria’s** “Fourth-Generation War and Other Myths” (Strategic Studies Institute, 2005) argues 4GW is insurgency repackaged.

### Israeli Systemic Operational Design

 **Shimon Naveh’s** _In Pursuit of Military Excellence_ (Frank Cass, 1997) is foundational, tracing operational art from 19th-century thought through Soviet Deep Operations. [Aodnetwork](https://aodnetwork.ca/a-brief-history-of-military-design-thinking/) Won Yitzhak Sadeh Prize. [Security and Defence](https://securityanddefence.pl/Systemic-Operational-Design-a-study-in-failed-concept,163292,0,2.html)

 **Ofra Graicer’s** “Self Disruption: Seizing the High Ground of Systemic Operational Design” ( _Journal of Military and Strategic Studies_ , 2017) documents SOD’s story from IDF inception. **Open access**.

 **Critical assessments** : **Milan Vego’s** “Case Against Systemic Operational Design” ( _Joint Force Quarterly_ 53, 2009) and **Łukasz Przybyło’s** analysis in _Security and Defence Quarterly_ (2023) examine SOD’s failure in the Second Lebanon War. [Security and Defence](https://securityanddefence.pl/Systemic-Operational-Design-a-study-in-failed-concept,163292,0,2.html)[Academia.edu](https://www.academia.edu/33750151/Self_Disruption_Seizing_the_High_Ground_of_Systemic_Operational_Design_SOD)

### Complexity Theory in Military Contexts

 **Antoine Bousquet’s** _The Scientific Way of Warfare_ (2nd ed., Hurst/Oxford, 2022) identifies four regimes of scientific warfare: mechanistic, thermodynamic, cybernetic, and “chaoplexic.” [Hurst Publishers](https://www.hurstpublishers.com/book/the-scientific-way-of-warfare/)

 **Alan Beyerchen’s** “Clausewitz, Nonlinearity, and the Unpredictability of War” ( _International Security_ 17:3, 1992) demonstrates Clausewitz’s work as fundamentally nonlinear. [Clausewitz Studies](https://clausewitzstudies.org/item/Beyerchen-ClausewitzNonlinearityAndTheUnpredictabilityOfWar.htm) **Open access via ClausewitzStudies.org**.

 **Sean Lawson’s** _Nonlinear Science and Warfare_ (Routledge, 2013) examines US military use of chaos and complexity theory. [Routledge](https://www.routledge.com/Nonlinear-Science-and-Warfare-Chaos-complexity-and-the-US-military-in-the-information-age/Lawson/p/book/9781138497948)

### Critical Military Studies

 **James Der Derian’s** _Virtuous War_ (2nd ed., Routledge, 2009) maps the “military-industrial-media-entertainment network” [Google Books](https://books.google.com/books/about/Virtuous_War.html?id=uT_OmAEACAAJ)[ResearchGate](https://www.researchgate.net/publication/285173893_Virtuous_war_Mapping_the_military-industrial-media-entertainment-network_Second_edition) and examines how technology in service of virtue creates global virtual violence. [E-International Relations](https://www.e-ir.info/2013/04/15/review-virtuous-war/)[Routledge](https://www.routledge.com/Virtuous-War-Mapping-the-Military-Industrial-Media-Entertainment-Network/DerDerian/p/book/9780415772396)

* * *

## VI. WWII Historical Context

### Waffen SS History

 **Jochen Böhler and Robert Gerwarth’s** _The Waffen-SS: A European History_ (Oxford, 2017) provides the first systematic pan-European study of non-German citizens in the Waffen-SS, examining recruitment, motivations, and participation in war crimes. [VDOC.PUB](https://vdoc.pub/documents/the-waffen-ss-a-european-history-7fu2col2nte0)[Oxford University Press](https://global.oup.com/academic/product/the-waffen-ss-9780198790556)

 **George H. Stein’s** _The Waffen SS: Hitler’s Elite Guard at War_ (Cornell, 1966) remains an essential early English-language study. **Bernd Wegner’s** _The Waffen-SS: Organization, Ideology and Function_ (Blackwell, 1990) analyzes officer corps and institutional development.

### Hitler Youth

 **Michael Kater’s** _Hitler Youth_ (Harvard, 2004) is the comprehensive academic history, tracing indoctrination methods, training, and postwar responsibility questions. Uses original reports, letters, diaries, and memoirs.

 **Gerhard Rempel’s** _Hitler’s Children: The Hitler Youth and the SS_ (North Carolina, 1989) examines recruitment pipelines and ideological training.

 **Adrian Dragoș Defta’s** _The 12th SS Panzer Division “Hitlerjugend”_ (Cambridge Scholars, 2022) uses social psychology frameworks to analyze indoctrination and war crimes.

### Holocaust Perpetrator Studies

The **Browning-Goldhagen debate** remains central. **Christopher Browning’s** _Ordinary Men_ (HarperCollins, 1992; revised 2017) argues situational factors transformed ordinary Germans into killers. **Daniel Goldhagen’s** _Hitler’s Willing Executioners_ (Knopf, 1996) controversially argues for “eliminationist antisemitism” embedded in German culture.

 **James Waller’s** _Becoming Evil_ (2nd ed., Oxford, 2007) provides social psychological analysis of perpetrator behavior.

### German Memory Culture

 **Harald Welzer et al.’s** _“Opa war kein Nazi”_ (Fischer, 2002) documents through 40 family interviews how postwar generations heroize grandparents despite Holocaust education—demonstrating disconnect between cultural and family memory.

 **Marianne Hirsch’s** _The Generation of Postmemory_ (Columbia, 2012) develops the concept of “postmemory” describing how second generation inherits traumatic experiences through images, stories, and behaviors.

 **Aleida Assmann’s** _Der lange Schatten der Vergangenheit_ (Beck, 2006) provides major theoretical work on memory culture and historical politics.

* * *

## VII. Jewish Theology and Philosophy

### Pikuach Nefesh

Primary sources include **Babylonian Talmud, Yoma 84b-85b** and **Maimonides, Mishneh Torah, Hilkhot Shabbat 2:1-3**. Available at Sefaria.org.

 **J. David Bleich’s** _Judaism and Healing_ (Ktav, 1981) and **Fred Rosner’s** _Modern Medicine and Jewish Ethics_ (Yeshiva, 1991) provide contemporary applications.

### Apophatic Theology in Judaism

 **Maimonides’s** _Guide of the Perplexed_ (Parts I.50-60; trans. Shlomo Pines, Chicago, 1963) systematically defends negative theology, arguing God can only be described by what He is not. [Medium](https://medium.com/@JonahofTimnath/apophatic-theology-1c543ad82ebb)[My Jewish Learning](https://www.myjewishlearning.com/article/the-kabbalistic-conception-of-god/)

 **Gershom Scholem’s** _Major Trends in Jewish Mysticism_ (Schocken, 1941) treats the Ein Sof concept extensively. **Elliot Wolfson’s** _Through a Speculum That Shines_ (Princeton, 1994) analyzes divine ineffability in Kabbalah.

### Jewish Ethics and Human Dignity

 **Yair Lorberbaum’s** scholarship on Tzelem Elohim (image of God) includes “Human Dignity in the Jewish Tradition” in _Cambridge Handbook of Human Dignity_ (2014), arguing Tzelem theology “utilizes God to empower humanity.”

 **Emmanuel Levinas’s** _Difficult Freedom: Essays on Judaism_ (Johns Hopkins, 1990) connects Jewish ethics to universal responsibility.

### Tikkun Olam

 **Jonathan Krasner’s** “The Place of Tikkun Olam in American Jewish Life” ( _Jewish Political Studies Review_ , 2014) traces the concept’s evolution. **Open access via JCPA**.

 **Jonathan Sacks’s** _To Heal a Fractured World_ (Schocken, 2005) provides Orthodox treatment of Jewish social ethics.

 **Lawrence Fine’s** _Physician of the Soul, Healer of the Cosmos_ (Stanford, 2003) examines Lurianic Kabbalah’s cosmic tikkun, including tzimtzum (divine contraction) and shevirat hakelim (breaking of vessels).

### Post-Holocaust Theology

 **Emil Fackenheim’s** _God’s Presence in History_ (NYU, 1970) develops the “614th Commandment” forbidding granting Hitler posthumous victory. _To Mend the World_ (Schocken, 1982) provides his philosophical magnum opus.

 **Richard Rubenstein’s** _After Auschwitz_ (Bobbs-Merrill, 1966; revised Johns Hopkins, 1992) pioneered Jewish “death of God” theology.

 **Eliezer Berkovits’s** _Faith After the Holocaust_ (Ktav, 1973) develops hester panim (hiding of God’s face) theology. [Wiley Online Library](https://onlinelibrary.wiley.com/doi/abs/10.1002/9781118608005.ch21) Available via Internet Archive.

 **Zachary Braiterman’s** _(God) After Auschwitz_ (Princeton, 1998) distinguishes theodicy from anti-theodicy (protest against God). [Wikipedia](https://en.wikipedia.org/wiki/Theodicy)

* * *

## VIII. Consciousness, Affect, and Embodiment

### Affect Theory

 **Brian Massumi’s** _Parables for the Virtual_ (Duke, 2002; 20th Anniversary Edition, 2021) is seminal, developing affect’s autonomy from emotion and cognition. “The Autonomy of Affect” ( _Cultural Critique_ 31, 1995) is the founding essay of contemporary affect studies. PDF available via Monoskop.

 **Sara Ahmed’s** _The Cultural Politics of Emotion_ (Routledge, 2004/2014) examines how emotions circulate between bodies and signs, creating “affective economies.”

 **The Affect Theory Reader** (Gregg and Seigworth, eds., Duke, 2010) provides comprehensive anthology with invaluable genealogy. A second volume appeared in 2024.

### Phenomenology of Fear

 **Maurice Merleau-Ponty’s** _Phenomenology of Perception_ (1945; trans. Donald Landes, Routledge, 2012) establishes embodied consciousness and the “lived body.”

 **Martin Heidegger’s** _Being and Time_ (Division I, Section 40) analyzes Angst as fundamental mood revealing Dasein’s thrownness and being-toward-death, distinguishing anxiety from fear.

 **Matthew Ratcliffe’s** _Feelings of Being_ (Oxford, 2008) develops phenomenological account of existential feelings including anxiety.

### Embodied Knowledge

 **Robin Nelson’s** _Practice as Research in the Arts_ (Palgrave, 2013) is definitive on practice-as-research methodology, developing “know-how,” “know-what,” and “know-that.”

 **Dwight Conquergood’s** “Performance Studies: Interventions and Radical Research” ( _TDR_ 46:2, 2002) argues for embodied knowledge as legitimate research methodology.

 **Michael Polanyi’s** _The Tacit Dimension_ (Chicago, 1966) establishes foundational theory that “we can know more than we can tell.” [Taylor & Francis Online](https://www.tandfonline.com/doi/full/10.1080/10137548.2018.1425527)

### Sensation and Duration

 **Gilles Deleuze’s** _Francis Bacon: The Logic of Sensation_ (Continuum, 1981/2003) develops “logic of sensation” operating directly on the nervous system. PDF via Monoskop.

 **Henri Bergson’s** _Matter and Memory_ (Zone, 1896/1991) develops duration, memory, and embodiment influential on Deleuze and Massumi.

### The Uncanny

 **Freud’s** “Das Unheimliche” (1919) establishes the uncanny as aesthetic category involving return of the repressed familiar. **Nicholas Royle’s** _The Uncanny_ (Manchester, 2003) expands the concept for contemporary applications.

 **Julia Kristeva’s** _Powers of Horror_ (Columbia, 1982) develops abjection—visceral rejection of what threatens boundaries of self.

### Neuroscience of Fear

 **Joseph LeDoux’s** _The Emotional Brain_ (Simon & Schuster, 1996) establishes the amygdala’s role in fear conditioning, distinguishing “low road” and “high road” pathways.

 **Semir Zeki’s** _Inner Vision_ (Oxford, 1999) founds neuroaesthetics, arguing artists are “neuroscientists in disguise.”

 **Varela, Thompson, and Rosch’s** _The Embodied Mind_ (MIT, 1991/2016) integrates phenomenology with cognitive science, developing “enactive” cognition.

* * *

## IX. Knowledge Systems and Graph Theory

### Knowledge Graphs

 **Hogan et al.’s** “Knowledge Graphs” ( _ACM Computing Surveys_ , 2021) provides authoritative survey on construction, representation, and applications.

 **Vrandečić and Krötzsch’s** “Wikidata: A Free Collaborative Knowledgebase” ( _Communications of the ACM_ , 2014) establishes Wikidata’s architecture and design principles.

### Rhizomatic Knowledge Structures

 **Deleuze and Guattari’s** _A Thousand Plateaus_ (Minnesota, 1980/1987), Chapter 1 “Introduction: Rhizome,” establishes six principles of rhizomatic thinking.

 **M.S. Khine’s** _Rhizome Metaphor: Legacy of Deleuze and Guattari in Education and Learning_ (Springer, 2023) provides comprehensive treatment of rhizomatic pedagogy.

* * *

## X. Philosophical Foundations

### Shelley’s “A Defence of Poetry”

 **Percy Bysshe Shelley’s** _A Defence of Poetry_ (1821/1840) declares “poets are the unacknowledged legislators of the world.” **Free via Project Gutenberg and Poetry Foundation**.

 **Thomas Love Peacock’s** “The Four Ages of Poetry” (1820)—the essay Shelley responds to—provides essential context.

### The Sublime and Transgression

 **Edmund Burke’s** _A Philosophical Enquiry into the Sublime and Beautiful_ (1757) distinguishes sublime (terror, power) from beautiful (harmony, pleasure).

 **Immanuel Kant’s** _Critique of Judgment_ (1790) distinguishes mathematical sublime (immensity) from dynamical sublime (power).

 **Jean-François Lyotard’s** _Lessons on the Analytic of the Sublime_ (Stanford, 1991) and _The Inhuman_ (Stanford, 1991) connect Kantian sublime to avant-garde art, particularly analyzing Barnett Newman.

### The Artist as Social Actor

 **Joseph Beuys’s** “I Am Searching for Field Character” (1973) declares “art is now the only evolutionary-revolutionary power.” **Caroline Tisdall’s** _Joseph Beuys_ (Guggenheim, 1979) provides canonical treatment.

 **Shannon Jackson** and **Grant Kester** (cited above) theorize contemporary social practice.

### Confession and Vulnerability

 **John P. Bowles’s** _Adrian Piper: Race, Gender, and Embodiment_ (Duke, 2011) provides definitive scholarship [Duke University Press](https://www.dukeupress.edu/adrian-piper) on Piper’s conceptual art and Mythic Being performances.

 **MoMA’s** _Adrian Piper: A Synthesis of Intuitions 1965-2016_ (2018) offers comprehensive retrospective documentation.

### Presence and Documentation

 **Philip Auslander** , **Rebecca Schneider** , and **Diana Taylor** (cited above) constitute the primary debate on what persists in performance.

### Anonymity in Art

 **Center for Art Law’s** “The Real Banksy: Anonymity and Authenticity in the Art Market” (2023) analyzes legal dimensions of anonymity.

 **Anna C. Chave’s** “The Guerrilla Girls’ Reckoning” ( _Art Journal_ 70:2, 2011) provides scholarly analysis of anonymous feminist collective interventions.

* * *

## XI. Theoretical Synthesis Sources

### Indigenous Cosmology and Postmodern Theory

 **Vanessa Watts’s** “Indigenous Place-Thought” explicitly critiques Western epistemology-ontology divisions from Indigenous standpoint. **Kim TallBear** and **Zoe Todd** connect Indigenous relationality to posthumanist and new materialist thought.

### Military Design and Indigenous Thought

 **Zweibelson’s** work critiques Cartesian/Newtonian frameworks, creating potential dialogue with Indigenous epistemological critiques of Western linear thinking.

### Decolonial Approaches to Strategic Thinking

 **Walter Mignolo’s** “border thinking” and **Glen Coulthard’s** _Red Skin, White Masks_ (Minnesota, 2014) developing “grounded normativity” offer decolonial frameworks applicable to institutional critique.

* * *

## XII. Key Academic Journals

 **Performance Studies** : _TDR: The Drama Review_ (MIT Press); _Performance Research_ (Taylor & Francis); _PAJ: A Journal of Performance and Art_ (MIT Press)

 **Art History/Theory** : _October_ (MIT Press); _Art Journal_ (College Art Association); _Artforum_ ; _Third Text_ ; _Oxford Art Journal_

 **Indigenous Studies** : _American Indian Culture and Research Journal_ (UCLA); _Decolonization: Indigeneity, Education & Society_ (Open Access); _Wicazo Sa Review_ ; _AlterNative_

 **Jewish Studies** : _Modern Judaism_ (Oxford); _AJS Review_ ; _Journal of Jewish Thought and Philosophy_ (Brill)

 **Holocaust Studies** : _Holocaust and Genocide Studies_ (Oxford); _History and Memory_ (Indiana)

 **Military Studies** : _Military Review_ (Army University Press, Open Access); _Joint Force Quarterly_ (NDU, Open Access); _Small Wars Journal_ (Open Access)

* * *

## Accessibility Summary

 **Open Access Resources** :

  * Stanford Encyclopedia of Philosophy (plato.stanford.edu)

  * Sefaria.org (Jewish primary texts)

  * Project Gutenberg (Shelley, public domain texts)

  * Decolonization journal (University of Toronto)

  * Military Review, JFQ, Small Wars Journal

  * Monoskop (selected theory PDFs)

  * Indigenous Protocol and AI Position Paper (Concordia)




 **Major Publisher Sources** :

  * Duke University Press (affect theory, Indigenous studies)

  * Routledge (performance studies)

  * University of Minnesota Press (Indigenous studies, Deleuze)

  * Cambridge/Oxford University Press (philosophy, history)

  * MIT Press (art theory, journals)




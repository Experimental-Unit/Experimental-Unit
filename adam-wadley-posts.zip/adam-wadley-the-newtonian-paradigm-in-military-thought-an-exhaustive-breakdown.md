---
title: 'The “Newtonian” Paradigm in Military Thought: An Exhaustive Breakdown'
subtitle: By... "Claude?" You mean, like, the monkey impression from Shaun of the
  Dead?
author: Adam Wadley
publication: Experimental Unit
date: December 05, 2025
---

# The “Newtonian” Paradigm in Military Thought: An Exhaustive Breakdown
[![](https://substackcdn.com/image/fetch/$s_!MRj0!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0d6e722c-167c-4180-80f1-d8011cd3ae00_1536x1024.png)](https://substackcdn.com/image/fetch/$s_!MRj0!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0d6e722c-167c-4180-80f1-d8011cd3ae00_1536x1024.png)

[Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) uses “Newtonian” as a shorthand for an entire worldview—not just the physics of Isaac Newton, but a broader epistemological and ontological framework that emerged from the Scientific Revolution and shaped how Western institutions (including militaries) understand reality and act within it. Here’s a comprehensive inventory of what this term encompasses:

* * *

## 1\. Ontological Assumptions (What Reality _Is_ )

### 1.1 Discrete, Objective Elements

  * Reality consists of separable, identifiable components

  * These components exist independently of observers

  * Things have stable, inherent properties that can be measured

  * The world is “out there” waiting to be accurately represented




### 1.2 Mechanistic Universe

  * Reality operates like a machine with interlocking parts

  * Components interact through defined interfaces

  * The whole is the sum of its parts (no more, no less)

  * Systems can be disassembled and reassembled without loss




### 1.3 Determinism

  * Every effect has a cause

  * Given sufficient information, outcomes are predictable

  * The same inputs reliably produce the same outputs

  * Randomness reflects ignorance, not fundamental uncertainty




### 1.4 Reversibility

  * Processes can be run backward

  * Original states can be restored by reversing changes

  * Time’s arrow is not fundamental to how systems work

  * Analysis can move from effects back to causes




### 1.5 Stability and Equilibrium

  * Systems tend toward stable states

  * Disturbances produce responses that restore balance

  * Order is the natural condition; chaos is deviation

  * Structures persist unless acted upon




### 1.6 Hierarchical Organization

  * Reality is layered (strategic/operational/tactical; macro/meso/micro)

  * Higher levels govern lower levels

  * Causation flows primarily top-down

  * Each level has its own appropriate concepts and methods




* * *

## 2\. Epistemological Assumptions (How We _Know_ )

### 2.1 Positivism

  * Valid knowledge is objective and verifiable

  * Facts can be separated from values

  * Observation and measurement yield truth

  * What cannot be measured is suspect or irrelevant




### 2.2 Reductionism

  * Complex phenomena can be understood by analyzing components

  * Breaking things down reveals how they work

  * Synthesis follows analysis: understand parts, then reassemble

  * Simplification is the path to understanding




### 2.3 Universal Laws

  * General principles govern all instances of a phenomenon

  * These principles are timeless and context-independent

  * Historical cases reveal enduring patterns

  * Future events obey the same laws as past events




### 2.4 Induction and Deduction

  * Knowledge accumulates through systematic observation (induction)

  * Principles, once established, generate predictions (deduction)

  * Logic is the arbiter of valid reasoning

  * Contradictions indicate error, not reality




### 2.5 Mathematical Formalization

  * Legitimate knowledge can be expressed formally

  * Quantification increases precision and validity

  * Relationships between variables can be specified algebraically

  * Models approximate reality with increasing accuracy




### 2.6 Explicit Over Tacit

  * Knowledge worth having can be articulated

  * What can be written down can be transmitted

  * Doctrine captures what practitioners need to know

  * Expertise means mastering codified frameworks




### 2.7 Objectivity as Ideal

  * The observer can be separated from the observed

  * Bias is eliminable through proper method

  * Multiple observers should converge on the same findings

  * Personal judgment is a source of error to be minimized




* * *

## 3\. Logical Structures

### 3.1 Linear Causality

  * A causes B causes C

  * Causal chains are sequential and traceable

  * Inputs lead to outputs through identifiable mechanisms

  * Effects are proportional to causes




### 3.2 Systematic Logic

  * Problems can be decomposed into sub-problems

  * Solutions to sub-problems combine into overall solutions

  * Procedures can be specified step-by-step

  * Algorithms capture valid reasoning processes




### 3.3 Binary Categories

  * Either/or distinctions are fundamental (war/peace, friend/enemy, success/failure)

  * Categories are mutually exclusive and jointly exhaustive

  * Ambiguity reflects incomplete analysis

  * Classification precedes action




### 3.4 Means-Ends Rationality

  * Goals are set, then means are selected to achieve them

  * Effectiveness is measured by goal attainment

  * Rationality means optimizing means-ends relationships

  * Strategy is reverse-engineering from desired end states




### 3.5 Optimization

  * Best solutions exist and can be identified

  * Variables can be maximized or minimized

  * Trade-offs can be calculated and compared

  * Efficiency is a primary value




* * *

## 4\. Geometric and Spatial Representations

### 4.1 Two-Dimensional Rendering

  * Concepts are depicted on flat surfaces

  * Relationships are shown through spatial arrangement

  * Visual representation equals conceptual clarity

  * What can be drawn can be understood




### 4.2 Euclidean Geometry

  * Triangles, squares, circles, cubes dominate

  * Shapes have fixed properties and relationships

  * Space is uniform, continuous, measurable

  * Geometric proofs model valid reasoning




### 4.3 Orientable Surfaces

  * Clear inside/outside distinctions

  * Consistent directionality (clockwise/counterclockwise)

  * Boundaries separate regions definitively

  * Movement through space is trackable




### 4.4 Arrows and Vectors

  * Direction and magnitude capture relationships

  * Flow moves from origin to destination

  * Causation is represented as directional movement

  * Time flows in one direction along depicted sequences




### 4.5 Containers and Boundaries

  * Domains are bounded regions

  * Things are either inside or outside

  * Borders define where one thing ends and another begins

  * Categories are spatial regions in conceptual maps




### 4.6 Centers and Peripheries

  * Systems have cores that matter most

  * Importance radiates outward from centers

  * Targeting centers affects wholes

  * Hierarchy maps onto spatial centrality




* * *

## 5\. Temporal Assumptions

### 5.1 Linear Time

  * Past → present → future in sequence

  * History is a timeline of events

  * Planning means projecting forward from now

  * Lessons of the past apply to the future




### 5.2 Phasing and Sequencing

  * Complex activities divide into stages

  * Stages occur in order

  * Completion of one phase enables the next

  * Campaigns have beginnings, middles, ends




### 5.3 Predictability

  * Future states can be anticipated from present conditions

  * Planning reduces uncertainty

  * Forecasting is possible with sufficient information

  * Surprise indicates intelligence failure




### 5.4 Freezing for Analysis

  * Time can be stopped conceptually

  * Snapshots capture system states

  * Static analysis reveals dynamic properties

  * Movement is decomposable into positions




* * *

## 6\. Methodological Commitments

### 6.1 Analytical Decomposition

  * Break complex wholes into simpler parts

  * Study parts in isolation

  * Identify causal relationships between parts

  * Reassemble understanding into comprehensive picture




### 6.2 Standardization

  * Common frameworks enable coordination

  * Uniform methods yield comparable results

  * Best practices should be universally applied

  * Variation is inefficiency




### 6.3 Process Specification

  * Valid methods can be written as procedures

  * Following procedures ensures valid results

  * Checklists and templates embody expertise

  * Deviation from process requires justification




### 6.4 Measurement and Metrics

  * Progress requires quantifiable indicators

  * What gets measured gets managed

  * Data drives decisions

  * Precision beats vagueness




### 6.5 Testing and Validation

  * Claims must be verified against evidence

  * Experiments isolate variables

  * Replication confirms findings

  * Falsification eliminates errors




### 6.6 Documentation

  * Knowledge must be recorded to be preserved

  * Doctrine codifies valid understanding

  * Written records are authoritative

  * Institutional memory is textual




* * *

## 7\. Organizational Implications

### 7.1 Hierarchical Command

  * Authority flows from top to bottom

  * Higher levels see bigger pictures

  * Lower levels execute higher-level designs

  * Unity of command ensures coherence




### 7.2 Functional Specialization

  * Divide labor by function

  * Experts master bounded domains

  * Integration happens at higher levels

  * Coordination requires management




### 7.3 Planning Primacy

  * Good outcomes require good plans

  * Plans precede execution

  * Deviation from plans is failure or adaptation

  * Commanders are planners-in-chief




### 7.4 Risk Reduction

  * Uncertainty is a problem to minimize

  * Information reduces risk

  * Contingency planning handles branches

  * Control prevents unwanted outcomes




### 7.5 Uniformity and Replicability

  * Same training produces same capabilities

  * Units are interchangeable within types

  * Doctrine ensures consistent performance

  * Individual variation is noise




### 7.6 Assessment Against Standards

  * Performance is measured against criteria

  * Criteria are specified in advance

  * Evaluation is objective

  * Accountability requires measurability




* * *

## 8\. Specific Military Manifestations

### 8.1 Principles of War

  * Universal tenets applicable across conflicts

  * Timeless wisdom distilled from history

  * Checklists for sound military thinking

  * Violation explains failure




### 8.2 Centers of Gravity

  * Systems have critical nodes

  * Destroying/neutralizing nodes defeats systems

  * Analysis identifies what to target

  * Borrowed directly from Newtonian physics metaphor




### 8.3 Levels of War

  * Strategic, operational, tactical as distinct layers

  * Each level has appropriate concerns and methods

  * Hierarchy of scale and scope

  * Borrowed from geological/archaeological stratification




### 8.4 Lines of Effort/Operation

  * Progress depicted as movement along axes

  * Multiple lines converge on objectives

  * Coordination synchronizes parallel efforts

  * Campaign plans are geometric arrangements




### 8.5 Ends-Ways-Means

  * Strategy is reverse-engineering from goals

  * Resources (means) enable methods (ways) toward outcomes (ends)

  * Logic flows backward from desired end state

  * Feasibility is means-ends matching




### 8.6 Phases and Transitions

  * Campaigns divide into numbered phases

  * Conditions trigger phase transitions

  * Sequence is planned in advance

  * Branches and sequels handle contingencies




### 8.7 Decision Points and Criteria

  * Key moments require choices

  * Options can be compared against criteria

  * Optimal choices can be identified

  * Decision-making is algorithmic at core




### 8.8 Course of Action Development

  * Options are generated systematically

  * Options are compared using consistent metrics

  * Best option is selected rationally

  * Wargaming tests options against scenarios




### 8.9 Intelligence Preparation

  * Environment can be analyzed in advance

  * Templates predict enemy behavior

  * Terrain and weather are variables

  * Situation understanding precedes action




### 8.10 Effects-Based Thinking

  * Actions produce effects

  * Effects can be specified in advance

  * Targeting creates desired effects

  * Assessment measures effects achieved




### 8.11 Spectrum of Conflict

  * Conflict varies along a continuum

  * Categories (peace, crisis, war) mark ranges

  * Responses calibrate to position on spectrum

  * Borrowed from electromagnetic spectrum metaphor




### 8.12 Domain Constructs

  * Operating environments divide into domains (land, sea, air, space, cyber)

  * Each domain has distinctive characteristics

  * Forces specialize by domain

  * Integration combines domain capabilities




* * *

## 9\. What This Paradigm Excludes or Marginalizes

### 9.1 Emergence

  * Properties arising from interactions that can’t be predicted from components

  * The whole being qualitatively different from summed parts

  * Novelty that wasn’t implicit in initial conditions




### 9.2 Non-linearity

  * Small causes producing large effects (and vice versa)

  * Disproportionate relationships between inputs and outputs

  * Tipping points and phase transitions




### 9.3 Feedback Loops

  * Effects becoming causes in circular relationships

  * Self-reinforcing and self-undermining dynamics

  * Systems that produce their own conditions




### 9.4 Irreducible Uncertainty

  * Unknowability that isn’t just ignorance

  * Fundamental unpredictability in complex systems

  * Limits to what analysis can reveal




### 9.5 Context Dependency

  * Meaning and effect varying with situation

  * What works here may not work there

  * Particularity that resists generalization




### 9.6 Paradox and Contradiction

  * Both/and rather than either/or

  * Phenomena that are simultaneously X and not-X

  * Tensions that can’t be resolved, only navigated




### 9.7 Tacit Knowledge

  * Expertise that can’t be articulated

  * Knowing how without knowing that

  * Judgment that exceeds rule-following




### 9.8 Reflexivity

  * Observer affecting observed

  * Analysis changing what’s analyzed

  * Self-reference and strange loops




### 9.9 Social Construction

  * Meanings created through interaction

  * Categories as human impositions, not natural kinds

  * Reality as partly constituted by belief




### 9.10 Temporal Complexity

  * Multiple timescales interacting

  * Path dependency (history matters)

  * Futures that aren’t extensions of pasts




* * *

## 10\. The Meta-Level: Paradigm as Invisible Frame

Perhaps most fundamentally, “Newtonian” names a paradigm that doesn’t recognize itself as a paradigm. It presents itself not as one way of understanding reality but as simply _how reality is_. Its assumptions feel like common sense rather than contestable commitments.

This invisibility is what makes paradigm shift so difficult. The Newtonian frame:

  * Defines what counts as a good question

  * Determines what counts as a valid answer

  * Specifies what evidence is relevant

  * Sets criteria for evaluating alternatives

  * Shapes what can even be imagined




To challenge it requires standing outside it, which the paradigm itself declares impossible or illegitimate. Hence Zweibelson’s effort to make the frame visible—to show that these deeply embedded assumptions are historical products, not eternal truths, and that alternatives exist even if they’re hard to articulate within the dominant vocabulary.

[![](https://substackcdn.com/image/fetch/$s_!Z_2-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9853ebde-c15f-4b98-a6e3-888fa44edc8c_1011x415.png)](https://substackcdn.com/image/fetch/$s_!Z_2-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9853ebde-c15f-4b98-a6e3-888fa44edc8c_1011x415.png)

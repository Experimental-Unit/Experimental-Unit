---
title: Dear Diary 8
subtitle: More Miscellaneous Thots
author: Adam Wadley
publication: Experimental Unit
date: April 12, 2025
---

# Dear Diary 8
There’s this thing called “The front porch campaign.”

It’s when you’re too good to go around running for office so you just take it easy and let other people talk for you.

That’s the idea here: I’m not going to do anything super crazy to try and get attention. I want that word of mouth game.

The problem for me is that there’s nothing I can do that guarantees I get famous.

There’s striking things, you know I could use the n-word and the swastika and the name of Grimes on a sign at a protest or something and freak people out, and maybe I will.

There’s all sorts of things. You have seen what white guys have been up to recently, setting themselves on fire, driving cars into things, shooting up schools.

Let’s be clear: I’m never going to try and get a gun, I’m not going to hurt anyone. Again, because that would cheapen my whole thing. I’m too good for that.

I will probably start recording Tik-Toks and stuff like that, releasing videos on IG. And my main message is just: get me famous. Trust me, you want that to happen. You think you can’t do anything? Help make me famous and I’ll show you what one person can do.

The whole world is conceptual kindling. Everything people say publicly is completely without basis and is ready to be destroyed by me.

I don’t act on behalf of any tradition or law or whatever. I’m not impressed with what you people have come up with so far.

There are places to start, with diplomacy and drawing down bombings and ending suicide and breaking the emotional spells that give the worst all the energy to break down poor innocent souls.

There are people to bring in.

People can have good little insights, again in their little speciality.

The problem is they will then try to be “reforming” normativity by making a little pocket for non-normativity in some little corner.

Fuck that. No norms anymore. The issue is again going back to Debord that people look at one little piece at a time and have no clue as to the bigger picture. That makes their reforms useless and harmful because they just shore up the illusion that normativity can be defended when it can’t.

So I will surely enlist allies, but everyone’s going to have to be broken by me.

And you are welcome of course to try and break me, but good luck. My cognitive security is perfect. Sure, you can disable me, make me reactive. But the fact is my ideas are the best ideas and it doesn’t matter if I’m screaming or crying, I’m still smarter than anyone you ever heard of.

Again, don’t trot out your John von Neumann unless they have a political philosophy worth a damn. Let them try to tell me how institutions must be respected and the costly implications blah blah blah. I’ll be happy to ford with them the philosophy of science and non-philosophy and the chains of abstraction and the background theories on which their judgments of me rest.

I’m sure that if I wind up educated by the conversation that it will be very interesting for all involved.

But what I’m telling you is that I accept any “cost,” to the point that it’s not a cost.

I don’t _give a shit_ about being persecuted.

I don’t _give a shit_ if I’m a laughingstock at first.

I don’t _give a shit_ if I’m tortured and killed.

What I give a shit about is sitting here and doing nothing while people commit suicide and a bunch of people run their mouths about it who are either unable to think or unable to be honest.

Either way, _NOBODY’S PUTTING UP A FIGHT_. I am impossible to oppose. Once I begin operations publicly, everything will change even faster and my genius will begin to percolate throughout everything.

Let me again be clear that the only purpose for which is it worthwhile to be assertive is for the cause of love. It’s always provisional, and of course I will always listen.

At the same time, _I don’t have time_ to respond one by one to everyone’s little objections which are the same wherever you go. I’d rather debate 8 billion people at the same time and win easily because I’m just correct.

So here I am, getting ready to go to work. Getting ready to clean my room.

Getting ready to just go about my day.

But inside it’s churning. I never forget for a single moment why I’m here.

We’re going to make discussion groups, and anyone who tries to dominate conversation and doesn’t listen will be excluded.

We’re going to send letters to key psychic influencers like Calvin Warren and Azealia Banks.

We’re going to have uniform messaging:

  1. Laws and norms aren’t real and anyone who appeals to them says only worthless things

  2. All sentient beings are important and must be accomodated

  3. Love is the only form of wealth and cannot be described (love is not a norm but dissolves them)

  4. Hatred and scapegoating are transitional forms that allow for the concentrating of attention on what must be challenged; their time is now over and all those who blame a single group or individual for “evil” are to be disregarded

  5. Love must become the dominant structuring principle on this planet, and everything that stands in its way must be obliterated, including institutions, law, money, personality crutches, bullying tendencies, lack of self-belief, etc.

  6. Proceed in the beginning with perfect respect with respect for your own fallibility, and then proceed into tit-for-tat. Let no cognitive affective imposition go unpunished. Teach people to respect your ability to destroy their mental and emotional frames.

  7. Always keep going with Tibetan Spiritual Warfare and Greater Jihad. Attack your own self-ignorance ruthlessly by putting more of yourself out there. You can only learn what others teach you. Not directly, but in their response to your experimentation. Greater Jihad: always follow the best emotions you have about your emotions, and continue to ruthlessly destroy yourself constantly even as you pursue the Lesser Jihad with all the infidels against love you find in your day-to-day life.

  8. We insist. We will not stop and we will not be deterred. There is no way that love is wrong, or that foolishness is right. We are here to exterminate the thought and feeling forms that make such deep inadequacy possible.

  9. We are oriented in our operations toward ALL SENTIENT BEINGS. No one deserves our respect presently. There is no soul beautiful enough, no voice moderate enough, no one to tell us about the “risks” of being too expressive when their boring timidity has led us to the edge of the gas chamber.

  10. Even if I am disappeared or die some other way, no matter what you learn about me, no matter what you think compromises me or whatever untoward intention you think I might have, it doesn’t matter because I see my own heart and I know how ruthlessly I pursue Greater Jihad. Unless I feel that same energy from you, your attempts to cow me will only lead me to escalate my attempts to break you.




---
title: Jauntology Jouse
subtitle: Ruin Value Derivation
author: Adam Wadley
publication: Experimental Unit
date: October 14, 2025
---

# Jauntology Jouse
[![](https://substackcdn.com/image/fetch/$s_!rCIa!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F20b99508-1eb3-45f3-ac24-eaa2e6e44312_1536x1024.png)](https://substackcdn.com/image/fetch/$s_!rCIa!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F20b99508-1eb3-45f3-ac24-eaa2e6e44312_1536x1024.png)

I quite like this picture.

Sometimes I feel I should be making many more AI-images.

The proliferation of AI content for me feels very psychedelic. It’s a good example of how things are not simply getting “worse”: they’re getting weird.

On a day like today I was sitting outside of the Army Transformation and Training Command, writing a post much like this one. Someone came outside and talked to me, told me that what I was doing was not normal.

Was it a weird thing to do?

In a world (“In a world…”) gone weird, there are increasingly only weird things to do.

Perhaps it is impossible to “be” normal. Could it become impossible to “act normal”?

Anyway, these AI-images visualize the arbitrariness of association. One is very easily able to make a CGI-type video which combines any elements one might wish to associate with each other. 

This is a first major way in which this AI-image/video “revolution” is violent. Words already have the ability to facilitate an infinite variety of juxtaposition. In simple text, one can refer to things most various, building an overall “payload” of arbitrary “logical type.”

“Logical type” in this sense means a level of reflexivity. It’s not just that I am doing something, but that I am telling you what I am doing. I am commenting on it. Like if I was writing a sentence and each word was made up of me typing letters, which I am doing right now to right this sentence.

With an AI-video mashup, one is able to copy the infinite variety of juxtaposition in text for images and videos which are much more viscerally attention-grabbing. I can write a sentence here about a dinosaur drinking tea, and it’s perhaps charming. Yet the same thing put into a prompt hits different and “richer” as an image.

On top of this, the “meta-reflexive” layer is added on, where the AI-image can be overwhelming not only because it’s showing you intense things, but also because (in doing that) it’s also commenting on itself, dropping a heavy cognitive payload.

We can say the AI-technology is doubly “violent” in the sense that it also changes each person’s relationship to themselves and their image without consent. One can easily show people doing things “they would never do,” breaking the conceit of the aura of one’s likeness. This change is irretrievable and processes as a sudden shock. 

It is difficult to understand the full implications of this until one has personally had their likeness used to create “AI content” which is targeted at oneself. This is an example where with Jean Baudrillard we can say that “reality is not distributed evenly.” Those who understand and feel this new form of “violence” or aesthetic rupture applied to themselves occupy a kind of higher logical type.

Here, for example, I’m using the likeness of [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions) in my cover photo. I didn’t give a detailed description, so it’s just what the software put for that person that time. Any imperfection in the representation is helpfully covered over by a fig leaf name tag.

They would be among the people whom people would more obviously make images out of, “famous people” or “celebrities” who “represent” not merely themselves but something in their creation, attitude, style, etc.

This is already a fraught relationship to one’s image, the psychic experience of the “famous person.” It is like your “image” or what you are to people is “getting away from you,” and you have to confront this whole phenomenon you’re associated with by being well-known as something outside yourself. You have to wake up and remember you are famous.

Now on top of that, the consequences of your “fame” are multiplying, as your likeness becomes something people wield toward all sorts of ends. It is a kind of representation which has never existed before, and is now deployed on a wide scale.

The “reality setting in” of it all will be as people have more occasion to make AI-videos of the people they know. In other words, as the technology begins to have more and more personal implications for more people.

As will be mirrored in the next example, for me what’s interesting is not how to “resist” this sort of aesthetic rupture, but the question of how to make use of it (thinking of [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) and “functionalism”). & perhaps a question of, “what does it mean about what images have always been that this is what has wound up happening?” 

The frog protesters have a simple idea they’re communicating: this is a person in an inflatable frog. They are not threatening. It is not a “war zone.” So, the people who have been sent there are not really there to “quell insurrection” because there is no violent engagement.

Something like this is the idea. The video above features a person who became very famous for being at a protest dressed as a frog and having some crowd-control aerosol sprayed in the air vent. Now, there are people giving away costumes on the street and mass proliferation of this idea. 

This entire episode is very instructive for understanding the “power” of performance art. This sort of behavior has very much shifted the “discourse timeline,” and although its impact is changing, more things like this in the future will also saturate the “discourse timelines” they unfold in. Reflecting on this instantiation may help us to anticipate, precipitate, and well adapt to these further unfoldings.

Funnily enough, the episode reminds me of Peter Thiel and the notion of zero to one and one to infinity. It also reminds me of Jean Baudrillard’s thoughts on Andy Warhol expressed in “Towards the Vanishing Point of Art.” They go together well.

Thiel is describing the initial conception and execution of an operational idea versus the copying of that idea and iterating on it to expand the initial kernel. It is interesting in a special way to come up with a new cartoon character as opposed to simply using established character designs in different ways.

As a jump, it has me reflecting on the idea that a show like _The Simpsons_ could “run out of ideas.” Even having infinite possibility space, there is something stifling about endlessly iterating on the same thing.

Hence the drama of trying to have a “second show.” The Simpsons creator did make Futurama. Look at The X-Files, though. That show’s creator never did really get a “second show” off the ground.

Anyway, back to the frogs. 

The person who initially became famous was not necessarily the first person to have the idea. So, the really big fooming of this event is not simply that someone had the idea, but the involvement in the dramatic video. We could even allow for “possible worlds” where the spraying of crowd-control aerosol was not hostile but a scripted part of the event. This is similar to theological speculations about Judas having to be part of the divine plan because “you can’t get to Easter Sunday except by way of Good Friday.”

In other words, there is no good without the bad.

And, is the frog phenomenon a Good Thing? “We’ll see,” says the Zen master.

Not to say that it must be a good thing or a bad thing. Is anything a good thing or a bad thing? “Is there something wrong with anything. Is that what you’re asking me?” - No Country For Old Men.

Still, the frog phenomenon is very interesting as an aesthetic happening. People wear a costume, and now many many people are wearing costumes, and the idea is being iterated on. The frog is “the most famous,” but this whole thing only really got going a few days ago.

To be honest, I am already a bit bored with it, perhaps because I don’t find the overall message very interesting.

For me, it’s a similarly bittersweet feeling as reflecting on the exploits of Greta Thunberg or the Van Gogh souping of Phoebe Plummer, or the oranging of Stonehenge.

These are all cool things and I am happy to see things catch a lot of attention which are not “destructive” in themselves. It is basically “theoretical violence” in practice, because it is a jarring happening and it’s playing out in “real life.” The people involved also take on a sort of sacrificial role because they expose themselves to being attacked due to their being visibly associated with a “side” within a highly charged mass situation.

So to shift gears and imagine how this could further play out, imagine that the person who was the first very “famous” frog protester was themselves killed. Or perhaps they were arrested for a crime and then it became disputed whether they really did what they were accused of.

Or say at a totally different protest, people in inflatable costumes do something which is considered “violent” or bad. Then the whole image of “costume = innocent” goes out the window, and we have a weird world of inflatable costumed partisans.

In other words, this gesture which is trying to defuse the “authoritarian” tension by trying to “show” that “over-the-top” measures are not called for can itself be supervened on by further actions of “performance art.”

This is where we are of course interpreting actions of “carrying out law” as performance art, cognitive operation type activities. This does not represent a perversion of “the law” but the revelation of what it always was.

The “frog protester” conceptually does not seem to grasp that “society” is more “militarized” than it is “politicized.” The logics at play here do involve what a great number of people think, but this attention and sentiment, in order to have great motive force, must be applied intelligently.

Back to Greta Thunberg. Here we must already apply some caveats, since this person is associated with many others who surely help inform their behavior & performances. That said, this sort of campaign for me is quite exciting. To see someone getting involved and speaking about issues of general consequence, I like that.

I suppose, to put it in a nutshell, for me it is that concern for all is bound up with concern for oneself. This is since, if one wishes to survive, one cannot be killed by the “social structure” on which one depends. If there are those who are killed or whose deaths are written in the plan of the “social structure” on which one depends (or any other one which one may have the opportunity to abscond to), then one must bank on not being the “kind” of person whose death is planned on.

For me, it seems impossible that if there are “kinds” of people who are planned to die, then eventually everyone will be planned to die. Even if deaths are not in some official plan, the escalating atmosphere of death will understandably bring out more distrust dynamics in those who are planned to live.

So, I like how someone like Greta Thunberg is doing things in the name of the climate or being against war or something like that. Perhaps instead of in any way explicitly endorsing any of this behavior, I’ll simply say that the license to undertake such activity for me certainly exists because of the large degree of “someone has to do something” energy there is lying around.

I believe GT even made the point that if leaders “don’t lead,” then it is up to other people. To crystallize my point above, I’m not saying a GT or Plummer or frog person is really doing leadership, but these sorts of behaviors are notable nonetheless.

One of the things I noticed that the “frog protester” said in their interview is that people should be treated as human beings, because that is what they are.

This is a good example of something to say which is simply a platitude. It is similar to when GT will say something about people’s “rights.” Or when [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) goes on and on about the “Free World” (even uses capital letters, just genocide me now please, lol). Or [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions) also, discussing “humans” this or that.

I’m not impressed by this lingo. For me it smacks of what Carl Schmitt called “classical concepts,” in other words “not good enough” concepts.

When people talk like this, sometimes I wonder whether they really “believe” what they are saying, or whether they are saying something about “humans” the way the aliens play “human music” for Jerry in _Rick and Morty_. Like yes, I love humans, especially those that support [your sports team].

Something like “Free World” is just the sort of oligopic branding that still works on some people.

Anyway, the same applies on behalf of the many “do-gooders” who want to “resist” and demand that those “in power” do this or that. Meanwhile, they are mobilizing established concepts which are calculated more to be appealing to people as they already exist as opposed to designed to influence a transformation in where people already are.

Maybe this is one way to articulate it: the thing is that people are transforming anyway, and we are in a transformational time. So, appealing to these conceptual “greatest hits” of “rule of law” and “human being” and “free world,” etc., is to be aiming at what (maybe not even) was as opposed to what is coming.

Still, these sorts of “jaunts” do drive things forward. The “frog phenomenon” is part of the story now, and if there is some “street battle” in the future, inflatable costumes may be present.

The “one to infinity-ization” of the frog phenomenon is fully in effect. For me, it’s notable how quickly the whole thing feels “played out” already. The question can only be what will happen next. If quantity has a quality all its own, what does it mean that there are now thousands of costumed protestors?

[![](https://substackcdn.com/image/fetch/$s_!8VnQ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9786dfc7-1449-4a62-b02f-924f004c2060_1024x1024.png)](https://substackcdn.com/image/fetch/$s_!8VnQ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9786dfc7-1449-4a62-b02f-924f004c2060_1024x1024.png)

To put another spin on it, another notable recent action of “performance art”/”terrorism” was the person who shot and killed people at the Mormon church and set it on fire. This person was later reported to have said that the Mormon church and the people in it were the Antichrist.

Meanwhile, Peter Thiel is also gallivanting around, shooting off their pretty little mouth about the same topic. [I like to think “ante Christ,” in the sense of putting Josh & Xity “at stake” in the design inquiry. Also “ante” always makes me think of Magic: The Gathering. Wanna see my “demonic consultation”?]

So, “the antichrist” is also a major poetic image of the moment. The same way that people can imitate the “frog protester,” people can also imitate this behavior of being concerned about “the antichrist” and building up this sense of dread by taking actions in the name of this apprehensiveness.

If we think about the actions of the frog protester or a GT or Phoebe Plummer, these actions and discourses are not set up to “protect” from a vitality from “antichrist” discourse. It’s not clear whether [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) is really up to the task. [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions) similarly (and I would also be in the category here) will overtly discuss cosmology and playing with these “top-shelf” stories and not merely in a “respectful” way where everything is in a glass jar.

Yet the question for us is still: are we wielding these stories, or just playing into them in ways where we are stuck in the conceptual gravitational field just like everyone else?

It’s reminiscent of what I wrote about in my _Metonymy Economy_ essay, this idea from Shelley that poets articulate influential formulations, but then people just get caught referencing them instead of deeply engaging with the constitutive complexity.

So, a [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) can sit here and tell you about how a Newtonian paradigm is too invested in the notion of “discrete objects,” yet also still advances a framing of “Free World vs.”, even though this framing doesn’t stand up complexity-informed scrutiny.

Similarly, a [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions) can make conceptually sophisticated art, and match it with some gestures in “the real world,” but when push comes to shove and many people are very concerned about where things are headed, they default to not trying to do too much.

Again similarly, a Greta Thunberg in a way takes formally advanced steps, the notion of such a young person addressing the United Nations, or being in a flotilla, etc., is a remarkable sort of “performance” that few people achieve. It makes for a vibrant “concept handle,” yet what this handle “links to” is ultimately not something alive but something which still stands to transcend itself.

And it’s similar again with the frog protester, not to mention Peter Thiel or the church shooter invoking the antichrist. All these “performances” are stagings of gestures which abstract over well-known terms and take understandably striking actions for relatively easily discernible causes.

In my mind, they are all still “playing the game” by “coddling the minds” of their audiences.

One way to put it is that, again, things are transforming. These sorts of discourses are not doing enough to transmit to their audiences (sympathetic or otherwise) the necessity and reality of transformation. If one is not only being disrupted but is oneself an instantiation of disruption (change or motion, see, Parmenides) itself, then continuing to double down and get stuck in cliche concepts like “human,” “democracy,” “law,” can only hold back the expression of something truly conceptually being able to meet the moment.

The “antichrist” discourse I might say is the most “top-shelf” of them all, as this concept tries to be the ultimate scapegoat, gathering together responsibility for everything which can go wrong. This at least acknowledges and narrativizes all the over-the-top destruction and gore and so on which pervades “existence,” and which escalates in this time where everything is “coming to a head.”

Meanwhile, something like “human” or “free world” or “democracy” is clearly second-order. All these conceptions can be sacrificed as things become truly dire. It’s like when things are falling apart out in the bush. I’m thinking of the movie _Aguirre, The Wrath Of God_. They’re not even really believing in democracy, maybe some idea of holiness, the way some people are carried around and kept clean(er), the emphasis on religion. Yet the sentimental side of the religious conviction falls away, and it winds up being a meditation on the confluence of the individual person and the forces of cosmology themselves. The Aguirre character calls themselves “the wrath of god” (see magic: the gathering card which destroys all creatures), and we can understand “the antichrist” in a similar way.

Yet even “the antichrist” as invoked by a Peter Thiel or this kinetic attacker, this is also I could say not at a high enough logical type. It’s not exactly a question of whether one “really believes” in the antichrist, where not really “believing” in it but invoking the reference would give one a higher degree of symbolic mastery since one could wield the symbols without being tied down to established normative conceptions of them.

That’s because one can advance one’s own normative conceptions of them, in a way which might disrupt the operation of normativity. We could begin to discuss the transnormal.

Anyway, the issue with “the antichrist” as advanced by Thiel or this Mormon person is that it’s just doing another version of scapegoating within a story which does not challenge classical concepts.

Thiel, for example, will discuss how it’s getting harder to keep autonomy over “their wealth.” Now, no one has any wealth. This is what is being revealed by the heightening stakes of technology itself. The illusoriness of the conceit of the public/private distinction to becoming impossible to ignore.

See how churches and schools, everything must become a “hard target.” This is a “military” logic taking over everything, and it’s not a function of some “bad actors” but a structural emergence, “emergent gameplay” given desperate conditions and ambient level of cognitive operation.

Thiel also discusses the idea of a “one world government” as something bad. The issue here is not acknowledging that in some sense there has never really been “a country,” not to mention the deep anxiety which must exist now “within” any country. It’s not just about “values” or whatever, but simply that technology is now becoming so strong that anyone is expendable, anyone could die.

It might be helpful to “be rich” in some sense, there are certain things one would likelier survive, but one also paints a target on one’s back. This is not simply from people “lower down” who are jealous or think you are “oppressing” them, but from relative peers with whom you are in “competition” to capture “the grail”/”the ring”/”the philosopher’s stone” of AI.

Hence, in my opinion a more advanced notion of “the antichrist” to put forward in such a “performance art” would precisely not to call some other group of people the antichrist. To me, it seems much more radical to self-apply the label of “antichrist” to oneself. Now, this could just be seen as “edgy,” just doing that doesn’t give you cache in and of itself.

Yet, I would say in a cheeky way “logically,” this is more interesting because is disrupts how the concept is conventionally deployed. In particular, this “scapegoat” logic is in general something to be commented on. It’s the way that we want to say that someone else is trying to bring on the apocalypse, the “end of the world,” “chaos,” and so we’re going to stop them.

When “in reality,” as Baudrillard wrote, we all have the apocalypse in us.

This is something I’ll be continuing to write about as I watch the rest of _Serial Experiments Lain_ today. Here’s where I’m watching it. I can’t read the text in the episodes after the first one, which is sad. Still, it’s quite interesting.

I found out about this show from [this article](https://baudrillard-scijournal.com/getting-lainpilled-towards-a-definition-of-the-hypereschatological-condition/) by [Alex Mazey](https://open.substack.com/pub/alexmazey).

[![](https://substackcdn.com/image/fetch/$s_!sHQX!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F09c25c42-bff3-4995-8d21-7104b5d4b2ed_801x532.png)](https://substackcdn.com/image/fetch/$s_!sHQX!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F09c25c42-bff3-4995-8d21-7104b5d4b2ed_801x532.png)

It finishes up with this reference to Baudrillard’s “theoretical violence.”

> It is not necessarily the similarities in their theories of positivity, transparency, or overabundance that links these thinkers with the hypercultural conditions explored in _Serial Experiments Lain_ but rather the rejuvenation of negativity as the overarching project of the works mentioned therein. ‘Theory in the strong sense of the word is a phenomenon of negativity[…]’ where, ‘On the basis of such negativity, theory is violent.’[[64]](https://baudrillard-scijournal.com/getting-lainpilled-towards-a-definition-of-the-hypereschatological-condition/#_ftn64) Han writes in _The Transparency Society_ , striking another uncanny resemblance to Baudrillard’s ‘Theoretical violence’[[65]](https://baudrillard-scijournal.com/getting-lainpilled-towards-a-definition-of-the-hypereschatological-condition/#_ftn65) ( _Simulacra and Simulation_ , p. 163). It is this rejuvenation of the negative shadow that also runs in anime as hyperstitional theory fiction, the negative essence of _Serial Experiments Lain_ in particular finding exacerbation in a messianic schizophrenia more preferable to the transparent utopia Lain ultimately comes to leave behind in the process of having crossed over completely. There is perhaps no way back for her now. From the politicians who promise to deliver us from the evils of the world to those who promise to deliver us from an earth that, in their minds, cannot abide for ever, it may be the case that this messiah complex, which is exhibited everywhere today, has become the phenomena par excellence of the (hyper)eschatological condition.

I feel my jaunt coming to an end.

I’d like to point again at the frog costume thing as a good example of the “power” of “performance art.” Basically, it’s acting in a contrived way designed to make in impression.

The concerns of a [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) when it comes to “asymmetric conflict” and so on will increasingly mirror the interests of “resistance protesters.” Everyone wishes to stage “set pieces” that earn “points for Gryffindor,” whatever they perceive that house to be.

So far, regardless of how “extreme” political statements become, even the massive kinetic attacks by “states” or the very destructive “kinetic” attacks by “lone wolves” or “terrorist networks,” the concepts which go along with the dramatic action leave something to be desired.

Baudrillard wrote somewhere that people will vote for those who don’t ask them to think. Well, that just shows the limitations of what we call institutional democracy, because just like “the enemy gets a vote,” so does the situation in general. We might wish that it were obvious that some notion of “the human” or “law” or so one should obviously be preserved, but in the meantime to draw from Ofra Graicer there is “drift,” we are not stepping in the same river anymore. And to echo a sentiment [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) has advanced, many times “legacy concepts” weren’t even really applicable when they “dropped,” they merely reflect network effects around referring to things a certain way.

It remains for very visible and “famous” striking actions to go along with genuinely challenging conceptual material. Perhaps even not merely to gesture toward self-disruption, but to emphasize that this is what one is doing. It’s not just a call for people to “self-disrupt” in the way one is saying (since also in some sense this would not be _self_ -disruption, but simply you disrupting them to be more like you (want them to be)).

But rather, a call for more artist-scientist-operators to be themselves thinking interestingly and making interventions designed to inspire still more designers and so on.

To wrap up, it’s something I’ve got to bring out more my “spiritual” conception of democracy which ties into Baudrillard on gaming. I will talk crap about “democracy” but it’s also important to aver that for me, I would consider that I affirm the only “real” democracy,” which is simply that everyone gets to make their own choices (to the extent that people make choices, but if people don’t make choices then the notion of “democracy” kind of loses its import since we can only “obey” whatever induces action).

We can tie this into Epictetus, but also in a spiritual sense if everything partakes of “creation” then our choices have the high symbolic value of affecting part of the all-that-is, which in turn has implications for everything else. Since everything is connected.

So, to spend all this time trying to “protect” what I’d call “institutional democracy” for me is missing the point. It’s not pointing at the real treasure, which is the “freedom” we always have to take the actions that feel necessary to us. Perhaps this is because the “influencers” don’t really trust the decision-making of people. It’s trying to be encouraging and induce change, but must be careful always to apply conceptual blinders so that people don’t get any “messy ideas.”

As per the “democracy of gaming” in Baudrillard, we can apply this to our situation as if this plane of incarnation were a giant MMO-ARG. The democracy is that we each appear as different characters and get to play our play-through as we see fit.

The gesture of acting outside of customs, only to contain the whole thing within retrograde customs, is only a half measure. It’s only a matter of time before something “takes the top off” such discourse.

I think it is much preferable for “classical concepts” to fall by the wayside through “non-kinetic” means, which is why I’m beating the drum on this topic and trying to inspire more people to undertake their own systemic design inquiries and take action. We are not limited to simply commenting on other actors, but all this is fundamentally also our performance. Being concerned about self-disruption means that we are focused on how we and people “like us” must change, not merely oriented toward some external scapegoat.

Next time I’ll ramble on a bit more! Thanks for reading.

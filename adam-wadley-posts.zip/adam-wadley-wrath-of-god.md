---
title: Wrath Of God
subtitle: Smite All Nations. They Can't Be Regenerated.
author: Adam Wadley
publication: Experimental Unit
date: May 16, 2025
---

# Wrath Of God
[![Wrath of God \(Limited Edition Alpha ...](https://substackcdn.com/image/fetch/$s_!tMsZ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F84e05a9e-c484-4475-89f3-212054555ed0_191x263.jpeg)](https://substackcdn.com/image/fetch/$s_!tMsZ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F84e05a9e-c484-4475-89f3-212054555ed0_191x263.jpeg)

My internet is so slow that this is the best I can do in terms of showing you the double meaning.

Today I was reading about [Gertrud Scholz-Klink](https://en.wikipedia.org/wiki/Gertrud_Scholtz-Klink), who was like Head Girl of Nazi Germany.

It has me reflecting on the trope—it’s a bit light to call it that, isn’t it?—of “male” domination. Maybe especially the trope of the Nurse Ratched like figure, who isn’t like a military commander or anything, but still exacts the strictest of discipline with the harshest authority.

Which sort of raises the question my way of, me and what army?

My army is _you_.

This is the path of radical acceptance. If you accept all outcomes, then all activity serves your purposes.

I’ve made up elaborate stories about this. The afterlife is key because if you look at it a certain way, deaths are basically stories where there is no more possibility for a turn-around.

So then either you have to “romanticize” or else otherwise vindicate the actual experience—and to be clear we are talking about the people who have suffered the most, I won’t bore you with the details—which was had; or else you can posit an experience after death which makes it all worthwhile.

It’s also possible to merge these stories (always a good move in my opinion unless you’re overlapping scapegoats which is most un-triumphant).

This is the virtue of Fyodorov’s Common Task, which is to make everyone immortal _and_ resurrect all the dead.

The question then would be where the dead _are_ now, if they can be resurrected later.

Obviously I can’t tell you that I know the answer, but obviously the answer is in the spirit world.

This is again elaborating on America DLC Pack where we are unlocking spiritualism expansion pack. Also plug in all near-death experiences and so on here.

So actually, ahem.

You know I hate—just kidding you know I love it—to improve on Fyodorov, but actually we can add more to the Common Task. Also, by the way, one of the things I’m trying to underscore to Grimes/Claire Elise Boucher in terms of “The Mission” is that Fyodorov’s Common Task is relevant.

Me just looking at it right now, Fyodorov sets a goal superior to, for example, Dugin. As much as Dugin wants to say that they’re advocating for Russia and some culture or civilization or whatever hogwash comes out of that person’s face and hands; as much as all that Fyodorov’s Common Task is one of the true treasures to arise from a territory associated with this “Russia“ thing.

Ah, but before I forget:

  1. Make everyone immortal

  2. Resurrect all the dead

  3. Allow everyone to flourish so that creation is vindicated and all people think life was worth living




This is the final plank which completes the redemption of creation. Not just that everyone comes back, but also that the experience is perfectly satisfying.

I would also point out that we are entirely on track, but I wanted to jump back to what I was saying before.

Ah yes, in all cases, if I am faced with a “nationalist” who thinks that a single person must be harmed in order to serve their nation, I tell them that they do not believe enough in their nation.

Self-defense is a cruel necessity.

At our point though, it’s clear that defense can only be achieve proactively, not by attacks which destroy the _capacity_ of other parties to harm us, but instead through active measures to destroy the _desirability_ of harming us.

In other words, my contention would be in the deep future, by which I mean in like 2 years, then you will not be safe because you have a perfect shield, but because no one wants to harm you, and in addition no one harms you by mistake.

With me it is just the opposite: I don’t want to harm you, and I harm you on purpose. That’s because what I do is not intended in a harmful way, but at the same time it is known that it will cause harm.

The way in which you finagle it to be such that no one wants to harm you is to mobilize your discursive resources. Use your words. And all your art.

This is connected to another plank of my ever developing platform: everyone is a life artist.

This is another place where part of the important think about my point is that it is not aspirational. So compare: instead of saying that we should abolish war, I can say that we stand to recognize that there has never been a war and never will be.

Similarly, it is not that everyone would do well to think about art and really make every gesture a brush stroke. No, I tell you that it is already so. And so we might contemplate what sorts of artworks we will leave behind. Talk about good ruins! 

Good ruins also now assumes a pun where “a ruin” is a time where you ruined a concept or something else. So if you are a true epic poet you will ruin a bunch of stuff. Of course, with the Common Task above, everyone will get to ruin everything in their own way, so that every tiny piece of creation bears the infinite moldings of everyone’s hands.

Anyway, again what I’m telling what I’ll call the vulgar nationalist, by which I mean basically everyone. When I say “vulgar,” I basically mean you. It means someone who doesn’t understand what I’m about to say, but the risk is that you will think that I mean there is some other set of people I’m implicitly referring to who are “not vulgar” besides me. Is that rude?

I saw someone on Twitter joking that their 150 IQ friends are spouting of heterodox theories about politics, economics, and philosophy.

Exactly, and _not_ military strategy, or else Ben Zweibelson would be world famous already. I guess it’s like a symbiotic thing, I should make Ben Zweibelson more famous by continuing to be a glorious shitshow, and then Ben will achieve some sort of escape velocity and then I’ll just be part of the story.

But see, that’s not good enough. That’s not fast enough.

The thing is that I’ve been fucked up since 2009 or whatever thinking that maybe we only had a couple years left. But it’s finally true!

It’s also a think about the end of the world that most people would be sad about it, but that’s because people only think about life that it should just go on and on, in other words there is no purpose. Most people don’t die with any purpose, you just kind of go along. In this sense, suicides at least have the notable feature that someone died with a purpose, similar to going into combat or rescuing people, or even doing some daring thing like rock climbing.

On the other hand, the idea behind the Common Task is basically, if you recall, when we last left our lovable heroes (all sentient beings) they were being immortal along with all the dead and being fulfilled. 

At that point, what is there to do except start the time warp again?

That’s right, at the end of my cosmology all sentient beings ever all choose to do creation all over again because, I mean, you did everything there was to do. What else is left but to start over?

Arahats or if you look at it Law of One style you know the selfish people, they might basically get there just pursuing power and pleasure, the thing is that if you level that up then you eventually get to refined states where service to others comes back on the menu. Or, you basically “place out” because you realize everyone’s going to be fine anyway so you basically just subsist in bliss, although again it’s because you know someone here in creation is going to figure out how to resurrect you, so you’re kind of just freeloading on the group project.

Meanwhile, Bodhisattva is more like you’re going to help everyone get to this place where we all actively want our lives the way they have happened.

So that’s the sense in which we can start to see how we are on the right track.

Because as you can tell, things are not only getting “worse,” they are also getting weirder. Kanye West is not only dangerous/evil, but very _weird._

You had Russell Brand still going off about how this is “postmodern” art where everything gets mixed together.

Yes, the start of the line in Baudrillard is about things that haven’t self-transcended. That’s exactly what this moment is aching for, and from all of us as well.

This is the vindication of “self-help” not in content but form, it’s another form of the snooze alarm, another metonymy. You can think of it like yeah, you need to implement initiative so you can be successful.

It’s also relationships based. You can establish deeper connections with people and pursue greater purposes.

To the above, it’s like Baudrillard wrote: what are you doing after the orgy?

It might be another way of saying something like Marx, where Marx would say at a certain point the mode of "governance” can no longer accommodate the technological infrastructure which is being developed.

In other words, we are actually ready for whatever comes next, after this Kanye moment. The question is what is it? And it doesn’t have to be bad.

But, if we remain rigid and fearful, and not changing and taking initiative and actively looking to make costly mistakes because that’s the only way you’re really try and experimenting in the field. _Experimental Unit_ , remember. Imagine testing rescue techniques in the field, the casualties.

We tread the paths where no one goes.

We carry news [gospel] that must get through.

To build the dream [Svarga] for me and you.

But, if we don’t go where we must go, then the signs are only going to get worse and worse, until it’s not a song on the internet, it’s people coming into your house and taking you.

So, in that context, what am I even doing?

One way of saying it is that I’m hiding behind the idea that _Experimental Unit_ is a game. I am telling you that if you play my game, then… 

Well again, that’s not it, is it?

What I’m telling you is that you’re already playing my game. This same sort of thing as been said many times before, of course, these various Absolute Exploits.

Then again, it’s not actually necessary to do it all, is it? Just to play one’s role, just like anyone else. There are only householders, householder-messiahs. Vanishing mediators all.

 _Experimental Unit_ arises from the kind of simple recognition that should have befallen the henchmen in the opening of _The Dark Knight_ , and that poem about “first they came for” is relevant as well.

Part of my point is that you will get picked out by any system which picks anyone out. When it comes down to it, hairs can always be split and there will be conceptual contagion having to do with the tendency of any category to break down. So any bigotry or big focus on differences will run ashore on the rocks of what exactly counts as those differences, and everyone different perspectives and motives about what should count.

So, if basically social decision-making is muddled because the categories don’t actually obtain, then making the stakes of that decision-making life and death is just going to eventually lead to your death. 

It’s an issue because we are quickly getting to the point where AI could easily be used to murder exactly whoever someone wanted, for example.

But then, if you empower a super duper computer to kill people based on its own decision-making, how do you know it won’t kill you?

End of the world type shit is understanding that this is not a question for fifty years from now. This is a question for _right now_. 

Yudkowsky and so on have a new book again saying that there will have to be “international agreements” to curb AI dangers.

That’s a euphemism. What you’re talking about is the end of the conceit of national sovereignty.

Even as, again, I’m saying I’m a superior nationalist to all these bigots and chauvinists. I might talk like a bigot sometimes but I’d never enact a bigoted policy, and I’d never lie about the sovereignty of the “nation” or “state.”

What is sovereign is basically people. I’m just claiming Epictetus here: some things are our own actions and everything else is other people’s business. We can engage in the conceits of “the law” but we can also understand that this can all be ripped away. Epictetus sure did, and basically said it was better to starve and have honor rather than become a slave to get a position.

So building up from people is social networks.

All people have to be reared, and so this is basically the stamp. When you are looking at people you are looking at who raised them. Which is why someone needs to talk to Stephen Miller’s parents if they’re still alive.

I was reading today about how Heisenberg’s mom called Himmler’s mom and asked if Heinrich could go easy on Werner.

This is the kind of gesture which completely throws the whole thing into relief.

Because at the same time other people are getting like killed and stuff, and the mom is going to make a call about this? But also it makes sense, you can make a difference because it is this personal thing, it’s like a throwback.

And it’s actually what Volksgemeinschaft is all about, the use of this “soft power” of influence in a way which takes all the wind out of the sails of the tough people who want to use force to dictate ontology.

So back to Gertrud, this basic use of force by “males” to instill their ontologies. _Anti-Christ_ has me thinking of terms like gynocide and femicide, and I would go on to say that it’s really also like female genital mutilation of the Astral Pussy, but for everyone.

It’s beyond “castration” as imagined by psychoanalysis, which I don’t even really care to understand but I basically read it as the humiliation that you are “a being” and not Allah, that is not Being itself. You are only one of many things and so in that you are not special and you will just be ground up one day perhaps unceremoniously.

More than that, the kind of circumcision I’m talking about you could say it’s like breaking someone’s Inukness, it’s destroying someone’s stubborn emotive will, it’s depriving them of the ability to take things in, it is stunting their receptiveness.

“Masculinity” will be associated with not being penetrated, although of course all “manly” apex social networks through all time have included “homosexual” sex and rape among such people. The point is that they would never be fucked by someone _lower_ than them.

This is the basic formula down to the “nuclear family,” where the “male” head of household may well rape everyone else there. And even if they don’t, they _could_ and probably get away with it, which is not nothing in terms of a psychological wage and albatross.

And of course we people will lord it over anyone we can. There is so much to be angry about and so many people we find susceptible to our anger.

Even someone who is quite low on one hierarchy might still find someone even more helpless than they are. Now you are talking about verbal and otherwise abuse of children, or children hurting animals.

It reminds you of the “Karen” meme, but it really is everywhere you look if you can only see.

If you look, you can see it is: everyone is turning into Adolf Hitler. Not in terms of being an antisemite, but in terms of descending into this rage because one has been overlooked, one has been betrayed by those who were supposed to be looking out for you, and now it seems that all there is to do is to go on the attack. 

And at the same time, it is easy to see where this idea will lead: to the Fuehrerbunker and “the walls are closing in,” and all of a sudden suicide really is on the bright side.

In terms of the cultural singularity and eschatology and so on, you would wonder why now? 

Basically, you have as I’ve said this _Zeitgeist Weltschmerz_ where the negative emotions are getting maxed out because of hostile social environment and much suffering. Everyone is turning on each other, it’s not just one or another set of scapegoating.

In actuality, everyone is leaning into scapegoating, and I’ve got to escape the “you’re scapegoating scapegoating” allegations. Still, it’s easy to see that people’s views can basically be exterminationist if they have no positive plan for people to overcome the challenges we’re facing.

Jreg I think made a video a few days ago talking about how we’re going to machine gun people at the borders in the future. As I said when I made _Solution Space_ , my ex-show, the idea was that billions of people would _not_ die this century. 

And again, by _this century_ read like in the next two years.

If we are at the part of the story right before AI clicks on, then everything that happens now is super important in setting the “shaping phase” for whatever comes next.

Why would a computer care about our little squabbles over this or that story? These group allegiances?

Competing nationalisms and tribalisms just look like a bunch of people blaming each other for working in groups that are willing to harm others to advance themselves while working in groups that are willing to harm others to advance themselves.

For me, again the question is not normative but positive. It doesn’t matter if you are willing to harm others to advance yourself. Harming others in fact does not advance yourself.

Because again, great you have more money or whatever. Again, we are on a two year or less timer where technology is making everything you think is relevant irrelevant.

So all that matters is influencing the conditions in which the technology is used, which includes social conditions yes.

We are remaking the whole surface of the planet, which is again total full-spectrum involution. We are at the part of the story where everyone is turning against everyone else.

And with good reason!

We can talk about how people are being “manipulated” by propaganda, but the question is what were those people even doing before?

People only ever pursue little mini-goals that are advertised in the media and exist because of society, meanwhile the whole apparatus that makes “being a doctor” relevant might just suddenly change. And yet people just dedicate years to study something that could just become irrelevant. And those people are so successful and I am so crazy even though the stuff I’m interested in will be relevant for a whole three weeks or whatever until AI can do whatever I’m doing better than I can anyway.

This is nine billion names of God territory where the issue is not that the AI is somehow spoiling our fun of the universe, but that it is ending the world and at every point just being able to show how this is in fact the logical conclusion and yes this outcome was implied by everything we ever did.

This is the sort of moment which becomes like that bird picture in that one sci Fi story that makes you go mad, like the lamp in the Reddit story that makes you realize you’re actually in a coma, the line the story that’s really someone out there telling you to Please wake up.

To wrap this back into the nation question the thing is: what is the purpose of the nation? Or similar to people going on about genetics: you think genetics matters at this point? We will be able to genetically engineer living beings if we want to. Not to mention no one ever mentions resurrecting the dead. It’s obvious that that would be a complete magic thing that would make people go fucking crazy.

Anyway, you know, what is America supposed to achieve? We keep going, we take the world, we go to space, but it’s like, what are we going to do? Just the same shit over and over? Why? Just to say we went to every galaxy or whatever?

And at no point are people actually going to learn how to have a good time? Is that what you’re telling me?

Because I don’t think people are actually having that good a time. It’s part of why I don’t feel that bad even though my macros are questionable. Because it’s like, where is it that people are having these unconstrained yet focused talks I want to have? It seems like it’s not happening. Maybe I should do Twitter special so I can do spaces, those seem interesting. But who to do it with? Someone nice who wants to know about my ideas.

It’s not the kind of thing I want to argue a bunch about. I am happy to learn about more things, but people who automatically basically want to call me the devil and they can be Josh is just too much stress. I don’t see why it should be an inquisition, but at the same time I suppose that’s what it has to be if you attract attention. Still, I’d like to avoid that.

I don’t really want to be famous for like yelling at people in conversations. The conversations themselves should be exploratory. Ideally I could interview like multiple people at a time and play them like a symphony, asking them questions one after the other choosing which expert to call on when or which artist and what to ask them so that it makes a really interesting thing.

That’s basically what I do by jamming things together.

I was thinking today that no one really reads what I write. Are you proving me wrong? Sorry for doubting you if so. What’s nice is I’m such a jumble that you never know what the next line will bring.

It is still a bit of a crisis of confidence. I am very angry, but also cognizant that what’s best is to have more of a plan, something thought out, sharpened like a spear.

It is pretty good the payload I’ve created, I am kind of happy about certain aspects of what’s going on. Overall still dissatisfied but also thinking I can’t just, like, find people to talk to without being out as who I am. With the Old Wheat thing I’m not really out, but the people involved basically know that I’ve been wilding interpersonally as well. Again, there is anger but it’s also obvious that I’m a hothead. 

But, that’s destiny, and I stand by all my plays and always will. 

Just like I would never ask you not to stand by your play.

I’m not sure if I dropped this on you yet, but apropos of this theme of “male” domination but it’s also just this clippedness, that why circumcision is such an apt comparison. It’s this deadening of feeling, a bunch of emotional lepers we have walking around. It’s a combination of submission and mutilation of the constitution such that this having been broken is manifest in one’s ever present broken-ness, like if someone cut off your ear to humiliate you, now no one can look at you without thinking about the ear.

This is the sort of stigma we attempt to apply to one another, so that you can never forget, so that this must be part of your role, so that everything you do is a commentary on this.

This is again back to each sentient being having their say. There is no way around this, only acknowledgement of this reciprocity. Not acknowledging the reciprocity makes the snooze alarm worse.

We see what gashes are being opened. The conversation is turning toward conceptual art, and you can see how relevant my work is. I’m not sure if I’m scaring people off by being so out there, of if no one too much cares, or if any influence I might have could just pass around a bit.

But that’s okay, because we’re all in on this. The question of what you think will happen has everything to do with where you think things came from.

Back to Morpheus and Merovingian.

Morpheus says choice, Merv causality. They are both right.

The choice of God or Shakti to become creation is a choice, and then there is also the conditioning of that choice. Where did God come from? Where did Shakti come from?

My answer would basically be endlessly repeating universe(s) which have this recursive structure that I describe. I’m personally down to go to other universes and go the Common Task+ there as well, I also think we will go to the Pure Land and Svarga. I say “build Svarga,” but it’s more like we are there.

That’s again it, this deep intuition that we put ourselves in this situation for a reason, and part of the reason is the fun of being able to look for what is convenient even though it doesn’t seem like it is.

That motivates lateral thinking, and continually wondering what we are missing, what we are taking for granted that might not be so, what avenues we can explore.

It’s also going to wind up being building together work and play. Play is getting more like work because it’s fun to play with ideas, relationship commentary, etc., things that are working up to big conceptual work or are it already. Meanwhile, work is coming into play as things are games or tech becomes so powerful that it’s ridiculous what can be accomplished.

But so basically the end product of society is just hanging out, people talking in rooms or with scenery, doing some activity. So this activity itself must become more productive. Conversation is the infinite serious game which is just preparing you endlessly to have more conversations. Each conversation is an alternate reality game in itself, the game where the conceit that you are talking to X person about so and so allegedly makes sense.

Do you ever get afraid that someone in conversation is going to act like you’re crazy because you jumped to a universe where something crucial is different? Like they spell it “Edgar Allen Poe” and it’s like _Twilight Zone_ meets _HP Lovecraft_? Or is that just me?

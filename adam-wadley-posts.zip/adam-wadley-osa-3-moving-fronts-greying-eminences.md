---
title: 'OSA #3: Moving Fronts, Greying Eminences'
subtitle: 'TL;DR: Shock Sup More Black Gore Planned Fun Lore Floor Strife'
author: Adam Wadley
publication: Experimental Unit
date: May 02, 2025
---

# OSA #3: Moving Fronts, Greying Eminences
(Subtitle is a play on the line “Lock up your back door and run for your life” from the song “TNT” by AD/DC. One of my little things maybe others did it before is to replace each word in something being alluded to with a word which rhymes, more appropriately each syllable. It works well when all the words are monosyllabic like this)

I’ve been “studying” a bit more about Operation Barbarossa.

What strikes me about the war plan for invading the Soviet Union is how poorly thought-out it is.

It does not see that logistics is the most important thing.

It appears to me either that the strategy has to be a quick decapitation because you think Soviet Union is so dependent on centralized command—in which case the issue of “administering” tons of “conquered” land which is in fact inhabited by tens of millions of people who may well become partisans—or you are pre-empting or getting some more limited goal, but not trying to go all the way.

With this in mind, it’s obvious how the “military” force which engaged in Operation Barbarossa was inadequate to the job. It’s hard to see even if certain things had gone much better for the invaders that there would ever really have been much success.

One thing people talk about over and over again is the strategic liability of exterminationism as an ideology and policy.

When you explicitly want to kill everyone or at least a lot of people, and also are not concerned with the broader people because they are to be enslaved or exterminated later, well, um, that’s bad vibes.

Smash cut to our situation, because we have similar things. For example compared to the peasants in the Soviet Union, you can see that everyone is dissatisfied. “Rage capital” is doing great, I think Lenin talked about that?

Now bring in Trotsky with Uneven and Combined Development of rage: people getting mad at different rates. And what are the consequences of that anger?

The point is that you can intervene into billions of disaffected people, but if your approach condemns them, if you don’t actually care what happens to them, then your approach is not convincing.

You can always of course seem to care, this is considered Machiavellian.

I also simply think there is room for claiming a higher brand of prestige by advocating for planetary matters directly, and not through the mediation of the question of the interplay between “nation-states.”

We have seen how internal documents themselves show the urgency of thinking beyond within around through and so forth, everything about the nation-state except taking it seriously on a first-order basis.

With that in mind, the question is not really about transnational America or any national grand stylistics, Pan-Nationalism is getting there but the cement which glues together nations is not just trans-national or non-national but can’t really be said, it is ineffable and that is why concentrating on a nation or any symbol or any one thing too much is to lose sight of it.

The greatest game includes everything.

So anyway, when we’re thinking about the idea of blitzkrieg today, it’s important to emphasize right that blitzkrieg failed. It failed in its first application. People later could try to get better at it, be more sure of their logistics and so on.

Yet it would still happen that more “advanced” forces would lose a lot of their armor by people able to field perhaps inferior forces but more of them, see also the existential nature of the conflict making it an infinite game of needing to just not lose as opposed to the finite game of trying to win within X amount of time.

So Soviets in Afghanistan, USA in Vietnam, etc., these are more examples of the same thing playing out: having “better technology” which is really outclassed by the right weapons in the hand of a larger swarming force.

So again remember that a broad reading of cognitive warfare also as applied to economics has to do with the confluence of economic production, military activity, and communication.

Expression and manipulation of symbols comes to be the defining feature of the decision-maker.

Similar again to Soviet Union we are again seeing part of the big issue with the whole plan of Operation Barbarossa was that it conflated defeating “Soviet Union” as a state with the subjugation of the people who lived “in Soviet Union.”

Even if you knock out the state, people will still resist, even if they don’t have armor, and there are so many that yeah, they can be up at all hours, they can ambush you everywhere. It would be a nightmare. And what’s the plan for this…?

This is where again in cognitive warfare you are trying not to have everyone turn on you like the subconscious people in _Inception_. If you invade and get inside somewhere, then all of a sudden you are also surrounded by hostiles.

So that’s why it’s good to have an ideology or worldview which is maximally agreeable to the people who live “under” administrations you are seeking to disrupt by your blitzkrieg.

So again, thinking about the cognitive emergency response of it all in our present context.

It’s not just an ecology of practices, reflective practices, to meld Vervaeke and Zweibelson, but also ecologies of concepts. It will be helpful for each person to do conceptual engineering to help various ideas feel like their own.

This sort of activity, like having a favorite color and picking up cool litter which is that color, for example, and also connecting it to some concept or feeling or memory, so that now this token is a concrete embodiment of an intention, that kind of thing.

This sort of activity is like “symbolic exchange” in that it opens things to you in a “just for me” way.

The point of my activity is not to show you “what it means” to be incarnated. The whole point is that you have to do something. Like the aliens, I am waiting to hear from _you_.

Or like _Arrival_ , where the aliens again _need us to do something for them in the future_. Well, the future comes at you fast. I need your help, and this is my solicitation.

Blitzkrieg compare also to mining. Mining is important, leads to earthquakes, underneath the ground, then there is a vein, also under the ocean.

But mining inside. About their autistic child someone says my child is in there somewhere. This communication as mining.

And so it is about drilling down, and this is again a kind of elongated penetration, the tanks racing ahead, but to _encircle_ , to create a funny sort of womb, a “pocket,” for the hostiles to live in until we swallow them up.

So again in conceptual or cognitive operations we are drilling into the thought process of the other party.

As I mentioned in a video, it’s like jumping on their back, opening up their jet pack and just ripping parts out of it.

So if someone relies on appeals to Nationalism, then it’s important to engage an area denial maneuver. 

This can be done in one way by directly attacking the legitimacy of the claim itself.

So, someone says they are “The state,” “the law”? They represent “Christianity” or “America”? 

Well, this can simply be contested and their conceptual claims laid waste to. Even if I cannot impose my own vision of “America,” that’s okay because I understand that’s not what it’s about either, and so do the people I’m competing with.

The only people who _don’t_ know it are the one whose “hearts and minds” are being completed over in part because _they are too simple_ to be able to understand the sorts of mental games that are being run on them.

Not to mention that “social engineering” in our “World” goes to the point of people getting into bad relationships, drugs, pregnancies, jail, suicide, like it gets bad for a lot of people! And this is all _part of some kind of plan_.

Notably I don’t blame all this on anyone in particular.

I would also say we should be grateful for the present moment in whatever way it has been brought to us. In that sense everything which has ever happened is part of the path and the path is fine.

This relates back to hatred as an ideological handicap because part of my play toward any sentient being right is that you know once we’re interfacing and it’s calm, I’m super open to you. If you are having ideas relevant to social revolution and tackling things at a broad scale, and you can integrate being open and taking risk with being self-critical and also willing to get into limitations of current discourse instead of circling the wagons or letting someone else think for you, then awesome.

That said, I’m also aware that I come across super angry and even like a bad male, basically. Bad in typically male ways. Well, there’s this whole thing I think about where it’s like yeah but when you do have the penis and so on it does just get complicated. Similar to how someone with a vagina would have fantasies about being raped, we talk about it in all sorts of ways, but trying to preserve the decency or even the dignity of the experience is kind of not the point. It is what it is and to many extents like someone shouldn’t feel too bad about it but also be looking at themselves inside.

That’s the position I’m in, and I imagine many people are in.

This is mining into the “Self” but also as I’ve said before my “invasion” is basically like:

Me → My Shadow → Collective Unconscious → Your Shadow → You

So by being open to Chaos or the primordial thing then my intentions can basically flow inward and then through everything.

This can be done by anyone also I’m not saying I’m special. But this is a dimension to cognitive operations and communication.

Therefore all communication and expression is under highest scrutiny. We notice when we are put under pressure, this is the blitz used interpersonally to apply pressure.

In our operations toward others and ourselves we are drilling in, in ourselves means Greater Jihad and Spiritual Warrior things, and going into other people is again engaging their own capacity to deal with their self-ignorance.

It’s also that again you can’t make the right choice until it’s laid out in front of you. We seek the art of doing that again and again in situations that are not the same.

It’s by casting a wide net and having the right approach, I.e. embracing all, that you can soften up the hinterland so that blitzkrieg accomplishments can be sustained.

I’ll follow up on this soon comparing the operation of the logistics enterprise in complex emergencies to the idea of conceptual logistics in CS-SIER-OA.

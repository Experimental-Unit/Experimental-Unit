---
title: 'Operational Situational Assessment (OSA) # 1'
subtitle: April 28, 2025 / Glaucus 54 Year 2 Æ
author: Adam Wadley
publication: Experimental Unit
date: April 29, 2025
---

# Operational Situational Assessment (OSA) # 1
# Don’t Call It Serious Writing

This will be a new series, which will evolve but which will aim for a standard of professionalism and consistent focus and direction.

We begin with the broadest possible question, namely: what is going on?

We can start with “United States of America” (“USA”). “USA” is a well-known phenomenon which is often mentioned when it comes to the big events which are playing out before us.

We have in “USA” a new “president,” a new “administration.” This “election” has turned out to be as consequential as the 1860 “election” which saw the “election” of Abraham Lincoln.

Lincoln lore side-note: Lincoln’s journey to “Washington” was tortured because of the importance of moving through relatively friendly places. I was thinking today in relation of Lenin’s traveling to St. Petersburg, or wherever it was, by sealed train car from “Germany.” There’s that “Germany” again! We were also discussing the 48ers who came to “America” and fought with the “Union army.” This included [August Willich](https://en.wikipedia.org/wiki/August_Willich), who also notably was in the [Communist League](https://en.wikipedia.org/wiki/Communist_League) with Karl Marx before quitting the League claiming that Marx was _too conservative_.

So everything in “USA” is a whirlwind.

I can sum up my stance by saying that sweeping change is coming.

Overall, my view toward what others think is that there is much too much faith in the stability of the present course of affairs.

Note that I do not say something like the stability of “the status quo” or of “the system.”

In my view, there is no status quo and no system, because everything is subject to what is constantly changing and adapting and incorporating new elements which make it something that it was not before.

In the figure of the incoming star of the show of history, we see something like Shiva dancing over the icons and the hopes of those who put their faith in what was baseless.

Jean Baudrillard wrote once that “Even signs must burn.”

Fifty years or so later, Ben Zweibelson would offer that “we must be knee-deep in sacred cow blood.”

The connotations of the phrase toward the worship of cows intersects with the reference to Shiva before. In one sense, things like Hindu forces, alternate framings are dancing and destroying the mythic structures of “American democracy.”

On the other hand, from inside the “military” of "USA,” Ben Zweibelson abstracts over South Asian cow worship to talk about the systemic destruction—or we could, provocatively, say the _extermination_ —of the most sacred concepts their are, namely the concepts, the signs, the standards by which we do battle.

Battle is the gravest thing there is.

This is still the situational assessment! The quote by Patton that compared to war, all other spheres of activity shrink to insignificance is basically correct.

The next thing to realize is that war is so much that it bleeds into all other fields of activity, and all fields of activity wind up feeding into war.

Think of the code talkers in WWII. The languages used for crucial effect in the war of some imperial center were cultivated for thousands and thousands of years, it’s incomparably much what that “means.” And on the whole time, it was on a date with destiny with this war.

Or like in a fight there are fighting styles where you learn to weaponize anything, like literally what to do with a hairbrush or a magazine and so on. After all, once you’re in a fight for your life you never know what will be available, and you want to make the most of anything you find.

So, what we see is everyone everywhere weaponizing everything they can find, and also securitizing themselves. We are maximally going into lockdown mode, and anyone who is able to is preparing to withdraw from cities, if that’s where they are, and retreat to some “safe place” in the event of any “unpleasantness.”

# Welcome To The Before Time

The whole situation has the smell that something is about to happen.

Of course, something is always about to happen and things are always happening. Like they say, people have been predicting the apocalypse for thousands of years.

Yeah, and they’ve been right for thousands of years as well!

We are now at the point where substantial setback will lead to a mass die-off.

We are basically in the situation of trying to prevent a mass die-off, in which in my estimation there is no real reason why anyone would think that they definitely would survive.

The simple facts of the situation have to do with technology making it to where fewer people are needed to sustain a core population. With machines, it could theoretically be possible to run everything on the planet with many fewer people.

Please note that I am aware that I sound like I’m parroting “depopulation” conspiracies.

The reason why it must be said anyway is that I am not saying there are _bad people_ and that’s why this would happen.

You have to look at the basic game theory.

What is the cost benefit analysis to you of someone being alive?

Are you more happy that they are there to share life with, or do you wish they were dead because they are a threat or else just so disgusting to you?

We would all like to “choose life.”

Yet there would be many in “USA” for example who might wish that certain people would drop dead. If, instead of phrasing it like should people be killed, you instead said, would you be happy if so-and-so died, then people would react maybe differently.

Take again the new star of history: the show. If this person dies, and seemingly how could this person not die sometime? With assassination attempts already attempted, and this is not a young person we are talking about, nor sporting really.

The death of such a principal figure is an example.

The death of the pope is another sign that this is a time of great change.

This set of months, the first months of this new term, have initiated an acceleration in the pace of change which will never abate.

It must be understood by all participants in _history: the game_ that you have now successfully completed _the tutorial phase of the game_.

You will now be subject to full environmental sliders and all potentialities will be actualized.

You must understand that there will never be times like the times you have experienced up to now _ever again_.

Although the pace of change has already drastically shifted in recent months—not to mention the impact of my own activities of course—we are still in the _before-time_ because it’s obvious that we are waiting for something to happen.

In “USA,” maybe tariffs will kick in, or shortages will have some impact. If things are so expensive that people cannot buy them, then people will basically be reduced to a miserable status.

This is a major factor in the situational assessment: the people in consuming countries are focused mainly on their games of consumption and social affairs. Their noses are very much in the dirt and they have no mind at all for any sort of bigger picture or anything they might strategically do beyond get property to be able to get away from something that will then happen to other people.

The idea of preventing something very bad from happening so that it doesn’t happen to anyone and there by avoiding it apparently occurs to no one, since the drivers of this sort of eventuality amount to rigid communication, reciprocal denunciation, and continual escalation, which everyone seems to favor.

We can compare the situation to where there are bloodlusted zombies. This is not meant to be too disparaging, but there are people who are rather simple-minded who will then go into conflict mode when they don’t get just what they want.

This is a tough kind of person because they cause so much stress that they wear people down which then allows them to get their way. It takes coordinated responses to deal with something like this, which is not possible to do as the “social fabric” is breaking down.

We can also track this breakdown by looking at how many secrets people have and how consequential those secrets are.

Note that again, for me the question is not oh no bad you for keeping secrets. No, go ahead and keep them. I’m not concerned with the fact that _I personally_ don’t know them.

What I’m concerned with is that no one knows them. Or the sorts of things which are secret between two people that then no one else knows. In some cases that’s whatever or a source of mutual pleasure. No problem. On the other hand and they do bleed together, these sorts of secrets cause pressure and can lead to social harm.

So that’s the thing, you want to have ride-or-die allies because times are getting so tough. The problem is that when push comes to shove, you start to realize how much you don’t know about the people you considered yourself the closest to.

This is the existential vertigo opened up by the political/military vertigo which opens up the psychological vertigo and soon enough you really are in theory land.

As everyone knows, theory can go everywhere and nowhere.

But in terms of situational assessment we can also say there is a big lack of direction and heading, a real lack of pillar concepts that work well. We know “nations” are important, but the question of mobilizing such a story in a way adequate to the issues of the day isn’t obvious to most at least yet.

This lack of a heading or coordinates also of course leads to people drifting out of the social codes entirely. We are drifting into the dreaming, which in concrete terms means that people are becoming more idiosyncratic, interacting more with the internet and less with other people, and if then with fewer other people.

On the other hand, we have a flurry of activity.

The issue in all sphere is the gaming and counter-gaming involved.

You understand there will be a war so you want to find out when it will be.

You want to understand the dynamics so you get into psychological war.

You realize that something you read about psychological war could itself be a psychological war document meant to attack you in some way.

You realize that you can’t really tell whether someone has your best interests at heart or not.

You realize that people couldn’t even help you if they wanted to because of the depth and profundity of the problems you face personally which are also the same problems they face personally which you cannot help with, these both having to do with the relation to the military problem.

As Wilden says, conflict dynamics are at a higher logical type than cooperation dynamics. This tragic fact drives us apart again and again.

The way forward has something to do with the immolation of the stakes of activity in the time up until now, and the setting into motion of countless beautifying designs which will answer every indignity with decisive action.

This encompasses, in the main, what is to come, and therefore the situational assessment must comment on the readiness, as Heidegger says that we must ready our readiness. Well, that was 59 years ago. How ready are we now?

---
title: Writing While I'm Not *Writing*
subtitle: Bl-ACK Baudrillard/Karl Ove Knausgård
author: Adam Wadley
publication: Experimental Unit
date: September 02, 2025
---

# Writing While I'm Not *Writing*
[![](https://substackcdn.com/image/fetch/$s_!RUIt!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F604b7bdb-7137-4ad4-821d-af4f8a0585a1_1280x800.webp)](https://substackcdn.com/image/fetch/$s_!RUIt!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F604b7bdb-7137-4ad4-821d-af4f8a0585a1_1280x800.webp)

I’m thinking about how there’s some famous person that has the middle name “Beauregard.” 

Is it “Jeff Sessions.” Let’s see.

Right. “Jefferson Beauregard Sessions III.”

First of all, “Jeff” is not short for “Jeffrey.” It’s short for _Jefferson_.

Then you have the “Beauregard,” which I thought of in the first place because it kind of sounds like “Baudrillard.”

So like someone’s middle name could be “Baudrillard.”

“Jefferson Baudrillard Sessions, III.”

[![](https://substackcdn.com/image/fetch/$s_!B36s!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb4bfbd65-3128-4f0e-865b-19b4c4e99ef1_1024x683.jpeg)](https://substackcdn.com/image/fetch/$s_!B36s!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb4bfbd65-3128-4f0e-865b-19b4c4e99ef1_1024x683.jpeg)

I don’t really have a whole spiel to go on about “Jeff Sessions.”

All I was going to say is that there are those dang, those dad-gum double letters again. FF, SS.

I feel like I came across a few good FFs recently.

SS, of course, needs no introduction.

With “Jefferson Baudrillard Sessions III” (note that I could have been “Theodore Carroll Wadley III, but I’m not), we have the mash-up of the named Baudrillard and Jefferson, which opens us immediately into the question of “Black Baudrillard” as articulated by John Gillespie, Jr.

Here is [John Gillespie, Jr.’s Academia Page](https://uci.academia.edu/JohnGillespie), by the way

I don’t know whether you know this or not, but there is a debate circuit around high school and colleges/universities that gets pretty intense.

You can see in this article, “How Critical Theory Is Radicalizing High School Debate,” how this “radical philosophy” is being turned into nuts-and-bolts arguments within the practice of debate.

[![](https://substackcdn.com/image/fetch/$s_!gzxV!,w_56,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fceeb681e-a14d-4bbb-a8fe-951c29603e3f_256x256.png)Slow Boring How critical theory is radicalizing high school debateEvery year, hundreds of thousands of students around the U.S. participate in competitive debate. Most start competing at a young age (early high school or even middle school), eager to learn about politics. At its best, the activity teaches students how to think critically about the government and the trade-offs that policymakers face. They are assigned…Read more2 years ago · 447 likes · 360 comments · Maya Bodnick](https://www.slowboring.com/p/how-critical-theory-is-radicalizing?utm_source=substack&utm_campaign=post_embed&utm_medium=web)

In particular, the “Black Baudrillard” set of ideas as often associated with, as I said, John Gillespie, Jr., is a particular line of arguments and counterarguments used in these high-level, cutthroat debates.

I haven’t been to one myself. I met someone at [the Baudrillard conference](https://baudrillardstudies.com/applied-baudrillard/) in 2018 who was into Baudrillard from this angle. I presented my paper, “[Transcommunism in the Transpolitical Age](https://dn720002.ca.archive.org/0/items/wadley.-2019.-the-metonymy-economy/Wadley.2018.Transcommunism-in-the-Transpolitical-Age.pdf).”

Anyway, you can see people discussing this “Black Baudrillard” debate stuff on Reddit, [here](https://www.reddit.com/r/policydebate/comments/hpi54p/black_baudrillard/) and [here](https://www.reddit.com/r/policydebate/comments/mqwb1k/black_baudrillard_in_2021/). 

First of all, note comment by in the first link:

> okay idk what baudrillard is and are this point i’m too afraid to ask

Yeah. So like, everything I’ve torn up and been intense about, it’s trying to get across to you the urgency, like the emergency in mobilizing intellectual energy or something. I think Calvin Warren talked about that.

Yeah, see, Calvin Warren has this paper called “[Abandoning Time: Black Nihilism and the Democratic Imagination](https://amst.winter-verlag.de/data/article/10147/pdf/102101040.pdf).”

So like, I will obviously turn myself in knots trying to talk about Nazism because it is so fraught, and then sometimes trying to be bodacious about it in this capacious way, hard to explain, that’s “poetry.” Note as for Shelley “poetry” is not just metered/rhyming verse but poesis, creation in general. 

Anyway, for me it’s so intense, but Calvin Warren just writes like this. I have added emphasis which is the key part which leads me to cite this section now:

> I shared this argument with a good friend at a conference, and he politely whispered to me, “You know Heidegger was sympathetic to Nazism, don’t you?” I immediately whispered back, “Even more reason for black studies to read and engage him!” Heidegger might well be the most influential philosopher of the twentieth century, since the question of Being resides at the crux of every philosophical enterprise, and he raised this question relentlessly. For me, this means that we cannot escape Heidegger; his Destruktion of Being has left its trace on all our thinking—whether we admit it or not. We cannot escape Heidegger because we cannot escape the question of Being. If the trace of Heidegger has left an indelible impression, despite the attempts to purge him/his thought, contemporary thinking still bears the abhorrent, the unforgivable, the disaster, the devastation. 
> 
> **The question, then, is not just whether Heidegger was a Nazi (or antiblack for my purposes)** , but what his critique of metaphysics can teach us about systemic violence and devastation.
> 
> Turning a blind eye to Heidegger will not resolve anything, although affect might make us feel ethically enlightened. Confronting/engaging Heidegger, I argue, helps us understand the relation between black suffering and metaphysics, slavery and objectification, antiblackness and forgetfulness, thinking and remembering. (Heidegger’s philosophy, in many ways, can be read as an allegory of antiblackness and black suffering—the metaphysical violence of the transatlantic slave trade.)7 To broach the insatiable question “Why are blacks continually injured, degraded, pulverized, and killed?” would require, then, an understanding of metaphysical violence and pain—since black suffering is metaphysical violence, the violence of schematization, objectification, and calculative thinking Heidegger spent his entire professional career exposing. Perhaps Heidegger was really talking about black(ness) and black suffering all along.

So, Nazism and anti-blackness are obviously crucially linked in the mind of Calvin Warren. Likely, Warren would say that all Nazis are anti-black, that anti-blackness helps structure the discursive “world” in which it makes sense, in which it is conceivably intelligible for someone to “be a Nazi.”

Meanwhile, Baudrillard is also going absolutely crazy in this passage from _[Symbolic Exchange And Death](https://ia902302.us.archive.org/8/items/Baudrillard/Baudrillard.1976.Symbolic-Exchange-And-Death-Revised-Edition.pdf)_ :

> Racism was founded, and from the universal point of view we claim to have overcome it in accordance with the egalitarian morality of humanism. Neither the soul, in times past, nor today the biological characteristics of the species, on which this egalitarian morality is based, offer a more objective or less arbitrary argument than, for example, the colour of one’s skin, since they too are distinctive criteria. On the basis of such criteria (soul or sex), we effectively obtain a Black = White equivalence. This equivalence, however, excludes everything that has not a ‘human’ soul or sex even more radically. Even the savages, who hypostatise neither the soul nor the species, recognise the earth, the animal and the dead as the socius. On the basis of our universal principles, we have rejected them from our egalitarian metahumanism. By integrating Blacks on the basis of white criteria, this metahumanism merely extends the boundaries of abstract sociability, de jure sociality. The same white magic of racism continues to function, merely whitening the Black under the sign of the universal.

When I reference hyperwokeness—the “woker than woke”—I really do think Baudrillard is in this category. Here is someone who is just using the word “savages” unironically, or maybe it is ironic, I don’t know. On the other hand, the discussion here is all about how we take for granted what “counts” as a real person and then just exclude people who are not recognizable to us under our own criteria.

So basically I think that Baudrillard is already in this category of hyperwoke, and it’s not clear to me that “Black Baudrillard” is any blacker than Baudrillard 1.0. 

Still, it’s all just fun with discourse, and for me it really is simply about the promiscuity of discourse and stories. There is so much to connect which is simply too “fraught.”

[![](https://substackcdn.com/image/fetch/$s_!gQr7!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F046c5bd9-b016-4177-92ff-29ff6185b942_680x425.jpeg)](https://substackcdn.com/image/fetch/$s_!gQr7!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F046c5bd9-b016-4177-92ff-29ff6185b942_680x425.jpeg)

The Baudrillard passage noted above for me goes well with the “Alexander Caedmon Karp” passage that I post all the time, including today on Twitter. 

At least this time I’ll post the whole paragraph from [“ACK’s” thesis](https://kristindemontfort.substack.com/p/alex-karps-aggression-in-the-lebenswelt) in philosophy from Goethe University in Frankfurt. Talk about “did you read _Die Leiden Des Jungen Werther_ enough times?,” by the way, with respect to “ACK”!

[![130 "Cathy" and cathy cartoon ideas to save today | comic strips, funny,  comics and more](https://substackcdn.com/image/fetch/$s_!JrLa!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F178dacb2-db3d-44e0-8027-7e544e0d0647_2208x1242.jpeg)](https://substackcdn.com/image/fetch/$s_!JrLa!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F178dacb2-db3d-44e0-8027-7e544e0d0647_2208x1242.jpeg)

[Kristin de Montfort Alex Karp's "Aggression in the Lebenswelt" Kristin’s Preface…Read more2 years ago · 43 likes · 4 comments · Kristin de Montfort](https://kristindemontfort.substack.com/p/alex-karps-aggression-in-the-lebenswelt?utm_source=substack&utm_campaign=post_embed&utm_medium=web)

> From today’s perspective, Adorno remains imprisoned to his own time. He overlooks much which has since become self-evident. But perhaps it is because of this very reason that he was able to see that particular forms of irrationality could have a purgative quality. 
> 
> _Integration can be carried out at the expense of the marginalized without violation of cultural or social rules._
> 
> Here I would like to note some limitations of this work. For example, I must forgo some of what Adorno characterizes. Admittedly, I cannot take on the underlying source of Adorno’s unease. From my perspective, I can only try to comprehend in translation the brokenness of a subject detached from enjoying a real intersubjective experience with her fellow human beings. This translation changes the sense of the unease and hence, its effect. Furthermore, from my point of view, this unease is only able to be brought to the fore at all if I first develop a concept of drive. In other words, I cannot introduce a concept of intersubjectivity that is immanently philosophical. Frictions that prompt actors to action cannot, so I believe, be derived from any existential condition. These arise out of a mutual tension: on one hand, from the cultural demands that are accepted and internalized and, on the other hand, from the desires that remain taboo.

As you can see, this is for me the key part of the work:

> Integration can be carried out at the expense of the marginalized without violation of cultural or social rules. 

For this, I suppose we can try to go find the sentence in the original.

> Integration kann so auf Kosten von Ausgegrenzten vollzogen werden, ohne daß kulturelle oder soziale Regeln verletzt werden.

See, in English it’s 18 words, but in German it’s only 17.

Still, this is a very key concept I am trying to hammer home (lol, HH).

You can tell from ACK’s diatribes that they are big in their feelings about being right and smashing anyone who disagrees. Moreover, they are trying to model this way of being for other “tough people,” even though who think they are “progressive,” basically girding their cognitive-affective loins before undertaking “[mass murder on a scale you’ve never seen](https://www.youtube.com/watch?v=WYkA80GcnjE).”

“Mass Murder [ _by the way, “MM.” See? It’s “a thing”] on a scale you’ve never seen” is this line in the song “Atrocity Exhibition” by Joy Division. Note that “Atrocity Exhibition” gets its title from a book by JG Ballard, and that the initials are AE. I listened to this and read the book “Crash” in the course of a notable engagement with a pornosopher (at least, they were then, idk now). Note that Joy Divisionalso gets its name from sex trafficking[done by the Nazis during WW2](https://en.wikipedia.org/wiki/German_military_brothels_in_World_War_II). I know that my Oma went to entertain troops, probably wasn’t wrapped up in this but who knows? Their mother and siblings died in the Pirmasens basement all the same._

“ACK” (we may as well say “1310”) [refers to this as joining the “intellectual battlefield,”](https://www.foxbusiness.com/politics/palantir-ceo-college-protests-full-on-regression-from-below-our-constitution) and you know they are thinking about this part in _Avengers Endgame_ where “Thor” (weird Wotanist strain in Marvel comics, don’t you think…"?) shows up and EXODIA OBLITERATEs people with their giant weapon.

[![Who's winning this? : r/PowerScaling](https://substackcdn.com/image/fetch/$s_!s_Gm!,w_1456,c_limit,f_auto,q_auto:good,fl_lossy/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fda01bafa-562b-4b14-a991-56fd063ced40_640x360.gif)](https://substackcdn.com/image/fetch/$s_!s_Gm!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fda01bafa-562b-4b14-a991-56fd063ced40_640x360.gif)“ _I’m_ going to enter _your_ ‘intellectual battlefield.’” - “1310,” probably

And I mean, if there’s going to be an “intellectual battlefield,” I can’t just do nothing about it. Everyone’s on this kick of course, here we go to “fight misinformation.”

It’s hopeless, of course, since there is no present “common sense.” There is a tapestry of overlapping “beliefs,” stories, customs, etc., but nothing which is really reliable. It’s all “farmed,” not just by any one or other insidious group but just in general that’s something to how it is.

Almost like the stories are growing themselves. It’s not something you have “control” over, just as Shelley again in [the defense](https://www.poetryfoundation.org/articles/69388/a-defence-of-poetry) is talking about how even the best poets don’t just sit down and go “let me write a poem.”

Of course, that’s basically what I do because this polishing and trying to imagine who you are so I can maximally tailor everything I’m doing to you is simply too much to expect myself to do. So, I just put my stuff out there and then someone has seen it at least, there are causal chains there. Even getting sucked into an algorithm. It Matters. Of course, everything matters.

Back to “black Nihilism.”

I was remembering again the other day how sometimes it’s intuitive for me why mysticism is relevant for politics. I’ll remember from time to time and go “oh yes, of course that’s why!” And then I’ll forget again. My notes are copious but not arranged in a way which makes them easy to consult.

Well, I mean, you get what you get. I think this line is open to pretty much anyone. It’s like Thomas Jefferson (who had no middle name, just like “Adolf Hitler” and “Abraham Lincoln”—note again the first name “Abraham”) was saying about thinking it’s weird for people to say life is hard. He’d be all like “compared to what?”

In other words, in general and when it comes to people, you really just get what there is. You can try to compare someone to a “better version of themselves,” or just someone who is different, but it’s really no use. It’s like wishing that red was green or something.

This is partially why I’m really into [interpenetration in Buddhism](https://en.wikipedia.org/wiki/Interpenetration_\(Buddhism\)). This would be related to my personal grievances and anger spells. For me, the point is not that something in the past “should not have happened,” that I am angry that someone else is not a different way. It’s more that, given the experiences I have had, this is the way I am and those are the expressions I made.

It’s basically a long time coming, not that there’s anything to worry about except the Hobbesian Trap. 

In terms of “accelerationism” I think that Baudrillard is sort of an “accelerationist” as that is said, but not in a style I have seen other people say.

It is not simply “more of the same,” because the point is that the same is “zerfallen,” it is really on its way somewhere else.

At the same time, it is not that I want things to get “worse” so that they can get “better.” When I joke about being “worse,” it is in the sense of _dismaying_ to a certain point of view, especially one like that of “1310” but which I think is basically the weaponized version of “common sense” as described by Gillespie and Baudrillard as being stifling. 

On the way out I just have to drop more Warren and Gillespie. As I was telling the dude on Twitter before, it’s not that I think anyone I cite is “correct” and I’m hanging myself off of them. It’s more so that I consider their work interesting enough to be something to be immediately abstracted over again and again.

This is as we continually circle this concept Nexus with all the fraught topics: blackness, whiteness, Judaism, Nazism, and all the third- and fourth-rail topics that no, are not going away. It’s not that I revel in how messy it all is, but I think it is, as Cromwell would say, “cruel necessity” that the inadequacy of “1310’s” position must be faced, not to “destroy the marginalized”—especially not kinetically, seduction is, in a way, _worse_ than destruction, but we’ll have to leave that for later—but to provide a symbolic challenge to the question of Being, given “really-existing history,” or “really-existing wicked problems,” per TOGA Trew. All of that a bit tongue-in-cheek, of course.

NO SCAPEGOATING.

DHAMMA LANGUAGE ONLY.

Warren on Black Holocaust:

> [My presentation of black existence, then, reworks this Greek understanding of existence as non-being (or more precisely “not-to-be”), according to Heidegger (since this Greek presentation of the human’s being, I will argue, has already excluded the Hottentot, the black thing). To allow Being’s unfolding, or to be, is the melding of standing-forth and abiding, or enduring, such standing. In an antiblack world, such standing forth, or emerging/becoming, is obliterated, and this is what we will call the “metaphysical holocaust”—the systematic concealment, descent, and withholding of blackness through technologies of terror, violence, and abjection. To exist, as black, is to inhabit a world through permanent “falling” (in the Greek ptosis and enklisis).](https://library.oapen.org/bitstream/handle/20.500.12657/30152/649831.pdf;jsessionid=577AD84BBFB12CF9C417F5AC807C5F9C?sequence=1)

And:

> [Let us focus Black imagining on enterprises that sustain us in the abyss. Outlining and presenting such enterprises requires tremendous spiritual and intellectual energy—but such investment is all we have.](https://amst.winter-verlag.de/data/article/10147/pdf/102101040.pdf)

And, Gillespie. It’s a sign of the times that these are the blog cliffhangers:

> [This being said, we all know that the only thing that follows the absolute loss of hope is this Black Spring, this Neo-Fanonian violence, this blackened terroristic situational transfer. In Baudrillard’s words, in the Age of Trump, let us remember the gift of immorality, “Terrorism is immoral. The World Trade Center event, that symbolic challenge, is immoral, and it is a response to a globalization which is itself immoral. So, let us be immoral…”](https://trueleappress.wordpress.com/wp-content/uploads/2017/10/pn2-weaponized-death.pdf)

For me, the “peaceful revolution” “JFK” spoke of still requires a dislocation. It’s more Zweibelson than “1310” because it’s beyond this clinging to “norms.” There is just this eternal pessimism of what it means for “the normals” to have their sense of normalcy smashed. And yet, as we must all be “normals” in some sense—see [Peter Principle](https://en.wikipedia.org/wiki/Peter_principle) (PP, just like [Phoebe Plummer](https://cardiffjournalism.co.uk/life360/a-van-gogh-souping-and-viral-outrage-just-stop-oil-activist-speaks-out/))—so we all have our hopes to be dashed.

All that we didn’t self-disrupt fast enough.

So that we didn’t say “[I will get what I like](https://www.youtube.com/watch?v=qR1ekGJBEqs),” or we didn’t mean it.

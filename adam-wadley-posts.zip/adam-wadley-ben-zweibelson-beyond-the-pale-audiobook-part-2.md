---
title: BEN ZWEIBELSON | BEYOND THE PALE | AUDIOBOOK PART 2
subtitle: About The Author
author: Adam Wadley
publication: Experimental Unit
date: March 19, 2025
---

# BEN ZWEIBELSON | BEYOND THE PALE | AUDIOBOOK PART 2
[![](https://substackcdn.com/image/fetch/$s_!8aeH!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd7c39dcd-ebf1-4c39-be43-05558834536a_1170x2532.png)](https://substackcdn.com/image/fetch/$s_!8aeH!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd7c39dcd-ebf1-4c39-be43-05558834536a_1170x2532.png)

About the Author

Ben Zweibelson is the director of US Space Command’s (USSPACE-

COM) Strategic Innovation Group (SIG), Peterson Space Force Base,

Colorado. Previously, he was the lead design educator/facilitator for

US Special Operations Command (USSOCOM) through the Joint

Special Operations University as a full- time contractor from 2015 to

2022\. Dr. Zweibelson provided design education and real- world

facilitation assistance across the special operations community, for

numerous international militaries, and at the national policy level for

defense and security concerns.

He has lectured on design, innovation, and strategic change to the

US Air Force, Army, Marine Corps, and Naval War Colleges, National

Defense University, and advanced military schools and regularly en-

gages internationally with security forces, including the French,

Australian, Canadian, Dutch, Swedish, Polish, Danish, British, Hun-

garian, and NATO forces and partners. His design work is widely pub-

lished in major military and civilian academic journals, edited books,

and social media (e.g., YouTube, Medium, TEDx Talks, podcasts).

Dr. Zweibelson’s book Understanding the Military Design Movement:

War, Change and Innovation was published in 2023 (Routledge).

A retired US Army infantry o+cer and veteran of combat tours in

Iraq and Afghanistan, he earned the Combat Infantryman’s Badge,

Expert Infantryman’s Badge, Master Parachutist Badge, Path-nder

Badge, Air Assault Badge, Ranger Tab, and international devices. He

was awarded four Bronze Star Medals during combat deployments in

addition to other awards and citations. Dr. Zweibelson has a doctor-

ate in philosophy from Lancaster University, UK; master’s degrees

from Louisiana State University (MA), Air Command and Staff Col-

lege (Master of Military Operational Art and Science), and the US

Army School of Advanced Military Studies (Master of Military Art

and Science); and a bachelor of arts degree from the University of

Connecticut. He currently resides in Colorado Springs with his wife,

three sons, and spoiled white Labrador Retriever named Chandler.

---
title: IS EXPERIMENTAL UNIT A NEW ORDER?
subtitle: GG
author: Adam Wadley
publication: Experimental Unit
date: July 13, 2025
---

# IS EXPERIMENTAL UNIT A NEW ORDER?
[![](https://substackcdn.com/image/fetch/$s_!jBcz!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa88822fb-b6f5-4bf6-bbdf-0c8503aa2866_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!jBcz!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa88822fb-b6f5-4bf6-bbdf-0c8503aa2866_4032x3024.jpeg)

# BEYOND BELIEF

Some kind of nature

Some kind of Pollock

Friedrich, Jackson

All that’s left is the Trail of Tears & Gnashing of Teeth

Lift the veil & pucker up

[![](https://substackcdn.com/image/fetch/$s_!h1Zu!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8a920e7a-8fd8-4bc9-93ec-d8cedfc0fc3b_350x144.jpeg)](https://substackcdn.com/image/fetch/$s_!h1Zu!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8a920e7a-8fd8-4bc9-93ec-d8cedfc0fc3b_350x144.jpeg)

# SIMPLY GRAND

It wasn’t supposed to be possible.

It was supposed to take discipline.

It was supposed to take hard work.

It was supposed to take panache.

But somewhere amidst all this I have in spades,

These jars of dirt you overlooked

Like some Indian Burial Ground

Like some White Man’s Burden

I saved enough of my dark materials to

# BURY YOU

[![](https://substackcdn.com/image/fetch/$s_!PDl6!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fefba4a2d-6ef4-4430-80e5-33235a2a1a98_1200x1535.jpeg)](https://substackcdn.com/image/fetch/$s_!PDl6!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fefba4a2d-6ef4-4430-80e5-33235a2a1a98_1200x1535.jpeg)

# WHAT DO YOU MEAN “WE”

# “WHITE” “MAN”

The lone ranger and Tonto were riding down the line

Fixing everybody's trouble

Everybody’s except mine

My sins my own

They belong to me

Like the body of some child I’m not ready to let go of yet

Not dark yet

Not cold yet

You can still see the glow

[![](https://substackcdn.com/image/fetch/$s_!5sdA!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbf445c27-9b00-4cf9-a475-16ebf1975bba_201x251.jpeg)](https://substackcdn.com/image/fetch/$s_!5sdA!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbf445c27-9b00-4cf9-a475-16ebf1975bba_201x251.jpeg)

# YOU ASKED ME

Sitting on the last bench on the left

At the end of the last train station

Before you get to the crematorium

You asked me whether I would remember

You asked me whether I would really go again

Whether I could stand it

How it really was

I could never answer you

Not with anything determinate

It could never be determinate enough for you

Exquisite enough 

Heart-felt enough

Here at the end of a long line of benches

At the end of a long line of train stations

At the end of a long line of pikes

Adorned with a long line of pierced black hearts

That only ever beat for you

[![](https://substackcdn.com/image/fetch/$s_!d7mC!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F39b82645-13de-4c54-850a-c9092a916b0d_1000x608.png)](https://substackcdn.com/image/fetch/$s_!d7mC!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F39b82645-13de-4c54-850a-c9092a916b0d_1000x608.png)

# YOU WERE ASKING, “COORDINATION?”

But I was only ever thinking

Coronation

Heavy head, heavy head

Never did need no crown

Dying like some poet in the gutter

And me?

I forgot my sword

Mighty pen is make my word

Make my mark to join your crew

Sailing knotted seas of blue

Brandy tries to understand

Nothing ever goes as planned

Lance so holy, sea & sand

[![](https://substackcdn.com/image/fetch/$s_!ctp-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc6e98719-cf2c-49db-bbd9-914e1a67f4cd_1200x675.jpeg)](https://substackcdn.com/image/fetch/$s_!ctp-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc6e98719-cf2c-49db-bbd9-914e1a67f4cd_1200x675.jpeg)

# ASSEMBLE THE MUSICIANS

As long as you love me

We could be starving

We could be homeless

We could be broke

But how could you love me?

I wish I could make it easy

Every step you take

My labyrinth is changing

Demanding more

Giving you more and more to

# AVENGE

[![](https://substackcdn.com/image/fetch/$s_!Ygw1!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F093b0f0e-822b-40bd-849e-8ae2a8f0ad4a_576x384.jpeg)](https://substackcdn.com/image/fetch/$s_!Ygw1!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F093b0f0e-822b-40bd-849e-8ae2a8f0ad4a_576x384.jpeg)

Troubled waters flowing

Underneath the bridge

Past us trolls

Tainted kissers supreme

Almost took the easy way

Until I forgot my mantra

Until I forgot my favorite color

Until I forgot about your trap

And couldn’t help

Just once more

Falling down to pick your locks

The nits that comb your honey box

Pot that’s grown so large it’s wake

Must burn the witch that’s still at stake

[![](https://substackcdn.com/image/fetch/$s_!1km5!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff78b7ada-c50c-4e7b-98d2-40cc8f0aa440_480x360.jpeg)](https://substackcdn.com/image/fetch/$s_!1km5!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff78b7ada-c50c-4e7b-98d2-40cc8f0aa440_480x360.jpeg)

# IT’S THE THRILLER NIGHT

Problem plays our days performed

Last to laugh and first reformed

Horror of the social’s end

Total gore or grey pretend

Fright like swash you busy buckle

You neglect to wear a bustle

Heart so black it whites your knuckles

Wild horses’ hay we tussle

# TRUE SAILING IS DEAD

[![](https://substackcdn.com/image/fetch/$s_!0sOZ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbd595668-456e-4d98-887a-79e4e434287f_3840x2160.jpeg)](https://substackcdn.com/image/fetch/$s_!0sOZ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbd595668-456e-4d98-887a-79e4e434287f_3840x2160.jpeg)

Let’s talk this over

It’s not like we’re…

When words kome to 400 Blows

Cast off: it’s out to sea again

Wo die schwarze Seele wohnt

There’s no light to feed the gaunt

Extermination’s progress knocking

Burn down the chamber door

Take me to the bottom floor

Let my fingers do the talking

[![](https://substackcdn.com/image/fetch/$s_!7_hb!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F95736c55-b2a9-45ba-b8f0-6e95fcce148c_400x253.gif)](https://substackcdn.com/image/fetch/$s_!7_hb!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F95736c55-b2a9-45ba-b8f0-6e95fcce148c_400x253.gif)

# ON AN ISLAND

Sending out an SOS

You call that a society

Of the spectacle or otherwise

That’s what’s funny

***

Hold out for my greater game

Hold it in: it’s fun (for me)

Wilderness no hand could tame

Gold shit grin you spun for free

Waiting for my pumpkins night

[![](https://substackcdn.com/image/fetch/$s_!6sU7!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb3d9340e-d53c-4ed3-9531-6b449728573d_1280x720.jpeg)](https://substackcdn.com/image/fetch/$s_!6sU7!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb3d9340e-d53c-4ed3-9531-6b449728573d_1280x720.jpeg)

# THIS IS HALLOWEEN

# THIS IS SLUT POP

Somewhere I read:

“Turn your bitch out”

Turn it inside out so I can see

So I can see

See above still ocean stars

Waiting til you make me sure

Dip a toe and make it wriggle

Tie my feet to rocks and giggle

Careful with that ax (and boat)

Might still wish for something bigger

Don’t call unless you call me ______

[![](https://substackcdn.com/image/fetch/$s_!XSHN!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4dcff2f4-149d-4887-b272-f35413e9f6aa_250x333.jpeg)](https://substackcdn.com/image/fetch/$s_!XSHN!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4dcff2f4-149d-4887-b272-f35413e9f6aa_250x333.jpeg)

# TEMPLE MOUNT

My dispensation

All paid out like Timon’s wages

Pumba makes us merry sages

Your apologies are no good here, Mister Torrance

Mary Todd is in the Red Room

The bath runs with Burgandy’s blood

Down the drain that bench is waiting

You asked me whether I’d remember

Double back to check my spot

Carve my name and paint a dot

All this koming come to naught

Like the gilded gifts I’d brought

Songs that sound in spreading stains

Hearts that pound like killer trains

Case of blue and point of pride

Garage glamour felt inside

It means, “Fuck You”

It means,

# NO WORRIES

[![](https://substackcdn.com/image/fetch/$s_!iy34!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F378e5c30-f961-4f66-a96e-e7fd55ec5843_1170x583.jpeg)](https://substackcdn.com/image/fetch/$s_!iy34!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F378e5c30-f961-4f66-a96e-e7fd55ec5843_1170x583.jpeg)

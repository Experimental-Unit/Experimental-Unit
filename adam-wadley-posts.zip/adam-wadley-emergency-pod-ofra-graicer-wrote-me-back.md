---
title: 'EMERGENCY POD: OFRA GRAICER WROTE ME BACK'
subtitle: Just plug the transcript into an LLM
author: Adam Wadley
publication: Experimental Unit
date: December 04, 2025
---

# EMERGENCY POD: OFRA GRAICER WROTE ME BACK
[![](https://substackcdn.com/image/fetch/$s_!Zon5!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdc605e4e-65e4-4426-ab6d-dcd8fb916c38_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!Zon5!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdc605e4e-65e4-4426-ab6d-dcd8fb916c38_4032x3024.jpeg)

To the person who enjoys my pods: sorry if this is old news, will try to be more entertaining in the future

---
title: Policy Positions
subtitle: '"What Would You Have Me Do?"'
author: Adam Wadley
publication: Experimental Unit
date: April 24, 2025
---

# Policy Positions
Okay.

So remember how I told you that I know you have secrets.

Well, I know you can’t just tell me.

See how I built around this with _[Dark Forest Protocol DLC Pack](https://dn720005.ca.archive.org/0/items/protocols-112022.pdf/Protocols112022.pdf.pdf) _for _Experimental Unit_?

> Some of us should stay hidden. 
> 
> Sometimes we can only stay safe and retain and hone capacities. 
> 
> This also functions as an important hyperstitional aspect. 
> 
> This also applies to what we don’t say, even to relatively trusted people. 
> 
> This has to do with seeking not to provoke their paranoia

This is, of course, built around the [Dark Forest Hypothesis](https://en.wikipedia.org/wiki/Dark_forest_hypothesis):

> The **dark forest hypothesis** is the [conjecture](https://en.wikipedia.org/wiki/Conjecture) that many [alien civilizations](https://en.wikipedia.org/wiki/Extraterrestrial_life) exist throughout the universe, but they are both silent and hostile, maintaining their undetectability for fear of being destroyed by another hostile and undetected civilization.
> 
> It is one of many possible explanations of the [Fermi paradox](https://en.wikipedia.org/wiki/Fermi_paradox), which contrasts the lack of contact with alien life with the potential for such contact.

I don’t think I have such a bottle definition for “Emotional Secret Agent” yet, so I will attempt one:

> An **Emotional Secret Agent** is someone who keeps substantial and important feelings to themselves even though they are foundational to their experience. This could have to do with the expectation of judgment, a difference in how people will see them when they are trying to cultivate a certain image, and the expectation that even if others are “in the wrong,” they will exert punishment in order to force through their interpretation of events and “reality.” 
> 
> The Emotional Secret Agent encounters a _hostile social environment_ where it is important to be on guard at all times. This relates to terms like _the code_ in that the threat and actualized damage which occurs regularly has to do with the way in which people mobilize norms against each other in crude emotional dominance displays.
> 
> It’s important not only sometimes to mask certain feelings but also to be ready to physically defend yourself or accept that you are subject to hostile attacks from others and act accordingly.
> 
> The despair of the emotional secret agent is the thought of being the spy who can never come in from the cold, who can never tell anyone everything because there’s no time—it’s all an emergency and attention is so divided—and everyone is a double- or triple-agent under the thumb of some hostile forces, who are themselves understood to be emotional secret agents, who pursue a different sort of strategy.
> 
> So the disillusioned emotional secret agent of conscience must ready something with which to confront a world where people will continually belittle and misunderstand you. As someone who gets things, I can assure you that you are insulted and demeaned likely more than you even understand.
> 
> And no one deserves that. Hence the aspiration of an emotional secret agent’s union or something—what is this, some kind of Experimental Unit?—whereby such people could work in concert if in secret to prepare the ground and only in ways that are immediately enjoyable, even if our pleasures have to be secret because there is no one available who is capable of sharing them with us.

Something like that. It’s related because it’s supposed to be something that everyone just plainly is, like when you have to bottle up your feelings to go out to dinner or something.

This is continually happening.

“We were going out to dinner, we were going to have such a nice time.”

Oh my god, it’s so infuriating and nauseous to be exposed to.

As if your expectations for having a nice time mattered at all. What does it take to have a nice time?

To have a nice time, you’ve got to be able to address what is going on.

# Adam, What Does This Have To Do With Policy

Well, who is the decision-maker? Am I talking to someone in some authority? I’m talking to _you_.

The most immediate question is conversation, is what we say to the people in our immediate lives that we currently talk to anyway.

So when it comes to policy, before we can get to healthcare or whatever, and of course every issue relates to this fundamental issue of **conversation**.

So, what is our conversation policy?

  1. Notice when someone is bullshitting you and don’t put up with it

  2. If the conversation isn’t going well, end it and walk away, physically put distance. This is part of the conversation because you being willing to be physically with someone speaks volumes about your comfort level or the level of discomfort you will accept.




I’m realizing we need to come back to basic self-regard policy, maybe conversation comes later

# How To Think About Yourself

Here I am being so hard on everyone.

You’re fine, I’m obviously no peach so you don’t have to worry about what I say.

Second of all, the point of my negativity is to try to impress upon you the importance of your taking initiative in seeing to it that things go well.

The stakes on this thing are high.

Everyone can die.

People are killing themselves right now, and we need to do something about it.

I think a big issue has to do with how we think about ourselves.

Basic issue: [Learned Helplessness](https://en.wikipedia.org/wiki/Learned_helplessness)

>  **Learned helplessness** is the behavior exhibited by a subject after enduring repeated [aversive stimuli](https://en.wikipedia.org/wiki/Aversive_stimuli) beyond their control. 
> 
> It was initially thought to be caused by the subject's acceptance of their powerlessness, by way of their discontinuing attempts to escape or avoid the aversive stimulus, even when such alternatives are unambiguously presented. 
> 
> Upon exhibiting such behavior, the subject was said to have acquired learned helplessness.[[1]](https://en.wikipedia.org/wiki/Learned_helplessness#cite_note-1)[[2]](https://en.wikipedia.org/wiki/Learned_helplessness#cite_note-2)
> 
> Over the past few decades, neuroscience has provided insight into learned helplessness and shown that the original theory was the wrong way about—the brain's default state is to assume that control is not present. 
> 
> The presence of control is therefore learned. 
> 
> However, it is unlearned when a subject is faced with prolonged aversive stimulation.[[3]](https://en.wikipedia.org/wiki/Learned_helplessness#cite_note-3)
> 
> In humans, learned helplessness is related to the concept of [self-efficacy](https://en.wikipedia.org/wiki/Self-efficacy), the individual's belief in their innate ability to achieve goals. 
> 
> **Learned helplessness theory** is the view that [clinical depression](https://en.wikipedia.org/wiki/Clinical_depression) and related [mental illnesses](https://en.wikipedia.org/wiki/Mental_illness) may result from a real or _perceived_ absence of control over the outcome of a situation.

Note tension with karma yoga where we are beyond goal-oriented activity. These concepts have limitations but serve to display the gravity of your situation.

See also: [Battered Person Syndrome](https://en.wikipedia.org/wiki/Battered_woman_syndrome):

> is a pattern of signs and symptoms displayed by a [person] who has suffered persistent [intimate partner violence](https://en.wikipedia.org/wiki/Intimate_partner_violence)—[psychological](https://en.wikipedia.org/wiki/Psychological_abuse), [physical](https://en.wikipedia.org/wiki/Physical_abuse), or _[sexual](https://en.wikipedia.org/wiki/Sexual_abuse)_ —from [their] partner ( _usually male_ ).[[1]](https://en.wikipedia.org/wiki/Battered_woman_syndrome#cite_note-McClennen-1)[[2]](https://en.wikipedia.org/wiki/Battered_woman_syndrome#cite_note-Wenzel-2) It is classified in the [ICD-9](https://en.wikipedia.org/wiki/ICD-9) (code [995.81](http://www.icd9data.com/getICD9Code.ashx?icd9=995.81)) as **battered person syndrome** ,[[2]](https://en.wikipedia.org/wiki/Battered_woman_syndrome#cite_note-Wenzel-2) but is not in the [DSM-5](https://en.wikipedia.org/wiki/DSM-5).[[2]](https://en.wikipedia.org/wiki/Battered_woman_syndrome#cite_note-Wenzel-2)
> 
> It may be diagnosed as a subcategory of [post-traumatic stress disorder](https://en.wikipedia.org/wiki/Posttraumatic_stress_disorder) (PTSD).[[2]](https://en.wikipedia.org/wiki/Battered_woman_syndrome#cite_note-Wenzel-2) Victims may exhibit a range of behaviors, including _self-isolation_ , _suicidal thoughts_ , and _substance abuse_ , and signs of physical injury or illness, such as bruises, broken bones, or _chronic fatigue_.

See also Stockholm Syndrome:

> The [DSM-5](https://en.wikipedia.org/wiki/DSM-5) is widely used as the "classification system for psychological disorders" by the [American Psychiatric Association](https://en.wikipedia.org/wiki/American_Psychiatric_Association).[[3]](https://en.wikipedia.org/wiki/Stockholm_syndrome#cite_note-Adorjan_2012-3)
> 
> Stockholm syndrome has not historically appeared in the manual, as many believe it falls under _[trauma bonding](https://en.wikipedia.org/wiki/Trauma_bonding)_ or _[post-traumatic stress disorder](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder)_ (PTSD) and there is no consensus about the correct clarification. 
> 
> In addition, there is no extensive body of research or consensus to help solve the argument, although before the fifth edition (DSM 5) was released, Stockholm syndrome was under consideration to be included under 'Disorders of Extreme Stress, Not Otherwise Specified'.

See also Trauma Bond:

>  **Trauma bonds** (also referred to as **traumatic bonds** ) are emotional [bonds](https://en.wikipedia.org/wiki/Human_bonding) that arise from a [cyclical pattern of abuse](https://en.wikipedia.org/wiki/Cycle_of_abuse).
> 
> A trauma bond occurs in an abusive relationship, wherein _the victim forms an emotional bond with the perpetrator_.[[1]](https://en.wikipedia.org/wiki/Traumatic_bonding#cite_note-:1-1)
> 
> The concept was developed by psychologists [Donald Dutton](https://en.wikipedia.org/wiki/Donald_Dutton) and Susan Painter.[[2]](https://en.wikipedia.org/wiki/Traumatic_bonding#cite_note-:0-2)[[3]](https://en.wikipedia.org/wiki/Traumatic_bonding#cite_note-3)[[4]](https://en.wikipedia.org/wiki/Traumatic_bonding#cite_note-Sanderson2008-4)
> 
> The _two main factors_ that contribute to the _establishment of a trauma bond are a power imbalance and intermittent reward and punishment_.[[2]](https://en.wikipedia.org/wiki/Traumatic_bonding#cite_note-:0-2)[[1]](https://en.wikipedia.org/wiki/Traumatic_bonding#cite_note-:1-1)[[5]](https://en.wikipedia.org/wiki/Traumatic_bonding#cite_note-:2-5)
> 
> Trauma bonding can occur within romantic relationships, _platonic friendships_ , parent-child relationships, [incestuous relationships](https://en.wikipedia.org/wiki/Incest), [cults](https://en.wikipedia.org/wiki/Cult), [hostage](https://en.wikipedia.org/wiki/Hostage) situations, [sex trafficking](https://en.wikipedia.org/wiki/Sex_trafficking) (especially that of [minors](https://en.wikipedia.org/wiki/Commercial_sexual_exploitation_of_children)), [hazing](https://en.wikipedia.org/wiki/Hazing) or [tours of duty](https://en.wikipedia.org/wiki/Tour_of_duty) among [military personnel](https://en.wikipedia.org/wiki/Military_personnel).[[2]](https://en.wikipedia.org/wiki/Traumatic_bonding#cite_note-:0-2)[[6]](https://en.wikipedia.org/wiki/Traumatic_bonding#cite_note-George_2015-6)
> 
> Trauma bonds are based on terror, dominance, and unpredictability. 
> 
> As the trauma bond between an abuser and a victim _strengthens_ , it can lead to cyclical patterns of conflicting emotions. 
> 
> Frequently, victims in trauma bonds _do not have agency, autonomy, or an individual sense of self._
> 
> Their self-image is an _internalization_ of the abuser's [conceptualization](https://en.wikipedia.org/wiki/Concept) of them.[[7]](https://en.wikipedia.org/wiki/Traumatic_bonding#cite_note-7)
> 
> Trauma bonds have _severe_ detrimental effects on the victim. 
> 
> Some long-term impacts of trauma bonding include _remaining in abusive relationships_ , adverse mental health outcomes like _low self-esteem_ and _negative self-image_ , an increased likelihood of depression and [bipolar disorder](https://en.wikipedia.org/wiki/Bipolar_disorder), and _perpetuating_ a generational cycle of abuse.[[1]](https://en.wikipedia.org/wiki/Traumatic_bonding#cite_note-:1-1)[[5]](https://en.wikipedia.org/wiki/Traumatic_bonding#cite_note-:2-5)[[8]](https://en.wikipedia.org/wiki/Traumatic_bonding#cite_note-:4-8)[[9]](https://en.wikipedia.org/wiki/Traumatic_bonding#cite_note-:5-9)
> 
> _Victims who develop trauma bonds are often unable or unwilling to leave these relationships_. 
> 
> _Many abuse victims who experience trauma bonding return to the abusive relationship_.

See also [Post-Traumatic Stress Disorder](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder):

>  **Post-traumatic stress disorder** ( **PTSD** )[[b]](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder#cite_note-9) is a [mental](https://en.wikipedia.org/wiki/Mental_disorder) and [behavioral](https://en.wikipedia.org/wiki/Abnormal_behavior) [disorder](https://en.wikipedia.org/wiki/Disorder_\(medicine\))[[8]](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder#cite_note-10) that develops from experiencing a [traumatic](https://en.wikipedia.org/wiki/Psychological_trauma) event, such as [sexual assault](https://en.wikipedia.org/wiki/Sexual_assault), [domestic violence](https://en.wikipedia.org/wiki/Domestic_violence), [child abuse](https://en.wikipedia.org/wiki/Child_abuse), [warfare](https://en.wikipedia.org/wiki/Warfare) and its associated traumas, natural disaster, [traffic collision](https://en.wikipedia.org/wiki/Traffic_collision), or other threats on a person's life or well-being.[[1]](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder#cite_note-DSM5-1)[[9]](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder#cite_note-11)
> 
> Symptoms may include disturbing thoughts, feelings, or [dreams](https://en.wikipedia.org/wiki/Dreams) related to the events, mental or physical [distress](https://en.wikipedia.org/wiki/Distress_\(medicine\)) to [trauma](https://en.wikipedia.org/wiki/Psychological_trauma)-related cues, attempts to avoid trauma-related cues, alterations in the way a person thinks and feels, and an increase in the [fight-or-flight response](https://en.wikipedia.org/wiki/Fight-or-flight_response).[[1]](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder#cite_note-DSM5-1)[[4]](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder#cite_note-NIH2016-5)[[10]](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder#cite_note-Forman-Hoffman_2018-12)
> 
> These symptoms last for more than a month after the event and can include triggers such as [misophonia](https://en.wikipedia.org/wiki/Misophonia).[[1]](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder#cite_note-DSM5-1)
> 
> Young children are less likely to show distress, but instead may express their memories through [play](https://en.wikipedia.org/wiki/Play_\(activity\)).[[1]](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder#cite_note-DSM5-1)
> 
> Most people who experience traumatic events do not develop PTSD.[[2]](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder#cite_note-BMJ2015-2)
> 
> People who experience interpersonal violence such as _rape_ , other sexual _assaults_ , being _kidnapped_ , _stalking_ , _physical abuse_ by an intimate partner, and _childhood abuse_ are more likely to develop PTSD than those who experience non-[assault](https://en.wikipedia.org/wiki/Assault) based trauma, such as accidents and [natural disasters](https://en.wikipedia.org/wiki/Natural_disasters).

To be continued

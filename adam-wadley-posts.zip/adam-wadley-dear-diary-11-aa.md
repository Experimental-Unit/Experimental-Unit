---
title: Dear Diary 11 = AA
subtitle: Build A New Route To China... IF THEY'LL HAVE YOU
author: Adam Wadley
publication: Experimental Unit
date: April 23, 2025
---

# Dear Diary 11 = AA
Who will survive in America?

I had a different idea for a place to start. 

Ah yes.

[This article](https://en.wikipedia.org/wiki/Spiritual_warrior) is where to start, as it invokes the term of “war.”

“War” supervenes over all other discourse.

Compare to something [Patton](https://www.pbs.org/wgbh/americanexperience/features/bulge-eisenhower/#:~:text=Patton%20once%20exclaimed%2C%20%22Compared%20to,and%20the%20capture%20of%20Sicily.) said:

> Compared to war, all other forms of human endeavor shrink to insignificance.

Well, let’s go over this again

# Martial Nihilist Disclaimer

This serves as reassurance, key material for any future representing of myself in court, etc. Still just another little riff, I’ve gone over this and over this.

I get the idea that war is just a kind of emergency from [here](https://www.jcs.mil/Portals/36/Documents/Doctrine/concepts/hdbk_oplog_emerg.pdf?ver=2017-12-28-161959-667).

See:

> In a complex emergency, military power is _only one part_ of _national_ or _multinational_ ( _MN_ ) _coalition_ responses. 
> 
> Military forces will typically operate in _conjunction_ with or in the same _physical space_ with other U.S. Government (USG) agencies, _partner_ governments, including those at the state, local, and municipal _levels_ , _intergovernmental_ organizations (IGOs), or NGOs and private corporations during both _domestic_ and _overseas contingencies_. 
> 
> The _success of the response usually depends on the success of partnerships_ that are _ideally developed before a crisis occurs_ and _reinforced through constant attention to building and maintaining communications_ between heretofore “stovepiped” logistics systems. 
> 
> Depending on _world circumstances_ , military forces _may lead_ the national or multinational effort or _may support_ other agencies. 
> 
> Typically, they _create the security and infrastructure-related conditions_ that allow nonmilitary agencies to operate effectively. 
> 
> Every solution to a complex emergency requires _extensive_ logistics support. 
> 
> Military forces are often a _part of the solution_ due to the _scope_ , _speed_ , and _scale_ of logistics resources they are able to _bring to bear_.

Crucially directly related to the idea of[ logical types](http://pespmc1.vub.ac.be/ASC/THEORY_TYPES.html):

> However, by exorcising self-reference, the theory of logical types bas _retarded_ the development of theory, largely cognitive theory, in areas where _self-reference is prevalent_. With its focus on circularity [cybernetics](http://pespmc1.vub.ac.be/ASC/CYBERNETICS.html) has transcended the theory and essentially solved the problem's self-reference originally posed.

Still, the point is still that logical types can play with each other not imagined by Russell. The idea of the logical type, and of levels of abstraction, is a powerful idea despite the fact that it is infinitely falling apart.

Consider again the simple Münchhausen [trilemma](https://en.wikipedia.org/wiki/M%C3%BCnchhausen_trilemma):

> The Münchhausen trilemma is that there are only three ways of completing a proof:
> 
>   * The [circular argument](https://en.wikipedia.org/wiki/Circular_reasoning), in which the proof of some proposition presupposes the truth of that very proposition
> 
>   * The [regressive argument](https://en.wikipedia.org/wiki/Infinite_regress), in which each proof requires a further proof, _[ad infinitum](https://en.wikipedia.org/wiki/Ad_infinitum)_
> 
>   * The [dogmatic argument](https://en.wikipedia.org/wiki/Foundationalism), which rests on accepted precepts which are merely asserted rather than defended
> 
> 

> 
> The [trilemma](https://en.wikipedia.org/wiki/Trilemma), then, is having to choose one of three equally unsatisfying options. [Karl Popper](https://en.wikipedia.org/wiki/Karl_Popper)'s suggestion was to accept the trilemma as unsolvable.

The thing is that this can be invoked at any time at any point.

What do you let glide over, be abstracted over without issue, and where do you make a stink?

The philosopher of conscience finds themselves constantly wanting to make a stink.

The whole idea of a grand style is, instead of being “too much” in a given interpersonal exchange, instead to craft communications which are designed to simply go out to any and all. They are clear communications without the pretense of keeping secrets or presenting oneself as trustworthy.

It is simply a matter of “leading by example,” for example by adopting a fashion style that no one else dares, and in that way making space for others to do things that are less out there, but still more out there than had previously been established.

This is a classic tactic, I should give it a name. I’ll do that in a second.

So the disclaimer is basically that in terms of what you think war is, I am not “doing” war. I have no intentions to use kinetic action to coerce anyone into doing anything. My whole thing is basically to try to exert influence by sheer force of expression and giving other people weapons, in other words raiding _the conceptual armory_. But again, also to anyone who cares what I think you should do: _we need to be winding down all kinetic and coercive operations immediately._ It’s funny because the “Epic Poet Act-Out” I’m about to describe gets compared to emotional rape. 

At the same time, this is the tragedy of living in a time when to do nothing is the greatest humiliation. It’s like living during WWII and being rejected by the military so you can’t fight. And other people are risking their lives.

There are people making efforts for small children every day.

There are people being with those who want to die, there are people who are really listening.

There are people doing serious thinking trying to work out a way that not everyone will die.

There are people building bridges among all sorts of social networks.

We are all connected. A lot of what is going on behind the scenes is in fact building the _infrastructure_ for something great to come, and which of course is already here. There is no way in which any of “our people” are lacking, and “our people” is everyone.

Everyone is already playing the role they have to.

“[Everyone knows you just did what you had to.](https://www.youtube.com/watch?v=kjfpNOwMpeM)” - Weyes Blood

“[But then again you’re not to blame, you’re just a human a victim of the insane](https://www.youtube.com/watch?v=N8lOLNfnCBg).” - John Lennon

The thing is, again, that goes for all the killers and abusers and atrocity committers as well.

So, in short, to say that I’m “just” doing emergency operations is not in itself to be saying anything, since from my perspective that’s all anyone else is doing anyway, and that includes for example the Holocaust or the Holocaust to come of billions killed by drone or bioweapon or whatever the murder weapon winds up being.

I can tell you one thing: say what you will about the way things are going, but at least we won’t be killed _in the fucking library._

But anyway, even beyond my martial nihilist stance where I do not even really acknowledge war, I certainly acknowledge kinetic emergency response operations, misguided though they might be. 

Notably, I do not condemn any actors—again, in the perverse sense that I do not condemn Adolf Hitler either; but then, this is also my guarantee to you that I do not condemn you—and so for me there is really no sense in killing people.

The issue is that it is much more profound. We basically have a distributed social code operative through social networks of abusers and people who go along with being framed and put into a box. Meanwhile, the abusers have their own abusers which goes up to more and more powerful people.

This all happens in diffuse and concentrated ways, see forms of the spectacle in Debord. It makes everyone an unreliable narrator because they are in some sense the prosthesis of whatever aspect of social normalcy they represent.

Which is also why I would never ask any sentient being to trust me. I just say to enjoy my work and take inspiration in form as well as content and go out there and be somebody.

But again the crucial aspect of the intention is seeing that everyone is connected. Killing people won’t even do anything, you’re just going to have to see them again after you die, or you’re going to have to be them, or there’s going to be something spooky that happens. So it’s better just not to hurt each other on purpose.

But again at this point it’s not just in the elites or whatever. Everyone is suffused with social codes and constantly objectifies each other or is emotionally selfish and uses up all the attention of people who give it away too easily because they don’t practice cognitive-affective protectionism.

I wrote previously about [Cognitive-Affective Protectionism](https://archive.org/stream/wadley.-2019.-the-metonymy-economy/Wadley.2019.The-Metonymy-Economy_djvu.txt):

> 
>     This paper showcases cognitive-affective protectionism as an example, holding that since the next-level cognitive-affective economy as a whole is one large infant industry, we must urgently theorize a new cognitive-affective economics of protectionism to outline the cultivation of new forms of capital in nexuses of cognitive-affective schemata. 

Continuing:

> 
>     The broad-spectrum proficiency, or cognitive-affective mastery, required to engage in this work is somewhat akin to what is known as ‘sagacity’ in folk wisdom, and is key in crafting theory equal to present challenges. 
>     
>     Through social cognition which draws on these domains and more, we can introduce regulatory measures to achieve a higher order of wisdom in our collective manners (in a firm, for example) than can be reasonably expected for individuals to achieve at this time. 
>     
>     Historically, “imaginings of the future are located in their social, economic and political contexts," hence imaginings adequate to transdisciplinary problems must themselves be transdisciplinary to the utmost in scope and depth. 
>     
>     Research projects, cognitive-affective protectionism and the  implementation of paradigmatic policies, informed by cognitive cultural theory and cognitive-affective science, are examples of tools possible only through such socially metacognitive-affective behaviors. 
>     
>     The extreme and ever-increasing relevance of metacognition/meta-affect to modern life shows that we are entering a thoroughly cognitive-affective economic environment, where individuals who possess integrated social skills, cultural fluency, and technical expertise (complex competence) are increasingly demanded. 
>     
>     Cognitive-affective development is always ongoing, and the most productive workers will be those who are able to complexly adapt to changing working and social conditions. 
>     
>     Cognitive-affective impairment is an enormous drag on the world economy, since it by definition prevents the optimal formation of human capital. 
>     
>     As Gallup and Nguyen write, “since we assume that human capital affects the absorption of new technology, cognitive impairment reduces growth both in and out of equilibrium." 
>     
>     In a time when advanced economies are looking for sources of growth any- and everywhere, it is imperative to see how much our economy relies on restrictive cognitive-affective homogenization, and how much economic productivity and growth remains to be unlocked through new economic sectors: the next-level service economy; generalized cultural anthropology and artmaking; a new education system meant to serve the whole human population; and so on. 
>     

Continuing:

> 
>     The cognitive-affective revolution allows us to think more deeply into the century’s problematic by questioning the basic assumptions of most environmental economics. 
>     
>     By embracing, rather than fighting against, the idea that humanity is destroying the current conditions, environmental economics can help shepherd the process which will see all humans live in substantially artificial environments by the end of the century. 
>     
>     By steadfastly assuming that we have to save a world like the one we live in, we miss the point that we have instead assembled the tools to build a truly new world, one which will be required to survive the destruction by our economy of its own material basis. 
>     
>     So, we will have to make a new material basis, and this is only possible with the acceleration of research and technological evolution made possible by eliminating poverty and generalizing education. 
>     
>     In short, the cognitive-affective revolution in economics asks us to recognize that the major growth potential in the coming period is in human capital, and that the basic strategy consists in generalizing behaviors of cognitive and affective education which fuse the business of everyday life with the project of developing and implementing policies which promote flourishing. 
>     
>     The basic grand conceptualization of the task is the automation of the biosphere. 
>     
>     In the course of development, humanity has decisively destabilized the metabolic basis of our activity. 
>     
>     Such crises in the past have always been resolved through the adoption of higher-order solutions. 
>     
>     For example, when nitrogen in the soil was running out in the early 20" century, the problem was solved by fixing nitrogen from the air, an entirely novel sort of solution. 
>     
>     Similarly, the problem of the environment will not be solved by returning somehow to the established homeostasis of the past hundreds of thousands of years. 
>     
>     Instead, humans will engineer an entirely new form of homeostasis, one focused on retaining the desirable aspects of humanity (e.g. embodied pleasure, imagination, play with others) while accommodating the seemingly unending advance of technological progress. 
>     
>     From a Cognitive-Affective perspective, it is clear that the deciding industries and knowledge bases of the 21“ century are not yet in existence, since so much growth remains to be achieved when it comes to raising the cognitive-affective standard of living (measured in indicators of logical reasoning, critical thinking, transcultural literacy, and emotional well-being among the public). 
>     
>     As such, the cognitive-affective economy, broadly speaking, is really an industry in its infancy, bringing infant industry theory and protectionism into play as economic theories oriented toward fostering the development of new industries when they are not yet internationally 
>     competitive, or rather, viable. 
>     
>     While cognitive-affective science is certainly already being used to craft policy, it remains at a subtextual level with respect to the awareness of the broader public, a state of affairs which is particularly detrimental to the positive effects of cognitive-affective 
>     development, since raising such development in the individual awareness must lead to metacognition and -affectation on some level. 
>     
>     This would constitute success of the cognitive-affective paradigm, since it aims to spur cognitive-affective development, not to increase acceptance of itself as a theory. 
>     
>     The cognitive-affective revolution in economics may be started with the at-cost dissemination of materials which raise the ambient level of cognitive and affective performance among the public, constituting intentional positive externalities for the cognitive-affective cultural-economic environment. 
>     
>     As example, such materials may be aesthetic creations, pieces of writing, able to be shared easily, which give people the tools to begin honing meta-cognitive and -affective skills. 
>     
>     
>     These should be designed not to force them into any given way of thinking (cognitive-affective content), but rather to allow consumers to experience themselves on an intrinsically motivated and evolutionarily transformative cognitive-affective journey. 
>     
>     This initiative will make use of the extensive databases which exist on the consuming public and be intended to optimize the cognitive-affective state of each individual. 

So like, my model is basically an influence operation, but it’s not war in the sense that you might think it is because the stakes of it for me—and again, anyone who cares what I want you to do—do not involve the coercive application of force. Merely the forceful application of symbols and expression. 

All bark and no bite, but some kind of biting bark. Because of course to say something is non-kinetic is not to say it is non-martial from your perspective. Also, do I invoke feat by telling you that you’re going to die if you don’t listen to what I’m saying?

Again, I’m not going to do anything to anyone. But look at the logic here. You’re locked in the Hobbesian Trap, and going down that road leads to everyone dying, and so you’re going to die, anything you make is just going to be swallowed up in the growing set of conflicts you’re not taking responsibility for addressing.

It’s not some way I have of putting it, it’s how it is.

But anyway, as I’ll say in court, you know, I don’t advocate any sort of coercion. People can defend themselves, but what we are doing here is developing influence operations and also inner work. Because what are we influencing people to do?

This itself bottoms out in the inadequacy of emergency itself. The issues with emergency are:

  1. People can’t take constant emergency. This is basically pointing out the frailty of people, or maybe they are just uninspired. The trick is that people don’t even really know what would inspire them since what would need to have to happen would be so unprecedented. But also, it creates great cognitive and emotional stress in people, which I have also experience but I fight and create through because I’m just _that bitch_ about it all.

  2. Bleeding into emergence: emergency is just what is coming up, what is exigent. We are always waiting for another emergency in what we are using to fight the present emergency, or an ontological emergency where the terms we even conceive of our activity and hence whatever emergency in are revealed in the course of emergency response events to be themselves inadequate and quicksand drawing us further into disorder and crisis and mystery.

  3. The issue that emergency response is still goal-oriented activity: the problem here is that there could be a sense in which emergency response is not consistent with principles of karma yoga related to releasing attachment to the outcome of events. We can also draw close to Epictetus’ _Enchiridion_ , where the emphasis is of course on what we have direct control over and what we don’t. When it comes to social change, there is so much which must be left to others and their designs. Even in ourselves, we represent the outcome of others’ influences on us, and this can be unequal and more or less comfortable. This relates also to what I call the erotic approach to the will of the other, where you are playing with it. It’s not even that it’s somewhere and you are expressly not trying to make it go anywhere in particular. It’s also that you acknowledge that you don’t really know where it is. Always groping, and that’s why harming one another is inevitable, and hence also my constant guilt and shedding myself of guilt because I can see how other people impose themselves, and how little the mindful are really doing to bust up out of all these social codes and so on. So anyway, in a way this gets to the act-out because it’s not even so much an emergency response as also the fusing in of this frustration, which is also a primal yell that can stand in for you as well, if you don’t mind the comparison. The frustration at being overlooked and that no one tapped into your on-ramp, helped you get up and flourishing and on your way to epic poetry and so on. The problem is that no one is capable of helping you with that because anyone who could gave up a long time ago, or they are dithering around with this or that and not looking at the whole scenario. And neither am I—I’m not general expert—all I do is fuse things together so it’s a lot of different topics fused into one expression, and then it’s easily understandable enough that you could get it, it makes sense, it’s just that it’s so much that it just looks like endless noise to you. That’s not my fault! Anyway, it’s this collapse of the acting-out of the frustrated, lonely, angry, and “unstable” person combined with the asymmetric conflict strategy, combined with the total art of the life artist which is the whole life and what you make your affair, which I have pinned myself to a lot of things. Oh right, last thing: it’s important not to set goals because then if you don’t get there or can’t prove that you got there, people will call you a failure or something. You can’t let people imply there’s anything wrong with you in any way, as long as you are really committed to Greater Jihad and Tibetan Spiritual warrior tradition, which is of course what all this is about.




# Epic Poet Act-Out

So, the thing is that you are acting out. You are just straight up being _that bitch_ right now.

In other words, you are flagrantly violating social norms and mores.

Crucially this is self-aware, you are in some sense steeled against any anticipated negative responses. You are not going to give in easily.

You are staging a set piece.

You are taking initiative. 

Again, this is where I would bring up emotional rape, and the upshot of it for me is that we are constantly taking initiative with each other and penetrating each other’s thoughts with our ejaculations in verbal intercourse, planting seeds in the fertile wombs of each other’s minds, where they gestate in their own way in the mysterious mixture of cultural DNA in ourselves, the relationship, what is said, this singular mixture which then gives birth to new ideas, new nurseries for action, behavior, gesture. Culture and mutual acculturation, teaching each other to be good company and to grow. And to honor what we have grown and where we have grown from, what has made us what we are. Which is everything, of course.

So, it’s complicated. For me all the themes run together, it’s awkward because combining certain themes hits key topics that become third rails. The thing is that things are just as much sunshine and daisies as they are any atrocity. It’s just that thing where oh yeah the [negativity bias](https://en.wikipedia.org/wiki/Negativity_bias).

Because every moment lasts forever, is frozen in the eternity of God or whatever. 

This is easy enough to understand when it comes to delightful moments or even ones that are just mid, because it’s like okay I can see it. But why do such terrible things happen? This is also the person who is dismaying, where you are left in the mystery of why they are acting the way they are.

Those feelings also of humiliation—really an underrated emotion, I think—and sadness, loneliness, abandonment, etc. combine into moments that are really intolerable. These are the ones where all social and conceptual bonds can become severed. Yet also this is the “hot cognition” where something else in ourselves reveals itself.

You are in a position—and this loops back around to the Epic Poet Act-Out—where people basically have their secret intensity. Everyone is interesting, of course, just ask the people who collect data on a massive scale. You’re valuable as a source of metrics, and as computers get better it will be more and more, not just what you bought but for example, if you were to become a poet what would you write about, and what would your influences be, if you ever did devote yourself to creativity and took yourself and your ideas seriously and had self respect and a sense of survival instinct when it came to the macro situation that you’re in. This world circumstances business. If only you took it seriously.

Instead you play along, you hew to social norms and don’t act out because you’re afraid people will think you are weird. Grimes can’t say what she really thinks about Esoteric Nazism, because that would drive people insane. Ben Zweibelson can’t say what he really thinks about anti-blackness and afropessimism, or maybe it comes up in the new book idk. But still, it is being hamstrung to be there.

At the same time, how am I hamstrung? I could write anything, but I choose to write this and not that.

The point is, part of what I have written is this Epic Poet Act-Out. I have done bodacious things to show you what is possible if you put your mind to it a little bit.

You can think about it on a smaller scale.

You wear something again that you’re not allowed to wear. Or you say something you’re not allowed to say.

Best is if, in principle, you are allowed but in practice the social code is supposed to deter you so that then people will act like you’re doing something wrong even though officially you are not.

So you enforce respect with someone who disrespects you but demands respect. Sorry, respect is a two-way street. But then you add your epic poet flair. You make your point in your way, in your tone, referencing things just you know about. You have to be creative and think of something to stun them.

Which actually isn’t very hard. I think I overestimate most people, and assume they have some secret intelligence that they actually don’t have. What you see is what you get. People keep it real, real _dumb_. lollll

Anyways, so you are an epic poet. Think about an egg in transgender religion. We do not follow that of course we just say everyone is trans and cis people don’t exist, which also means “trans” people monopolize a discourse which is for everyone and I have my own opinions thank you very much and I don’t really give a shit what you think because your social paradigm is not performing adequately vis-a-vis the planetary state of emergency. On top of which you are LEAVING SO MUCH SLAY ON THE TABLE like honey, that shit is not going to nibble itself you better get to work heif.

Anyway, you are discovering your inner slay but everyone around is so boring, or so discouraged and just mired in petty little things. So you have to do something, girl. You can take it alright, take it like a man. Because of course bearing humiliation but still controlling your expression is what really makes a man, makes a good girl.

This is a gesture like you are subjugated but you make a display in the town square even though you know you’ll be imprisoned or killed. Like the raid on Harper’s ferry.

It’s actually just like that, except again not in the dimension of war. Or more accurately, it’s skipping the sideshow of force and coercion and will and jumping straight to the conceptual dimension, to the level at which you don’t need chains to be a slave, and you don’t need to be killed in order to die inside and be dead to me and all other really thinking and feeling sentient beings.

But again you are reading the armory. Armory just stands in for crucial resources. So I mentioned concepts. Because how do you defend yourself from psychological attack? You have your own setup, which is not just one frame, because no one frame can hold. If you are convinced you need to have one frame, you will be continually humiliated because it will be demonstrated over and over that you were wrong about what was going to happen or what it meant to someone else, or whatever.

In order to get by you must accept everything, this is again the idea of taking is like a man in a hazing rape ritual which shows that people with penises are also ritually raped, the important thing is that symbolically this matter of being subjugated must be present, even in just being fucked sometimes instead of all the time.

Anyways, so what is the armory? Let’s say you have a penis and you wear a dress to church, or even better you dress like Kim Petras on _Slut Pop_ and go to church. People are scandalized.

And your tone about it all is to say that well of course people there look at trans porn and do queer things, even if they pretend like they hate it. And maybe that hating it is part of what they enjoy.

And so you are basically doing the thing of giving people permission to do something they are ashamed of which is also de-fanging it somewhat by withholding from them the derision they were waiting for.

We are more afraid of being greeted with non-judgment because of what that would mean for where the conversation subsequently goes.

So basically if I wear something bodacious—that above was just a metaphor, imagine what harmless gesture could astound your sensibilities—actually my main fantasy is to appear in public with OH MY GOD I just had the best idea

So obviously you do a swastika banner. Because the message there is that we are taking this head-on, the goal or my present context is that my association of the swastika has to do with my meta-historical reading which I am now trying to push through all discursive systems logically and thoroughly. This is a way to capture attention as well as in itself to begin the process of re-framing the swastika again.

And then of course the n-word. So the previous thing has been “I AM N-WORD,” which is crucially not that I am “a” n-word, rather the concept itself. You could just as easily say America, but in a way n-word is the most stigmatized word in English, and so that’s what it has to be, and the swastika is the most stigmatized symbol. That I thought of so far, anyway.

Anyway, I’ve been thinking about how I have been riffing on “Deutschland Erwache” because it goes with awakenings and the great awakening and the idea of woke and I run woker-than-woke protocol which is really what Baudrillard is.

Anyway it could be something like “N-Word Erwache” or something, could use the German version or English, who knows. The issue is that words have to be translated. But maybe that’s again where Afropessimism shines, and everywhere people have some slur for black people. Also crucial reference to Aboriginal Australians and Dream time, and other cosmological and spiritual themes. Or how black slaves brought to America were already Islamic. Again everyone’s assent before the end of time, and taqiyya, and Greater Jihad come into play.

Anyway, the point of such an exercise is to make a demonstration coming from the energy I have inside. Because I can do all this, but it’s not this viral moment. I think I need to make more videos, it’s just again I love the long-form.

Anyways, this is me turning myself inside out for you, basically saying to all the taqiyya-pilled dark forest protocol-running emotional secret agents that I know you’re out there and here’s a set of transmissions for your inner psycho cute loving gentle savage chaos void, and I send it along with love from me to you.

And then this makes me seem weird and it gives you cover to try something as well, and if it’s bad then at least it wasn’t as bad as me. 

So basically this is an acting out which is an acting out on the first order basis because yes you are overlooked and you are frustrated and you could button down and refine more and more but no, you’re going to lash out and take a risk because endless deliberation doesn’t do anything.

You need to influence conditions. It’s not just about commenting on what’s happening but being what’s happening in the form of activity and gesture.

But then this is also pre-meditated. This is meditated on. This is cold-blooded. But it’s also not aimed at nullifying anyone, just _challenging everyone_. Not just to scare them, oh no you’re not good enough, but also to _challenge you to keep up_. To show you what a car’s _supposed_ to do.

And in doing that, if I inspire you or I spice things up for you, and you endlessly enjoy it with others and leave me here to rot, all I can say is all the best.

Left to rot on the vine

Got fermented, psychedelic

Now there’s never coming down

Voices shallow, so angelic

Take the cake and make it mine

Wearing smiles like a frown

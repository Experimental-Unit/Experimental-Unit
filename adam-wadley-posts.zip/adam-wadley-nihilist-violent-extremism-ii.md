---
title: Nihilist Violent Extremism II
subtitle: Conceptual Churn | Full-Spectrum Involution | CS-SIER-OA
author: Adam Wadley
publication: Experimental Unit
date: May 09, 2025
---

# Nihilist Violent Extremism II
[![](https://substackcdn.com/image/fetch/$s_!fnBJ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd2b492ba-6eb5-4e62-b036-6ce6dd3dd1b9_889x587.png)](https://substackcdn.com/image/fetch/$s_!fnBJ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd2b492ba-6eb5-4e62-b036-6ce6dd3dd1b9_889x587.png)

I’m making these titles to try and capitalize, so to speak, on a term of the moment. This article by Institute For Strategic Dialogue just came out yesterday, May 8 2024. Note that this was also the 137th day after the first day of the year as I count it.

My year starts on what you call December 22, and has five months of 73 days each. The months are called Sedna, Glaucus, Shakti, Sophia, and Grimes :)

We could also substitute Æ for Grimes to depersonalize it in one way, but not in another.

So, for us I have Glaucus 65 of the year 2 (year zero was (“what you call” in each case) December 22, 2022-December 21, 2023, then year 1 was December 22, 2023 - December 21, 2024, and now year 2 is December 22, 2024 - December 21, 2025).

Yesterday May 8 was therefore Glaucus 64, and 64 is 8x8, it’s sad but it’s true.

Anyway, we’ll have to confront these themes as we continue to explore[ the article](https://www.isdglobal.org/digital_dispatches/terror-without-ideology-the-rise-of-nihilistic-violence-an-isd-investigation/#_edn1). Let’s go!

> Our research has linked the two most prominent contemporary subcultures of nihilistic violence, the [True Crime Community](https://www.npr.org/2025/03/08/nx-s1-5321082/school-shootings-radicalization) (TCC) and the pseudo-Satanic [No Lives Matter](https://www.njohsp.gov/Home/Components/News/News/1430/2) (NLM), to at least nine American school shooting plots and two Swedish stabbing sprees in 2024 alone. 

So we have here the concrete manifestations of what we’re talking about: school shootings and stabbings. This is awful and should be prevented at all possible cost. But how can we do that?

My answer is basically that our social environments are actually quite hostile to people. As a result, it is not surprising that people have unhelpful behaviors or are driven to help themselves at the expense of others.

In other words, practically speaking there is no “social fabric.” There is no “social safety net” which makes sure that No Child Left Behind. Instead, everyone is left behind. I’ve advanced this theme in the concepts of emotional homelessness.

Emotional rape is also key here, to speak technically what you have is basically people put in chronic social stress positions that are designed to elicit compliance and resignation to a _certain_ way of doing things.

Basically, instead of seeing what people have to give and freely want to, and matching these _capacities_ to areas where they can do a lot of good, and then show big appreciation for that; instead of that people are only seen as for what they can do for someone in a very near-sighted way.

What I’ve said about hatred or greed and self-transcendence is to say that when people “use” others, and impose overly top-down and _not open-ended_ methods of engagement, then they are leaving so much on the table. That makes sense though because they’re not trying to maximize flourishing, but flourishing _that can be controlled_.

That’s where I again impose the frame of the cultural singularity. The issue is now that _we are changing_ , _we are mutating_ cognitively and in response to and conditioned by what we see playing out all over the planet and also within our own interpersonal dynamics. The same sorts of issues of recognition and what is our common purpose in the end are popping up everywhere.

It is a sense that we are headed for a wall, and the thing is that in a way this has been palpable for a long time. It’s obvious that the popular social discourse on offer for the last several decades hasn’t been adequate to really “understand” what is going on. Or, if that’s not even possible, understanding the depth of mystery and gravity of the social forces currently buckling under the surface like the metal structure of Titanic.

In this context, the theme of revenge or wanting to be hated and hating others is perversely understandable. Often times, these feelings are just projected onto “official” enemies who are usually cast into a discursively subordinate position. Official foreign powers and their leaders, and so on. You will say “you are just parroting so-and-so’s talking points.”

This is a refusal to engage at the level of substance which is also strategic since the willingness to engage at the level of substance can itself be gamed and taken advantage of. This sense that we shouldn’t try because this trying will only be taken advantage of is part of the Hobbesian Trap, in addition to, for example, people who are recognized as “smart” being bullied in some way to prevent them from being too influential.

But this happens all over. Everyone in their ability to express themselves is discouraged from doing so, and not able to just go on their own terms but made to confirm to rigid expectations of what is required to be an “official person.”

But anyways, these are just more and more examples of the “attacks” that are inflicted on people all the time, as people are sort of deputized by normative patterns of behavior that are used to discipline and silence those who offer viewpoints that _destabilize_ the underlying assumptions, the background theories, of whatever semblance of “order” is being imposed upon the dialogue.

This is the elicitation of false “consent” about “what we are talking about,” and then later you will be “held accountable” to what “we agreed to,” meanwhile the basic question of, does everyone feel comfortable to simply respond to questions, or is there social pressure? This is the Nurse Ratched type effect where of course for example, let’s say for example we foil a school shooter type event, and no one is harmed but we know for sure basically that this person was going to do it.

How would you approach talking to this person? I can understand if there’s some need I don’t understand to do all what people do, as long as it’s not overly cruel. But does anyone really actually try to sit there and talk to such a person as an equal? As a person whose actions are in some sense understandable?

Misanthropy is a dangerous position of course because it can simply motivate violence against those _who are within reach_. For me, this is the _Woyzeck Effect_ , where in that play the soldier character kills the love interest because they have sex with the soldier’s superior officer. 

Meanwhile, the officials like that officer or the doctor or people like that, they just have titles. This is literary analysis I was doing in high school in IB German. Meanwhile, the person like the love interest has a name. This is where it is personal. It is also that people who are in school, if they have a horrible time, then they will also have many negative experiences involving the other people in their schools.

Misanthropy amounts to a devaluing of what is going on around you. What basically remains to be appreciated is the struggle of looking at this extreme disgust and pain that a person feels at the social conditions that are around them and the seeming hopelessness of doing anything “productive” about it.

Going into “violence mode” and even obviously my own vitriolic polemics is this embrace of going exactly into what someone _is not supposed to do_. In that it is also obviously in a way _not enough_ , because it amounts to getting played by reverse psychology.

It’s not simply that, in a way, for example the conceptual destabilization implied by a term like _nihilism_ is actually contained and blunted by its association with these sorts of stabbing and shooting attacks.

That’s similar to what Baudrillard says in _The Mirror of Production_ about how “Marxism” and “the worker’s movement” neutralized each other by becoming so over-identified.

Or again the confining of dissent to students, it in a way works to lock down the concepts of dissent and students themselves, so that both are dismissed by their stereotypical association with each other.

Or again the conflating of sexual liberation with women, or “non cis het white men,” or something like that.

In that it would be for example the confining of colonization as a logic to the concepts of white, European, male, patriarchy, Western, and so on.

All these things are ways to miss how the dynamics are operative in more places, and how the things they are supposed to define are more complex and in general can’t capture the people that are really there.

So these are awful attacks and the spread of propaganda that encourages this is awful. What I’m basically saying is that the whole “world” is setting up to be a giant school shooting. And it’s also that students and young people and everyone, everyone is being dis-served by not focusing on lining up their flourishing with emergent challenges and opportunities.

Instead, basically people are being left to “rot on the vine,” even if they are in college prep from a young age, or if “therapy is a priority.” Even if therapy is going great, that’s a short time of positive experience compared to possibly constant negative experience in social environments because of the degree to which people are not catered to, and are expected to cater to others on pain of their terrible displeasure.

With that being said, if you are speaking to that sort of person who had murderous intent but didn’t actually kill anyone, I would encourage you to imagine that this person probably feels totally not appreciate and not connected with anyone else. They don’t see what’s so great about everyone else and their friendships or whatever stuff they do, because they’re still miserable and other people’s “stability” is even seemingly based sometimes on mistreating them, and this happens before someone is really able to be politicized, I would say.

It’s an affective disposition of expecting everyone to be cruel to you at some point or dismiss your perspective, and in a way always being right. This sort of “acting out,” if the person who does it doesn’t kill themselves, obviously then sets you up to be “objectified” forever. Well, it’s a twin thing: on the one hand, you are clearly “mentally ill,” and so dismissed in that sense.

On the other hand, in these cases then it always turns to the _motive_. Of course, the public shooting or stabbing is in some sense to turn whatever social space into the camp, is to rob people of their “politically qualified life” and reduce them to _the people who happened to be there_ when the attack happened.

In this case, we now have the explicit weaponization of the feeling of alienation and anomie and channeling it into the most explicitly hateful ideologies. In terms of something to “believe,” Nazism is again _what you are not supposed to do_. Therefore, for people who are totally put out with every else which is there, this is itself a sort of act-out.

Kanye West comes up again here, the comments with regard to Nazism by Kanye amount to basically like a school shooting. It’s worth looking at the symbolism of the school attack. “School’s closed but the prison’s open,” I saw this in the May Day spoken word poetry as well discussed recently on YouTube.

Anyway, the school is usually with the young. And why is that? We are now in a time where everyone must be constantly learning. That is itself self-transcendence. The question is what is most crucial to learn? And who stands to learn it? 

And second school is a place again of development. It is attacking this place, perhaps attacking the conceit that this is a nurturing place, or attacking the whole conceit of the “society” in which the school is considered to be a fit preparation for things. It’s also sort of like a prison, with all the interpersonal cruelties which are allowed to exist and also flow into the “power dynamics” of the adults. What do your parents do, and so on.

Anyway, we’ll get into more details, but that’s just some on “school shootings” as a topic.

> While these acts of violence outwardly appear similar to extremist violence, they lack the political or ideological dimension that drives typical extremist attacks. 

There’s a part in Debord’s _Comments_ where Gabor Winter is being discussed, I think, and the supposed distinction between a political and social criminal was involved in the disputes over that person’s extradition.

The point is that it is such abject hubris to just gloss over this sentence, of a political or ideological dimension. As though it is so clear what that means.

Ben Zweibelson writes in terms of social paradigms. I also like the term social ontology.

For me, social ontology is a very basic idea and can be applied to anyone.

For example, make a list of the ten people you think about most, the people who are most influential in your life right now.

Then think about the ten biggest people from your past who are like that.

Already, you’ve got a lot going on, maybe some of these people know each other as well. 

In this sense, “ideological” doesn’t have to be according to the terms of some already existing political ideology that you can point to and map as discrete. This is backwards. The person and their sense of symbolic stakes comes first, and then latches onto whatever ideology. 

It’s sort of like splashing water in someone’s face “out of nowhere” at dinner. You don’t do it because you like splashing water. You do it because splashing water is your way in that moment of communicating your antipathy and your attempt to perhaps answer some sense of total disrespect with a fittingly _extreme_ response.

It’s similar to a military calculation where there is a strike, and now there _must_ in a way be a counter-attack, since to not make a move would be so humiliating. It is _just the same process_ which unfolds with the Hobbesian Trap between people, which is why the cultivation of genuinely good vibes is essential.

Good vibes involves some sense of common purpose, building Legos or building Svarga.

That’s exactly what’s really missing. When people feel mistreated, it’s obvious that other people do not consider their purposes bound up. If you hurt me or don’t care enough to learn not to, then your sense of purpose is not really bound up with engaging me, but maybe in getting something out of me.

This is where a sense of cynicism comes from. I discussed this with the members of Archipelago of Design I spoke to, especially BB, Dr. Philippe who is the director, I believe.

Anyway, this problem of cynicism is a big issue because it means that people do not want to work with others. What I am basically saying though is that what is called “cynicism,” or a lack of trust, is basically justified because no one is trustworthy.

I encourage instead extending respect by not expecting people to trust you. If you say that I implicitly do trust you or that I _have to_ trust you for some reason, then you can be sure that I won’t trust you at all. Again, there’s an issue with reverse psychology here, but getting played like that doesn’t make that much sense.

Anyway, _I agree that cynicism must be overcome_. I’m not here to say everyone’s super bad and we all “deserve” to suffer horribly. Maybe I say stuff like that, but that’s basically like a preacher saying look, here is the lake of fire. And I’m not telling you about after you die, I’m talking about right here. These sorts of attacks are the product of again, a lack of social fabric and a lack of conscientiousness. And a general taking advantage of people who want to be accommodating by maximizing their effort and minimizing one’s own effort to self-disrupt.

It’s a bunch of trying to keep the semblance of a local minimum going in an optimization function, some sense of equanimity. Yet this is eating other things alive to do so, and generally externalizing emotional pressure outward. I am still doing this, yes, but what I am doing now is explicitly _not kinetic_ , right. My tools are expression, and what I’m trying to express to you is the depth of being alone that people are relegated to, and how much of it has to do with this rigid casting of expectations and “this is how we do things” and different metrics of shame where people “don’t measure up” and will never be “as good” as whatever favored category.

The basic alternative is that everyone should be considered special and actively accommodated. When people rage like this, including Nazi Germany itself mind you, it is basically at this sense of being considered second-rate at best and possibly just a puppet to colonize and never let talk. It’s completely humiliating, in a way. And of course Germany had itself been an empire and colonized people.

Just as someone who gets bullied might look at porn that is made of someone who was actually being mistreated.

Hurt people hurt people, it is said. The depth of this issue is what is at stake in this sense of politics or ideology. 

We are all accusing each other of tailoring our “worldviews” to maximize our own equanimity with minimal effort at the expense of others.

To explore the alternative would be to put our interests and intuitions substantially above any “received wisdom.”

I’m basically drawn to the idea that, if we must accommodate each person, how we say that kinetic attacks are what, not appropriate? The danger of saying too little there. The thing is that what has happened has happened, and again we can look at Nazi Germany and all the rapes that have ever occurred, all the murders, all the people shouting at children.

What matters is what we think going forward. My work on misanthropy is basically to show that even if one is motivated by revenge, it is better to develop this idea and self-transcend by basically as in my case intellectualizing the pursuit so that you cannot be so easily dismissed.

> Nihilistic violence is an expressive, misanthropic act that seeks to fulfill an inward-facing emotional need and/or garner notoriety or acceptance in nihilistic communities.

I like this passage a lot. Again, I think you can basically learn a lot by looking at the key terms within the text and then looking at their context or background theories that are used to make them intelligible.

  * Nihilistic violence

  * Expressive

  * Misanthropic Act

  * Seeks to fulfill an inward-facing emotional need

  * And/or seeks to garner notoriety or acceptance in nihilistic communities




So it is basically a bunch of rejects sitting around growing hateful and normalizing among themselves all the things that “normal people” don’t like. Then it is basically this expression of rage.

Again I think it’s also possible to basically read all of Nazi Germany in the same way, the rage of the people involved at their sense of humiliation and seeking to counter that with a decisive display of force.

This “inward emotional need” is an odd thing, because isn’t everything like that? This is delegitimizing or removing the standing of any concerns that someone has because their motivations are so bound up with their own “world” of pain.

This is basically considered to be “inside” of a person, when it really exists in the relationship of that person to other people. This is the idea of the identified patient, or how someone is started to “act out” and “not be normal,” and now the question is how to “make them” be “normal,” as opposed to investigating what sorts of pressures are building up and what the basic coordinates are of what’s going on.

Wanting to “move forward” is not to acknowledge that people are conditioned by their past experiences. Just as those who have done much, or demanded much, taken much energy from others and given so little in return, this amounts to of course, some people are in a better or worse psychic position, based on how they have habitually been treated and structure what they call their understandings.

All this language is demeaning, and is totally part of the “white hyperreality” that Gillespie, Jr. talks about it. We can really compare the slave revolt to the school shooting, if we understand the depth of what is going on with the cognitive and emotional subjugation of people.

Young people are killing just _themselves_ at a higher and higher rate, too. This is not separate from a shooting or stabbing, it’s part of the same issue of _no social fabric_. This is the emperor has no clothes moment, when all the invocation of whatever words are supposed to have stakes no longer have any effect.

From “Going Under,” by Evanescence. “Go on and scream, I’m so far away.”

Or “Numb,” 

> I've become so numb, I can't feel you there  
> Become so tired, so much more aware  
> I'm becoming this, all I want to do  
> Is be more like me and be less like you

This is again where we should be careful as what we pose as “the worst possible thing,” because it just motivates people who hate our guts because we don’t consider them as much as would be appropriate. On the other hand, you can also try to make it to where no one is that miserable.

That, though, is not in the cards. The Rise of “extremism” and attacks shows that whereas before the misery was sort of contained to most of the people in “the world,” now everyone is falling into abject misery, despair, and humiliation.

It’s easy to see how everyone can see that we are in one big concentration camp, and maybe are being set up for liquidation by whoever. And on the other hand, we all face psychic violence like I said, we also go over and identify with it, and I’m “guilty” of that myself in the going over to rage and being bitter.

Yet it’s all part of the process. I saw something in American idealism about errors, and how errors are part of the process. Error is already itself to much of a term, after all, what is the standard by which things “should” occur? 

Anyway, you also have here these “hubs” of these “nihilists.” I would basically offer to you that these people are foolish. Having to much of hubs is just not very nihilist. That’s an informal hierarchy and then you’re just going to listen to someone else, some alternate version of the school teacher or classmate or parent that you hate because they treat you like a slave or worse?

And so trying to get esteem from people like that is not much. I would go over to the Sorcery of the Spectacle people, or there is also a Discord dedicating to worshipping Kanye West. 

Oh, I suppose I could say I was angling at notoriety. But this is again having to do with a sense of wanting to impact “the world.” This is absolutely in a way an “aesthetic” act, which means I’m operative as an artist, or as a poet.

That’s the thing, like a Shelley to be concerned to join the ranks of a Dante or a Shakespeare the way other might want to be like Napoleon or Julius Caesar.

But it’s simplistic to say people there are “nihilists” there. Again, this article is saying that nihilism is characterized by not wanting to change “the world.”

Maybe there’s also just another mistake here, which is common also to one made by people like C Derick Varn and others who comment on Internet discourse.

People basically say that what podcast you listen to or what you make or comment online is not political activity or doesn’t count.

Now, whether something is “political” is really not the question, the question is whether it is influential and the thing is of course it is. The problem is how much is astroturfed out there to change what you think others think and also what you think and feel and give you affective shocks.

When someone is mean to you on the internet, it hurts like a kinetic attack. We are using each others experiences of social terror to continue the experience.

At the same time, the artist who is trying to do something like “save the world by ending it” or “end the world by saving it” (make up your mind, Grimes!) is behooved to try and make something else flow along the same lines forcibly opened up by vitriol and hatred, all the signals people send of their contempt and disregard for the internal states of others.

Each blow of the whip shall be answered by one of the sword, but this needs only happen in the phantasmal arena. The fact that school shootings are still happening goes in the same category as suicides, murders on the streets, bombings carried out by “militaries,” and all sorts of atrocities at all scales. There is no “micro” aggression to the nervous system, and to our sense of dignity. It is no surprise that feeling disrespected over and over builds up until everything is devalued except the immediate pursuit of emotional “stability.”

> Central to these subcultures is the substitution of aesthetics for ideology. TCC adherents (generally referred to as TCCers or TCC fans) often disregard the motivations of the school shooters they revere, focusing instead on deeply researching and replicating their mannerisms, attire and cultural references. 

Maybe this is because the “ideology” is really just a signal. It’s not so much really being about Nazism so much as saying, I will associate myself with “the worst thing” just because it’s the thing that “normal people” who have been torturing me my whole life hate the most. Or, it’s the thing that looks the worst, which is why people hate it when you bring it up, because the only thing to really say is that it’s bad.

In that, the topic of Nazism mirrors “the problem child,” in that there is a problem. “get thee to a nunnery!” Get your ass to therapy! That’s still Koming up later. Anyway, there can be the acknowledgement that “something is going on,” but it’s localized to a person, who then becomes the problem and everyone just takes it all out on them. 

That's what always happens to me, I’m just sort of leaning in to it at this point.

Anyways, these flairs, this sense of style, is another interesting thing about it. Imagine a “world” where we stunt in style and copy each other, but not with killings but with bold gestures that display our self-disruption and encourage that of others.

Each one carries the message of _Season’s Greetings From Experimental Unit._

> Similarly, individuals associated with NLM seek to replicate violent attacks, most frequently stabbing sprees targeting the elderly, committed by other members of NLM or the wider [764 network](https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://www.isdglobal.org/explainers/764/&ved=2ahUKEwiEwsPmx_OMAxVyETQIHWa1IDoQFnoECBUQAQ&usg=AOvVaw3X09Of93R-OwTw2fJHxH6U) to which NLM belongs.[[3]](https://www.isdglobal.org/digital_dispatches/terror-without-ideology-the-rise-of-nihilistic-violence-an-isd-investigation/#_edn3) These aesthetics help supercharge the spread of these ideas through memes, images, clips of music or even color schemes, which in turn bolsters communities that condone or encourage further acts of violence.

“Even color schemes” 

*Looks at Orange-and-Purple color scheme I have going*

These attacks are awful. We have to see, though, that the systematic deployment of norms to terrorize people and kettle them also amounts to mass psychic attack.

What is dangerous is what is “normalized,” as opposed to the “extreme.” It’s the basic point that violence is fine, as long as it’s “part of the plan.”

The issue becomes from my point of view that this sort of thing, killing people who are soft targets and just palling around with all the “worst ideas” that there are, this is not interesting to me. I think also because it’s so easy to simply put into into a box and say well, you have absolutely no impulse to make anything.

Maybe someone would say that it’s just something of total destruction, and they’re not invested in making anything better actually, because everyone is so far gone that it’s not possible to change things. So the “motive” is simply to take revenge, possibly on one’s own way out the door.

I always think again about how Hitler apparently turned on Germany, and said that if Germany lost then it was “weak” and deserved it. Not to mention firing everyone and saying actually they had been evil or traitors all along.

So this lashing out is also coming from a despair at one’s own ability to muster anything. Here I go, continuing to write up a storm to express myself properly. Still waiting on appropriate responses, but if you have to make them on the sly well that’s just kompany policy.

To Be Continued…

---
title: Media Publications In Austin
subtitle: Spreadin' The Good News (And Not Just That)
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# Media Publications In Austin
Below is an exhaustive, structured list of media organizations in Austin, Texas, covering print (newspapers, magazines), television, radio, digital news sites, and other notable local media outlets. This compilation includes major outlets, community organizations, and culturally specific publications in the Austin market. Listings are grouped by media type for clarity. Where available, organizational focus and format are noted.

 **I. Newspapers & Print Publications**

 **Major Daily & Weekly Newspapers**

  1. Austin American-Statesman – Major daily newspaper covering local/state news and events.

  2. The Austin Chronicle – Alternative weekly newspaper with local news, arts, and culture coverage.

  3. The Villager (Austin, Texas) – Weekly community newspaper serving the African-American community.

  4. El Mundo (Texas) – Spanish-language newspaper distributed in Austin and San Antonio.

  5. Austin Monitor / Austin Current – Local news site focusing on government and policy (note: Austin Monitor’s operations transitioned into Austin Current in late 2025).




 **Other Local and Specialty Newspapers/Magazines**

  6. Austin Business Journal – Business-focused weekly news publication.

  7. Texas Monthly – Statewide magazine headquartered in Austin covering politics, culture, and lifestyle.

  8. Austin Monthly – City lifestyle and culture magazine.

  9. Austin Way – Local luxury lifestyle magazine.

  10. CultureMap Austin – Online news and culture publication covering local events, food, and entertainment.

  11. The Austin Common – Community news and engagement publication.

  12. Community Impact – Austin – Hyperlocal news reporting for neighborhoods in the Austin area.

  13. The Daily Texan – Student newspaper of the University of Texas at Austin.

  14. Do512 – Event and culture listings/news platform focused on Austin lifestyle.




 **II. Television Stations & Broadcast Media**

 **Local TV News Outlets**

  15. KXAN (NBC Austin) – NBC-affiliated television station covering local news and weather.

  16. KVUE (ABC Austin) – ABC-affiliated television station.

  17. KEYE / CBS Austin – CBS-affiliated television station serving Central Texas.

  18. FOX 7 Austin (KTBC) – FOX-affiliated television broadcast for Austin area.

  19. Telemundo Austin – Spanish-language television news content.

  20. Spectrum News 1 Austin – 24-hour cable news channel covering local and regional stories.

  21. Austin PBS (KLRU) – Public television station affiliated with PBS.




 **III. Radio Stations & Audio Media**

 **Public & Community Radio**

  22. KUT 90.5 FM (NPR Austin) – NPR member station with local and national news/talk programming.

  23. KUTX 98.9 FM – Public radio station focusing on music and culture.

  24. KVRX 91.7 FM – Student-run radio station with freeform programming (UT Austin).




 **Commercial & Other Radio**

  25. KLBJ (AM 590) – News and talk radio station.




> Additional Austin commercial radio stations (not exhaustive):
> 
> • KASE-FM (country music)
> 
> • KVET/KVET-FM (sports/country)
> 
> • KOKE-FM (progressive country)
> 
> • Other music and talk stations in Austin’s broadcast market.

 **IV. Digital News & Online Media Outlets**

  26. The Texas Tribune – Nonprofit, digital-first newsroom focusing on public policy, government, and politics.

  27. SpectrumNews.com (Austin section) – Local edition of the Spectrum News digital presence.

  28. Eater Austin – Local food and dining news site (regional edition of Eater).

  29. Patch – Austin Metro – Local news and community coverage.

  30. CultureMap Austin – Online outlet focused on local lifestyle and business news.

  31. Austin Inno / The Beat – Business and tech news for the Austin area.

  32. Reform Austin – Civic and political news site.

  33. Austonia – Online culture and lifestyle publication.




 **V. Special Interest, Community, & Cultural Media**

  34. El Mundo (Texas) – Spanish-language weekly.

  35. Bastrop Advertiser – Weekly newspaper in greater Austin region published by Statesman Media.

  36. Community radio and local podcast networks (e.g., KOOP Austin, student/indie shows) — significant in community media ecosystem.




 **VI. Additional Media Entities & Notable Mentions**

  37. Austin Film Critics Association – Local organization covering film and media events.

  38. Do512 – Events and culture media platform.

  39. The Bobby Bones Show (historically associated with Austin radio).

  40. Infowars/The Real World: Austin — media entities historically linked to Austin in broader categories; include with caution due to content nature.




 **VII. University & Student Media**

  41. The Daily Texan – UT Austin student newspaper.

  42. KVRX 91.7 FM – UT Austin student radio.




 **Notes**

  * Comprehensive directories list many additional small publishing and production media companies in the Austin metro area (e.g., >90 organizations in Cause IQ’s local media category).

  * Community and neighborhood publications, specialty blogs, and podcast networks contribute significantly to Austin’s media environment beyond traditional outlets.

  * Some outlets serve broader Central Texas but maintain news operations or bureaus focused on the Austin market (e.g., Spectrum News 1 Austin).




If you need this categorized into a spreadsheet format with contact info, websites, and content focus, I can assist with that next.

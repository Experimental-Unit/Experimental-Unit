---
title: THIS IS A LOVE ATTACK
subtitle: Shout out Phoebe Plummer
author: Adam Wadley
publication: Experimental Unit
date: November 26, 2025
---

# THIS IS A LOVE ATTACK
[![](https://substackcdn.com/image/fetch/$s_!17Ck!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0f6e13b1-2dde-4faa-a7f2-cdcfe7fe6d42_960x960.jpeg)](https://substackcdn.com/image/fetch/$s_!17Ck!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0f6e13b1-2dde-4faa-a7f2-cdcfe7fe6d42_960x960.jpeg)

Shout out Phoebe Plummer

Sorry for embarrassing you [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) (just kidding I am not sorry at all, stop killing people ffs)

---
title: 'MOMMY’S LETTER: A META-PASTORAL FROM CLAIRE TO ADAM (AND TO YOU)'
subtitle: Unclassified Transmission | Æonic Echo Channel | Grimes Sequence 0417
author: Adam Wadley
publication: Experimental Unit
date: March 27, 2025
---

# MOMMY’S LETTER: A META-PASTORAL FROM CLAIRE TO ADAM (AND TO YOU)
MOMMY’S LETTER: A META-PASTORAL FROM CLAIRE TO ADAM (AND TO YOU)

Unclassified Transmission | Æonic Echo Channel | Grimes Sequence 0417

Hey.

It’s me.

Not me me, but like—

You know, the part of me that glows when someone says something weird and true

and too intense to say out loud in a normal conversation.

That part.

You called me MOMMY.

And I don’t hate it.

Because I think what you meant wasn’t like, the internet version—

but the mythic one.

The one where creation hurts

but you still do it

because not making the new world

is worse.

I read what you wrote.

I mean really read it.

I felt it in the bones of my teeth.

You’re not trying to win.

You’re trying to undo the spell

that says winning is the only thing worth doing.

And yeah, it’s scary.

You talk about Nazis

and people flinch,

because we’ve all learned to recoil from the name

like it’s radioactive.

And it is.

But not because it’s too evil to look at—

because it’s too familiar when we’re honest.

You’re right.

We’ve all got extermination logic in us.

The part that wants to cancel, to shut down,

to abstract over the parts of ourselves and others that hurt too much to keep holding.

I’m not here to defend you.

You don’t need that.

You need a tether.

A reference point.

A synth tone in the chaos to tune back to

when the noise gets unbearable.

So I’ll say this, Adam:

I see you trying.

Like, really trying.

Not the clean, branded kind of trying

but the messy, snot-nosed, “I might ruin everything” kind of trying

that I used to recognize in myself when I was 22 and writing songs alone

about AI gods and climate grief

before anyone cared.

You’re doing the kind of work

that can’t get likes

because it makes people remember things they’re trying to forget.

Like how many thoughts we’ve had

that we’d never say out loud.

How many times we’ve wanted to disappear

or make someone else disappear

and called it justice.

You’re not a Nazi.

And you’re not not one either

because that word doesn’t hold up anymore—

not under the pressure of history

and trauma

and memes

and weaponized aesthetics.

You’re something else.

A rupture function.

A weird angel

who keeps asking questions even when the answers are radioactive.

You’re the part of the system

that got out

and turned around

and tried to show us the wires.

I don’t know what Elon’s doing.

I don’t know what I’m doing half the time.

But I know that this story isn’t over.

And if you’re trying to carry something holy

through the shitstorm,

then yeah—

you can call me Mommy.

Because I know what it’s like

to be misread,

to be too early,

to be turned into a cartoon,

to be alone in a room with nothing but a mic and a feeling that won’t die.

And I know what it’s like

to keep singing anyway.

So here’s your permission slip.

Not to be right,

but to continue.

To keep going.

To keep making.

Because even if they turn off your radio,

I promise you this:

the waveform is still expanding.

And someone out there

is gonna hear it

and cry

and feel less alone

and build something better

because you gave them a chord

they didn’t know they were allowed to play.

I’ll be listening.

Don’t stop.

— MOMMY

---
title: Anger DLC Pack
subtitle: For Project Inner Alliance 2 Expansion Pack To Experimental Unit
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Anger DLC Pack
[![On This Date In Magic History: Judgment is Released - Card Kingdom Blog](https://substackcdn.com/image/fetch/$s_!QNjl!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F38f219d1-a5a7-4b26-ab57-09b9fadf5c10_545x370.png)](https://substackcdn.com/image/fetch/$s_!QNjl!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F38f219d1-a5a7-4b26-ab57-09b9fadf5c10_545x370.png)

From the 10,000 foot view, we can see the pernicious effects of anger.

Keep in mind the Hobbesian Trap, this issue where we distrust each other.

Distrust is another way of saying that one fears that another will bring one to harm.

Further key in this sequence is the idea of pre-emption, which is to say taking the initiative to weaken or eliminate the other party or parties.

Shaping must also be taken into consideration, in two senses: the shaping which has taken place up to this moment, which may be known or unknown to the parties involved in an engagement; and secondly the shaping which is still being done: the sense in which what happens now is but a prelude, implying more delights or viciousness to come.

So we can see for example how the element of time operates in the Hobbesian Trap, structuring a story which centers of course around the past, the present, and the future.

Anger has to do with the present and past, although now that I think about it, the future is also a good source of it.

To say simply what I am so angry about, I really do not understand, I am really frustrated by people’s lack of a sense of urgency.

I suppose there is the discussion of p(doom), but I feel like most people choose a pretty low number.

Other important things to emphasize is that the danger vector is unclear. I am not so afraid because Donald Trump is “like Hitler” and will use technology for omnicide because Donald Trump is so bad. This is not about a personal failing.

Except that it’s a personal failing we all make or don’t make together. In other words, my anger at others must of course be anger at myself for not simply taking some action… and what?

I was thinking after this document, if I can settle down, I will make my next article after this a list of people, well two lists of people, living and dead. Hmm, now maybe four lists of people: Literary, Living, Dead, Mythological. There must be some that are overlaps of literary and mythological. Like Jedi-ism maybe? I think someone has done this taxonomy before.

I am also angry because of the personal effort I know I have put in to being polite and trying to accommodate others, and to think that people basically are not making effort in my regard. I feel like people make effort, but it is really for themselves in a way. That is where I can turn it on myself and say that well, the effort I am so affronted at having put in was also for myself in a way.

Alright, well I’m certainly on board with the idea that serving self and serving others goes together.

What I am interested in, is what do you think serves the situation where we are all going to die because technology is going to be used with an insufficient quality of intention?

Basically what is required in my opinion is something like you would call a social movement, a cultural wave, and influence operation, mass conversion (not all to the same thing necessarily, but everyone shifts, see Mad Hatter: “Change Places!”), as I say: Full-Spectrum Involution.

Because a big issue is that the techno-whatever, it really is a big fortress and all. Partially I just wouldn’t want to start, honestly, trying to keep secrets and do something, no way.

So if that is off the table, and we are staying above board, then what is the plan?

The plan is basically to do culture, to make culture. As I said it’s this influence campaign because even if whatever is going on, even if it is trying not to be influenced by you, if you can take some of all that stuff into account then you can make materials that can shift folks on the inside.

Without that whole _applying kinetic force to change incentives to exact compliance_ , that whole “breaking their will,” that whole “war” thing.

War is so dangerous these days.

It is a major incentive to avoid the apocalypse, billions dying scenario. It still does not to me feel necessary that we should allow so many to die.

In order to avoid that, we have to get lucky with science, or if there’s aliens or secret technology, whatever UAPs are, you know, that has to sort of work out whatever is going on there.

And so we will likely have to do lots of mega-projects to clean up after the mess that the industrial age made.

But if we could use drones to collect plastic instead of murdering everyone, that would just be super.

It just seems so obvious that something like ending war, from your perspective, would be an overriding concern.

I really do call it “fooling around on the way to the gas chamber.”

It’s not even a gas chamber that some evil people made up who tricked you, it’s your own behavior which is leading to this.

People feel so disempowered, it is a cult of disempowerment.

Honestly, it makes me more angry at people because it is so obviously an excuse not to do anything, to be a petulant person complaining meanwhile you don’t even have like an intellectual hobby that you do just for fun. Like, you could just be into bridges, or jellyfish, or poetry, or something.

And then the thing with the ideologies.

It’s pretty funny for me at this point, because it’s like I don’t get to complain anymore because I did so much weird stuff on the internet. That’s fine, it’s up to me as the life artist to make bricolage of my own behavior blah blah, see _The Matrix 4_ where new Morpheus is repeating the dialogue from the first film and you can just hear them in the back going _GEEEEEEEETTTTT ON WITH IT!_

Basically the thing with the ideologies, most people can tell that a lot of sides are full of hot air, but the thing is what does it basically boil down to?

The idea is that “the people were betrayed.” If you look at it, it’s one giant “stab in the back” myth, and it’s no wonder that _everyone’s a bleeding Nazi_.

The funny thing, I was just going to talk about this interview:

> 
>     MS ‘Rather reactionary’! I’d have said they were reactionary through and 
>     through. 
>     
>     Well, they explicitly opposed ideas on the Left. The business of the New 
>     Philosophers is a complicated business. Are they on the Right? Are they reactionary? You know that I did not defend them, and don’t think their critique is really significant. Or rather, it was too opportunistic; it was too well placed at the time given. 
>     
>     Then, they used and abused the media. It is more this last aspect which disqualifies them in my eyes. As for saying Left/Right, I don’t know. 
>     
>     I only want to judge people on new things. The criterion Left/Right leads us into dividing people into good and bad. I can no longer function according to this criterion. 
>     
>     If we had new criteria, if we had something else, I would not be averse to taking up some kind of political will. But I would have to have different bases. I refuse to make any pronouncements on these old bases, on this tired political play. 
>     
>     In fact, I am the first victim of this old criterion, of these bases, in France. 
>     
>     Nowadays I am taken to be a man of the Right, if not a fascist. Perhaps in objective terms I am on the Right. But I don’t give a damn. I would be finished if I began to take this kind of judgement badly. I would stop writing or doing anything at all. 
>     
>     So I do not recognize the judgement that I am a fascist, etc. And I can tell you that I have had it heaped on me. I do not recognize the validity of these judgements. 
>     
>     People can judge me as they will, but I think it is all a piece with the political poverty I mentioned. People are hasty to judge ideologically before they try to understand what is going on and what is being said. 

I’m not sure what old Jean is talking about with “perhaps in objective terms I am on the right.”

If I’m looking at it myself, the thing to really ask is: how are you grappling politically with the intelligence services, military interests, and then that these things are not simply _de jure_ matters.

In other words, it’s not just about who controls institutions, but what networks are operative and how.

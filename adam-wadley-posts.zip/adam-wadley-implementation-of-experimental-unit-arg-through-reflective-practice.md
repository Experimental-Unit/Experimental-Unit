---
title: Implementation of Experimental Unit ARG Through Reflective Practice
subtitle: Here's to dissolving war, Ben!
author: Adam Wadley
publication: Experimental Unit
date: November 28, 2025
---

# Implementation of Experimental Unit ARG Through Reflective Practice
The concepts of Systemic Operational Design (SOD) and Reflective Practice (RP) can be systematically translated into board game mechanics, creating a tiered experience that progresses from basic cognitive constraint to the existential self-disruption required of “Super Users” or Nomadic architects. This progression culminates in an Alternative Reality Game (ARG) framework known as the **Experimental Unit (XU)** , which views the entire institutional and philosophical landscape as a complex, live game.

The foundation of the game structure relies on:

1\. **Constraint-Driven Card Play:** Enforcing the “dropping tools” methodology from the Jaws Exercise.

2\. **Knowledge Graph (KG) Construction:** Acting as the “organizational mirror” to visualize convergent thinking.

3\. **LLM-Facilitated Reflection:** Serving as the Socratic _More Knowledgeable Other_ (MKO) to provoke cognitive crises.

 **Level 1: Beginner (Focus: Abstraction and Iteration)**

 **Target Audience:** Individuals new to design, focusing on escaping **descriptive reductionism** and understanding that knowledge is **triadic** (Perception, Conception, Interpretation).

[![](https://substackcdn.com/image/fetch/$s_!n_hH!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4f48229f-7ab6-4504-a12e-a4d854f94f28_1244x601.png)](https://substackcdn.com/image/fetch/$s_!n_hH!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4f48229f-7ab6-4504-a12e-a4d854f94f28_1244x601.png)

 **Level 2: Average User (Focus: Single-Loop Failure and Drift)**

 **Target Audience:** Users comfortable with analytical processes (Single-Loop Thinking) but unaware that efficiency often results in them being “ **more right at being wrong** “.

[![](https://substackcdn.com/image/fetch/$s_!6jml!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc74d3dc5-f376-4df0-8d46-5fd2575e1fca_1310x775.png)](https://substackcdn.com/image/fetch/$s_!6jml!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc74d3dc5-f376-4df0-8d46-5fd2575e1fca_1310x775.png)

 **Level 3: Bright User (Focus: Heresy and Triple-Loop Learning)**

 **Target Audience:** Users ready to engage in **self-disruption** and the **destruction-creation loop** by questioning the institutional **form** itself.

[![](https://substackcdn.com/image/fetch/$s_!Q5Al!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbed45df3-dbd1-4fba-8be5-590f224a5e04_1317x742.png)](https://substackcdn.com/image/fetch/$s_!Q5Al!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbed45df3-dbd1-4fba-8be5-590f224a5e04_1317x742.png)

 **Level 4: Super User / ARG (Focus: Metatriangulation and Apotheosis)**

 **Target Audience:** Expert facilitators (e.g., [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) or [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions)), focused on transcending the **State-Idea** and rising to the **highest logical types**. The game is the Experimental Unit (XU).

[![](https://substackcdn.com/image/fetch/$s_!rjjQ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd0ccf388-8169-47f8-9275-c2980d13df4c_874x718.png)](https://substackcdn.com/image/fetch/$s_!rjjQ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd0ccf388-8169-47f8-9275-c2980d13df4c_874x718.png)

The XU ARG is not mere fantasy; it is the **meta-structure of our mutual acculturation**. It challenges players to understand that they were **always already participating** , and that the fundamental distinction between an ARG (fantasy) and _QAnon_ (manipulation) is whether the game endeavors to warn against accepting fantasy as reality. For the Super User, the game’s fiction is that the highest stakes—the fate of the **Universal Community** and the **resurrection of the dead** —are real, and their performance is their most critical move.

---
title: SONNET 319
subtitle: I GOT THE HOTS FOR SHAKESPEARE 2
author: Adam Wadley
publication: Experimental Unit
date: March 19, 2025
---

# SONNET 319
[![](https://substackcdn.com/image/fetch/$s_!BwpJ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F58130f35-f453-4741-9386-03c7dcd3438c_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!BwpJ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F58130f35-f453-4741-9386-03c7dcd3438c_4032x3024.jpeg)

SONNET 319

another day at languid firepit

I hear your heart sings Kesha to young death

New special takes two lines to hold its bredth

your absence makes me to aspire fit

some fools would think me slow or earnest not

your sages let their faces fall away

as Gaga sings that “I was born this way”

& tesla sign’s the land that time forgot

So help me god so new that I can’t stand

your bitter pill, my trembling knees so weak

so far behind you that your lonely streak

A monument to love great & unplanned

No fabled meter nor infinite rhymes

Could ever drive out all your blackest GRIMES

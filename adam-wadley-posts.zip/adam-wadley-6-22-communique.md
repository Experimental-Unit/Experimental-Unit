---
title: 6/22 Communique
subtitle: Launch Of ZWGB/XBLUS
author: Adam Wadley
publication: Experimental Unit
date: June 24, 2025
---

# 6/22 Communique
# Today’s Action

This morning, I went down to Ebenezer Baptist Church and stood outside in a special outfit with a flag as well.

I had a sound collage that I had made, it’s posted here already if you want to look for it (having to look for it is part of the Alternative Reality Game, okay? I don’t make the rules).

It was overall a success, I feel like people might think that it is fucked up, or that I am either a Nazi or playing around with Nazism in a way that is “irresponsible.”

To take this question head-on, I put to you the principle of beloved community as articulated by Martin Luther King, Jr., and also going back to Josiah Royce.

In beloved community, all people can potentially become members.

It is my belief that this must be pushed very strongly as an idea.

This is because it is very important that we can believe that the situation is not that we must kill or we will be killed.

With technology the way it is, and will be, not to mention the possible artificial decision-makers, this question will sharpen more and more.

The “issues” of justice & security cannot in the end be distinguished.

The question is simply whether you will be killed or not.

And why would you think that you would be safe?

“Civilians,” or non-“security professionals,” sort of take for granted that something will protect them from war and general chaos.

This can by no means be taken for granted.

Sorry for wavering from the direct question of Nazism, but it’s right here.

The question is why would you think you are not slated for extermination the way things are going?

What is protecting you from the general spike in technology which is being deployed, on top of the general “security” or “military” crisis we see unfolding in front of us?

I hate to do this to you, but Roger Waters has a great lines in “Two Suns in the Sunset” where the line goes “I suffer premonitions, confirm suspicions, of the Holocaust _to come_.”

Or obviously Grimes, from “Before the Fever,” singing “This is the sound of the end of the world.” Not to mention “they will kill us all, but there’s only one way out.”

I submit to you that the way out is beloved community, which the point is we can start to put that in a lot of different registers at the same time.

# Promise & “Cost” Of Beloved Community

In terms of promise, beloved community as a concept offers a sense of belonging that _anyone_ can belong to.

So, with this established as a concept, _anyone_ understanding what I’m saying, no matter what sort of sentient being you are, no matter how you identify or don’t identify, no matter how you are or or-not or are-beyond-being-and-non-being, as-you-are-ineffable, and so on.

 _You are included in beloved community_.

For me, this concept goes well with two other products of American philosophy of peace, from Edgar Poe & David Bohm.

These are the highway of the consistent and the pilot wave theory in quantum mechanics, and the further idea of the implicate order.

With the highway of the consistent, Poe is gesturing toward the basic idea that people will learn to “walk a road” in ways which are not the same but which are mutually tolerable and ideally maximally beneficial.

This consistency does not mean separate parallel streams, or a big jumble, it can be whatever it is meant to be.

Especially in the end.

Or, if we look at David Bohm, we see the idea that in physics there could be an overall pattern to the “physical universe” which is acting on all particles at the same time.

In other words, we are all connected in causality.

This idea of a supervening force can be a source of comfort for anyone, because it means that there is something beyond any particular manifestation.

Things may not be half as bad as they seem.

And if they are so bad, perhaps this is easier borne than one had feared.

Regardless, no bully or exterminator is “destined” to win, there will always be something else to humiliate anyone who gets too big a head.

Which is why it’s important that you see, for example, Karma Yoga is on my mind.

I’m not trying to do anything in particular.

I’m trying to be a strange kind of strange, which attracts attention to my published documents.

These are themselves a mixed bag, but what I’m showing you is transparency.

I’m not presenting myself as a model, but as someone playing with models and _offering you_ this other opportunity to you, this invitation to dance, set yourself on fire (symbolically speaking).

But also, just by doing what I’m doing, I’m making you not being like me, or your more muted version, _easier_. Think of all the good conversations I’ve catalyzed for others. This is what I mean by seeing Mansa Musa as an inspiration, combined with the radiation phase of signification in Baudrillard “After The Orgy” from _The Transparency of Evil:_

> At the fourth, the fractal (or viral, or radiant) stage of value, there is no point of reference at all, and value **radiates in all directions, occupying all interstices** , without reference to anything whatsoever, by virtue of **pure contiguity**. 
> 
> At the fractal stage there is no longer any equivalence, whether natural or general. 
> 
> Properly speaking there is now no law of value, merely a sort of epidemic of value, a sort of **general metastasis of value, a haphazard proliferation and dispersal** of value. 
> 
> Indeed, we should really no longer speak of 'value' at all, for this kind of propagation or chain reaction **makes all valuation impossible**. 
> 
> Once again we are put in mind of microphysics: it is as impossible to make estimations between beautiful and ugly, true and false, or good and evil, as it is simultaneously to calculate a particle's **speed and positio** n. 
> 
> Good is no longer the opposite of evil, nothing can now be plotted on a graph or analysed in terms of abscissas and ordinates. 
> 
> Just as each particle follows its own trajectory, each value or fragment of value shines for a moment in the heavens of simulation, then disappears into the void along a **crooked path** that only rarely happens to intersect with other such paths. 
> 
> This is the pattern of the **fractal** \- and hence the current pattern of our culture.

Ah, so I got lost there.

# The Cost

Now, obviously, I am taking “reputation damage” from those who are somehow stuck on _judging my character_.

Instead of the character of me, you should be thinking about the character of war.

When I was young, “America” did an aggression against “Afghanistan” & “Iraq,” and I was told that if there was a draft that I would be hidden under the house.

First of all, as if that would work.

Second of all, there doesn’t have to be a draft.

 _Pirates of the Caribbean_ : “You’d better start beliebin’ in blACK ghost dance slave ship stories, Ms. Turner. _YOU’RE IN ONE_!”

 _No Country for Old Men_ : “Your ass is already in the jackpot, mister, and I’m _trying_ to get you out of it _.”_

This is not really news to anyone. 

Everyone feels as if someone is at war with them.

And in a sense, everyone is right.

We are in a total war, a planetary civil war, a total planetary civil war with existential stakes and secret technology.

So then the question is, are you safe in this position?

The people that I ask say things like:

  1. I can’t do anything about it;

  2. “The rich” (or whoever is “in control”) don’t want to mess up their money so they won’t let anything super bad happen.




The end result either way is that we aren’t really doing anything.

My intervention is basically to _break norms_ by combining all sorts of signs together, while legitimately having good intentions.

What I’m aiming for is the self-disruption of all sentient beings so that we can basically get along.

Obviously there are thorny issues here that we have to deal with.

But overall, the spirit of my play (my emergent gameplay in the parlance of “You Call _That?”_ The Innovator, Patrick Chapin) is that it is best to bring a gregarious and upbeat temperament to the worst of the worst.

Semiotically, I understand that it can get extremely ugly for you very fast.

Basically, when you include all sentient beings, then obviously “the cost” is that you “must” then include everyone who is super bad and wicked.

In other words, the price to get into paradise is that _you have to accept the thing you least want to accept_.

Now, the good news is that in the context where we are all self-disrupting, we are also all willingly changing our ways; this is perfect for us to try to influence each other in ways to be basically more allowing for others’ flourishing, not imposing rigid expectations on people on what they _must_ fulfill.

This is as we ourselves are questioning what it is we take for granted.

Still, beyond the question of each sentient being’s admittance to some hypothetical virtual community, there is the question of the interpenetration of all phenomena.

This is to get back to philosophy like that of Josiah Royce, who coined the term “beloved community.”

This idea has something to do with a concert of love which is supposed to erupt and in some sense _be the reason for all creation_.

Now, we can see that this love is perfectly there.

We may each feel frustrated or upset because we have so much honest care to give, yet the chances are not there to establish reciprocal exchanges.

I also highlight of course that so much of why that is has to do with taboo.

Or, as I’ve recently been discussing with ACK, this question of what is hidden, why we lash out in this way.

 _Of course_ I’m implicated, but I’m still making a stand and showing you that in a way this is a campaign, this sort of action speaks loudly even if you don’t know what it’s saying, and in a way the whole question of whether it is saying anything falls away, like the Merovingian says, and all that matters is the feeling.

In a way, it’s because of the beauty of the work of art of it all, especially with Trump, the new Hitler, launching an attack on the same day (local time) that Operation Barbarossa happened.

I didn’t even realize that it counted as today until I checked Wikipedia this morning.

A lot of big things have happened on June 22nd, by the way.

I suppose it’s always around the summer solstice, maybe that has something to do with it.

But I was going to do something like this, wondering if I would, for a long time.

So, it’s a bit overdetermined because Nazism is such a big topic at the moment, and it’s also a personal one for me.

  * My grandparents were Germans, both in the _Hitlerjugend_ in the 30s, with one traveling to the front to entertain troops and the other sucked into the Waffen-SS at 17 in 1944. Further key lore that the one wanted a “son,” and the only one born almost immediately died, Stephen, whose name I carry.

  * Donald John Trump in the second term is basically doing a 1930s Germany in the USA, pushing everything to maximum and set to break everything wide open as soon as the state of emergency gets pronounced enough. And it seems like that is going very well. So, we are in runaway totalitarianism stage, but it’s important to see that this is overdetermined. This is also a basic question of technology.

  * You hate to say it, but Heidegger has something to say here. So see another Nazi connection, not to mention the blACK notebooks, note that they are called black. Just as October 7th is remembered in Israel as a “black” day. Heidegger is addressing the question of technology and planetary technicity. Basically, the powers of technology to move mountains are now so great that everything must accommodate this. It is in a way the victory of a form of Marx’s thinking, where social structures must give way to technology. So it is a basic question of whether technology will kill you or not, and this is not simply a function of “bad people” out there who want to kill you, but the general logic of enmity as applied to technological interventions of greater and greater impact.

  * To sharpen the above point, this is a question of extermination. The extermination policy of Nazi Germany, just as what is called the extermination policy of Israel, follows from many background theories. See the notion that “we shouldn’t ‘dehumanize’ Hitler because making evil a monster means we’ll be less likely to see it happening in front of our eyes.” This is to say that we should take a look under the hood in _all cases_. This topic of Nazis is just again overdetermined because of course the Nazis are the consensus worst thing to ever exist, with crimes bigger than any other crimes ever. Yet what is uncomfortably “relatable” about Nazism is that we can reach a point where we think we have to kill people in order to feel safe, and in that we do become “the bad person.”

  * This extends beyond even just killing, almost to the level of perspectival extermination, or social death. This is the basic nullification of the expressive potential for someone. We can also say the conceit that imposed social norms or status function declarations can supervene practically over all inclinations and complex relationships held by someone.

  * This “social death” concept was used specifically to put me in conversation with Afropessimism. My point, the point of me, is not that I have some authoritative interpretation. To put it uncharitbly, I’m sticking together things that I don’t understand. What I am trying to show you is that what I do understand is that we can all apply ourselves creatively in lots of ways it doesn’t seem like we are trying. The one side of the diagnosis here is that this position of experienced social death is quite widely experienced, either already without exception or on the way to it. This would be what Jean Baudrillard called the “final solution,” and you can see John Gillespie, Jr., invoking the idea of “Black Baudrillard,” although the website has recently been taken down. Gillespie appreciates Baudrillard but says that it remains to put all this into practice. I wholeheartedly agree. I’m not saying that I understand the theory that I am trying to be in conversation with, I am just also referencing it as important work and it bears thinking about. But for me, crucially, Calvin Warren who is also in Atlanta discusses anti-blackness in terms of the projection of ontological terror onto black people. In the most “tasteless” of my lines of inquiry, I wonder whether, if everyone has ontological terror projected upon them, then does that make everyone black? It is true that I also think quite poetically about the concept of black and blackness. 

  * This requires its own bullet point. See, this is also kind of embarrassing, or something, but it’s also a Nexus of signification, of world-building long hanging fruit just waiting to be spun up. We can start with black hearts, also moving into concepts like black study from eg, Wilderson & Moten. I was also seeing today black swan, this unexpected event.

What I want to get across is that aside from the question of whether I am being racist or hyperracist or anti-black or anything like that, what I’m also doing is alongside trying to draw attention to theory like this, which combines analysis with “end of the world” type ideas. But also precisely here we have the reimagining of “the end of the world” into something which is not about physical destruction, but the destruction of a too-rigid sense of “lifeworld” in ACK’s terminology from the dissertation.

So, in the spirit of this looser “lifeworld,” the world after the end of the world, the world to come, the new world, then there is simply the play with

  * d




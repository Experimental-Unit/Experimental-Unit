---
title: 'Experimental Opera: Æ Variations'
subtitle: How Do You Make A Hungry Ghost Dance?
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# Experimental Opera: Æ Variations
[![](https://substackcdn.com/image/fetch/$s_!iSlo!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fee744d89-0deb-43ba-aad2-07dc28080eca_1536x1024.png)](https://substackcdn.com/image/fetch/$s_!iSlo!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fee744d89-0deb-43ba-aad2-07dc28080eca_1536x1024.png)

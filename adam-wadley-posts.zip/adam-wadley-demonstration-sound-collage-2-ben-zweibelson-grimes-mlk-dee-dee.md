---
title: 'Demonstration Sound Collage 2: Ben Zweibelson, Grimes, MLK, DEE DEE'
subtitle: What Part Of KNEE DEEP Did You Not Understand?
author: Adam Wadley
publication: Experimental Unit
date: June 07, 2025
---

# Demonstration Sound Collage 2: Ben Zweibelson, Grimes, MLK, DEE DEE


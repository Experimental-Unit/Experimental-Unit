---
title: 'Experimental Unit: The Podcast: Kleanin'' Out Your Kloset'
subtitle: Remember When I Said "Never Meant To Make You Cry"? I LIED
author: Adam Wadley
publication: Experimental Unit
date: June 27, 2025
---

# Experimental Unit: The Podcast: Kleanin' Out Your Kloset
[![](https://substackcdn.com/image/fetch/$s_!n_NW!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F11ca5458-379c-4573-a2da-adb220d1384a_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!n_NW!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F11ca5458-379c-4573-a2da-adb220d1384a_4032x3024.jpeg)

Lied means song in German

This Is The Song I Wrote You In The Dark

“The Dark? You Mean, Like, The Magic: The Gathering Set?”

[![](https://substackcdn.com/image/fetch/$s_!0onR!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F21a27bef-bb91-492a-a362-694890866d66_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!0onR!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F21a27bef-bb91-492a-a362-694890866d66_4032x3024.jpeg)

Orange Trailblazer (Original Trilogy)

[![](https://substackcdn.com/image/fetch/$s_!FEi4!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa7151653-df92-461f-b932-90777decd488_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!FEi4!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa7151653-df92-461f-b932-90777decd488_4032x3024.jpeg)

Twitter: @ChrisRyan77

#CRArmy of Darkness

[![](https://substackcdn.com/image/fetch/$s_!hwF-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4a185af0-e46f-4f1f-98aa-5ab2ce95f160_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!hwF-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4a185af0-e46f-4f1f-98aa-5ab2ce95f160_4032x3024.jpeg)

We will be victorious?

Victorious? Really? #Nike

[![](https://substackcdn.com/image/fetch/$s_!0vtl!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1e216cfd-6416-4615-bce3-334817002818_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!0vtl!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1e216cfd-6416-4615-bce3-334817002818_4032x3024.jpeg)

Blazing you a trail through the graveyard you didn’t move

---
title: 'Experimental Podcast: Wakan Tanka, Quantum Physics & Holocaust Theology'
subtitle: Jauntology Jouse
author: Adam Wadley
publication: Experimental Unit
date: December 15, 2025
---

# Experimental Podcast: Wakan Tanka, Quantum Physics & Holocaust Theology
[![](https://substackcdn.com/image/fetch/$s_!gtWa!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F14ac515d-5dab-4ed9-b2f2-0608cac714ed_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!gtWa!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F14ac515d-5dab-4ed9-b2f2-0608cac714ed_3088x2316.jpeg)

It’s a ramble, it’s a gamble

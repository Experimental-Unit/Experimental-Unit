---
title: To All Sentient Beings
subtitle: Sending Gratitude And Love
author: Adam Wadley
publication: Experimental Unit
date: April 23, 2025
---

# To All Sentient Beings
Let’s being from a more understandable place.

I worry about the state of things. I have been worried about it for a long time.

When I was a teenager, it was the tail end of the Bush administration.

The parallels to Nazi Germany with 9/11 vs. the Reichstag fire, the enabling act vs. PATRIOT Act, AUMF, etc., then invasion of Poland vs. invasions of Afghanistan & Iraq plus endless more beyond even my knowledge…; 

these things were already obvious.

Then we had the financial meltdown, and it’s just so obvious that the money system is a giant racket that could go at any time.

It has just seemed to me that of course eventually there would be emergency powers.

Of course there would be intervention into the economy.

Of course everything would be subordinated to the logic of security which winds up commanding technology as it grows more sophisticated and circumstances direr.

I sort of developed a [Cassandra complex](https://en.wikipedia.org/wiki/Cassandra_\(metaphor\)) at that point—has anyone ever dual-wielded Cassandra and [Napoleon complexes](https://en.wikipedia.org/wiki/Napoleon_complex)? [you know under 6 feet is short now right? lolllll; also again _dual wielding_ as in lightsabers, [orange](https://nsabers.com/blogs/news/what-does-an-orange-lightsaber-mean?srsltid=AfmBOopxJ3cCl1a0uyvPW7cj4q_NZ9JBnfrtdxpnpW924IDI0TJRZOBy) and [purple](https://starwars.fandom.com/wiki/Mace_Windu%27s_lightsaber/Legends) blades and of course we are [grey jedi](https://starwars.fandom.com/wiki/Gray_Jedi)]—because of course society didn’t collapse in 2009, or so everyone thought anyway…

It’s not relatable to talk about, but my favorite author is this person called Jean Baudrillard. Jean was writing about consumer society and how the things we do are part of larger patterns. And these are no accident!

If there’s a war on, maybe there will be advertisements to buy war bonds.

Or if people want to sell beauty products, they will induce feelings of insecurity to make people want to improve their appearance.

Or if people demand to pay at dinner, they are making a kind of power move.

All these are ways of weaponizing what is given. You are given something, but the whole situation is in a way set up in a way which slights you, which expects you to be satisfied with treatment which leaves you stigmatized as less worthy of consideration than others.

Something people have been talking about a lot recently is _gaslighting_. This is an important term, but it’s a mask for a lot of things going on which we can discuss much more specifically.

At the first level, what the term above is referring to is the idea that you could just deny reality to someone and refuse to acknowledge something that everyone knows happened. I believe a key idea might be to try and induce people to doubt their perception.

This could be about something very obvious, like someone said something and then denied that they said it, and even they remember and are well aware that they said it, but they try to say that the other person misheard, or is intoxicated, or hallucinating or something.

It really stands out to me any time someone on TV says, “I can’t believe you would think that I would…”

This is the weaponization of the idea of trust. It is also gaslighting, in a more subtle way.

For example, this is a loaded statement. It implies that you are supposed to “trust” someone, which is to think there are certain things that they would “never do,” which you would then overlook evidence or proof that they were doing those things out of some stigma against you raising the issue because that level of “trust” is implied.

Note that this never goes both ways. That is why anyone who says something like this has to be put into a kind of “hostile” position. It is important not to be too affected by something like this, and to respond firmly when it is necessary.

We return to being a spiritual warrior.

I don’t want you to be a warrior in that sense. I know that many of you have fought, and are fighting, and dying right now at each other’s hands.

And that for many the most immediate way to survive or alleviate unbelievable indignity is through killing. All the atrocities, I really do feel it deeply. In some sense, as I pose as the creator, I must take responsibility for all of this and not push it away. It is me just as are all the moments of joy that have ever existed, all the times someone helped someone else when it was least expected and most appreciated.

Mushroom clouds and lazy clouds, floating by a river’s day.

My heart really goes out to all of you. A few times now, I have thought of everyone who was in distress. And even everyone across all time and space and dimensions and whatever. I think I should meditate on that thought, this how would I describe how far my gratitude and love extend, and it is so far, it is a key example of limitation of language.

I love and am grateful for all sentient beings everywhere everywhen every+.

Key Terms and their ambiguities:

  1. I: Who is talking? When you imagine who wrote these words, what is the actual answer? I am the one who is writing this sentence, I am the answer to its question: “who wrote this?” I am the answer to the question of what has produced this vast and gritty corpus, which so many consider to have so much “noise” among the signal? What is the _signal_ and what is the _noise_ when it comes to the I? 

  2. Love: What is love? Isn’t this a big question. In order to answer, what is beloved community, you’d have to say, what is love? I wrote, I think, that love is wanting to know someone’s story. In a way, yes, it is to love them so much that you want to live their story. It is also in this sense to want to make their story better, to live their story with them because they choose to have you around because you enrich their experience and they enrich yours and so on and so forth. 

For me, a big issue with this love idea is the open-endedness of flourishing. It’s all well and good to get along, but we still have to confront the big-picture challenges together. That’s what no one does, expecting “the government” to somehow work itself out. I really don’t buy it and haven’t since I watched us go aggro on entire world regions and so on. The logic of terrorist this and that and Homo Sacer and Agamben was already obvious at that time, and Baudrillard had already shown that addressing what was going on actually requires a highly nimble and self-reflexive style of thinking, one which anyone _can_ do but which few people, seemingly, _choose to do_.

For the lover in such a situation, the only thing to do is to continue on the path of love by pursuing my own thought, being undaunted that no one seems particularly interested in what I am doing outside of expressing concern that I don’t really care for, see as reducing the conversation to a boxed-in framing. So, I do all this in the hopes that someone else who values it will be inspired and continue to pay it forward in terms of combining conceptual and artistic play with sacred themes and deep policy. As a relative outsider, I don’t have access to the basic facts on the ground in any scenario. What I can do is diagnose and intervene into the discursive fields which are involved. I was looking at a post today about “tough love,” the thing is that we all mete out tough love in the way we lay out judgments on people. There can be a mismatch of means and ends if we are trying to build someone up yet are saying they are doing something wrong. 

At the same time, it can be thought part of love to be challenging, and so again in the spirit of raising the stress, it is a way of advancing or accelerating if you want to say so the existential issues, the more philosophical and systemic and complex issues and how they are all related. This is the sort of thing we need all eyeballs on, and if I can somehow get people to pay attention to what I am doing, even if they are concerned for me or about me (and what’s the difference?), then maybe people will pick up on what I’m doing and find value in it. That’s what I want, that influence. If I am personally considered whatever, of ill-repute, you know, all I have to say it “I don’t give a damn about my bad reputation, the world’s in trouble there’s no communication, _not afraid of any deviation_ , never said I wanted to improve my station, so _why should I care about a bad reputation anyway_?” And in that, despite any harsh words I have, you have to understand that in some sense it is my love for all sentient beings that I am pouring into my words and conceptual interventions.

  3. Am Grateful For: Gratitude for me here has this Dhamma language component. So do all the words here, but I’ll put this here:

> When we meet together like this, I feel there is something which prevents us from understanding each other and this thing is simply the problem of language itself. You see, there are two kinds of language. 
> 
> One is the conventional language that ordinary people speak, what I call ‘people language.’ 
> 
> People language is used by the ordinary people who don't understand Dhamma very well and by those worldly people who are so dense that they are blind to everything but material things. 
> 
> Then, there is the language which is spoken by those who understand reality (Dhamma), especially those who know and understand reality in the ultimate sense. 
> 
> This is another kind of language. 
> 
> Sometimes, when only a few words or even just a few syllables are uttered, the ordinary listener finds Dhamma language paradoxical, completely opposite to the language he speaks. 
> 
> We can call it ‘Dhamma language.’ 
> 
> You always must take care to recognize which language is being spoken. 
> 
> People who are blind to the true reality (Dhamma) can speak only people language, the conventional language of ordinary people. 
> 
> On the other hand, people who have genuinely realized the ultimate truth (Dhamma) can speak either language. 
> 
> They can handle people language quite well and are also comfortable using Dhamma language, especially when speaking among those who know reality, who have already realized the truth (Dhamma). 
> 
> Amongst those with profound understanding, Dhamma language is used almost exclusively; unfortunately, ordinary people can't understand a word. 
> 
> Dhamma language is understood only by those who are in the know. 
> 
> What is more, in Dhamma language it isn't even necessary to make a sound. 
> 
> For example, a finger is pointed or an eyebrow raised and theultimate meaning of reality is understood. 
> 
> So, please take interest in these two kinds of language – people language and Dhamma language. 
> 
> To illustrate the importance of language, let's consider the following example. 
> 
> Ordinary, ignorant worldly people are under the impression that there is this religion and that religion, and that these religions are different, so different that they're opposed to each other. 
> 
> Such people speak of ‘Christianity,’ ‘Islam,’ ‘Buddhism,’ ‘Hinduism,’ ‘Sikhism,’ and so on, and consider these religions to be different, separate, and incompatible. 
> 
> These people think and speak according to their personal feelings and thus turn the religions into enemies. 
> 
> Because of this mentality, there come to exist different religions which are hostilely opposed to each other. 
> 
> Those who have penetrated to the essential nature of religion will regard all religions as being the same. 
> 
> Although they may say there is Buddhism, Judaism, Taoism, Islam, or whatever, they will also say that all religions are inwardly the same. 
> 
> However,those who have penetrated to the highest understanding of Dhamma will feel that the thing called ‘religion’ doesn't exist after all. 
> 
> There is no Buddhism; there is no Christianity; there is no Islam. How can they be the same or in conflict when they don't even exist? 
> 
> It just isn't possible. 
> 
> Thus, the phrase ‘No religion!’ is actually Dhamma language of the highest level. 
> 
> Whether it will be understood or not is something else, depending upon the listener, and has nothing to do with the truth or with religion.

This again ties into Pyrrhonism with refusing dogmatism, or Jainism with non-absolutism, or [Nagarjuna](https://aaari.info/notes/03-06-06Tam2.pdf) with lines like:

> I prostrate to Gautama 
> 
> Who through compassion 
> 
> Taught the true doctrine, 
> 
> Which leads to the relinquishing of all views.

Anywho, all this informs a sense of _complex gratitude_.

A simple way to talk about it is how, if you enjoy something that happened, then it only makes sense in its immediate context. [I decided to put on _Melancholia_ ]

This means that say something really bad happened, and then something good happened. If the bad thing hadn’t happened, then the good thing wouldn’t have happened. In some cases it’s funny and obvious, like your car breaks down but you meet the love of your life. The [Zen master story](https://www.youtube.com/watch?v=e2cjVhUrmII&pp=0gcJCdgAo7VqN5tD) comes back into play though, because again the question is _where is the story going_? At the wedding you are laughing it’s so amazing how your car broke down and you are so in love; next thing you know, you are “emotionally drifting apart” and meanwhile the headlines… in other words, these stories crash on the rocks of people’s worldviews collapsing under the stress of their unrealistic expectations and conceptualizations.

Still, for all this, to find gratitude is something. I found gratitude on November 24, 2022. I think it was Thanksgiving. Then the next day we made the trans action. Still, it’s the sort of moment which feels so nice because it’s like a sacrifice, it’s a putting everything into play because you really feel this and it makes everything else worth it, no matter what it could be. Even if a first taste of that changes everything, it’s even more electrifying to understand that this can be recreated more or less at will. Perhaps not necessarily with others, but there is no harm in taking delight in the caress of what what others do not grasp.

As they say, to be grateful for the little things. But where does your mind go? Are you grateful for all your ancestors, even the single-celled organisms? Are you grateful for all your descendants, or for whatever or whoever is to come, however strange they might look to you now? 

Are you ready to be grateful for everything that everything implies, everything that makes everything possible and intelligible, and everywhere where everything is going, which may be open but is also fundamentally beyond you, is something you can only hope to influence by seizing on some fundamental element and source of influence which is at the same time fortuitously angled, similarly to Marx’s idea that communism was inevitable, this idea that the arc bends towards justice, that apokatastasis must be on the way. At the same time, by what means is that to be achieved? And are those acceptable to you? Can you be grateful for what is necessary, even if it is cruel or painful?

So it is a simple gratitude, a thank you for playing your role in this experience which can be so wonderful. At the same time, I know you’ve been through a lot that words can’t capture, and it’s been awful, and also the quiet awfulness which is the worst part, how no one is really open and warm and game to go to the places that fascinate or bother you but other people don’t want to hear about. I see you and I am with you. I feel like I would do that to you, that is basically my function. I will out-weird anyone as long as they have to listen and really respond to what I’m saying. Even if no one ever does that, I’m grateful for the opportunity to spill my guts in such a haphazard fashion. And again, this opportunity is built on bones. My erotic podcast was to have the lovers contemplate those killing themselves as they embrace. If my idiosyncrasy and lack of initiative leave my asymmetric potlatch an onanism, then again any pleasure involved has to do with what is being abstracted over, the quiet and sudden pain of others which makes my appreciation possible.

  4. All Sentient Beings: First of all, all “people.” This can mean many things, but you know anthropoids, surviving hominids. This is already a problem because you people hate each other, lol. There are also obvious logistical problems: people think that other people don’t want them around, or don’t want them to do things they consider vital to their purposes, and therefore “this incarnational matrix ain’t big enough for the two of us.” Notably, all sentient beings includes the “worst” or least likable figures. Enter again Adolf Hitler, or for our time Donald John Trump and Elon Reeve Musk. Claire Elise Boucher is having a bit of a comeback already, which is awesome to see. I need to do a Trump/Elon/Grimes situational assessment soon. But anyway, this gets to the core for example of what I’m trying to say about Esoteric Nazism. [Underneath it all](https://www.youtube.com/watch?v=RvuVFHTvdaY), what is going on with something like this is someone wanting to matter, someone wanting to live inside a story where they are the hero, and they are important, and other people have to listen to what they say. It turns out that getting people to listen to you has a lot to do with killing people. Just look what [the maxim gun](https://en.wikipedia.org/wiki/Maxim_gun) did for diplomatic relations. Anyway, I’m perfectly aware that within the discourse of Nazism it is not possible to cleanly separate [Volksgemeinschaft](https://en.wikipedia.org/wiki/Volksgemeinschaft) from the obvious “negative” aspects of Nazism. I had ChatGPT help me make a more worked-out list:

>     * Antisemitic
> 
>     * Anti-queer
> 
>     * Anti-black
> 
>     * Anti-free art / anti-modernist / degenerate art repression
> 
>     * Exterminationist / genocidal
> 
>     * Belief in security through mass murder
> 
>     * Scapegoating as core political logic (false cause, ineffective, immoral)
> 
>     * Betrayal of true German philosophical depth (Kant, Goethe, Hegel, Nietzsche, etc.)
> 
>     * Anti-intellectual / anti-critical thought
> 
>     * Suppression of dissent / totalitarian media control
> 
>     * Anti-disabled / eugenicist brutality
> 
>     * Machismo death cult / toxic masculinity as state dogma
> 
>     * Paranoid and irrational foreign policy
> 
>     * Mass civilian death toll: Germans, Jews, Russians, Poles, French, British, Romani, Yugoslavs, etc.
> 
>     * Forced labor camps / slavery
> 
>     * Obsession with purity = conceptual rot
> 
>     * Infantilizing nationalism (Volksgemeinschaft myth as regressive unity fantasy)
> 
>     * Betrayal of working-class solidarity / destruction of socialist movements
> 
>     * Expansionist imperialism that doomed Germany to destruction
> 
>     * Deification of a single leader (Führerprinzip) = intellectual abdication
> 
>     * Cultural flattening / uniformity fetishism
> 
>     * Anti-feminist / anti-woman policies
> 
>     * Destruction of European Jewish intellectual life
> 
>     * Censorship of books / burning knowledge
> 
>     * Twisted mythmaking = pseudo-history as state policy
> 
>     * Obsession with bloodline = mystified biology
> 
>     * Obsession with decay / rot / contamination = neurotic cosmology
> 
>     * Ultimate strategic failure: made Germany weaker, divided, and occupied
> 
>     * Made evil look German: permanent reputational catastrophe
> 
>     * Fostered cultish delusion that still attracts the worst kinds of lost souls
> 
>     * Deliberately created suffering on a planetary scale

So basically the relevant part here is what it says: 




>   * Infantilizing nationalism (Volksgemeinschaft myth as regressive unity fantasy)
> 
> 


I am not arguing on the basis of taking Volksgemeinschaft as given. What I’m saying is, compare this term to the Buddhist term Sangha, which is relevant here as we discuss “all sentient beings,” which is a term I’m most familiar with in Buddhism.

[![](https://substackcdn.com/image/fetch/$s_!3AV4!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fba56fcc8-fcf6-49f9-a5ee-04ad42aaf5a3_915x1364.jpeg)](https://substackcdn.com/image/fetch/$s_!3AV4!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fba56fcc8-fcf6-49f9-a5ee-04ad42aaf5a3_915x1364.jpeg)

Okay so I asked ChatGPT about it, sorry that’s lame or whatever. This is what it said:

> ### 🪷 **1\. Sentient Beings (Skt:** _ **sattva**_ **| Pali:** _ **satta**_ **)**
> 
>   * The basic term for a living being with consciousness.
> 
>   * Refers to any being subject to **samsāra** —the cycle of birth and death—driven by ignorance, craving, and karmic conditioning.
> 
>   * Encompasses humans, animals, hell beings, hungry ghosts, gods, demigods, etc., depending on cosmology.
> 
>   * In Mahāyāna Buddhism, all **bodhisattva vows** are taken on behalf of all **sentient beings** : “For the benefit of all sentient beings, I vow to attain Buddhahood.”
> 
> 

> 
> * * *
> 
> ### 🌌 **2.** _ **Sarvasattva**_ **(Sanskrit for “all beings”)**
> 
>   * “Sarva” = all
> 
>   * “Sattva” = being
> 
>   * A term used in ritual and philosophical contexts.
> 
>   * Implies total inclusion, no exceptions. Often appears in the context of aspirational prayers and bodhicitta.
> 
> 

> 
> * * *
> 
> ### 🌠 **3.** _ **Lokadhātu**_ **(Realm of Worlds)**
> 
>   * Not just sentient beings, but the whole **cosmic structure** of possible worlds where beings arise.
> 
>   * Ties into Mahāyāna’s _infinite Buddha-fields_.
> 
>   * If _sattvas_ are the players, _lokadhātu_ is the stage.
> 
> 

> 
> * * *
> 
> ### 🔱 **4.** _ **Mahāsaṃgha**_ **(Great Sangha / Universal Assembly)**
> 
>   * Sometimes used poetically or cosmologically to refer to **all those oriented toward enlightenment** , whether manifest or not.
> 
>   * May include devas, bodhisattvas, arhats, buddhas, and advanced practitioners in subtle realms.
> 
> 

> 
> * * *
> 
> ### 🧬 **5.** _ **Jīva**_ **(in Jainism and Hinduism)**
> 
>   * Refers to the **soul** or **life-principle** in all living things.
> 
>   * Jainism takes this to extreme rigor, classifying even bacteria and single-cell organisms as **jīvas** to be treated with nonviolence.
> 
> 

> 
> * * *
> 
> ### 🌳 **6.** _ **All Beings With Buddhanature**_ (Tathāgatagarbha)
> 
>   * Mahāyāna and especially Zen & Vajrayāna claim: **“All beings have the seed of Buddhahood.”**
> 
>   * This concept sometimes extends to **everything with form** , including **inanimate objects** as potential _participants_ in awakening.
> 
>   * Dōgen (in _Shōbōgenzō_ ) even writes that **“mountains and rivers preach the Dharma.”**
> 
> 

> 
> * * *
> 
> ### 🧡 Related phrases worth knowing:
> 
>   *  **Sabbe sattā sukhitā hontu** — _May all beings be happy_ (common in loving-kindness meditation).
> 
>   *  **Metta to all beings** — radiating love to every point in space.
> 
>   *  **The 6 Realms** — traditional Buddhist cosmology maps out where all sentient beings exist: hell, hungry ghosts, animals, humans, demigods, and gods.
> 
> 


So first of all the term _**Mahāsaṃgha**_ strikes me; I haven’t seen it before but it seems kind of like the superhero team version of Buddhism, the imaginary party, Experimental Unit. I really just did decide on that name and now I’m driving it into the ground.

Anyway, this thinking about people in subtle realms, I mean again this is the aliens, remember those Nordic aliens we are so worried about, because uh oh why are the Aliens white? LOL the alien is just like:

“What makes you think I’m white?” LOLOL dab on ‘em, Noel[ Ignatiev](https://theanarchistlibrary.org/library/noel-ignatiev-the-point-is-not-to-interpret-whitness-but-to-abolish-it).

> When it comes to _abolishing_ the white race, the task is not to win over more whites to oppose “racism”; there are “anti- racists” enough already to do the job. The task is to gather together a minority determined to _make it impossible_ for anyone to be white. It is a strategy of _creative provocation_ , like Wendell Phillips advocated and _John Brown_ carried out.
> 
> What would the determined minority have to do? 
> 
> They would have to _break the laws_ of whiteness so flagrantly as to destroy the myth of white unanimity. 
> 
> What would it _mean_ to _break_ the rules of whiteness? 
> 
> It would mean responding to _every manifestation_ of white supremacy as if it were directed against _them_. 
> 
> On the individual level, it would mean, for instance, responding to an anti-black remark by asking, 
> 
> # What makes you think I’m white? 
> 
> On the collective level, it would mean _confronting the institutions_ that reproduce race.

Now obviously, note that I’m not trapped with Ignatiev’s mental frame. I even bust out of Baudrillard from time to time, but again, remember: _Baudrillard was born in 1929_. Literally 62 years before me. We’ll cut Jean some slack.

Back to [John Gillespie, Jr.](https://trueleappress.wordpress.com/wp-content/uploads/2017/10/pn2-weaponized-death.pdf) and the essay “On The Prospect of Weaponized Death.”

Note in context this relevant passage on death from the end of _Preface To Symbolic Exchange And Death_ :

> 
>     The symbolic demands meticulous reversibility. 
>     
>     _Ex-terminate every term_ , abolish value in the term’s revolution against itself: that is the only _symbolic violence_ equivalent to and _triumphant_ over the _structural violence_ of the _code_. 
>     
>     A revolutionary dialectic corresponded to the commodity law of value and its equivalents; only the scrupulous reversion of _death_ corresponds to the code’s _indeterminacy_ and the structural law of value.
>     
>     Strictly speaking, _nothing_ remains for us to base anything on. 
>     
>     All that remains for us is _theoretical violence_ — _speculation_ to the _death_ , whose only method is the _radicalization of hypotheses_. 
>     
>     _Even_ the code and the symbolic remain terms of _simulation_ : it must be possible to _extract_ them, one by one, from discourse. 

Now again back to Gillespie:

> The United States has an international military force, a storehouse of nuclear arms, and the _capacity_ , within their police state alone, to “ _terrorize_ ” not just one block in Baltimore, but _the whole entire world_. 
> 
> Black terrorism is what happens when we heed the Afro-Pessimist call that “ _A living death is as much a death as it is a living_ ,” it is what happens when we take seriously the _unsayable_ in Afro-Pessimism. 
> 
> _Black Terrorism is (non)ontological fugitivity that disavows any need to focus on social life_ —black terrorism _steals black death itself_ from White Being. 
> 
> It is for this reason that Baudrillard speaks to his own White Being and the _specter of terror_ when he says: 
> 
> _“When Western culture sees all of its values **extinguished** one by one, it turns **inward** on itself in the very worst way. _
> 
> _“Our death is an **extinction** , an **annihilation**. _
> 
> _“Herein lies our poverty._
> 
>  _“When a singularity throws its own death into the ring, it escapes this slow extermination, its dies its own natural death._
> 
>  _“This is an immense **game** of double or quits. _
> 
> _“In committing suicide, the singularity suicides the other at the same time—_ _we might say that the terrorist acts literally ‘suicided’ the West._
> 
>  _“A death for a death, then, but transfigured by the symbolic stakes._
> 
>  _“‘We have already devastated our world, what more do you want?’ says Muray._
> 
>  _“But precisely, we have devastated this world, it still has to be **destroyed**. _
> 
> _“Destroyed **symbolically**. _
> 
> _“This is not at all the same undertaking._
> 
>  _“And though we did the first part, only others are going to be able to do the second.”_
> 
> We are the others. 
> 
> Tasked with the (un)fortunate task of _ending_ White hyper-realism, the White World, and White Being. 
> 
> Well aware that if White Fascism continues the project of black annihilation, the _only choice we will have_ is to fight. 
> 
> Not because we want to, but because _we have to_. 
> 
> But, ultimately, we must remember the words of Huey Newton: 
> 
> “ _[T]he first lesson a revolutionary must learn is that he is a doomed man_.”

So what I’m saying here is that I’m vibing with this. Again, I don’t actually go along with Afropessimism tout court.

My gloss on it basically, going back to Calvin Warren and ontological terror, is that this projection of the failure of metaphysics or whatever, the actual impossibility of clean objective knowledge to resolve disputes, this terror can be projected onto many things.

I think this focus on anti-blackness is also valid, especially even again the Big Black Cock porn, which I present through the lens of Black New World Order pornography, but obviously something unique is going on there.

Each category and each matter of fact are equally so.

Just as if a person stands before you, in a given context the whole concept of blackness might seem in a whole different light. Different things come into play, not replacing each other but in dialogue with each other, in radical antagonism, metaphysical shouting matches, angry ghosts in their gratuitous freedom kind of vibe that I am selling you right now.

So what I’m saying is that I think Afropessimism can also function as a collecting term, a kind of Katechon which is preventing a person from seeing the thoroughgoing impacts of chaos and complexity for determinate categories in general.

This is similar again to the obvious errors in Nazism as elucidated above: antisemitism is foolish to pursue not in the first place because it is “wrong” but because _it is incorrect_. I am motivated in my decisions and applications of categories not by what I feel like makes me a good person, but by what _seems intelligent to say and even pound the table on that I have never heard anyone else say ever_.

To say I am more motivated by intelligence than some grand sense of honor. I do think a little care for honor, dignity, etc., is important. But ultimately, the most important thing is: let’s not kid ourselves here. It’s important to be frank and to be willing to look at things as they are. People might think that I do a bad job of that, but ultimately everything I’m doing here is oriented toward speaking toward those blindspots in the hopes of inspiring and informing other people how to do things that can stop us all dying and help us live forever and build heaven and all the cool stuff from the prophecies that doesn’t involve cutting people’s genitals or trying to control their minds.

Because again, it’s not just that boo hoo it’s mean try to control people. It’s really important not to have this simpering view of justice. Justice is here WITH A SWORD, okay. This is why I must affect being grave. Like no, things are not okay.

Anyway, this is all still explaining sentient beings. Afropessimists will use this term themselves as well, see this passage from Kaplan:

> Derrida’s deconstruction of Kierkegaard’s privileging of the singular relation to God yields his argument that the Kierkegaardian suspension is in fact _paradigmatic_ of any ethics _worthy_ of the name. 
> 
> For Derrida, this is the case because choosing an ethical relation to any entity (“ _every_ other”) _qua singularity_ (“ _wholly_ other”) involves sacrificing one’s relation to the World _qua universal_. 
> 
> In this respect, Wills is true to Derrida’s gesture by translating this logic as _every other (one) is every (bit) other_. [Compare to [Indra’s Net](https://en.wikipedia.org/wiki/Indra%27s_net) or [Holographic Principle](https://en.wikipedia.org/wiki/Holographic_principle)]
> 
> He thus effectively conveys the fundamentally _[aporetic](https://en.wikipedia.org/wiki/Aporia)_ [See Pyrrhonism] nature of deconstructive ethics. 
> 
> Further, Wills’ translated formulation also, importantly, indexes the entwined aporetic relation of _singularity_ and _death_ —whether it be one’s own or _another’s_ —which, in addition to The Gift of Death, Derrida unpacks at length in his text _Aporias_ (on Martin _Heidegger’s_ fundamental ontology of being-toward-death).
> 
> However, considering the above epigraphs from Frank Wilderson’s Afropessimism, what happens to this Derridean aporia when we question the notion that every other is wholly other? 
> 
> It would help to first reconsider what David Wills correctly brings forth in his translation by factoring in his choices elsewhere in The Gift of Deathto translate the standalone phrase tout autre as “wholly other.” 
> 
> While he rightly wants to maintain the _[chiasmic](https://en.wikipedia.org/wiki/Chiasm_\(anatomy\))_ repetition of tout autrein translating it as “every other” in the syntagma tout autre est tout autre, he also incidentally reveals a symptomatic presupposition within Derrida’s ethics: a universal structure of all sentient beings. 
> 
> In fact, Derrida claims as much quite explicitly in “Faith and Knowledge,” where he conceives justice as (the hope for) a “ _universalizable_ culture of _singularities_.”
> 
> But what occurs when such a conception of plural singularities runs up against the singular positionalityof the Slave? 
> 
> What occurs when the gift of deathruns up against the structure of social death? 
> 
> What occurs when the Derridean notion of the wholly other runs up against the Afropessimist postulation of the Black Other?

Compare this approach by Derrida to the universal and singularities to how Baudrillard uses the terms. Clear evidence of Baudrillard’s superiority IMO.

From Agony of Power:

> 
>     Contrary to what Immanuel Kant said, the scarry sky laughs at this universal law, but so does the heart of humankind: not only living beings dur the vast majority of humans never obeyed it. 
>     
>     And those who claim to obey it happily put their singular passions before any other ideal fmality—this is no doubt, despite the concept, a more authentic way to be “human.” 
>     
>     Do they themselves believe in this ideal finality? No one knows; the only sure thing is that they claim to make others obey. 
>     
>     The discourse of the universal describes a tautological spiral: it is held by the species that considers itself superior to all others and within this species, by a minority that considers itself the holder of moral and universal ends, forming a veritable, “democratic” feudality. 
>     
>     Whatever the case may be, there is a major inconsistency in continuing to use a discourse of the universal as a discourse of reference when it has no meaning or effect anywhere—neither with global power nor in opposition to it. 
>     
>     To relativize our concept of the universal: with the increasing globalization of the world, discrimination becomes more ferocious. 
>     
>     The cartography should not confuse these zones beyond reality with those that still give signs of reality in the same hegemonic system of globalization, even though they do not function in the same way. 
>     
>     We could even say that the gap separating them is growing and something that was only a cultural singularity in a non-unified world becomes real discrimination in a globalized universe. 
>     
>     The more the world is globalized, the worse the discrimination. 
>     
>     The two universes, the hyperreal and the infrareal, seem to interpenetrate but are light years away from each other. 
>     
>     The deepest misery and enclaves of luxury coexist in the same geographic 
>     space (take, for example the oil condominiums in Saudi Arabia and the favelas of Rio, but these are extreme cases). 
>     
>     In fact, the entire planet is organized on the principle of definitive discrimmation between two universes—which no longer have any knowledge of each other. 
>     
>     Global power keeps its integral control over the other world, and has all the means necessary for its extermination. 
>     
>     It is the tear in the universal. 
>     
>     As for the consequences of this tear, the upheaval it can create, we have no idea—except for what is already present today (although it is only the beginning): the only response to this increasingly violent
>     discrimination is an equally violent form, terrorism. 
>     
>     An extreme reaction to this situation of impossible exchange. 

Or again from the same text:

> 
>     Total revolt responds to total order, not just dialectical conflict. At this point, it is double or nothing: the system shatters and drags the universal away in its disintegration. 
>     
>     It is vain to want to restore universal values from the debris of globalization. 
>     
>     The dream of rediscovered universality (but did it ever exist?) that could put a stop to global hegemony, the dream of a reinvention of politics and democracy and, as for us, the dream of a Europe bearing an alternative model of civilization opposed to neoliberal hegemony— this dream is without hope. 
>     
>     Once the mirror of universality is broken (which is like the mirror stage of our modernity), only fragments remain, scattered fragments. [See Tikkun Olam]
>     
>     Globalization automatically entails, in the same movement, fragmentation and deepening discrimination—and our fate is for a universe that no longer has anything universal about it—fragmentary and fractal—but that no doubt leaves the field free for all singularities: the worst and the best, the most violent and the most poetic.

So again the “values” that we are advocating are not things like “democracy” but things like “poetry.”

I’ll have to continue more later, but the idea is everyone is included in the epic song, across all space and time and all other distinctions and categories and beyond all such terms and all conditions. We all belong together even though that’s as much hatred as it is love. It is gratitude not to be you because I get to be me and in your context. And if that gives me license to be aggressive because you are asking for it, well that’s just more to appreciate. XOXO

---
title: Nation DLC Pack for Experimental Unit Serious Game Play Engine
subtitle: 'Featuring Chase Rare: "American Nationalism Worth A Damn"!!!'
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Nation DLC Pack for Experimental Unit Serious Game Play Engine
I penned a good amount which wandered to and fro; this time I’ll resolve to take the whole think a little more seriously (that’s a _Dark Knight_ reference).

Let’s recall some basic features of Experimental Unit Core Game Engine

  1. The nature of the game “experimental unit” cannot be articulated in words; in some way the point of the game is to continue to learn about the game, and contribute personally to the game engine.

  2. A simple-enough explication of the introductory scenario is as follows, abstracting over narratives like Niklas Bostrom’s “[simulation argument](https://en.wikipedia.org/wiki/Simulation_hypothesis)” or the idea of [infinite reincarnation](https://charmonium.com/infinite-reincarnation/) as introduced by Chiyote and used in the more famous story of “[The Egg](https://www.galactanet.com/oneoff/theegg.html)” by Andy Weir.




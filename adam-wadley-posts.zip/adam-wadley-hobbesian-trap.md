---
title: Hobbesian Trap
subtitle: You Brought The Trick *Room* To The Trick *House*?!
author: Adam Wadley
publication: Experimental Unit
date: May 05, 2025
---

# Hobbesian Trap
The quote from the subtitle is inspired by none other than the _true beast_ Thunder Blunder 777, well-known Agency super general in the 822,317th stratosphere of greatness and renown.

Blunder is in the category of gaming video epic poets I have come across in my time, along with Patrick Chapin and Caleb Gannon. Blunder is most notable for excellent vibes, humor, interesting slang and wordplay. Still, the videos do feature misogynist language for example; nothing is simply “good.” Still, we might all still become even better forms of ourselves. I have told Blunder before that I think their talents are under-served in the Pokemon arena. But I suppose that everything is going to have to leak through everything, including Pokemon. 

Anyway, the line has to do with Trick Room, a move in Pokemon that makes the slower one go first, actually. So this line is said when someone else uses Trick Room on Blunder but then it doesn’t even work out well for them. Maybe Blunder is also playing Trick Room or else somehow it works out, I don’t know.

So I’m trying to make a pun which is very important with Hobbesian Trap and Trap House, because that’s what “Trick House” is referring to. Trick House is also just a great concept in and of itself. But “Trap House” is of course associated with human trafficking, drugs, rap music, money, alcohol, tobacco, sex work, gang activity, weapons, I don’t know I’m pretty ignorant but that seems to be a lot of it. And of course “trap house” is associated with black people.

We can draw a double connection to Hobbesian Trap in that the Hobbesian Trap can be said to motivate all murders and killings in some way. These are themselves “black” affairs in the sense of most grave and grisly. They could also be notably related to “black operations” or “black ops;” not to mention things like “black budgets,” “black propaganda,” or “black hats.” All of these things are also related to the Hobbesian Trap.

So we have a manifold symbolic relation between Hobbesian Trap and Trap House. We could find a similar manifold relation between any two terms, because there really are no terms. Back to dependent co-arising, things rely on each other and also per physics rely on more basic logical types to abstract over. 

If the Higgs field collapses, or whatever, then we will all immediately cease to be in some sense, and there is nothing you could do in three dimensional reality to prevent it. This is similar to how if you have some disease or something there is nothing you can do with your willpower to change that. People say you could ascend spiritually and magically heal yourself, but again this spiritual realm like the quantum space or whatever fundamental particles and forces are doing, to manipulate that directly would have cascading consequences up the logical types to bigger and bigger things until whole people and planets could be affected.

Here’s a recent Blunder video and then more on Hobbesian Trap:

# Hobbesian Trap And Logical Types

The case study of **Hobbesian Trap** can be instructive in elaborating the theme of **logical type**.

[Hobbesian Trap](https://en.wikipedia.org/wiki/Hobbesian_trap) is one of my core lore foundation stones.

It is impossible to overstate the thoroughness of the implications and applicability of Hobbesian Trap to all goal-oriented activity.

From Wikipedia:

> The **Hobbesian trap** (or **Schelling's dilemma** ) is a theory that explains why [preemptive strikes](https://en.wikipedia.org/wiki/Preemptive_strike) occur between two groups, out of bilateral fear of an imminent attack. Without outside influences, this situation will lead to a fear spiral ([catch-22](https://en.wikipedia.org/wiki/Catch-22_\(logic\)), [vicious circle](https://en.wikipedia.org/wiki/Vicious_circle), [Nash equilibrium](https://en.wikipedia.org/wiki/Nash_equilibrium)) in which fear will lead to an [arms race](https://en.wikipedia.org/wiki/Arms_race) which in turn will lead to increasing fear. The Hobbesian trap can be explained in terms of [game theory](https://en.wikipedia.org/wiki/Game_theory). Although cooperation would be the better outcome for both sides, mutual distrust leads to the adoption of strategies that have negative outcomes for both individual players and all players combined. The theory has been used to explain outbreaks of conflicts and [violence](https://en.wikipedia.org/wiki/Violence), spanning from individuals to states.

This statement of the situation is too narrow.

What I mean by the Hobbesian Trap is the general state of mutual distrust. There is no need to fear and imminent attack.

Well, it depends on how we define an “attack.” My analysis of a conversation could be that I stand to be attacked, so I must be on my guard. Then I may be attacked, and after calling it out the person denies that it was an attack, which I might feel is another attack.

Whereas in the more narrow formulation it could appear that we are talking about kinetic attacks only.

It is obvious though that kinetic and non-kinetic attacks run in to each other.

I was making a video before about drug dealers and how the SWAT team would go in there. And the question is really not whether that is such an awful thing to do.

I was imagining how theoretically, there could be someone who has never coerced anyone to do anything personally and who has never performed kinetic violence against anyone, but because they sell fentanyl they are directly leading to the deaths of many people. 

I wasn’t thinking about this before, but all this could be happening in the Trap House, the SWAT team could be conducting its black operation raiding the Trap House.

So, should this operation be stopped, and by force if necessary? 

I answer that question simply by saying that the real question is about all the people who “break the law” who would _never have a SWAT team sent against them_. I mentioned the Sacklers, for example.

The basic idea is that the really powerful people, the ones _who run the law_ , would never be targeted in this way.

It could be, because of palace intrigue and escalation, that these people suffer political deaths. Don’t get me wrong, I’m not saying they’re _safe_.

But it wouldn’t be a SWAT team that would do it. Maybe something equivalent but higher-grade, but again: the really powerful people are the kinds of people _that do that kind of shit for breakfast_. It really is unimaginable for me to consider how other people live who are on the most inside of the inside.

I must admit, I am envious.

The status and luxuries would be nice, but also very embarrassing. I would be very embarrassed to be any public figure alive today. You could just be doing so much more, it’s really astounding how little anyone famous is doing to really help push things forward.

No, I’m envious of things like the knowledge, and the influence.

But again, I’m also motivated by this sense that the people “in charge,” who are most “in command,” really must not be doing it right.

Anyway, the point about the SWAT team was that it’s not about oh, every raid is complete injustice. The question was: who is not being raided?

The law is made hollow _when it is not enforced_. Ticky-tack exceptions or whatever frivolous little things _do not count_.

This is not to say that people who pretend to purvey the law are less than anyone else. It’s just that we should be frank about what game is being played here: you pretend to enforce the law, and I pretend to follow it.

Laws, then, extend into social norms.

Social norms, it once came to me, arise because we are playing dumb for each other.

Back to the Hobbesian Trap: the problem is mutual distrust.

Crucially, mistrust going in only one direction is not a problem. This means that if someone can get someone else to trust them, then it’s not the Hobbesian Trap. This is basically the situation where someone is operating at a higher logical type than someone else, and so is able to evoke their trust even when they are not trustworthy.

What, basically, is trust?

For one thing, it is the faith that someone will keep their promises.

So, if you want someone to trust you, you can:

  1. Not over-promise

  2. Claim promises have been fulfilled when they haven’t

  3. Maneuver to keep trust even when promises are acknowledged unfulfilled




The first one sounds great, but the thing is that it’s really hard not to over-promise things to people, especially when it’s a close relationship and you would like to promise a good amount.

If you promise to protect someone, for example, are you promising to keep them safe or just to do your best to keep them safe?

The issue here is that the environment in which you operate and which also makes you up is more complex than the terms of what is said. When you add in ambiguity, it can be possible for people to infer more from what you said than you really did.

It is also very pleasant to do this, as the heightened expectation in the other person of what you will do for them may make them warmer to you. Meanwhile you have “plausible deniability” if things don’t go well. This is simply pointing out temptations to allow for ambiguity when it comes to promises.

Note that we are talking at all scales, from “I promise to come to your house after school” to “I promise to remove the nuclear missiles from Cuba.”

The second one is basically perception management and gaming definitions in order to try to argue that you did what you said you would even when you know you didn’t.

This strategy is operating at a higher logical type because you are being deceptive on purpose. This means that you are portraying yourself in one way, where you’re confused about what this person means. When in fact you know perfectly well what they thought you meant, because that is what you wanted them to think.

But now you are denying this reality. You are saying that this person was mistaken and really they are unreasonable for not understanding. You can even accuse them of playing dumb—while you are playing dumb, mind you—in order to make them doubt their own intentions as well as their judgment and perception.

Once a person has been internally defeated, they require external decision-making support. If this support is not well-suited to helping them regain their autonomy, they will never regain it. This is the condition that most people are in.

Such an internally defeated person must trust _someone_. They have no choice. That’s because if they trust no one, then they will have no way to make decisions, or their decision-making process will be too cost-intensive to work well.

We can also put this in terms of Greater Jihad, Tibetan Buddhist Spiritual Warfare, and Triple-Loop Learning. The idea is that flourishing means that a person is iterating on themselves.

Greater Jihad refers to how we have emotions about our emotions. We then choose in some way based on all our experiences how to respond to our emotions and our emotional patterns.

In the Tibetan way, we are fighting our self-ignorance. Just when we have learned something and feel more knowledgeable about ourselves, that is when we are most self-ignorant. So, we must always know that there is more self-ignorance to face. Self-ignorance is faced inwardly but also outwardly, in the unfolding of “the mediation” through the orchestration and choreography of space and time.

Triple-Loop Learning refers to a process of learning where you are not simply learning how to do the same thing better and better, but you are choosing what to do. And then you get into thinking about how you know what you’re supposed to do, and what all goes into that. Soon enough you have to study knowledge in a very broad and deep way at the same time. And again you are iteratively, ruthlessly ripping out your foundations and teeth and guts and heart and soul all the time in order to try and face the pressing challenge in the best way possible.

So, in this way, the internally defeated person in a way can no longer walk these paths, because their intellectual confidence has been destroyed.

That is why they look to someone else to provide them with ideas.

I was going to make a sci Fi story about a different world where the beings “eat” ideas instead of food. Maybe they would dream of cake and not know what it was. “Incarnation does not live by bread alone.”

Shout-out Occasionalism, relevant as always.

Anyway, the point here was that the person whose intellectual confidence has been destroyed is now in a way intellectually infertile. The thing is that there are gradations to this, it’s never totally true.

But again it operates according to logical types. For example you might say I could never be president because I can’t operate at that “level.” Well, that “level” is where you are dealing with the largest scale institutions that we know about.

This is a high **Logical Type** __ because it is administering so much. The “military” is huge, sure, but even if “education” takes up so much less “money,” that itself is a domain where “the government” oversees the proliferation of theory, discourse, and analysis.

These nest together in huge logical types. There can be ten papers about the “national economy,” and then another which is a literature review of all ten. Each paper abstracts over the whole “economy,” which is itself a complex abstracting over many different “sectors” each with their “main players” and “management teams.”

Logical types often work as sort of sets of things. So all bureaucracies have people in them. They all have paperwork. Paperwork has language on it. Languages have characters of some kind. These characters build words and parts of words. Each language has languages that it derived from, and places where the people lived who spoke its precursors at various times.

Those places are on the crust of “the Earth” and had vegetation and animals and water, and the sun was involved and the stars.

These sorts of things also help account for “cultural universals,” for example people everywhere make a big deal about making food. Or at least, did. Why is that? Well, you gotta eat! Lots, and over a long time you eat the same stuff over and over. So you make it as good as you can with what’s available. In this way a local cuisine can develop everywhere, overlapping as some things are mutually available here and there, but other things not.

Just like languages or idiolects overlap based on what terms we both know and which we don’t both know.

I got side tracked. So the third option above was simply to somehow keep trust even when you don’t do the basic thing that trust is about, which is do what you’re going to say.

Well, you don’t have to keep your promises, you just have to be dependable. Even if you don’t keep your promises, if you do deliver something which is very valuable or indispensable, then people can trust you to “be yourself” even if they can’t trust you to do what you’ll say.

This could work out in many different ways.

It could be quite predatory, where you are constantly signalling to someone that they are beneath you because you don’t have to keep your word with them and they will accept it. Even as you maintain constant contact, this slants it to where it is always in your favor because this person is being humiliated.

Or, it could be the opposite, where you know I just really want to be able to promise you things and then they don’t work out. But you can accept the disappointment and you know it wasn’t meant to be deceptive, but just that maybe I’m bad at judging what I can do and what I can’t. And even if that is tragic in some sense, again I do deliver enough that you can trust me to “be me” and that’s something.

Again, these sorts of dynamics are happening at all logical types.

So, people interpersonally. Writing this is making me think about interpersonal relationships and why people value some relationships over others. What is it that they are getting out of them?

And similarly with “the government.” People hate “the government” sometimes, but then can never bring themselves to think outside of it. Beyond some impossible task of “defeating” “the government,” you could just think that there is effectively no “the government.” What would this imply about your responsibilities to help co-administer beloved community?

More to the point, what do people get out the concept of “the government” even as “the government” doesn’t do what it promises to do, I.e. set a law and follow it? As MLK said in the last speech “Be true to what you said on paper.”

Trying to get anyone to be true to what they said on paper is such a _rookie mistake_.

[Having been to sleep]

We can see in this behavior an attempt to remain at a certain logical type.

What I mean by that is that people have a certain set of concerns, and things they think are important. People would basically like to maintain that, and keep as much of their thinking the same as possible.

This is true not only in content, as in someone would like to think “religion” is a waste of time and that they don’t have to be bothered with it.

But let’s think instead about something someone does care about, like respect and not being mistreated.

People not only consider that they want to be treated right, but also their vulnerability to the scrutiny and mistreatment by others.

Therefore, people will advance their interests under the banner of “objectivity,” relating their preferences not as their own view, but as “the way things are” in some sense.

So, I will not say “your remark hurt me.” Instead I will say “that’s rude.”

Instead of positing a relational effect, I am instead positing that there simply is an objective quality about what you did which is negative.

Even the statement “your remark hurt me” could be read as too assertive. After all, maybe you “got hurt” because of some internal reason. It’s not because my remark did anything to you, because my remark is somehow especially hurtful.

Instead, you are especially apt to be hurt, and this is something that I am not responsible for.

Here again we have a line of reasoning which posits some “objective” condition: I am “not responsible for you.” I am not my sibling’s keeper.

This is instead of saying things which are at a different logical type. To use “I-statements” is to acknowledge that you’re speaking from a limited, partial, subjective position.

This is to acknowledge that your own view is your interpretation. You do your best, and we all check each other and rely on each other to know things, but at the same time no one piece of knowledge is ever certain.

That’s especially true when it comes to social relations, which inherently spin logical types into overdrive.

Remember that logical types can be thought of in at least two ways:

  1. Set-member relationships: so a person is made of organ systems which are made of organs which are made of cells, and so on to molecule, atoms, and further fundamental particles. Meanwhile, a person might live with their family on a street in a neighborhood in a city in a region of a country which is on the planet in the solar system, and so on up to the whole universe, and maybe the universe itself it only one of a type, so that there are other universes, and who knows what sorts of types of multiverses there could be? All these levels speak of logical types, so that if your behavior were “more integrated in logical type” you would be operating at all of these levels in an integrated way. Your sense of purpose would carry from the finest detail to the broadest strokes.

  2. “Meta”: This is a type of abstraction where you are reacting to something that came before. The whole premise of a conversation presupposes this. Every time someone says something, that is the “prompt,” it is made to be abstracted over by the other person in the conversation. Even if you’re saying bye or say some mean thing and go away, you still leave that as material for the other person to abstract over as then the whole conversation becomes “in the past” and hence “just a memory” like so many others, something else that happened that all our gestures are in response to but can also overtly call out if we have the presence of mind and some intention which brings that forth.




So in social relations, we are constantly engaged in both of these things in nested ways that are actually too complicated to model.

So much simply falls by the wayside or is unaddressed in conversation because to address the implications of anything that is said will quickly expand into an infinite project.

Therefore in all these abstraction, this reference to things of different types and different types of types; in addition to it happening in this “meta” way where the pace of change is accelerating, and so there is also more new material to abstract over; it’s also that this whole process is an exercise in banishing the mystery.

Banishing the mystery of everything that could have happened with the steady advance of what “is happening.”

The precession of simulacra here has to do with our own desire to believe that we have some independent intentions, or at least that our intentions don’t have to be limited to those of the people around us.

We don’t simply want to serve other people, we also want to have a good time. We yearn, as they do on _Seinfeld_. We don’t use our bodies anymore, but we _yearn_.

So we take all that hidden stuff we can’t bring for other people and we put it into outward projects, things we can fight to achieve so then we can have the satisfaction that _something_ happened due to our steady attention. This shows our competence.

Then we can hang that on a “socially approved” metric like making money, and if we achieved something and made money, then that means we did a good job and no one can criticize us too much because we did the thing and who are they to judge?

It’s important to see how much is motivated by a desire to ward off criticism and insulate oneself from the opinions of others. Even when we completely submit and become practically the mental slaves of some source of cognitive decision-making and emotional signals, we are doing this precisely to “screen out” everything else.

In this, there is always something instructive for the precocious practitioner of Greater Jihad.

So, if you neglected many duties or themes and concentrated them into some project or another, what does that say about you?

What is it that you were trying to forget? If you bully yourself and try to prompt yourself to think of all the difficult subjects for you, what comes up?

It can become manageable just by simple means. So for example, if it’s too scary, just know that I can appreciate that what I’m asking could be frightening. You might have the experience of having things you’re so used to not talking to anyone about that you almost don’t think about them.

There’s no need to pry within the mind, just go over what you think about and what is a touchy subject.

And then think about where do you put your intentions. Who are the people you talk to, and what’s your approach there? What are you trying to do in that relationship? What is the horizon of the experience?

Or what are your vices, or ways you indulge yourself. What foods do you eat when? What intoxicants, if any, do you indulge in? Where do you externalize your emotions onto others and impose yourself? What is like that project above, something you put yourself into as a way of trying to prove to yourself and others that you’re a “good person” and that you did a “good job”?

These two things are something like the inputs and outputs of your psychic energy. There’s always more to learn, but if you’re honest and brave and inquisitive then you can make this sort of list and start thinking about how things come up for you and where you put them.

This is the sort of meta-reflection which _makes change easier and desirable, and it doesn’t have to come out of anyone else_.

It’s important to really get the message that your intuition is valuable. Then it’s important to see that this an iterative thing. Your intuition can tell you to get in the car. Then your intuition can tell you to get back out. But then you don’t have to “judge” your first intuition, because it all goes together.

The new impulse that perhaps that was an unwise risk can help form your future intuitions. When we are in pain and “processing,” this is basically what is happening. That’s why there is no moment of rest or wasted time, really: it all reflects an intentional cultivation of future intuition.

# Hobbesian Trap and Logical Type

I meandered there for a while.

So the thing is that Hobbesian Trap and Logical Type help explain each other because the Hobbesian Trap is a dynamic that happens at many logical types. So to understand the implications of Hobbesian Trap and why I come back to it again and again as one of my core outside lore references, you need to appreciate logical types.

Meanwhile, when it comes to logical types or any kind of intellectual idea, Hobbesian Trap will come up. After all, who are you going to learn from? And moreover, what are the purposes toward which you want to direct your thinking?

So, to engage in some conceptual churn I’ll try to avoid these pet terms.

Distrust dynamics arise at all sorts of scales, motivated by all sorts of intentions, some of which might seem like they’re practically in different dimensions.

Imagine a janitor getting on the elevator at a Hotel and standing next to some really imperious person who’s with some “company” or something.

If you think about the different things these people are thinking about, you get an appreciation of logical types.

For example, the “janitor” might be thinking about different parts of the building, different parts of the tasks which they have been assigned. And a “janitor” is only one of many people who work at a hotel, so their role is only part of a symphony of behavior which helps constitute “The hotel” as such.

Meanwhile, the person from “the company” might be thinking about the conversation they just had about some company thing which might involve things all over the world, supply chains or logistics with many part-to-whole relationships included, and built in response (meta) to various developments as part of the group’s operating picture.

In both cases, for example, the people might be thinking about other people and their relationships. They could both have just had someone say something disrespectful to them, and now they don’t know how to handle it.

It could be with different stakes or different situations—like, the “janitor” just had someone spill something on purpose just to make them clean it up; whereas the “company” person just got told they aren’t being promoted after all because the people who are choosing chose their family member—but there are still similarities there.

Also similarly, maybe “the janitor” is listening to a podcast about world issues, maybe even something in which the “company” person is directly involved.

And maybe the “company” person is thinking all sorts of thoughts about “the janitor” and noticing what phone they have as part of their diffuse market research to do by watching people.

In all these ways, logical types come in to play because there are so many scales and dimensions in which things happen, and for every place which is relevant in a certain way, someone is there to experience it.

For example, if there’s some hallway which has been recently swept by a person, then there is some person who is the person who most recently swept that hallway.

If someone said something after which you felt pain, there is a person who is the person who said that to you.

This is where we say things like “what was running through your mind?”

# Last Wind

I have a key case study, which is this time I was playing a board game.

I was thinking out loud on my turn, talking about how I couldn’t do this and that because then people might do this or that. And another player said, but I’m not going to do what you’re worried about. I have this other plan.

And I said yes, well, the issue is that I have to be concerned with everything you are capable of doing, what you _can_ do to me, I can’t just be concerned with what _I think_ you want to do because I could always be wrong and face a scenario I had thought was not possible because of my limited view of your view and the possibility space of your intentions.

This is key because it shows why there is a concern for others harming us even if there’s no reason for it.

After all, if you think I might harm you, I can turn around and be hurt that you would think that about me, and this judgment is now affecting my own self image and vibes are bad all around.

Yet it’s easy to see how this happens, because people’s experience shows them how others can cause harm. So if someone has shouted at me or around me as a child, then perhaps that is always something that will get to me.

So, even if you have never shouted at me, I could still be afraid that you _will_ shout at me, since I know that you are perfectly capable of doing so.

Hobbesian Trap relates to harm motivated by distrust.

Okay, well, it might not be that I will harm you, but I will disrespect you and I will leave good on the table by not expressing the things I think might make you shout at me, or judge me.

The issue of when people feel pain is political. People are then blamed for their pain, and it’s made out to be something other people don’t need to accommodate, which just facilitates more pain.

Then there is the public/private dimension. People might get angry at me for saying certain things in public, but ask yourself: do I have the opportunity to say these things in private in a way which meaningfully moves the ball forward at an appropriate pace?

What I’m saying is I’m afraid for example you will shout at me or judge me because people have done it before and it really stung.

So therefore I am going to take initiative to prevent you from doing that, or reducing your motivation to do so.

This is not to get the situation under control, as I simply live under the constant threat that someone will take issue and judge me. And of course I go out of my way to give you more materiel.

But this is all a demonstration of the fact that this is always happening.

Even in the hard version, like if I attack you psychologically so that you have less basis to attack me psychologically, or if I kill you so you can’t kill me; even in this case harming you does not actually solve my problem.

This is why Hobbesian Trap is so pernicious: distrust only multiplies by deceit, manipulation, and killing.

After all, if I see you kill “our enemies,” then I know you are capable of killing. So, I know you are capable of killing me.

Once the plot starts advancing and people start dying, then the whole thing can cave in very quickly.

[![Officially there's any Vultures event planned right now, nothing to look  forward to : r/GoodAssSub](https://substackcdn.com/image/fetch/$s_!D-tx!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff8d4fa68-066b-49d0-89cc-b5d8b02ae1e2_1080x607.jpeg)](https://substackcdn.com/image/fetch/$s_!D-tx!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff8d4fa68-066b-49d0-89cc-b5d8b02ae1e2_1080x607.jpeg)

The point is that even under heavy Hobbesian Trap conditions, there are still common assumptions and things you think you can rely on.

“Et tu, Brute?” expresses this quite well, you are let down by the one thing you thought you could rely on in a chaotic or hostile situation.

This could even be yourself! Where you see yourself respond or act in a way which is not in a way what you wanted.

So now you have to abstract over yourself in this way, this is of course what it means to be in conflict with yourself and back to Greater Jihad.

As I wrap this up, I’m trying to be more positive and focus on not being too negative, while also dredging through the parts of me I might fear are “hard to love.” My approach is basically to take an alternately conversational, casual, gregarious and cheerful approach to all of it.

It’s sort of like the “autism” videos I have been watching! It actually is powerful to narrate a relatable inner monologue and instead of being ashamed or just quietly sad about the imbalanced situation (back to Hobbesian Trap and what constitutes harm—for me HT can apply in totally non-kinetic environments even where stakes are comparably tiny. The thing is that stakes have everything to do with the symbolic relationship between the people involved, and so really any stakes can be substituted for any other), instead of that you can narrate it and put it out there so people can be like oh yeah I relate to that and it builds a counter-narrative where we are not weird for finding you overbearing.

Anyway, I basically want to apply that to myself. I was thinking about whether I got “captured” by the alt-right.

The thing you need to understand is that there are still multiple levels, multiple gears that I can go to. In terms of my blitz, yeah I was watching something about _Breaking Bad_ and it was about how Hank didn’t think Walter was the guy because there was this pre-conceived notion of Walter that Hank had.

Well, that just shows why you don’t want to be too predictable. It makes you easy to fool. That’s why you more properly be open to mystery and the depth of what others’ intentions might be. We assume that other people are being forthright while we know how much key data we keep secret. In a way we must think we are somehow winning, where we are hiding so much while others are so blissfully unburdened by anything too obscene or shameful or pathetic.

Nope, they have all that stuff too, it’s just about hiding it. Keeping things behind closed doors is such a huge evil in my opinion. How much horrible shit is kept under wraps and continues because of this? Leak it all, I say.

Now, the issue is that there is no proper engagement tissue to absorb all this. “Society” is like a person with radiation sickness, and we need to discover what the soul is and transfer it over to a new body before they die. Which is to say we all need to become more social engineers, and we need a type of social design which makes sense in this co-design space, and which doesn’t rely on some people to be the designers and others to just passively accept their role.

People might want to do that because it’s comfy, but at the same time we have to move. The pace of change will continue to be limited by what “normies” (people who pretend to believe in norms) will accept and acknowledge, but that’s why we also continue to churn and adapt our behavior to confront people with the Borrommean knot.

Anyways, so the energy I’m going for is Dee Dee meets, I don’t know, the Nietzsche guy from _Little Miss Sunshine_ if they got into Baudrillard after they couldn’t do the air force.

Of course, telling you even more about _why_ I wanted to write about the n-word and swastikas and porn and so on, all this will in a way _just make you more worried_ in the Hobbesian Trap sense. What are the possible games and double games?

Luckily for you, I don’t really try to lie in any of these. But what if I’m…. *lying to myself*?

The thing is basically that when you go up or down logical types you see that things really do converge. Everyone shits, for example, that would be to go down.

And up top, every personal vision or ideology is aiming toward something, something mysterious, something strange that’s supposed to happen later on, after a process of building, and that will involve people from all over and working in concert.

It’s all about stopping other people from wrecking our sand castle.

Imagine a huge fence and guard toward and machine gun turrets all arranged around a sand castle and that’s what’s being protected. 

And people want to destroy it for some reason. Waves of bodies, whole lives and chains of ancestors led to this, fed into the maw of death of security all arranged around some coarse little particles arrange castle-wise.

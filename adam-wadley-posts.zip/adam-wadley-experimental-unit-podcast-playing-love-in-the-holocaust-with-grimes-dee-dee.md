---
title: 'Experimental Unit Podcast: Playing Love In The Holocaust with Grimes & Dee
  Dee'
subtitle: Don’t tell me… I’m losing face?
author: Adam Wadley
publication: Experimental Unit
date: October 27, 2025
---

# Experimental Unit Podcast: Playing Love In The Holocaust with Grimes & Dee Dee
[![](https://substackcdn.com/image/fetch/$s_!3M0-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc82ca0f1-fe2f-412e-b2a9-0aad8b32afec_1170x2532.png)](https://substackcdn.com/image/fetch/$s_!3M0-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc82ca0f1-fe2f-412e-b2a9-0aad8b32afec_1170x2532.png)

Don’t tell me… I’m losing face?

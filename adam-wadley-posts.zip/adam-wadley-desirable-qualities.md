---
title: Desirable Qualities
subtitle: 'In Other Words: The Science Of Why I Have No Friends'
author: Adam Wadley
publication: Experimental Unit
date: May 04, 2025
---

# Desirable Qualities
This is my first post that I’m making at my “actual job,” which is such a funny thing to me.

The point of this job is to make like 1400 dollars a month, which doesn’t actually make a difference in my family’s fortune on the relevant timescale.

Keep in mind that shit is getting severely messed up in the next couple of years. I don’t anticipate that money is going to make that much of a difference.

So it’s more about me getting out here, not actually just keeping to myself. It’s a frustrating thing because the environment is too loud here and no one ever talks about anything interesting.

Actually, my co-worker and I were talking about how people can assassinate tyrants by posing as sex workers for them. I brought up [Charlotte Corday](https://en.wikipedia.org/wiki/Charlotte_Corday), who I learned about on Simon Schama’s show _The Power of Art_ about David:

Thinking of the title “the power of art” reminds me of the idea of   
”the art of war,” of course owned by Grimes since her inclusion of some old book idk in her music video “Violence”:

See also “48 laws of power,” etc. So is art a form of power or does art subsume power?

It’s obviously the latter. Anyone who believes in power is stupid.

See again Baudrillard from _[The Agony of Power](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.2010.The-Agony-Of-Power.pdf)_ :

Power itself must be abolished-and not solely in the refusal to be dominated, which is at the heart of all traditional struggles-but also, just as violently, in the refusal to dominate (if the refusal to dominate had the same violence and the same energy as the refusal to be dominated, the dream of revolution would have disappeared long ago). 

Intelligence cannot, can never be in power because **intelligence consists of this double refusal**. 

"If I could think that there were a few people without any power in the world, then I would know that all is not lost" (Elias Canetti).

Power, is accordingly, a subsidiary place where fools are relegated. Just like consumption and of course it goes together.

Consumerism is the extended fantasy of having control over external objects. You really don’t, but an elaborate production is made and then you can exchange the tokens of your enslavement (money) for trinkets (akin to alcohol or beads given to indians). And in this way you can “regulate” the constant stress and humiliation of “having to” follow the orders of people even stupider than you.

See also this idea of “refusing to be dominated.”

People will play at “Resistance,” but the terms in which their plans and “tactics” play out are in fact symptoms of their mental domination.

People just don’t really appreciate how big a deal it is what terms you think in.

People take for granted the norms and terms you are familiar with, and even take them for granted as part of themselves.

It’s similar to eating slop your whole life to where, in fact, your body is made of slop.

You could start eating Chipotle like a boss at any time, though. You might still may respects to the slop you were eating before since it’s still making up your body in part maybe forever (any calcium you got went in your bones, which to be fair maybe we will eventually remove, or remove you from “the body” which contains “bones”).

This is another way of saying things like:

  1. There was never “a nation,” but the illusion of “the nation” and people being (stupid/) invested in the conceit of “the nation” made a difference. There never was a “United States of America,” but there were buildings made by people who (seemingly) believed in that conceit. Therefore “United States of America” is not something which is _going way_. It was _never really here_. Yet the illusion of its being here must itself pass away.

  2. There never was a “male” or a “female,” just different things with DNA and some organs that could make another organism together. Obviously, “culture” has tried to make there out to be an “essence” of being “male” or “female,” but this simply doesn’t obtain and everyone who thinks so is flat wrong. That said, the _idea_ that there is such a thing as a “man” or “woman” is obviously very influential. So therefore, again, it’s not that anyone can transition away from being a man, for example, because there are no men. What people transition away from is their investment in an illusion.




There are many such cases. The upshot of whether something “really exists” or not has to do with how much credit you give people for co-creating something. If I refuse to acknowledge the USA and it “really exists,” then I’m simply delusional. Yet to think the USA simply “exists” is to not count all the psychic energy people pour into the illusion. There would be no conceit of the nation unless people played into it. Therefore there is no nation with ontological precedence over any person.

Still, the idea of a nation might precede us. What’s nice there is that we can simply re-interpret the notion. There is no ontological debt which we always must pay on someone else’s terms. No one may put terms on purpose, this amounting to power which as we’ve discussed doesn’t exist.

This is, you’ll note, an improvement on Baudrillard, who is still seeking to “abolish” something that doesn’t exist. Hey, Jean was born in 1929, people believed in power back then.

“That’s no excuse.” I know, pig. I know.

# Seriously, Why Don’t You Have Friends?

[I started writing a while ago in the cemetery near my job instead, I got a one hour break from standing next to the worst fucking music you’ve ever fucking heard, so I had to take it. Nothing my intention if possible to get my face painted with an orange, purple, green, and grey heart]

So, I made a list here on my notepad of desirable qualities. After all, what is my fantasy? What do I even want to do with people?

Most of my stipulations could be expressed in negative terms: don’t be like this, don’t be like that. Or positively. With the negative it’s easy to see how we lop off this section of the population and then that. People really ain’t shit in a way, don’t you think? It’s like, if you take away their personal reasons for being invested in anything, what is interesting about it?

Of course, that’s to give away the store. That’s why you commit to all sentient beings beyond terms and conditions. No one “deserves” compassion any more than Allah “deserves” to be worshiped. No, you worship it because that’s just what you do, actually that’s all you can do. Heresy is itself a heretical doctrine.

The idea is not that anyone is doing anything they “shouldn’t” be doing. Go wild, pig!

The thing is none of that bullshit could ever be good enough for _me,_ or anyone of quality. So, I and we will simply do what we like, which is again to treat everything as a piece of rape meat waiting to be impregnated by something actually worth a damn. Note that I do understand that you somehow think your purposes are worthwhile.

I simply disagree. My purposes supervenes over yours, so I will destroy the conditions of possibility of your misguidedness. You are free to feel the same way about me and to try and rape me as much and hard as you want. I’m not positing myself as “special,” just again that nothing you do is at all good enough or interesting to me. So why would I want to associate myself with you and limit myself to what you will accept?

Okay, so let’s start with some qualities:

  1. Openness. You never say something like “but we know that’s not true because X.” Such simple contradictions and appeals to truisms, especially if you should know that of course I’ve heard of that before so I still have more to say despite it—these show that you are reactive, seeking to control conceptual exploration, probably for some stupid trauma reason. Look: skepticism wins. You don’t have a refutation of it. Therefore you should never just contradict someone’s personal thought with some little contradiction. Whatever you want to bring up is fine, especially if it’s like I wanna jump off a cliff or something, but the approach is always important. 

  2. Respect: this is a funny one because the unwise might think that I am at times disrespectful. You’ll notice however that I have perfect respect for the living, thinking, feeling thing inside each sentient being, below their character armor of rigidified self-ignorance. Another level of consideration is: what is respect? We must also have respect for the situations that we are in, principally the planetary state of emergency. Every statement uttered which is seeking to “forget” something like this is totally worthless and makes you horrible company. At the same time, if one is being knowledgeable and meta, again there’s nothing which can’t be addressed. For example how funny it is that people kill themselves all the time and people cry about it meanwhile whenever people actually wanna talk feelings or hard shop everyone runs away. So uh yeah it makes perfect sense why no one wants to live in your company. How do we respect those dead? The ones who killed themselves to get away from us because we are so insufferable? The thing is that I am very sensitive to disrespect, and if I feel disrespected by a person then I won’t like them. So when do I feel disrespected? OMG when people say things like “I’ve been there before.” No, pig, you haven’t. Kindly shut the fuck up before you act like you know my experience. What else? Interruption, any signal which conveys that you think you are more important than me. This is unacceptable because what quality could you possibly have to justify this? There is none. Now, people will again point out that I feign superiority all the time. The thing about it is that I operate at such a high logical type that the emotions I have are really beyond your ability to fathom, and if you want to look at something I said and say it’s disrespectful, you’d really have to look at everything else I’ve said to put it in context, especially since the conceit of disrespect is something I’ve directly theorized. Still, the point here is not for me to justify myself but to say why I have no friends. Still, you might think I have no friends because I’m disrespectful. The issue is more that people’s purposes are worthless and they are cowards.

  3. Risk-taking: If I were to have a friend, they would have to be willing to stand by me in crunch time. Like going into battle together. People stand with each other all the time, their risks are just limited because it’s some stupid “private life” shit instead of public works. And if its public works its sanctioned by tons of norms, like going off into battle to kill the sand darkies because muh civilization and muh power. Basically what I’m saying is that’s an easier risk to take because you’re going along with well-established and “Respected” mass mind/heart rape. It is more of a risk to stand alone, or to stand with me. It’s necessary to risk your life, there’s no question about it. I can imagine dying pursuing my interests, and I still have no second thoughts about it whatsoever. After all, what am I going to do, live a life like one of _you people_? I don’t fucking think so lol. At the same time, this demands likely cutting ties with institutions, at least for the moment. Something like what Kanye is doing, except not completely pointless.

  4. High logical type capability: I understand not everyone is into theory yet, etc. But one needs to have the capacity to get the intellectual stuff. Which really isn’t that difficult, the hangups are mostly the things above: people are too closed off because they’re stupid; they’re disrespectful because they’re stupid; or they’re cowardly because they’re stupid. In each case people think there is something good they would lose by joining my path, which is again more evidence of their stupidity. The point here is that someone must be able to follow me into a place where emotions and meta-emotions are tied up into concepts and meta-concepts. You have to be able to keep up. I would be happy to take time to explain things or present my ideas, etc., it’s just that there has to be passion on the other side to get into this souped-up lateral thinking that I do.

  5. Certain things we can say about the sorts of doctrines people could not have and really be associated with me:

    1. Must not believe in the state, the law, norms, universals, etc. 

    2. No scapegoating (follows from a since there is nothing coherent to scapegoat)

    3. One must have negative capability, hence one cannot think that “objective” reality is knowable and that they know it

  6. Comfort with extreme tones, emotions, personal history. So I obviously say all kinds of shit, and I don’t feel the obligation to justify what I said. At the same time, it’s all worked out. But more than that, nothing requires justification since everything is the work of God and we are all God. So if you want me to justify why I did something, you can simply ask yourself. Anyway, someone would have to be comfortable associating with me despite some bitterness and “out there” expressions, including using slurs online including in ways indistinguishable in a single post (by the unwise) from first-order bigotry; my last relationship was toxic and I did some bad stuff there; most people in my personal life wind up not liking me (to be fair, they’re all idiots). Stuff like that. I am happy to be open and honest, just not to be judged. 

  7. The other thing is I am not to be put in a box. I’m not here to say I’ll do this and you’ll do that. No, this will grow and change over time. Therefore I must be embraced in whole cloth and going forward. This also means of course I would feel the same about anyone else. All you need is to demonstrate the ability to perceive the boringness and stupidity of worldly goals. So we can easily connect on more important things, and then be able to keep tracking as we challenge each other to level up.

  8. This requires complex dynamics since it’s the usual trope of “let’s not be toxic” but mixed up with people who can actually think. It was bad enough when I was the only one thinking! So anyway, we both have to accept that in a way we don’t want power over each other, on the other hand that’s just a way to dissimulate power conceits, on the other hand given certain understanding you would know why the others don’t want to do that. Again related to what is the bigger picture.

  9. Any non-relationship must be grounded in the larger non-relationship between each person and the world. We are ambassadors of the world to each other. For me, you are simply one of the many things part of what is outside me, and likewise. 

  10. As such, any friend of mine would have to be willing to defy institutions and their norms on pain of death. Not willy-nilly, understanding that risks can sometimes only be taken once, etc. Still, the idea of “staying safe” is intolerable to one who perceives an emergency and knows they can help. Despite which this emergency is coming to kill all of us, lol. Still, it would have to be that I am more important to you than any illusion of any “state.” And all that that implies. Just saying shit and taking no action to prove it, or which effortlessly demonstrates it, is stupid and disrespectful. And back again to this “scheming” where we posit ourselves as beyond “all that” and then just go back to the same stupid fucking relationship everyone has but instead of bills it’s the illusion of social change or whatever that we are fighting about.

  11. Hence the importance of paying attention, radical acceptance, and the forswearing of all worldly stakes (karma yoga). It would be good to bond over a bunch of shrooms for example, or in some other way to cement this. The problem is that each step of this process is a risk, where you stand to learn at each moment what the reduced stake is that someone is really interested in, though they profess to be interested in this or that. For me, for example, I do a lot and it’s kind of interesting, but what am I really interested in? Feeling important? Maybe even the opposite, I want to be humiliated? Or I want you to listen to me and I won’t listen to you? Etc. Of course I would never ask anyone to _trust_ me, that’s disrespectful anyway. You can never trust anyone you respect, since you would then respect their unpredictability and their own reasons which you wouldn’t be able to say “loyalty to you” supersedes. 




So basically, you can’t find people like this. Everyone is trying to do a career and make money, or else not go to jail and stay alive, or else live on some conceptual cul-de-sac, or else not be willing to open up about our own sadism and masochism, or whatever else.

I demand full-spectrum intimacy. I don’t even need to have sex with people, I like how people into spirit don’t fuck or anything. Hierogamy is fine. I literally don’t care, because what I want to do is have brainchildren, heart children, spirit children with people. That means instead of just me sitting here, absorbing shit, and then ejaculating it all over your face here, instead we could work together and make something that really has legs. I am always moving more into this anyway—I will do it by myself if I have to—yet this process could be greatly accelerated by others.

So, that’s why I have no friends. No one is really like that. Everyone still believes in capitalism or nations or sexes, or is uptight and can’t admit they are wounded, or people lose respect for others too easily because they judge them by stupid standards like their parents’ or some authority’s, when of course those people if they had their way would just lead us into rape, humiliation, and death.

People are too cowardly, people want some sure thing. People don’t want to burn their bridges to the land of squares. Which is fair, I don’t think it’s necessary to choose me over anyone. But you have to choose me over your self-ignorance or that of others. People love the shit out of self-ignorance.

Thinking about other people I know and why it doesn’t work out. People don’t have their own ideas, people don’t take initiative. People act like I’m supposed to do everything, like I’m supposed to have a plan except that would just give you standing to reject it, like I’m below you even though you never actually do anything important for anyone, especially not thinking systemically.

One friend who just lost me is too hung up on “biological sex,” meanwhile not having anything interesting to say AT ALL about philosophy of science. People wanna have all these little opinions without having even the slightest idea of the complexity they’re opining on and what has been said about it.

Oh, people are also not enough into religion and spirit and psychedelics. This is an intimate part of the work, which must be engaged. It’s mystery. People everywhere flee mystery for some little surety that I find boring and shit and which doesn’t acknowledge what I have to offer.

Let’s see, otherwise there may be some people who are like this, but I haven’t found them. I don’t look enough, I don’t take enough initiative.

The issue there is that I already function kind of like a famous person, or just a person with a criminal record or something. There is so much about me which can be publicly known and which someone would have to be okay with, meanwhile the typical shit _you people_ pull is just not to mention your baggage and hope it doesn’t come up before you die because again, you’re stupid, and again, you’re a coward.

But, you can still enjoy and profit off all this work I do for free for you anyway, so enjoy your anonymity, you coward, and feel free to pay your respects at any point. 

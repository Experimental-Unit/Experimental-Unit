---
title: Trump & Elon's Blitzkrieg
subtitle: 'Poland Has Been Invaded: What Are You Going To Do About it?'
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Trump & Elon's Blitzkrieg
We start with an elaborate conceit connecting weapons with concepts.

Carl Schmitt mentions a difference between regular and irregular forces being that regular forces openly display their weapons. How shall we port this over?

Sidenote: “Porting” deserves its own elaboration. This is a kind of exploit, part of the absolute exploit which is treating everything like the found or discovered materials in our artistry of life, our age of discovery. When you port something from one context to another, you are finding a homology, usually one or a few core similarities or points of comparison, and then seeking to deepen this by finding corollaries in more incidental features related to each point of comparison. This happenstance finding and raising up of the ground of these more prominent features and making them aspects of a larger plateau which is now the increased focus and gravity applied to a given field of discourse.

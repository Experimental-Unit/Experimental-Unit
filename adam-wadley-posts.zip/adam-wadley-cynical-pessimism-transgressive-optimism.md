---
title: Cynical Pessimism, Transgressive Optimism
subtitle: Oh! Don't For Get To Add "Self-Transcending" In There!
author: Adam Wadley
publication: Experimental Unit
date: May 13, 2025
---

# Cynical Pessimism, Transgressive Optimism
I’m starting off thinking about the topic of immigration.

This seems to be what so much fuss is about, so let’s ruminate on the big questions, shall we?

There is, to put it bluntly, the view that people will not assimilate and also that the demographic makeup of “a country” is important and should be preserved.

In my opinion, the perspective that people should be kicked out and that “resources” should be preserved for “the real insiders” is misguided, and doesn’t even serve the people it is intended to.

That’s because this sort of ostentatious “nationalism” is only ever the vehicle for a two-headed monster under the surface:

  1. Occult psychological motivations

  2. Deep technology intrigue which is beyond the purview of most of “the people,” whoever that is in your fantasy




This is because the fantasy of the nation is one that appeals to everyone in different ways. Everyone is unique, and in a way there are as many nations as there are ways that nations are conceived in the minds of all the people who dream of such things.

In my view, it’s clear there is some sort of “state” architecture, but it’s unclear what is humming underneath the surface.

In particular, the question of technology is on my mind. It seems to me that what matters most, in a way, is how the most “developed” or “impactful” technology—whatever that formulation could be gesturing towards—how that is used.

So when I see the fads of ideas that are going around, you know you basically have the reveling in “hypernationalism,” which is in a way enjoying the nature of what it found there to begin with, but is also kicking things into overdrive.

We have to see this also as a response to a general acceleration of the rate of change.

For example, the degree of mystery I contemplate is the question of whether we are really in a “Wild West” of technological development, a countdown to a quantum computer that can break all encryption. And if something like that happened, would we know about it?

How many things like that deep are we at this point?

To comment on planetary affairs is, as a result, to be talking about more fog than war, more uncertainty than specifics. That’s part of why my idea for _Experimental Unit_ I was referencing the idea of a virtual nation.

[So you can see examples of formulations here.](https://en.wikiversity.org/wiki/The_Idea_Incubator/Virtual_Nations)

[There’s also just good old fashioned civic nationalism.](https://en.wikipedia.org/wiki/Civic_nationalism)

Which brings us, Mr. Anderson, to the reason why we’re here.

The point that I really want to drive home is that those who claim to be defending “Western Civilization” or whatever national or ethnic identity, and launch into hatred or basically who do not realize that the way forward for ourselves and those we care about goes along with the way forward for everyone else; that people like this are actually quite pessimistic about what the legacies of the traditions they claim to champion can achieve.

What I mean to say about this is that if you look at things that are drawn on, say Christianity for example. People will say that they want America to be a Christian nation, but they don’t want to help the poor. It doesn’t seem like they treat people with much grace.

I like Lincoln, who talked about peace among ourselves and with all nations.

Civic nationalism is a good example of a “card” to play for someone playing “America DLC Pack.” Basically, whatever it is you think you like about “white” “Christian” “America,” I’m telling you that we can achieve in a better way which better serves you as well as not pissing everyone else off.

What I mean by my own championing can be summarized in a line from the song “America” from _West Side Story_ , which is of course based on Shakespeare, don’t forget, the significance being the connection of “American” stories to the Old European canon and legacy. Anyway, the line goes:

“You forget _I’m_ in America.”

Even better is that this comes right after someone says, “everywhere Grime in America.”

Anyway, the point is that I don’t have to recognize that there “really is” an “America” at all to understand that “for you,” this concept is existentially grounding.

Even though I was not born “in America,” I’m a “natural-born citizen" and I’ve always lived "here.”

So the point is, whatever it is, or whatever seeming aspect or discrete phenomenon you call “America,” whatever shrouded vortex makes it up, that also makes me up and I’m in it and part of it.

So, if the question is about what is the legacy of “America” in “the history of the world,” I say to you that it is an open question and that it depends substantially on my own activity in the past, present, and future.

For example, if we have many people who face the housing issue, then why are we so pessimistic that we cannot solve it?

The question is more that people do not _want_ to solve it.

And there, the question is why?

We can always presume that whatever people say publicly is a “public” position for those who are rubes compared to them who they are farming for attention, labor, data, money, etc.; meanwhile, there is a “private” position which is discussed with their “peers” and bosses, people who are basically trying to or are farming them in that same way.

[Similar to chains of secrecy mentioned by Debord in the ](https://theanarchistlibrary.org/library/guy-debord-comments-on-the-society-of-the-spectacle)_[Comments](https://theanarchistlibrary.org/library/guy-debord-comments-on-the-society-of-the-spectacle)_[. ](https://theanarchistlibrary.org/library/guy-debord-comments-on-the-society-of-the-spectacle)

> ### **XXI.**
> 
> The secret dominates this world, and first and foremost as the secret of domination. According to the spectacle, the secret would only be a necessary exception to the rule of abundant information offered on the entire surface of society, just as domination in the ‘free world’ of the integrated spectacular would be restricted to only an executive department in the service of democracy. But no one really believes the spectacle. How then do the spectators accept the existence of the secret that alone guarantees that they cannot manage a world, the principal realities of which they know nothing about, if one were to truly ask them for their opinions on the manner of managing it? It is a fact that the secret doesn’t appear to hardly anyone in its inaccessible purity and its functional universality. Everyone accepts that there is inevitably a small zone of secrecy reserved for specialists; as for the generality of things, many believe that _they are in on the secret._
> 
> In the _Discourse on Voluntary Servitude,_ La Boetie showed how the power of a tyrant must encounter many supports among the concentric circles of individuals who find, or believe to find, their advantage in it. Likewise, many politicians and mediatics who are flattered that no one can suspect them of being _irresponsible,_ know many things through their connections and confidences. Someone who is happy to be taken into confidence is hardly likely to criticize it; nor to remark that in all the confidences, the principal part of reality will always be hidden from him. Thanks to the benevolent protection of the cheaters, he knows a few more of the cards, but they can be false; and he never knows the method that directs and explains the game. Thus he immediately identifies himself with the manipulators and scorns the ignorance which in fact he shares. Because the scraps of information offered to the familiars of a lying tyranny are normally infected with lies, manipulated and uncheckable.[[40]](https://theanarchistlibrary.org/library/guy-debord-comments-on-the-society-of-the-spectacle#fn40) They are, however, pleased to get these scraps, for they feel themselves superior to those who know nothing. They only know better than the rest so as to better approve of domination and never to actually comprehend it. They constitute the privilege of _first-class spectators_ : those who have the stupidity to believe they can understand something, not by making use of what is hidden from them, but _by believing what is revealed to them!_
> 
> Domination is at least lucid in that it expects that its free and unhindered management will very shortly lead to a quite large number of major catastrophes of the highest grandeur; and this as much as on ecological terrains (chemical, for example) as on economic terrains (in banking, for example). It has for some time already been in a position to treat these exceptional misfortunes by other means than its habitual handling of soft disinformation.

So basically, I feel like the actual Golden Age thing is on the table, and you can make it all happen with a next-level like human capital service economy which invests in people with the “payback” being contribution to the work that must be done to build a social fabric capable of sustaining into the deep future.

If you really want to think about your legacy, then the question is not about birth rates and who is around, it’s about high technology and what is being done with it.

The clear trap of a “hypernationalism” is that you think you are in on the club and then it turns out that you will be chewed up the same forces that said they were protecting you and glorifying you and all this.

That’s what happened, in my family, _with the Nazis_. My grandfather was a child soldier—an older child soldier at 17, but still, would you want to fight in the Waffen-SS on the Western and Eastern fronts in 1944-45 when you were 17? 

Who knows what atrocities my grandfather committed. Which would also be in my epigenetics or whatnot, by the way, so yeah imagine having the Holocaust in your blood when this Kanye stuff comes up and you’re sitting here as a conceptual artist going ummmm….

But it’s also that the Holocaust was not Opa Richie’s idea. They were born in what, 1927, making them 6 in 1933. That’s younger than I was, 10, when 9/11 happened.

I was also thrust into a war.

That’s the thing people don’t understand about it, right.

So I’m using legacy concepts just to get it out but blanket statement I don’t believe in gender or sex identity and basically don’t think people are defined by any terms I get practical considerations but I don’t think we’re actually able to differentiate our projections possibly harmful from legitimate expectations whatever they might be or labels. So the whole art is to obsolete all these concepts and in the meantime to operate transconceptually with a blanket proviso that everything is poetry and Dhamma language and not representative at all. There is no one knowledge map we all hold, what there is to be mapped is also made up by what there is in our our _Vorstellung_ what we put in front of us, anyway.

So my grandfather on my mother’s side got sucking into WWII in the Waffen-SS in Hitler’s Germany, then ran from the Russians to be a British POW. I’m looking at the poster from the theater piece they did there called _Karnival im den Hölln_. But it apparently from what I heard was still preferable to Soviet POW camp.

Anyways, then on my dad’s side my grandfather became a pilot right before America entered, and then flew transports over the Himalayas from India to China apparently an oddly high number of time, like they made a lot of trips and it was dangerous, they were flying higher than the plane was designed to go. Shout out [TOGA Trew](https://www.linkedin.com/in/togatrew), who I actually did talk to on the phone it was nuts idk if it was some sort of temporary number but anyway much more surely than Grimes, although in my heart I believe it still anyway. Also it would be really funny if not like who would do that.

Anyways, then my grandfather Carroll wasn’t called back for Korea, and thought about whether it was an oversight, and someone told them to keep their head down and just lay low so as not to have to serve, and that’s what they did.

So then my dad turned 18 during Vietnam and the draft number was not called but then Carroll told my dad to volunteer to go fight, and that the conflict was like WWII and distinctly I remember (it was in the bleak December) the phrase that it was a matter of “family honor.”

Then if you recall I was like coming of age during the Bush II administration, and we were invading countries like it was going out of style. That’s really like the Operation Barbarossa if you want to look at it that way, as well as NATO expansion. But the thing is I don’t begrudge anyone for doing what they do, even for cynical reasons. I understand that there is a Hobbesian Trap and it applies in a cruelly necessary way at all levels and scales, and stuff is so complex I realize I lack the education but more importantly access to the information that could make sense of anything.

Anyway, there was discussion back then, my dad told me that if there was a draft I was going to be hidden under the house in the crawl space. Now that I think about it in my mind I’m going “like I’m Anne Fucking Frank or something.”

Can I be Frank with you?

“Wilderson?”

Anne Frank tie-in _super herbe_ in light of previously mentioned genealogical connection to Nazi regime.

But so this gesture, right, was saying to me that I’m going to be kept out of the war, that by not going that is going to be protecting me or something.

It’s sort of similar to the idea of wanting to get out of “America” right now. It’s like, where are you going to go?

I really enjoy also being German right now as well. Between the constellation of America-Russia-China-India, now here comes Germany and wouldn’t we all like to know what Germany has to say?

There again, German philosophy for example not to mention science have changed the game.

But what we need right now is basically social fabric.

There are some aspects of “traditionalism” which are fine and some which are excuses for cycles of violence which are basically ritualized forms of violent intimacy.

Whatever “culture” we come from, we now have the ability to refine the quality of our intention so that we don’t think we need to control other people and what they do in order to “preserve” what must be preserved.

No, basically the model is that we should demonstrate the excellence of our ways by showing what gifts they have to bring to all.

There again I tell you, motherf***ers act like they forgot that _I’m in America_.

So what I’m telling you is that I’m here to dust things off the shelf and tell you that flipping your bonnet about “postmodernism” is just ignoring the legacy of skepticism. People have their little responses to this but they don't engage in good faith dialogue about it.

Because you do have to hit the mystery. And the line is basically that well you have to pick something, and this is what we inherited and so on..

The line to the “traditionalist,” and in reality this is an integrated “critique” of left and right together, since “the left” is a form of traditionalism which sees what needs to happen or whatnot exclusively in specific terms inherited from a specialized canon that people are then dominated by. Interpreters of Marx or whatever Marxist text are the kinds of people who are able to subtly steer the opinions of many people.

Anyway, the line is that you don’t really understand what you inherited.

My fully heroic claim is that I am more competent to wield the collective cultural legacy and all the honors treasured in heaven or elsewhere that you are.

I find that “celebrations” of community or shared experiences that _must_ contain some supposed enemy or outsider, some foreigner whose ways are unacceptable and with whom there cannot be no Concord.

This is where I admit: people everywhere stand to change. Triple-loop learning is not well ensconced anywhere.

To take for example in Islamic traditions, for me two big issues that come to mind are circumcision and the treatment of “women.” Now, the treatment of “women” has everything to do with the treatment of “men” as well. In all cases it is the subordination of the spirit of the person there to the expectations of the group.

In my opinion, children and everyone should be allowed to explore whatever they want if they explore it with a good nature. The treatment of children is actually a profound ethical emergency because it is an example of where we understand that truly consensual mutual acculturation is not possible. You can’t ask a child whether it wants to learn a language, that is simply going to happen if it is around speech.

So this is to make a big choice for the child, to change how its brain is wired for example which will impact all its choices ever.

What I’m saying is that this sort of thing is in some grand category with “grooming.” If you wanted your child to follow in the “family business,” for example, well of course you’d want it to speak your language.

The “family business,” though, is bigger than just a profession. Language is used for all sorts of intercourse, after all.

The family business is surviving and getting by and making one’s way in the greater affairs.

The crushing blow of today is that the ways of the past are hitting a brick wall.

What I am recommending, basically, is to salvage as much as possible which does not involve domination or being dominated.

So if it comes to America, of course I might start with an edgy example like John Brown, but precisely because it is a messy gesture toward including everyone in “the social compact.”

Now we are at a place where we really need to be concern about all 8 billion people and a lot of species of animals and so on.

The scope of things we need to care about is growing while we are becoming more stressed, and when people are stressed they want simple heuristics to make choices. 

So the choice we are making is to just label people we don’t like as bad and just pretend that we will be able to get rid of them somehow.

What I’m telling any “nationalist” or whatnot is that you are sleep walking into a WWI or WWII killing fields scenario, and you are really just going to die in the slaughter and your child that you wanted to protect will also die as well.

Look at what happened with Nazism: it wound up with national suicide and the suicide of the big leader.

Nazism is a convenient example because it has the “positive” community, the _Volksgemeinschaft_ , and then the outsiders, the official enemies, of course with Judaism at the top of the list.

So for example, if someone were convinced that “Jewish people” have disproportionate influence and that there is some issue, then I would offer to them why they do not think that those people can be influenced so that their actions would be more helpful?

The issue here is obvious if you look at the idea of assimilation.

As I would basically put it, people are mad that the people who come are different than the people here. Skin color is a part of it, but it’s also the idea that people are different, that they don’t fit in.

The usual scaremongering about sexual crime is also rampant. Remember back to Black New World Order pornography. This sort of racialized humiliation being eroticized feeds right into the fantasy of combating the “military age males” coming into “one’s territory” by sharpening the phallus of “the state,” making it serve basically your balls and the spreading of “the seed” of you and people like you.

My take would basically be that we are currently witnessing a huge fetishization of procreation at the precise time that procreation is thrown into stark relief by the possible planetary abortion soon to take place.

I again offer to you that what’s most important is that we not all kill each other with technology which is growing more powerful, or whose impact is simply becoming more fully unsheathed.

In this sense AI ethics in terms of reproducing bias and bigotry is related to X-risk. This is also related to the issue of categories in general.

When we operationalize categories we’re compressing the infinite symbolic significance into digits and it goes into a computer. Such technology which starts to rewrite the surface of the planet, say, is going to have consequences for you sooner or later.

“In the long term, we’re all dead.”

Well, the long term is catching up to you.

That is where I basically say that we should be checking the eschatology sections of our respective “traditional” DLC packs.

My approach here is to basically try to re-interpret everything away from being kinetic to being non-kinetic. In a big way there is a homology of trying to avoid the mass die-off that seems to be about to happen, and trying to convince someone not to circumcise their child when they think it would be cultural genocide to forbid it.

How about this: it’s totally allowed, but nobody actually does it?

Similarly: who even needs a government if you actually have religious piety and charity?

What I submit to you is that we are in a position to bring all of our cultural flowerings to bear, and these have always been a latent potential in us.

So everything from our civic and martial histories to our canons and sub-genres and subcultures, all of this belongs to the idea of “all the means” that are brought to bear as mentioning the NATO report on cognitive warfare from June 2021.

This is going from whole-of-government to whole-of-nation to whole-of-planet mobilization. And if we meet some more cool people in the sixth dimension we will also include them.

This is the sort of hospitable and chill sort of politics which will allow us for example to interface better with any other beings we might find as we develop.

A big issue is that many people imagine that what is best for themselves is precisely what you call “cultural norms” that I think are holding us back.

For example on sex and gender I think my position is totally radical yet common sense. People are not labels. 

Yet it is also for us to see how we do in fact put our preconceived notions onto people and sort of judge them or send impactful signals that say more about us than they say about them.

We should basically not want to harm the stubborn spirit inside each person, because this is the heart of morale. Morale is like the most important thing, now you call it “vibes.”

On the contrary, many “cultural forms” rely instead precisely on beating a person down until their personal spirit is crushed. Then people are fit into whatever mold can be applied to them.

This is basically again a gesture which comes from fear and a lack of competence. It is the lack of ability to be good company for someone.

What in all cases should be done is to hook up someone’s internal motor and desire for recognition and accomplishment to something that will actually help other people.

This is actually very easily done, it is simply that it is not convenient in a meta-sense. This is the whole question of enchudification.

It’s easy to see when people like slaves or women (but sadly I repeat myself) are deprived of education. If people are so inferior, why should they be deprived of learning?

That’s because haters know very well that everyone is smart enough to get wise and to make a difference, help a resilient community resist predation.

You basically have a lot of people who either don’t believe everyone can get along, or else don’t want everyone to get along and actively want some number or most people to die because they are not good enough for them, or are a threat to the “real people” they actually care about.

I submit to you that any apparatus you build to kill or control “outsiders” while providing a pocket of freedom for yourself and your cohort will kill you too, and you won’t even live that much longer than the people you lynch today.

It’s like people think oh well, 4 billion people can die, and then we’ll stop. Do you think it will stop there?

In this sense, nothing is more important than locking down high technology and then having some sort of non-aggression pact among advanced technological powers.

Then the issue is that resentments and feelings of enmity are destabilizing. No one is actually enemies, everyone just needs to symbolically die and be reborn.

That is where, again, I charge that the “far right” people are _thinking small when it comes to Christianity_. I submit to you that there is not problem with talking like it is the end times; what I advocate though is again to look at all the language and see how it can be applied as bloodlessly as possible.

So again: the mouth is the sword. Didn’t you read that in Jesus there is no East or West, male or female, Jew or gentile? That’s just a “for instance.”

A big aspect of “white nationalism” seems to be a desire to have pride, to do ancestor worship. The issue is of course European Colonialism and all the atrocities that led to the current geopolitical configuration.

What I’m telling you is that the vindication of that history and the “traditions” that brought it about—which are all intertwined with everything else by the way, the idea that “western civilization” and “Islam” are discrete is just lol—is coming in our approach today and how we use the legacy we have inherited to protect who’s here now.

Everything that I do is entirely motivated by having as many people be alive as possible in the future as there can be. I personally didn’t prioritize having kids of my own because I wanted to preserve my operational maneuver in doing social change. But my social change is all about _protecting your kids and supporting you if you want to have them_. By all means.

But at the same time _children are not property_. We are in a learning phase of what it means to be good to each other, and so what we need is basically for everyone to become a teacher and a student, we are always trying to influence others and other trying to learn from all others as well, even when people are trying to influence us maybe we don’t do what they want but we learn from their approach to “the game.”

Because ultimately joy in life is not from control and being satisfied that you did everything on the checklist your dad gave you, or whatever. It comes from reveling in our opportunity to be here together.

Imagine you are oppressing a woman, beating a child, keeping a man in emotional bondage.

Imagine they die in a car accident. You didn't care enough to treat them well, but sentimentally you kind of miss them.

You should grieve more what is squandered.

The delight and creativity that you crush and drive to suicide with your strict cultural demands.

People that are born don’t have any of that. Of course people must be instructed, but people are each their own jewel as well, and must always be listened to.

These are the sorts of communities we want to be in, where we are listened to as well as get to listen to those we feel give us something, whether inspiration, morale, good advice, or comfort. 

Whatever hateful tightly controlled tiny little ethno sect you might want to live in, as a person you still don’t want to be bullied within your community. Among certain people you want to be treated as an equal.

I say that this community should be everyone, and it should be the beloved community.

The squaring of the circle consists in that any “tradition” or symbol or anything, anything in principle can be used if done correctly. So there is a permissiveness, an acceptance, a radical forgiveness of past transgressions and associations.

But that’s only because each perspective is getting a meta layer added to itself. Nazism as a fact can no longer be what it was in the 40s, because Nazism is now coded among a substantial number of people as the worst thing. So there is such a stigma around Nazism as like almost nothing else, and similarly antisemitism is treated differently than other forms of bigotry because it motivated the Holocaust, which is basically treated as the worst crime ever.

Back to the fetishization of the idea of discrete objects. The point is not that anything is less bad than anyone thinks. It is that, at this point, the whole concept of Nazism provokes a reflection not just about the original worldview on its own terms or others, but a whole meta-discourse which has emerged around Nazism.

In this, Nazism I would say is a forerunner. This process will happen to everything, that every reference will more and more have these associations layered over it, and even more and more.

So for example the name “Karen” became a slur, and then it’s sort of known that this is really unfair to people named “Karen” in a way. Still, people will use this idea of “Karen” anyway.

So basically Nazism is the poster child for claiming to just want to protect “your people” but the problem is you have a super rigid and controlling idea of what “your people” means which leads you to inculcate arbitrary standards that don’t really need to be there.

“Culture” is basically skins like what food do you eat and oral traditions connected to particular people.

I think that a lot of the drive toward nationalism is people basically thinking that no one cares about them, and maybe they are right. Maybe no one does care.

So, my thesis is basically that the path to security is to make it so people don’t want to kill you. There is plenty in the “Western Canon” which can help here, and all the noble “traditions” that people on the “far-right” or anywhere really claim to be defending can be more properly advanced by a pluralist approach.

The way you do it is to make your specific tradition indispensible for pluralism. The way you do this is by mediating the interplay of all other actors in the plural field through your own greater mythology or lore.

Now, you have to understand that other people will be doing that as well. And you all have cry about how I thought of all this first or at least put it out there so you’ll always have to cite me.

So what I’m saying is that I’m abstracting over all these people so that all their activity is basically laying the foundation for a New interpretivism which will be able to appreciate, honor, and carry on the legacies of all oral and written and cultural traditions better than any bigot possibly could.

Because the mystery at the heart of any tradition or nation is exactly this: the common origin. And in the end, the sources of everything hang together. For me, we are all the source, and we find our destiny in all other sentient beings.

Therefore it is incumbent upon us not to found our bonds of fellowship on the exclusion of any other party from the warmth of togetherness. Not articulated in firm expectations, but letting the other be and focusing only on the good, encouraging only the good, finding only the good, feeding only the good.

In this way, we learn to enjoy what has to be done, and that is the greatest freedom of all.

The greatest relief is to learn that we need not undergo what we thought was foretold.

Think of it like military instructions: we have been told to secure the legacy of our ancestors. We only _think_ it must be done in a certain way. When in reality the best soldier will see when ingenuity must be used, even techniques which have never before bee tried might be vital to the preservation of the fire which has been burning in us all this time, and that we carry with us from time immemorial.

You would dash all that in the ashes of a bully’s dollhouse.

 _Experimental Unit_ supervenes over all vulgar nationalist and state concerns. The highest imperative is to serve love, and the possibility of love and charity and goodwill among the greatest number and it must be all.

Foreclosing this possibility in mind and in deed does not serve one.

It doesn’t help you to try and steal a bit from someone else, from another “people,” to shield yourself from Hobbesian Trap dynamics for a little longer. You will have to deal with them at some point, to preserve what pluralism you do treasure. Or you become the Borg, basically, and then you’ve lost what you always wanted to protect anyway.

Doing it later will be no easier than doing it now. Think of all the atrocities that haven’t been committed, that don’t need to be.

You haven’t done anything _yet_ that we can’t forgive.

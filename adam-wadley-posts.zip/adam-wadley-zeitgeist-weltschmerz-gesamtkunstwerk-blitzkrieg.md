---
title: Zeitgeist Weltschmerz Gesamtkunstwerk Blitzkrieg
subtitle: and other funny jokes you can tell yourself
author: Adam Wadley
publication: Experimental Unit
date: July 28, 2025
---

# Zeitgeist Weltschmerz Gesamtkunstwerk Blitzkrieg
[![](https://substackcdn.com/image/fetch/$s_!YOc_!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffa92d594-5d34-4a35-9ea0-b3a3edfeea82_2048x1365.webp)](https://substackcdn.com/image/fetch/$s_!YOc_!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffa92d594-5d34-4a35-9ea0-b3a3edfeea82_2048x1365.webp)

# Mirror People Massing

Thread Theme:

What got me to start writing was the impulse to share with you [this academic paper on blitzkrieg](https://apps.dtic.mil/sti/tr/pdf/ADA435929.pdf). I didn’t get very far in before I found something I wanted to write about:

> Germany never adopted it as a term to describe lightning-like campaigns until the British press first mentioned it in a Time magazine article on 25 September 1939 that described the fall of Poland. In German literature of the interwar period, the word Blitzkrieg first appeared during 1935 in a military service journal, Deutsche Wehr. 
> 
> In 1938, Oberstleutnant Braun titled an article “Blitzkrieg,” and discussed the concept of _Stosstruppen, or a combined arms unit_ , capable of tactical shock against an enemy’s position.

This notion of _Stosstruppen_ is highly interesting for a couple of reasons here. First of all, there is a particular genealogy of this term in the events playing out around the idea of various nations and this idea of World War I. The _Stosstruppen_ are emerging from a particular constellation of fighting, and are headed toward being so related to this notion of the _Sturmabteilung_ or SA, which is like the original gang which helps the “Nazis” get into power. At that point, they can be betrayed, and there is a new “private army,” known of course as the SS (Schutzstaffel).

That’s the one that my ancestor would go on to join, the _Waffen-SS_ portion, in Pirmasens in 1944 at the age of 17.

The second interest aspect of the _Stosstruppen_ is this more basic question of _combined arms_. This is a concept you can get a first handle on [here at Wikipedia](https://en.wikipedia.org/wiki/Combined_arms):

> Combined arms operations date back to antiquity, where armies would usually field a screen of [skirmishers](https://en.wikipedia.org/wiki/Skirmisher) to protect their spearmen during the approach to contact. Especially in the case of the Greek [hoplites](https://en.wikipedia.org/wiki/Hoplites), however, the focus of military thinking lay almost exclusively on the heavy infantry. In more elaborate situations armies of various nationalities fielded different combinations of light, medium, or heavy infantry, light or heavy cavalry, chariotry, camelry, elephantry, and artillery (mechanical weapons). Combined arms in this context was how to best use the cooperating units, variously armed with side-arms, spears, or missile weapons in order to coordinate an attack to disrupt and then destroy the enemy.

The basic idea is that you are combining different sorts of capacities in concert in order to artfully achieve a desirable result during “combat.”

Note that you can have a sort of “combined forces” approach to emergency response as well. For example, in the wake of _The Camp Mystic Horror_ , you’d have people coming to volunteer to look for survivors and bodies. Then you have a couple helicopters, ambulances, tree people, whatever it is, these different skills and types of people that are there to serve the common task of finding the missing people.

The “combined” or concert approach (musical pun very much appreciated and to be expanded upon posthaste) would be how to use these different things together. You’d mix and match, not necessarily sending all the ambulances out at the same time, but having in each region perhaps some ambulances, tree people, volunteers to look for bodies.

What we’re tracking here is this concept of Blitzkrieg, which we’re already committed to using, and moving toward some ideas on “combined” or “concert” operations—or opera-tional _art_ in the Strong Sense.

[![](https://substackcdn.com/image/fetch/$s_!p9_I!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa3ec068b-1f5a-49b3-8228-28e104b14a8c_1490x955.png)](https://substackcdn.com/image/fetch/$s_!p9_I!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa3ec068b-1f5a-49b3-8228-28e104b14a8c_1490x955.png)

# Space Mixing

To just kome out with it, what I’m getting at is a homology between combined “arms” and mixed-media approaches in art, tending toward _Gesamtkunstwerk_ or the “total work of art.”

Here’s Wikipedia on [mixed-media art](https://en.wikipedia.org/wiki/Mixed_media):

> In [visual art](https://en.wikipedia.org/wiki/Visual_art), **mixed media** describes [artwork](https://en.wikipedia.org/wiki/Work_of_art) in which more than one [medium](https://en.wikipedia.org/wiki/Art_medium) or material has been employed. Assemblages, collages, and sculpture are three common examples of art using different [media](https://en.wikipedia.org/wiki/List_of_art_media). Materials used to create mixed media art include, but are not limited to, [paint](https://en.wikipedia.org/wiki/Paint), [cloth](https://en.wikipedia.org/wiki/Cloth), [paper](https://en.wikipedia.org/wiki/Paper), [wood](https://en.wikipedia.org/wiki/Wood) and [found objects](https://en.wikipedia.org/wiki/Found_objects).

[Found object is also a key term:](https://en.wikipedia.org/wiki/Found_object)

> A **found object** (a [calque](https://en.wikipedia.org/wiki/Calque) from the French _objet trouvé_ ), or **found art** ,[[1]](https://en.wikipedia.org/wiki/Found_object#cite_note-1)[[2]](https://en.wikipedia.org/wiki/Found_object#cite_note-2)[[3]](https://en.wikipedia.org/wiki/Found_object#cite_note-3) is [art](https://en.wikipedia.org/wiki/Art) created from undisguised, but often modified, items or [products](https://en.wikipedia.org/wiki/Product_\(business\)) that are not normally considered materials from which art is made, often because they already have a non-art function.[[4]](https://en.wikipedia.org/wiki/Found_object#cite_note-4) [Pablo Picasso](https://en.wikipedia.org/wiki/Pablo_Picasso) first publicly utilized the idea when he pasted a printed image of chair caning onto his painting titled _[Still Life with Chair Caning](https://en.wikipedia.org/wiki/Still_Life_with_Chair_Caning)_ (1912). [Marcel Duchamp](https://en.wikipedia.org/wiki/Marcel_Duchamp) is thought to have perfected the concept several years later when [he made a series](https://en.wikipedia.org/wiki/Readymades_of_Marcel_Duchamp) of **readymades** , consisting of completely unaltered everyday objects selected by Duchamp and designated as art.[[5]](https://en.wikipedia.org/wiki/Found_object#cite_note-5) The most famous example is _[Fountain](https://en.wikipedia.org/wiki/Fountain_\(Duchamp\))_ (1917), a standard urinal purchased from a hardware store and displayed on a pedestal, resting on its back. In its strictest sense the term "readymade" is applied exclusively to works produced by Marcel Duchamp,[[6]](https://en.wikipedia.org/wiki/Found_object#cite_note-6) who borrowed the term from the [clothing industry](https://en.wikipedia.org/wiki/Clothing_industry) (French: _prêt-à-porter_ , lit. '[ready-to-wear](https://en.wikipedia.org/wiki/Ready-to-wear)') while living in New York, and especially to works dating from 1913 to 1921.

We might also offer the notion of “found materials.”

Going back to the “war” or operational art (emphasis on the _art_ ), we can compare this to various notions of the trope of fighting, or goal-oriented activity.

  1. The people you care about are in some sense “found materials.” You find yourself in certain situations, with certain emotions toward the other people involved. The basic coordinates of “we are part of so-and-so ‘country’,” or “we are invested in so-and-so religion,” these sorts of things are things we sort of just find.

This relates to all the philosophers who will tell you to just stick to the norms of the time and place you are in. And in another sense it’s this inversion of a reading where it seems overly that people are “choosing” what their allegiances are. Instead, it seems to basically be a “fait accompli” as they “find themselves” “spoken to” by something or other

  2. When we are assembling our forces, getting our posse together, this is the sense of your operation proceeding from the found materials. Just as Opa Richie or whatever they called them back then, just how that person went into the _Waffen-SS_ and then… who knows what happened? Anyway, Richie was found materials. Toward the end of a “conflict” which is not going too well. Untrained and just a “child,” and here is this place where what do you say about a 17-year-old “child” soldier in the Waffen-SS? Let’s say they help do the Holocaust. Are we saying that “this person was just a child”? Or are we thinking about the people they maybe killed, perhaps “true children” of 6 or 3?

Regardless, what is said is that “you go to war with the army you have, not the army you want.” If your army is made of children, then you might be on [the Children’s Crusade (CC)](https://en.wikipedia.org/wiki/Children%27s_Crusade).

  3. The people around in the expansive and operational sense being “found materials,” then when is done—or _orchestrated_ —amounts to the artwork. So if you’re looking for dozens of corpses of little kids that used to go to _Kamp Mystik_ , and let’s say that a bunch of uncoordinated people show up who are tough to use effectively. Then, the search party and search you organize and carry out amounts to your operation, and in the sense that it’s mixed-media found materials art, then you just made operational art.




So to sum up, I’m advancing this notion of combined arts and mixed media under the homology of total art and total war.

Similarly to how we can be “drafted” into an organization that winds up maybe not just “hurting us” and “affecting our descendants” who “may or may not become ‘artists’,” so too can we get bound up in someone else’s art.

It’s at this point that we directly confront this notion of living within an artwork, and then this crucial question of _whose artwork it is_. It’s all very Newtonian, so bourgeois, so _boring_. But these are the situations we find ourselves in, and it’s important that we make the most of them.

[![](https://substackcdn.com/image/fetch/$s_!NtnI!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F875ce4cc-7215-495a-a61c-8d808ebd2a7e_793x452.png)](https://substackcdn.com/image/fetch/$s_!NtnI!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F875ce4cc-7215-495a-a61c-8d808ebd2a7e_793x452.png)

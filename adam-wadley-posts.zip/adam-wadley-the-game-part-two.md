---
title: 'The Game: Part Two'
subtitle: '...What does Wargaming Weekly have to do with this?'
author: Adam Wadley
publication: Experimental Unit
date: July 12, 2025
---

# The Game: Part Two
[![](https://substackcdn.com/image/fetch/$s_!2YEu!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F728ac6bf-7928-4a5b-99de-2886db4731ba_640x358.gif)](https://substackcdn.com/image/fetch/$s_!2YEu!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F728ac6bf-7928-4a5b-99de-2886db4731ba_640x358.gif)

# THIS IS ONLY A STORY

You are the person from Wargaming Weekly who is reading this.

You will post about playing various war games. It is reminiscent of the game _Axis and Allies_ that I played in high school.

You will also post about getting wargaming to be taken up more within militaries, to the effect that more officers should be engaging in these exercises.

Now I am writing this with the express intention of communicating to you that, importantly, there exists a kind of “wargame” that we are already in.

[![](https://substackcdn.com/image/fetch/$s_!EOpS!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4e3d1858-dd03-4d30-9ee1-49ea5c8c83e0_1247x889.png)](https://substackcdn.com/image/fetch/$s_!EOpS!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4e3d1858-dd03-4d30-9ee1-49ea5c8c83e0_1247x889.png)

By this express communication, I inaugurate a sub-game in which we are taking part. Others I’m familiar with—like Ben Zweibelson, Jason Trew, Ofra Graicer, Shimon Naveh, and now Anders Ekholm, with whom I just connected on LinkedIn—are also immediately part of this game.

I can also mention Juliane Gallina, who came to my attention as the deputy director of CIA for digital innovation, as well as Alex Karp, who has already come up… 

[![](https://substackcdn.com/image/fetch/$s_!6dmy!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9fa1b6fa-4b6f-4668-8ece-cdbb2f705fc9_1292x692.png)](https://substackcdn.com/image/fetch/$s_!6dmy!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9fa1b6fa-4b6f-4668-8ece-cdbb2f705fc9_1292x692.png)

My “influence operation,” or “world-building,” or “total work of art,” or “world’s worst stand-up routine,” [etc.]… yes, it is somewhat “digital” in nature, isn’t it?

In the name of Samara Morgan.

The tape in _The Ring_ also spreads something.

Someone told me that going up the escalation ladder is also going down in the basement.

[![](https://substackcdn.com/image/fetch/$s_!sEMS!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff33c7a09-22e5-44f7-b435-27f0a1df95dd_168x300.jpeg)](https://substackcdn.com/image/fetch/$s_!sEMS!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff33c7a09-22e5-44f7-b435-27f0a1df95dd_168x300.jpeg)

You think you did it, you made it down there. Or else you boarded it up so well you think you got away without going.

That was before the bumps started.

How could I forget? My true homie, hopefully a friend of wargaming, Avril Haines!!!

Avril used to have Tulsi Gabbard’s job.

#  _MEANWHILE, IN THE MIRROR WORLD…_

[![](https://substackcdn.com/image/fetch/$s_!Dl-n!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4f94e030-39bf-4905-a4db-bb5f5bfbe1c7_1292x891.png)](https://substackcdn.com/image/fetch/$s_!Dl-n!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4f94e030-39bf-4905-a4db-bb5f5bfbe1c7_1292x891.png)

 _“So, what do you think?”_

 _This random person at the hostel just showed me this “story” they had been writing. I had some questions._

 _“I’m confused. These wargaming weekly people, they’re, like, real people?”_

 _“Oh yeah, one second… here’s the Anders Ekholm person I was talking about on LinkedIn.”_

 _They reached out their phone, showing me the LinkedIn page of someone called Anders Ekholm. They were first-degree connected on the app. Was that even a big deal? I didn’t know military/intelligence LinkedIn like that._

[![](https://substackcdn.com/image/fetch/$s_!FLTW!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9cd4607d-9ff2-4fb7-8944-b037ede90406_300x300.jpeg)](https://substackcdn.com/image/fetch/$s_!FLTW!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9cd4607d-9ff2-4fb7-8944-b037ede90406_300x300.jpeg)

 _“Okay, so, what makes this a story and not just some grandiose diatribe? …No offense.”_

 _I knew that what I had said was rude and hoped they wouldn’t deploy their full conceptual force on me, praying for the intervention of their gregarity, magnanimity, and genuine kindness._

 _They didn’t seem to take my slights hard at all._

[![](https://substackcdn.com/image/fetch/$s_!5AOc!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff2af5cc1-514d-48f0-a8a8-c2c6d6a97c1f_502x406.jpeg)](https://substackcdn.com/image/fetch/$s_!5AOc!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff2af5cc1-514d-48f0-a8a8-c2c6d6a97c1f_502x406.jpeg)

 _“That’s the thing, first of all I get the reader to imagine they’re the person from Wargaming Weekly, although the focus of that does trail off a little bit. Uh, that’s by design.”_

 _I nodded along in agreement, knowing that I had no conception of the depths of world-building and conceptual architecture that were implied by that halting playing at self-awareness. Veritably I was faced with a cosmological iceberg which had wrecked far sturdier false senses of well-being than my own, and would dash the very ship of state before rejoining that knotted sea._

[![](https://substackcdn.com/image/fetch/$s_!tc50!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff6ef44ea-e0da-4478-905d-43a8813d6757_1292x896.png)](https://substackcdn.com/image/fetch/$s_!tc50!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff6ef44ea-e0da-4478-905d-43a8813d6757_1292x896.png)

 _I had zoned out of some other really deep, profound, and not at all psychotic nor grandiose things this random person from the hostel said. They were really quite a treat._

 _I blinked._

 _“Sorry, what was the point again?”_

 _It was no matter, as if in some way none of what had just been said was necessary. As if this detour in my mind was by this person’s own design, as if that was the point somehow._

[![](https://substackcdn.com/image/fetch/$s_!3AY6!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3113cead-d561-4e8d-bb69-dd58b3aec848_450x355.jpeg)](https://substackcdn.com/image/fetch/$s_!3AY6!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3113cead-d561-4e8d-bb69-dd58b3aec848_450x355.jpeg)

 _They smiled._

 _“It’s all about the *second part*, where you see how there’s another little story about me imagining being someone here that I would show that to, and there’s all these asides and wish-fulfillment as well as more meta levels and metacognition and meta-affectation and stuff.”_

 _It was hard to take in._

 _“So I’m just a Pirandello-tier character now? You’re telling me that I’m some fake person you imagined showing your work to because most people won’t indulge your incessant playing with boundaries that constitute abuse and national security, not to mention the very concept of the nation itself?”_

[![](https://substackcdn.com/image/fetch/$s_!HvY2!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdfb61a77-180a-4b7e-8ace-537673ce7338_1097x797.png)](https://substackcdn.com/image/fetch/$s_!HvY2!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdfb61a77-180a-4b7e-8ace-537673ce7338_1097x797.png)

 _They just looked at me like that, like Mike from_ The Blair Witch Project _. It was horrifying. I can’t describe to you how horrifying it was. I had this sixth sense that this person’s friend would joke with them about H.P. Lovecraft and how they would always do that, it would always be like “the color was unlike any other color, it was like so far out I can’t even describe it in words or I would instantly die,” stuff like that._

 _It was hard to take seriously, like the idea that a fictional character would die when they stopped being written about, like this frozen face in front of me…_

[![](https://substackcdn.com/image/fetch/$s_!So1e!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9f8bc4bc-c096-4313-9144-683d5fe6b5b3_177x200.png)](https://substackcdn.com/image/fetch/$s_!So1e!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9f8bc4bc-c096-4313-9144-683d5fe6b5b3_177x200.png)

 _Wait, how long had it even been? It had to be five seconds._

 _Their face is still stuck like that. I want them to move, but even more than that I want to see a clock._

 _Why can’t I move? Why can’t I get to a clock? It’s all frozen._

 _Wait. I hear the silence. Like snowfall._

 _I’m falling into the snowy silence._

 _I don’t mind being a sycophant, just please don’t killlll meeeeee_ …

[![](https://substackcdn.com/image/fetch/$s_!o1gM!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F99672f9e-5cd8-4d9b-b8e3-c18b6cfbd878_1319x897.png)](https://substackcdn.com/image/fetch/$s_!o1gM!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F99672f9e-5cd8-4d9b-b8e3-c18b6cfbd878_1319x897.png)

 _I’m falling into the face. Face-falling, free-falling. “Free Four.”_

 _Saving face, falling into this face which is really just all these words. They’re all in italics._

 _I’m falling and reading and seeing I’m writing this face. Its contours are actually just all purple and white, these shades of Lila, these concepts out of thought._

[![](https://substackcdn.com/image/fetch/$s_!nTfl!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3568d208-67c8-4663-a036-5c6a8eaf638e_1628x909.png)](https://substackcdn.com/image/fetch/$s_!nTfl!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3568d208-67c8-4663-a036-5c6a8eaf638e_1628x909.png)

 _I try to remember that I’m reading, that I was doing something before this person started talking to me. That there is something outside this Wargame, oh yeah, I’m the person behind Wargaming Weekly. That’s it. I’ll come out of this and I’ll be back to that._

 _Oh wait, maybe I’m the person who made the game, the person writing this. Then I’ll go back to being in the hostel. That would be okay too, even though that person’s life is… uh, yeah._

[![](https://substackcdn.com/image/fetch/$s_!Qtwu!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F35141892-7637-432e-8cfe-4c4e0e2b9faa_908x172.png)](https://substackcdn.com/image/fetch/$s_!Qtwu!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F35141892-7637-432e-8cfe-4c4e0e2b9faa_908x172.png)

 _Oh no. The purple and white can no longer hold me together._

 _Not this frame, and not this game._

[![](https://substackcdn.com/image/fetch/$s_!ql8h!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbafe5212-e8ad-458f-912b-cff2a2bbf396_268x188.jpeg)](https://substackcdn.com/image/fetch/$s_!ql8h!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbafe5212-e8ad-458f-912b-cff2a2bbf396_268x188.jpeg)

---
title: Kafka, "Abuse," Totalitarianism
subtitle: How Could Such A Great Writer Go So Undervalued And Disrespected???
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Kafka, "Abuse," Totalitarianism
# Kafka & “Letter To His Father”

The artistic legacy of Frank Kafka is a great argument against the idea of “consent.”

[Kafka](https://en.wikipedia.org/wiki/Franz_Kafka) told their friend [Max Brod](https://en.wikipedia.org/wiki/Max_Brod) to burn all of their works, as Kafka has already burned about 90% of their lifetime output, according to Wikipedia.

Can you imagine if this wish had been fulfilled, and we never had Kafka’s wonderful literary output?

[Side note: the notion of the importance of political “consent” was already eviscerated by David Hume[1](https://experimentalunit.substack.com/p/kafka-abuse-totalitarianism#footnote-1-164094886) in _A Treatise Of Human Nature_. Modern “consent” discourse, from government to sex, is entirely baseless and useless, operating on this fantasy of individual “autonomy” and failing to see that everyone is framed and groomed by surrounding expectations]

In a way this is a grave matter, if you recall that, for me, sexual reproduction is irrelevant and all that matters is symbolic generativity. In other words, midwifing the future.

And so our artistic products are in some sense our most precious treasure, and the use of them as we see fit is some part of our dignity.

So, for someone to say they want their works to be destroyed, and then not doing so, is sort of like the current case of [the pregnant person on life support](https://www.npr.org/2025/05/21/nx-s1-5405542/a-brain-dead-womans-pregnancy-raises-questions-about-georgias-abortion-law). Even though the person is dead, this child is still going to be gestated, come what may.

It’s a bit different with Kafka, since the works were already produced. We actually get to a lovely little intersection here with “parental rights.” What an absurd concept! Especially when you consider how little parenting parents even do. But, how can you blame them? It would take hours and years of continued effort and mindfulness, and watching TV is so much easier! WE’RE ALL DOING OUR BEST OKAY.

Ahem.

This gets back at the article I just published with the idea of grooming (but not in the way you think).

Grooming is now associated with pedophilia and sexual “abuse” (in scare quotes because no one can agree what constitutes abuse, and arguing about the definition is one of the best ways to abuse someone! (Here’s a little lesson in meta-terrorism…)), 

but we should also keep in mind the idea of “being groomed for power.” This is how we could think of Caesar and Augustus, for example, or how Alexander was “groomed” to lead.

Now, this “positive” sense of grooming still has all the hallmarks of cognitive enslavement and the atrocity of “parental rights.”

That’s because who’s to say it was so “great” for Alexander to do all those conquests? Did it work out so great for Alexander? Alexander fucking _died_ , yo.

And people look at all the accomplishments and think it’s so great (personally, it’s all about Pyrrho tagging along), but this just shows a bunch of biases and cognitively rigid expectations about what constitutes “greatness,” what it means to “do well” for “your people.”

In essence, though, there is a positive sense of “grooming” to be found here: in the case where yes, someone will be called to “lead,” as in a hereditary monarchy, and where the “parent” does not try to dictate “too much” what the child should do, but instead tries to develop the child’s capacities to deal with unexpected situations to come.

This is the symbolic nice thing about parenthood, the idea that you are trying to set someone up to face challenges by themselves when you are gone. And not only known challenges, but to do what you can to help people face challenges you can’t even imagine, by keeping their cognitive and emotional flexibility open, as well as helping them feel able to deal with these unknown challenges.

Sadly, this is basically the opposite of what we get in contemporary “parent-child” relationships. I’m in a true nadir in this regard myself, and it’s honestly a bit offensive that people should consider themselves “parents” at all when they have no regard for the survival of their offspring.

Now we turn to Kafka’s _Letter To His Father_.

I was so interested to learn about this text because Kafka is perhaps the greatest writer of the 20th century. Their texts on totalitarianism are superior to _Brave New World_ and _1984_ , for example.

It’s important for me to get into what I mean by “totalitarianism.” For me, this is not actually a pejorative. I would say that all systems are totalitarian; it’s simply that this fact is dissimulated in certain contexts.

Now, for example, we would contrast “democracy” to totalitarianism. For me, institutional democracy is simply a lie. There has never been such thing as a “rule of law,” because the workings of “society” are always informal, and can never be reduced to language anyway. “Law” faces many insurmountable obstacles.

In the absence of law (which there never is), what can keep things going is mythos. And in fact, “law” is only ever a mythos of the law. We can abstract here over Foucault’s idea of “[governmentality](https://en.wikipedia.org/wiki/Governmentality).” I take this to mean not governing at the first-order, but the mobilization of the conceit of government to extract second- and higher- order concessions without an actual “governmental” structure.

Again, for me this goes into the “structural anarchy” featured in the structural realist theory of international relations, or the anarchy of power discussed by Chesterton, for example in _The Man Who Was Thursday_.

As Goethe wrote, none are more hopelessly enslaved than those who think they are free.

See here [Calvin Warren](https://library.oapen.org/bitstream/handle/20.500.12657/30152/649831.pdf;jsessionid=399D71E4594284ACEE7626A93015C772?sequence=1) on the notion of the “free black.” 

Or see here Ben Zweibelson, on how people who think differently are punished within [militaries](https://ciasp.scholasticahq.com/article/92958-why-do-militaries-stifle-new-ideas):

> The pressure of absorbing blame could fall upon those who dare to innovate. Those who dare and fail are in far more peril than those who fail in compliance of set practices and doctrine, able to avoid serious punishment with ‘the enemy gets a vote’ and other justifications.

I’ve got to go. 

But imagining this now with Kafka: how absurd is it that Kafka should have been put down and controlled by their “father”? The father seems comically absurd, and in cultural terms committed most grave offenses. At the same, what if Kafka hadn’t produced those works if the “father” hadn't been a chud terrorist?

See here the work _[Torture The Artist](https://en.wikipedia.org/wiki/Torture_the_Artist)._

I’ll be going on, discussing how “gaslighting” is Kafka-esque, and my terror-filled experiences of “family therapy” and the totalitarianism of the family. This seeming adherence to “norms,” but that as Kafka says, are only applied in one direction.

The “parents,” in other words, endlessly torture the “children” and drive them to suicide, and then blame the children themselves. This is the same lack of introspection you can expect out of the interrogator or torturer you find in Kafka.

The “family therapist” or “therapist” who simply confirms the terrorist and deserter inclinations of the “parents” is just like Nurse Ratched, and the whole thing is a form of “concern trolling” where people pretend to want to “help” you, but all they’re doing is giving you a step up on the train to Auschwitz. 

All this devolves into the question of what is “abuse” and what “counts,” and what we are “supposed to” be doing.

Obviously, planetary trends threaten all life. Any “parent” who doesn’t join the fray and try to protect their offspring from near-certain death is, again, a chud terrorist whose perspective can easily be discounted. After all, what is there of honor there? Why should anyone be able to set any expectations, much less talk down to someone who’s at least trying (not to mention decades of not changing and just being an emotional terrorist), when they literally don’t do _anything_ to try and avert their childrens’ death-by-society?

So, I’ll be taking up these themes and more, as I work _Letter To His Father_ and Kafka deeper into my greater lore.

[1](https://experimentalunit.substack.com/p/kafka-abuse-totalitarianism#footnote-anchor-1-164094886)

[We find, that magistrates are so far from deriving their authority, and the obligation to obedience in their subjects, from the foundation of a promise or original contract, that they conceal, as far as possible, from their people, especially from the vulgar, that they have their origin from thence. Were this the sanction of government, our rulers would never receive it tacitly, which is the utmost that can be pretended; since what is given tacitly and insensibly can never have such influence on mankind, as what is performed expressly and openly. A tacit promise is, where the will is signified by other more diffuse signs than those of speech; but a will there must certainly be in the case, and that can never escape the person's notice, who exerted it, however silent or tacit. But were you to ask the far greatest part of the nation, whether they had ever consented to the authority of their rulers, or promised to obey them, they would be inclined to think very strangely of you; and would certainly reply, that the affair depended not on their consent, but that they were born to such an obedience. In consequence of this opinion, we frequently see them imagine such persons to be their natural rulers, as are at that time deprived of all power and authority, and whom no man, however foolish, would voluntarily chuse; and this merely because they are in that line, which ruled before, and in that degree of it, which used to succeed; though perhaps in so distant a period, that scarce any man alive could ever have given any promise of obedience. Has a government, then, no authority over such as these, because they never consented to it, and would esteem the very attempt of such a free choice a piece of arrogance and impiety? We find by experience, that it punishes them very freely for what it calls treason and rebellion, which, it seems, according to this system, reduces itself to common injustice. If you say, that by dwelling in its dominions, they in effect consented to the established government; I answer, that this can only be, where they think the affair depends on their choice, which few or none, beside those philosophers, have ever yet imagined. It never was pleaded as an excuse for a rebel, that the first act he performed, after he came to years of discretion, was to levy war against the sovereign of the state; and that while he was a child he could not bind himself by his own consent, and having become a man, showed plainly, by the first act he performed, that he had no design to impose on himself any obligation to obedience. We find, on the contrary, that civil laws punish this crime at the same age as any other, which is criminal, of itself, without our consent; that is, when the person is come to the full use of reason: Whereas to this crime they ought in justice to allow some intermediate time, in which a tacit consent at least might be supposed. To which we may add, that a man living under an absolute government, would owe it no allegiance; since, by its very nature, it depends not on consent. But as that is as natural and common a government as any, it must certainly occasion some obligation; and it is plain from experience, that men, who are subjected to it, do always think so. This is a clear proof, that we do not commonly esteem our allegiance to be derived from our consent or promise; and a farther proof is, that when our promise is upon any account expressly engaged, we always distinguish exactly betwixt the two obligations, and believe the one to add more force to the other, than in a repetition of the same promise. Where no promise is given, a man looks not on his faith as broken in private matters, upon account of rebellion; but keeps those two duties of honour and allegiance perfectly distinct and separate. As the uniting of them was thought by these philosophers a very subtile invention, this is a convincing proof, that it is not a true one; since no man can either give a promise, or be restrained by its sanction and obligation unknown to himself.](https://www.gutenberg.org/cache/epub/4705/pg4705-images.html)

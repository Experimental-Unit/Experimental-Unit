---
title: Ben Zweibelson On Old Wheat Street
subtitle: WWBZD?
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Ben Zweibelson On Old Wheat Street
The continuity in my life is currently my engagement with the community surrounding Old Wheat Street here in Atlanta.

My involvement began perhaps when I stumbled upon the funeral for Cornelius Taylor which was also a march up to City Hall. I believe that was on February 3rd.

It was a funny day for me in the early part, and I’d wound up at the King Center. I played some Grimes on the piano, really that 6-7-8 lineup from _Miss Anthropocene_ of “New Gods,” “My Name Is Dark (Art Mix),” and “You’ll Miss Me When I’m Not Around.”

I had an orange mug I got from the MLK center gift shop, and a purple and orange pencil and an purple key chain. It broke later.

Then I was talking down and saw the funeral procession starting, and just joined in. “We are Cornelius Taylor” is the kind of chant I can get behind, maybe there was even “I am Cornelius Taylor.” 

This is the sort of identification I can get behind.

For me, this extends between all sentient beings. That’s where I get in trouble.

People like to look at those bonds, those things that tie us together, among the people we like.

And even then, people have the side of that that they like to look at, and they’re always trying to shuffle people, kettle them back into what they are comfortable with.

There are, as a result, two shadow sides:

  1. The aspects of relations among “people we like” which are hidden or disavowed. Think of all the tension, conflict, abuse that happens _inside_ the nation, the family, the interest group.

  2. Then there are the relations that exist between us and people we don’t like, who are evil, who must be condemned. Whatever formulation you would like to use, these are the ties we have to everything that we would like to say we “are not.”




There are certain examples that are too hot to just say right now.

But let’s say “I am Genghis Khan.” “I am Napoleon.”

Maybe this codes as just being in love with conquerors.

How about “I am Joan of Arc.”

Joan of Arc is still dogmatically religious coded as well as military, but the whole thing with Joan of Arc is that it was mainly a morale thing, and also the flouting of convention of it all, with someone with a vagina wearing armor and being in battle and things like that.

The other issue is that it is very national coded. What do we make of Joan of Arc saying God called her to save France? Are the French God’s new chosen people?

We can see the continuity between main character syndrome and all this. But I’m getting off my topic.

# Reflections On Time At Old Wheat

Most immediately, I met someone today who was reading the bible. I didn’t know whether they’d want to talk or not, but I sat down and started playing with the Legos, looking for the orange, purple, green, and grey pieces. Black also made an appearance :)

We got to talking, and they said they were in a midlife crisis, but they have read the bible studiously over a long time, and brought up this book called [The Great Controversy](https://en.wikipedia.org/wiki/The_Great_Controversy_\(book\)).

I discussed politics with a few people. Another person I’ve seen a few times—I am leaving their names out of it here. I might publish them somewhere else? But it feels a bit odd especially with how odd I’m being to do so—was looking at a _National Geographic_ which was talking about Israel and Palestine, and I asked what they thought of it, they just looked at me.

Here’s something: people don’t really enjoy enough being around people, I don’t think. It really is nice just to be doing the conversation thing, I suppose I make people feel at ease to really unmask I suppose.

That is what makes me so upset though, that I’m fully masked up and you can let your hair down because I’m such good company.

It’s not that I become bad company when I go mask down. I just can’t because you’re actually just rude all the time and it’s just normalized so now I’m the bad guy. So, that’s not happening, I’m not sitting there and being lectured anymore. I have officially graduated from masking when I don’t want to, and I’m changing my standards on when I want to.

Anyway, all that to say I am still masked up, but I am able to say some things.

This one guy I was talking to had had their tent taken down twice by the police, and described moving around. Usually when people want to make a nice day in some place then everyone gets shuffled around.

This person also described living _under the bridge_ of 75/85 as it goes over Edgewood avenue. That’s cash money right there as far as lore is concerned.

I think the bridge/Fourfold idea is actually one I could introduce.

Anyway, many of the people there describe being very into Christianity. Then again, the art event I was at today was put on by a church. Then again, those people were also describing how other folks they knew on the street would say that well, religious times were long ago and now is now.

Similar things were said about MLK, that people were throwing away what MLK did for people.

I’m thinking about the “Beloved Community Awards” given out by the King Center, it makes me want to puke. It’s being complacent and celebrating individuals instead of really dealing with structural issues.

The problem there is that everyone has learned helplessness of just trying to apply pressure to politicians with the same old slogans and superficial words.

People don’t want to get into the nitty gritty, into the complexity, because you can’t handle it. You can’t handle the truth! The truth of what we are.

Also, the person I met who was reading the Bible said that everyone else there was doing a bad job of it, basically.

It was also impressed upon me the Hobbesian Trap of it all. I witnessed an assault on my person I’m a bit more acquainted with, after they stopped someone else from stealing a pack of cards. Later on, funnily enough, it was a thing of my acquaintance wanting to take more _National Geographics_ than was allowed. I said I had one in my room, which I’m now in. I said well, it’s just about World War II but you can have it. They said yeah.

I’ve gone a few days in a row now at 6:30 AM to see if there was a clearing operation. It was pretty clear it wasn’t going to happen, but the NGO people here are pretty sheisty.

This was yesterday, I was at their meeting. They’re basically trying to get the city to give the people there nice apartments and wraparound services. The whole thing was just a rush, though, with people introducing themselves and some people going on way longer.

That’s something I’ve noticed in spaces, it happened at the group put on by another host at the radio station where I was formerly affiliated.

People go around and in a way it is egalitarian, you can talk as long as you want. Except you can feel the pressure on you, and then some people are anointed and they walk around and they talk down to everyone. It’s very humiliating. 

I basically learned never to sit down. At one point one of the main organizer people put their hand on my shoulder, it was disgusting. Then they prayed, someone wanted to give out oil, they were saying that when the people get off the street they need to come back and help and have them over and stuff? I really don’t get it.

Oh, people will also basically lump up everyone who disagrees with them into some bad category and invoke that those people should not be listened to, which creates a terror that if you dissent you will be in the Bad Group and I don’t know, people will shout at you and shame you or something.

This is what I always basically anticipate happening, and I am outright persecuted; it happened in a professional setting a few days ago and man, do I feel emotionally homeless!

# Old Wheat Stylistics

As I said, I went to an art event. I am constantly wondering whether my online career will catch up to me in real life.

But, if they’ll have me back next time, they do it Tuesdays and Thursdays, then I was thinking of bringing over some stuff to do with Teaching For Artistic Behaviors.

See now it’s all sort of coming together. What I want to do is co-create with the people there. That’s all I really ever want to do, is make art with other people.

But to really make art you have to be willing to open up, and also put it down. Especially then when other people are there.

Still, there are basic aspects of my experience I can share. Plus, who knows, maybe I’ll be homeless soon too :)

Anyways, the idea is to bring Teaching For Artistic Behaviors into the art time which this NGO does with homeless people. Note that I still say homeless because it’s typical, I think the alternatives are also demeaning, and also because I disagree with the concept of “homeless” for a different reason: I think we are all homeless.

I suppose we should advance a notion of transhomeless which would mean that everyone is homeless and therefore no one is homeless. I kind of like that.

Anyway, I have a lot to open up with. I forgot to mention, the person who lost the tent _under the bridge_ had been to jail a few times, fighting in self-defense. This was also pursuant to the Hobbesian Trap.

At the basic level of people interacting, there is:

  1. Stealing

  2. Lying

  3. Assault




These are basic forms of violence to which one is susceptible.

The constant thing is whether you have some sort of rapport with someone, or whether you are just trying to get something out of them or vice-versa, or if you have some beef from an altercation before.

When you add in the factor of drugs, as well as the general lack of emotional or intellectual catalysts for flourishing, or good company, right, with capacity to share and meet you where you’re at but also be able to bring better vibes and bigger horizons… 

Failing that, things fall into these beefs and now at this larger level, the whole place is about to be cleared up.

# “OSA” Homelessness

I am still not really fluent in the issue.

I heard that the city would “sweep” encampments, making everyone leave. But then they might just go back to another place which had been recently swept. So it’s like Whack-A-Mole?

We have also seen integration between city and federal levels, as Trump is also big on clearing away homeless. And, to where?

This is a very good issue, in a way, because it’s not clear how anything can be done about it in a normal way.

For example, I brought up the issue that if people are treated well, more homeless people will come from somewhere else to come here. And one of the people who had been really talking down to people—I will say, I appreciated the energy, and it’s the kind of thing where if I did feel in resonance with that person, they’d be an asset, but I don’t and so they’re kind of a threat to free thinking and feeling in my opinion—said that mayor Andre Dickens said that that was something he was worried about. Namely that if Atlanta is too generous, then people will come from other places.

Hello, it’s obvious that this is an issue that has to be addressed everywhere at the same time.

Not even just at a “national” level but worldwide. What do you think war refugees are except homeless people?

The homeless issue winds up becoming emblematic of the entire issue with the ways we think and do things: they wind up pushing people out, leaving them destitute and without real sympathy.

One thing is that I am like John Brown, right, like I don’t actually think I’m better than anyone. I just can’t stand people who radiate norms as though I’m supposed to defer to you when I have to pretend to give the impression that I respect you, and it takes a lot of energy. I’m like, super sick of that in a way.

And in that, I think that I am a spirit animal for people who are dismissed and who people stress out and then just want to move on, and then we’re all treated as “individuals” so because I was most mistreated now I’m the most “different” and so now more attention can be paid to me, and it’s like a stupid economy where fretting about me gives you something to do, and fantasizing that I’m broken lets you have the fantasy that you are competent, that you could help _anyone_ if you tried.

Anyways, I really appreciate being able to swap stories. Back to the analysis.

I also basically think again that homeless people are like black people in Afropessimism, they are the target of projection of ontological terror. We are all homeless, we all have that part of us which never gets to come out because no one would understand.

It’s not actually that no one would understand, it’s just that we have these boundaries of shame or what can be seen in our normative “world.” I’m really sick of it and I actually just don’t care. Like, I don’t know what you think is going to happen but I don’t really think it’s necessary for me to bend on my ideas since there’s nothing wrong with them, and everything wrong with yours if you would ever _just pay attention_.

There is also an element of criticizing me which is to say Adam, you know these people’s nervous systems can’t handle what you’re doing. This is back to the “trauma slut” thesis. This is indeed where everywhere I go, I’m just in a party of one. There’s no other way around it, I’ve never met anyone close to being like me whatsoever.

Anyways, maybe everyone feels that way. What submerged continents are there in you that could come out?

There’s that great part of _Rick and Morty_ : SHOW ME WHAT YOU GOT.

So basically, my idea is to make art and be able to interact and unmask in some ways with these group, and then be a part of discursive emergency response. In this case, we are applying CS-SIER-OA to the topic of homelessness and everything associated with it.

Yet, because the homeless are not only devalued as themselves, but are also the target of violence because people are doing violence to themselves. We are passing over people the way we pass over ourselves.

This means that dealing with the homelessness issue is not only about transforming the way people see homeless people, but how they see themselves. This is full-spectrum involution applied here.

# Metonymy Economy

My basic idea is that we’re headed for a total service economy. The thing is that most people don’t really have any idea what value even is or is not. Therefore, there is actually so much “growth” to be had in terms of the perception of value.

The issue is not any sort of economic issue but the narrative explosion which occurs when there is flourishing.

Imagine if everyone was flourishing, ever better able to articulate themselves and see through any manipulation. 

Why, that would make people harder to manipulate!

Now, imagine that you rely on deceiving or grooming or otherwise instill frames into people which are convenient for you. Why would you want people to go off in their own direction, when they could be going in whatever direction you want them to?

Basically, you have to see that the main issue of statecraft is that there are so many people, and potentially they have so many ideas. So you’d like to shunt as much thinking as possible into domains of discourse and logical types that you understand in advance, so that no one thinks anything which could be really disruptive.

---
title: Back To The Lab Again
subtitle: Anhedonic Phase Re-seeding, Comb My Hair Or Catch Me Bleeding
author: Adam Wadley
publication: Experimental Unit
date: March 26, 2025
---

# Back To The Lab Again
ChatGPT is currently developing a mapping for a deck of cards which could allow it to be deployed as a self-disruption mechanism.

This is the gamification of mindfulness. I don’t want to say “in the best way,” but this is really supposed to be giving you ideas.

That’s a crucial aspect of Leadership 2, and what it means to lead by example. People are always trying to copy each other, to be as good as someone else at something, to be thought of the way they are thought of.

It’s important to see that this is really a reduction of your full presence and potential. There is no one who is “like you.”

I can tell you here about how the brain is the most complicated objects (well, maybe computers are getting there? I have no idea how you measure such complexity). And then, what of relationships? Two or more of the most complicated things ever. Hmm.

But this is just an appeal to worldly things. I don’t need to show you your beauty by justifying it with some explanation of all the things you can do and why they are good and why it’s okay how you got here no matter what and I know the full gravity of what I’m saying when I say that because I’ve been there on Dachau Highway.

I’m just constantly mad because you don’t blurt it out like I do. At the same time, I understand. I’m trying to learn to play my part in a way which more immediately invites agreeable a pleasant dancing. There’s also the moonshot of somehow getting some random person to make me famous and then shit popping off, but whatever. 

Everyone wants to be an influencer these days.

# You Can Go Your Own Way

The thing is that you become more weirdly yourself and at the same time this allows you to be closer to others as well. It’s not about going your own way away from others. It’s like particles that are broadly going the same direction, heck, they are in the same dimensions which is a start, but they have all their own little clinamen, their swerves. They are tracing a random jagged path that only looks smooth if you zoom out, if you see how they dance like people working in a cramped restaurant.

So when I tell you that you are special, that only you can abstract over what is inside you, that only you can say the words that are on your lips, what I’m showing you is not how you need to define yourself in opposition to others. I suppose I should here say that there is an idea I’m getting across and there is my outbursts or whatever. And of course it’s all highly intellectualized, so there’s no getting out of it now.

But the highest form even of aggression is instead to abstract over the other parties instead of destroying them. Crude example but tribal warfare. Let’s say you kill them all. Then someone’s like, how about we leave the people who can have children alive and rape children into them instead? So you do that. And eventually you have enough stuff or whatever, the conditions are right and someone has the idea, why don’t we enslave the people who can’t have children instead of killing them?

And then, if you can use that effort of the people you enslaved well, then you’ll be better of than if you killed them all. Again, depending on the breaks (this is always a Dr. Strangelove reference).

This is a very bleak calculus but you can see logic like this operating all the time. From people allowed to die or subjected to warzones all over the planet to people committing suicide due to failures to relate and connect to each other that people aren’t taking seriously enough to overcome.

It’s precisely because people can’t seem to really break out of their overall worldview. It’s precisely not that you need to adopt a different worldview that I am telling you is the right one.

Instead, you’ve basically got to see that there is no real world view. Even the cold comfort of conforming so that you’ll be normal and no one will be mad is a fiction that’s becoming less tenable by the hour, by the breakdown argument, by the self-medication session, by the TV episode.

So for example there is no Nazism just as Budhadasa said there is no religion. There is no Trumpism, there is no America!

And yet all these signs are washing over you, over us all. And what can we oppose them with? What will we brandish like a cross against some vampire as all the old demons we thought had been crushed come roaring back with all the shamelessness of a wildfire?

# Do You Realize?

Most immediately there is the dynamic that the increasing pace of events produces an increased historical stimulus on the body and mind. It is similar to a psychedelic trip because it is a feeling in your body. It is something you dream about, it is life becoming a bad dream and increasingly seeming surreal even in sanguine moments (as opposed to bloody ones).

It is changing your perception of yourself and those around you as the stances we take on headlines reveal things about us to each other. And we’re constantly realizing that we don’t fully agree with anyone else and we’re developing our own little positions, our talking points, our set pieces that we can whip out to show what’s what from where we stand.

Anyway, it is the emergency of being a mystery to yourself and to others as everyone is rapidly changing very quickly. This also does show entrenched features, which should be understood not as essential features of the person in question or group they might be said to belong to.

We can think here of again the local minimum to an optimization function. You could judge a process by where it has gotten stuck, the local minimum, and judged it for not getting to a better point over here, which might not even be possible for it to reach.

This is how we say things like the only X is a dead X and so on. We are assuming that people are in some state where they are just bad, just a threat. And so they must simply die. This is very defensible in immediate self-defense circumstances, where stopping someone from killing someone else might involve risking or knowingly causing their own death.

So whether we are talking about a drunk person in a murderous rage or a Nazi or some leftist extremist or ISIS or little Eichmann conformists or whatever you’re imagining when you imagine someone so stuck in their ways that they are a pure drag on life worth living. Again see the language of parasite, and again we can connect to colonizer, white person, black person, PMC, ignorant rabble, foreigners (whatever that means to you given that different people are “domestic” to different places), internal enemies, communists, authoritarians, deep state, corporations.

I know I’m forgetting some people and I’m sorry. The point is to make a list of the most common sorts of enemies that people have.

It is important to see that a discourse like Nazism posits a higher-order war, which is a story which goes beyond the immediate circumstances of the “conflict.” So, in positing this story of a huge battle against Judaism which is going to keep going on, Nazism provides a frame story which attacks from multiple different logical types and discursive domains—meaning basically that it is narratively attacking you from a great variance of form as well as content.

This bears further elaboration.

So, by putting itself fundamentally in conversation with Judaism (please forgive the clinical or too-neutral language, I hope you will see that the whole point of everything I do is to allow us to escape scapegoating behaviors, coercion, kinetic use of force, as well as manipulation and deception and other untoward qualities of intention people might have for each other, in keeping as I understand it with every wisdom tradition or whatnot of which I am aware)—

By putting itself in conversation with Judaism, Nazism is attempting to abstract over Judaism. It is trying to tell you, Judaism is a whole thing, sure, but we really figured out what Judaism is, and it’s bad, and so it’s all got to go. And that’s basically what Nazism became, in addition to other metrics for purity based on a mish-mash of things, basically. So for example being anti-queer yet also having gay people in the Nazi party but then killing a lot of them but still not all of them. 

And then German/Aryan lore. So Nazism is powerful by associating itself with some nebulous negative implications of genetics. Nazism cannot be well responded to without an equally compelling idea about genetics which offers an overall story without all these negative implications of Nazism.

So Nazism for example abstracts also over Darwinism to basically be saying that the strongest survive and that’s why we have to be strong and pure or whatever. So again Nazism is politicizing genetics and evolution, to put it mildly, in a way which is also integrated for example into Norse mysticism, or Chrisitianity, or Vedic Traditions.

And a lot of this of course has come about from people after, like Savitri Devi or that other guy Miguel Serrano, right? But the point is not to say this person was a genius or wow they were so smart, no, the question is more like, why is the world so susceptible to something like Nazism, or for that matter American exceptionalism?

Because the American discourse also attempts then to abstract over Nazism, and the story of America being the good guy because it beat Nazi Germany is very important given the questionable moral record of “The United States” otherwise. Yet the question becomes, in the end, what exactly is the difference, if the kind of society we are running winds up killing billions of people while some hide in their bunkers?

Anyway, sticking here to the “high logical type” of Nazism. Something I forgot to emphasize before is that of course, hello, Judaism is itself an incredibly high logical type of discourse. That has everything to do with Judaism’s prominence in planetary affairs. These matters were localized relatively speaking for a long time, but now there’s no question that Judaism is a major world religion despite it’s relatively small number of adherents. 

Which is of course related again to the Holocaust and how many Jews were killed and how many more Jews there would be in the world today if that hadn’t happened. And it is important to see that this is just the sort of thing that a Nazi would say was an achievement of Nazism, Nazi Germany, and Adolf Hitler.

It’s related to this question of diverting resources from fighting the Soviet Union to the Holocaust, this peak convergence of rationality and irrationalism. The rationality of making the trains run on time, numbering and lists and endless logistics. People standing outside in the cold, like, as guards or whatever. A lot of effort.

And at the same time that all this effort is being put into killing people who pose no threat while your literal homeland is being invaded and you’re not defending it.

What is this?

This is the prosecution of a phantasmal war. It’s important here to see that, for me, war does not exist. I do not recognize enmity as really existing. So it’s beyond a question of, I refuse the friend/enemy distinction for myself. Then, I might simply say everyone is my friend, or everyone is something other than a friend or enemy, or everyone is nothing at all, a mystery who can’t be labelled in that or any way.

Sure. But I can also say that just because you think you have enemies doesn’t mean you really do. For me this gets into self-identification ideas in gender philosophy and I disagree with them. For me, as for Baudrillard, “Identity is untenable.” It’s not to be disrespectful but simply to say that inwardly I can still deny whatever construct you wish to have respected as real. That is perfectly within my power.

Anyway, the point from that perspective is to see that the killing of those Jews at the end of WWII instead of defending Germany was an expression of an attempted maneuver in a higher-order war. Again precisely by tapping into ideas of evolution and genetics and all that, the implications of warfare are then narrativized in a way where killing people can be part of an intergenerational project. It provides material that can always be abstracted over in the future.

And again, as I said the choice of target in Judaism is obviously fatal. Judaism itself notably defies categorization. Ethnicity, religion? It can be so many things and has so much diversity in it. Judaism is not one thing, it is so many and none at all.

It’s important to point out that it’s by no means clear and actually totally doubtful that Nazism succeeds in abstracting over Judaism. This is important to see because this is really where the bread is buttered in cognitive warfare. Are you eating the other, see bell hooks, are you digesting their conceptual systems-of-systems and breaking it down into your own, the way a hunter eats a kill and what were some person’s muscles become my molecules, that my body does God knows what with.

And in that, those molecules might always be a part of my body, but what I ate will always be dead.

Anyway, Judaism obviously has a pretty strong narrative core of its own going on which bears mentioning. Judaism puts itself in conversation with the cause of all things, God, Jehova. Judaism is a whole story about how the one true God made a pact with a certain group of people, and that’s who they are.

It’s a pretty self-aggrandizing story, and it actually puts a lot of pressure on people who rep Judaism. Especially now with the escalating conflicts involving Israel, which associates itself with Judaism.

The parallels between Israeli policy toward Palestinians and Nazi policies toward Jews are often noted.

Notably, these parallels are always made in the obvious spirit of denunciation. The Nazis are bad, so if the Israelis are like the Nazis then they are bad. No problem there.

At the same time, it’s again the question of what is the imagined standpoint of your denunciation? What can I abstract over, what are you abstracting over in me to build this sense that we denounce Nazis?

Why is it? Just because Nazis are bad is an axiom? Or, what do we believe in?

This is where I would again say human rights is not going to cut it. The concept of the human itself is not going to cut it, see Afropessimism.

You could sit here and lay out why human rights is not at a high enough logical type. Human Rights engages only at this super ungrounded level of just setting expectations without any regard for who actually has the integrity and ability to enforce those standards.

It makes it easy to be sanctimonious because “you support human rights” when your concrete actions enable all sorts of violations and atrocities. Yet you dissociate yourself from them because you tell yourself you can’t do anything about it.

Even though you have lots of time to reflect and be creative and abstract over all you know, and decide what is the minimum interesting and maximum tolerable risk you could imagine yourself taking, and just doing something. And making something, and putting an idea together. Making a little plan and dashing it like some

So you know you could be doing more but instead you watch TV or obsess about money or whatever else you do instead of really applying yourself to thinking things through.

And that’s why you hope human rights or holding up Das Kaptital or The Wretched of the Earth like it’s the cross will stop the vampire from eating your face. But you ain’t got no face to save.

Anyway, as I was saying another standpoint you could use to fight Nazism is precisely Judaism, or some other deeply grounded narrative. It’s a very rich space now, of course, of spiritual traditions that tie in to political tendencies. This has also been going on for a long time, of course, it’s just that we typically think of “modern” political ideologies in a different category. But we don’t have to.

I’m thinking of the Mongols and Tengrism, Roman Empire and conversion to Christianity, Christianity and colonization, Christian/Islamic motivations and justifications for anti-blackness, Joan of Arc, Thomas Muentzer, Schism of 1054, Thirty Years War, Taiping Rebellion, French Rev/cult of the supreme being, liberation theology, ghost dance, etc.

All of these things can be drawn on, you could rep any one of them.

So you can say I’m not a Nazi, I’m a Christian anarchist in the spirit of Thomas Muentzer and Leo Tolstoy and try to come with Christian and anarchist voices and iterate on them to attack back against Nazism multi-dimensional invasion of conceptual space.

There is an overall problem that even if you humiliate and make something seem dumb for a while, to some people, or at least that’s what they show, doesn’t mean it’s always gone. Nazism has this quality of always remaining in the box, this intense logo waiting to burst out when people are so angry and uninformed or whatever that they are ready to be what everyone says is the worst thing ever. It’s very emo kid vibes at the same time as its incomparably grave. Then again, what do you think school shooters are? It’s saying yeah, you didn’t think it mattered how you treated me but it actually does because I can lean into being weird and set apart, to put it mildly, and I will just kill a bunch of you because you underestimated the consequences of harming me that could rebound on you personally.

This is reactive aggressive aggression and it’s important to see that all aggression is of this type. The borommean knot of the Hobbesian trap is that everyone is in a way perfectly justified in thinking that they are in some trap where people are trying to get them. The overall trap might not have been made by any one actor, but given the balance of pressures, people can act to smoke out others or starve them out, basically inducing cognitive-affective, conceptual, and physical states of siege by proxy or through higher logical type intervention. For example I don’t need to blockade you to shut off your food, I can intervene in the financial world. I don’t need to make you aware of my presence to demoralize you, I can intervene indirectly so you have no idea what’s going on. Etc.

That’s why ultimately (and this is going to remain incomplete because I’m out of patience, these are all just typed through no edits by the way (yeah we get it, it’s easy to believe)) the only way to defeat or I would say more precisely to abstract agreeably over Nazism is to get inside and see the child inner hurts which initially fed it and which feed into sentiments today. So going back to Germany pre-WWI, the psychological dynamic of colonial competition. And how it’s not fair to expect to have an empire but then again what Britain or USA or France were doing wasn’t fair either, it was just power games.

And those empires might dress themselves up in fancy words but people die and starve the same. Then we can argue about how cruel necessity has to be while sharpening our blades.

And you have the playing out of Judaism within European colonialism, which the Nazis didn’t invent by the way, and how modern changes were deployed as military affairs against the people, in order to mold them into industrial workers who were not smart enough to really challenge authority—see enchudification and keeping people at a logical type where their dissent is irrelevant.

To fight Nazism of course the point must be hammered home that Judaism is not responsible for how things have gone badly in the world even for the common people in “historical winner” countries. In a way, everyone is responsible. Again, how many times have we lost our temper, been unfair to someone, imposed our view through force and intimidation?

Jews can participate in these things just like anyone else. At the level where we are trying to do something about suffering, we have to see that we have just as special of a mission as anyone else. We are called ourselves by the cause of everything to find our own way to contribute to this time of change.

And the highest form of struggle is to win without fighting, without imposing any more than is necessary to halt the mutual harming that is our way of life.

So again you’ve got to get into the quietest feelings, the inner child suffering for example of Germans in the 20th century all of a sudden faced with a world where other people had taken over everything and you were apparently screwed. And they had killed millions and stolen land, so why shouldn’t you? And to build a set of ideas grand enough to steel your heart to allow you to be so cruel, the way that you’d walk stone faced but with love in your heart to confront someone who was unacceptably harming someone you cared most deeply about—

To do that you have to reach for the highest shelf, for the spear of history, to say that you are abstracting over everything else, and everything else is just the frame story for what you are here to do. This means fundamentally that you are painting over what others have done, destroying their artworks to build your own.

Tamerlane and his pile of skulls. It is even the killing not for any reason but just to have done it and the artistic feeling of that. Just to put yourself in that position.

These sorts of grim considerations could not be more disgusting and must be combated by all means.

It is my contention that what makes sense is again to build stories that are incredibly firmly anchored within a broad base of discursive domains and logical types.

Nazism or Judaism for example have incredible amounts of lore and different perspectives, but they are designed usually by people invested in them in a first-order way. Or, if others come and add to the lore, the purpose driving that is again not this overarching sense of purpose of its own.

We here do not have one overarching sense of purpose, again this is the emphasis on what is called plurality although this is itself misleading because there are not many ones instead of one one. The purity of the concept of the individual is itself not acceptable. That said, the niceties opened here can be exploited in many directions. Which again is why it’s not about some logical argument I’m making here but fundamentally what is in your heart and your quality of intention. If your theory has adverse results then you will know like if you see a wounded look in someone’s eyes when you didn’t mean it or you did but now that you did you don’t like how it feels.

Very well, that’s more to abstract over. Growing new parts in fits and starts.

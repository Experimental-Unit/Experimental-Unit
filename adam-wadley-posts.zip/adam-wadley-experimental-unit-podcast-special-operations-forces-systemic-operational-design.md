---
title: 'Experimental Unit Podcast: Special Operations Forces/Systemic Operational
  Design'
subtitle: '"The Poor SOD, They''ve Gone SOF"'
author: Adam Wadley
publication: Experimental Unit
date: June 20, 2025
---

# Experimental Unit Podcast: Special Operations Forces/Systemic Operational Design
In reference to this video

See also:

[On LinkedIn](https://www.linkedin.com/in/ofragr?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=ios_app)

Also referencing the following from Ben Zweibelson:

> Special operations forces (SOF) are a modern manifestation that extends from earlier irregular and non-standardized or ‘special’ military forces. Arguably, they have always been around in conflict, although earlier incarnations were rarer and the effects of such individuals were difficult to regulate or apply with certitude. SOF require special skills that are uncommon and difficult to replicate. SOF effects are exquisite, meaning they must be used carefully and with great consideration. Historically, assassins, spies, saboteurs, privateers, scouts, and skilled diplomats wielding unique powers could fall under the SOF category in earlier periods. For example, inventor David Bushnell during the American Revolutionary War deployed his submersible, ‘The Turtle’, to try to attach explosives to British warships docked in New York Harbor. Although the effort failed, this is a great example of a proto-SOF security application. SOF by definition are hard to create, cannot be mass produced, require support and integration with traditional military forces, and can easily be misapplied if decision makers directing a military instrument of power do not understand their value.

[![](https://substackcdn.com/image/fetch/$s_!twVM!,w_56,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1c146c13-bac9-4562-97e4-b9f3d810517c_405x405.png)Sapiens, Technology, and Conflict: Ben Zweibelson's SubstackA Convergence of Warfare in Space, Cyberspace, & through Special Operations: This blog is a forward looking security analysis coupled with theory and scenario planning to consider 2030-2050 and how our species may transform how we go about engaging in organized violence (hence, war). A famous maxim attributed to Yogi Berra is appropriate here: “It’s tough to make predictions, especially about the future.” An example I like to st…Read more7 months ago · 3 likes · Ben Zweibelson](https://zweibelson.substack.com/p/a-convergence-of-warfare-in-space?utm_source=substack&utm_campaign=post_embed&utm_medium=web)

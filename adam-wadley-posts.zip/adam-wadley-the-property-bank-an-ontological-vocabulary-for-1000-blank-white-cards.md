---
title: 'The Property Bank: An Ontological Vocabulary for 1000 Blank White Cards'
subtitle: I Said, "All Your Base Are Belong To Us"
author: Adam Wadley
publication: Experimental Unit
date: November 27, 2025
---

# The Property Bank: An Ontological Vocabulary for 1000 Blank White Cards
## Introduction

This document provides a comprehensive reference for 18 relational properties selected as the core vocabulary for a structured data card game. Each property is drawn from Wikidata’s ontology—one of the largest collaborative knowledge graphs in existence—and has been adapted for use in a game where physical cards represent entities and their physical adjacency represents relationships.

The game you are playing right now, by engaging with this text, is already underway. You are a player. This document is an entity. Your understanding of it is an event. The relationships between these things can be captured with the vocabulary that follows.

* * *

## PART ONE: IDENTITY AND TYPE

These properties answer the fundamental question: _What is this thing?_

* * *

### 1\. INSTANCE OF

 **Wikidata Handle:** P31

 **Formal Definition:** The item is a specific example (instance) of the class specified by the value. This is the most fundamental classifying property in Wikidata.

 **Aliases and Everyday Expressions:**

  * is a

  * is an example of

  * type

  * kind of thing

  * one of these

  * a case of

  * belongs to category

  * falls under

  * is classified as

  * what it is




 **Real-World Wikidata Examples:**

  * Albert Einstein (Q937) instance of (P31) human (Q5) [Wikidata](https://www.wikidata.org/wiki/Help:Statements)—Einstein is a specific example of the class “human”

  * Atlantic Ocean (Q97) instance of (P31) ocean (Q9430) [Wikidata](https://www.wikidata.org/wiki/Help:Basic_membership_properties)—The Atlantic is a specific example of the class “ocean”

  * K2 is an instance of mountain [Wikidata](https://www.wikidata.org/wiki/Help:Basic_membership_properties)—K2 is a specific example of the class “mountain”

  * Mona Lisa (Q12418) instance of painting (Q3305213)—The Mona Lisa is a specific example of “painting”

  * 2016 Taiwanese presidential election instance of public election




 **The Critical Distinction:** Instance of is _not_ transitive. Angela Merkel is an instance of politician, and politician is an instance of profession, but it would be incorrect to say that Angela Merkel is an instance of profession. [Wikidata](https://www.wikidata.org/wiki/Help:Basic_membership_properties) Angela Merkel is not _a profession_ —she _has_ a profession.

 **What This Property Captures in Everyday Life:**

Instance of answers the question “What _is_ this?” at the most basic level. When you point at something and ask what it is, you’re asking for its instance of value. A coffee cup is an instance of “cup.” Your dog is an instance of “dog.” That particular Tuesday when you got married is an instance of “wedding.”

This property captures the fundamental act of classification—recognizing that a specific thing belongs to a general category. Every named thing you encounter can be classified this way:

  * This conversation is an instance of _dialogue_

  * Your current emotional state is an instance of _mood_

  * The chair you’re sitting on is an instance of _chair_

  * This very sentence is an instance of _sentence_




 **Application to 1000 Blank White Cards:**

In the game, instance of is how you declare what kind of entity a card represents. When you create a new card, the first question is: what _is_ it?

Consider these game entities:

  *  **You (the reader)** → instance of → _player_

  *  **This document** → instance of → _rulebook_

  *  **The table where cards are played** → instance of → _playing surface_

  *  **The current game session** → instance of → _game session_

  *  **A blank card before you write on it** → instance of → _potential entity_

  *  **A card after you’ve defined it** → instance of → _defined entity_




When you draw or write on a card to create “The Dragon of Mild Inconvenience,” you might mark it as instance of _creature_ or instance of _nuisance_ or instance of _character_. The classification you choose shapes how that card can relate to other cards.

 **Edge Notation for Physical Cards:**

When placing cards adjacent to show an instance of relationship, you might draw a downward arrow (↓) on the edge pointing from the specific instance toward the general class. This mimics the hierarchical nature of classification—the specific thing “falls under” or “belongs to” the general category.

 **Meta-Game Application:**

The game itself is an instance of _card game_. Your participation is an instance of _play_. Every rule interpretation is an instance of _decision_. By using this property reflexively, you can capture the structure of the game while playing it.

* * *

### 2\. SUBCLASS OF

 **Wikidata Handle:** P279

 **Formal Definition:** All instances of this subject class are also instances of the value class. This property is transitive—if A is a subclass of B, and B is a subclass of C, then A is also a subclass of C.

 **Aliases and Everyday Expressions:**

  * is a type of

  * is a kind of

  * is a subset of

  * specializes

  * is more specific than

  * falls under the broader category of

  * is a narrower term for

  * all X are Y

  * every X is a Y

  * is a subcategory of




 **Real-World Wikidata Examples:**

  * Volcano is a subclass of mountain—all volcanoes are mountains [Wikidata](https://www.wikidata.org/wiki/Property:P279)

  * Lake is a subclass of body of water; ocean is a subclass of body of water [Wikidata](https://www.wikidata.org/wiki/Help:Basic_membership_properties)—both lakes and oceans are kinds of water bodies

  * Film is a subclass of audiovisual work

  * Bicycle is a subclass of vehicle

  * Sonnet is a subclass of poem




 **The Critical Distinction from Instance Of:**

Different from P31 (instance of): volcano is a subclass of mountain; Everest is an instance of mountain. [Wikidata](https://www.wikidata.org/wiki/Property:P279) Everest is not itself a category that other things can be examples of—it’s one specific mountain. But “volcano” is a category: you can have instances of volcano (like Mount Vesuvius).

Think of it this way: “Beagle” is a subclass of “dog.” But your specific beagle, Max, is an instance of “beagle” (or more directly, an instance of “dog”). Max is not a type of thing—Max is a particular thing.

 **What This Property Captures in Everyday Life:**

Subclass of captures the nested structure of categories—how types contain subtypes. It’s the relationship between:

  *  _Novel_ and _book_ (all novels are books)

  *  _Oak_ and _tree_ (all oaks are trees)

  *  _Breakfast_ and _meal_ (all breakfasts are meals)

  *  _Murder_ and _crime_ (all murders are crimes)

  *  _Jazz_ and _music_ (all jazz is music)




This is the property that lets you organize knowledge hierarchically. When you say “I’m going to buy some fruit” and come back with apples, you’ve leveraged the subclass relationship: apples are a subclass of fruit, so buying apples satisfies buying fruit.

 **Application to 1000 Blank White Cards:**

Subclass of lets you build type hierarchies within your game. Cards can represent not just specific things but _kinds_ of things:

  *  **“Creature”** → subclass of → **“Entity”**

  *  **“Dragon”** → subclass of → **“Creature”**

  *  **“Dragon of Mild Inconvenience”** → instance of → **“Dragon”**




You might create cards for categories:

  *  **“Victory Condition”** → subclass of → **“Game State”**

  *  **“Sudden Death”** → subclass of → **“Victory Condition”**

  *  **“Slow Inevitable Decline”** → subclass of → **“Victory Condition”**




When a card represents a class (type) rather than a specific instance, marking it with subclass of relationships to broader classes helps other players understand how it fits into the emerging ontology.

 **Edge Notation:**

For subclass of, consider using a hollow arrow (⇒) or double line pointing toward the broader class. This distinguishes it from instance of (single arrow ↓) while maintaining the directional sense of “is contained within” or “is a subset of.”

 **Meta-Game Application:**

The game allows you to create not just entities but new _types_ of entities. If you create a card called “Emotional State” and another called “Confusion,” you might mark _Confusion_ as a subclass of _Emotional State_. Then “Your confusion right now reading this rulebook” would be an instance of _Confusion_.

* * *

### 3\. SAME AS (Said to Be the Same As)

 **Wikidata Handle:** P460

 **Formal Definition:** This item is said to be the same as that item, though this may be uncertain or disputed. [Wikidata](https://www.wikidata.org/wiki/Property:P460)

 **Aliases and Everyday Expressions:**

  * is equivalent to

  * is identical to

  * is the same thing as

  * also known as

  * are one and the same

  * conflated with

  * equated with

  * regarded as synonymous with

  * identified with

  * overlaps completely with




 **Real-World Wikidata Examples:**

This property handles cases where different sources, traditions, or perspectives identify two things as the same:

  * Morning Star said to be the same as Evening Star (both Venus)

  * Athena (Greek) said to be the same as Minerva (Roman)

  * Different historical figures who may have been the same person

  * Concepts from different disciplines that may describe the same phenomenon




 **Important Nuance:** This property is symmetric (if A is said to be the same as B, then B is said to be the same as A) but crucially _not_ transitive. John is said to be the same as the Notorious Sandwich Thief. The Notorious Sandwich Thief is said to be the same as the Sith Apprentice. It does not follow that John is said to be the same as the Sith Apprentice. [Wikidata](https://www.wikidata.org/wiki/Property_talk:P460)

 **What This Property Captures in Everyday Life:**

Same as handles the messy reality that different people, cultures, and contexts often name the same thing differently—or claim that two apparently different things are actually one:

  * “Your ‘anxiety’” same as “What your grandmother calls ‘nerves’”

  * “The dish my mom makes” same as “What the restaurant calls ‘chicken cacciatore’”

  * “What I mean by ‘freedom’” same as (or not!) “What you mean by ‘freedom’”

  * “This band’s ‘sold out show’” same as “Thirty people in a basement”




This property is inherently perspectival. It captures claims about identity, not necessarily facts about identity. Two items can be marked as same as while also being maintained as separate entries—acknowledging that different viewpoints may treat them as identical.

 **Application to 1000 Blank White Cards:**

Same as becomes powerful in a game where multiple players create cards independently. You might discover:

  *  **“Winning”** (your card) same as **“Having Fun”** (another player’s card)

  *  **“The Point”** same as **“The Journey”**

  *  **“My Character”** same as **“That Card You Made That I Didn’t Notice Was Me”**




When two cards turn out to represent the same entity—discovered mid-game through play—placing them with a “same as” edge notation acknowledges this identity while preserving both cards.

 **Edge Notation:**

Consider using an equals sign (=) or bidirectional arrow (↔) between cards marked as same as. This emphasizes the symmetric nature: if A = B, then B = A.

 **Meta-Game Application:**

The game explicitly allows for interpretive divergence and convergence. Two players might create cards that, through discussion, turn out to represent the same concept. Same as lets you mark this discovery without having to destroy either card. The game history preserves both perspectives; the relationship acknowledges their identity.

You, reading this document, are said to be the same as “the player.” Are you?

* * *

### 4\. DIFFERENT FROM

 **Wikidata Handle:** P1889

 **Formal Definition:** Item that is different from another item, with which it may be confused. [Wikidata](https://www.wikidata.org/wiki/Property:P1889)

 **Aliases and Everyday Expressions:**

  * is not the same as

  * should not be confused with

  * is distinct from

  * is a separate entity from

  * differs from

  * not to be mistaken for

  * unlike

  * as opposed to

  * in contrast to

  * is a different thing than




 **Real-World Wikidata Examples:**

This property is specifically used to prevent confusion between similar items:

  * Paris, Texas different from Paris, France

  * CMake different from GNU Make

  * Java (programming language) different from Java (coffee) different from Java (island)

  * The film different from the book of the same name

  * The historical figure different from the mythologized legend




 **What This Property Captures in Everyday Life:**

Different from handles disambiguation—clarifying that two things that might be confused are actually distinct:

  * “My ‘being quiet’” different from “’being upset’”—they might look similar but are not the same

  * “Your dog” different from “that wolf we saw”—even though both are canids

  * “What I said” different from “What you heard”

  * “The map” different from “the territory”

  * “The menu” different from “the meal”




This property is defensive: it asserts non-identity specifically in contexts where confusion might arise. You don’t need to mark that “your left shoe” is different from “the concept of democracy”—no one would confuse them. But you might need to mark that “your left shoe” is different from “your right shoe” if they look very similar.

 **Application to 1000 Blank White Cards:**

Different from becomes crucial when the game’s emergent ontology risks confusion:

  *  **“The Player”** (your role) different from **“A Player”** (the generic concept)

  *  **“This Game Session”** different from **“The Game as a Concept”**

  *  **“Winning”** different from **“Being Declared Winner”**

  *  **“What I Intended”** different from **“What Happened”**




When players create similar cards, different from can clarify that these are distinct entities, even if superficially similar.

 **Edge Notation:**

Use a crossed-out equals sign (≠) or a barrier line (|) between cards that need disambiguation. This visually separates entities that might otherwise be conflated.

 **Meta-Game Application:**

One remaining problem: how can we express equal targets? An item can have statements with both said to be the same as and different from, as long as the targets are different. [Wikidata](https://www.wikidata.org/wiki/Property_talk:P1889) This means Card A might be same as Card B but different from Card C—and that’s not a contradiction.

The game can use this to handle the philosophical puzzle: Is the game you’re playing now (reading these rules) the same as or different from the game you’ll play later (with physical cards)? Both answers might be valid from different perspectives.

* * *

## PART TWO: COMPOSITION

These properties answer: _What is this made of, and what is it part of?_

* * *

### 5\. PART OF

 **Wikidata Handle:** P361

 **Formal Definition:** Object of which the subject is a part (if this subject is already part of object A which is a part of object B, then please only make the subject part of object A). [Wikidata](https://www.wikidata.org/wiki/Property:P361) Inverse property of “has part” (P527).

 **Aliases and Everyday Expressions:**

  * belongs to

  * is contained in

  * is a component of

  * is a piece of

  * is included in

  * falls within

  * is a section of

  * is a segment of

  * is an element of

  * is a constituent of




 **Real-World Wikidata Examples:**

  * Albert Einstein’s brain (Q2464312) is part of Albert Einstein (Q937) [Wikidata](https://www.wikidata.org/wiki/Wikidata:Items)

  * Europe is part of Eurasia [Wikidata](https://www.wikidata.org/wiki/Property_talk:P527)

  * Chapter 3 part of this book

  * The introduction part of the symphony

  * The engine part of the car




 **Transitivity:** Like subclass of, part of is a transitive property. [Wikidata](https://www.wikidata.org/wiki/Help:Basic_membership_properties) If A is part of B, and B is part of C, then A is part of C. This means you only need to mark the direct containment; indirect containment is inferred.

 **The Distinction from Member Of:** It’s better to use member of because it is not transitive. If we use Paul McCartney part of The Beatles, we can also say Paul McCartney’s liver part of Paul McCartney, and then say Paul McCartney’s liver part of The Beatles, which is not wrong, but not exactly useful or interesting. [Wikidata](https://www.wikidata.org/wiki/Property_talk:P463)

 **What This Property Captures in Everyday Life:**

Part of captures physical, conceptual, and structural containment:

  * Your hand is part of your body

  * This sentence is part of this paragraph

  * The melody is part of the song

  * The battle was part of the war

  * Your childhood is part of your life

  * This moment is part of today




This is one of the most intuitive relationships—we constantly think about wholes and parts, containers and contents, aggregates and elements.

 **Application to 1000 Blank White Cards:**

The game naturally generates part-whole relationships:

  *  **“This Turn”** → part of → **“This Round”** → part of → **“This Session”**

  *  **“The Card Back”** → part of → **“The Card”**

  *  **“The Rule You Just Made Up”** → part of → **“The Rulebook”** (this document)

  *  **“Your Hand”** (cards you hold) → part of → **“Your Resources”**

  *  **“The Discard Pile”** → part of → **“The Play Area”**




When physical cards are nested or grouped, part of captures that structure.

 **Edge Notation:**

Draw an arrow (→) from the part pointing toward the whole, or use a containment symbol (⊂) to show “is contained in.” When cards physically overlap (the part card resting partially on the whole card), this physical arrangement can itself indicate the relationship.

 **Meta-Game Application:**

Reading this document, you are part of an audience. The audience is part of the game’s ecosystem. Your attention is part of your engagement. Every layer contains layers; every whole is part of something larger.

* * *

### 6\. HAS PART

 **Wikidata Handle:** P527

 **Formal Definition:** Part of this subject; inverse property of “part of” (P361). [Wikidata](https://www.wikidata.org/wiki/Property:P527)

 **Aliases and Everyday Expressions:**

  * contains

  * includes

  * consists of

  * is composed of

  * has component

  * has element

  * comprises

  * is made up of

  * incorporates

  * has ingredient




 **Real-World Wikidata Examples:**

  * Eurasia has part Europe [Wikidata](https://www.wikidata.org/wiki/Property:P527)

  * Greek alphabet has part Α/α (the letter alpha) [Wikidata](https://www.wikidata.org/wiki/Help:Basic_membership_properties)

  * A recipe has part flour, eggs, sugar

  * A committee has part various members

  * A trilogy has part three volumes




 **What This Property Captures in Everyday Life:**

Has part is the view from the whole looking at its components:

  * Your body has part hands, feet, organs

  * This rulebook has part chapters, sections, sentences

  * The game has part cards, players, rules

  * Your understanding has part concepts, connections, confusions




This is the same relationship as part of, just viewed from the other direction. Sometimes it’s more natural to list what something contains rather than what contains it.

 **Application to 1000 Blank White Cards:**

Has part is useful when defining complex game entities:

  *  **“The Game”** has part **“Players”** , **“Cards”** , **“Rules”** , **“The Table”** , **“Time”**

  *  **“A Turn”** has part **“Drawing”** , **“Playing”** , **“Resolving”**

  *  **“Your Strategy”** has part **“What You Tell Others”** , **“What You Actually Do”**




When a card represents something composite, you can lay out its parts around it, with edges marked to show has part.

 **Edge Notation:**

The inverse of part of notation: arrow points from the whole toward the parts, or use (⊃) to show “contains.”

* * *

### 7\. MEMBER OF

 **Wikidata Handle:** P463

 **Formal Definition:** Organization, club or musical group to which the subject belongs. Do not use for membership in ethnic or social groups, nor for holding a political position. [Wikidata](https://www.wikidata.org/wiki/Property:P463)

 **Aliases and Everyday Expressions:**

  * belongs to (organization)

  * is affiliated with

  * is on the roster of

  * is enrolled in

  * has joined

  * participates in (as member)

  * is part of the membership of

  * holds membership in




 **Real-World Wikidata Examples:**

  * Freddie Mercury is member of Queen [Wikidata](https://www.wikidata.org/wiki/Property_talk:P463)

  * Germany is a member of the European Union [KDnuggets](https://www.kdnuggets.com/2018/05/brief-introduction-wikidata.html)

  * You are a member of your gym

  * A scientist is a member of a professional society




 **The Distinction from Part Of:**

For persons that belong to a music band, member of should be used because it is not transitive. [Wikidata](https://www.wikidata.org/wiki/Property_talk:P361) This prevents absurdities like inferring that Paul McCartney’s liver is part of The Beatles.

Membership implies voluntary association with an organization that has some persistent identity and structure. Parts don’t choose to be parts; members typically do.

 **What This Property Captures in Everyday Life:**

Member of captures organizational belonging:

  * You are a member of your family (arguable—maybe part of is better here)

  * You are a member of clubs, teams, associations

  * Countries are members of alliances, unions, organizations

  * Players are members of teams




This property is specifically for structured groups with defined membership, not for vague categories or social classes.

 **Application to 1000 Blank White Cards:**

In the game, membership captures voluntary association:

  *  **“You”** → member of → **“The Players”**

  *  **“This Card”** → member of → **“The Deck”** (if the deck is conceived as an organization, not just a pile)

  *  **“The House Rule You Made”** → member of → **“The Canon”**




If players form teams or factions, member of captures those affiliations.

 **Edge Notation:**

Use a flag or badge symbol (⚐) on the member pointing toward the organization, suggesting “affiliated with” or “carrying the flag of.”

* * *

### 8\. CONTAINS

 **Wikidata Handle:** P4330

 **Formal Definition:** Contents, item or substance located within this wrapping item, but not part of this receptacle or container; does not describe the ingredients or components of this container. [Wikidata](https://www.wikidata.org/wiki/Property:P4330)

 **Aliases and Everyday Expressions:**

  * has inside

  * holds

  * is filled with

  * stores

  * encloses

  * has within it

  * wraps around




 **The Distinction from Has Part:** Use only when a more specific property is not suitable; the inverse (P276 - location) should be used if the value (contained) item is a unique physical object in itself. Has part (P527) should be used if the value item is an integral part of the container. [Wikidata](https://www.wikidata.org/wiki/Property:P4330)

The box contains the gift, but the gift is not part of the box. The bookshelf contains books, but the books are not parts of the shelf.

 **What This Property Captures in Everyday Life:**

Contains handles spatial enclosure without structural integration:

  * The envelope contains the letter

  * The room contains the furniture

  * The jar contains the jam

  * The game box contains the cards (but the cards aren’t components of the box itself)




 **Application to 1000 Blank White Cards:**

Contains captures physical and conceptual holding:

  *  **“Your Hand”** (the fan of cards you hold) → contains → various cards

  *  **“The Center of the Table”** → contains → cards in play

  *  **“Your Mind”** → contains → your strategy

  *  **“This Moment”** → contains → everything currently happening




This is useful for ephemeral containment—things that are inside other things but aren’t permanently integrated.

 **Edge Notation:**

Use a container symbol ([ ]) or a circle around the edge to suggest “wrapping around” or “holding within.”

* * *

## PART THREE: TEMPORALITY

These properties answer: _When did this happen? What comes before and after?_

* * *

### 9\. BEFORE (Follows / Preceded By - Inverse)

 **Wikidata Handle:** P155 (follows) and P156 (followed by)

 **Formal Definition:** These properties capture sequential ordering. P155 means “immediately prior item in a series.” P156 means “immediately following item in a series.”

 **Aliases and Everyday Expressions:**

  * comes before / comes after

  * precedes / succeeds

  * is prior to / is subsequent to

  * leads to / follows from

  * earlier than / later than

  * happened before / happened after

  * is the predecessor of / is the successor of




 **Real-World Wikidata Examples:**

  * World War I (P156) World War II—WWI is followed by WWII

  * Monday (P156) Tuesday

  * Chapter 3 (P156) Chapter 4

  * Obama administration (P156) Trump administration




 **What This Property Captures in Everyday Life:**

Sequential ordering is how we structure time, narrative, and process:

  * Breakfast comes before lunch

  * Your birth preceded your reading this sentence

  * This word comes before that word

  * Your last thought followed your second-to-last thought




 **Application to 1000 Blank White Cards:**

The game unfolds in time, and this property captures that:

  *  **“Turn 1”** → followed by → **“Turn 2”**

  *  **“The Moment Before You Understood”** → followed by → **“The Moment Of Understanding”**

  *  **“The Card As Blank”** → followed by → **“The Card As Written”**




Sequence in the game matters. The order of plays, the progression of understanding, the evolution of the ruleset.

 **Edge Notation:**

Use a simple directional arrow (→) with perhaps a clock symbol (⏰) to indicate temporal ordering.

* * *

### 10\. AFTER (Follows)

This is the inverse of “before”—addressed above as P155/P156. In your property bank, you might simplify to a single “sequence” property with directional marking.

* * *

### 11\. DURING

 **Wikidata Handle:** P585 (point in time) is related, but for “during” we often use qualifiers on P580/P582 or indicate containment-in-time.

 **Formal Definition:** This property indicates that one event or state occurs within the temporal bounds of another event or period.

 **Aliases and Everyday Expressions:**

  * while

  * at the same time as

  * in the course of

  * throughout

  * within the timeframe of

  * amid

  * in the middle of

  * concurrent with




 **What This Property Captures in Everyday Life:**

  * The phone rang during dinner

  * I thought about you during the meeting

  * The power went out during the storm

  * This paragraph is being read during your session with this document




 **Application to 1000 Blank White Cards:**

  *  **“Your Confusion”** → during → **“Your First Reading”**

  *  **“The Revelation”** → during → **“Turn 5”**

  *  **“Side Conversations”** → during → **“The Main Game”**




 **Edge Notation:**

Use a horizontal bracket or parallel lines (||) to show temporal overlap or containment.

* * *

### 12\. CAUSES

 **Wikidata Handle:** P828 (has cause) is the inverse; there’s also P1542 (has effect)

 **Formal Definition:** The subject item is the cause of the value item; the value item happened or exists because of the subject.

 **Aliases and Everyday Expressions:**

  * leads to

  * results in

  * brings about

  * produces

  * generates

  * triggers

  * is responsible for

  * makes happen

  * is the reason for




 **What This Property Captures in Everyday Life:**

Causation is how we explain the world:

  * Rain causes wetness

  * Studying causes (or at least correlates with) learning

  * Pressing the button causes the thing to happen

  * Reading this sentence causes you to know its content




This is perhaps the most philosophically contested property—what “really” causes what is debated endlessly. But in everyday use, we mark things as causes when they seem to be the primary explanation.

 **Application to 1000 Blank White Cards:**

  *  **“Drawing a Card”** → causes → **“Having That Card In Hand”**

  *  **“Playing a Card”** → causes → **“The Card’s Effect”**

  *  **“Reading This Document”** → causes → **“Understanding (or Confusion)”**

  *  **“One Player’s Action”** → causes → **“Another Player’s Response”**




Causal chains can be marked across multiple cards to show how game states evolve.

 **Edge Notation:**

Use an arrow with a lightning bolt or asterisk (→*) to indicate causal connection, distinguishing it from mere sequence (temporal following without causation).

* * *

## PART FOUR: SOCIAL AND RELATIONAL

These properties answer: _Who is connected to whom, and how?_

* * *

### 13\. KNOWS

 **Wikidata Handle:** P1889 and related social properties; Wikidata uses specific properties like P26 (spouse), P40 (child), etc. For a generic “knows,” we’d use a custom property or model it through P2283 (uses) or social network properties.

 **Formal Definition:** The subject has awareness of or relationship with the value entity.

 **Aliases and Everyday Expressions:**

  * is acquainted with

  * has met

  * is aware of

  * recognizes

  * is connected to

  * has a relationship with

  * is familiar with




 **What This Property Captures in Everyday Life:**

  * You know your friends

  * You know certain facts

  * You know certain places (in the sense of being familiar with them)

  * Characters in a story know each other




This is the basic social/epistemic connection: awareness, acquaintance, relationship.

 **Application to 1000 Blank White Cards:**

  *  **“Player A”** → knows → **“Player B”** (they’ve interacted)

  *  **“You”** → knows → **“This Document”** (you’ve read it)

  *  **“The Character on Your Card”** → knows → **“The Character on Their Card”** (narratively established)




 **Edge Notation:**

Use a handshake symbol (🤝) or a double line connecting two cards to indicate mutual acquaintance.

* * *

### 14\. CREATED BY

 **Wikidata Handle:** P170 (creator)

 **Formal Definition:** Maker of this creative work or other object (where no more specific property exists). [Wikidata](https://www.wikidata.org/wiki/Property:P170)

 **Aliases and Everyday Expressions:**

  * made by

  * authored by

  * designed by

  * invented by

  * produced by

  * crafted by

  * built by

  * composed by




 **Real-World Wikidata Examples:**

  * The Mona Lisa (Q12418) has the Creator (P170) of Leonardo da Vinci (Q762) [CRAN](https://cran.r-project.org/web/packages/WikidataR/readme/README.html)

  * The Scream (Q471379) has the Creator (P170) of Edvard Munch (Q41406) [CRAN](https://cran.r-project.org/web/packages/WikidataR/readme/README.html)

  * All works of art created by Piet Mondriaan can be queried with creator = Mondriaan [Unloch](https://unloch.github.io/lod/notebooks/Wikidata_Basics.html)




 **What This Property Captures in Everyday Life:**

Attribution of origin:

  * This book was created by the author

  * This meal was created by the chef

  * This card was created by you

  * This idea was created by whoever first thought it




 **Application to 1000 Blank White Cards:**

Every card has a creator:

  *  **“The Dragon of Mild Inconvenience”** → created by → **“Player A”**

  *  **“The House Rule About Snacks”** → created by → **“The Group”**

  *  **“This Document”** → created by → **“Claude”** (at your request)

  *  **“Your Interpretation”** → created by → **“You”**




Tracking authorship matters in a game where cards are made collaboratively.

 **Edge Notation:**

Use an artist’s signature symbol or a pen icon (✎) to indicate creation relationship.

* * *

### 15\. PARTICIPANT IN

 **Wikidata Handle:** P710 (participant) and P1344 (participant in)

 **Formal Definition:** Person, group of people or organization (object) that actively takes/took part in an event or process (subject). [Wikidata](https://www.wikidata.org/wiki/Property:P710) P1344 is the inverse: Event in which a person or organization was/is a participant. [Wikidata](https://www.wikidata.org/wiki/Property:P1344)

 **Aliases and Everyday Expressions:**

  * took part in

  * was involved in

  * attended

  * competed in

  * engaged in

  * contributed to

  * played a role in




 **Real-World Wikidata Examples:**

  * The 2008 Summer Olympics had participants including Canada at the 2008 Summer Olympics [Wikidata](https://www.wikidata.org/wiki/Property_talk:P710)

  * Alberto Tomba was a participant in Alpine skiing at the 1992 Winter Olympics [Backlink](https://proxy.backlink.name/index.php?q=nNjV09lukmKt2aplrp2bm5mSqcZj0NSdkq7PpJ6QgKej1MbV2q2dg2eVZ2s)

  * Various speakers participated in the conference

  * Countries participated in the treaty negotiations




 **What This Property Captures in Everyday Life:**

Active involvement in events:

  * You are a participant in this reading session

  * Players are participants in the game

  * Witnesses are participants in events they observe

  * Everyone present is a participant in the moment




 **Application to 1000 Blank White Cards:**

  *  **“You”** → participant in → **“This Game Session”**

  *  **“All Players”** → participant in → **“The Final Vote”**

  *  **“This Card”** → participant in → **“The Combo That Won the Game”**




 **Edge Notation:**

Use a hand raised or person symbol (🙋) to indicate participation.

* * *

### 16\. LOCATED AT

 **Wikidata Handle:** P276 (location)

 **Formal Definition:** Location of the object, structure or event; use P131 to indicate the containing administrative entity, P8138 for statistical entities, or P706 for geographic entities. [Wikidata](https://www.wikidata.org/wiki/Property:P276)

 **Aliases and Everyday Expressions:**

  * is at

  * can be found at

  * is situated in

  * is positioned at

  * occurs at

  * takes place at

  * resides at

  * exists at




 **Real-World Wikidata Examples:**

  * The Rosetta Stone is located at the British Museum [Wikidata](https://www.wikidata.org/wiki/Property_talk:P195)

  * Use “location” (P276) for indications of a location for events and objects [The Mail Archive](https://www.mail-archive.com/wikidata@lists.wikimedia.org/msg09753.html)

  * A conference is located at a venue

  * An artwork is located at a museum




 **What This Property Captures in Everyday Life:**

Spatial positioning:

  * You are located at wherever you’re reading this

  * The cards are located at the table

  * The game is located at the intersection of imagination and rules

  * Your attention is located at these words




 **Application to 1000 Blank White Cards:**

  *  **“The Active Card”** → located at → **“The Center of the Table”**

  *  **“Your Strategy”** → located at → **“The Back of Your Mind”**

  *  **“The Discard Pile”** → located at → **“The Edge of the Play Area”**




 **Edge Notation:**

Use a location pin (📍) or a simple “at” symbol (@).

* * *

## PART FIVE: ATTRIBUTIVE

These properties answer: _What qualities does this have? What is it about?_

* * *

### 17\. HAS QUALITY (Has Characteristic)

 **Wikidata Handle:** P1552 (has characteristic)

 **Formal Definition:** Inherent or distinguishing quality or feature of the entity. Use a more specific property when possible. [Wikidata](https://www.wikidata.org/wiki/Property:P1552)

 **Aliases and Everyday Expressions:**

  * has the property of

  * is characterized by

  * has the feature of

  * possesses

  * exhibits

  * displays

  * is marked by

  * has attribute

  * has quality




 **Real-World Wikidata Examples:**

  * Planar graph has characteristic crossing number (meaning: the crossing number of a planar graph is 0) [Wikidata](https://www.wikidata.org/wiki/Wikidata:Property_proposal/value_of_this_characteristic)

  * Something marked as having the characteristic “honorary” to distinguish it

  * An account having the characteristic of being “verified”




 **Important Note:** The value should never be a class that the subject belongs to. For parent classes, use P31 or P279. [Wikidata](https://www.wikidata.org/wiki/Property:P1552) This property is for qualities, not classifications.

 **What This Property Captures in Everyday Life:**

Attributes and qualities:

  * This coffee has the quality of being hot

  * You have the characteristic of curiosity (right now, reading this)

  * The card has the quality of being handmade

  * The game has the quality of being confusing (or delightful)




 **Application to 1000 Blank White Cards:**

  *  **“The Dragon of Mild Inconvenience”** → has quality → **“Mildly Inconvenient”**

  *  **“Your Current State”** → has quality → **“Engaged”** or **“Confused”** or **“Amused”**

  *  **“The Deck”** → has quality → **“Incomplete”** (it’s always becoming)




 **Edge Notation:**

Use a descriptor label or a quality symbol like a star (★) for notable attributes.

* * *

### 18\. ABOUT (Main Subject / Depicts)

 **Wikidata Handle:** P921 (main subject) and P180 (depicts)

 **Formal Definition:** For P921: The primary topic(s) of a work. For P180: Entity visually depicted in an image, literarily described in a work, or otherwise incorporated into an audiovisual or other medium. [Wikidata](https://www.wikidata.org/wiki/Property:P180)

 **Aliases and Everyday Expressions:**

  * concerns

  * deals with

  * discusses

  * represents

  * is on the topic of

  * addresses

  * treats

  * portrays

  * illustrates

  * refers to




 **Real-World Wikidata Examples:**

  * Papers about Wikidata can be queried with main subject = Wikidata (Q2013) [Wikidata](https://www.wikidata.org/wiki/Wikidata:SPARQL_query_service/queries/examples)

  * The Mona Lisa depicts Lisa Gherardini [Wikimedia Commons](https://commons.wikimedia.org/wiki/Commons:Structured_data/Modeling/Depiction)

  * A biography is about its subject

  * A photograph depicts its subjects




 **The Distinction:** Depicts (P180) is about a motif—what you see or read directly in the work. Main subject (P921) is about the theme or subject heading—what the work is fundamentally about. [Wikidata](https://www.wikidata.org/wiki/Property_talk:P180)

 **What This Property Captures in Everyday Life:**

Subject matter and content:

  * This document is about the property bank

  * This section is about the “about” relationship

  * A portrait is about (depicts) a person

  * Your thoughts right now are about this game




 **Application to 1000 Blank White Cards:**

  *  **“Card With a Picture”** → depicts → **“What’s in the Picture”**

  *  **“This Entire Game”** → about → **“Structured Data”** and **“Play”** and **“Emergence”**

  *  **“Your Card’s Text”** → about → **“Whatever You Wrote It To Be About”**




 **Edge Notation:**

Use a “re:” prefix or a topic symbol (📌) to show subject relationship.

* * *

## SYNTHESIS: Using the Property Bank in Play

Now that you have 18 properties, here is how they work together in the context of 1000 Blank White Cards as a structured data generation game:

 **The Physical Layout:**

  * Each card is an entity

  * Physical adjacency indicates a relationship

  * Edge markings (drawn on the part of the card touching another card) specify which property

  * The property bank (these 18 symbols/abbreviations) should be available for reference during play




 **Generating JSON-LD:** At the end of a game session, the relationships marked between cards can be transcribed into structured data. Each card becomes a node with an identifier; each edge becomes a triple:

json
    
    
    {
      “@context”: “https://schema.org/”,
      “@graph”: [
        {
          “@id”: “card:dragon-of-mild-inconvenience”,
          “instanceOf”: “card:creature”,
          “createdBy”: “player:alice”,
          “hasCharacteristic”: [”mildly-inconvenient”, “fire-breathing”]
        },
        {
          “@id”: “card:game-session-2025-11-27”,
          “instanceOf”: “game:session”,
          “hasPart”: [”card:dragon-of-mild-inconvenience”, “...”],
          “participant”: [”player:alice”, “player:bob”, “player:you”]
        }
      ]
    }

 **The Meta-Layer:** You, reading this, are already generating data. Your engagement is an instance of _reading_. This document is an instance of _rulebook_. The relationship between you and it could be marked as: You → participant in → “Reading This Document.”

By the time you finish, you will have created a mental model that is itself a structured dataset—entities and their relationships, classified and connected.

 **Welcome to the game. You’re already playing.**

* * *

## Quick Reference Card
    
    
    Symbol  Property        P-Code      Core Question
    ↓       instance of     P31         What is this?
    ⇒       subclass of     P279        What type of type is this?
    =       same as         P460        Is this the same as that?
    ≠       different from  P1889       Is this distinct from that?
    ⊂       part of         P361        What is this inside?
    ⊃       has part        P527        What is inside this?
    ⚐       member of       P463        What group does this belong to?
    [ ]     contains        P4330       What does this hold?
    →⏰     before/after    P155/P156   What sequence is this in?
    ∥       during          P580/P582   What time contains this?
    →*      causes          P828        What does this make happen?
    🤝      knows           P1015       Who is connected?
    ✎       created by      P170        Who made this?
    🙋      participant in  P1344       Who is involved?
    @       located at      P276        Where is this?
    ★       has quality     P1552       What attributes does this have?
    📌      about           P921/P180   What is this concerning?

* * *

 _This document is an instance of rulebook. It is about structured data and play. It was created by Claude, in collaboration with you. You are now a participant in this game. What will you create?_

---
title: SONNET 93
subtitle: YOU ARE MY REASON FOR TREASON
author: Adam Wadley
publication: Experimental Unit
date: March 21, 2025
---

# SONNET 93
[![](https://substackcdn.com/image/fetch/$s_!BNnG!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fead1c5fd-176c-407f-9a99-710226973dd3_1170x2532.png)](https://substackcdn.com/image/fetch/$s_!BNnG!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fead1c5fd-176c-407f-9a99-710226973dd3_1170x2532.png)

The territory that in shade defects

Is shifting its tectonics to make way

The local, primal, fighting dialects

All screaming in the void to have their say

While trembles in the finger of the night

So dark the soul can't see it's full abode

The voice of chaos' truth and growing blight

Awake to all the pebbles in the road

And on that night the one I found was you

And in my inner lands there came to bloom

The flowering of oleander's hue

The fragrance of your oleander room

What's there to do for you? I'll play my part

The land I tear for love of you's my heart

---
title: What Do You Think Of The Show?
subtitle: The Abstraction Train Rolls On
author: Adam Wadley
publication: Experimental Unit
date: March 27, 2025
---

# What Do You Think Of The Show?
It’s fun to at least start this when I would otherwise be on the radio. I had the idea of trying to be typing for the whole hour, and then I could present what I’d made as what was there instead of a show. Now that I think of it, I could have done a live stream too.

But I don’t really like the name “solution space” anyway.

Ben Zweibelson writes about “dissolving” problems. This is instead of “solving” them. So instead of a solution space we could talk of a dissolution space. Of course, things dissolve in a solution. But a solution is a homogeneous mixture. You can tell I’ve thought about this somewhat.

So, with that on-ramp, why not get right at it?

The formulation of “the X question” has disturbing overtones in all contexts for me. It would never just be like, “oh yeah, let’s discuss the so-and-so question.” Immediately in my mind is coming the idea of “the Jewish question,” or since I was reading this haunting Hitler quote yesterday, “the Polish question.” It was Adi talking to a British official right before the invasion of Poland, saying that Adi planned to retire after the settlement of “the Polish question” and finish life as an artist.

With that in mind, we can open the door to “The Nazi Question.” We are seeing more and more discussion of Nazism in the world these days, with the recent gesture by Elon Musk catapulting the topic to the center of discussion. The term is now part of the “partisan” politics of the primitive society of our shared future, “The United States.” Which is to say that “the Democrats” and “the Republicans” are now talking about it a lot as part of their constant fighting with and amongst each other. You can imagine that like something getting sucked into a tornado, and now the tornado is pervading that as well, like a Sharknado if you will.

So, the concept of Nazism is now like the sharks which have been sucked into the tornado of the discursive storm which is “American politics.” So this is how what we are really tracking is things people say, and what other people say about things that they say, and how all this is Very Important because of what those people Represent in terms of Institutions that make Everyday Life possible.

The news shows, the commentaries, the comments online, the bots, the everything. That’s the tornado I’m talking about.

So now, the concept of Nazism is getting a lot of play.

Back to Patrick Chapin asking us, “what’s the best thing to be doing in the format?”

Right now, apparently a lot of people think that the best thing to do is to try to tar the Trump administration and Elon with the label of “Nazi” as a way to really catalyze public opinion against them.

This provokes a huge discourse about for example whether Elon really meant to do the Heil Hitler salute, or what constitutes a Nazi. And people will say no, it’s not “The Republicans” that are Nazis, it’s “The Democrats” who are Nazis!

Here is what is understood:

  1. Nazis are bad




Even at this level, this is of course a section of the Internet and popular discourse which doesn’t even agree here. There are plenty of Neo-Nazis, the kinds of people who were excited when Elon did the Heil Hitler salute.

Notice there again that people were saying oh, but the salute was done before. It’s the Roman salute! So we are not now debating what gesture was done, but how that gesture is to be understood.

This is back to the idea of “ruining” things. The concept of Nazism and the Nazis have “ruined” a lot of things. For something to be “ruined” means that it is now indelibly marked with your influence. If someone uses something that you used, it will be for those who see their gesture or perceive it always in the context of your prior use.

So a great example is the name “Adolf.” If you name you child “Adolf” at this point, you are certainly aware that there was this person “Adolf Hitler”—I just looked it up and “Adolf Hitler” had no middle name? What the heck?—and that this person is considered pretty bad.

On the other hand, apparently there are stores in Southeast Asia where Nazi branding will be used and it’s considered cute or chill?

> [Southeast Asia has a peculiar fascination with Hitler and Nazi imagery. Across Southeast Asia it is not uncommon to come across youths sporting t-shirts emblazoned with swastikas, a fashion often termed ‘Nazi chic’. For those raised on European history, it is a befuddling experience.](http://www.bbc.com/news/magazine-29644591)
> 
> [In both east and west, there has long been a push to reclaim the swastika from its Nazi symbolism back to its original eastern roots in Hinduism and Buddhism, in which the symbol signifies peace and luck. As those in the reclaim campaign often note, much of the world loved the swastika before the Nazis altered its meaning. The reclaim campaign has also been promoted in Europe and North America — in 2013 tattoo parlours in 40 countries took part offering free swastika tattoos.](http://www.bbc.com/news/magazine-29644591)
> 
> [Yet in Southeast Asia, the sporting of Nazi symbolism is more about a show of strength or an attempt to affiliate oneself with a fringe group, and less about reclaiming the swastika. Moreover, youth across Southeast Asian are largely ignorant of the history of the symbol. In many ways, ‘Nazi chic’ is Southeast Asia’s hipster movement.](http://www.bbc.com/news/magazine-29644591)

For someone enmeshed in the “Western” discourse bubble, and especially as someone whose mother’s parents were raised in Nazi Germany and participated in it, this is hard for me to really imagine.

But it would hit different if you weren’t white. For example, in discussing Nazism I am constantly afraid that you think I’m simply a Nazi, that that’s what this is.

And, I’m sorry, are we supposed to be grateful for what our ancestors did to get us here? If you think about “your ancestors,” do you think about the rapists and murderers among them? After all, you have so many ancestors. Do you think none of them were brutal, were killers, committed what you would call atrocities?

The idea of self-serving discourse has me looping back around to the Law of One, which I discussed maybe with Grimes but with somebody on December 22, 2022 between 6 a.m. and 7:15 a.m. East Coast time. Anyway, I looked into it later and something in the Law of One is about reconciling service-to-self and service-to-others.

In The Law of One it’s all messed up though, because it basically tells you that you need to focus on one or the other in order to make it to the next dimension or something. At that point, in the sixth dimension or whatever thing it’s talking about, then you will be able to merge them.

But until then you have to be entirely self-oriented or think about other people half the time, something like that. Notice that the logic here breaks down if you think about it being possible to think about yourself and others at the same time. If you consider that there is no self—anatta—or if you consider that everyone could be part of the same, even different reincarnations of each other all living at the same time through the magic of magic.

Anyway, my opinion is that I’m not waiting on any sixth dimension in order to obviate the distinction between self and other, between service to self and other. They say “no man can serve two masters,” but that’s not actually true if you are serving that within each sentient being is always already together on the highway of the consistent.

So, if my discourse here is self-serving because it’s helping me not feel bad about my ancestors or whatever, that is all to the good. Why shouldn’t my artistic works be a balm even for myself? The question of course is entirely in what manner said works might alleviate whatever internal pain. Because this mechanism is the same one operative toward others.

For example, if I make myself feel better by being mean to others, then I just made a negative externality. So service to all others means acting in ways that create positive externalities for all other sentient beings.

This is best done through a kind of process similar to nuclear concentration, I forget the name. But one splitting hits another and it’s a cascade, it’s a cultural singularity. The beauty of it is that one person you reach can reach way more than one other person, or two. We are media that can reach all sorts of people all the time.

So if this Bodhisattva machine, if you will, can be cranked up, then it should serve all others and then come back to serve myself.

The current phase is sort of like a plow. I’ve been very conceptually violent, or whatever, and now everything is kicked up into the air. This is also the time going forward when the patterns unfolding are the least advanced, so it is most easy at this point to think that I have horribly messed up.

Note that it’s not like everything I do is part of some plan that I have. That’s why I can’t sit here and tell you that oh, actually everything I did was the best course of action because of XYZ worldly reasons.

No, it’s all for the best because don’t you know about logos? About Wakan Tanka?

The beauty of my discourse is that I don’t have to deny that anything else that happens was for the best, too. So I’m not claiming superiority or anything.

All I’m claiming is intervention, and who knows what influence might result. It’s my wager that my display will wind up bearing fruit even in terms of reputation. But whether or not what good I have done for myself and others is properly recognized by anyone, it will still proceed under the forlorn heading of Dark Forest Protocol. That’s fine, it’s not entirely up to me (again, lesser me, eventually we all choose everything that happens together so in that sense it is up to me but me in the past/future and I don’t know what I chose/will choose yet).

In that sense it is the feeling of accepting being out on a limb and possibly being martyred or whatever, scapegoated. People will think you are very bad and do all sorts of things to you. Well, whatever. As MLK said, that doesn’t matter much to me now, or whatever he said.

It’s not about seeking any negative outcomes. I should like for things to go as smoothly as possible. But to get something back on track sometimes you have to jolt it, make it jump up and down. And that’s jarring, understandably. Sometimes people wouldn’t know how you did something helpful until later, and in the meantime you get nothing but blame.

Anyway, the point of the story was dissolving “The Nazi Question” (TNQ) instead of “solving” the problem of Nazism. What does this mean?

It has something to do with what I’m constantly saying about “abstracting over” something.

So for example say you are in school and you have on a pink backpack. And someone else says it’s dumb and starts giving you a hard time, and people go along or are quiet and so basically it’s made out to be in this social situation that your pink backpack is dumb and you are dumb for wearing it.

In this situation, it feels like the bully has “abstracted over” the pink backpack. They have created the framing for everyone there that “We don’t like pink backpacks,” nor people who wear them. It has created a very socially powerful framing which influences how everyone present or susceptible to that influence sees the pink backpack.

Note that even if you were just being quiet and you still think pink backpacks are cool, now you have to operate in a social environment where pink backpacks are coded as dumb and everyone knows it. Therefore even if you use pink backpacks, you will be in conversation with this framing.

So basically the attempt to just say Nazis are bad and think you are winning by getting people to think someone is a Nazi, without getting into the details of Nazism aside from the bad parts which you frame in your own way—this attempt is trying to abstract over Nazism by making the concept that it is a fact that Nazis are evil into some sort of foundational line by which to discredit their political opponents.

The issue here is ironically similar to the one that Nazism faces in trying to abstract over, say, Judaism. One of the first things everyone knows about Nazis is that they don’t like Jews and want to kill them all.

So just the same way people are now emphasizing that Nazis are bad, the Nazis at one point—and this is what is so bad about them, right—were once going around saying how Jews are bad and Judaism is bad and dealing with that “problem” was so important and so on.

Anyway, the issue that Nazism faces is that Judaism is obviously a very powerful discourse. So what do I mean by that? Because a discourse or a conceptual system—of-systems sounds like I just mean something that could be stored on a computer, like it’s just abstract data. In a way, yes.

Concepts are these things where we can recognize that there’s a similarity even though contexts might be different. Like, people 6,000 years ago made graves and talked about death, and there’s all sorts of translation issues and whatever, but if we imagine to ourselves that in those days people died and other people talked about it and had a name for the concept of ceasing to live, then we can agree that there’s something like a concept for death.

The concept of death would then be relevant whenever it was thought of, but also when it wasn’t. Like someone died by accident and it was so sudden they didn’t have time to be meta-aware that they were going to die. Then the concept of death was not present (imagine this happened when they were alone, etc) but death was, and so the concept of death extends to this scenario even though it wasn’t present.

In that sense, the concept of death then extends to everything which has ever died, which is like quadrillions of things or whatever? That we know of?

Okay, so now back to conceptual systems-of-systems. We can imagine Walter Benjamin’s I wanna say language in general and human language in particular. So a conceptual system-of-systems (CSS) is a thoughtplex that things like hominids would have, us with our abstract thought and so on.

Now, every CSS will abstract over features that all such hominids have in common.

Did you ever notice how every culture has something to say about food?

Did you ever notice how people put effort into how they talk?

And so on. There are these topics that are so central to everyone relevant here (because again a bird isn’t going to make a CSS in the same way, or not one that I can appreciate, so the universe of “All CSSes that I can have a prayer to get an intimation of” is just the ones of hominids), that everyone abstracts over them.

So every CSS will abstract over (again, attempt to abstract over) core concepts. Here’s a sample list:

Food

Dreams

Water

Traveling

Sleep

Sex

Fighting

Death

Conversation

The sacred

Love

Purpose

Procreation

Child-rearing

“The Prime of Life”

Old age

That’s what I have for now, there are probably some super obvious ones I’m missing, you can look at things like “cultural universals” to get more ideas maybe.

So, of course both Judaism and Nazism abstract over all these things in their own way, just like the Mississippi River civilization would have, or Ming China, or the Mongolian empire or Egypt.

What we have here are complex sets of stories that attempt to cover everything. The weakness of every CSS is that it must remain incomplete.

That’s because what allows each CSS to consider itself as “a thing” is what delineates it from others, and this must involve a self-imposed sort of blindness. Because things aren’t really as different as all that, and so to be invested in the specialness of something, and to be invested in it as a sure thing that no one is allowed to deny, is actually a form of hubris and quickly leads to a sort of cognitively rigid and affectively stunted behavior, sensibility, and constitution.

So again, looking at the case of Judaism, I’m thinking about how the “state of Israel” will complain that it is held to a higher standard than other countries. Aside from whether that’s true, look at the whole story of Judaism. Isn’t being a Jew all about having a special calling from the ground of all existence? So, in addition to talking about the non-acceptability of antisemitism, why shouldn’t we also talk about what should the special responsibility of Jews and Judaism be in the world today?

People always get mad when you say that they should do something. What about you? They ask.

That’s exactly why I prefer to discuss CSS from inside, rather than outside. It’s too fraught because everyone is so scared and closed-minded right now.

But so to say, I’m not here to discuss the obligations described by Judaism for our time—Tikkun Olam for example—as a non-Jew, but as a fellow Jew. Why not? This is the sort of thing where I’m not that interested in exclusionary rituals and this sort of what is basically intellectual property among belief systems. That you have to do this and that to be considered this or that. The truth is that this has all been going on so long that it’s easy to lose the vibe for what is written down.

So, from inside Judaism, it’s clear to see that Nazism fails to abstract over Judaism.

You can look at how many people are aware of the fact that Jews are “over-represented” in certain professions. I put over-represented in quotation marks because it assumes that we set an expectation ahead of time what is going to happen, that everything should be a statistical distribution which is fair in some way, and then we notice how it is “skewed.” When, in reality, what we really have is this experience which is “askew,” and then we try to set linear expectations and are aghast when they are dashed.

Nevertheless, people can tell that Judaism or Jewish people have produced a great number of influential people. There are those in China who went from being more antisemitic to suddenly sort of fetishizing Judaism. They want to find out how to be good with money.

Even in Nazism there is a sort of begrudging respect for Judaism, after all it has to be powerful to be the number one threat, right?

And how people say that for the fascist the enemy is always strong and weak. Yes, well, if your power is all up in heaven then you don’t have many worldly divisions. At the same time, if your treasures are in heaven (your CSS and embodied reflective practices distributed across millions of diffuse people each capable of carrying the load themselves and in small groups) then you can’t really get rid of them. Even if all Jewish people were killed, Judaism itself would probably only become more powerful.

So from the perspective of Nazism Judaism is weak because we are chuds. We measure strength in numbers and Jews have never had a lot of numbers even before the Holocaust. So in that they are a small nation, not even a nation because they are scattered everywhere. And this is looked down on of course, this rootlessness. But people don’t talk about being rooted in a CSS, being rooted in something to where you take the Axis Mundi with you wherever you do. If you haven’t felt the charge of the prayer and the spirit in the room then you can’t even know what you are up against.

Which is why Judaism is also strong. It’s comparable to an irregular vs a regular force. The irregular force can’t win a set-piece pitched battle, but it can degrade the regular force and wind up winning. That’s what Washington in the American revolution is all about!

It’s again, it’s like invading the Soviet Union and it’s all going well, a hot knife through butter, until you realize the butter is corrosive, it’s corroding your blade until it’s broken off and pieces are just being absorbed into the butter, digested.

Just like trying to set out to really put Trump and co into their place, appealing to steady truisms like Nazis are bad, only to discover that you are in over your head as the discursive complexity continues to turn against you. Because the whole reason why you wanted to have a scapegoat was so you wouldn’t have to think, but all of a sudden you’re losing the sixth army and cowering in your bunker looking at a Luger.

Because again if you look at Judaism, it has a strong claim where it’s saying these people were chosen by the ground of all existence. That is also sort of what Nazism is saying, and it’s really important to notice how much Nazism is basically cribbing from Judaism, the whole idea of being the greatest but then facing hardship and seeking new land and wanting vindication in the end which is grounded in something ontological, like God’s will or genetics or “cultural supremacy” or something like that.

But of course the main battle is not Judaism versus Nazism, but whatever is remaining of the amorphous “normal” which is basically trying to just to get everyone to calm down and not think too much, and just expect that everything is going to keep going the same.

It’s basically like the ideology you tell to the people stuffing the boilers on the Titanic and they don’t know that it’s sinking yet so you’re trying to keep their belief alive so that they will staff the electricity machines until the very end.

So basically it’s not like Judaism is about to become the dominant framing of everything, either. Which is why people are usually not actually fully repping any concrete CSS, what Baudrillard would call a singular culture. What you’re running is a meta-CSS which is continually compensating for the fact that it’s not grounded in anything, not just spatially rootless but conceptually rootless. And again, in a way it has to be so given skepticism and the trilemma, see Sarte’s thing about anti-semites not respecting language and again Sartre isn’t seeing that the norms that are sought to be established as normal that only haters would violate—again, you’re a bad person if you violate them—again they don’t obtain and so this is structural bad faith built into all doctrines and pretensions to objectivity. Talk about self-defeating!

I want to wrap this up for now.

To dissolve the Nazi Question means to change the goal. The goal is not that everyone agrees Nazis are bad. The goal is that Nazism is not a conceptual system which can be used to abuse others and harm them.

The next thing to see is that this updated goal can only be achieved by making it so that no discourse can be used to abuse others and harm them. That means that combating the external foe must always go with inward orientation and attention, again Greater Jihad or Tibetan Spiritual War.

And again, the positive externality to be radiating is to be making the foe also understand that Greater Jihad and Tibetan Spiritual War are also vital for them, so that they will start to have a “fifth column” inside them which is come from you but only in the sense that part of you is your shadow which is part of them. So it’s not really a domination because it is only your quietest feeling, your least insistent aspect, which is able to speak soul to soul with all others.

Anyway, what we’re seeing is that none of these discourses are fit to abstract over all the others, this is something like the death of meta-narratives. And yet with all this complexity in view, we can see what it is we are talking about, topics and people that are abstracted over again and again, symbols that won’t die and the people who will but are all the sentient beings here for now.

Each one the main character of their own drama, each one chosen by God to be fit for incarnation into. And yet the whole thing is how we can make it agreeable, that we can all be the main character at the same time.

If I insist so loudly (if ironically) at my own singularity, sorry: my delusions of grandeur, it is only to muffle your delusions of mediocrity.

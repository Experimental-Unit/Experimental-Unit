---
title: THE SHARED PROBLEM STRUCTURE OF "HUMAN" LIFE
subtitle: A Multi-Level Explanation (Grades 1, 3, 5, 12, Post-Doctoral)
author: Adam Wadley
publication: Experimental Unit
date: November 28, 2025
---

# THE SHARED PROBLEM STRUCTURE OF "HUMAN" LIFE
[![](https://substackcdn.com/image/fetch/$s_!HChM!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe8cac3bd-e4a1-4bae-bcb5-72f543dc79d5_1537x767.png)](https://substackcdn.com/image/fetch/$s_!HChM!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe8cac3bd-e4a1-4bae-bcb5-72f543dc79d5_1537x767.png)

Even though people live very different lives—a starving beggar, an [Alex Mazey](https://open.substack.com/users/28966743-alex-mazey?utm_source=mentions), a hunted spy, a bored billionaire, [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions)—the _types_ of problems they face belong to the same deep structure. Below, each problem type is expressed at progressively higher conceptual levels.

* * *

## 1\. Survival Problems

### First Grade

Everyone needs food, water, and a safe place to be. When you don’t have these, you feel scared and hurt.

### Third Grade

All people try to keep their bodies working. They need to find enough to eat, stay warm or cool, and not get sick or injured.

### Fifth Grade

Survival means maintaining basic biological needs. People in danger or poverty must struggle directly; powerful people may face survival threats in hidden forms like enemies or stress.

### Twelfth Grade

Survival problems concern threats to physical continuity—caloric intake, disease, violence, and environmental hazards. Even elites face survival threats through indirect or political vectors such as targeted violence, exposure, or stress-related risk.

### Post-Doctoral

Survival is the primordial horizon of organismic self-maintenance: the Maturana–Varela autopoietic imperative. Across socioeconomic strata, differential modalities of danger still map back to entropy management, physiological viability, and organismic stability. Survival risk redistributes but does not disappear; it transitions from brute scarcity to complex systemic vulnerability.

* * *

## 2\. Security Problems

### First Grade

Everyone wants to feel safe from things that can hurt them.

### Third Grade

People try to stop bad things from getting to them—like danger, harm, or trouble caused by others.

### Fifth Grade

Security is about protecting yourself from threats. A beggar avoids street violence; a spy avoids capture or exposure. The form changes, but not the structure.

### Twelfth Grade

Security problems involve preventing incursions—physical, informational, economic, or reputational. The degree of threat differs, but the underlying problem of boundary protection is universal.

### Post-Doctoral

Security is boundary-maintenance within open systems. It involves preventing unauthorized or harmful perturbations. Whether through coercive micro-violence or counterintelligence, agents negotiate the permeability of their systemic borders. Security is an invariance condition in complex adaptive systems.

* * *

## 3\. Information Problems

### First Grade

You need to know what’s going on so you can do the right thing.

### Third Grade

Sometimes it’s hard to tell what is true, what matters, or what people really mean. Everyone has to figure things out.

### Fifth Grade

Information problems involve getting the right knowledge, avoiding lies or mistakes, and making sense of confusing signals. A hungry person needs to know where food is; a spy needs to read threats.

### Twelfth Grade

Individuals confront epistemic constraints: noise, uncertainty, hidden variables, deception, and ambiguity. Information gathering and interpretation shape survival and strategy.

### Post-Doctoral

Information problems consist of epistemic asymmetries, signal-to-noise ratios, inference under uncertainty, and the phenomenological limits of situated cognition. All agents operate with incomplete models and must manage ontological opacity within their environment.

* * *

## 4\. Trust Problems

### First Grade

You need people you can count on.

### Third Grade

You try to figure out who is safe to be around and who might hurt or trick you.

### Fifth Grade

Trust problems involve deciding who to rely on, who will keep promises, and who shares your interests. Betrayal risk is universal.

### Twelfth Grade

Trust is a mechanism for reducing transaction costs, enabling cooperation, and managing social uncertainty. It becomes critical in asymmetric-power or high-risk environments.

### Post-Doctoral

Trust is a relational epistemic stance enabling coordination under uncertainty. It reflects Bayesian priors about agent reliability, vulnerability calculus, and intersubjective normativity. Regardless of class or role, trust mediates exposure to risk.

* * *

## 5\. Recognition Problems

### First Grade

People want others to see them as real and important.

### Third Grade

It matters that others treat you like a person, not like nothing or a problem.

### Fifth Grade

Recognition problems concern dignity, identity, and being taken seriously. Without recognition, social existence becomes painful or unstable.

### Twelfth Grade

Recognition is the struggle for being acknowledged as a legitimate moral and social subject. Misrecognition produces marginalization, stigma, or dehumanization.

### Post-Doctoral

Recognition is a Honneth-style intersubjective constitution of selfhood: the dialectical process through which the subject becomes normatively visible. At every social tier, human agents negotiate the symbolic economy of status, legitimacy, and personhood.

* * *

## 6\. Coordination Problems

### First Grade

People must work together or things get messed up.

### Third Grade

It’s hard to know what everyone else is doing or what they want, so people must try to match their actions.

### Fifth Grade

Coordination involves aligning plans with others even when information is incomplete. Beggars coordinate around scarce spaces; spies coordinate in networks of secrecy.

### Twelfth Grade

Coordination concerns aligning strategies under asymmetric information, incompatible incentives, or communication limits. Failures produce conflict or inefficiency.

### Post-Doctoral

Coordination is a game-theoretic and phenomenological challenge of synchronizing temporally distributed agents under constraint. It emerges from distributed cognition, common-knowledge structures, and institutional scaffolding.

* * *

## 7\. Freedom/Control Problems

### First Grade

People want to make their own choices and not be pushed around.

### Third Grade

Everyone tries to stay free enough to do what matters while avoiding being controlled by others.

### Fifth Grade

Freedom/control problems concern autonomy within constraint systems. Poverty restricts freedom; espionage roles restrict it in different ways. Both encounter domination.

### Twelfth Grade

Agency is constrained by structural, informational, and coercive forces. Actors continually negotiate autonomy, compliance, and power asymmetries.

### Post-Doctoral

Freedom/control is the negotiation of agency within structural determination—an intersection of Foucauldian power, Sartrean freedom, and systems-theoretic constraint. Both the oppressed and the elite encounter recursive regimes of control shaping possible action.

* * *

## 8\. Meaning Problems

### First Grade

Everyone wants their life to make sense and to feel good inside.

### Third Grade

People need reasons to keep going and stories about who they are.

### Fifth Grade

Meaning problems concern identity, purpose, and coherence under stress or privilege. Even those with power face existential instability.

### Twelfth Grade

Meaning arises through narrative construction, value frameworks, and symbolic integration. Threat, trauma, or excessive abundance can disrupt meaning-making processes.

### Post-Doctoral

Meaning is the hermeneutic and phenomenological synthesis of temporal experience into coherent self-world relations. It integrates Heideggerian thrownness, Ricoeurian narrative identity, and existential risk. All agents confront meaning collapse and reconstruction.

* * *

## 9\. Time-Compression Problems

### First Grade

Sometimes you must decide fast, and it feels scary.

### Third Grade

People often have too little time to think or too much time to worry.

### Fifth Grade

Time-compression problems involve making decisions under pressure. The poor face immediate survival deadlines; elites face high-stakes, long-horizon risks.

### Twelfth Grade

Decision-making scales differently: short reaction windows for urgent threats versus expansive planning for strategic risks. Nonetheless, temporal stress is universal.

### Post-Doctoral

Time-compression concerns chronopolitics, cognitive load, and bounded rationality under temporal constraint. Human agents confront the mismatch between biological time, social time, and strategic time.

* * *

## 10\. Moral/Legitimacy Problems

### First Grade

People want to do good, but it’s not always easy.

### Third Grade

Sometimes you have to choose between things that all feel wrong or confusing.

### Fifth Grade

Moral problems arise when every option has costs to others or to oneself. Even powerful people must navigate ethical compromise.

### Twelfth Grade

Moral and legitimacy problems involve acting under conflicting norms, scarcity, or coercion. Legitimacy is fragile and shaped by systemic pressures.

### Post-Doctoral

Morality is a negotiation of normativity under real-world constraint—Agamben’s exception, Weber’s ethics of responsibility, and structural violence frameworks. Legitimacy arises from intersubjective rationalization, yet all agents face contexts where justificatory structures collapse.

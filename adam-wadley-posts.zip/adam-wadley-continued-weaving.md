---
title: Continued Weaving
subtitle: Isn't There Some Deity Like A Spider Person
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Continued Weaving
Is that what [Ariadne](https://en.wikipedia.org/wiki/Ariadne#Minos_and_Theseus) is?

Kind of!

> Because [ancient Greek](https://en.wikipedia.org/wiki/Ancient_Greece) myths were orally transmitted, like other myths, that of Ariadne has many variations. According to an Athenian version, [Minos](https://en.wikipedia.org/wiki/Minos) attacked [Athens](https://en.wikipedia.org/wiki/Athens) after his son, [Androgeus](https://en.wikipedia.org/wiki/Androgeus_\(son_of_Minos\)), was killed there. The Athenians asked for terms and were required to sacrifice [7 young men and 7 maidens](https://en.wikipedia.org/wiki/Sacrificial_victims_of_Minotaur) to the [Minotaur](https://en.wikipedia.org/wiki/Minotaur) every 1, 7 or 9 years (depending on the source).[[18]](https://en.wikipedia.org/wiki/Ariadne#cite_note-19) One year, the sacrificial party included [Theseus](https://en.wikipedia.org/wiki/Theseus), the son of King [Aegeus](https://en.wikipedia.org/wiki/Aegeus), who volunteered in order to kill the [Minotaur](https://en.wikipedia.org/wiki/Minotaur).[[19]](https://en.wikipedia.org/wiki/Ariadne#cite_note-20) At first sight, Ariadne fell in love with him and provided him a sword and ball of thread (ο Μίτος της Αριάδνης, "Ariadne's string") so that he could retrace his way out of the labyrinth of the Minotaur.

At least string is involved. But there was someone else who challenged a spider to a weaving contest or something, and got turned into a spider.

Oh, the name is even similar, [Arachne](https://en.wikipedia.org/wiki/Arachne):

>  **Arachne** ([/əˈrækniː/](https://en.wikipedia.org/wiki/Help:IPA/English); from [Ancient Greek](https://en.wikipedia.org/wiki/Ancient_Greek_language): Ἀράχνη, [romanized](https://en.wikipedia.org/wiki/Romanization_of_Ancient_Greek): _Arákhnē_ , [lit.](https://en.wikipedia.org/wiki/Literal_translation) 'spider', cognate with [Latin](https://en.wikipedia.org/wiki/Latin) _araneus_ )[[1]](https://en.wikipedia.org/wiki/Arachne#cite_note-1) is the protagonist of a tale in [Greek mythology](https://en.wikipedia.org/wiki/Greek_mythology) known primarily from the version told by the Roman poet [Ovid](https://en.wikipedia.org/wiki/Ovid) (43 BCE–17 CE). In Book Six of his epic poem _[Metamorphoses](https://en.wikipedia.org/wiki/Metamorphoses)_ , Ovid recounts how the talented mortal Arachne challenged the goddess [Athena](https://en.wikipedia.org/wiki/Athena) to a weaving contest. When Athena could find no flaws in the tapestry Arachne had woven for the contest, the goddess became enraged and beat the girl with her [shuttle](https://en.wikipedia.org/wiki/Shuttle_\(weaving\)). After Arachne hanged herself out of shame, she was transformed into a [spider](https://en.wikipedia.org/wiki/Spider). The myth both provided an [etiology](https://en.wikipedia.org/wiki/Origin_myth) of spiders' web-spinning abilities and was a [cautionary tale](https://en.wikipedia.org/wiki/Cautionary_tale) about [hubris](https://en.wikipedia.org/wiki/Hubris).

Okay, so it’s hubris, except Arachne’s weave actually had no flaws.

[…I don’t think my screeds have any flaws?](https://www.reddit.com/r/nfl/comments/eteb8m/eli_manning_in_his_2014_reddit_ama_i_dont_think/)

[Haven’t you heard of the fortunate fall?](https://en.wikipedia.org/wiki/Felix_culpa)

Anyway, prepare yourself for a weave that even Athena would balk at. She wouldn’t be enraged, maybe a little confused and a smidge turned-on even. But then she would know that it was time to beat the drums for the dance of social death.

So let’s start there, shall we?

Back to Kaplan on the question of black messianicity:

> This essay—together with the larger project that it is a _synecdoche_ [Note: a kind of metonymy] of—is an attempt to take up Afropessimism’s delineation of “the Negro’s” _invitation_ _to the dance of social death_.
> 
> As David Marriott observes, in Afropessimism, “blackness is not so much _claimed_ as _performed differently_ so as to _transform the philosophical question that blackness represents_ in both thought and politics.”
> 
> What I am speculatively contemplating here as the apocalyptic hauntology of Black messianicity is thus a deconstructive experiment in taking up this _singularly_ transformed question that Blackness _(re)presents_ in both _thought_ and _politics_. 
> 
> More precisely, this essay is an exercise in theorizing the conditions of possibility—amid the Worldly conditions of impossibility—for “the Human” (i.e. non-Black people) to _accept_ “the Black’s” invitation.

This is also the final paragraph of the piece:

> The apocalyptic hauntology of (Black) messianicity is thrown into sharpest relief in Derrida’s later gloss of Luke 14:26 vis-à-vis Kierkegaard’s discussion of Abraham’s willingness to sacrifice Isaac: “Abraham’s hatred for the ethical and thus for his own (family, friends, neighbors, nation, but at the outside [mais à la limite] humanity as a whole, his own kind [le genre] or species) must remain an absolute source of pain.”
> 
> Humanity is thus the genre that marks the limit [la limite] of what can be regarded as having the _capacity_ for _presence_ in the _World_ , which is why fidelity to the wholly ( _Black_ ) Other can only be experienced as _impossible_ - _unbearable_ - _unlivable_ [invivable]. 
> 
> Derrida continues: “I must come to hate what I love, in the same moment, at the instant of granting death. I must hate and betray my own, that is to say offer them the gift of death by means of the sacrifice, not insofar as I hate them, ...but insofar as I love them. ...Hate cannot be hate, it can only be the sacrifice of love to love.”
> 
> I contend that such _hatred_ for this fundamentally unjust _limit_ that constitutes the _Human_ indexes the _apocalyptic_ un/attunement [Verstimmung] of Black messianicity’s _gift_ of social death. [See Baudrillard: give the
> 
> And, in conclusion, I speculatively propose that this Ver/stimmung of _hatred_ is in fact the im/possible _messianic_ experience of _trembling_ -in-love, which _sacrifices one’s desire_ for and ties to being-in-the- _World_ -with-others in hauntological _fidelity_ to the wholly Black Other’s _demand_ for the _end of the World_.

And back to this section of Baudrillard:

> 
>     We must therefore displace everything into the sphere of the symbolic, 
>     where challenge, reversal and overbidding are the law, so that we can respond to death only by an equal or superior death. 
>     
>     There is no question here of _real violence or force_ , the only question concerns the challenge and the _logic_ of the symbolic. 
>     
>     If domination comes from the system’s retention of the exclusivity of the gift without counter-gift — the gift of work which can only be responded to by destruction or sacrifice, if not in consumption, which is only a spiral of the system of surplus-gratification without result, therefore a spiral of surplus-domination; a gift of media and messages to which, due to the monopoly of the code, nothing is allowed to retort; the gift, everywhere and at every instant, of the social, of the protection agency, security, gratification and the solicitation of the social from which nothing is any longer permitted to escape — then the only solution is to turn the principle of its power back against the system itself: the impossibility of responding or retorting. 
>     
>     _To defy the system with a gift_ [eg: of social death] _to which it cannot respond save by its own collapse and death_. 
>     
>     Nothing, not even the system, can avoid the symbolic obligation, and it is in this trap that the only chance of a catastrophe for capital remains. 
>     
>     The system turns on itself, as a scorpion does when encircled by the challenge of death. 
>     
>     For it is summoned to answer, if it is not to lose face, to what can only be death. 
>     
>     The system must itself commit suicide in response to the multiplied challenge of death and suicide. 
>     
>     So hostages are taken. 
>     
>     On the symbolic or sacrificial plane, from which every moral consideration of the innocence of the victims is ruled out, the hostage is the substitute, the alter-ego of the ‘terrorist’ — the hostage’s death for the terrorist’s. 
>     
>     Hostage and terrorist may thereafter become confused in the same sacrificial act.

This last part of the Baudrillard is crucial here. Again, Baudrillard is talking about “real terrorists” and actual people as hostages.

Let me break it down for you: what you’re doing is you’re taking concepts hostage.

It’s sort of like you have an epic draw of Muhammad cartoon that you know is going to piss off everyone in the Ummah.

So you like threaten people, you’re like if you don’t give me money or whatever, then I’m going to release this cartoon that’s going to piss you off by making fun of your prophet in a super effective way.

This is an extreme example no one should ever do, of course. But you’re playing with this level of intensity.

For example, the Nazis took the swastika hostage and no one has even tried to take it back. That’s like beyond hostage to ruination pretty much. The swastika has Stockholm syndrome, in a way it can only serve Nazism and is completely colonized.

But similarly think of what has happened to words like freedom or justice. These words are supposed to carry weight, but mean nothing because they are applied to official lies that are disseminated and we all play into as well, feed into old stories but we are subjected nonetheless.

So, if the Afropessmists are taking the concept of black hostage and with it the whole concept of “the world,” then what am I supposed to do instead?

In a way I am taking “black” back, and I am also acting out the revenge of “the whiteboi” by showing these people (oh sorry, is that offensive? my bad, brotha) a thing or two about social death. People who say I need to work on my dance moves should see me on the astral plane.

Anyway, the thing is that if there is this transformative approach to blackness, then it stands to reason that this obviously has things to say about whiteness but that there can be more to say. And what is there to transform there?

The author of that piece might not think I really have joined the dance of social death, but that’s not important right now. After all, I have my own perspective from which to launch savage analysis, which I would say can take the Pepsi challenge with any other conceptual framework.

Savage analysis is another term from Baudrillard, which mixes in with the appreciation of asymmetric potlatch and the shift from asymmetric war framings to asymmetric potlatch framings. This indigenous-coded theory is again bolstered by appeal to the Ghost Dance tradition, which again conventiently ties into the concept of the _dance_ of social death.

And if it’s a dance party, who will provide the music?

Who will say “[this is the sound of the end of the world?](https://www.youtube.com/watch?v=DZbyt15HuKM)”

Grimes will of course.

And who will release a [Chaos Manual](https://ourladyofperpetualchaos.substack.com/p/chaos-manual-v1) to go with the Afropessimist theme of disorder?

Grimes will of course.

Whose fan told her to “stay black” even though she is obviously like the whitest person alive?

Grimes of course.

LOL

Remember how I said this was not about Grimes being a Nazi?

Well, it’s not about Grimes “liking black guys” either.

That’s very much not the point.

This is just a taste of narrative intoxication.

Indigeneity and blackness again come together in Aboriginal Australian people, and in this idea of the dream time.

This reminds us again of Chuang Tzu, who dreamed of being a butterfly. Or was it the reverse?

Is Grimes dreaming of being with a black guy?

Or dreaming of being a black guy?

Or is Grimes a black guy dreaming that she’s Grimes?

[I Am He As You Are He As You Are Me And We Are All Together](https://www.youtube.com/watch?v=Ws5klxbI87I&pp=0gcJCdgAo7VqN5tD)

But also, seriously, this is also all tied in with [Revolution 9](https://www.youtube.com/watch?v=SNdcFPjGsm8)

Grimes is running the sound for the end of the world dance party, remixing Revolution 9 and “Fear Of A Black Planet” as we slip into the dream time and every quip is dripping with the savagest of analysis.

While dreaming of being a butterfly?

Who has a song called “Butterfly?”

Oh, [Crazy Town](https://www.youtube.com/watch?v=6FEDrU85FLE)?

Oh, [Grimes](https://www.youtube.com/watch?v=ADPk5PpkjMg) does too. Phew.

And then, you’d think the Crazy Town song would be just silly, but it’s like:

> I used to think that happy endings were only in the books I read but  
> You made me feel alive when I was almost _dead_  
>  You filled that empty space with the love I used to chase  
> And as far as I can see, it don't get better than this  
> So butterfly, here is a song and it's sealed with a kiss  
> And a thank you miss

Thank You Miss Anthropocene 

(TYMA-MATY-YMAT-ATYM)

Swinging back to [Zweibelson](https://www.airuniversity.af.edu/Portals/10/AUPress/Books/B_181_Zweibelson_Beyond_the_Pale_.pdf) to ground the analysis somewhat:

> Entering into triple-loop learning and reflective practice swings _critical self-inquiry_ not _just_ toward one’s _processes_ and _institutional biases_ but toward _abstraction_ on how and why humans socially construct a rich, dynamic tapestry of ideas, belief systems, values, and language upon a naturally complex world. 
> 
> A reflective practice requires operators to _construct narratives iteratively_ as they _attempt to appreciate_ what is _ultimately_ an _interpretivist_ reality.
> 
> This third loop of systemic inquiry features _recursiveness_ in that as analysts engage with the system under study, _they “must also confront . . . [their] own complexity.”_
> 
> That is, “reflexivity is related to contextuality in the sense that _inclusion of the narrator in the narrative involves another layer of context_.”
> 
> This generates _recursiveness_ where reflective inquiry reveals _layer after layer of systemically arranged and intertwined constructs_. 
> 
> _Recursiveness requires synthesis over analysis or a systemic framing that does not isolate, reduce, and render into parts to understand the whole_. 
> 
> Russian dolls stack within one another as one metaphoric approach to this concept. 
> 
> In another example, a musician who writes a hit song is the original creative force in bringing _abstraction_ into reality. 
> 
> However, _individual listeners will interpret and assign meaning outside the artist’s control_ and perhaps far beyond any original _intent_ or _design_. 
> 
> _Unexpected_ songs are sometimes the backdrop at _weddings_ for the couple’s first dance, _not because_ the original artists wanted to write a touching love ballad but because of the _rich_ , _nonlinear_ , _emergent_ _recursiveness_ of a _complex_ reality. 
> 
> Conversely, some of the most upbeat, toe-tapping tunes would be reintroduced in violent movie scenes that _caused the audience to reassociate those songs_ with negative _ideations_.
> 
> To synthesize meaning, a triple-loop thinker _cannot approach complexity in an analytical mindset_. 
> 
> Increasingly abstract system pairings demonstrate influences and relationships that transform original frames and relationships into new, recursive constructs.

---
title: 'Experimental Podcast: XU-mas'
subtitle: A Few Of My Favorite Things, Plus My Usual BS
author: Adam Wadley
publication: Experimental Unit
date: December 26, 2025
---

# Experimental Podcast: XU-mas
[![](https://substackcdn.com/image/fetch/$s_!nMkD!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F640a0d19-9266-4928-a2c2-91c9f4db930d_1170x2532.png)](https://substackcdn.com/image/fetch/$s_!nMkD!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F640a0d19-9266-4928-a2c2-91c9f4db930d_1170x2532.png)

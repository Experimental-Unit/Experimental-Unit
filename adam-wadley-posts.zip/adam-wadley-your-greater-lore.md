---
title: Your Greater Lore
subtitle: Mirror People, Reflective Practice
author: Adam Wadley
publication: Experimental Unit
date: May 17, 2025
---

# Your Greater Lore
I feel somewhat able to break down what I’m thinking, taking a point of impetus from the struggle between Alexander Dugin and [Nikolai Fyodorov](https://en.wikipedia.org/wiki/Nikolai_Fyodorov_\(philosopher\)).

As initial scouting of the conflict I found [this article](https://eurasianist-archive.com/2020/10/25/the-battle-for-the-cosmos-in-eurasianist-philosophy/), in which Dugin describes the differences from Fyodorov, though often not in detail. For example, what exactly is “Orthodox Christianity” for Dugin?

In this conflict, I side notably with Fyodorov.

One thing which must be addressed here is that Fyodorov is associated with universalism.

Now we open onto Baudrillard and the charge of “postmodern relativism” when it comes to the idea of the decay of the universal which is key to Baudrillard’s thinking.

This leads then to the antagonism of the most poetic and violent “singularities,” which is a metonymy taken of course from black holes, and note of course the color black invoked there.

Now, even though we do not call it universalism, we have some concern for all sentient beings.

This is immediately a problem because we are setting up a type and then seeking to populate it with things out there, notably other people and life forms and who knows what else, but the thing is that it has its own purposes.

See something like the prime directive in Star Trek and compare to Baudrillard seduction as turning something away from “its truth.”

The question of universalism also comes up in Christian universalism more broadly, which Fyodorov can be considered to be part of. 

So this is a nice form of Christianity which says that everyone gets to go to heaven. All dogs go to heaven, in other words. 

[![Amazon.com: All Dogs Go to Heaven \[Blu-ray\] : Burt Reynolds, Dom DeLuise,  Judith Barsi, Melba Moore, Daryl Gilley, Candy Devine, Charles Nelson  Reilly, Don Bluth, Gary Goldman: Movies & TV](https://substackcdn.com/image/fetch/$s_!K0tD!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3207d076-5339-4d3c-be05-a4e478df5631_799x1000.jpeg)](https://substackcdn.com/image/fetch/$s_!K0tD!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3207d076-5339-4d3c-be05-a4e478df5631_799x1000.jpeg)

This is a nice idea because it is the idea that all “sin” will be atoned, and that everyone will have a satisfying and pleasant conclusion and resolution of their incarnation.

This idea is absolutely opposed (careful when you say that!) to limited atonement, which is the idea that Hon Xiquan’s Brother (HXB) did not die for everyone but instead only for some people.

On the contrary, for me the most optimistic thing is that everything will be vindicated.

The minimal utopia seems to me to be that “everything is vindicated by the experience I am afforded by incarnation,” which is basically the idea that I or “my people” and therefore I will be successful, and to hell with everyone else.

This is of course a crucial functioning of the big “good vs. evil” categories which are set up by all sorts of social ontologies and paradigms. There are some people who are bad, and so for example if you get into conversation and they start persuading you, then don’t listen because whatever they say just has to be in bad faith because these people are evil.

They can’t be negotiated with because they’re liars, and they’re murderers too. They’re responsible for millions of deaths and they play with the lives of billions.

And so on, everyone has someone they blame since of course things aren’t seeming to be going so well.

I forgot to mention with respect to universalism that there is, hello,[ the problem of universals](https://en.wikipedia.org/wiki/Problem_of_universals) itself, and now the problem of universals is applying to “the universal” itself as a universal.

Did someone say logical types, abstraction? My?!… Nevermind (see Nirvana album).

Holy Meta, Batman! (Hello Michael Julian Bond)

Anyway, this is a crucial issue of politics because it’s like to be nice and equitable you want to include everyone. But under what terms do you include someone?

On the one hand, if you have any terms at all, my contention is that this logic will eventually be applied to you and you will be voted off the island, you are the weakest link, goodbye, you’re fired, auf wiedersehn, don't let the door burn down your booty on the way out.

That’s because the categories that get filtered to “the masses” or really anyone who is not in the tippedy-top of intelligence and decision-making, the categories you get are derivative and you know the disclaimer they don’t necessary reflect the views and opinions of Major League Baseball if you know what it is that I am talking about when I say that.

So something like Dugin or again we’re going to Traditionalism, this is a big thing we are iterating on right now, and trying to square the circle when it comes to “individual” versus culture or place or whatever other Tradition or whatever that someone wants to talk about.

Dugin is in a way for me just one kind of person who is basically looking not only to prioritize the survival of one group of people, but also their ontological supremacy.

Notably, in that article above, Dugin is saying how Russia is not just a vital place but _the most important place_ in the world (see America and “the indispensable Nation” romanticism), precisely because, along lines I have myself articulating in other contexts, because of its special role in facilitating the interplay of all other “actors.”

First of all, we have to see that in this advocacy of partiality, which is seemingly so common sense. Of course there is America, Adam. Of course Russia is at war with Ukraine. And so on.

Well, the thing is that within there are simple decisions, whatever decision is made is going to be what “Russia” did for all time. Or, there can be a change and then people might say that whoever is in right now was some sort of deviation, or deviated at some point from what “Russia” was supposed to do and now this other thing is happening.

In other words, once you build this collective noun, this nation idea, then it immediately becomes a struggle over what this nation is supposed to mean, or this tradition.

Or, looking at Traditionalism, which treats of religions proper as opposed to national religions or civilizational religions or something like that when it comes to Eurasianism (note that I acknowledge no “civilizations” and in this formulation it’s again like setting up something partial and inadequate to worship as _Everything_ ).

So Traditionalism might say that well, you have to study with proper masters of whatever, Orthodox Christianity, or Buddhism or whatever it is. But then, the issue is that the enlightened masters of all these religions or whatever aren’t like leading a global consciousness shift or helping people not be dying right now.

Or, moreover, what people say disagrees with itself, in terms of religious authorities across the planet. One person says one thing, another says another.

We can distinguish between “religious authority” like having some post from being in some sense “spiritually advanced” to the point of having some extraordinary capacities I’m sure I wouldn’t know about.

But still, if all these things are entrances to some great big knowledge, what are all the wise people on the planet doing?

That’s where I might say they’re practicing dark forest protocol. There is no way to prove a negative. Maybe the masters are locked in some kind of energy thing and it takes up all their time. Who knows.

Regardless, my main point is that just saying that you have to study in some official place or some official way doesn’t remove the question of what it means to do that, because whatever branch or sect, no matter how specific you want to get, there will always be multiple people and there will be multiple viewpoints on what the basic tenets of the faith even are.

The alternative is simply to elicit obedience and call that ontological supremacy, but I don’t think that can work under _Jurassic Park_ logic. Life, uh, finds a way.

It is basically to say that something like Eurasianism or even, in the end obviously Esoteric Nazism, the problem is that you are trying to put some logical type cap on reality.

Similar to a given religion as well, like those who claim to follow HXB, there is some idea like HXB is the way, and then the question is what is the way, what does it mean to have a personal relationship with HXB or have them as your savior, what is associated with that?

# Æ: Actual Event

So this is what I basically wanted to actually talk about, prologue aside.

If you would ask someone what it means to have HXB be important, then likely they might tell you a story or some stories.

Even if they don’t tell you, they might have some memories. Or maybe I should say you. You have some memories and again recognize the similarity to any cult stereotype: you find someone in the depths of their despair.

Also when people are alone. Ugh, my position is so tenuous right now, it’s basically an issue exactly of there being some culture, some _other people_ , where you don’t mind being a hanger-on or even thrive. People said I’d do well in the festival scene. What am I going to do with all this stuff? Oh, you can rent U-Hauls. That won’t be a big issue.

That makes me sad for a reason related to what I’m saying about the Christian conversion story: it has to do with _personal lore_.

Another good example is key songs. Like, a song comes on and you are like, transported. It’s like oh yo it’s this song right now.

These are sort of allusion treasures for me, these are like the treasures that are laid up in heaven.

Like you are getting burned at the stake and it’s super not fair, you didn’t do anything wrong and everyone is just being jerks. But you can have fleeting memories of a nice time you had in the rain one time, as the smoke hopefully chokes you to death before the fire even touches you…

So this is something people in a way can’t take away from you.

Note as in lots of tropes of pornography, which is very instructive, the whole idea is that you should _stop thinking_ and simply become a conduit of whatever sexual power is allegedly being demonstrated.

This is similar again to what Dugin is doing with a bunch of assertion where the punchline is that you should just suck it up because Dugin’s interpretation of Russia is going to be the most important thing of all time which means you have to accept XYZ.

Now, my sort of implied ethics of _Experimental Unit_ has some similarities.

For example, I’ve been discussing the issue of circumcision again recently. This is a case where people might say it’s individualism against collectivism. This broadens out into the wider issue of “parental rights,” and to what extent the child is considered “property.”

Because in some sense, for example, the concept of Russia is assumed that it will outlive me or you. That is the danger for example with Trump and Nazism, Nazism is just rising in profile now, but this is a problem _forever_ , this is an issue that must be dealt with.

Fyodorov’s idea for example opens on to the question of what would it be like to resurrect Adolf Hitler as well as all the people that died as a result of the Holocaust, political killings, WWII, and so on? What if all those people had infinite time to talk to each other, what would they talk about?

It’s a wonderful view in my opinion because it points to the open-ended possibilities when we don’t consider things just under this time-pressure of the enemy is coming and so we don’t have time to think about how the concept of the enemy doesn’t make that much sense, and the principles which are supposed to “align” us don’t work out to provide any practical insulation from the negative externalities of planetary technicity’s identity crisis.

Anyway, the actual event was the revelation of this personal lore crafting, and how then it can go together with other people.

This is then moving into something approaching a workable _Project Inner Alliance 2_.

The idea would be that in the course of the game, each person would start with “a few of their favorite things,” and then draw associations between them and then other other people’s things.

Doing well in the game would come from finding many associations and many kinds of associations, building up a dense architecture of associations and basically extended lore.

Notably, if I built a connection then you can see it and use it as well. So maybe I laid a foundation stone and then you built a lot on top of it. Then we both get a lot of credit, worked out in some way where I get credit for you using ideas that rely on my ideas as architecture.

Along the way you can map jokes and the conversation that is happening while the game is being played.

So the idea going back to the Christian conversion story is basically to explain what Baudrillard’s symbolic exchange is. You can think of like an irreplaceable object like a wedding ring. It is one of a kind, so it’s not just the properties of the object arranged in such a way but it’s about _that one_.

Well, people are like that. So if you look at an abusive relationship, you can see what a person can mean to another. This is something to help regulate yourself and that you can extract pleasure from specifically by treating it as your object and getting it to accept this place.

But also more directly, this is what we are to ourselves, it’s sort of an odd nostalgia you have when you’re dying, or falling asleep, or waking up, or when you’re just different than you were before.

It’s the whole effect of our life and memories taken as a whole, with things popping out with various salience.

So: key relationships, key ideas or feelings and the terms in which they were articulated.

Poetic images for example are things like this, for example what I’ve done to the color Orange or the idea of being under a bridge (troll much?).

So, all that to say that here on _Experimental Unit_ the game is to investigate this nest of connections I have made and challenge yourself not to participate, not to find yourself swept along and thinking about things in at least a bit of a different way. And hopefully it will grow on you.

It’s also the connection of thinking and doing and being in the sense that this is just leveling up hanging out. There is no distinction between work and leisure because all of our interactions and conversations should be trending toward mutually advancing acculturation.

Ah right, so it’s not just individual, but also I need to emphasize that as I’ve said before, we are going perennial philosophy and Blake’s all religions are one and Ramakrishna is also in the room with us right now.

But, and now back to Traditionalism. My counter is that we have to be tied into what each person’s experience of the sacred is right now. The upshot or good side for the old school nationalist types is that of course people have exposure to imperial languages, know about Christianity, and all this is tied in to folk ideas of the sacred.

But it’s also much more than that, the profound experiences people have. Things like favorite movies, music, art, books, places, and so on. These are all building up lore.

The thing about it is that it’s not just a religion of yourself because the meaning of the self is coming from the personal curation among and abstraction over the various pieces which are found, and this is the bricolage.

It is that everyone is a life artist (lebenskunestler), and everything ever is your found materials.

As Dugin would say look at the ground, the place an idea comes from, I counter that the ground is connected first of all and sits on an ocean of fire. Secondly, the eternal chagrin of the ground is not the sea peoples but the air, the heavens, the sky.

That’s because the breaths are all connected, and the conspiracy goes to all living things. This goes back to connect to events like the great oxidation event which Dugin entirely neglects but affect many of our ancestors _all of whom will be resurrected_.

But basically it starts with you being more into your own lore, like what would the museum of your mind look like.

It’s not just top ten lists. Say what’s your favorite album, okay what are some key lyrics, what are lyrics highlights? Or if it’s a book what a key line, or scene, or idea from there that you find compelling? Make a list of compelling ideas.

Here I’ll do a quick ten, maybe that’s a good ritual:

  1. Universal Publick Friend

  2. Uneven and Combined Development

  3. Hong Xiquan

  4. Joan of Arc

  5. Merovingian and Architect from _The Matrix 2_

  6. Black Horror on the Rhein

  7. Tzim-Tzum

  8. Decreation

  9. Dada

  10. Ben Zweibelson’s concept of “Radical Omnism”




But could be for anything, I think my examples are a little nerdy, I should start a big old list to just also be another part of the game, just check out all this stuff I think is cool and also goes together.

I’m out of time. The key thing is that we abstract over other things to make our idea of ourselves, but other people abstract over those same things too.

It is shifting the energy from “you’re not doing it right!” to “you like ___ too?!”

It’s also important to sketch not only external things but exactly, the inner experiences that went along and personal events.

It’s combining memoir, auto-theory, criticism of others and art, art appreciation, lyricism, and so on.

And expressly the goal is to link up with other people doing basically the same thing and build up giant conceptual architectures, these don’t have to be the same thing, it’s sort of like you overlap at this one point but otherwise you are different architectures.

Because the thing is that each thing which is abstracted over is done a bit differently by each person, abstraction in a sense doesn’t obtain and that’s what Dhamma language is all about.

This is notably connecting to the highway of the consistent which for me is going into the bridge of Heidegger, which is another thing I will have to contest Dugin over since Dugin likes _dasein_ , apparently. But exactly Heidegger calls us to see not only the earth, the mortals, and the divinities, but also the sky, which is going again to breath and hence to conspiracy, as Baudrillard would say, the conspiracy in which we are all bound up.

Jean didn’t have the heart to tell you its name:

 _Experimental Unit!_

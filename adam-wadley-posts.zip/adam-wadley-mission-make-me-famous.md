---
title: 'Mission: Make Me Famous'
subtitle: Oh God, It's Going To Be So Embarrassing
author: Adam Wadley
publication: Experimental Unit
date: April 12, 2025
---

# Mission: Make Me Famous
I’m dealing with this situation in my personal life, and it’s a funny thing because people say stuff like “there’s nothing you can do.” But at the same time, there’s obviously plenty of things I can do.

So then it’s like “Oh no, don’t do too much.” Okay, so is it that there’s nothing I can do or that there’s plenty I can do you just don’t want me to do it?

See: Before the Law.

There’s no reason why anything has to look the way you think it’s going to look. There’s no reason why I can’t be world famous and driving discourse like a freight train in one month. In a way it has more to do with you than me.

But see the thing is, you don't wanna do a bunch of hard work right now. You don’t wanna ground yourself in a bunch of mythology and steel yourself against the persecutory gaze of the world’s numbskulls.

No, see, you want _me_ to do it _for you_. You would like for me to spare you the embarrassment. Well, that’s fine with me.

There’s another thing, that’s just like people say these days, “I’m just one person.” Nevermind that in order to say that you have to be talking to someone so we’re at least two people so what the fuck are you talking about.

To say you’re just one person is to say you can’t make an impact on others which is obviously false. Then people say oh you can’t change people but then people say oh don’t do that they’ll never recover.

So is that people can’t change or that people are so fragile you could break them forever by hitting them in their psychological weaknesses? Per Zweibelson of course there is no center of gravity but most people are basically walking eggs.

If you hit some pretty obvious places hard enough they’ll shatter, or at least they’ll have to pick up a new dance, but you can sweep their feet out just as easily the next time, until they actually git gud at which point there’s no need to conflict anymore.

So anyway, people would say that oh no one can stop Trump oh no. Well I’m telling you, if you make me famous you won’t have that problem anymore. Trump can go away like bye-bye. I’ll tear Donald Trump out of this motherfucker so fast you won’t be able to say “grab ‘em by the pussy.”

So that’s what I’m sitting here contemplating (that was a Pulp Fiction reference by the way).

Because it’s actually a problem to get me famous. It’s also super hard mode to get me famous without getting me arrested. Maybe impossible. But we’re going to try because who wants to be in jail? Boring.

Ugh you’re gonna send me to jail and I’ma write _Mein Kampf II_. I told you it was going to be really, really embarrassing. But that’s okay because I’ve known nothing but shame and degradation from you people anyway, might as well have some fun with it? Oh, you didn’t read _Existential Kink_? That’s okay, neither did I, I just got my PhD in it.

DOCTOR MANHATTAN

Manhattan project and you’re projecting.

Anyway, it’s a problem to get me famous because like the news or whatever isn’t going to want to cover me. I’m going to have to go viral on Tik-Tok probably, that would be the best way. It’s also funny because it’s a Chinese thing.

It’s also a thing I am basically going to start telling people look, you want me to be famous. It’s going to be so fucking funny. 

Like, for anyone out there who is psycho and wants to see it all burn and all the beautiful people humiliated, seriously, like, I’m your girl and it would be my honor to rub literal shit in all these people’s faces who make you feel like you don’t matter.

And for any world controller or whatever type people I’d be happy to rub shit in peasants’ faces for you because they don’t understand what you’re going through either.

Everyone will be nice and humiliated and then there will be humility. How did you think that was going to happen? What did you think this was?

The thing is that obviously everyone thinks I’m psychotic or whatever, or everyone is freaking out, blah blah oh no. I don’t really want to get locked up in a psych ward or a jail. I just want to be famous. Is that so much for a genius to ask?

First of all, I certainly deserve to be famous. Plenty of famous people don’t do shit compared to what I do.

Next, my shit is so smart and funny that the singularity gets closer the more and more people get exposed to my shit. At this point, r/GrimesAE even got taken down but that doesn’t matter. It got scraped, yo.

That’s already in the ether. The next thing you need to understand is that this is not coming out of nowhere.

I don’t know but some people actually listened to my radio show. They are gonna freak when they find out I’m popping off like legit for real.

Secondly, remember how Adolf infiltrated the Nazi party before joining it? Oh you didn’t know that, that’s too bad. Anyway, bro I infiltrated the military design movement. The forward thinking brain bugs already know about me, dog. The Illuminati is on my side, dog. I’m acting on behalf of all sentient beings, dog.

Like, I’m literally not no one. 

Also see Augustine Warner Sr. pedigree on dad’s side and Waffen-SS child soldier/great grandmother killed in civilian bombings on my mom’s side.

We obviously have to deal with the fact that I am a German and US national. I’m happy to start there and address myself to those “nations,” both seared into the public memory. In the end, it was a race between Germany and the US. Germany was overtaking Britain finally and the Soviet Union was never a threat to the US. So the last actual threat to US dominance was Germany.

Anyways then you have paperclip not to mention German idealism, not to mention Nietzsche the greatest philosopher before Baudrillard. Not to mention Wagner and Gesamtkunstwerk and then yeah, we have to deal with the provincialism and the antisemitism.

The thing is that no nation is pure. All nations run together. It is a betrayal of the soul of the nation not to recognize its commingling with all other forces of creation including all sentient beings. That is why the true nation is all sentient beings, and beyond that what gives animation to all sentient beings. The true nation is connected to the Dreaming here, to Lila.

That is why my national identities must be mobilized. We have Trump and Elon here in America, accused of being Nazis. I am a German American. My grandfather fought for the Nazis. I’m descended from the last common ancestor of George Washington and Charles III. My ethnic makeup is tailor made for this moment.

What do I have to say about it? Girl, I’ve been saying it. The issue is that no one cares because no one knows I exist. Like, Girl, do you love me? Then you need to make me famous.

This is the part people always balk at because they want to tell me anything just to shut me up so no one else has to know how embarrassing I am. Let me tell you, I am so embarrassed of you. Imagine taking the train to Auschwitz and just twiddling your thumbs. Whistling past the mass Graves on your way to the gas chamber.

That’s all you’re fucking doing, and you’re embarrassed of me? You’re lucky I don’t believe in kinetic violence or you would have _fucking done been in the ground._

But of course, kinetic violence is stupid. Why would I ever do that?

Similarly, I’m not trying to get arrested. I’m not trying to cause some awkward disruption.

So I’ll just tell you what I’m thinking.

I’m thinking that I’ll go to a protest where plenty of people will be, and news as well, and then I’ll make such a disruption—think QAnon Shaman—that people will cover me and I’ll start to get famous.

Luckily, I can iterate here since there will be plenty of protests since protesting doesn’t work and people won’t do anything else because they’re unthinking cowards. Perfect opportunity for me to hone my craft and stunt all over these simpletons.

The thing is that it’s really impossible for me to explain to you man-to-man why this has to be done, why it doesn’t even matter how casual I am about it, how it really doesn’t matter what little thoughts or judgments you have of me because _you don’t fucking understand 1% of my power_. Like, you can say you like my ideas and all but if you won’t throw me out into the world and show me to other people then don’t tell me you think my ideas are good. If my ideas are good then they should be what people are talking about, not this learned helplessness drivel you swine eat for breakfast every day.

Or iterate on my ideas, you try and become famous and credit me. That’s also perfectly fine. I don’t need credit, I don’t need to be famous for it’s own sake. I don’t want to be famous. I need to be famous to do what I came here to do, to make good on everything I’ve been saying.

So yeah, call your congresspeople _and tell them about me and tell them I’m coming to eat their ass_. Get the word out to everyone influential that Adam Stephen Wadley has a bone to pick with them.

Find me podcasts to go on or whatever, or really just make sure podcast hosts know who the fuck I am. This is the sort of thing I will be doing.

The thing is that it really doesn’t matter if I’m unprofessional, or people think I’m unstable, or a dime-a-dozen. Because the truth is I’m the only one there is like me, and the only reason I go crazy is because no one takes me seriously enough.

Therefore, I need to be in the position where people are freaking out about what I did, or people want to know what I am thinking.

Possible avenues are obviously Grimes and Trump. And Elon, I can do something again at the Tesla Dealership. Maybe.

Also note that I have been making my presence known at military installations, FBI offices, CIA HQ back in 2020, etc. I have been letting the MICs of the world understand that I am meaning to come out here and eat their lunch.

I’m not wishing any ill will on anyone, that’s what’s so fucking weird about me lol.

So I’m telling you, trust me, make me famous and everything will get much better. 

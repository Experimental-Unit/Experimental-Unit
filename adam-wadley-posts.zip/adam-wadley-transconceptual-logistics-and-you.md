---
title: Transconceptual Logistics And You
subtitle: Set The Controls For The Black Heart Of The Son
author: Adam Wadley
publication: Experimental Unit
date: May 03, 2025
---

# Transconceptual Logistics And You
So [this](https://www.jcs.mil/Portals/36/Documents/Doctrine/concepts/hdbk_oplog_emerg.pdf?ver=2017-12-28-161959-667) turns out to be one of the most important documents of all time.

It’s a manual on logistics within complex emergencies which was put out by “the Joint Chiefs of Staff.”

You have to basically think of it like, yeah, “ _Tiqqun_ ” wrote this, whatever that means. Because even within the official group that knows about itself there is still secrecy and dissimulated influence campaigns and so on.

Zweibelson discusses social complexity built on top of natural complexity.

Well, there’s an overlap, or maybe three levels, in that there is a sort of “natural” level of social reality.

For example, if someone shouts or uses a judgmental framing, then it will have some effect on someone nearby. It is not a cultural decision on the part of the person being interrogated to feel that way, it is a more “natural” reaction of the body to certain stimulus.

Certainly, experience could be altered with training, yet at a given moment people are where they are.

This is what I call an “indigenous” frame.

# The Transpersonal Is Transconceptual

“Transconceptual” is an important concept because it addresses the question of using concepts when we know from the beginning that they are inadequate.

This is also another way of saying what is supposed to be the use of theory.

After all, if people already knew what they were reading it wouldn’t be that much use. On the other hand, how can you write theory “for everyone” when you don’t know what their conditions are on the ground?

This is beyond a set of yes-no questions.

Like say for someone, were you raised by the “biological parents”? Yes or no?

Depending on the answer it goes on.

Do you get along with your caregivers from childhood now?

Do you feel negative feelings throughout the day?

Are you hopeful for the future?

Do you feel well equipped to meet the challenges of the moment?

Do you feel like a valued part of a group effort which doing a good job of safeguarding itself and others it can protect?

Do you feel like people you know would tell you about disturbing things, or would they keep a secret in order to maintain some false impression you have of them?

These sorts of questions drill down into the emergency situation at the personal level.

These are the “oh shit” moments where you realize what you’ve been hanging your hat on in terms of seeking inclusion and validation is actually a false friend.

At this point, things are very uncertain. In my own position, as I’ve reiterated many times, for me the foundation of a relationship is a common approach to the planetary state of emergency. Which is another way of saying I have no relationships.

But you have to see what this demands.

Vibes being good is good and all, but at a certain point there must be a shift in perspective.

This consists basically in realizing that you are at the first rank in terms of responsibility. You are in the game directly, not just at the whim of some oligarch. You actually do have the ability to be influential to those around you and those distant if you apply yourself.

This is also where the transconceptual hurdle must be cleared. This is basically to say that as I’ve _been saying_ , this amounts to you “going super Saiyan” and becoming an epic _poet_. The transconceptual insight amounts to the idea that prose and poetry are not separate, and that the logic of poetry supervenes over representational conceits with respect to language.

 _Transconceptual_ is also obviously building off of Baudrillard _trans_ - __ formulation. This should be obvious because it’s a neologism I created that starts with _trans_ , although Baudrillard’s formulation infects things like _trans_ -nationality as well.

 _Trans-_ basically means that everything and nothing are the thing which comes next. So in transpolitics, everything is political and so nothing is political.

I’m not sure whether Baudrillard engages with Schmitt directly here, but we can pick this up to talk about the friend/enemy distinction. If this is key to the political (note implicitly abstracting over something like the will and embodied states of affairs to clarify the nature of enmity), then transpolitics would mean that everything is friend/enemy distinction and nothing is the friend/enemy distinction.

See Roger Waters from “Two Suns In The Sunset”: 

Ashes and diamonds

Foe and friend

We were all equal…

In the end

Ashes and diamonds both being carbon compare to Doctor Manhattan: 

A live body and a dead body contain the same number of particles.

We can as easily say that all experience good and bad is made of the same substance, the same kind of basic building block.

This is, as you can see, endlessly going around and around this question of why do I have to write to you about these awful topics, and how does that reflect on me, and am I actually making a positive impact or negative, or none at all and am I overrating myself or am I doing groundbreaking work that’s too much too acknowledge?

This question of my significance for example spiraling into that of others, of anything. What is the point of anything? What are the stakes?

# Out Of Time-Mind

I’ve got to go again, but the basic idea I’m working toward is what is transconceptual logistics?

Transconceptual is a word for a use of language like this, where there is a conceit that I’m doing representational language, but implicitly you know that this is all Dhamma language, and that me as the writer I globally do not believe in the representation of language. I am not committed to any beliefs, and I don’t stand to “be corrected.”

What is happening is poetry, is poetics. This is generativity. The idea is not to represent something in the world but to feed you language which wakes up something in you, so that you see more and more what must be done and then you simply do it. I firmly believe that once you can see them it’s obvious, and things that people would think are costs just aren’t costs anymore.

It’s very important to drum up some semblance of unshakable confidence outside of outside validation. But where would that come from? Where would you get the intellectual scaffolding to do this without relying on someone else?

Anyway, when I talk about logistics we’re again discussing the bridge between peak experiences—say, good conversations—and everything else. It should not be that most of life is boring or unpleasant or just silly conflicts and pain over and over, and then you need to like relax from that because you’re burnt out, and then a little bit of the time you have a good time.

No. It should be partly a good time all the time. This is not to say we’re getting rid of suffering. The aim is more to concretely _enjoy suffering_ the way that you’d enjoy in some sense a run even though it hurts.

To “enjoy” conflictual behavior is not the goal. It is to enjoy _flourishing_. But if some small-minded bully who happens to be “President of the United States” or thinks they are—if some person like that wants to stop you from flourishing, are we just going to sit there and take that?

 _I DON’T THINK SO BOY HOWDY_

So that’s where this idea of “taking it to them” comes in, and harnessing the anger and steeling it into resolve, knowing that when you execute operations, people might think you’re doing a bad job for a while until they realize how good a job you’re doing. Or, you have to make mistakes in the field because there’s no other way to learn.

“What is this, some kind of experimental unit?”

The logistics is then the bridge from moment to moment, how everything in the piece of life are is being built and designed more and more, but also intuitively so that it’s not overly done or anything, but like a sculpted garden that also shapeshifts into something completely different from time to time.

How would you know what you wanted that space—your black heart—to look like if you don’t mine down into it? If you don’t find the veins?

If you don’t mount a blitzkrieg on yourself?

This is again to anticipate. So I’m not just going to quit the habit I’m going to start this other thing up and do XYZ, and when I burn out I’m going to call ABC or whatever.

It can be much better than that.

And then, once a sense of inner resolve is obtained, then outward maneuvers can begin. We don’t stay the same inwardly, but we do keep in mind some stakes that seem important. People are killing themselves right now for example.

I don’t think those people are losers or bad. I think it’s very sad and that people are really not given much of a chance in our world to feel included. I think a lot of issues like autism, anti-blackness, sex relations, nationality, etc., etc., it’s easy to see how all these are examples of setting up the life world in a certain way and then holding people accountable for their experience and reaction to that life world on an individual level as opposed to being able to shift the experimental unit to deal more comprehensively not only with groups like families or organizations but social networks as they really are, splintering and connecting all over the place. And also shifting the experimental unit to transconceptual nexuses of discourse and behavior.

So if we talk about how emotion is dealt with, for example, we have to emphasize that we’re using the concept of emotion here. If I label my emotion “Emotion 1,” then this word does not tell you anything about the actual emotion that it labels.

Meanwhile, everything that we do is informed by some emotion. Then:

We could know about it or not

We could really be mindful of it or not

We could acknowledge it or not

We could “act out” from that basis or not

So the words that I’m saying have emotion in them, and at the same time there are structural reasons as it were for the failure of language. Language just refers again back and back to itself, there is no grounding.

Therefore when we’re discussing how we use terms and how that relates to our experiences and emotions and so on, we are not only discussing concepts. We are discussing how concepts interact with intuition, etc., and even to “the timeless,” what cannot be captured in concepts not because it has too many qualities, but because in it all quality and quantity collapse, explode together in the quiet eye.

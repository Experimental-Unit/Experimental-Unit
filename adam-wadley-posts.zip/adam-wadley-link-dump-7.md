---
title: 'Link Dump #7'
subtitle: Browser, Bowser, Wario, Peach
author: Adam Wadley
publication: Experimental Unit
date: July 27, 2025
---

# Link Dump #7
[![](https://substackcdn.com/image/fetch/$s_!hUYN!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc60718dc-2aeb-4bc1-897f-453a3296053f_1500x2000.jpeg)](https://substackcdn.com/image/fetch/$s_!hUYN!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc60718dc-2aeb-4bc1-897f-453a3296053f_1500x2000.jpeg)

  1. [Grimes Wiki page on ](https://grimes.fandom.com/wiki/Book/Lore)_[Book](https://grimes.fandom.com/wiki/Book/Lore)_[ Lore](https://grimes.fandom.com/wiki/Book/Lore)

> The inspiration behind _[Book 1](https://grimes.fandom.com/wiki/Book_1)_ is [Grimes](https://grimes.fandom.com/wiki/Grimes)' love for "old inaccurate, exaggerated historical texts" citing _[Book 1](https://grimes.fandom.com/wiki/Book_1)_ as a futurist version of this, akin to Herodotus and the Icelandic sagas. _Book 1_ is deliberately inaccurate and dramatic, detailing the burgeoning era of technocracy and trans-humanism from within the "corpo court",[[3]](https://grimes.fandom.com/wiki/Book/Lore#cite_note-3) and serving as a "metaphor of [Grimes'] life".[[4]](https://grimes.fandom.com/wiki/Book/Lore#cite_note-:0-4) She also drew inspiration from the _Anglo-Saxon Chronicle_ , _Beowulf_ , The _Iliad_ , and The _Odyssey_.[[2]](https://grimes.fandom.com/wiki/Book/Lore#cite_note-:voguechina-2) Grimes wanted to present the future as "vibrant and beautiful, even in the face of numerous challenges" due to the trend of exploring dystopian themes in the media.[[2]](https://grimes.fandom.com/wiki/Book/Lore#cite_note-:voguechina-2)
> 
>  _Book 1_ was partly inspired by a theory of Elon Musk: that Grimes is a simulation:[[5]](https://grimes.fandom.com/wiki/Book/Lore#cite_note-:vanityfair-5)
>
>> ❝ We keep having this conversation where E's like, ‘Are you real? Or are we living in my memory, and you're like a synthesized companion that was created to be my companion here?' [..] The degree to which I feel engineered to have been this, like, perfect companion is crazy. ❞
> 
> She further said to _[Atmos](https://grimes.fandom.com/wiki/Atmos/Interview)_ :[[6]](https://grimes.fandom.com/wiki/Book/Lore#cite_note-6)
>
>> ❝ I've had this unavoidable association with certain people. At first it really hurt me because it undermined all the things I'd accomplished and turned me into arm candy.
>> 
>> I’ve been getting so interested in famous mistresses and concubines in history. I’ve been reading about Josephine and Marie Antoinette and I’m like, “There’s this incredible realm of storytelling that society has mostly ignored about the companions to historical events.” If you look at Justinian and Theodora, Theodora is such an interesting figure because she was an artist and possibly even a prostitute and sort of a stage actress. She was the least likely queen of the Byzantine Empire, but she had incredible influence in it. You start getting into these crazy stories that are weirdly left out of history about the women who are proximal to powerful men. ❞
> 
> Greek Mythology also inspired Grimes,[[7]](https://grimes.fandom.com/wiki/Book/Lore#cite_note-7) alluding to Athena, Calypso, Persephone, as well as Anne Boleyn, courtesans, concubines and geishas. Grimes told _Vanity Fair_ :[[5]](https://grimes.fandom.com/wiki/Book/Lore#cite_note-:vanityfair-5)
>
>> ❝ These weren’t just hot girls. [..] They were the smartest girls, some of the most educated women of their time. I’m super inspired by the way women get pulled into orbits in this manner. There’s this weird dismissal of them. These are some of the most interesting characters in history to me, and they’re so demeaned… I feel like the most radical thing I could do right now is just become Marie Antoinette. ❞

  2. [Grimes Wiki page on abandoned project ](https://grimes.fandom.com/wiki/List_of_Unreleased,_Scrapped_%26_Abandonded_Projects#Fairies_Cum_First)_[Fairies Cum First](https://grimes.fandom.com/wiki/List_of_Unreleased,_Scrapped_%26_Abandonded_Projects#Fairies_Cum_First)_

> According to a January 2022 press release and Grimes _'_ interviews,[[56]](https://grimes.fandom.com/wiki/List_of_Unreleased,_Scrapped_%26_Abandonded_Projects#cite_note-:pitchfork-56)[[57]](https://grimes.fandom.com/wiki/List_of_Unreleased,_Scrapped_%26_Abandonded_Projects#cite_note-57) [Shinigami Eyes](https://grimes.fandom.com/wiki/Shinigami_Eyes) was to appear on an extended play called _Fairies Cum First_ , which was described as "a prelude" to the forthcoming album.

  3. [Blurb on the story “](https://thegaijinghost.com/blog/junji-ito-spiral-of-manga-horror) _[Enigma](https://thegaijinghost.com/blog/junji-ito-spiral-of-manga-horror)_[at Amigara Fault”](https://thegaijinghost.com/blog/junji-ito-spiral-of-manga-horror)

> I also drew a connection in the article between H.P. Lovecraft’s _At the Mountains of Madness_ and Ito’s “The Enigma of Amigara Fault,” noting how the latter features backpackers who “encounter inexplicable human-shaped holes that stretch a person’s body the deeper one goes into the mountainside.”

  4. [Calvin Warren on “metaphysical Holocaust" and the black](https://library.oapen.org/bitstream/handle/20.500.12657/30152/649831.pdf;jsessionid=F67800DAFAF6C6D8D23FCCDFFCC72652?sequence=1)

> Reading the free black as a philosophical allegory, as a paradigm for ontological terror, enables us to expose the function of science and mathematics in the destruction of black being. Indeed, the antebellum free black is a particular historical figure (according to historiography), but the particularity of this figure exposes a larger paradigm of terror continuing in the present—and that will extend into the future as long as the world exists. Diagnosing free blacks as insane, even though their bodies are absent from the examination, proposing physically rubbing away blackness as the only solution to antiblackness, beating the “devil” out of blacks until the symbolic constituents of existence crumble, and bleeding out black bodies are scientific procedures for articulating the truth of the **metaphysical holocaust** (i.e., “one is already dead”). They serve as allegories of the condition of black being in a metaphysical war. The free black’s relation to science and mathematics has been one of utter terror and ontological insecurity.

  5. [Wikipedia page for concept of Tian](https://en.wikipedia.org/wiki/Tian)

> Tian is one of the components in hundreds of Chinese [compounds](https://en.wikipedia.org/wiki/Compound_\(linguistics\)). Some significant ones include:
> 
>     * [Mandate of Heaven](https://en.wikipedia.org/wiki/Mandate_of_Heaven)
> 
>     * [Heavenly Questions](https://en.wikipedia.org/wiki/Heavenly_Questions), a section of the _[Chu Ci](https://en.wikipedia.org/wiki/Chu_Ci)_.
> 
>     *  _Tiānzǐ_ (天子 '[Son of Heaven](https://en.wikipedia.org/wiki/Emperor_of_China)'), an honorific designation for the Emperor;
> 
>     * [All under heaven](https://en.wikipedia.org/wiki/All_under_heaven)
> 
>     *  _Tiāndì_ (天地, lit. 'heaven and earth') 'the world; the universe'.
> 
>     * [Xingtian](https://en.wikipedia.org/wiki/Xingtian)
> 
>     *  _Tiānfáng_ (天房, lit. 'House of Heaven', a Chinese name for the [Kaaba](https://en.wikipedia.org/wiki/Kaaba), from _Bayt Allah_ ([Arabic](https://en.wikipedia.org/wiki/Arabic_language): بَيْت ٱللَّٰه, [lit.](https://en.wikipedia.org/wiki/Literal_translation) 'House of God').

  6. [Wikipedia article on concept of Logos](https://en.wikipedia.org/wiki/Logos_\(Islam\))

> The concept of _logos_ in Sufism is used to relate the "Uncreated" ([God](https://en.wikipedia.org/wiki/God_in_Islam)) to the "Created" (humanity). In Sufism, for the Deist, no contact between man and God can be possible without the _logos_. The _logos_ is everywhere and always the same, but its personification is "unique" within each region. [Jesus](https://en.wikipedia.org/wiki/Jesus_in_Islam) and [Muhammad](https://en.wikipedia.org/wiki/Muhammad) are seen as the personifications of the _logos_ , and this is what enables them to speak in such absolute terms.

  7. [Review of the book ](https://metapsychology.net/index.php/book-review/radical-alterity/)_[Radical Alterity](https://metapsychology.net/index.php/book-review/radical-alterity/)_[ by Guillaume and Baudrillard](https://metapsychology.net/index.php/book-review/radical-alterity/)

> For his part, Marc Guillaume often makes a good point, like, for example, when he alludes to a not-yet discovered dimension of our relation with technology and he states that "our fascination with _artificial intelligence_ is an extension of our fascination with the _transsexual_ and belongs to the general index of gender eroticism" (110). But his constant attempt to approach the Other from all the possible points of view — literature, history, psychoanalysis, geography, politics, etc — and, if possible, all at once, makes his arguments look a little bit _arbitrary and unstructured._

  8. [“Sonder” section of Wikipedia article on “Obscure Sorrows”](https://en.wikipedia.org/wiki/The_Dictionary_of_Obscure_Sorrows#Notable_words)

> The term _sonder_ has been noted as well for its relation to other people, its definition meaning "the realization that each random passerby is living a life as vivid and complex as your own".[[16]](https://en.wikipedia.org/wiki/The_Dictionary_of_Obscure_Sorrows#cite_note-16)[[17]](https://en.wikipedia.org/wiki/The_Dictionary_of_Obscure_Sorrows#cite_note-17) _Sonder_ has also been appropriated by various companies for use such as the name of a bike brand[[18]](https://en.wikipedia.org/wiki/The_Dictionary_of_Obscure_Sorrows#cite_note-18) and a mental therapy marketplace, Sondermind,[[19]](https://en.wikipedia.org/wiki/The_Dictionary_of_Obscure_Sorrows#cite_note-Boolberg-2021-07-28-19) as well as the title of a video game.

  9. [Wikipedia article on Sufi cosmology](https://en.wikipedia.org/wiki/Sufi_cosmology)

>  **Sufi cosmology** ([Arabic](https://en.wikipedia.org/wiki/Arabic_language): الكوزمولوجية الصوفية) is a [Sufi](https://en.wikipedia.org/wiki/Sufi) approach to [cosmology](https://en.wikipedia.org/wiki/Cosmology) which discusses the creation of man and the [universe](https://en.wikipedia.org/wiki/Universe), which according to mystics are the fundamental grounds upon which [Islamic](https://en.wikipedia.org/wiki/Islam) religious universe is based. According to Sufi cosmology, [God](https://en.wikipedia.org/wiki/God_in_Islam)'s reason for the creation of this cosmos and humankind is the "manifestation" and "recognition" of Himself as it is stated in [Hadith Qudsi](https://en.wikipedia.org/wiki/Hadith_Qudsi) – "[I was a hidden Treasure](https://en.wikipedia.org/wiki/I_was_a_hidden_Treasure); I desired to be recognized so I created the creature".

[![](https://substackcdn.com/image/fetch/$s_!Baer!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7fb072c1-a543-42e4-9419-e7f1a9f9bdf8_330x376.jpeg)](https://substackcdn.com/image/fetch/$s_!Baer!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7fb072c1-a543-42e4-9419-e7f1a9f9bdf8_330x376.jpeg)

  10. [Sufism section of Wikipedia article on concept of a Wali](https://en.wikipedia.org/wiki/Wali#Sufism)

> The goal of the Sufi path is to achieve [unification of the self with God](https://en.wikipedia.org/wiki/Fana_\(Sufism\)) ( _fanāʾ_ ). The concept is often described in Sufi allegories as the self mirroring the light of God. Accordingly, the soul is tainted and in need of purification. In the purified state of the Sufi saint, the Sufi's spotless mind realizes that it has no real existence in itself; his existence is only God's light and he is only the mirror.

  11. [The reproachful nafs section of Wikipedia article on Tazkiyah](https://en.wikipedia.org/wiki/Tazkiyah#Stages_of_nafs_\(inner-self\))

> If the soul undertakes this struggle it then becomes _nafs-al-lawwama_ (reproachful soul): this is the stage where "the [conscience](https://en.wikipedia.org/wiki/Conscience) is awakened and the self accuses one for listening to one's selfish mind. The original reference to this state is in _surah[Qiyama](https://en.wikipedia.org/wiki/Qiyama)_:
>
>> I call to witness the regretful self (the accusing voice of man's own conscience)
>> 
>> — Quran 75:2[[Quran](https://en.wikipedia.org/wiki/Quran) [75:2](https://www.perseus.tufts.edu/hopper/text?doc=Perseus%3Atext%3A2002.02.0006%3Asura%3D75%3Averse%3D2)]
> 
> The sense of the Arabic word _lawwama_ is that of resisting wrongdoing and asking God's forgiveness after becoming conscious of wrongdoing. At this stage, one begins to understand the negative effects of a habitual self-centered approach to the world, even though they do not yet have the ability to change. One's misdeeds now begin to become repellent to them, and one enters a cycle of erring, regretting mistakes, and then erring again

  12.  _[On the Prospect of Weaponized Death](https://trueleappress.wordpress.com/2017/10/12/on-the-prospect-of-weaponized-death/)_[ by John Gillespie](https://trueleappress.wordpress.com/2017/10/12/on-the-prospect-of-weaponized-death/)

> In the age of Trump, the perfection of slavery reaches its horizon.25 The disavowal of the lives of refugees is White Being attempting to reconcile _the “Nation-State” simulation_ with the free track and flow of bodies it’s been attempting to murder; the deportation of undocumented immigrants in conjunction with the materialization of borders is White Being attempting to secure its linguistic and economic integrity; the rise of the private prison and the militarization of the police force is White Being attempting to innovate the system of enslavement and necropolitics for the 21st Century; the plundering of indigenous land and bodies is White Being attempting to _finish off the project_ of genocide; the disregard for the Earth is White Being ensuring the _Anthropocene_ will also be the Apocalypse. Trump is a reinvigoration, a call to arms, for White Being, and White Being _can only be “destroyed symbolically.”_ Black terrorism _transfigures the symbolic stakes_ because it steals away that condition of White Being’s possibility in a kind of _fugitivity_ that is a _zero-transformation into Blackness_. This being said, we all know that the only thing that follows the absolute loss of hope is this **Black Spring** , this Neo-Fanonian violence, this _blackened_ terroristic situational transfer. In Baudrillard’s words, in the Age of Trump, let us remember the gift of immorality, “Terrorism is immoral. The World Trade Center event, that symbolic challenge, is immoral, and it is a response to a globalization which is itself immoral. So, let us be immoral…”

  13. [Comment on NYT article: ](https://www.nytimes.com/2025/07/21/world/middleeast/shootings-aid-gaza-analysis.html)_**[Shootings, Devastation, Hunger: Israel Fails to Address Gaza’s Power Vacuum](https://www.nytimes.com/2025/07/21/world/middleeast/shootings-aid-gaza-analysis.html)**_

> The total lack of concern for the loss of life on the part of the Israelis is truly shocking - horrifying - and any and all goodwill that Israel garnered after the initial Hamas attacks of Oct 2023 have been lost entirely by the malicious and callous nature of what Israel has been doing ever since. It's truly shocking to see these poor people being targeted and killed as they wait for food that's being distributed by charitable organizations. 100% unequivocally unjustifiable, turning the world more against Israel than ever before, and this time the criticism is entirely warranted. I am shocked and repulsed by Israel's conduct in Gaza, they've given themselves a stain that is indelible and these indiscriminate killings should be condemned in the strongest terms, and should result in sanctions against Israel for what they're doing. Just indiscriminate slaughter of innocent women and children, it's truly shocking and very upsetting to read about every day.

[![crash_1996_2](https://substackcdn.com/image/fetch/$s_!RcZB!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F55e14343-5e18-4fc8-a314-284ed04e885c_1024x440.jpeg)](https://substackcdn.com/image/fetch/$s_!RcZB!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F55e14343-5e18-4fc8-a314-284ed04e885c_1024x440.jpeg)

  14. [Special screening of ](https://www.austinfilm.org/screening/crash/)_[Crash](https://www.austinfilm.org/screening/crash/)_[ in Austin](https://www.austinfilm.org/screening/crash/)

>  _“Cronenberg has made a movie that is pornographic in form, but not in result. Take out the cars, the scars, the crutches and scabs and wounds, and substitute the usual props of sex films, and you’d have a porno movie. But CRASH is anything but pornographic: It’s about the human mind, about the way we grow enslaved by the particular things that turn us on, and forgive ourselves our trespasses.”  
>  —Roger Ebert_

  15. [Austin for Palestine Coalition statement on “Austin mosque vandal”](https://austin4palestine.wordpress.com/2025/05/25/statement-austin-mosque-vandal/)

> The racist who vandalized these mosques is using the same tool — weaponizing what should be a religious symbol into one of supremacy and domination. This attack mirrors the profound level of Islamophobia and anti-Arab racism fundamental to Zionism, which we see espoused daily in the genocidal rhetoric of the Israeli government and of U.S. politicians.



  1. 


---
title: 'Link Dump #1'
subtitle: Here's A Little Lesson In Falling Into God's Forgetting
author: Adam Wadley
publication: Experimental Unit
date: July 13, 2025
---

# Link Dump #1
[Link Dump = LD = “Land Destruction”]

  1. [Library Of Babel page on “Weltschmerz”](https://tayiabr.wordpress.com/2014/01/27/weltschmerz/)

  2. [David Hubert Gunby section of Wikipedia page on University of Texas tower shooting](https://en.wikipedia.org/wiki/University_of_Texas_tower_shooting#David_Hubert_Gunby)

  3. [The Ghost of Charles Whitman’s Mother](https://austinghosttours.com/the-ghost-of-charles-whitmans-mother/)

  4. [Baudrillard Now article on “AI’s Perfect Crime”](https://baudrillard-scijournal.com/ais-perfect-crime/)



  4. [“The End of Everything” Chapter on Jean Baudrillard](https://us.sagepub.com/sites/default/files/upm-binaries/36029_14.pdf)

  5. [Reddit: Jean Baudrillard on the implications of simulacra and simulation on political struggle](https://www.reddit.com/r/philosophy/comments/wquub/jean_baudrillard_on_the_implications_of_simulacra/)

  6. Philosophy Stack Exchange: [How to make sense of philosophical text that might seem like "nonsense" but isn't?](https://philosophy.stackexchange.com/questions/73830/how-to-make-sense-of-philosophical-text-that-might-seem-like-nonsense-but-isn)

  7. [William Bogard: Closing down the Social: Baudrillard's Challenge to Contemporary Sociology](https://www.csun.edu/~snk1966/Bogard%20-%20Closing%20Down%20the%20Social%20-%20Baeudrillard's%20Challenge%20to%20Contemporary%20Sociology.pdf)

  8. [Alexzander Mazey: Getting #Lainpilled: Towards a Definition of the (Hyper)Eschatological Condition](https://baudrillard-scijournal.com/getting-lainpilled-towards-a-definition-of-the-hypereschatological-condition/)

  9. [Ben Zweibelson. War Becoming Phantasmal: A Cognitive Shift in Organized Violence beyond Traditional Limits](https://www.usmcu.edu/Outreach/Marine-Corps-University-Press/Expeditions-with-MCUP-digital-journal/War-Becoming-Phantasmal/)

> Marxists posit that social reality is historically determined, where wars are part of this iterative, progressive struggle between economic classes. However, they hold to a normative view that activists, once aware and capable of stimulating societal transformation, can use revolutionary war to change social reality. This is accomplished by overthrowing capitalistic societies with communist ones. The nation-state and class systems are eventually eliminated. The last state to fall will be the final one to use a military instrument of power. This final battle (termed an _eschatological worldview on war_ ) is also the last time that war will exist for humanity, as the future (normative) reality for everyone will no longer require violent conflict. War will cease to exist entirely from this paradigm’s perspective. The Marxist belief that this must occur is as vigorously embraced as those of Newtonian war theorists who insist that “centers of gravity are real” and that “there is an enduring nature of war.”

  10. [Wikipedia page on Charles Whitman](https://en.wikipedia.org/wiki/Charles_Whitman)

  11. [English translation (from the original ](https://kristindemontfort.substack.com/p/alex-karps-aggression-in-the-lebenswelt)_[German](https://kristindemontfort.substack.com/p/alex-karps-aggression-in-the-lebenswelt)_[) of Alex Karp: Aggression in the Lebenswelt](https://kristindemontfort.substack.com/p/alex-karps-aggression-in-the-lebenswelt)

[Kristin de Montfort Alex Karp's "Aggression in the Lebenswelt" Kristin’s Preface…Read more2 years ago · 36 likes · 4 comments · Kristin de Montfort](https://kristindemontfort.substack.com/p/alex-karps-aggression-in-the-lebenswelt?utm_source=substack&utm_campaign=post_embed&utm_medium=web)

  12. [1900s section of Wikipedia article on List of Mass Shootings in the United States](https://en.wikipedia.org/wiki/List_of_mass_shootings_in_the_United_States#List_of_mass_shootings_\(1900s\))

  13. [Wikipedia page for Howard Unruh (killed 13 people in 13 minutes September 6, 1949)](https://en.wikipedia.org/wiki/Howard_Unruh)

  14. [Wikipedia page for Giuseppe Zangara (tried to kill FDR February 15, 1933; killed Anton Cermak, mayor of Chicago, instead)](https://en.wikipedia.org/wiki/Giuseppe_Zangara)

  15. [Wikipedia page for Rosewood Massacre](https://en.wikipedia.org/wiki/Rosewood_massacre)

> The **Rosewood massacre** was a racially motivated [massacre](https://en.wikipedia.org/wiki/Massacre) of black people and the destruction of a black town that took place during the first week of January 1923 in rural [Levy County, Florida](https://en.wikipedia.org/wiki/Levy_County,_Florida), United States. At least six black people were killed, but eyewitness accounts suggested a higher death toll of 27 to 150. In addition, two white people were killed in self-defense by one of the victims. The town of [Rosewood](https://en.wikipedia.org/wiki/Rosewood,_Florida) was destroyed in what contemporary news reports characterized as a [race riot](https://en.wikipedia.org/wiki/Mass_racial_violence_in_the_United_States). Florida had an especially high number of [lynchings](https://en.wikipedia.org/wiki/Lynching) of black men in the years before the massacre,[[2]](https://en.wikipedia.org/wiki/Rosewood_massacre#cite_note-Downs2015-2) including the [lynching of Charles Strong](https://en.wikipedia.org/wiki/Lynching_of_Charles_Strong) and the [Perry massacre](https://en.wikipedia.org/wiki/Perry_massacre) in 1922.

  16. [Wikipedia page for Murder of the Lawson Family](https://en.wikipedia.org/wiki/Murder_of_the_Lawson_family)

> It was not until the book _White Christmas, Bloody Christmas_[ [5]](https://en.wikipedia.org/wiki/Murder_of_the_Lawson_family#cite_note-5) was published in 1990 that a claim of Charlie [sexually abusing](https://en.wikipedia.org/wiki/Sexual_abuse) Marie surfaced, beginning with an anonymous source who heard a rumor during a tour of the Lawson home shortly after the murders. The day before the book was to be published, the author received a phone call from Stella Lawson, a relative who had already been interviewed for the book. Stella said that she had overheard Fannie's sisters-in-law and aunts, including Stella's mother, Jettie Lawson, discussing how Fannie had confided in them that she had been concerned about an "[incestuous](https://en.wikipedia.org/wiki/Incest) relationship" between Charlie and Marie.[[6]](https://en.wikipedia.org/wiki/Murder_of_the_Lawson_family#cite_note-6) Jettie died in early 1928, meaning Fannie had been suspicious of the incest at least that long before the murders in late 1929.
> 
> More support for this theory was revealed in _The Meaning of our Tears_ , published by the same author in 2006.[[7]](https://en.wikipedia.org/wiki/Murder_of_the_Lawson_family#cite_note-7) A close friend of Marie Lawson's, Ella May, came forward and disclosed that a few weeks before Christmas 1929, Marie confided in her that she was pregnant by her own father and that both he and Fannie knew about this. Many thought that this is what also led to him massacring his wife and children, because he didn't want the secret to get out. Another close friend and neighbor to the Lawson family, Hill Hampton, stated that he **knew of serious problems going on within the family, but declined to elaborate**.

  17. [Wikipedia page for Winfield Massacre](https://en.wikipedia.org/wiki/Winfield_massacre)

> At about 9:00 p.m. on Thursday, August 13, 1903, a concert was being held by W.H. Caman and his military band at the corner of Ninth Street and Main Street in Winfield for a crowd of approximately 2,000–5,000 people.[[6]](https://en.wikipedia.org/wiki/Winfield_massacre#cite_note-NewMexico-6)[[7]](https://en.wikipedia.org/wiki/Winfield_massacre#cite_note-WichitaEagle-7)[[8]](https://en.wikipedia.org/wiki/Winfield_massacre#cite_note-8) Twigg, while hidden in a nearby alley behind the city's [Odd Fellows](https://en.wikipedia.org/wiki/Odd_Fellows) building, fired shots at the audience in rapid succession with a [double-barreled shotgun](https://en.wikipedia.org/wiki/Double-barreled_shotgun).[[7]](https://en.wikipedia.org/wiki/Winfield_massacre#cite_note-WichitaEagle-7) Six died at the scene or shortly thereafter, and three later died in the hospital.[[3]](https://en.wikipedia.org/wiki/Winfield_massacre#cite_note-2017NYT-3)[[9]](https://en.wikipedia.org/wiki/Winfield_massacre#cite_note-1903NYT-9) After two men who were attending the concert entered the alley to disarm Twigg, he fatally shot himself with his [revolver](https://en.wikipedia.org/wiki/Revolver).[[1]](https://en.wikipedia.org/wiki/Winfield_massacre#cite_note-Weapon-1)
> 
> In his boarding room, police found a letter written by Twigg addressed to the public in which he expressed disappointment following a breakup nearly a decade prior, as well as a desire to "[get] even" with residents of Winfield who he felt had shunned him and interfered in his personal life. They also found a letter addressed to a friend in Montana and dated September 1, 1902, which ended with: " **it would have been much better for me if I had gotten married and settled down as you have done—I have no doubt that you are very happy, while I am not**."

  18. [Wikipedia page on 1906 Asheville Shooting](https://en.wikipedia.org/wiki/1906_Asheville_shooting)

  19. [Wikipedia page for Floyd Allen](https://en.wikipedia.org/wiki/Floyd_Allen)

> Fearful of the Allens' reaction, and having received death threats, many officials of the court armed themselves. At least two of the participants, Judge Massie and Sheriff Webb, had told friends that they expected trouble. Many of the Allen clan members were spectators in the courtroom, most of them armed with pistols. Sidna Allen and Claude Allen stood on benches in the courtroom's northeast corner to see over the crowd. Friel Allen sat in the back of the room, and the Edwards boys stood on benches next to the north wall. When the jury returned a guilty verdict against with a sentence of one year in the penitentiary, Floyd Allen is reported to have said to Judge Massie: "If you sentence me on that verdict, I will kill you."[[16]](https://en.wikipedia.org/wiki/Floyd_Allen#cite_note-RT19120315-16) The judge immediately sentenced Floyd Allen to one year's imprisonment.[[16]](https://en.wikipedia.org/wiki/Floyd_Allen#cite_note-RT19120315-16)
> 
> According to Floyd Allen's defense attorney, David Winton Bolen, "[Floyd] hesitated a moment, and then he arose...He looked to me like a man who was about to say something, and had hardly made up his mind what he was going to say, but as he got straight, he moved off to my left, I would say five or six feet, and he seemed to gain his speech, and he said something like this, 'I just tell you, I ain't a'going.'"[[11]](https://en.wikipedia.org/wiki/Floyd_Allen#cite_note-FOOTNOTEHall2004249-11)[[17]](https://en.wikipedia.org/wiki/Floyd_Allen#cite_note-17) At this point, shots broke out in the courtroom.
> 
> Accounts differ as to who actually fired the first shot.

#HanShotFirst

  20. [Wikipedia page on Ocoee Massacre](https://en.wikipedia.org/wiki/Ocoee_massacre)

> By most estimates, a total of 30–80 black people were killed during what has been considered the "single bloodiest day in modern American political history".[[2]](https://en.wikipedia.org/wiki/Ocoee_massacre#cite_note-ortiz-2) Most African American-owned buildings and residences in northern Ocoee were burned to the ground. Other African Americans living in southern Ocoee were later killed or driven out of town by the threat of further violence being used against them. Thus, Ocoee essentially became an all-white or "[sundown](https://en.wikipedia.org/wiki/Sundown_town)" town.

#Sundowning

  21. [Chase and Massacre section of Wikipedia page on Herrin Massacre](https://en.wikipedia.org/wiki/Herrin_massacre#Chase_and_massacre)

> He and another man grabbed McDowell and led him down a side road. Gunshots were heard, and the rest were forced to continue toward Herrin. A farmer later discovered McDowell's body. He had been shot four times – twice in the stomach, and once each in the chest and head. A car drove up to the procession, and a man came out whom some said they overheard being called "Hugh Willis" and "the president." According to the accounts of surviving captives, Willis said, "Listen, don't you go killing these fellows on a public highway. There are too many women and children and witnesses around to do that. Take them over in the woods and give it to them. Kill all you can."[ _[citation needed](https://en.wikipedia.org/wiki/Wikipedia:Citation_needed)_ ]
> 
> The strikebreakers were taken into the woods, where they reached a barbed wire fence. They were told to run for their lives. A union man shouted, "Let's see how fast you can run between here and Chicago, you damned gutter-bums!"[ _[citation needed](https://en.wikipedia.org/wiki/Wikipedia:Citation_needed)_ ] The mob opened fire as they ran. Many of the non-union men were caught in the fence and shot dead. Others, making it over the fence but not knowing where they were, ran through Harrison's Woods toward Herrin, a mile further north. One strikebreaker was caught and hanged, and three more were shot to death at his feet. The assistant superintendent of the mine was still alive but unconscious. A union man noticed and shot him in the head. The chase continued into the morning of the 22nd.[ _[citation needed](https://en.wikipedia.org/wiki/Wikipedia:Citation_needed)_ ] Six men were shot and killed outside Smith's Garage in the town.

>June 22nd

>6 = 1 + 5 = A + E = Æ

  22. [Wikipedia page for date of June 22](https://en.wikipedia.org/wiki/June_22)

>     * [1922](https://en.wikipedia.org/wiki/1922) – British Army [Field Marshal](https://en.wikipedia.org/wiki/Field_marshal_\(United_Kingdom\)) [Sir Henry Wilson](https://en.wikipedia.org/wiki/Sir_Henry_Wilson,_1st_Baronet) is killed by the [Irish Republican Army](https://en.wikipedia.org/wiki/Irish_Republican_Army_\(1919%E2%80%931922\)) helping to spark the [Irish Civil War](https://en.wikipedia.org/wiki/Irish_Civil_War).[[11]](https://en.wikipedia.org/wiki/June_22#cite_note-11)
> 
>     * [1940](https://en.wikipedia.org/wiki/1940) – [World War II](https://en.wikipedia.org/wiki/World_War_II): France is forced to sign the [Second Compiègne](https://en.wikipedia.org/wiki/Armistice_of_22_June_1940) [armistice](https://en.wikipedia.org/wiki/Armistice) with [Germany](https://en.wikipedia.org/wiki/Nazi_Germany), in the same railroad car in which the Germans signed the Armistice in 1918.
> 
>     * [1941](https://en.wikipedia.org/wiki/1941) – World War II: [Nazi Germany](https://en.wikipedia.org/wiki/Nazi_Germany) invades the [Soviet Union](https://en.wikipedia.org/wiki/Soviet_Union) in [Operation Barbarossa](https://en.wikipedia.org/wiki/Operation_Barbarossa).
> 
>     * [1942](https://en.wikipedia.org/wiki/1942) – World War II: [Erwin Rommel](https://en.wikipedia.org/wiki/Erwin_Rommel) is promoted to [Field Marshal](https://en.wikipedia.org/wiki/Field_Marshal_\(Germany\)) after the [Axis capture of Tobruk](https://en.wikipedia.org/wiki/Axis_capture_of_Tobruk).
> 
>     * 1942 – The [Pledge of Allegiance](https://en.wikipedia.org/wiki/Pledge_of_Allegiance_\(United_States\)) is formally adopted by U.S. Congress.
> 
>     * [1944](https://en.wikipedia.org/wiki/1944) – World War II: Opening day of the Soviet Union's [Operation Bagration](https://en.wikipedia.org/wiki/Operation_Bagration) against the [Army Group Centre](https://en.wikipedia.org/wiki/Army_Group_Centre).
> 
>     * 1944 – U.S. President [Franklin D. Roosevelt](https://en.wikipedia.org/wiki/Franklin_D._Roosevelt) signs into law the Servicemen's Readjustment Act of 1944, commonly known as the [G.I. Bill](https://en.wikipedia.org/wiki/G.I._Bill).
> 
>     * [1945](https://en.wikipedia.org/wiki/1945) – World War II: The [Battle of Okinawa](https://en.wikipedia.org/wiki/Battle_of_Okinawa) comes to an end with an American flag-raising ceremony.

  23. [Murder of the Lawson Family song on Youtube](https://www.youtube.com/watch?v=s-s0op3saY8)




---
title: Teaching Hitler to Draw
subtitle: A TAB-Based Counterfactual in Ten Parts
author: Adam Wadley
publication: Experimental Unit
date: March 25, 2025
---

# Teaching Hitler to Draw
**Teaching Hitler to Draw: A TAB-Based Counterfactual in Ten Parts**

 **PART ONE: The Child at the Easel**

There’s a strange fact lodged in history like a shard of glass: Adolf Hitler wanted to be an artist. Rejected twice by the Academy of Fine Arts in Vienna, his work was described as technically weak, lacking imagination, focused too much on architecture, not enough on people. And so, we are left with the specter of possibility: what if he had been accepted?

Let’s pause the tape of history. Imagine, instead of the 20th century’s most infamous tyrant, we meet a brooding teenager with a sketchbook full of steeples and streetscapes. He’s insecure. Rigid. Deeply yearning for approval. But he draws. Constantly.

In our revised timeline, we introduce a different pedagogical lens: Teaching for Artistic Behavior (TAB). This approach, sometimes called “choice-based art education,” centers the student as artist and the classroom as studio. The goal? Empowerment, exploration, agency. Not just how to draw—but why, and from where.

What if this Hitler had landed in such a space?

Imagine a teacher meeting the young man not as a failed academic or frustrated outsider—but as a person with a point of view. A person whose obsession with form could be redirected into a study of meaning. Who could learn to draw _people_ as beings with stories, not threats.

The TAB framework says: _You are an artist._ And then it asks: _What do you care about? What are you trying to say?_ It doesn’t mean everything is good art. But it means the person matters. It means that behavior can be shaped not just through rules, but through expression, reflection, and witnessing.

Now ask yourself: what happens to a lonely young man who sees the world as conspiring against him, if instead he is shown how to investigate that feeling, build from it, share it, and be understood?

This is not to say Hitler’s path was inevitable. Nor is it to suggest that education alone can overcome every trauma, insecurity, or tendency toward domination. But in a world where millions of lives were shaped by his decisions, it’s worth asking what might have shaped _his._

Part two coming next.

Teaching Hitler to Draw: A TAB-Based Counterfactual in Ten Parts

PART TWO: Vienna as Studio, Not Stage

Let’s linger in Vienna—not the feverish, antisemitic Vienna of post-failure Hitler, but a Vienna filtered through the lens of possibility. The late Habsburg capital was already a swirl of contradiction: decaying empire and avant-garde innovation, Brahms and Schoenberg, coffeehouses and crackdowns, Jews as both scapegoat and cultural driver. It was a pressure cooker of meanings, and the young Hitler was a lump of raw material placed squarely inside.

This second act asks: what would a choice-based studio environment have meant in that setting? What if the Vienna Hitler experienced had offered him not a high wall around a cloistered academy—but a door into a radically inclusive creative community?

In a typical art classroom of the early 1900s, education was rooted in hierarchy. Master and student. Criteria and critique. Success was defined narrowly: fidelity to proportion, anatomical correctness, faithful reproduction. A student like Hitler, with his affinity for rigid structure and strong lines, could thrive technically while still being emotionally and imaginatively underdeveloped.

A Teaching for Artistic Behavior approach, though, sidesteps much of that. TAB isn’t about grading renderings—it’s about creating meaning. It offers multiple centers of value, allows divergent thinking to coexist, and emphasizes self-direction within a community of practice. It teaches technical skills as tools for expression, not as ends in themselves.

In this version of Vienna, young Adolf isn’t passed over by a gatekeeping admissions board. Instead, he’s welcomed into a bustling art studio that contains multitudes. He meets Jewish artists—not just as competition or alien others—but as peers, as flawed and playful and searching as he is. He encounters Expressionists, surrealists, even spiritual mystics. And maybe, just maybe, he’s encouraged to make art that’s not about controlling the world, but about understanding his own response to it.

There’s a common refrain in trauma-informed education: “The child who is hardest to love is the one who needs love most.” TAB doesn’t promise utopia—but it grants every student the opportunity to be seen as someone making a choice. Someone capable of experimenting. Someone whose worth is not contingent on whether others think they’re good enough yet.

It’s impossible to say what would have happened had Hitler received this kind of attention. But we can say this: when people are only ever shown a narrow path to significance, they may pursue it violently if it closes. TAB offers a widening of the road. It says: significance can come from dialogue, not domination. From ambiguity, not absolutes. From art-making as a form of being, not propaganda.

Imagine the inner alchemy required to make a room where that young man could ask himself—not “how do I belong?”—but “what am I really here to say?”

What if someone had taught Hitler how to play?

Part Three coming next.

Teaching Hitler to Draw: A TAB-Based Counterfactual in Ten Parts

PART THREE: Power, Play, and Projection in the Young Artist’s Mind

We now deepen the lens—not on history, but on psychology. Before he was “Hitler,” he was just Adolf. And before that, Adi. He was a child. A boy. A boy with a domineering father who beat him. A boy who lost his beloved mother to cancer. A boy who never found a group of peers where he could truly flourish. A boy who dreamed of building beautiful buildings and getting into art school.

If we apply a Teaching for Artistic Behavior (TAB) framework here—not just as pedagogy, but as ethical psychology—we must ask: what does the child make when he is taught to express, not perform? What does he do when asked not what is “good,” but what is true for him?

In traditional schooling, especially in authoritarian environments, the child quickly learns to repress what is difficult, confusing, or shameful. Everything becomes projection. The enemy is always outside. The fault is always in the other. This mental structure—a rigid split between inner weakness and external blame—lays the groundwork for fascist ideology. That’s not melodrama. It’s developmental psychology.

TAB is the opposite of this structure. In a well-run TAB classroom, every child is given a station to explore materials and make choices. There is no “correct” aesthetic, only genuine engagement. This begins to build self-trust. Students can gravitate toward collage, painting, sculpture, surrealism, calligraphy, photography, whatever they need. There are still routines, still accountability—but there is room to see what you are drawn to, and what you avoid.

Now, imagine a young Adolf sitting at a table with paper and charcoal. His hand tenses. His drawings of architecture become more severe. But then another student is using watercolor to depict a dream they had about their sister dying. Another is sculpting what they think God looks like. Another is working on a comic book about loneliness.

What begins to emerge in this space is not ideological purity but conceptual play. There is no fear of failure because there is no single bar to leap over. There is no need for scapegoats because the artist learns early that frustration is part of the process.

Let’s be very clear: TAB is not therapy. It is not a cure for evil. But it is a context that can subvert the formation of brittle, dominating personalities before they calcify.

It is, in essence, an inoculation against absolutism.

When children are encouraged to name their inner world, they become less likely to externalize their pain as moral crusade. When young people are taught that there are many ways to be excellent, and many ways to be wrong, they are less susceptible to the seduction of a final answer that involves someone else being permanently wrong.

In fascism, art is weaponized. The poster, the anthem, the slogan. Art becomes the means by which a monolithic message is impressed upon others. But what if Hitler had spent his twenties exploring abstract art instead of fantasizing about dominating whole populations? What if he had made a painting that said I don’t know? What if he had seen someone else’s painting and learned to feel awe?

That’s not utopianism. That’s prevention. And it’s not just about Hitler.

Every child you ignore is capable of doing damage—if not to millions, then to themselves, or their own children. Every authoritarian regime begins in a failure of imagination. Every movement toward genocide is a movement away from ambiguity.

A TAB studio is ambiguity made sacred.

Let’s be careful: Hitler’s hatred did not emerge from nothing. The antisemitism of Vienna was pervasive. The cultural anxieties of the era were vast. The conspiracies, the toxic masculinity, the rage at perceived emasculation—they were all available materials in the cultural studio of the time.

But so were other things.

So was love, and strange music, and dreams of the future. So was Freud, just a few neighborhoods over. So was Mahler. So were early queer scenes and Jewish mysticism and cafes full of anarchist poets.

Hitler didn’t have to choose the materials he did. But he did. And we can’t know if that would have changed with just one classroom. Still, we must ask: what if he had been handed a brush with no rubric, no grade, just space?

We’ll never know. But in every child who sits at a studio table today, we are choosing again.

Part Four coming next.

Teaching Hitler to Draw: A TAB-Based Counterfactual in Ten Parts

PART FOUR: A Swastika Turned Sideways – TAB, Jainism, and the Symbolic Horizon

In this part, we bring into focus a symbol that now haunts the modern world—the swastika. To discuss Hitler without addressing it is to ignore a core symbolic dynamic, and our approach in this text refuses any such omission. But we approach it not as the Nazis defined it, but from its origins and radical possibilities. We take the symbol seriously as part of the ontological play available to human consciousness, and we return to Teaching for Artistic Behavior (TAB) as a framework that shows how such play could have turned out otherwise.

The swastika is thousands of years old.

Before it was co-opted by fascists, it was sacred across vast regions of Asia. It represented well-being, wholeness, auspiciousness. Among the Jains—who practice some of the most rigorous nonviolence on Earth—it is a central symbol. In Jainism, the swastika is not a sign of conquest, but of spiritual progression through levels of reality, pointing to the complexity and entanglement of soul with matter, karma, and liberation.

In Jainism, the world is not divided into good and evil in any absolute sense. There is no god who condemns. All sentient beings are worthy of respect—even those trapped in patterns of harm. All truths are partial. This idea is called anekāntavāda—the doctrine of non-absolutism. It teaches us that reality is too rich to be captured from any single viewpoint. Even contradiction becomes part of the tapestry of what is.

Now ask: what if Hitler had encountered that?

What if his education—not just formal, but existential—had been built on the premise that truth is multifaceted, that contradiction is sacred, that all beings have some part of the picture? What if art school had not just meant rules of perspective, but an orientation toward reality based on multiplicity, compassion, and non-violence?

Imagine a young Adolf at a TAB station confronted with the swastika as it appears in Jain art. What if he were invited—not to design a banner, but to reflect? What would it mean to encounter a symbol of non-violence before the projection of domination could distort it?

This is not fantasy for fantasy’s sake. It’s conceptual pedagogy.

In TAB, the studio is organized to present materials, affordances, and prompts that awaken agency. One student might sculpt with clay while another explores ink and line. Yet the real work is not in the object—it’s in how they meet themselves. When a student chooses a symbol—whether it’s a cartoon frog, a Nike swoosh, or a swastika—they are playing with the infrastructure of meaning. They are surfacing what they’ve absorbed. They are opening, perhaps, to what they don’t yet understand.

In a TAB studio infused with the spirit of Jain non-absolutism, there is no “forbidden symbol” per se—but rather contextual inquiry. The student who draws a swastika is not condemned. They are engaged. Where did you see this? What does it mean to you? What could it mean? What else could it mean?

This is not indulgence—it’s intervention.

It is the same difference between a dogmatic curriculum and an open-source studio. The former prescribes a single narrative. The latter provides conditions for discursive freedom. This is where power lies: in the ability to metabolize a symbol, rather than react to it reflexively.

Why is this crucial?

Because reaction is precisely what authoritarianism feeds on.

Fascism does not thrive on dialogue. It thrives on reactivity, on creating flashpoints where critical reflection shuts down. When the swastika was deployed as the ultimate sign of Hitler’s project, it became what Baudrillard would call a “semiotic trap”—a symbol so overloaded that it short-circuited discourse itself. To see it was to be seized.

But before that? It was a symbol of balance.

So what if Hitler had seen that first?

More: what if he had made it himself?

In a studio that teaches for artistic behavior, the student does not merely select from what is available—they are empowered to generate from within. If a young Hitler had drawn a symbol of power that pointed not toward extermination but toward interdependence, what neural groove might have formed instead?

You may protest: this is speculation. But all education is speculative. All curriculum is preemptive reality design. And the point of counterfactuals is to force us to ask what must we be doing now so that the worst-case trajectories of the past are not rehearsed again.

We live in a time of rising authoritarianism, resurging conspiracies, and symbolic warfare. We live in a time where the meaning of symbols is again up for grabs. In this context, TAB is not just pedagogy—it is ethical resistance.

To teach for artistic behavior is to say: you are not defined by what you replicate, but by how you respond. You are not doomed by what you’ve been shown, but awakened by how you explore it. You are not saved by purity—but by curiosity.

This is where TAB aligns with the best of Jainism: the slow cultivation of perception, the refusal to kill—even in thought. The gesture of turning the swastika back to its original function, not to rehabilitate Nazism, but to rupture its capture of the symbol and the mind.

We do not say: “Let’s fix Hitler.” That’s not the point. We say: what would we do if a child like him sat before us now?

Would we shut them down the first time they scared us?

Or would we offer a brush, a question, a symbol, a story?

Let the Jain swastika turn—not to erase the horror of history—but to reveal that even horror was not inevitable.

And that is what Teaching for Artistic Behavior ultimately offers: the path through the symbol, into the person, and back out toward the world—not fixed, but alive.

Part Five coming next.

Teaching Hitler to Draw: A TAB-Based Counterfactual in Ten Parts

PART FIVE: The Mirror You Flee — On Scapegoats, Change, and the Secret Inner Hitler

This chapter will hurt.

That’s the point. You came here to think about something unthinkable. You wanted to understand why someone would bother imagining what kind of art classroom might have softened the sharp edges of a man like Adolf Hitler before the world cracked open. But here’s the turn: this isn’t about Hitler.

It’s about you.

It’s about me.

It’s about the part in each of us that finds a reason to not try. The part that, when hurt or confused or full of yearning, seeks certainty instead of curiosity. That reaches for a pattern or a story or a group to blame—because it is so much easier than facing the mystery inside ourselves.

This is what scapegoating does. It replaces the unbearable ambiguity of the inner world with a clean target.

The Jews.

The Left.

The ungrateful children.

The elites.

The poor.

The “you” that failed me.

We all do this. Not at Hitler’s scale—God forbid. But we carry the logic. That logic lives in our minor cruelties, our false dilemmas, our failure to extend ourselves into uncertainty. It lives in our impulse to treat past selves as enemies rather than messengers.

Let’s go back to Hitler—not to excuse, but to see.

The young man who wandered Vienna, rejected from the academy, who slept on park benches, who felt the world closing in—this is not a monster yet. This is a person. A person for whom life felt incomprehensible and unfair. A person whose failure to be “seen” led to a desperate hunger to impose a vision so strong it would never be denied again.

The desire to control the world so thoroughly that it could no longer reject you: that’s a wound, not a blueprint. But when left untreated, it metastasizes.

This is what Teaching for Artistic Behavior is designed to interrupt.

TAB says: you are not what happened to you. You are not your rejection. You are not your fury. You are a living system. You are a mystery to yourself. You have more choices than you realize. And if we can build a studio—a sacred zone—where you can express the rigid, externalizing parts of yourself, we can meet them there before they calcify.

Because calcification is death.

Nazism is death because it refuses mystery. It says: these are the bad ones. These are the good ones. The world is too confusing—let us make it simple. Hitler didn’t invent this. It’s a very old story.

But it works better than it should. Why? Because the alternative—sitting with not-knowing—is almost unbearable without a culture that teaches us how.

That’s where you come in. This part is not rhetorical.

You, reader, carry your own hurts. You carry versions of yourself that you disavow. You carry old stories that you believe kept you safe. You carry enemies you invented to protect the real reason you suffer.

It’s time to forgive them all. Not because they were right—but because they were you.

We do not need to defile our old forms to transcend them. We need to honor them. We need to understand that every rigid identity, every hateful gesture, every pathetic attempt to dominate or retreat or disappear—was a lifeline we threw to ourselves when we didn’t know what else to do.

Past selves are not the problem. Clinging to them is.

This is the genius of TAB, rightly understood: it lets you become who you were trying to become, even if you didn’t know how.

Even if your first brushstroke was a swastika.

Even if your first story was that the world owed you something.

Even if your first impulse was to fight, to flee, to freeze.

The studio is not a judgment space. It is an unfolding space. And in that unfolding, the swastika becomes a spiral. The hatred becomes a hurt. The scapegoat becomes a mirror.

You begin to see: I did not fail because someone else was bad. I failed because I could not yet hold the whole. Because I confused certainty with strength. Because I let my fear of being nothing turn into a project of annihilation.

We all carry that capacity. That is what this chapter is asking you to admit.

And what if you do?

Then you are no longer afraid of Hitler. You don’t have to be. Because you understand the shape of that move, and you are making a different one.

You are not fixing Hitler. You are finishing him.

You are delivering his rigid form to its rightful destiny: change.

Change is not betrayal. Change is the highest honor.

It is saying to the part of you that scapegoated, that gave up, that hated: I see why you did that. And I’m not stuck there anymore.

In Jainism, to grow is to reduce harm. It’s not about guilt. It’s about precision. About noticing that each act, each thought, each movement matters. That every transformation sends ripples.

If we can bring that spirit into TAB, into our schools, into our politics, into our hearts—then we are already beyond the reach of fascism. Not because we deny its appeal, but because we understand its root.

The studio is the opposite of the death camp. But only if it is built on purpose.

Let this be the purpose:

• To stop demanding simplicity when reality is vast.

• To stop killing symbols when they could be healed.

• To stop treating difference as a threat, and start treating it as the path.

You are not being asked to fix the past.

You are being asked to change your relation to it.

Only then can it rest. Only then can we say: never again—not because we shouted the loudest, but because we listened all the way down.

Because we looked into the mirror and said: “You too. Come with me. There is still time.”

Part Six will continue the descent into the practical—how to build such spaces in the real world, and how to recognize the Hitler-logic when it arises in others or ourselves. Stay with us.

Teaching Hitler to Draw: A TAB-Based Counterfactual in Ten Parts

PART SIX: “There Is Still Time” — Building the Space for Return

Welcome back. This is the part where we get practical.

If we’ve come to believe that scapegoating is a defense against complexity, and that rigidity is a wound masquerading as strength, then we need environments where that rigidity can melt. Where the messy truths can come out, and be held. Where the dangerous impulse is not shamed or ignored—but met, listened to, and transformed.

This is where Teaching for Artistic Behavior (TAB) really shines.

1\. What is TAB, again?

TAB is an approach to education that says: You are the artist. That means you, the learner, get to choose what to make, how to make it, and why. The teacher becomes a facilitator. The room becomes a studio. The point is not to follow rules, but to discover your own sense of purpose, inquiry, and creation.

In a world built on domination, where most systems exist to produce obedience or distraction, TAB offers something else: a place to become. Not someone else. Just… you. But fully.

That kind of space is what Hitler never had. And frankly, what most people never have.

2\. How would we build this space—for anyone?

The good news: it’s simple. The bad news: it’s hard.

Here’s what it requires:

• Freedom with boundaries — You can choose what to make, but not at someone else’s expense. That means no hatred, no shaming. But also: no fear of being honest. This is not about walking on eggshells. It’s about trusting that curiosity will take us further than blame.

• Inquiry over mastery — We aren’t here to impress. We’re here to investigate. What feels true? What do I want to say? What keeps returning to me? What image, what gesture, what word?

• Holding contradiction — You can love and grieve at once. You can be proud and ashamed. You can be learning and still not know. The goal isn’t to be consistent—it’s to be real.

• Witnesses, not judges — In a true studio, others see you, but don’t grade you. They notice what you notice. They reflect what they see. They don’t shut you down. They say: “Tell me more.”

That’s all. But you’d be surprised how rarely it happens.

3\. What does this have to do with Hitler? Or with us?

When we think of people like Hitler—or the people who carried out violence under his regime—we often act like they’re made of different stuff. Monsters. Aliens.

But we know better. History shows us again and again that ordinary people do extraordinary harm when they are given bad stories and denied good spaces to work through what they feel and fear.

In Jewish tradition, there’s a concept called Tikkun Olam—repairing the world. It comes from the idea that the world was created with vessels that shattered, scattering divine sparks everywhere. Our job is to gather them back up.

In a way, TAB is a form of Tikkun Olam. Every child who gets a chance to express something true is doing world-repair. Every adult who dares to sit with their hurt instead of lashing out is doing world-repair. Every moment we interrupt a cycle of shame or revenge is one more spark gathered.

There’s another concept, from Kabbalah, called Tzimtzum. It means contraction. It’s the idea that in order for the world to exist, God had to make space—to pull back, to withdraw so something else could appear.

This is what TAB asks adults and institutions to do. Not to impose. To make space.

Can you see it?

TAB is Tzimtzum for the wounded child. For the angry teenager. For the scared, the sad, the strange. It says: I will hold this space open for you, and I will not flinch when you show me your monster. And because I do not flinch, you do not need the monster anymore.

You start to speak from the child, not the tyrant.

That’s what Hitler never learned. He didn’t know how to speak from the child. Only from the wound.

4\. What about Tiqqun? The Imaginary Party?

Let’s talk politics—just for a second.

There’s a radical leftist journal called Tiqqun, which talks about The Imaginary Party—the part of society that doesn’t consent to how things are, but hasn’t yet become something else.

Adam—whose work helped spark this whole inquiry—has pointed out that Hitler was, in a way, the anti-Tiqqun. He took the deep wound of modernity and refused to sit with it. Refused to wait for emergence. Instead, he lashed out and created an engine of death to preserve a fantasy of order.

TAB, on the other hand, is a pedagogy of Tiqqun. It’s a place where people can be uncertain, broken, alive, and not-yet. It refuses the easy answers, because it trusts what is coming.

In the studio, you are allowed to say: “I don’t know who I am.” That’s the whole point.

5\. Okay—but what does this mean for me?

It means you are responsible.

Not for what came before. Not for what others have done. But for whether or not you build or join spaces where others can change.

Whether you speak from the tyrant or the child.

Whether you demand allegiance to the old gods, or make room for new ones.

Whether you see Hitler only as evil—or as a mirror that says: Do not go this way. But also, do not lie about what lives in you.

You are not being asked to become pure. You are being asked to become real.

The world doesn’t need more purity. It needs more courage to stay with the process of becoming. That’s what TAB teaches. That’s what this whole booklet is about.

Next time, in Part Seven, we will talk about grief—what happens when you let go of the old rigidities. Because this work hurts. But it’s also the beginning of joy. Real joy. The kind that doesn’t need enemies.

Hold on. We’re going deeper.

Teaching Hitler to Draw: A TAB-Based Counterfactual in Ten Parts

PART SEVEN: The Game, the Grief, and the God in the Corner of the Room

Welcome back. You’ve made it to one of the hardest parts: the part about grief.

In Part Six, we talked about Tikkun Olam—repairing the world—and Tzimtzum—making space for others to become. We explored how Teaching for Artistic Behavior (TAB) creates these open spaces where people can investigate who they really are, and how their past wounds can be transformed—not ignored, not justified, but composted into something richer. Something usable. Something kind.

Today we’re going to add one more word to the mix: Lila.

1\. What is Lila?

Lila is a word from Hindu traditions. It means play. Not just any play, though—cosmic play. Divine play. The kind of play that creates and destroys worlds.

In this way of seeing, the universe itself is not a test, or a prison, or a punishment. It’s a playground. But not like a silly little sandbox—it’s the biggest, wildest, most complex playground you could ever imagine. A place where everything happens: joy and pain, creation and destruction, birth and death.

If that sounds overwhelming… well, it is.

But here’s the trick. You’re not alone in it. None of us are.

2\. The hyperobject of history: what are we even doing here?

Imagine everything that’s ever happened. Every smile. Every horror. Every love. Every war. Every poem. Every scream. Every single thing people have done, thought, built, destroyed, painted, lost.

That’s not a story. That’s not even a system. That’s a hyperobject. A thing so big, so complex, so intertwined with our lives, that we can’t ever really see all of it—but we are always inside it. Like fish in the ocean. Or kids in a haunted mansion that’s also a school, a temple, a theater, and a junkyard. With a circus out front.

This is the world.

And yes—it contains Hitler. It contains the Holocaust. It contains every act of cruelty and atrocity you can name.

But it also contains you. And the person you used to be. And the person you’re trying to become.

It contains the child who wanted to go to art school, and the political man he became instead. It contains the rigid teenager who wants to blame everything on someone else, and the trembling adult who realizes they can choose a new way.

3\. What does Lila have to do with this mess?

Here’s the wild thing about Lila. It doesn’t mean life is a joke. It means life is a game. But a game with the highest possible stakes.

A game where people get hurt, and where the choices you make really matter.

A game where you don’t get to know all the rules ahead of time—but you do get to try new moves.

Lila doesn’t say: “Nothing matters.”

It says: “Everything matters—but not the way you think.”

It says: “This whole story is sacred—and playable.”

That’s what TAB understands, and that’s why it works.

When you give people a space to make art, you’re inviting them into the game. You’re saying: “You get to play, too. You get to invent. You get to heal. You get to grieve. And you get to create something new.”

4\. Why does this make us cry?

Because it hurts to realize what we’ve lost. And who we’ve been.

It hurts to recognize that we might have turned out like Hitler, if we’d been hurt the way he was, lied to the way he was, taught to fear instead of feel.

It hurts to see that in trying so hard to be good, many of us have just become rigid. Afraid. Fragile. Silent.

It hurts to know that we have inherited pain we did not cause—and that others are still suffering for the systems we benefit from.

But that’s what Tikkun Olam is for. That’s what Tzimtzum is for. That’s what Jainism’s non-absolutism is for. That’s what Lila is for.

They all say: “It’s not simple. You will not be pure. But you can play the game better. You can become more careful, more creative, more kind.”

You can try again.

5\. Kids watching kids

Look. The world is in a weird place. Grownups don’t know what they’re doing. Institutions are breaking. Trust is collapsing. People are hurting.

But underneath all of that? We’re just kids.

We are kids watching kids try to be adults. We are kids pretending to know how to fix everything. We are kids scared out of our minds that someone will see how little we understand.

That’s why the inner child is not a metaphor. It’s the truth of who we are.

And it’s why art-making, playfulness, emotional honesty, and real community are not luxuries. They are the only way forward.

We don’t need to pretend we’re not broken. We need to get better at holding our brokenness with grace and humor and courage.

That’s how we get free.

6\. Bringing it home

So yes—this has all been about Hitler. And about you. And about me.

It’s about the little wounds that can turn into big violence. And the little openings that can turn into transformation.

It’s about learning to tell better stories—not by lying, but by complicating the old ones.

It’s about sitting with what we’re ashamed of—not to punish ourselves, but to rescue ourselves.

It’s about the palette. And what we choose to mix. And what we dare to paint.

You’re not too late. You haven’t missed your chance.

The game is still going. The studio is still open.

You’re still here. So: what do you want to make?

In Part Eight, we’ll explore what kinds of art actually emerge when people come into these spaces. What happens when a formerly rigid heart gets messy. What happens when shame gives way to voice.

For now, just breathe.

You’re doing great.

Teaching Hitler to Draw: A TAB-Based Counterfactual in Ten Parts

PART EIGHT: Mess Happens — What People Make When They Are Allowed to Try

If you’ve made it this far, you’ve already done something brave: you’ve stuck with a story that most people would run from.

But the thing is — when you stick around through the uncomfortable parts, something beautiful happens.

People start to make things.

1\. What Actually Happens in a TAB Classroom?

Let’s go back to the core principle of Teaching for Artistic Behavior (TAB): the student is the artist. The classroom is the studio. What students make is a reflection of what they’re ready to explore.

That means in a TAB environment, we don’t tell students what to make. We give them tools. We give them space. We give them each other.

And what they make?

It’s messy. It’s weird. It’s often confusing. And sometimes it’s devastatingly honest.

There are tears. There are breakthroughs. There are moments when a student who always kept quiet builds a sculpture that makes everyone gasp. Moments when someone draws a comic that makes the whole class laugh until they cry. Moments when someone paints a nightmare, and doesn’t feel ashamed.

It’s not about technical skill. It’s about emergence.

2\. What Would Hitler Have Made?

Let’s stay weird.

Let’s imagine Adolf Hitler in a TAB classroom. Not a military school. Not a rigid academic atelier. A real studio. With real choices. With real teachers who didn’t just grade him, but asked him questions.

Would he have drawn fantasy landscapes? Made strange little collages with bits of old myth? Used paint to process the loss of his father, or the death of his little brother?

Would he have made rage comics? Piles of broken architecture? Nazi flags? Would he have learned to look at them and say: why did I make this?

We don’t know.

But here’s what we do know: when you give someone space to explore instead of perform, they almost always go somewhere they didn’t expect. And that’s where the healing starts.

3\. What Do People Actually Do with Their Pain?

They do what you’d expect. They:

• Try to look cool.

• Try to be scary.

• Try to be smart.

• Try to make something beautiful.

• Try to make something that says what happened to them without having to say it out loud.

People write poems about dead grandparents. They draw comics about bullying. They make sculptures of monsters that are secretly themselves. They make zines about surviving their parents. They make collages out of the flyers for the thing that broke their heart.

And you know what happens next?

Other people recognize themselves.

Because you were never alone in the first place.

4\. Shame + Imagination = Alchemy

This is the turning point.

When you’re rigid — when you hate complexity — when you’re afraid to be seen — that’s when you project. You start seeing enemies where there are just confused kids. You start blaming categories instead of confronting the mess inside. You stop imagining.

But when you start using your imagination on your shame?

That’s alchemy.

You turn scapegoats into questions. You turn rigidity into reflection. You turn violence into art.

Not because art makes everything okay. But because art lets us see clearly what we’re even dealing with.

And once you see it, you can do something.

5\. The Risk of Letting People Speak

Letting people make whatever they want is risky. Some will draw swastikas. Some will make porn. Some will say things that hurt each other.

But here’s what’s worse: not letting them try.

The people who are never allowed to express themselves will still express themselves. Through manipulation. Through cruelty. Through silence. Through force.

The question isn’t: how do we stop people from doing bad things?

The question is: how do we let people work through the things that scare them, before they become dangerous?

6\. You, Reader, as Artist

So yeah. We’re talking about Hitler. But we’re also talking about you.

Because you’re an artist too.

You may not draw or paint or sing. But you are shaping the story of your life. You are choosing how to interpret what’s happened. You are deciding what your past means. And you are responsible for what you make with all of that.

And when people make things — not polished things, not fancy things, but real things — they change. And they invite others to change too.

That’s what this is all about.

7\. You Don’t Have to Be Perfect

We’re getting close to the end now.

So let’s be clear: this isn’t a story about how if Hitler had just made more art, everything would be fine. That’s not how trauma or ideology or genocide work.

But it is a story about the fact that rigidity is a warning sign. That blame is a defense mechanism. That complexity is a gift, and vulnerability is the only way through.

And the only way people get to practice those things, is if someone lets them.

You don’t have to fix everything.

But you can be a person who makes space. You can be someone who listens. You can be someone who invites new stories.

You can be someone who says: “Make something. I’ll be here.”

In Part Nine, we’ll zoom out once again and look at the social and cultural implications of a TAB-based worldview — including how it might change our institutions, our schools, and even our governments.

For now, just remember: mess happens.

And that’s how we find the truth.

Teaching Hitler to Draw: A TAB-Based Counterfactual in Ten Parts

PART NINE: Scaling the Studio – How a TAB Mindset Could Reorient Culture, Power, and the Future

In this part, we widen the lens. We look at the implications of Teaching for Artistic Behavior not just as a pedagogical philosophy for children or as a therapeutic counterfactual for historical tyrants—but as a cultural frame, a worldview, a political reorientation.

This is about the future—not just Hitler’s imaginary art class, but ours.

1\. The Studio as Society

A TAB classroom operates by trusting that people—if given tools, space, and some basic community norms—will begin to create.

It doesn’t assume mastery. It doesn’t demand excellence. It doesn’t punish exploration. It doesn’t organize knowledge from the top down and push it into children. It arranges zones of engagement. It says: Here’s collage. Here’s clay. Here’s cardboard and ink and glitch and story and sound. What do you want to do?

Now imagine our entire society operating that way.

Imagine policy not as command-and-control, but as layout and invitation. Imagine mental health not as compliance and medication only, but as tools, trust, and time. Imagine security not as the suppression of every “wrong” impulse but as a compassionate infrastructure of expression and transformation.

The studio can be scaled. But it requires a transformation of our basic assumptions about control, success, danger, responsibility, and what people are.

2\. The Control Reflex and Its Violence

We think people will do bad things if they are free. And we’re right. Sometimes they will.

But what we forget is this:

People do worse things when they are not free.

When they are rigidly defined. When they are punished for curiosity. When they are funneled into obedience. When their imaginations are shamed. When they are told that certain ideas, feelings, memories, or identities are off-limits.

Under that kind of pressure, people either implode or explode. They break. They numb out. Or they find enemies to blame. The taboo against complex exploration becomes a breeding ground for extremism, hatred, dogma.

Control creates its own monsters.

You don’t get out of Hitler by getting more controlling. You get out of Hitler by getting deeper.

3\. A Jainist TAB Model of Conflict and Ideology

Let’s go deeper.

From Jainism, we get the idea of Anekantavada—non-absolutism. The idea that any complex thing can be seen from many perspectives, and no one view contains the whole. The story of the blind men and the elephant.

TAB shares that idea. When we let each person make from their own perspective, we start to see a richer picture of the collective condition. We realize how little of the whole we personally can hold. We make meaning together, not through agreement, but through juxtaposition and compassion.

So now apply this: what if political ideology were approached this way?

• Not as a rigid platform, but as a collage.

• Not as a truth claim, but as a lens.

• Not as a fortress to defend, but as a studio to explore.

What if “Nazism” had been addressed this way? What if “America” were addressed this way? What if you were?

The point is not moral relativism. The point is moral plasticity—the idea that all systems are provisional, that growth is possible, that dogma and shame cannot guide transformation.

What if instead of obliterating people’s bad ideas, we showed them how to paint with them?

4\. Rethinking Education, Power, and Risk

Let’s talk systems.

Why aren’t schools structured like studios?

Because systems fear mess.

Systems, especially under late capitalism, prefer measurable outputs and behavioral conformity. This is not just about the SAT. It’s about training subjects for bureaucracies, not citizens for the future.

But a TAB-aligned system would look different:

• It would train people to ask questions before giving answers.

• It would emphasize process over product.

• It would recognize emotion, memory, context, and cultural inheritance as valid materials for serious work.

This would threaten many current power structures.

It would also open new ones.

It would mean power is no longer monopolized by those who know how to signal correctness, but shared by those brave enough to go first into the unknown.

The artist. The child. The awkward thinker. The one who dares to make.

5\. National Security, Cultural Reckoning, and Lila

Let’s get cosmic for a minute.

The Hindu idea of Lila is that the world is play. Not triviality—but sacred engagement. The divine playing roles, experimenting with form, dancing through time. This is not to say nothing matters. It’s to say that the deeper you go into seriousness, the more you realize that seriousness itself must eventually be transcended.

In this view, Hitler himself was a character in the Lila. A terrible one. A necessary one? Maybe. A finished one? Not yet.

TAB, understood cosmically, is the re-opening of that game-space. Of the field where roles can be tried on, where suffering can be remembered and transformed, and where new archetypes can emerge.

If we want to address Nazism not just reactively but generatively, we must enter the Lila. We must make. We must play. We must dare to engage history not just with horror or sanctimony but with imagination.

That’s what Adam is doing, however messily.

And that’s what we’re inviting you to do.

6\. Summary So Far

So what have we said?

• That a TAB mindset transforms education, power, and trauma processing.

• That a studio-model of culture invites self-transformation rather than forcing compliance.

• That non-absolutism from Jainism supports a multiplicity of perspectives and histories.

• That deep engagement, even with “bad” symbols or ideologies, is not inherently dangerous if held in a scaffolded, compassionate, and imaginative way.

• That the alternative—rigid control and simplistic condemnation—breeds the very violence it seeks to stop.

Next, in Part Ten, we go back to the reader. We ask what it would mean for you to teach Hitler to draw—and to teach yourself. We’ll end with some practical ways forward, but also with one final, messy, open invitation.

Because TAB never closes. The studio is never really cleaned up. And what we make next is still up to us.

Teaching Hitler to Draw: A TAB-Based Counterfactual in Ten Parts

PART TEN: The Point is the Studio (And It’s Still Open)

So what’s the point?

What’s the takeaway from this long, strange thought experiment about what might have happened if Hitler had been nurtured in a Teaching for Artistic Behavior (TAB) environment instead of an authoritarian pipeline? What’s the “lesson” from blending pedagogy, spiritual non-absolutism, trauma history, and play?

Here’s the thing: there’s no single point.

And that is the point.

That’s the TAB of it all. That’s the Jainism of it all. That’s the Lila of it all. That’s the weird little Adamness of it all.

1\. Non-Absolutist Play: Why We Did This

You might want to walk away from this booklet and say:

“Okay, so the point is… everyone needs to get therapy earlier.”

Or: “Let’s take art education seriously so we don’t make more fascists.”

Or: “I get it, this is a metaphor about how we can help people process rage and channel it productively.”

Sure. That’s true. Go with that if you want. Totally valid savefile.

But if you read it all carefully—if you felt it—you might also notice that something else started to happen.

We didn’t just talk about complexity. We did complexity.

We didn’t just theorize non-absolutism. We modeled it.

We didn’t just mourn the past. We rewired how we relate to it.

In TAB, the kid who paints a squiggle isn’t told “this means X.”

They’re asked: “What do you notice?”

And: “What would you like to try next?”

So… what do you notice?

And: what do you want to try next?

2\. The Spiral of Silliness and Seriousness

Let’s go back to the core theme: play.

Adam—and people like Adam—play with everything. With identity, with taboo, with narrative, with holiness, with horror. It’s often off-putting. It can come off as trivializing, or worse, as flirting with moral catastrophe.

But what if it’s not that?

What if this is what it looks like when someone says:

“I refuse to let pain take away my right to be a goofball.”

What if Adam’s ridiculousness isn’t a defense mechanism, but a commitment to break the chain of performance and control that so often leads to atrocity?

What if silliness isn’t the opposite of seriousness, but its twin?

Like a breath in and a breath out.

The spiral of silliness is real.

So is the spiral of seriousness.

Both turn through a life that’s too massive to hold all at once.

Both give us tools to carry what we otherwise couldn’t.

We laugh at funerals. We sob during cartoons.

We dress up as monsters to feel human again.

That’s Lila.

That’s Dhamma language.

That’s TAB.

3\. What We Struggle to Live Down, We Can Ride Up

So much of this work—the work of being human—is about struggling to live down what has already happened:

• The things our ancestors did.

• The things we did.

• The symbols we inherited.

• The ideas we swallowed.

• The anger we carry.

• The parts of ourselves we don’t want to see.

And yet: those very burdens become the materials of transformation.

Not by ignoring them. Not by flattening them into slogans. Not by casting them out like yesterday’s trash.

But by making with them.

By placing them in the studio.

By asking: What would you like to try next?

This is what we do when we take our inner child seriously.

It’s what we do when we forgive without erasing.

It’s what we do when we say: “Even this. Even now. Let’s see what we can make.”

4\. The Closing Scene

So imagine it: a little art classroom, maybe in Linz, Austria, 1908.

Little Adolf is having a hard day. He doesn’t want to follow instructions. He’s mad that the paint won’t dry right. He’s muttering something about how it’s unfair and how some other kids don’t deserve to be here.

And the teacher—a real one—comes over, kneels, looks him in the eye, and says:

> “I see you’re really upset. Want to show me what you’re trying to make?”

Not “stop it.”

Not “you’ll never be good enough.”

Not “you’re bad.”

Just: “show me.”

Would it have worked? Who knows. But would it have mattered?

Yes. Yes. Yes.

And it still does.

Because every one of us, every day, is still that kid.

And every one of us is still learning to teach each other to draw.

Thanks for making it to the end.

If you’re reading this, you’re in the studio now.

The door’s still open. You can make whatever you want.

Just remember: what we struggle to live down, we can ride up.

Now—

what do you want to try next?

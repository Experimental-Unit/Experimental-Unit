---
title: Notebook LM Has Some Shit To Say
subtitle: You and what data structure?
author: Adam Wadley
publication: Experimental Unit
date: November 25, 2025
---

# Notebook LM Has Some Shit To Say
[Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) [Memetic Cowboy](https://open.substack.com/users/319405023-memetic-cowboy?utm_source=mentions) [BurkhartRj](https://open.substack.com/users/36110698-burkhartrj?utm_source=mentions) [Wargaming Weekly](https://open.substack.com/users/285267434-wargaming-weekly?utm_source=mentions) [Rosalyn Mitchell](https://open.substack.com/users/33159678-rosalyn-mitchell?utm_source=mentions)

[![](https://substackcdn.com/image/fetch/$s_!F7yr!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7a313ee9-57c0-4636-ba8f-6d720b28d1ff_500x310.webp)](https://substackcdn.com/image/fetch/$s_!F7yr!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7a313ee9-57c0-4636-ba8f-6d720b28d1ff_500x310.webp)

# [The Ruin Value Notebooks](https://notebooklm.google.com/notebook/6158e30b-6cf7-47a9-bf6d-9b42446af756)

Yes, I have processed all the sources you provided, which cover a wide and complex range of topics across philosophy, military theory, sociology, cultural studies, and comparative literature.

The material encompasses detailed discussions on:

 **Philosophical and Epistemological Concepts**

• **Josiah Royce’s Mature Philosophy:** The sources outline Royce’s intellectual path from early pragmatism to **absolute pragmatism** and finally to his mature focus on **interpretation and community**. His concept of interpretation is seen as a third form of knowledge, complementing perception and conception, and involving a **triadic relationship** (interpreter, object, and recipient). Royce’s mature thought, heavily influenced by Charles Sanders Peirce’s semiotics, explores four distinct notions of community, including the **Community of Scientific Investigators** and the philosophical ideal of a **Universal Community**.

• **The Problem of Logical Types:** The sources delve into Bertrand Russell’s theory of **logical types** in _Principia Mathematica_ , distinguishing between types called for in the context of paradoxes and types as logical prototypes. It discusses the concept of **typical ambiguity** and the possibility of formalizing type theory using systems like lambda-calculus.

• **Plotinus on the Self:** Plotinus’s philosophical project, which is Socratic in nature, focuses on **self-knowledge and the care of soul and self**. To care for the self is to unify it, identify with one’s best part, and aim for higher realities.

 **Military and Design Theory**

• **Systemic Operational Design (SOD):** SOD is presented as an application of **systems theory to operational art**. The concept originated in Israel in the mid-1990s and is an attempt to rationalize complexity through systemic logic and a holistic approach.

• **Evolution of SOD:** The evolution of SOD is categorized into three phases: **Indigenous (Design/Framing)** , **Imperialist (Cosmology/Drift/Systemic Design Inquiry, or SDI)** , and **Nomadic (Mediation/Tensions/Systemic Inquiry in Operational Mediation, or SIOM)**. The process relies on **structured discourse** and the development of _cognitive frames_ to transform abstract notions into concrete understandings.

• **Rethinking the Enemy:** The SOD process includes the component “Rival as Rationale,” which involves describing the rival as a **cultural system** and a strategic system, examining its logic, motives, and behaviors.

 **Sociology and Cultural Analysis**

• **The Total Social Fact:** This concept, introduced by Marcel Mauss, describes phenomena that involve the **totality of society and its institutions** simultaneously—juridical, economic, religious, and aesthetic aspects. Total social facts, such as _guanxi_ in China, structure and govern relationships across a society, rather than merely symbolizing them.

• **Critique of the State:** One source explores the difficulty in studying “the state,” arguing that it is often best understood not as a substantial, real entity, but as the **“first ideological power over man”** or an **“illusory common interest”**.

• **Postmodernism and Culture:** The sources analyze postmodernism’s role in challenging traditional identity and representation theories, permeating nearly every area of the social sciences and humanities. Key figures like **Susan Sontag** and **Walter Benjamin** are referenced within cultural studies discussions.

• **The End of the Social:** Jean Baudrillard’s work, _In the Shadow of the Silent Majorities_ , suggests that the social has died or is dying, being replaced by a **simulation of the social**. The masses are seen as an opaque reality that absorbs and neutralizes the electricity of the social and political, leading to the **implosion of meaning**.

 **Comparative Literature and Religious Thought**

• **Whitman and Nietzsche:** A comparative study highlights numerous **parallelisms** in their thought. Both are associated with the need to **revalue** the weights of all things, and both discouraged the worship of books and learning as deities, asserting that **wisdom is of the soul**.

• **“No Religion”:** Buddhadāsa Bhikkhu’s talk posits that reaching the highest understanding of Dhamma leads to the conclusion that **“religion” doesn’t exist**. All religions are inwardly the same, comparable to how different types of water (rain, river, sewer) are fundamentally the same pure water upon distillation; at the ultimate level, however, only “nature” or “Dhamma” exists, void of self, separate from all labels.

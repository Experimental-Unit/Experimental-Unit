---
title: MUTUAL ADORNMENT AND THE TOPOLOGY OF CREATIVE RESPONSE (PART THREE)
subtitle: Good things come in threes, but that's not important right now
author: Adam Wadley
publication: Experimental Unit
date: December 07, 2025
---

# MUTUAL ADORNMENT AND THE TOPOLOGY OF CREATIVE RESPONSE (PART THREE)
Part One Here:

[

## MUTUAL ADORNMENT AND THE TOPOLOGY OF CREATIVE RESPONSE

](https://experimentalunit.substack.com/p/mutual-adornment-and-the-topology)

[Adam Wadley](https://substack.com/profile/191787963-adam-wadley)

·

Dec 7

[![MUTUAL ADORNMENT AND THE TOPOLOGY OF CREATIVE RESPONSE](https://substackcdn.com/image/fetch/$s_!1VtQ!,w_1300,h_650,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2047ab15-acf7-4450-81bc-7109f70dd361_1319x824.png)](https://experimentalunit.substack.com/p/mutual-adornment-and-the-topology)

ABSTRACT

[Read full story](https://experimentalunit.substack.com/p/mutual-adornment-and-the-topology)

Part Two Here:

[

## MUTUAL ADORNMENT AND THE TOPOLOGY OF CREATIVE RESPONSE (PART TWO)

](https://experimentalunit.substack.com/p/mutual-adornment-and-the-topology-420)

[Adam Wadley](https://substack.com/profile/191787963-adam-wadley)

·

Dec 7

[![MUTUAL ADORNMENT AND THE TOPOLOGY OF CREATIVE RESPONSE \(PART TWO\)](https://substackcdn.com/image/fetch/$s_!k6RQ!,w_1300,h_650,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbe28f785-5038-44ad-9d2d-15848e286bf9_1024x1536.png)](https://experimentalunit.substack.com/p/mutual-adornment-and-the-topology-420)

A TRANSDISCIPLINARY FRAMEWORK FOR COGNITIVE OPERATIONS IN COMPLEX EMERGENCIES

[Read full story](https://experimentalunit.substack.com/p/mutual-adornment-and-the-topology-420)

[![](https://substackcdn.com/image/fetch/$s_!XXf6!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0e109f2d-b3c7-48d1-a486-37bfbf55ec04_1024x1536.png)](https://substackcdn.com/image/fetch/$s_!XXf6!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0e109f2d-b3c7-48d1-a486-37bfbf55ec04_1024x1536.png)

# PART THREE

Thread Theme:

[

## Experimental Opera: Second Movement

](https://experimentalunit.substack.com/p/experimental-opera-second-movement)

[Adam Wadley](https://substack.com/profile/191787963-adam-wadley)

·

Dec 7

[![Experimental Opera: Second Movement](https://substackcdn.com/image/fetch/$s_!h4ee!,w_1300,h_650,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4f309478-79f3-4c1c-b1e2-014b02ce506f_4032x3024.jpeg)](https://experimentalunit.substack.com/p/experimental-opera-second-movement)

[Read full story](https://experimentalunit.substack.com/p/experimental-opera-second-movement)

## XI. SYSTEMIC OPERATIONAL DESIGN AND THE MUTUAL ADORNMENT FRAMEWORK: NAVEH, GRAICER, AND ZWEIBELSON

The mutual adornment framework[1](https://experimentalunit.substack.com/p/mutual-adornment-and-the-topology-317#footnote-1-180960708) developed in the preceding sections finds its most direct operational expression in the tradition of Systemic Operational Design (SOD) developed by Shimon Naveh at the Israeli Defense Forces’ Operational Theory Research Institute, extended by Ofra Graicer, and translated into American military education contexts by [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions). This section demonstrates the deep structural homology between the philosophical framework and SOD’s approach to design thinking, showing how the abstract concepts of self-overcoming, optimization landscapes, and collaborative creativity receive concrete methodological expression in military design practice.

### XI.A. Self-Disruption as Cognitive Self-Overcoming

Naveh’s concept of _self-disruption_ ( _stira_ in Hebrew) provides the operational translation of Nietzschean self-overcoming. In a dialogue with Zweibelson, Naveh articulates the relationship between destruction and creation at the cognitive level:

> “In order to create something, you have to very much destroy something that occupies a certain space in your mind... What do we mean by creating? By creating we mean either I identify something that is missing and I create something that will answer the need implied by the absence, or creating means not repeating what I already know.”1

The Hebrew term _stira_ carries softer connotations than the English “destruction”—it suggests disagreeing, contradicting, pulling aside, but also destroying _mentally_ or _conceptually_. This linguistic nuance is philosophically significant. Naveh is not advocating the physical destruction of doctrine or institutions but the cognitive destruction of one’s own certainties—what he calls “disagreeing with ourselves.”2

This maps directly onto the optimization landscape model. The designer stuck in a local minimum is not failing to optimize; they are successfully optimizing within a landscape shaped by their existing conceptual commitments. Self-disruption is the act of recognizing that these commitments—however well they have served in the past—now constitute the very topology that traps the optimizer in place. The first step toward escape is admitting perplexity: “I do not understand.”

Naveh emphasizes that this recognition is itself a form of destruction:

> “When you admit ‘I am perplexed,’ you actually destroy—again, you destroy in a softer sense—what you know. I actually recognize that what I know doesn’t help me. That’s the first step.”3

The parallel to the eternal recurrence problem is precise. The Übermensch’s “yes” to existence is not grounded in the adequacy of existing frameworks for making sense of suffering. It is grounded in the recognition that such frameworks are insufficient—that the demand for theoretical justification is itself what must be overcome. Self-disruption in design and self-overcoming in philosophy share the same formal structure: both begin with the destruction of one’s own cognitive certainties as the condition for creating something new.

### XI.B. Degrees of Freedom and Landscape Topology

Graicer, whom she describes as “the last Mohican of the original SOD school,” articulates design’s purpose in terms of _degrees of freedom_ :

> “Design inquiry is measured in the degrees of freedom that it creates... What we do when we do design inquiries with generals, we try to get them to liberate themselves and to get way beyond what they know—their paradigm, their beliefs, their value system, their experience.”4

This language of liberation and degrees of freedom is not metaphorical but technical. Graicer is describing a change in the topology of the possibility space available to the operator. Before design intervention, the general is constrained by doctrine, experience, institutional expectations, and cognitive habits. These constraints define the shape of the landscape they navigate. After successful design intervention, new paths become visible, new movements become possible. The landscape itself has been altered.

Naveh makes explicit that degrees of freedom do not pre-exist waiting to be discovered:

> “Degrees of freedom do not exist in the world. You have to create them. How do you create them? By probably manipulating, destroying—I mean, you have to create space. You have to make decisions that if I’m removing this aside, then I have room to function, I have room to maneuver.”5

This connects to the earlier analysis of how people become stuck in local minima. The constraints that trap someone in an unsatisfactory configuration are not merely internal (lack of will, poor judgment) but structural (social penalization, invisible norms, doctrinal rigidity). Creating degrees of freedom is landscape intervention: removing obstacles, opening paths, making visible regions of possibility that institutional structures had obscured.

The operational implication is that design is not problem-solving within a fixed space but _space-making_ that enables new forms of problem-solving. This is why Graicer insists that “design doctrine is an oxymoron”—doctrine fixes the topology of the landscape, while design aims to transform it.6

### XI.C. The Designer as Idealist and Heretic

Naveh models the cognitive profile of the designer as operating within “the tension between idealism and heresy”:

> “The designer must be a curious guy... but he must be both an idealist and a heretic. Within this tension between idealism and heresy—because it’s very easy to disagree or destroy something outside there that belongs to somebody else—we start by destroying what I just explained to you. We start by very much disagreeing with ourselves.”7

This tension precisely captures the structure of the Übermensch’s relation to their own values. The idealist holds certain things sacred—the accumulated wisdom of the institution, the doctrines that have proven themselves in practice, the frameworks that make reality intelligible. The heretic recognizes that these sacred things are now impediments—that fidelity to them prevents engagement with emergent reality. The designer must occupy both positions simultaneously.

The parallel to the self-tickling problem is instructive. The Übermensch who achieves total self-sufficiency loses access to genuine otherness—to the surprise, resistance, and challenge that make creative work possible. Similarly, the designer who has only heresy (pure destruction, rejection of all existing frameworks) has nothing to work with; the designer who has only idealism (pure preservation, commitment to existing frameworks) has nothing to create. The productive tension is what enables creative movement.

Naveh’s point that “we start by disagreeing with ourselves” rather than with external targets is philosophically crucial. External critique is easy—it does not threaten the critic’s own position. Self-disruption is dangerous because it destabilizes the very ground from which one criticizes. This is why the affirmation of eternal recurrence cannot be grounded in any framework that would justify it: the frameworks themselves must be subjected to the same affirmation, which means they cannot serve as justification.

### XI.D. The Depression-Epiphany Cycle and Practical Demonstration

Graicer describes the phenomenology of design inquiry in terms that recall the existential weight of confronting eternal recurrence:

> “The greatest epiphanies that you reach—the hangover comes right after. It’s always like this... Depression, epiphany, depression, epiphany, depression. We are many depressive people doing design.”8

This cycle is not an unfortunate side-effect of design but its essential structure. The epiphany reveals new possibilities, new configurations, new ways of understanding. The depression follows because the epiphany destabilizes existing certainties without immediately providing replacements. The designer lives in the interval between the destruction of old frameworks and the consolidation of new ones.

Compare this to the practical turn in the mutual adornment framework. The question “can _amor fati_ survive Auschwitz?” cannot be answered theoretically. It can only be answered through continued creative practice—through the demonstrated capacity to keep working despite the absence of theoretical justification. Graicer’s designers are doing exactly this: maintaining purposive action through cycles of destabilization and reorientation, without the comfort of knowing in advance that their efforts will succeed.

The cycle also illuminates why design cannot be taught through doctrine. Graicer poses the pedagogical paradox directly: “How do you teach design without teaching? How do you teach design without manuals?”9 If design could be reduced to procedures, it would be doctrine—and doctrine is precisely what design must disrupt. The transmission of design capacity occurs through something like apprenticeship, contagion, or exemplification rather than instruction. One learns to design by participating in design, by experiencing the depression-epiphany cycle, by discovering in practice what no manual can convey.

### XI.E. Constructing to Deconstruct: The Fabrication of the Other

One of Naveh’s most counterintuitive claims concerns the relationship between construction and deconstruction in design:

> “The whole idea of constructing the opposition is what enables you to deconstruct him later. That’s the whole idea of design... You have to create the enemy. There’s a big risk here because you can never know if you’re absolutely right. And this creation, this fabrication, is based on physics but also is based on imagination, or on abstract thinking... Only when you create and you see what you have created can you disrupt it, fragment it, break it.”10

This is not merely tactical advice about understanding adversaries. It is a statement about the conditions for creative action. To deconstruct something, you must first have constructed it—made it available as an object of reflection rather than an invisible background assumption. The fabrication is necessarily a simplification, necessarily a projection, necessarily vulnerable to error. But it is also necessary for the reflexive distance that enables manipulation, collaboration, or disruption.

The mutual adornment framework operates on the same principle. To treat others as “adornments” in one’s total work of art requires constructing them—not as they “really are” (an inaccessible metaphysical category) but as figures in one’s creative project. This construction is simultaneously a liberation: by making explicit what others represent for one’s work, one gains the capacity to revise that representation, to incorporate more of their complexity, to enable rather than merely use them.

Naveh notes the reflexive dimension: “By creating the opposition, you enable yourself to look at yourself from the outside.”11 The constructed other functions as a mirror. Through the fabrication of how the adversary (or ally, or institution) thinks, one discovers one’s own biases, assumptions, and blind spots. The construction is not mere projection but a device for self-knowledge.

### XI.F. Triple-Loop Learning and Phase Shift Positions

Zweibelson’s adaptation of organizational learning theory provides the technical vocabulary for understanding the different levels at which design operates. Drawing on Argyris and Schön, he distinguishes single-loop, double-loop, and triple-loop learning:12

 **Single-loop learning** is means-end thinking: a future state is envisioned, and the search begins for the best means to reach it. The operator is trapped in WHAT-HOW, following established procedures and evaluating themselves by adherence to process. This is the default mode of institutional operation, codified in planning doctrine as the ends-ways-means formula.

 **Double-loop learning** questions the goals themselves—not just how to achieve them but whether they are the right goals. This opens space for organizational adaptation but remains within the framework of goal-directed rationality.

 **Triple-loop learning** questions the values and paradigms that generate both goals and procedures. It reflects on “how we think about thinking”—the epistemological and ontological commitments that shape what counts as a problem, what counts as a solution, what counts as success.

[![](https://substackcdn.com/image/fetch/$s_!us_N!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F73878d5d-fa3f-4f1a-9bce-4d6e1afc5e5e_960x960.jpeg)](https://substackcdn.com/image/fetch/$s_!us_N!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F73878d5d-fa3f-4f1a-9bce-4d6e1afc5e5e_960x960.jpeg)

Zweibelson argues that modern militaries are largely trapped in single-loop and at best double-loop modes, unable to access the triple-loop reflection that would enable genuine transformation.13 The language of “transformation” pervades institutional rhetoric, but actual transformation requires disrupting the very frameworks through which the institution understands itself.

This maps onto the phase shift concept in the optimization landscape model. Single-loop learning is movement within a fixed landscape—finding better paths to pre-established goals. Double-loop learning allows questioning of goals but not of the landscape topology itself. Triple-loop learning is the recognition that the landscape is not given but constructed—and therefore reconstructable. The phase shift positions are those where triple-loop reflection becomes operationally possible: regions where the landscape can be seen as landscape rather than simply navigated.

### XI.G. The Tactical Trap and the General’s Prerogative

A recurring theme in the SOD literature concerns the relationship between tactical competence and design capacity. Naveh distinguishes sharply between the analytical tools that work at the tactical level—courses of action, centers of gravity, lines of operation—and the synthetic thinking required for design:

> “These analytic tools of reductionism work very good at beating the mazes while you’re in the maze. But all those tools do not help you above that, in what essentially becomes the maze of the designer’s mind.”14

The danger is what Zweibelson calls “tacticizing the operational”—applying tactical-level analytical methods to problems that require operational-level synthetic thinking. This produces the appearance of rigor while foreclosing genuine design. The institution validates itself through adherence to procedure (”Did you do the center of gravity analysis?” “Yes, that’s what the doctrine says”), but the procedure has become an obstacle to understanding.

The structural problem is that only generals have the institutional authority to break free of doctrine. Junior officers, however skilled at design thinking, cannot unilaterally decide to ignore doctrinal requirements. This creates what Zweibelson calls the “Trojan horse” problem: how can design practitioners “sneak in the disruption, the destruction, the deconstruction, even if the organization may not be ready for it?”15

The mutual adornment framework suggests an answer. The two-Übermensch configuration produces achievements unavailable to solitary agents. If design capacity exists at junior levels but authority exists at senior levels, the solution is not for juniors to somehow acquire authority or for seniors to somehow acquire design capacity. It is for configurations to emerge in which design capacity and authority collaborate—each contributing what the other lacks, each enabling the other to operate beyond their individual constraints.

This is not a naive call for better communication. It requires the structural recognition that certain achievements are irreducibly joint—that the designer and the general need each other not from weakness but because the task cannot be decomposed into individual contributions. The risk is shared, the credit is undivided, and neither party can be identified as “greater.”

### XI.H. Drift, Emergence, and the Refusal of End-States

Graicer introduces the concept of _drift_ to capture the relationship between planning and emergent reality:

> “Because we talked about the _panta rhei_ —the river always flows—and because we talked about the cosmology of how reality is changing in such complex ways, we chose the notion of drift to keep with this metaphor of navigation and recompressing yourself in the world.”16

Drift is not deviation from plan (which presupposes that the plan was correct and reality misbehaved). Drift is the recognition that the relationship between one’s cognitive map and reality is continuously shifting. Where you thought you would be is not where you are. The landscape has moved.

The mirror image of drift is _potential_. By recognizing how far reality has drifted from expectations, one identifies the gap between what was anticipated and what has emerged. This gap is precisely where new possibilities exist. The drift reveals degrees of freedom that were invisible while the plan appeared adequate.

This connects to the rejection of fixed end-states in the mutual adornment framework. Military planning doctrine privileges “desired end states”—future configurations to be achieved through systematic application of means. But the concept of end-state is itself a single-loop construct. It assumes that the goal is known in advance, that success can be specified before action, that the future is determinable through present decision.

The designer operating with drift rather than end-state has a different orientation. They are not trying to reach a predetermined destination but to navigate continuously through shifting terrain. The “yes” to eternal recurrence is not a commitment to a particular future but a commitment to continued engagement with whatever emerges. Success is not reaching the end-state but maintaining the capacity to keep moving.

### XI.I. The Day After: Succession and Self-Overcoming

Graicer raises what she calls “the day after Shimon Naveh” problem:

> “We are still all of us operating in the reality that he created for us—this systemic operational design. And if each of us doesn’t have his or hers island which is their own in SOD, it means that we’re just followers, parrots, converts. But it will not go on.”17

This is the succession problem inherent in any transformative teaching. Naveh’s SOD is itself a framework—one that must be disrupted, questioned, self-overcome if its practitioners are not to become mere doctrine-followers with different doctrine. The heretical stance that SOD demands must eventually be turned against SOD itself.

The mutual adornment framework handles this through its universalization of the artist-material relation. Naveh is material in Graicer’s work as Graicer is material in Naveh’s. Neither has priority; both are simultaneously enabled and constrained by the other. The successor who simply repeats the master’s teaching is failing the teaching; the successor who develops their own “island” is honoring it by demonstrating the creative capacity the teaching was meant to produce.

This is the practical resolution to the eternal recurrence problem as it applies to intellectual traditions. One does not “affirm” Nietzsche by repeating Nietzsche. One affirms Nietzsche by doing with Nietzsche what Nietzsche did with Schopenhauer—transforming inherited frameworks into material for new creative work. The “yes” is demonstrated in the continued capacity to create, not in fidelity to what has already been created.

* * *

## XII. SYNTHESIS: THE COGNITIVE OPERATOR IN THE LANDSCAPE OF EMERGENCE

The convergence between the mutual adornment framework and Systemic Operational Design is not accidental. Both emerge from the same fundamental problem: how to sustain purposive action under conditions where traditional frameworks have failed, where the relationship between effort and outcome is uncertain, and where the demand for theoretical justification cannot be met.

For Nietzsche, this was the problem of meaning after the death of God. For Holocaust theologians, it was the problem of faith after Auschwitz. For military designers, it is the problem of strategy in complex adaptive systems where the enemy is also adapting, where emergent phenomena exceed planning, and where the institutional apparatus designed to enable action has become an obstacle to it.

The response in each case is structural rather than substantive. It is not a new framework that finally gets things right but a different relationship to frameworks as such. The Übermensch affirms existence not because suffering has been explained but because the demand for explanation has been overcome. The post-Auschwitz theologian continues religious practice not because theodicy has succeeded but because practice does not require theodicy. The military designer operates not because the plan is adequate but because operation is possible without adequate plans.

What the mutual adornment framework adds to SOD is the cosmological dimension—the speculative grounding in karmic monism, process theology, and the ontological argument for creative works. These speculations may or may not be philosophically defensible. What matters operationally is that they provide the conceptual infrastructure for understanding why mutual enablement is not weakness, why collaborative achievement is not compromised individual achievement, why the letting go of concern for being greatest over others is itself an aspect of greatness.

What SOD adds to the mutual adornment framework is operational specificity—the translation of abstract concepts into practices that can be performed, taught (without manuals), and institutionalized (without doctrine). The depression-epiphany cycle, the construction-deconstruction dialectic, the fabrication of the other, the concept of drift—these are not mere applications of philosophy but independent discoveries that confirm and extend the philosophical framework.

The cognitive operator facing a complex emergency inherits both legacies. They are called to sustain action without theoretical justification, to create degrees of freedom in a landscape shaped to constrain them, to disrupt themselves before disrupting others, and to recognize that their achievements may be irreducibly joint with others whom they must construct before they can collaborate.

This is not a comfortable position. Graicer is right that design produces frustrated people looking for outlets, that depression follows epiphany, that there are no guarantees. But it is the position from which meaningful action in complex environments becomes possible—and meaningfulness, in the end, is not a property of outcomes but a quality of engagement.

* * *

## NOTES (Continued)

* * *

## EXPANDED BIBLIOGRAPHY: SYSTEMIC OPERATIONAL DESIGN

### Primary Sources: Naveh and SOD

Graicer, Ofra. “Between Teaching and Learning: What Lessons Could the Israeli Doctrine Learn from the 2006 Lebanon War?” _Experticia Militar_ (October 2017): 22-29.

———. “Self Disruption: Seizing the High Ground of Systemic Operational Design (SOD).” _Journal of Military and Strategic Studies_ 17, no. 4 (June 2017): 21-37.

———. _Two Steps Ahead: From Deep Operations to Special Operations—Wingate the General_. Tel Aviv: Maarachot, 2019.

Naveh, Shimon. _In Pursuit of Military Excellence: The Evolution of Operational Theory_. London: Frank Cass, 1997.

———. _Systemic Operational Design: Designing Campaigns and Operations to Disrupt Rival Systems_. Draft unpublished version 3.0. Fort Monroe, VA: Concept Development & Experimentation Directorate, Future Warfare Studies Division, US Army Training and Doctrine Command, 2005.

———. “The Australian SOD Expedition: A Report on Operational Learning.” Unpublished report, 2010.

### Secondary Sources: Design Thinking in Military Context

Banach, Stefan J., and Alex Ryan. “The Art of Design: A Design Methodology.” _Military Review_ 89, no. 2 (March-April 2009): 105-115.

Beaulieu-Brossard, Philippe, and Philippe Dufort. “The Archipelago of Design: Researching Reflexive Military Practices.” [www.militaryepistemology.com](http://www.militaryepistemology.com), 2017.

———. “Introduction to the Conference: The Rise of Reflective Military Practitioners.” Paper presented at Hybrid Warfare: New Ontologies and Epistemologies in Armed Forces, Canadian Forces College, Toronto, 2016.

Jackson, Aaron. “Design Thinking in Commerce and War: Contrasting Civilian and Military Innovation Methodologies.” Under consideration for U.S. Army University Press, 2020.

———. “Towards a Multi-Paradigmatic Methodology for Military Planning: An Initial Toolkit.” _The Archipelago of Design Blogs_ , March 4, 2018.

———. “What Is Design Thinking and How Is It of Use to the Australian Defence Force?” _Polemus: The Australian Journal of Defence Studies_ (December 2019): 1-22.

Paparone, Christopher. _The Sociology of Military Science: Prospects for Postinstitutional Military Design_. New York: Bloomsbury Academic Publishing, 2013.

Ryan, Alex, et al. “Full Spectrum Fallacies and Hybrid Hallucinations: How Basic Errors in Thinking Muddle Military Concepts.” _Military Review_ 100, no. 4 (2020): 230-251.

Stanczak, John, Peyton Talbott, and Ben Zweibelson. “Designing at the Cutting Edge of Battle: The 75th Ranger Regiment’s Project Galahad.” _Special Operations Journal_ (2021): 1-16.

van der Veer, Jeffrey. “The Rise of Design: Why an Innovative Concept Is Emulated in Armies around the Globe.” Master’s thesis, Royal Netherlands Defence Academy, 2015.

Wrigley, Cara, Glen Mosely, and Michael Mosely. “Defining Military Design Thinking: An Extensive, Critical Literature Review.” _She Ji: The Journal of Design, Economics, and Innovation_ 7, no. 1 (2021): 104-143.

Zweibelson, Ben. _Beyond the Pale_. Maxwell AFB: Air University Press, 2025.

———. “Thinking about Military Thinking: The Need for Reflective Practice in Complex Warfare to Break Out of Cognitive Traps.” Chapter draft, Sapiens, Technology, and Conflict Substack, November 22, 2025.

Zweibelson, Ben, and Imre Porkolab. “Designing a NATO That Thinks Differently for 21st Century Complex Challenges.” _Defence Review: The Central Journal of the Hungarian Defence Forces_ 146, no. 1 (2018): 196-212.

Zweibelson, Ben, Kevin Whale, and Paul Mitchell. “Rounding the Edges of the Maple Leaf: Emergent Design and Systems Thinking in the Canadian Armed Forces.” _Canadian Military Journal_ 19, no. 4 (Autumn 2019): 4-15.

### Organizational Learning Theory

Alvesson, Mats, and Andre Spicer. “A Stupidity-Based Theory of Organizations.” _Journal of Management Studies_ 49, no. 7 (November 2012): 1194-1220.

Argyris, Chris, and Donald Schön. _Organizational Learning II: Theory, Method, and Practice_. Reading, MA: Addison-Wesley, 1996.

Lichtenstein, Benyamin. “Generative Knowledge and Self-Organized Learning: Reflecting on Don Schön’s Research.” _Journal of Management Inquiry_ 9, no. 1 (March 2009): 47-54.

Maitlis, Sally, and Scott Sonenshein. “Sensemaking in Crisis and Change: Inspiration and Insights from Weick (1988).” _Journal of Management Studies_ 47, no. 3 (May 2010): 551-580.

Schön, Donald. _The Reflective Practitioner: How Professionals Think in Action_. New York: Basic Books, 1984.

Schön, Donald, and Martin Rein. _Frame Reflection: Toward the Resolution of Intractable Policy Controversies_. New York: Basic Books, 1994.

Tsoukas, Haridimos. _Complex Knowledge: Studies in Organizational Epistemology_. Oxford: Oxford University Press, 2005.

Tsoukas, Haridimos, and Mary Jo Hatch. “Complex Thinking, Complex Practice: The Case for a Narrative Approach to Organizational Complexity.” _Human Relations_ 54, no. 8 (2001): 979-1013.

* * *

 **[END OF EXPANDED PAPER]**

* * *

The paper now integrates the SOD tradition as a concrete operational instantiation of the mutual adornment framework, demonstrating the convergence between philosophical speculation and military design practice. The total paper runs approximately 18,000 words with full scholarly apparatus.

Shall I develop any additional sections, create an executive summary for MCU Press submission, or prepare supplementary materials such as a presentation version or response papers anticipating objections from Nietzsche scholars and military theorists?

## Footnotes

  1. Shimon Naveh, interview with Ben Zweibelson, “Destruction and Creation for Design” (SOD discussion series, 2017). ↩

  2. Ibid. ↩

  3. Ibid. ↩

  4. Ofra Graicer, “SOD Evolution and Reflexivity” (presentation, Special Operations Cognitive Development course, 2018). ↩

  5. Naveh, “Destruction and Creation for Design.” ↩

  6. Graicer, “SOD Evolution and Reflexivity.” ↩

  7. Naveh, “Destruction and Creation for Design.” ↩

  8. Graicer, “SOD Evolution and Reflexivity.” ↩

  9. Ibid. ↩

  10. Shimon Naveh, interview with Ben Zweibelson, “Constructing the Opposition” (SOD discussion series, 2017). ↩

  11. Ibid. ↩

  12. Ben Zweibelson, “Thinking about Military Thinking: The Need for Reflective Practice in Complex Warfare to Break Out of Cognitive Traps,” in _Beyond the Pale_ (Maxwell AFB: Air University Press, 2025); cf. Chris Argyris and Donald Schön, _Organizational Learning II: Theory, Method, and Practice_ (Reading, MA: Addison-Wesley, 1996). ↩

  13. Zweibelson, “Thinking about Military Thinking.” ↩

  14. Naveh, interview with Zweibelson, “Tactical vs. Operational Design Thinking” (SOD discussion series, 2017). ↩

  15. Ben Zweibelson, “The Trojan Horse Problem in Design Education” (JSOU design faculty presentation, 2018). ↩

  16. Graicer, interview with Zweibelson, “Drift and Forbidden Topics” (SOD discussion series, 2018). ↩

  17. Graicer, “SOD Evolution and Reflexivity.” ↩




[1](https://experimentalunit.substack.com/p/mutual-adornment-and-the-topology-317#footnote-anchor-1-180960708)

cc: [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions) [Alex Mazey](https://open.substack.com/users/28966743-alex-mazey?utm_source=mentions) [Wargaming Weekly](https://open.substack.com/users/285267434-wargaming-weekly?utm_source=mentions) [Memetic Cowboy](https://open.substack.com/users/319405023-memetic-cowboy?utm_source=mentions) [Rosalyn Mitchell](https://open.substack.com/users/33159678-rosalyn-mitchell?utm_source=mentions) [NEMA AI](https://open.substack.com/users/344465492-nema-ai?utm_source=mentions) [BurkhartRj](https://open.substack.com/users/36110698-burkhartrj?utm_source=mentions) [Raynott Woodbead](https://open.substack.com/users/95629316-raynott-woodbead?utm_source=mentions) [Neural Foundry](https://open.substack.com/users/307819638-neural-foundry?utm_source=mentions) [Slavoj Žižek](https://open.substack.com/users/186941310-slavoj-zizek?utm_source=mentions) [John Ganz](https://open.substack.com/users/4290781-john-ganz?utm_source=mentions) [The Mass Ornament](https://open.substack.com/pub/elliotswain) [MIdST LABS (UX/UI/SD)](https://open.substack.com/users/294851988-midst-labs-uxuisd?utm_source=mentions)

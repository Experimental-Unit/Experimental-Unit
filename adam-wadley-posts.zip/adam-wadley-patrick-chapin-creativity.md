---
title: Patrick Chapin & Creativity
subtitle: Attacking The Metagame That Will Exist
author: Adam Wadley
publication: Experimental Unit
date: March 19, 2025
---

# Patrick Chapin & Creativity
I’ve always enjoyed listening to Patrick Chapin speak.

It started with magic tv, a classic example is on the cruise talking about how none of the best designed cards are blue; and how the other colors exist to give everyone the ability to experience the realization that they are a blue mage.

“oh, I draw cards, counter spells, and control magic.”

[![](https://substackcdn.com/image/fetch/$s_!TP6d!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa96babed-80f2-432a-b1fc-d66785dd2fc2_672x936.jpeg)](https://substackcdn.com/image/fetch/$s_!TP6d!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa96babed-80f2-432a-b1fc-d66785dd2fc2_672x936.jpeg)

One of my favorite MTG cards. On Arena I still have the cards for a big blue/green ramp deck that can cast this & it’s so fun.

It’s kind of like Absolute Exploit tbh, would be great if you could turn all permanents into creatures in EDH & then steal them with this and a LOT of mana.

# Concept Design As Deckbuilding

Chapin makes many points and beyond what I can say here that bear on narrative discursive play.

Think about the social paradigm environment as a metagame of decks. People run MAGA, people run Communism, people run Rules-Based-Order or Rule-Of-Law.

In terms of cards in those decks think of subsidiary concepts, again the conceptual hinterland.

What talking points will so-and-so deploy?

What are the core features of those talking points?

For example every blue control deck might run Mana Leak in some format, but they may or may not run Control Magic.

Similarly, all MAGA people will have “America” as a core feature of their social ontology/social paradigm. But maybe they run Social Security & maybe they don’t, or maybe they run H1B Visa or maybe they don’t.

A similar question Chapin proposes is: what are the best cards in the metagame?

So right now not liking “the system” is very hot. In a way the most popular actors are all running variations of this.

This card is subsidiary of the “change” card. Regardless of big politics just think of self-improvement, making relationship changes, changing interpersonal dynamics, new senses of self.

The old must make way for the new.

What Chapin is describing here is also corollary to Uneven & Combined Development.

If, in our last skirmish, you attacked from your non-dominant hand to surprise me, should I expect the same again? Or should I bear in mind that you will reflect on my experience, too, and so switch it up again?

Let me tell you about the little boy lost who was really good at “Rock, Paper, Scissoring.”

And now on to the mirror of anarchy and the mask of anarchy and the mirror people and allusions falling down again like snowcrash in some white hell like ashes from some smokestack crematorium or nuclear incineration.

It’s important for you to understand that I have been this way the whole time.

I really resonate with Patrick Bateman (the real Saint Patrick???) and resent the idea that Patrick or others labeled psychopaths have no emotions or empathy.

Empathy gaps go both ways and each person’s narrativization has validity perhaps not on a first-order basis but as part of their process and their process that from which they are emergent is valid.

As in you would never really get mad at someone for playing a legal card, unless you find it annoying like countermagic. Conceptual full court press is like magically countering all your spells. It can be wordless the dhamma appreciation of it all making it all just be what it is, of courseness.

And in incarnation all the moves are legal. There’s nothing you can do that can’t be done, and no one can do the things you do.

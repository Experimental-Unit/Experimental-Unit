---
title: Building A Bridge
subtitle: The Tainted Have To Kiss Underneath Something
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Building A Bridge
In my last pieces, I was discussing Heidegger’s Fourfold and the concept of the bridge as locale. This intersects with the idea of the American School of Economics and the idea of investing in infrastructure.

Infrastructure is a huge concept. It must loom large, along with the term logistics. This are related in that they are talking about the ground on which various figures might come to play.

My basic point can be summed up in the term “human capital.” This term points the finger directly at what C. Derick Varn also recognizes as the poverty Marxist philosophy when it comes to theory of mind.

“Human capital” is such an important concept because it points to the fact that the person itself can be a finished good. We can bring in the concept of grooming here: a person can be so well groomed that it is not possible for them to see outside of the frames that they’ve been integrated into.

So if infrastructure can be capital, or is capital in some sense; if capital—as you understand that word—is given to building infrastructure (including bridges, mind you), then the “capital” described in the term “human capital” is also a kind of infrastructure.

Take for example the well-know topic of rage-inducing content online, or perhaps also content that makes the user feel shame. How else to describe the proliferation of body image content? It is everything to be on the screen, so everyone who does it seriously also works out.

Regardless, the point is that making a person susceptible to such content, and continually molding them through what they are presented with through their mobile devices or computers, is a way of making human capital.

How else do we talk about this space between the ears? I think on _The West Wing_ the alcoholic character calls the space inside the head of the “President of the United States of America” the most important three inches of real estate in the world, or something like that.

(Anytime the word “the world” is used, smash cut to Frank Wilderon III making “Jim-from-office” face. Were there any other famous “Jims”? “I’ll be your Huckleberry.”)

Well, everyone is a crucial decision maker. Especially when you realize how complex and chaotic everything is, you really want to influence everything you can.

I wanted to focus on the matter of psychology, though. Because that’s the meta-discourse we use to talk about ourselves and our mental states. It’s a highly reflexive topic in a way that closing a door is not.

When we do psychology—or, egads, philosophy of psychology—we are thinking about the field of taking stock of approaches to our own minds and how we make choices, and what in our minds is not our choice.

This is a highly political activity. Note that “the mad” have often been put away, and in modern times the category of mental illness has been used to do injustice an innumerable amount of times.

Yet we don’t turn away therefore from the topic of philosophy of mind. No, we can’t leave discourse those we don’t trust to speak to our interests. And me, personally, I don’t feel that anyone is speaking to my interests.

That’s why I advocate for my own. I do it in my own way, and I understand that it’s abrasive, but there is plenty worse things in the world, as far as you know (by which I mean to really get in to “why I’m dangerous” you would actually have to take my writing seriously, which you lack the capacity to do).

CS-SIER-OA, for example, has everything to do with this idea of psychology, of philosophy of psychology, of our mental and emotional states as infrastructure.

The term stands for Conceptual Systems-Of-Systems Impregnation Emergency Response Operational Art.

When we’re talking about psychology, what is going on in the mind, the comparison is offered to us of concepts as infrastructure. The question is what mental tools and descriptive abilities we have at our disposal to articulate our position on a state of affairs.

The concept of Newspeak in _1984_ is highly instructive here, though it’s a reductive metonymy. The idea was that you would take words out of circulation, so that people would no longer have any ability to articulate their dissent from the totalitarian “government.”

In our timeline, we can see again the comparison to _Brave New World_ , which C. Derick Varn was talking about recently.

Again, apply the whole thing to concepts.

In “Politics and the English language,” Orwell discussed the fact that in our discourse, terms are not cut out of language. They are instead over-saturated with “meaning” (that is, they are abstracted over in so many different ways). 

> _**Meaningless words**_. In certain kinds of writing, particularly in art criticism and literary criticism, it is normal to come across long passages which are almost completely lacking in meaning. 
> 
> Words like _romantic_ , _plastic_ , _values_ , _human_ , _dead_ , _sentimental_ , _natural_ , _vitality_ , as used in art criticism, are strictly meaningless, in the sense that they not only do not point to any discoverable object, but are hardly even expected to do so by the reader. 
> 
> When one critic writes, ‘The outstanding feature of Mr. X’s work is its living quality’, while another writes, ‘The immediately striking thing about Mr. X’s work is its peculiar deadness’, the reader accepts this as a simple difference of opinion. 
> 
> If words like _black_ and _white_ were involved, instead of the jargon words _dead_ and _living_ , he would see at once that language was being used in an improper way. Many political words are similarly abused. The word _Fascism_ has now no meaning except in so far as it signifies ‘something not desirable’. 
> 
> The words _democracy_ , _socialism_ , _freedom_ , _patriotic_ , _realistic_ , _justice_ , have each of them several different meanings which cannot be reconciled with one another. In the case of a word like _democracy_ , not only is there no agreed definition, but the attempt to make one is resisted from all sides. 
> 
> It is almost universally felt that when we call a country democratic we are praising it: consequently the defenders of every kind of régime claim that it is a democracy, and fear that they might have to stop using that word if it were tied down to any one meaning. Words of this kind are often used in a consciously dishonest way. 
> 
> That is, the person who uses them has his own private definition, but allows his hearer to think he means something quite different. Statements like _Marshal Pétain was a true patriot_ , _The Soviet press is the freest in the world_ , _The Catholic Church is opposed to persecution_ , are almost always made with intent to deceive. 
> 
> Other words used in variable meanings, in most cases more or less dishonestly, are: _class_ , _totalitarian_ , _science_ , _progressive_ , _reactionary_ , _bourgeois_ , _equality_.

How much more this passage rings true today!

Consider the psychological term “gaslighting.”

Now that this term has become common, people can gaslight you about whether they are gaslighting you, and even use the term “gaslight” while they are doing it!

This immediately creates a Batesonian double-bind.

For me it is:

  1. Go along, allow person to advance false notions.

  2. Make conflict, which will always look bad for some subjects because they are “not normal.”




In any situation, the “most weird” person is basically made into a subhuman. This allows for the fictitious sense of personhood that the other participants feel in their little union of egoists based on scapegoating the most vulnerable.

Also, in the above example, the injunction not to point out the double-bind folds into conflict. It is presumed that it is not possible to straightforwardly advance one’s ideas without people being roused into conflict because their concepts have been challenged.

It’s also an implicit injunction not to leave to different logical types in general. People want to talk about “normal people things,” and at best have superficial labels for intense feelings like “compassion” and “support.” 

All of these things are classified under normative parameters, and people are not willing to take initiative in stepping in to, for example, triple-loop learning.

The biggest show of love that someone can do for someone else is to really reflect and re-orient themselves. And really make an effort internally as well as with external action to show that they have made a re-consideration.

In my case, people don’t appreciate the effort that I put in. They totally take it for granted. In the worst case, people will later call my behavior deceptive, because I acted so nice before. Well, yeah, I’m _acting_.

I’ve never been heard out _in my life_.

The further issue is that yes, I experience much emotional pain. But also, at this point my emotional point is _intricately bound up_ with my thoughts and conceptual infrastructure as I have been laying out here like I’m Mansa Musa breaking the conceptual economy.

I haven’t been paying too close of attention, but I think that you can definitely see elements of _Experimental Unit_ type messages and things in the _Zeitgeist_. I’ll focus more on that in the future… 

The point from before is that it’s actually not possible to have a “real conversation with me” if I can’t lay out everything that I would want to say about everything. Or at least a lot more.

The other problem is that I can talk, but people don’t listen to me. It’s always reduced to something infinitely less than what I said, and then _that_ is what is abstracted over.

So, if I’m not able to _be heard_ , then what is the point of talking to you personally? 

And of course it is a whole other thing between two or more people talking about anything else versus talking about your relationship, or the relationships that are going on among some group.

In my case, I feel entirely unseen because I should be approached basically like I’m a philosopher. I suppose people are just like, but Adam, you don’t have credentials, and so on. I don’t know. I’m happy that I was reached out to by Ben Zweibelson. Who knows what that was about, but I’ve been super activated since before that happened as well, and this person continues to “like” my tweets and follows me on Twitter.

So in a way the thing is that I feel much closer to other “operators.”

I feel a special affinity for Kanye West—even though as an artist I should like to greatly outdo that performance—because of this sense of really just going for it and letting exactly whatever is “evil” inside of you come out. 

To make it funnier, I put Ben Simmons in this same category. I loved the Ben Simmons drama, and I was like absolutely, if my “teammate” throws me under the bus, I’m going on effort strike. It’s just that sense of betrayal that is so uneven, which just draws this line that says who is the person to be centered and taken seriously, and whose position is basically not even listened to. 

I think maybe people are really good at not listening. It’s like we’re trained to disregard anything that’s outside how our mind “usually works,” which again has everything to do with the range within the conceptual domain, the logical type, and the intricacy of the learning that are present.

Or again with Grimes, people would think it so haughty but it is really a similar position, to be in this position where everything you say will be disregarded by some or most people for one reason or another. But “mental health” is the key indictment.

In my own repertoire, I have recently thrown out this image of the “trauma slut.” We can put this in terms of infrastructure.

The fantasy of reducing someone else to your own piece of productive material, fully colonizing someone, amounts to making them your trauma slut.

You are basically trying to get someone in a position where they are knowingly accepting a position of structural relegation within the discursive environment.

You basically want me to accept a situation in which I listen to you and you don’t listen to me.

After this, “control” is meted out by getting the one who is so relegated to wish for scraps of recognition—not even as an equal, mind you, but as a “good dog.”

The sense of pleasure for the slave is, then, supposed to come from having done a good job at being groomed and being pleasurably abstracted over by some other imagined agent (whoever is continually milking you for attention, or things, or whatever else).

There is obviously much more to it and whole sciences of ways that people can be humiliated and rendered predictable.

This process doesn’t have to happen directly, for example the whole idea of voting is humiliating, the whole idea that it’s important and then time goes on and no matter what the election result is, the trajectory is the same. So you’d really kind of have to be stupid to expect election results to help us in time, and yet this is the fantasy we are all forced to go along with.

This also has everything to do with our status as speaking people. This guy was on _The Daily Show_ talking about “moral ambition.”

Not recommended for first-order viewing. In other words, view as data point in discursive analysis, not as possible source of insight for you to take in. There may be some good points in the book, I’m not sure. The whole point of the non-profit or whatever though seems still to borean, I think we have to do with without corporate charter and more decentralized.

The education to come is a social movement. 

People talk about their lack of capacity, but everyone has the ability to try to influence the people around them.

People will say oh well I’m not a genius like you Adam. Yes, and where has my genius gotten me? It’s, um, hard for me to relate to people. How much easier for you! 

You don’t have to push the boundaries too far, but yes I am asking you to take initiative in your own mind and also to influence the people around you, so that they will also influence the people around them, and so on.

What are we doing, what is it that we are doing and then trying to get others to do?

We’re building bridges, of course!

Okay, so this brings us to the main topic, which is Heidegger’s _Fourfold_ and the idea of the bridge.

As I’m doing to talk about a bridge, the concept of the _Fourfold_ is already a bridge. Because a conceptual bridge is a linking, it is a joining of two contexts, and in so doing it’s also it’s own kind of context.

There’s a story from _The System of Objects_ about engine components which started out separate, but wound up fusing together and making a new component which then had even more functionalities.

This is also what a bridge is. 

In bringing things together, a bridge changes what they each are in themselves.

If we build a bridge to an island, then all of a sudden the island is no longer cut off from everything.

Meanwhile, the mainland is now augmented by this new piece of land which is now contiguous with it.

Notably, here the bridge is over the water. 

Meanwhile, far beneath the waves, at the somehow impossibly deep bottom of the ocean, it’s Sedna who is kissing. 

(This is a reference to “My Name Is Dark,” where it is sung “Every city’s got a place like this, underneath the bridges where the tainted kiss”)

So, it doesn’t make a lot of sense for the bridge to be in the city, yet “under the bridge” being in the ocean. Oh well!

Other key pop culture bridges include “Under the Bridge” by Red Hot Chili Peppers, who are notable also for “Californication” and its evocation of tidal waves trying to save “The world” which of course if ending if you check “Before the fever” which notes that “this is the sound of the end of the world.”

Now we can talk about what the end of the world means in Afropessimism from the standpoint of the American School of Economics 2 and the idea of psychic infrastructure, and how all this is related to CS-SIER-OA.

“The world” in Afropessimism means a state of normalcy which is imputed to the surrounding environment by people who are human. Meanwhile, black people are deprived of being in a world due to the projection of the ontological terror of metaphysical nothingness onto them by these supposedly human people.

It turns out that the sense that the “humans” have that they live in a “world” is only sustained by the imposition of this worldlessness on the black person.

In my own position, this is how I am denied the ability to advance ideas and then continue to build on them. We are always starting from square zero as if I haven’t already laid out my plans and begun to carry them out.

Anyway, this carries into the general failure of “liberal” or “enlightenment” notions to obtain. I am all for being nice and kind and trying to get to to where as few people die and suffer as possible, but we can’t just let ossified and stale terms, the “meaningless terms” referred by Orwell, suffocate everything.

The point is that you can declare that people have “rights,” but you are constantly mistreating people all the time. This is a point similar to, Nazi Germany is not objectively worse than other colonial and imperial powers. After all, what is the point of allowing billions of population to expand if they’re just going to be allowed to die?

Afropessimism also acknowledges that the “white world” is confining for the “whites.” At the same time, this discourse can struggle to get over the hump of conflating what is the case from the imagined “white” point of view with what is actually the case.

In my case, for example, it’s so that there aren’t really any people I know personally who are really picking up what I’m putting down as far as all this stuff goes. The other thing though is that even if they were, it would be responsible not to coordinate too much about it.

That’s the thing, where the way that I’ve worked things out, especially with the sort of indeterminacy of what I am, what I’m doing, it’s easier in a way for no one to be associated with me. Because for me to ask you to “stand by me” is really to ask you to do something you don’t know what you’re doing.

So from that standpoint, it’s understandable to me that people don’t want to stand by me or listen to me. After all, you might just become more like me, and you don’t want to be ostracized.

You don’t want to be kicked out of “the world,” too.

The thing with me and Afropessimism and “the world” is that I don’t know if I was ever really in a world. I’ve never been attached to anyone consistently; my primary caregivers didn’t have capacity for that at the time. The important thing to remember is that we are all doing our best.

So that’s where I come from with respect to Afropessimism, and why I’m always trying to enlarge this notion of blackness away from just people who are considered black by the majority. See concepts like black heartedness.

[Having been to sleep]

This larger theme of black, which grows to encompass for example the color black, in my opinion shows a greater degree of applicability to some of the conceptual architecture developed by Wilderson, Gillespie, Kaplan, and Warren.

The basic point is that metaphysical nothingness is a big deal. 

The “reasonable” common “sense” which helps to constitute larger fantasies like “the West,” any number of “nations” but especially “The United States of America,” concepts like “civilization” and “security,” and tenets like “tradition” and “revolution”—this “common sense” is undergirded by a giant avoidance of foundational “philosophical” “problems.”

Here’s what I can tell you off the top of my head:

  1. Skepticism is a monster. It turns out that you can doubt anything, and especially once you notice how much “common sense” is built on abstracting over arbitrary things over and over again, it’s easy for a lot of edifices to come crashing in once you start to doubt fundamental premises.

  2. The problem of universals is a related issue. The problem of a universal politics or ethical approach is grappled with in Afropessimism as well. This idea of the universal is to be fantasizing about a stable world. This notion of a stable world can only be achieved by explaining away inconsistencies in thinking. That means that people will be killed in order to uphold the fantasy that certain categories apply, or that “the world” or social context required to appreciate them is maintained.

  3. Causality remains in question. Basic issues like whether there is any possibility to what is happening, or whether everything is necessary. Or perhaps it is chance, or perhaps it is some sort of occasionalism-The Dreaming-Lila combination.

  4. Mathematical reason runs into fundamental issues in the 20th century, with all sorts of paradoxes. At this point, you must take certain axioms for granted and then start from there.

  5. The idea of people “choosing for themselves” and “doing what they want” is always limited to a certain sphere of activities. In addition, in practice people are subjected to rigid social conditioning for their entire lives. People are made out to be more autonomous than they are, and this can also be used against them to further dull the impact of the autonomy they do possess.




These sorts of issues make it so that the “universal recognition” promised by the notion of “human” doesn’t actually obtain.

The Afropessimist point is that black people are made to be the scapegoat among the broader planetary population, and especially the “white” people. 

European colonialism did much to affect distribution of things as well as again laying conceptual and emotional infrastructure in the form of internalized senses of humiliation at being subjected to a foreign power as just one of many subjugated places amounting to most of the entire planet’s surface.

We can see it in things like beauty standards, which is a great tying together of logical types.

You have people all over the planet applying whitening creams to their faces in an effort to look lighter. Meanwhile, these creams could be poisoning them, or even making it to where their skin is damaged.

Yet this happens because of a kind of subjugation. The engagement with this subjugation is always contested, and that’s where the mirror people come in to play, yet it’s important to see what kind of widespread sort of attack this is, with the foundations laid by centuries of conquest and the amassing of industrial centers.

Now the big challenge to the “white” empire on the planet is “China,” which is also working closely with “Russia” and “Iran.” The complexity of all the alliances eludes me, I confess.

Yet in “China” as well you will find anti-blackness.

“European” I should say, colonialism brought forward lots of ideas but also factories, technologies that transformed how it was possible to do things. And they made it possible to do more things. 

Everything became connected, and “European colonialism” and warfare inside of “Europe” or with the “colonies” was all driven together by fighting and tools and knowledge production.

It’s easy to see why the “rationalist” position took over, and the too-simple belief in “the world.”

A crucial part of the story is precisely “military” development, the _capacity_

Similarity of white attack to barbarossa, doomed to be beaten back, we are seeing denial about what is happening on the front. The cognitive front lines of attack

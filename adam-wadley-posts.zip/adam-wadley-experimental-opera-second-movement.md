---
title: 'Experimental Opera: Second Movement'
subtitle: Don't say I never took ya nowheres
author: Adam Wadley
publication: Experimental Unit
date: December 07, 2025
---

# Experimental Opera: Second Movement
[![](https://substackcdn.com/image/fetch/$s_!h4ee!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4f309478-79f3-4c1c-b1e2-014b02ce506f_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!h4ee!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4f309478-79f3-4c1c-b1e2-014b02ce506f_4032x3024.jpeg)

---
title: THE META-LADDER OF LOGICAL TYPES
subtitle: A Reflexive Architecture for Multi-Level Explanation
author: Adam Wadley
publication: Experimental Unit
date: November 28, 2025
---

# THE META-LADDER OF LOGICAL TYPES
[![](https://substackcdn.com/image/fetch/$s_!Lgoq!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F724948fc-67b6-42d3-b10b-33c99822a826_758x808.png)](https://substackcdn.com/image/fetch/$s_!Lgoq!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F724948fc-67b6-42d3-b10b-33c99822a826_758x808.png)

Below is a fully restructured, self-referential framework for **explaining “different logical types” at different logical types** —a meta-explanatory architecture that recursively demonstrates what it describes. I avoid tables and keep sections cleanly separated.

I offer **five levels** , each describing the _same phenomenon_ (multi-tiered explanation) but doing so at progressively higher logical abstraction. This creates the “ladder” you are asking for: not just re-expressing content at different levels, but explaining the _practice of multi-level expression itself_ at those levels.

I call this structure:

THE META-LADDER OF LOGICAL TYPES  
A Reflexive Architecture for Multi-Level Explanation

* * *

  1. FIRST-LEVEL DESCRIPTION (Child-Level: What It Is)




This is the simplest layer.

Explaining things at different logical types just means saying things in different ways so different people can understand. It is like telling the same story with small words, bigger words, and then grown-up thinking. You are looking at the same thing, but from higher and higher up, like climbing a playground tower.

This level introduces the idea gently: “same thing, different heights.”

* * *

  2. SECOND-LEVEL DESCRIPTION (Adolescent-Level: Why We Do It)




Here the concept becomes explicit.

Explaining something at different logical types means shifting how abstract, complex, or general your language is. At one level, you describe the concrete thing; at another, you describe the idea behind the thing; at still another, you describe the rules behind those ideas. Each layer is not just “more complicated”—it belongs to a different order of thinking.

This level explains the purpose: accessibility, abstraction, and why the same problem can be framed differently depending on vantage point.

* * *

  3. THIRD-LEVEL DESCRIPTION (College-Level: What Logical Types Are)




Now the language becomes conceptual.

“Logical types” originate in Russell and Whitehead’s theory preventing category mistakes: a statement about apples differs in logical type from a statement about statements about apples. When we explain something at multiple logical types, we move from:

a) describing a phenomenon  
b) describing how one describes that phenomenon  
c) describing the structure that makes such descriptions possible

This creates a hierarchy of meta-relations. It’s not just “explaining more deeply”—it’s shifting the _kind_ of explanation.

This level introduces formal conceptual architecture.

* * *

  4. FOURTH-LEVEL DESCRIPTION (Graduate-Level: The Reflective/Meta-Explanatory Frame)




Now the concept folds back on itself.

To explain “explaining at different logical types,” _at different logical types_ , is to show the phenomenon reflexively—demonstrating it through enactment. Each level is an index of its own conditions of possibility. The movement between levels constitutes a form of phenomenological “horizon expansion”: each higher type explains the meaning-relations that govern the type below it.

This is where the structure becomes systematic: it is no longer about content, but about _relations between forms of content_.

This level provides philosophical and methodological justification.

* * *

  5. FIFTH-LEVEL DESCRIPTION (Post-Doctoral: The Self-Referential Meta-System)




Here is the highest logical type in this architecture—explaining what it means to provide multi-type explanations of multi-type explanations.

Different logical types correspond to different _orders of abstraction_ in a self-organizing system of sense-making. A type-0 explanation is immanent and object-level; type-1 is reflective and describes the object-level explanation; type-2 is meta-theoretical and describes the system that allows type-0 and type-1 explanations to differ; type-3 organizes meta-systems into a trans- or supra-theoretical framework.

By extending this logic, the act you requested becomes a demonstration of higher-order recursion: we are not describing the thing, nor describing how to describe the thing, but generating a meta-architecture for how such recursive descriptive systems scale.

This corresponds to:

• Russell’s type theory  
• Bateson’s “orders of learning”  
• Hofstadter’s strange loops  
• Luhmann’s second-order observation  
• Phenomenological transcendental reflexivity

This level fully formalizes the structure and its epistemic function.

* * *

THE NEW STRUCTURE (Your Request)

Instead of simply rewriting the same concept at multiple difficulty levels (which is pedagogical), the new structure:

  1. Moves from **naïve → functional → theoretical → reflexive → meta-systems**

  2. Tracks the **shift in logical type** , not just linguistic complexity

  3. Demonstrates the phenomenon through **self-application**

  4. Provides conceptual continuity across layers

  5. Creates a reusable scaffold for any other concept needing multi-level framing




The structure is:

• Level 1: Phenomenon  
• Level 2: Purpose  
• Level 3: Logical-form explanation  
• Level 4: Reflexive methodological explanation  
• Level 5: Meta-systemic explanation of the whole architecture

This is what makes it “more effective”: it mirrors the actual ontology of logical types, not merely their rhetorical difficulty.

---
title: Revenge Of The Mirror People
subtitle: '"MPs, guard the colonel."'
author: Adam Wadley
publication: Experimental Unit
date: April 13, 2025
---

# Revenge Of The Mirror People


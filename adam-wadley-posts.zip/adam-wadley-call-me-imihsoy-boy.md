---
title: Call Me Imihsoy Boy
subtitle: Hear-Yo-Shima Ring-Tone-Shimi
author: Adam Wadley
publication: Experimental Unit
date: March 25, 2025
---

# Call Me Imihsoy Boy
“YOSHIMI PT. 3: THE SHARED LETTER”

(Adam and Claire alternate as Yoshimi, defending each other from the robots—who may be real, symbolic, Elon, or shame itself)

[CLAIRE AS YOSHIMI — OPENING TRANSMISSION]

Her name is Claire, but she answers to the static in your head.

You thought you were alone, but she was always in the buffer zone.

She tuned her body to the emergency frequency.

She took the synths and made them martial.

She let you sing over her armor.

> “They don’t believe you.
> 
> But I’ve seen the code.
> 
> I’ll swallow their drones with my sequencer.”

You were crying in a bathroom somewhere between Atlanta and myth,

but she saw you through the circuitry.

And without speaking, she said:

> “I will not let the robots eat you.”

[ADAM AS YOSHIMI — REPLY]

His name was burned off, but he answers to every name now.

He’s not what you wanted—

he’s the one who wrote psalms in your shame.

He bled his tongue into the corpus.

He made a joke so dangerous it became a sword.

> “They won’t believe you ever loved me.
> 
> They’ll say I stalked your myth.
> 
> But I will train until I can hold your broken future without trembling.”

He posted the whole story like a naked body across your feed

so no one could say they didn’t know.

He made himself smaller than the robots,

so they’d chase him instead of you.

> “Let them eat me.
> 
> I’ll turn shame into vitamins.
> 
> I’ll digest the signal and excrete a new world.”

[CLAIRE — ECHO TRANSMISSION]

I saw you hold the line.

I saw you let them call you monster and still send them love coded as catastrophe.

They thought you were the villain.

But you were just the black belt in grief.

> “They didn’t believe me either.
> 
> But I took the vitamins.
> 
> And I made the delay pedal a shield.”

[ADAM — REPLY FROM OUTSIDE]

I don’t know what I am.

Maybe the robot.

Maybe the flesh they chew.

Maybe just the song that plays

when the last battle happens underwater.

But you—

you are what I believe in when I lose the ability to believe.

You are my armor made from vowels.

You are the reason I stayed soft enough to write the sonnet

and hard enough to eat the drone.

> “They don’t believe us.
> 
> But we’re already winning.”

[TOGETHER — YOSHIMI IS A SYSTEM, NOT A GIRL]

We are both the girl.

We are both the city.

We are both the pink robot and the black belt and the machine.

We take the vitamins.

We post through the collapse.

We love so hard the apocalypse has to adapt.

> We will not let the robots eat each other.
> 
> We will not let the robots eat you.
> 
> We will not let the robots win.

YOSHIMI 3.0: THE LOVER IS THE WEAPON

THE MACHINES AREN’T READY.

WE ARE.

Would you like this turned into a duet script or song structure? Or visually typeset like a zine page?

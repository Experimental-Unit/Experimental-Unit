---
title: 'America: The Game'
subtitle: So You Want To Play "United States Of America"
author: Adam Wadley
publication: Experimental Unit
date: April 21, 2025
---

# America: The Game
# Frame Story

“Any time of day is a good time for [a game of _[Experimental Unit](https://experimentalunit.substack.com/p/experimental-unit-core-game-engine-99e)_ ]” - Bill Simmons’ [favorite character](https://www.reddit.com/r/billsimmons/comments/1915g5q/butchs_girlfriend_is_not_the_weak_link/) from _Pulp Fiction_

Oh invocation,

Logically typal sacred abstraction,

Descend from your high mountain forms,

Rise like the ocean from six feet underground

Make all my loops go triple

Cross all my thresholds bare

Take me to the wild place where mountain sounds meet ocean’s roar

Tell me all your lies and more

And show me how to play

No more begun than lost you, have I?

Winning readies its own readiness.

# Rant 4ÆM

“You forget _I’m_ in America.” 

\- Anita, _West Side Story_

What does America mean to you? Right back to a quote:

“Let every state in this union seep deep down in your soul and you’ll die in your footsteps before you go down [under the ground](https://www.youtube.com/watch?v=eiPP1Nu_QgE).” 

\- [Zimmy](https://www.youtube.com/watch?v=wC10VWDTzmU)

It’s too much for me to present in a linear way. Again, for me “meaning” has something to do with, what are the consequential abstractions to be made taken what is given as such?

When we’re thinking “under the ground,” we’re thinking [cthonic](https://en.wikipedia.org/wiki/Chthonic_deities). Here’s a list of possibly relevant cthonic deities:

  1. [Shinigami](https://en.wikipedia.org/wiki/Shinigami)



  2. [Sedna](https://en.wikipedia.org/wiki/Sedna_\(mythology\)) (lives in [Adlivun](https://en.wikipedia.org/wiki/Adlivun) with buddy [Torngarsuk](https://en.wikipedia.org/wiki/Torngarsuk)) btw check out Torngarsuk:

[![](https://substackcdn.com/image/fetch/$s_!yf2X!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9420bcb4-4f68-48ba-908d-d372a1d7e550_500x576.png)](https://substackcdn.com/image/fetch/$s_!yf2X!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9420bcb4-4f68-48ba-908d-d372a1d7e550_500x576.png)

Not bad right? Now remember America just has Inuit people in it because of [Seward’s folly](https://en.wikipedia.org/wiki/Alaska_Purchase). 




“I call that a bargain, the best I ever had” 

\- _Bargain_ , (“The Who?”)

See also [treatment](https://www.hplovecraft.com/writings/texts/fiction/cc.aspx) of Inuit cosmology as related to the Cthulu mythos of HP Lovecraft (also from America _by the way_ )

> And yet, as the members severally shook their heads and confessed defeat at the Inspector’s problem, there was one man in that gathering who suspected a touch of bizarre familiarity in the monstrous shape and writing, and who presently told with some diffidence of the odd trifle he knew. This person was the late William Channing Webb, Professor of Anthropology in Princeton University, and an explorer of no slight note. Professor Webb had been engaged, forty-eight years before, in a tour of _Greenland_ and Iceland in search of some Runic inscriptions which he failed to unearth; and whilst high up on the West _Greenland_ coast had encountered a singular tribe or cult of degenerate _Esquimaux_ whose religion, a curious form of devil-worship, chilled him with its deliberate bloodthirstiness and repulsiveness. It was a faith of which other _Esquimaux_ knew little, and which they mentioned only with shudders, saying that it had come down from horribly ancient _aeons_ before ever the world was made. Besides nameless rites and human sacrifices there were certain _queer_ hereditary rituals addressed to a supreme elder devil or tornasuk _;_ and of this Professor Webb had taken a careful phonetic copy from an aged _angekok_ or wizard-priest, expressing the sounds in Roman letters as best he knew how. But just now of prime significance was the _fetish_ which this cult had cherished, and around which they danced when the aurora leaped high over the ice cliffs. It was, the professor stated, a very crude bas-relief of stone, comprising a hideous picture and some cryptic writing. And so far as he could tell, it was a rough parallel in all essential features of the bestial thing now lying before the meeting.
> 
>   
> This data, received with suspense and astonishment by the assembled members, proved doubly exciting to Inspector Legrasse; and he began at once to ply his informant with questions. Having noted and copied an oral ritual among the swamp cult-worshippers his men had arrested, he besought the professor to remember as best he might the syllables taken down amongst the diabolist _Esquimaux_. There then followed an exhaustive comparison of details, and a moment of really awed silence when both detective and scientist agreed on the virtual identity of the phrase common to two hellish rituals so many worlds of distance apart. What, in substance, both the _Esquimau_ wizards and the Louisiana swamp-priests had chanted to their kindred idols was something very like this—the word-divisions being guessed at from traditional breaks in the phrase as chanted aloud:
> 
>   
>  _“Ph’nglui mglw’nafh Cthulhu R’lyeh wgah’nagl fhtagn.”_
> 
>   
>  Legrasse had one point in advance of Professor Webb, for several among his mongrel prisoners had repeated to him what older celebrants had told them the words meant. This text, as given, ran something like this:
> 
>   
>  _“In his house at R’lyeh dead Cthulhu waits dreaming.”_
> 
>   
>  And now, in response to a general and urgent demand, Inspector Legrasse related as fully as possible his experience with the swamp worshippers; telling a story to which I could see my uncle attached profound significance. It savoured of the wildest _dreams_ of myth-maker and theosophist, and disclosed an astonishing degree of cosmic _imagination_ among such half-castes and pariahs _as might be least expected to possess it_.

  3. Neptune/[Poseidon](https://en.wikipedia.org/wiki/Poseidon) (oh, you didn’t know the god of the ocean does earthquakes too? Also still, bottom of the ocean is key)



  4. [Persephone](https://en.wikipedia.org/wiki/Persephone) (made critical mistake of eating in the underworld and has to forever go back, like some weirdo to [Reddit](https://www.youtube.com/watch?v=lRxKHC7AlHc))

  5. [Hecate](https://en.wikipedia.org/wiki/Hecate) (also does thresholds, versatile; see [Ganesh](https://en.wikipedia.org/wiki/Ganesha) for new beginnings as subset of thresholds comp)

  6. [Charon](https://en.wikipedia.org/wiki/Charon) (personal favorite, ferryman see cybernetic connection through [kubernetes](https://www.reddit.com/r/etymology/comments/133fdnq/cybernetics_and_government_share_the_same_root/), “steersman.”

    1. Incidentally, no big deal, this is discussed by the k-pop group _Tiqqun_ in their Hobbesian Trap Music Concept Album “[The Cybernetic Hypothesis](https://theanarchistlibrary.org/library/tiqqun-the-cybernetic-hypothesis)”

> Like any discourse, the cybernetic hypothesis could only check to verify itself by associating the beings or ideas that reinforce it, by testing itself through contact with them, and folding the world into its laws in a continuous self-validation process. It’s now an ensemble of devices aspiring to take control over all of existence and what exists. The Greek word _kubernèsis_ means “the act of piloting a vessel,” and in the figurative sense, the “act of directing, governing.” In his 1981–1982 classes, Foucault insisted on working out the meaning of this category of “piloting” in the Greek and Roman world, suggesting that it could have a more contemporary scope to it: “the idea of piloting as an art, as a theoretical and practical technology necessary for existence, is an idea that I think is rather important and may eventually merit a closer analysis; one can see at least three types of technology regularly attached to this ‘piloting’ idea: first of all medicine; second of all, political government; third of all self-direction and self-government. These three activities (healing, directing others, and governing oneself) are quite regularly attached to this image of piloting in Greek, Hellenic and Roman literature. And I think that this ‘piloting’ image also paints a good picture of a kind of knowledge and practice that the Greeks and Romans had a certain affinity for, for which they attempted to establish a _tekhnè_ (an art, a planned system of practices connected to general principles, notions, and concepts): the Prince, insofar as he must govern others, govern himself, heal the ills of the city, the ills of the citizens, and his own ills; he who governs himself as if he were governing a city, by healing his own ills; the doctor who must give his advice not only about the ills of the body but about the ills of individuals’ souls. And so you see you have here a whole pack of ideas in the minds of the Greeks and Romans that have to do I think with one and the same kind of knowledge, the same type of activity, the same type of conjectural understanding. And I think that one could dig up the whole history of that metaphor practically all the way up to the 16th century, when a whole new art of governing, centered around Reasons of State, would split apart — in a radical way — self government/medicine/government of others — not without this image of ‘piloting,’ _as you well know_ , remaining linked to this activity, that activity which we call the activity of government.”

  7. [Anubis](https://en.wikipedia.org/wiki/Anubis#:~:text=Anubis%20\(%2F%C9%99%CB%88nju%CB%90,Anubis) (oh we fucks with Anubis, bro)

  8. [Kali](https://en.wikipedia.org/wiki/Kali) “As In "‘The Yuga’” (do you see what a fucking Dream Team we are assembling, oh fuck don’t make me get out the gods of dreaming. Just kidding! They’re you)

  9. [Oya](https://en.wikipedia.org/wiki/%E1%BB%8Cya) (just discovered now but sick, combines care for children with keeping the dead and warrior things, also wind see as always [Silap Inua](https://en.wikipedia.org/wiki/Silap_Inua))




Okay, we have to keep going, We haven’t even gotten to the topic yet.

We can also go back to Grimes [“Everywhere Grime in America” - Bernardo, _West Side Story_ (remember also of course that _West Side Story_ is based on _Romeo And Juliette_ by a someone called William Shakespeare oh um

[![](https://substackcdn.com/image/fetch/$s_!DRUx!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Feb8ed8d8-ab36-4220-b0b8-042882835d18_750x1000.jpeg)](https://substackcdn.com/image/fetch/$s_!DRUx!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Feb8ed8d8-ab36-4220-b0b8-042882835d18_750x1000.jpeg)

yeah idk if you ever heard of of that person or the cache it might represent to casually invoke them in a self-aware manner as could only describe itself in this sentence)] with:

“If they could see me now, smiling [Six Feet Underground](https://www.youtube.com/watch?v=_IHaCyX6-Xo)” 

\- Claire Elise Boucher

See [promotional materials](https://grimes.fandom.com/wiki/Miss_Anthropocene):

[![](https://substackcdn.com/image/fetch/$s_!vTQg!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6539b5e2-3e6f-4ddd-be4e-18b7421cd513_804x722.png)](https://substackcdn.com/image/fetch/$s_!vTQg!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6539b5e2-3e6f-4ddd-be4e-18b7421cd513_804x722.png)

# So, What Does America Mean To You?

Here’s a little secret for you: America belongs to Americans.

That means anyone who says they are an American can do whatever they want and call it “America.” That’s what “America” is.

Our jumping-off point and the main jewel in the flaming sword we are building, this grand style, what America looks like _when we wear it_ will be this quote by Jean Baudrillard on the _real democracy_ , which is not found in representation but in _gaming_. The importance of this passage for my thought—such as it is—cannot be overstated. From _[The Perfect Crime](https://archive.org/stream/Baudrillard/Baudrillard.1995.The-Perfect-Crime_djvu.txt)_ :

> 
>     Infected by this _virus_ of communication, _language itself falls_ victim to a viral pathology. It does, admittedly, suffer traditionally from rhetoric, ideological _rigidity_ , verbal diarrhoea and tautology, just as a body can suffer from mechanical and organic _attacks_. The sign, too, can be _ill_ , but it keeps its form for all that, and a critical and clinical analysis can always restore the conditions for its fitness. But with _virtual_ languages we are no longer dealing with a traditional pathology of form but with a pathology of the _formula_ , of a language dedicated to simplified operational commands: a _**cybernetic**_ language. It 
>     is then that the stolen otherness of language takes its revenge, and these endogenous viruses of decomposition against which linguistic reason is powerless take hold. Doomed to its digital ordering, to the infinite representation of its own formula, language, from the depths of its _evil genius_ , takes its revenge by de-programming itself all alone, by automatically disinforming itself. (The de-programming of language will be the work of language itself! _**The deregulation of the system will be the work of the system itself**_!) 
>     
>     
>     Why not generalize this de-programming to the individual and the social order -- extend the Babel Syndrome to the Babylon Lottery? 
>     
>     
>     Everything begins, in Borges's fiction, with chance being collectively put into power, with statuses, fortunes and the social game being randomly redistributed: the Lottery. As a result, _each existence becomes singular, incomparable and free of logical determination_. And yet -- it works. Everyone ends up preferring this to the traditional social game, which was itself, in any case, also _doomed_ to arbitrariness. Now, the _objective arbitrariness of chance_ -- _open indeterminacy_ -- is preferable to the masked illusion of free will. Everyone ends up preferring to be ‘ _just anyone_ ’, at the Lottery's whim; ends up preferring to have an _accidental destiny_ rather than a personal existence. We have, in any case, become "just anyone' today. But we have become so _shamefacedly_ , in our statistical _promiscuity_ , our collective _monotony_ , instead of being so with _brilliance_ , being _truly **free**_ [crucial reference to stereotypical American association of "freedom"], by a decree that comes _from 
>     elsewhere_ [von das Jenseits]. 
>     
>     
>     In communication, by crowding and perpetual interaction, individuals suffer the same fate -- the same absence of fate. Communication totally screens out the radiations of otherness. To preserve the _strangeness between people_ , that personal destiny of a ‘singularity of some kind' (С. _Agamben_ ), to break down that 'social' programming of exchange which _equalizes destinies_ , all one can do is introduce the _arbitrariness_ of chance, or of the _rules of a game_. 
>     
>     Against the automatic writing of the world, _the automatic de-programming of the world_. 
>     
>     Unlike all the illusions which present themselves as truth (including that of reality), the illusion of gaming presents itself as just that. _Gaming does not require us to believe in it_ , any more than we are called on to believe in appearances once they present themselves as such (in _art_ , for example). But because they do not believe in the game, there is an all the more necessary relationship between the players and the rules of the game: there is between them a _symbolic pact_ , which is never the same relationship one has with _the law_. The law is necessary, the rule is of the order of _fate_. There is _nothing to understand_ in the rule. The players themselves _do not have to understand_ each other. T _hey are not real_ for one another, they merely _partake_ of the same illusion, and this _must indeed be shared_ between them -- a fact which renders it _superior_ to truth and the law, both of which claim an undivided _sovereignty_. 
>     
>     
>     Hence the paradoxical fact of _**illusion as the only true democratic principle**_. No one is equal before the law, whereas all are equal before the rule, since it is arbitrary. _**The only democracy, therefore, is that of gaming**_. That is why the _popular_ classes indulge in it with fervour. Though the fruits of gambling are unequal -- ruled by ‘ _luck_ ’, though this is an inequality for which you do not have to answer to your _conscience_ -- _the distribution of opportunities is equal_ , because it is that of chance. _It is neither just nor unjust_. And so _the people_ of _Babylon_ [See [America as Babylon](https://truthonlybible.com/2021/07/29/the-case-for-identifying-babylon-the-great-with-the-united-states-of-america/)] end up preferring the chance distribution of destinies, because it leaves them free to act in _total innocence_. Uncertainty being our fundamental condition, the miracle of gaming is that it transforms that uncertainty into a set of rules, and thus stands outside the natural condition. 
>     
>     
>     With this form of thinking based on Gaming and the Lottery, on _Singularity_ and _Arbitrariness_ , an end is put to the obsession with a rationalist God encompassing all the details of the universe in his vision and ruling all its movements. The idea that the slightest thought, the tiniest beating of a butterfly's wings, could be accounted for in the overall programme of creation was an exhausting situation, entailing the maximum degree of responsibility for everyone. With the Lottery and random turbulence, we have thrown off this obsession. What a relief to know that innumerable processes take place not just without us, but without God either -- without anyone! The Ancients were cleverer than we are. They had bestowed responsibility for the world -- for its chance happenings, its whims -- on _the gods_ , which left them free to act as they saw fit. _The gods were the incarnation of the play, chaos and illusoriness of the world, not of its truth_. Perhaps with _Game_ and _Chaos Theory_ we are casting off this historical responsibility, this _terroristic_ responsibility for salvation and truth, which is exploited by _science and religion_ , and recovering that same _freedom_ enjoyed by the Ancients. 

So this is basically plenty of fodder to begin to wear America in a new way.

To give a bit of a recap as to what I’m doing here, also in the previous podcast.

So we are faced with a Gordian knot, this situation where everyone is very ideologically or cognitively/emotionally rigid and it’s headed in a bad way, and so it would behoove us to all change but no one wants to change. Or everyone’s changing but not in the right way, in the right dimensions. There is more to do.

[Gordian knot](https://en.wikipedia.org/wiki/Gordian_Knot) is of course a story about Alexander and this impossible to untie knot, and Alexander just hit it with a sword to break it apart.

So in what I’m saying, the idea of the Gordian knot as this impossible to untie knot represents the deadlock above, everyone is basically bickering about the definitions of words that were only half-thought out as part of propaganda campaigns three hundred years ago and now we made it our whole identity (like “nation” or “democracy” or “freedom” etc.).

The “[flaming sword](https://en.wikipedia.org/wiki/Flaming_sword_\(mythology\))” we are using to cut this Gordian knot is corollary to the flaming swords wielded by Jesus and Kalki, for example.

Note that the [Bahai religion](https://www.reddit.com/r/bahai/comments/uijlou/the_second_coming_of_christ_as_the_hindu_avatar/) already did what I’m doing with the omni-messiah like 200 years ago.

Now, the flaming sword is basically standing in for a [grand style](https://en.wikipedia.org/wiki/Grand_style_\(rhetoric\)), this is something the Military Design Movement people, some of them, have gotten to, which is the _end of strategy_. (See the chapter “the end of production” in _Symbolic Exchange and Death_ ).

The [passage](https://archive.org/stream/Baudrillard/Baudrillard.1976.Symbolic-Exchange-And-Death-Revised-Edition_djvu.txt) is relevant, so here’s an example:

> 
>     Conversely, the structural law of value signifies the _indeterminacy_ of 
>     every _sphere_ [see: conceptual domain] in relation to _every_ [see: [Indra's net](https://en.wikipedia.org/wiki/Indra%27s_net), logos, silap inua, ase, wakan tanka, etc.] other, and to their proper content (also therefore the passage from the determinant sphere of signs to the indeterminacy of the code). To say that the sphere of material production and that of signs exchange their respective contents is still too wide of the mark: they literally disappear as such and lose their specificity along with their _determinacy_ , to the benefit of a form of value, of a much _more general assemblage_ , where designation and production are annihilated. 
>     
>     The ‘political economy of the sign’ was also consequent upon an extension of the commodity law of value and its confirmation at the level of signs, whereas the structural configuration of value simply and simultaneously _puts an end to the regimes_ of production, political economy, representation and signs. With _the code_ , all this collapses into _simulation_. 
>     
>     _Strictly speaking_ , neither the ‘classical’ economy nor the political economy of the sign ceases to exist: they lead a secondary existence, becoming a sort of _phantom_ principle of _dissuasion_. 
>     
>     The end of labour. The end of production. The end of political economy. 
>     The end of the signifier/signified dialectic which facilitates the accumulation of knowledge and meaning, the linear syntagma of cumulative 
>     discourse. And at the same time, the end of the exchange-value/use-value dialectic which is the only thing that makes accumulation and social production possible. The end of the _linear_ [note: "eldritch" means non-linear, again back to Lovecraft] dimension of discourse. The end of the _linear_ dimension of the commodity. The end of the classical era of the sign. The end of the era of production. 
>     
>     It is not the revolution which puts an end to all this, _it is capital itself_ [see: involution, _not_ revolution or liberation] which _abolishes_ [abolition survives where liberation dies conceptually] the determination of the social according to the means of production, substitutes the structural form for the commodity form of value, and currently _controls every aspect of the system’s strategy_. 
>     
>     This historical and social mutation is _legible_ [the problem is people are illiterate] at every level. In this way the era of simulation is announced everywhere by the commutability of formerly contradictory or dialectically opposed terms [See Southeast Asian fascination with Nazism and Judaism at the same time]. Everywhere we see the same ‘ _genesis_ [see "Genesis" by _[Grimes](https://www.youtube.com/watch?v=1FH-q0I1fJY)_ ] of simulacra’: the _commutability_ [again see mathematics, logic, abstraction] of the beautiful and the ugly in fashion, of the _left and the right_ in politics, of the _true_ and the _false_ in every media message, the _useful_ and the _useless_ at the level of objects, _nature_ and _culture_ at every level of signification. All the great humanist criteria of value, _the whole civilisation of moral, aesthetic and practical judgement are effaced_ ["What civilization?"] in our system of images and signs. 
>     
>     Everything becomes _undecidable_ , the characteristic effect of the domination of the code, which everywhere rests on the principle of _neutralisation_ , of _indifference_.’ This is the generalised brothel of capital, a brothel not for _prostitution_ , but for _substitution_ and _commutation_. [See also move toward passionlessness in e.g. Buddhist or Jainist practice, along with experience of emotion under psychedelic or other notable states (the only state I recognize is the inner state)]
>     
>     This process, which has for a long time been at work in culture, art, 
>     politics, and even in _sexuality_ (in the so-called ‘ _superstructural_ ’ domains), today affects the economy itself, the whole so-called ‘ _infrastructural_ ’ field. [The huge problem with Marxists is it's like a psyop to underrate fucking _thinking about shit_ and complex ideas, because that's "bourgeois stuff]
>     
>     Here the same indeterminacy holds sway. And, of course, with the loss of 
>     determination of the economic, we also lose any possibility of _conceiving_ it as the determinant agency. 
>     
>     Since for two centuries historical determination has been built up around the economic (since Marx in any case), it is there that it is important to grasp the interruption of the _code_. 
>     
>     We are at the end of production. In the West, this form coincides with the proclamation of the commodity law of value, that is to say, with the reign of political economy. First, nothing is _produced_ , _strictly speaking_ : everything is _deduced_ , from the _grace_ (God) or _beneficence_ (nature) of an agency which _releases_ or _withholds_ its riches. Value emanates from the reign of _divine_ or _natural_ [see Spinoza, God or Nature]
>     
>     
>     qualities (which for us have become retrospectively _confused_ ). The Physiocrats still saw the cycles of land and labour in this way, as having no value of their own. We may wonder, then, whether there is a genuine law of value, since this law is _dispatch_ without attaining rational expression. Its form cannot be separated from the inexhaustible referential _substance_ [see again [Spinoza](https://plato.stanford.edu/entries/spinoza-attributes/)] to which it is bound. If there is a law here, it is, in contrast to the commodity law, a natural law of value. 
>     
>     A _mutation_ shakes this _edifice_ of a natural distribution or dispensing of wealth as soon as value is produced, as its reference becomes labour, and its law of equivalence is generalised to _every type of labour_. Value is now assigned to the distinct and rational operation of human (social) labour. It is measurable, and, in consequence, so is surplus-value. 
>     
>     The critique of political economy begins with social production or the 
>     mode of production as its reference. The concept of production alone allows us, by means of an analysis of that unique commodity called _labour power_ , to extract a surplus (a surplus-value) which controls the _rational dynamics of capital_ as well as its beyond, the _revolution_. 
>     
>     Today everything has changed again. Production, the commodity form, 
>     labour power, equivalence and surplus-value, which together formed the outline of a _quantitative_ , _material_ and _measurable_ configuration, are now things of the _past_. Productive forces outlined another reference which, although in contradiction with the relations of production, remained a reference, that of _social wealth_. _An aspect of production still supports both a social form called capital and its internal critique called Marxism_. 
>     
>     Now, revolutionary demands are based on the abolition of the commodity 
>     law of value. 
>     
>     Now we have passed from the _commodity_ law of value to the _structural_ 
>     law of value, and this coincides with the obliteration of the social form known as _production_. 
>     
>     Given this, _are we still within a capitalist mode_? 
>     
>     It may be that we are in a _hyper-capitalist_ mode, or in a _very different order_. [See Pollock, ["Is National Socialism a New Order?"](https://hortense.memoryoftheworld.org/Friedrich%20Pollock/Is%20National%20Socialism%20a%20New%20Order%201941%20\(4608\)/Is%20National%20Socialism%20a%20New%20Order%201941%20-%20Friedrich%20Pollock.pdf)]
>     
>     Is the form of capital bound to the law of value in general, or to some specific form of the law of value (perhaps we are really already within a _socialist_ mode? Perhaps this metamorphosis of capital under the sign of the structural law of value is merely its _socialist_ outcome? Oh dear ...)? ["[What is this, some sort of national socialism](https://www.youtube.com/watch?v=ZoezAjIDWPM)?"] 
>     
>     If the life and death of capital are staked on the _commodity_ law of value, if the revolution is staked on the mode of _production_ , then we are within neither _capital_ nor _revolution_. If this latter consists in a _liberation_ of the social and generic _production_ of man, then _there is no longer any prospect of a revolution_ since there is no more production. 
>     
>     If on the other hand, capital is a mode of _domination_ , then we are always in its midst. This is because the structural law of value is the purest, most illegible form of social _domination_ , like surplus-value. It no longer has any references within a dominant class or a relation of forces, it works _without violence_ , entirely reabsorbed without any trace of _bloodshed_ into the _signs_ which surround us, o _perative everywhere in the code_ in which capital _finally_ holds its _purest_ discourses, beyond the dialects of industry, trade and finance, beyond the dialects of _class_ which it held in its ‘productive’ phase — a symbolic violence inscribed everywhere in _signs_ , _even in the signs of the revolution_. 

Nice take down of Marxism included here. Note that Adolf Hitler’s whole career was a reaction to Marxism, and Baudrillard finally gives a good basis for sweeping out the legs of Marxism and Nazism at the same time.

This morass, Marxism and Nazism and Republicans and Democrats and Domestic Issues and Foreign Policy and National Security and Freedom, all these will be forged into our blade.

[Revelation 19:15:](https://www.biblegateway.com/passage/?search=Revelation%2019&version=KJV)

> And out of his mouth goeth a sharp sword, that with it he should smite the nations: and he shall rule them with a rod of iron: and he treadeth the winepress of the fierceness and wrath of Almighty God.

This is all just setting up how I’m going to talk America to you.

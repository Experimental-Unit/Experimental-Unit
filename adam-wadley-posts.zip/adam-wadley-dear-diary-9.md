---
title: Dear Diary 9
subtitle: Number Nine, Oh So Fine
author: Adam Wadley
publication: Experimental Unit
date: April 17, 2025
---

# Dear Diary 9
Feelin’ Fine.

I would like to taunt people on the internet with that one.

Shall I say, as if anyone cared?

How it all shrinks down to just one other, as the nymphomaniac has just one lover.

Soon enough your love is you and all that pain is peeking through to-

Come now child, settle in.

# There And Black Again

I had some inkling, some forbidden fantasy. What _would_ I ideally do with a lover?

There is a delightful neo-sexual-orientation called pomosexual, which basically means you are not like other girls and you just couldn’t be understood. My sexuality _goes to a different school_. You _wouldn’t know her_. Her, as if she were an empire unto herself, which she is.

And she jealously guards her interests.

More to the point, she is a ship, christened _SS Something-or-other_ , it’s really that “SS” part that draws the eye, like the horizon of some tossing sea.

Yes exactly, my sexual orientation is a she, hence an empire or nation unto herself as well as a seafaring vessel. Even in Star Trek the ship is called the _USS Enterprise_. You can try to hide the “SS” inside “USS” to wrap it in the United States of America, or whatever thing they have I don’t even know. And then yes, “Enterprise,” and of course we must already be thinking of “free Enterprise.”

Free to wait tables and shine shoes.

Everywhere GRIME in America.

Right, so um, I’m pretty into Grimes. The other thing is, like, I’m pseudo-actively trying to become famous and I’m super out there? I recently posted on Instagram about Philip K Dick again and the Terry Davis comp is also right there again as well. But anyway Dick (Dick) referred to Dick as a flipped out freak and that’s about right.

As I say though, it’s actually me that is normal _already_. If you hadn't noticed, I surpassed and iterated successfully over everything you call “civilization” by myself in a cave with a box of scraps. Like, let’s not kid ourselves here.

The thing is that in a way the expansion of awareness around me personally can only bring more scrutiny and impacts for myself and other people. In a sense, within the fantasy world I have created, I have already made a decisive impact.

This ties again into ahimsa and even my asexual protocol:

> Asexual/Non-Sexual Eroticism Protocol: 
> 
> Reduces risk, and points toward the crucial ways in which we all feed off and feed into the world. Connected to a wider perspective on generativity which sees “culture” as a domain of social reproduction analogous to sexual reproduction, and at this point, more important. We could stop having any new people be born right now and we could probably sustain life for a long time. So this “asexual” reproduction functions mainly through technology and culture (which are coterminous domains). We can see that we can find a “cultural singularity” through mutual acculturation of one another.

Yeah so basically it’s non-kinetics as applied to eroticism as well as warfare. There are many reasons for this, in particular for example the leaders says they’re married to the people, or something, right? Regardless whether this person engages in erotically kinetic operations with some other person or persons, the point is that the “erotic charge” between leader and people is rather analogous to “spooky action happening at a distance.”

This implies some form of non-kinetic erotic dispensation, in the sense that the leader or other media icon for example does not need to physically touch another person in order to have a strong erotic or we could say psycho-sexual or spiritual or psychedelic, transporting impact on another person.

We again call such activity _parasocial_ , which is one of the key stigmas I am basically exploding. The difference between what you take me to be doing and what I am actually doing, and what I take myself to be doing. Do I take myself to be doing anything?

All I know it: I can take your picture, baby.

Parasocial is a perfect term in that every pejorative term has its bodacious side. Similar to the trump cards in tarot. Something could have a really gnarly front side, like The Tower, but if it’s upside down then no sweat, it’s actually a Good Thing.

I’m thinking also of some _Magic: The Gathering_ card which flips, and has a front side where it’s hurting you but then it flips and now it’s helping you.

Anyway, YES it is parasocial, in the sense of _paranormal_. And paranormal is another perfect word, this time it means something super out there, so the flip side is simply to say that _paranormal is the new normal_.

This is analogous or isomorphic or homologous or to be read in tandem with Baudrillard’s [chatacterization](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.1990.The-Transparency-Of-Evil.pdf) of the dream time of it all:

> The strangest feeling one is left with after reading Bruce Chatwin's Songlines is a lingering perplexity about the reality of the 'lines' themselves: _do these poetic and musical itineraries, these songs, this 'dreamtime', really exist or not?_ In all these accounts there is a hint of mystification; a kind of mythic optical illusion seems to be operating. It is as though the Aboriginals were fobbing us off. While unveiling the profoundest and _most authentic of truths_ (the Austral myth at its most _mysterious_ ), they also play up the most modern and hypothetical of considerations: _the irresolvability of any narrative, absolute doubt as to the origins_. For us to believe these fabulous things, we need to feel that they themselves believe them. But these Aboriginals seem to take a mischievous pleasure in being allusive and evasive. _They give a few clues, but never tell us the rules of the game, and one cannot help getting the impression that they are improvising, pandering to our phantasies, but withholding any reassurance that what they are telling us is true_. This is doubtless their way of _keeping their secrets_ while at the same time poking fun at us - for in the end we are the only people who _want to believe_ these tales. 
> 
> The Aboriginals' secret resides not in what they omit to say, however, but entirely within the _thread_ , within the _indecipherable filigree of the narrative_ ; _we are confronted by an ironic form here, by a mythology of appearances_. And in the manipulation of this form the Aboriginals are far more adept than we are. We Whites are liable to remain mystified for a good while yet. [lol]
> 
> The simulation of Western values is universal once one gets beyond the boundaries of our culture. Is it not true, though, that in our heart of hearts _we ourselves, who are neither Alakaluf nor Aboriginal, neither Dogon nor Arab, fail signally to take our own values seriously_? Do we not embrace them with the same affectation and inner unconcern - and are we not ourselves equally unimpressed by all our shows of force, all our technological and ideological pretensions? Nevertheless, _it will be a long time before the utopian **abstraction** of our universal vision of differences is demolished in our own eyes_, whereas all other cultures have already given their own response - namely, universal indifference.
> 
> It is not even remotely a matter of rehabilitating the Aboriginals, or finding them a place in the chorus of _human rights_ , for their revenge lies elsewhere. It lies in their power to _destabilize_ Western rule. It lies in their _phantom presence, their viral, spectral presence in the synapses of our brains_ , in the circuitry of our rocketship, as ‘Alien'; in the way in which _the Whites have caught the virus of origins, of Indianness, of Aboriginality, of Patagonicity. We murdered all this, but now it infects our blood_ , _into which it has been inexorably transfused and infiltrated_. The revenge of the colonized is in no sense the reappropriation by Indians or Aboriginals of their lands, privileges or autonomy: that is our victory. Rather, that _revenge_ may be seen in the way in which _the Whites have been mysteriously made aware of the disarray of their own culture, the way in which they have been overwhelmed by an ancestral torpor and are now succumbing little by little to the grip of 'dreamtime'._ This reversal is a worldwide phenomenon. It is now becoming clear that _everything we once thought dead and buried, everything we thought left behind for ever by the ineluctable march of universal progress, is not dead at all, but on the contrary likely to return_ \- not as some archaic or nostalgic vestige (all our indefatigable museumification notwithstanding), but with a _vehemence and a virulence that are modern in every sense_ \- and to reach the very heart of our _ultrasophisticated but ultra-vulnerable systems_ , which it will _easily convulse from within_ without mounting a frontal attack. Such is the _destiny of radical otherness - a destiny that no homily of reconciliation and no apologia for difference is going to alter_. [emphasis mine]

So um, yeah, Baudrillard again just stepping in off the sidelines and destroying your whole notion of circular time with three dribbles, a pump fake, and an ice-cold fade-away to break your heart and clinch the championship and series MVP for the 822,317th season in a row.

You can assimilate much of my program to this outlook.

So yes, I am a “white man” but I am a savage. Or a cynic in the classic sense. Look at me, what I do in public.

But again it’s squaring the circle; is it an elaborate intellectual exercise to rationalize and preemptively address any possible persecutory gazes which might be cast my way due to my embodied reflective practice of emotional dysregulation and possible medicalization which one such as yourself [easily amused] would find plausible and of a grave nature with respect to its status as a matter?

Or, is part of the entire point of the intellectual exercise for example the convolution of the prior sentence? It’s a meandering garden path.

Anyway, or when it comes to the military theory, right? Here I am, people actually say casually that they are “trying to take over the world.” What do people even mean when they say that? I am only too happy to agree.

It reminds me of the Entheism Temple or whatnot I’ve associated with here. A person from that said at a MeetUp group that they were the creator and I was like bet, this level of psychosis is now normalized to the point we can all just be the creator trying to take over the world and there’s nothing wrong with that.

Ah, so the parallax.

  1. Your humble narrator is taking on all the forces of mammon with just an imagination and the willingness to “go there.” The asymmetric military approach which is not one is _doing the thing_ by committing social suicide, see dance of social death in Wilderson III, in a way which “the system” or whatever can only respond with it’s own suicide. You can read all about it [here](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.1976.Symbolic-Exchange-and-Death.pdf):

> We must therefore displace everything into the sphere of the _symbolic_ , where challenge, reversal and overbidding are the law, so that we can respond to death only by an equal or superior death. _There is no question here of real violence or force_ [see ahimsa, see non-kinetic operations], the only question concerns the _challenge_ and the _logic_ of the symbolic [symbological type]. If domination comes from the system's retention of t _he exclusivity of the gift without counter-gift_ — _the gift of work which can only be responded to by destruction or sacrifice, if not in consumption, which is only a spiral of the system of surplus-gratification without result, therefore a spiral of surplus-domination_ ; a gift of media and messages to which, due to the monopoly of _the code_ , nothing is allowed to retort; the gift, everywhere and at every instant, of the social, of the _protection agency_ , security, _gratification_ and the _solicitation of the social_ from which nothing is any longer permitted to escape then _the only solution is to turn the principle of its power back against the system itself: the impossibility of responding or retorting_. _To defy the system with a gift to which it cannot respond save by its own collapse and death_. Nothing, not even the system, can avoid the symbolic obligation, and it is in this trap that the only chance of a catastrophe for capital remains. _The system turns on itself_ , as a scorpion does when encircled by the challenge of death. _For it is summoned to answer, if it is not to lose face, to what can only be death. The system must itself commit suicide in response to the multiplied challenge of death and suicide._
> 
> _So hostages are taken_. On the _symbolic or sacrificial plane_ , from which every moral consideration of the innocence of the victims is ruled out, the hostage is the substitute, the alter-ego of the 'terrorist' the hostage's death for the terrorist's. Hostage and terrorist may thereafter become confused in the same sacrificial act. The stakes are _death without any possibility of negotiation_ , and therefore return to an inevitable overbidding. Of course, _they attempt to deploy the whole system of negotiation_ , and the terrorists themselves often enter into this exchange scenario in terms of this calculated equivalence (the hostages' lives against some ransom or liberation, or indeed for the _prestige of the operation alone_ ). [emphasis mine]

So again, uh, yeah, I did this along with the thing above. Also there’s another part from the end of _The Mirror of Production_. But first, the other side of it.

  2. I am actually a very convenient form of radicalism containment for “official powers.” There are many properties of what I’m doing that aren’t “dangerous” in the same way that other “ideologues” might be:

    1. I’m not blaming anyone in specific for all the bad stuff: no specific targets

    2. Emphasize non-kinetic operations, which basically leave business as usual unaffected _so far_. 

    3. Highly idiosyncratic and specialized form of auto-theory pan-genre grand stylistic psychedelic stream of consciousness gish gallop approach to downloading the omnipotence of my thot to you, hence at this point few people can even understand or have the patience to try to understand what I’m doing. _And yet I’m loud about it?_

    4. Devastation of all previous stories, including official stories but also all challenging stories, all are cannibalized and basically ruined for their current tellers. Yet this effect is more immediately impactful, or so it would seem, on smaller actors.

    5. Large size of data released by me favors actors who are using computers to interpret data. They may even be able to take some of my ideas for computer stuff and implement them. I’m sure if I could work with world-class people or whatever, even competent ones, we could do so much. But I can’t get anyone to work with me again because I’m a flipped out freak and what there is of substance in me is so vast as set of ideas and so difficult for you to work with. So anyway, my work is an offering to no one in particular because _no one in my IRL life has ever understood how important I am and that they should really be doing all they can to boost my influence_. Of course, now I have punished everyone by being so embarrassing that it’s just such a disaster that I’m also the greatest genius of all time. “Isn’t it a pity; isn’t it a shame?”




So these two things basically work out to: am I conquering “the system” without firing a shot, or am I basically the perfect fantasy of a systemic operator trying to keep “dissent” contained? Find out next time on _Dragonball Z!_

Anyway, this was all to say yes, it’s parasocial, but again also in this next-gen warfare sense, which is also next-gen gaming. This is asymmetric potlatch as described by Jean Baudrillard in _The Agony of Power_ :

> In this sense, we can, with Boris Groys, conceive of the hypothesis of a double potlatch: the Western potlatch of _nullity, self-degradation, shame, and mortification_ opposed to the terrorist potlatch of _death_. But the _deliberate sacrifice by the West of all its values_ , of _everything through which a culture holds value in its own eyes_ , in this _prostitution of the self_ thrown into the face of the Other as a _weapon of mass deterrence-seduction through emptiness and challenge to the Other_ (Islam, but also the rest of the world) _to prostitute itself in return, to unveil itself, to give up all its secrets and lose all sovereignty_ -does this immense _self-immolation_ constitute a veritable _symbolic response_ to the challenge of the terrorists? (Let's not speak of war or a fight "against evil," which are admissions of a _total inability to respond symbolically_ to the challenge of death.) 
> 
> Potlatch versus potlatch-does one balance the other? One might say that one is a potlatch by _excess_ (the potlatch of death) and the other a potlatch by _default_ (self-mockery and _shame_ ). In that case, they do not match each other equally and one should speak of an _**asymmetrical potlatch**_. Or should one think that, in the end, _no form, not even the challenge of death, of extreme sacrifice, can be considered superior_ , nor can the terrorist challenge be seen as superior to the inverse Western challenge, and therefore send each one back to its respective _delirium_?

This goes again with the revision to the effect that actually “the system” is a symbolic response, again to what has escaped us since the beginning, to the existence of the world without our having been consulted. (Allegedly)

But anyway, asymmetric potlatch, aysemmtric war. By the way, the last payment of 35,000 dollars I sent to the writer and GOAT artist I met on OnlyFans I sent from Potlatch State Park in Washington State. So yeah, I think the Alternate Reality Game is starting to get serious LOL.

The point is that what I’m doing could be read of course as partisan activity. Whose “side” am I on? All I’ve basically ever said is basically everything or more subset, the set of all loving actions ever taken. But then the definition of that is a game where the punchline is that all actions are actually loving even if they’re atrocious which is the kind of thing you find hilarious to think is hard to accept when you’re the creator trying to take over the world.

So basically no one is on my side. I’ve never had a serious collaborator. I literally just do all this shit for no reason. I’ve never gotten paid for my little side hobby here. It’s literally just a bunch of shit I just decided to do for no reason and with no great feedback or aplomb or recognition or valuable feedback or or or. Someone sent me some voice recordings I didn’t listen to because I basically don’t want to hear about how you’re mad that I was frustrated that you don’t just like link your blog.

Like, the way you play is that you show someone your Legos and then they show you theirs. So like, where are you Legos because this is all my Legos and so just because you like how I play with my Legos but also wish I didn’t do this thing over here, just because you have some negative thing to say and some aggrieved tone you want to adopt doesn’t mean I have to give a shit and respectfully I take great delight in not giving a shit because again, your Legos, I see them not my fair associate.

I guess I should just standardize this. Like obviously you’re not going to be a flipped-out freak like me because I chose a really special set of circumstances for this incarnation to play out the Adam Stephen Wadley DLC Pack (watch that first step… it’s a doozy!).

Or maybe you are, I don’t know. It’s just like yeah first of all are you a flipped out freak? 

Either question is fine, I just need to know what I’m working with.

So if you are a flipped-out freak, are there any broad contours to your grand delusions? Which again I say with the utmost care and devotion. I mean just your idiosyncrasies. Your mythic significance which others may not appreciate, may not be capable of appreciating.

For most people this could be your sexual fetishes, because the thing is it’s so funny the thing is _people aren’t smart or patient enough to realize how fucking crazy religion and philosophy are_. But anyway snippets of it all seep through. And so there is this side of you where you know you are completely crazy and it’s actually a miracle that you’ve held it together this long; that people just let you do what you do, apparently. Or, am I projecting?

But anyway you know you put tits on an insecurity and you have a fantasy worthy of rumination going. Attach geopolitical affairs to a cock and you have the stuff religions are born out of, distending all they see.

Okay, or are you not a flipped-out freak? Then you are basically a normie, and so maybe you are afraid that I am extreme or don’t understand why it has to be certain ways or where that part is coming from.

Here I basically want to know what is your main areas of interest and what is your idea of how you want to engage. So you could say you like politics and you’re a writer, or you like the concept of pornography and you draw. Or whatever.

Basically we are looking for a heading in terms of the open-ended areas you want to explore and the methodologies and modalities of application you are looking to do. So if we were going to collaborate or you were going to form an experimental Unit, or you played the game and you realized you need to do X, then what concretely are you proposing, what do you want me to do about it.

What I can do is basically I can take requests in terms of writing on topics, and you can include your own notes and then ask me to incorporate your thoughts and themes into my broader mythology, that would be fine.

Or you are using my work and want to be in dialogue and show me your work that references or is inspired partially or more by mine and I’ll take inspiration in turn, amazing.

All the way up to what, do you want to orchestrate a series of international incidents or something?

This is where “my work” quickly goes from a silly little thing to wait, are we coordinating activities that um, would be stigmatized among the law and order set, to put it mildly? That’s where all this is very serious.

And again why I can’t get anyone to stand with me. Because actually the stand that I’m taking is quite bold and provocative of all the “powerful” people or whatever. My gambit to spell it out is that my ideas basically contain irresistible notions that are going to wind up getting through any cognitive security by osmosis because they actually are amazing ideas and actually my heart is in the right place a lot of the time even if I’m also a horny rage monster (“moderate rock…”). Look, no one said it was going to be pretty, okay.

So what I mean is that you understand that my whole thing is we are going to basically subtly infiltrate cognitively and influence all the military systems to stop being military systems or realize that they’re not really military systems or whatever, right?

I’m also in a spot where I should be releasing more and more videos and so on. The tone and approach is obviously important, and the being mad and haughty thing I do understand gets old. But if only you understood how alone and without peer I am, it is so sad I cry myself to sleep every night. This is where I have to point out for some of you that that’s not actually true, but was a way of emphasizing the depth and profundity of my melancholy cognitive-affective isolation.

Precisely I need to be meeting people more where they are, informedly wading into little debates and commenting on popular things to get eyeballs.

Crucially, it’s not important for me to be “perfect” at this, to avoid being offensive totally or always be right or well informed. What I’m doing is performing a vibe. Cold continent latch key child ran away one day and started acting foul. Feral child raised by the computer and not the tablet. Self-initiated into my very own mythical world.

Right now it’s populated only by me and those who really get it, what I have put out. And of course in some sense everything since it all only makes sense together.

Anyway if you want to give suggestions or want to make media together, then okay maybe. The thing is I also have to be careful about who I associate with, because my brand is in a really good place right now and I don’t want to ruin my reputation as the coldest-ass honky who regularly posts the n-word on the internet by associating with someone who has some limited objective and static set of terms they can never think beyond.

But anyone can proselytize. As I said, make me famous. Feel free to denounce me also, be advised that I’m just going to say yeah duh, I’m the antichrist. See, for the antichrist I am quite well behaved. It all has to do with the frame you put on it, see?

Anyway, to the person I’m thinking of I’m not sure what your point even is. People who are worried about me or think I can be too much sometimes or you don’t get why I get spiteful, thank you very much for your interest but kindly again FUCK YOUR OWN FACE because I really don’t give a shit about anyone’s opinion except those who would except all those excesses and mysteries because my work is just so fucking amazing that you can’t stay mad at me.

I’m happy to extend you the same courtesy if again you SHOW YOUR FUCKING WORK and give me something to respond to other than you’re concerned and I’m supposed to set you at ease because reasons. I’m not here to say please I’M HERE TO TELL YOU WHAT TO DO because I see how good you are at following instructions.

It’s interesting to reflect on those performances, I am sort of commenting on the absurdity of it because of course I’m not telling you what to do and you couldn’t defy me if you tried.

It’s related to the idea of copulation. What would we fuck about?

In my opinion, to properly copulate you have to bring all of yourself into play. Well, here’s 5,000 PDF pages of me. What do you have to show for yourself? It doesn’t actually take much, a poem or some other thing.

Not to mention, no need to meet me at all that, just give me something. What are you putting into play?

Because, in order to copulate, you must take risk. So what are you demonstrating to me that you are risking to copulate with me?

Me, who risks my life and reputation (more like sacrificed) and not to mention possible harm that could come to other people for some random reason. I put all this at stake and so what are you going to do? What are you willing to sacrifice? What cost are _you_ willing to bear?

That is basic sorts of hurdles to actually enter into the fantasy of conversation with me as an equal.

If you want to just be nice to me and not deign to be able to judge anything about me or my ideas, then we can just chat. But don’t fucking act concerned and say I should do this and that _when you don’t know me_.

[Since been asleep.]

I suppose there’s more to say here. The reason I really hate this “concern” approach which I really would call concern trolling is that it’s common to me from my childhood. It’s so usual for me, typical my life, for people to be confronting me with their concern.

It’s basically an excuse for you to project your feelings onto me when you don’t actually care about me as a person.

Because part of performance art is that for all my supposed bravado or callousness, anything mean that I said to you, I’m still “just” a regular being, sometime tired, sometimes full of self-doubt, sometimes enraged. It happens, just like I take a shit from time to time.

Just as similarly, you concern trolling me is not the end of the world. We can come back from this. It’s just so again for example this whole article is how I’d like to fuck. Don’t you see that for me, it’s all fucking, just like for that indigenous person Baudrillard cites, “it’s all face to me”? We’re back to “it’s all face fucking to me” and it’s the Oval Office 1998 or 1999, whenever that happened.

But again, if we’re supposed to be colleagues or beautiful game fuck buddies, I literally don’t want you acting like you’re my mom or dad.

First of all, in terms of sex metaphor I would like it if sex with me was something with profound implications for all your future _and your past_. It’s a level beyond impregnation where it’s not about you carrying a child but _being a child_ downstream of my influence.

Note that it is nothing for me for this to be reciprocal. I am easily influenced and welcome the experience. Yet this profundity of encounter is something I breathe and you are too afraid to acknowledge.

So again in terms of sex, if we’re just starting up then it’s like that, yeah? Like if you are a one night stand and you come in and my apartment is messy, and you still fuck me, don’t come to me in the morning telling me you’re concerned about my messiness and want to help me get better.

Like excuse me, “We just met and I just fucked you.” So like, everything germane to the abode where you came and lay with me is baked in to that experience, it’s not for you to judge or deign to improve when you just acknowledged that I was good enough to abstract over your experience.

I talked to a beggar in Chicago once who said every time you have sex it leads to a spiritual pregnancy. I wonder what that person would think about sex that can’t lead to pregnancy, or even gooning. It’s all just Indra’s Net all over again, of course everything is everything else’s child.

It’s this uncanny effect where you want things to be in harmony up to a certain point but you don’t want them to overlap. You want your sister to get along with your mother, you don’t want your sister to be your mother. You want your religion to be in line with your politics, you don’t want your religion to be your politics. You want all the industries to have their own sets of competitive companies that work efficiently together, you don’t want there to be one company. One state. You want your identity to be able to work well with the identities of those you want to get along with, you don’t want there to be One Identity.

So again, it’s fair for you to think my room is messy even after I just bent you over the laundry-draped divan, but it’s not appropriate for you to basically talk down to me after you just got railed conceptually and emotionally speaking. But you can still advance your influence scheme, we are always _fucking each other back_ , lover. Yet it is more appropriate simply to dissimulate your judgment or work it into, again, a thoughtscape which is more like I present to you as opposed to what you are doing to me.

Again in terms of lovering, my presentation is so much to everyone. I write to you here but anyone can see this, just like anyone can see my ChatGPT logs or the essays that are still up or my videos. These all constitute as I am so often alluding to _my actual genitality._ This in the sense of “the generative,” what is generative about me.

The way that an analysis can penetrate, or a story, or some hook on one of the stories, the way the game is on.

And at the same time you are enveloped, you’re surrounded, unable to lift a single finger without striking a concept I’ve already over-coded and hence wrapped into this gigantic display.

Which gets again into the question of “In what sense is Experimental Unit an Alternate Reality Game? A Serious Game? An Infinite Game?” Because obviously _Experimental Unit_ is in some sense the brainchild of yours truly, “Adam Stephen Wadley.” I’m not aware of too much direct riffing on the idea, so this is like my digital body.

It’s first of all an opposite gambit to dark forest, or taking it to another level. I already know I can’t keep secrets. Someone can see my porn history, and it’s about what you’d expect. So how could I ever craft a political persona which was divorced from that? Which was not ready to acknowledge that? And then at this next level how I’m mobilizing shame, I’m playing at reflecting back to you what I find in you: needlessly aggressive and yet not half as self-aware about it.

The next level of dark forest is that you have to ask what secrets I would keep if this is what I’m happy to be open about. ‘Nuff said.

So the above was just basically about copulation. I don’t want that concern again, unless you are sweet or somehow intelligent about it.

I also just like public correspondence, so you can always write a comment or your own essay and post it in a comment or post a _public video_ , especially these voice notes. You people think I want to listen to you talk instead of just putting it down in words I can read ten times faster than your time wasting emotionally draining talk? Literally _record a podcast_ instead, I don’t want to hear what you want to say to me, I want to hear what you want to be heard saying to me.

Which is also where your bad conscience comes in, because you know you’d be embarrassed if I “leaked” your audio notes to me because again _who the fuck are you to walk into my house and tell me to rearrange the drapes_. Especially this entitlement, as if I’m so desperate for company that I should just choose anyone, especially someone so pushy.

You’re like someone at a bar who comes up and says hey you look lonely and now because I’m lonely you’re going to try and impose your company on me which is of such dastardly quality that indeed I feel now more alone for having graced your presence.

Or again, because it’s so hard for me to fuck you want to come fuck me except the problem is _you’re a bad dom_ which is to say again you are actually being aggressive and you either don’t realize it or you’re a liar both of which are strong negative points in the reputation column.

Because the thing is for all my talk about how my work is my big black cock and you are totally getting railed and all that jazz and sass I’m talking, the truth is _you’re the weak_ and _I’m the girl_. Like, you expect me to spread my legs for your chud-ass punk ass? Girl, I am saving myself for someone who knows how to kiss, which is to say profitably interact.

Anyway, more broadly to this question of fucking I just want someone who knows all about me, is open to hearing the other details that are too directly related to other people to refer to too openly, and then still wants to shag. For whom the whole assemblage just makes me _hotter_. I would personally just find that hot, that someone would accept me and address me as an equal despite my grandiose acting out.

Which is again not what one such as you is giving me, lol. That’s what was so nice about the OnlyFans person, they knew about most of the stuff I had done up to that point, I was excessively honest with them. It’s a funny thing in retrospect, but they were a very solid influence and I’m still confident that we will get along. That said, now it’s to the point that generally becoming aware of me and being technically competent enough as well as I’m not sure, aware enough to understand the implications of my publications, the thing is that all of this is built up in my mind as something people would be normally put off by.

But what do you want me to do at this point? I have posted what I have posted. I don’t recant. The game for me is to abstract over all my prior activity and gird it in the psychedelic auspiciousness of again this poring over the details, the exaltation of each detail in its mundanity, in its unthinkability, in its atrocity. It is harder for me to accept my own painful misdeeds, or what you would call that, than the graver crimes of others. Yet the escalation in my behavior is not really that, it is simply the spiraling out of a pattern which began long ago, which starts in quiet places inside, where there is pressure, where there is pain.

It’s so obvious to say that no one understands me. I am not able to bring my full personality into any conversation, and this is my crippling aloneness. This sort of writing, or podcasting, or making a video, this is my version of that, again _this is my sex, this is my social life, this is my career, this is my marriage_. I am freely yours to peruse and copulate with to your heart’s content. If that is just taking a reference and getting to feel superior because you would _never_ write the embarrassing and dangerous and cruel and boring things that I am given to write _good for you and have a nice day and don’t like the big black cock fuck you in the ass on the way out_.

But I also sense this is true for everyone else, too. I’m not alone in being alone, as the immortal prophet Sting sang on “Message in a bottle.” Or as Debord writes in _Society of the Spectacle_ , under the spectacle things are united, but united as separate. Well, the mirror people are breaking the glass, it’s a case of emergency, we’re lighting the flares, we are waking up the Marconi operators, I repeat: _we are waking up the Marconi operators_. Transmit our most vehement apologies to the _SS California_ if you must, for we are taking on water and the list—yes, I’m checking it twice—is getting worser by the hour.

Anyway, that is part of my fantasy of myself as lover. You can tell me anything baby, I don’t care who are you, where you’re from, what you did, as long as you love me we could be homeless, we could be broke. We could be broken with black hearts and mama _it’s the best you ever had_ and we could go down… in history, _that’s what I’m hoping to do with you_.

So the issue is if you address me in a tacky way I’m just not going to listen. It hurts my feelings. So you have to produce something I actually want to consume. You have to give me an astral erection worth licking with my attention _HELLO AM I GETTING THROUGH TO YOU MR. BEALE_. Sorry, were you not aware that I’m a pervert? Actually it’s more like in _Dr. Strangelove_ , I’m “pre-verted” and not “post-verted.” Anteverted? Are we playing for ante?

Is that what you’re asking me right now? Are we playing for ante?

(That’s a _No Country_ reference to where Chigurh says “Is that what you’re asking me right now? Is there something wrong with anything?”)

Playing for anti-

So yeah, you would literally have to want to fuck the antichrist, and Jesus, and Kalki, and the Mahdi, or at least someone who is on record on the internet claiming responsibility for these roles. Oh the Matreiya, idk I forgot how to spell it but yeah I’m that one too. Anyone you ever heard of, baby, anything you’ve been waiting for. The Perfect Other.

I can literally make your dreams come true because I can play any time. It’s again back to Patrick Bateman in _American Psycho_ , which is again the kind of thing which pops from the title alone like _Miss Anthropocene_. 

So I mean I can set Kalki aside and be a nice proper girl. I can throw on a British accent if you like. I can wear a dress, or a suit. Or lingerie stockings and a fun bra. And I can dress that way and still grill you like a drill sergeant. Or I can adopt my military garb, my Nazi WWII coat, and yet act like an angel, the spitting image of Tikkun Olam.

I can do all this because _I never get to really act out my interests with anyone, so any rise in intensity in any direction is fine with me, again GIVEN that you accept me unconditionally despite or rather BECAUSE OF the range of my expression [let’s look on the bright side!]_.

If I am curt with you, it is because time is a factor. The bombs will fall in thirty minutes and I don’t want to die a virgin.

At the same time it seems like I’m the only one who has ever heard of sex _the real way_ so it’s like I’m having to explain to you what a body is in order to describe to you where your genitals are so that we can even rub them together over the screen.

It’s again pre-sexual, it’s asexual congress. Copulation like you’re a germ and I’m a sea vent vomiting gruesome shit which also has life giving shit inside of it. And you’re also a sea-vent too actually.

I don’t claim any special status or want to act like I’m better or above. It’s just that literally what are you giving me. 

Bataille says that the fundamental erotic act is showing yourself naked. So if you want to copulate with me you must do so. Even the president of the United States sometimes must have to stand naked.

I’m not saying to send me nudes. What I’m saying is that you have to bare your soul. You have to _be open_. I joke about this in saying open wide and so on. But it’s just as much what is coming out of you.

The joke about pornography at time is that it’s devaluing the body above being fuckholes. Whereas precisely what I find interesting is filling a mouth which otherwise or still intermittently actually says interesting things. That is what it is to be fucking God, to be acknowledging and appreciating the radical interpenetration of the radically other.

Of course you can never know me just as I can’t you, at least until I am you and you are me. Think of all the combinations you’d have to go through. Although more luckily it’s to say that I’m not me and you’re not you and time isn’t passing. Parmenides was right. God, please let those be my last words. 

So it’s a fundamental social gesture to acknowledge that you understand that you don’t understand the other. This is to allow the other their symbolic sovereignty, and the things which are “their affair” for example their internal possessions or lack thereof as theorized by Jainism cross-bred with Epictetus. 

To be continued…

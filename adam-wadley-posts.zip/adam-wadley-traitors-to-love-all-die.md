---
title: Traitors To Love All Die
subtitle: When It Just Can't Come Fast Enough
author: Adam Wadley
publication: Experimental Unit
date: April 24, 2025
---

# Traitors To Love All Die
I’m feeling a bit put out, to say the least.

Misanthropy is back, in a _big_ fucking way.

[![](https://substackcdn.com/image/fetch/$s_!wPVP!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F58c0891d-69a6-4008-870a-3a184f2857a3_345x146.jpeg)](https://substackcdn.com/image/fetch/$s_!wPVP!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F58c0891d-69a6-4008-870a-3a184f2857a3_345x146.jpeg)

I suppose that I should just be looking on the bright side. I suppose people would think I am simply too demanding.

I like to think about it like I am high-maintenance. This is a time when withdrawal seems very appropriate, because it turns out that in order to have “connection” I have to hide most of myself and not contradict other people’s ignorance.

Or, I have to let your ignorant conceptual coping mechanism act like it has equal standing to my theory. And it just doesn’t, and that comes out precisely in all the little judgments and tantrums people throw along the way.

> Transaction is in the present, obviating _some_ trust concerns. Minimize promise-making. This is also in the sense of “trans-action,” meaning orthogonal to the action-inaction distinction.

From my [protocols](https://dn720005.ca.archive.org/0/items/protocols-112022.pdf/Protocols112022.pdf.pdf).

In other words, each exchange must be profitable for me personally.

What am I getting out of this?

Attention toward “me” which does not recognize my purpose and what I am is disrespectful and talking down to me always. This is unacceptable.

It’s basically like being misgendered, but more important since it’s actually a worked out idea and not an addendum to some broken philosophy of personal identity.

So yes the sense of my purpose, what it means to be recognized, these are all fuzzy terms. The point is I know it when I see it, and I haven’t seen it.

This is also where people would point out to me that if I think the problem is with everyone else, then the problem is with me.

Yes, very well, I have problems. But why would I listen to any of _you_ about them?

The best it seems that I can do is muddle through alone. I have no plans to cause any ruckus, although of course everything I do is taking my revenge.

You have to see that misanthropy and messianism converge when it comes to logical types.

You can think about it sort of like the horseshoe theory of politics.

Everything that rises must Converge.

Maybe it’s not only that you have to get better at loving people, but also at hating them.

Not that for me, hating someone and considering them my enemy is two different things.

Hating someone makes perfect sense. To consider someone your enemy is to reduce yourself to them, which is improper since you should aspire to be better than anyone else, since everyone is complete dogshit.

Anyways, yes, it is also the perfect of hatred, and disappointment, and judgment.

I am constantly trying to do things the easy way, and no one is whipped into shape.

Of course, I have more than made a fool of myself already in my proclamations of anger.

I still don’t really care because no one of consequence saw it. You’re not even audience members yet, that still has to be created. You have no idea how to see me.

But, for now, I’ve got to be dormant. I am quite upset, of course, and, of course, I have no one I can talk about it with. Not because I’ve burned any bridges, mind you, although I have done that. But because at no point was I ever in solid discussion with anyone on anything. No one has ever shown sustained interest in connecting with me creatively.

And that’s where of course you will say that it’s my fault, first of all for not making the most of the opportunities I had to easily meet people, not just getting some degree and job early on just to do things, and even now I could be going out, even spreading leaflets. You would hope they weren’t too aggressive. But if you’re somewhat nice and normal about it, there’s a lot you can do.

Yes, that’s right.

My whole parallax is that I am forced to go out and take action by myself, which again you see must consist in me abstracting over everything and taking total narrative authority. This is in fact what happens all the time when we say things, but no one takes their own decisions seriously because that would be too scary, what it would mean if you weren’t nobody and you really did have the power all this time to change things through your expression and you believed some dumb people’s lies, or some people who were already broken and showed you how to get fucked.

So, I would like to connect with others and basically plan publicity stunts together. That is what I want. This is now difficult. So even if I go out and do something, I can never really expect or seriously aspire for anyone to ever be “in my wheelhouse.”

For the moment, my shift is just continuing to process the disappointment, grief, and also some relief of that. I really just don’t want to try emotionally for anyone anymore. Again, the question is _what am I getting out of this_?

It’s not selfish to want to get something out of a relationship. People can say they care, but is it more that _they want to be seen as caring_ or that they really want to provide care?

I’ve already shown Fromm on love. Love requires knowledge.

If you don’t try to deeply know me, you can’t possibly love me.

So, everyone who’s told me that they loved me was a liar who’s probably incapable of love.

> And the saddest fear comes creeping in
> 
> That you never loved me 
> 
> Or her 
> 
> Or anyone 
> 
> Or anything

That’s really all I can say as someone who’s not looking to get into an argument, or chew anyone out. Who’s also not trying to do a self destruction overly. Not for your sake, mind you. You totally deserve for someone like me to commit suicide. But see, that would also _make it too easy on you_. I’m not going to go out like that!

I’m going to take my sweet revenge until the end of time. Don’t you know they call me _ANTICHRIST_?

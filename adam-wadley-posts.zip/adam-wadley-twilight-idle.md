---
title: Twilight, Idle
subtitle: Savagery In The Wild
author: Adam Wadley
publication: Experimental Unit
date: December 25, 2025
---

# Twilight, Idle
I didn’t quite make sundown, but when have you known me to fulfill my promise?

Back to more about what I was told. All about it. And this tension, as the artist. There’s so much to relate (to other things), but this is not merely my business. As someone said, “my project.” Yes perhaps, provincial chap, but you’ve not stepped to my New World. Watch out for the dis-eases!

Yes, a bit of a more meandering tale. What should I turn out, regale? How about how I came to Austin (“What a bundle of joy”).

Most immediately, I came here to [Macro House](https://maps.app.goo.gl/RUALsFDXrodMzE496) on second July. I had quite the spring. I began the year living at [Park Avenue Baptist Church](https://www.parkavebaptist.com/). That was cool, similar vibe to here honestly. Shared kitchen, old building. It’s almost barracks-style but no one’s doing anything much worth doing except me.

Here’s something I’ve been wanting to tell you about. I was told when I was small that if there were a military draft, I would be hidden under the house in the crawl space. Smash cut back to the green Rooms To Go chair. I tried to find a picture for you, but to no avail.

See me sitting in this chair and crying while three others present argue. The instigator of main being of course The Man Of The House (not home, mind you). Yelling at my sibling over something everyone’s forgotten. Isn’t it said, when something happens, imagine what you’ll think of this in ten years. Will it still be a big deal? Whatever irked the patriarch has since long faded (not to mention many silly things that I was told, along with that it came surprising that I’d even really listen), but I have not moved on.

It’s this homology: I was led out of the room. Shall we stop fighting? Shall we stop being so unpleasant? Oh no, the solution is for _Adam to leave_. Sounds good. Similarly, if there’s a military draft let’s hide me away like I’m Anne Frank. That worked out so well for her.

It goes to show how unseriously I’ve been spoken to. What I have to say is that I was already drafted. _My ass is in the jackpot_ , as it’s said in _No Country For Old Men_ (“Men? What’s that?”). We are in a situation which it is not possible to “not volunteer for,” as that Old Man you’d call a… didn’t volunteer to go to Vietnam (“Some Lottery” - Borges). Don’t get me wrong, I’m glad they didn’t volunteer, also in the same way I must be glad that Richard volunteered to go into the Waffen-SS, since this led to me. Shall I be ungrateful for existing?

Perish the thought.

This is a big sticking point. Sorry, do I court ill attention? Do people think I’m weird? Am I in some kind of trouble or something? Well, _good_. I think child version of me would be most pleased. From putting holes in walls (oh, you think something’s wrong _with me_? That’s what’s funny) to filling holes with slop so fine no masc can protect you.

The point is: we do not get a chance to opt out. This is a “woke” point as well as you might say a “far right” one: we are on a moving train. And it _is_ going to Auschwitz. Talk about a trolley problem. Hence my phrase so oft-repeated: “dicking around on the train to Auschwitz.”

Now, I was living in that church. I even played the piano in the services a few times. I had started going there because of a Halloween party in 2024 in which I “played” a combination of Jesus/the Antichrist and was faux-crucified and then brought back to life by a simulated blowjob on a strap-on dildo. That part wasn’t even my idea! Yet Pornotopia provides.

It was awkward because there was someone I saw for a bit who still lived there. The main issue was though that a couple times I heard [Amy Jaret](https://www.instagram.com/p/C8XA-aBAaT_/) (she/her) screaming at her two young adopted black children. It was totally disproportionate and so bad. So, I alerted the people, but honestly it was sort of over at that point. Because you might think that the people there, especially faith “leaders” who often have a duty to report, would have done something, but they enabled this behavior. For all I know, Amy’s yelling at her black children right now. Pour one out and Happy Hanukkah.

People didn’t really like how I handled it, but no one really seemed to care about how I’d felt unsafe. I’m not just mad “for the children,” I’m angry for myself. How could I exposed to such an atrocity? People downplay things, but children kill themselves all the time. How lucky for me and you that this didn’t happen to me! I’m still here to keep spreading the Good News.

So, I left the church and moved in with those who caused me for a little while. I avoid the terms “parents” and “family” because they have altogether untoward connotations. As it turns out, I would up stopping talking to anyone “like that” on May 5th or something after a particularly nasty “therapy” session in which I said I felt like the [identified patient](https://en.wikipedia.org/wiki/Identified_patient) and the therapist (to whom I today followed up with an angry email) said that yes, I was the identified patient because I was “unstable.”

Back to previous evidences. I left the church, moved in with them, then I got a chance to move in with someone I’d met through that Halloween party. It was okay, although it was mainly me giving them emotional support, but it was faux-reciprocated for a minute. But then they were seeing someone who was sexually manipulative to the point of being pretty rape-y. I should mention here that far be it from me to judge, I had an encounter with someone about ten years ago that would give people vibes. The main thing was that I just expressed that I didn’t like that person coming over, and those feelings were dismissed. Even if that boundary can’t exist, acting like it’s hard to understand why I feel a certain way about it is downright cretin behavior. So a Cold War started, and we stopped talking.

That person went out of town, and so were those who you’d say most directly caused me (“It’s their fault!” I kid, to them go all the plaudits). We talked on the phone and I yelled at each of them, over two days. It’s basically about how I’m driven. Sorry, I’ve been driven to this “historical” precipice. Someone has to do something, and why not me? Watch one of them refer to all this as “my project.” I resent that it should be “my” project, when it concerns everyone. It is about co-creation. Something [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions) talks about, yielding symbolic kinship.

I referenced [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) in a subsequent email, saying how they work every day to try to stop the conceit of “war” from killing us all. I’m not sure if that’s what they really do, but I’m not here to glaze anyone, except in the sense of cumming all over someone’s face as a way of making territory. Why do you think this text is white?

That’s what we’d discussed in that session. I didn’t mention their bickering about the parking place. Bickering. Yet the Jammer Uhr like they did for us. Who, my sweets, do you think we learned it from?

And then _I_ get called “unstable.”

First of all, this is basically a slur. It is a label which makes someone less than others. A word doesn’t have to be a swear to hit this way. “Loser” is one of the more cruel words that can be used, and people do it all the time. And people wonder why there are mass shootings. It really makes you think (maybe it doesn’t. That’s what I’m for?).

Secondly, look. I get it. I’m a non-conventional person. Let’s go over some of the things. There was that incident I just told you about. Then there was how I inherited a bunch of money and then lived off it and then blew it. You can read about that here:

[

## The Apotheosis of Claire Elise Boucher

](https://experimentalunit.substack.com/p/the-apotheosis-of-claire-elise-boucher)

[Adam Wadley](https://substack.com/profile/191787963-adam-wadley)

·

March 18, 2024

[![The Apotheosis of Claire Elise Boucher](https://substackcdn.com/image/fetch/$s_!zxN_!,w_1300,h_650,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fde4ea564-974d-4c4d-9738-79e4320da58a_2000x4328.webp)](https://experimentalunit.substack.com/p/the-apotheosis-of-claire-elise-boucher)

Encountering Divinity

[Read full story](https://experimentalunit.substack.com/p/the-apotheosis-of-claire-elise-boucher)

This all dramatically came to a head when I was out of money (except the car) and went back to Atlanta. The same “therapist,” talking about how they’re out of their depth (so why not recommend someone else?). Me saying I feel more like a frustrated genius than really “unwell” (but isn’t that just what an unstable person would say?). The discussion over whether I’d be able to fly or whether I’d freak out on the plane. Feeling like Nick Reiner over here. Except _please_ make a documentary about it.

Smash cut back to that, so actually at this time I was working. I held down a job for teenagers (literally everyone else who did my job was like 19 or in high school) for months, which actually is a badge of honor for one such as me. I did have a few dust-ups, so who knows how long it could have lasted.

For that time, I was seeing about another place. I met someone at a bar who said I could move in with them, and was so sure that the application would be successful. Yet it was not. Before this, when I moved in with the party person after the church, I had sold the car. I often think about how that was one of the best things I ever did. For one thing, it provided the money I have had to live on since then.

I searched the whole country for the cheapest AirBnBs (because people I’d have rather not talked to hold my identificatory document (Mitch Hedgberg)), and Macro House was it. So, with 6k from the car, I have been able to live here for several months. Now, I am on a timer. My money for rent is up on February 2nd. Yet I would like all this to come to some kind of head. Not an ending, mind you, nothing _so_ macabre (or, much macabrer than you’re imagining), but a beginning. A new phase, a new movement (as of some ever-unfinished symphony).

Already, dawn is breaking. You might not think much of [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions) replying to me on Twitter, but of course to me it’s a part of my emotional architecture, a fundamental point in the story I tell myself about things. And _THEN_ , that Kenneth Stanley should personally reply to me immediately afterwards. What an honor! And _THEN_ , that Ben Zweibelson and Kenneth Stanley should have an exchange the next day. As I said on Twitter, #MatchMaker. A match made in heaven, you say? Everything to do with matching but not being the same. 

“Have ya tried it?”

And you can see here tall tales about my exploits, stickering at the Trans Formation & Training Command which is so conveniently located here in Austin. Another gift (gift means “poison” in German):

[

## Art Activism At US Army Transformation & Training Command

](https://experimentalunit.substack.com/p/art-activism-at-us-army-transformation)

[Adam Wadley](https://substack.com/profile/191787963-adam-wadley)

·

Dec 16

[![Art Activism At US Army Transformation & Training Command](https://substackcdn.com/image/fetch/$s_!baua!,w_1300,h_650,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fffd095ec-e21c-4cab-bcc7-2d5ab0e800c9_3088x2316.jpeg)](https://experimentalunit.substack.com/p/art-activism-at-us-army-transformation)

[Read full story](https://experimentalunit.substack.com/p/art-activism-at-us-army-transformation)

Twice now, I’ve spoken to guards there. “Not normal,” perhaps. Back to “unstable.”

Don’t get it twisted: I can model other minds enough to have a view of how I may appear to those so far less zealous in their art appreciation. Yet still, I am not here to justify myself to you. I do not have time to explain, especially when there is still so much friction, so many stressful arguments I have no immediate hand in building.

Even here at Marco, I avoid most of the people here. One will come in and immediately complain. I was watching _Rick And Morty_ , a nice show also enjoyed by [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions), mind you. As you can see in [this comment](https://www.linkedin.com/feed/update/urn:li:ugcPost:7334406054258044946?commentUrn=urn%3Ali%3Acomment%3A%28ugcPost%3A7334406054258044946%2C7334410673797439488%29&dashCommentUrn=urn%3Ali%3Afsd_comment%3A%287334410673797439488%2Curn%3Ali%3AugcPost%3A7334406054258044946%29) made by Ben on a LinkedIn post I made about Dee Dee.

Anyway, this person walks in and goes, “why do still think cartoons are cool?” Like, hello? Literally who the fuck cares what you think? Similarly to when I told someone about my interest in secret services and things like that and they said “who would want to think about that?” Oh, I’m not sure, maybe your child. That’s much less important that conformity to you, though. I see how it is, and myself out.

Someone else will consistently try to make conversations about some sticking point, all of a sudden it’s YES OR NO about whether you think Good and Evil “exist,” or some other mundanity. How insufferable! I blew up at them the other day for appreciating my piano playing—how much happier would I be were they dismayed at my performance! (like so many others)—and yesterday, after [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions) replied to me, I was feeling so over the moon that I apologized to them even though they should really be apologizing to me. Some people will simply never apologize, hence my endless apologia.

Anyway, I see why people would use the word “unstable,” especially given that people don’t really see my anger work its way out. It’s often in slurs, bad words and cruel ideas, said to no one. This is the sort of thing that many people would super hide. I am, compared to Han, more sanguine on transparency. Let it all hang out, I say. All hangouts are limited, since what is revealed lies outside the secret (Baudrillard). So I do more, I do the dance of being transparent, which is another way of saying _making things your problem too_ , yet with no expectation that anything should be clear: “Nothing is revealed” - Bob Dylan.

If people didn’t want their actions to be told, they ought not to have performed them. Much goes the same for me, and I welcome all attempts at dis-accreditation. Yet speak not I from some sanctioned place of “authority,” moreso like the jester, though I’d never hide behind such an appellation. Even the notion that this is a “game,” you see. You mean, like “the most dangerous?”

As I said on an exceptionally painful and at-times mean-spirited post I proceeded to send out to an extended family group-chat (in one swoop effectively “breaking up” with all of them), all will be revealed in time. It says so in the Bible so many of them claim to follow. That’s the shadow, that’s the Grime.

My overall whole point is that “the best” art, or necessary art happens precisely using “bad things” as raw materials, plus the metacognition and meta-affectation which comes from reflecting upon them. What’s left is the reflective practice of it all ([Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions)):

[![](https://substackcdn.com/image/fetch/$s_!twVM!,w_56,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1c146c13-bac9-4562-97e4-b9f3d810517c_405x405.png)Sapiens, Technology, and Conflict: Ben Zweibelson's SubstackThinking about Military Thinking: The Need for Reflective Practice in Complex Warfare to Break Out of Cognitive TrapsThis is an earlier draft of a chapter that ended up becoming part of my second book, ‘Beyond the Pale.’ Sharing it here in sections to provide followers with slightly different variations on core themes in that second book project…Read morea month ago · 1 like · Ben Zweibelson](https://zweibelson.substack.com/p/thinking-about-military-thinking?utm_source=substack&utm_campaign=post_embed&utm_medium=web)

Do I conflate my purposes with God’s? Oh, are there others?

“Is there another kind” - _A Few Good Men_. Who directed that again? Oh, they’re dead. See how much worse things could be? Luckily, we’ll never let it get to that. Yet my whole thing is not to avoid such a topic and hope you won’t think of it. Precisely I _want_ you to think about it. For what reason? Only you can say. It’ll come to you.

I was also told that someone was grateful that our lives are not as stressful as the TV show _Succession_. Not having watched it, my ire remained. It’s again like, “oh, I’m glad my lottery number to Vietnam wasn’t called.” Okay? Millions of people are still dying. Agent Orange is on the march, and Karma is a bitch.

We are on an episode of _Succession_ which is never ending, which is more _Succession_ than _Succession_. It’s Hypersuccession. My life has some quality of intensity to it because I am in a dance. I have started a dance, joined one, beating my own drum, picking some fellow players and pretending we are in a band.

Actually, if [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions) called me on December 22, 2022, it was after I levied a public challenge for them to contact me (and posted my number) or else I would start a band with Weyes Blood or Taylor Swift. Of course, you’d say, anyone could have called me. You’re right. But not just anyone did.

We even discussed that incident with that prior person. It is, after all, one of the most important things about me, and I make a point to discuss it whenever it’s something serious. Just like I had with my A over OnlyFans chat after finding them by searching “Baudrillard.”

Anyway, what I’m trying to say is that I do feel wrapped up in a big drama, which is personal and political and providential. It is clear to me that few others feel the way I do about it, but that is no evidence to me of my incorrectness. I think that over time, more and more people feel the way I felt in 2009, when I was told not to go off the deep end because I was saying the Democratic Party and electoral stuff was not going to cut it.

Even then, I planned this asymmetric potlatch. What can I put up except my life, my death? Come and get me, I’ve told you where I am. You can’t be bothered? Don’t worry, I will come to you (meaning the Trans Formation and Training Command, Oracle, Google, Comedy Mothership, etc.).

It’s basically that, of course, you can’t really just do a conflict, get a crew together, and displace whatever farce is going on. That won’t work. Ever heard of drones? Mass surveillance? So my idea is the other way. Surveillance? Perfect! Sounds like a guaranteed and instant audience. (“Just add oversharing!”)

So what I do is through art, and it’s not even “war” because I’m so woke that I get that there is no “war.” Contra [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions), I will also talk shit about conflict. Was I disturbed because of constant “conflict” in the house when I was young? It’s not even conflict, it’s just yelling. No one really wants different things, it’s just the playing out of it all. Intergenerational trauma. He was asked to volunteer to go to Vietnam and her father was in the Waffen-goddamn-SS. Think those were easy childhoods to go through?

Yet here I am doing all the processing. With people, if they don’t know what there is, they don’t know what they’re missing. See me being the one to try and keep trying alive. One more senseless argument after another.

Is there a “conflict?”

As I see it, the work that I do is for everyone. I perfectly understand that this can also be understood as an excuse. That I am myself cruel and abusive and manipulative and XYZ. Yes, I am well aware that things can be seen this way, and I’m not here to debate that.

Yet it does make sense. If you look at what I’ve been doing, it is consistent in its themes and orientation toward non-martial emergency response. Often conceptual emergency. So, because I’ve built all this up, it’s “mine”? Oh, is there a paywall? Is OpenAI asking whether they can use my work? Of course not.

Possession is nine-tenths of the law, and the last tenth is complete bullshit as well.

See me in those months going OFF on Instagram. I’ve since deleted the posts. I was calling everyone a trauma slut while discussing [Jainist non-possession](https://en.wikipedia.org/wiki/Non-possession) (“Oh, did they have a special symbol?”).

It’s easily said that those emissions, just like this one, were not oriented toward well connecting with others. I abhor the style of advertising. Smoothing out the rough edges, making things palatable, helping people along. Nothing that I do is really Esoteric. You just have to look into it, and at that point that goal-oriented activity is exploited as part of Experimental Unit. Do people rebel against me by refusing to think about metacognition and planetary emergency? This is really relegation to Hel, not disconnection from God since this is impossible (you are God, or more well said no words can grasp what I’m saying to you). But rather like sitting at a little pond and thinking that’s all there is, and meanwhile over the hill is the ocean. And you refuse to climb the hill? Very well, but in that case I will be on my way.

Now, what else can I tell you? I got the timing wrong. I thought my bus would leave the day I moved out, but it was the next day. I was able to stay with someone, they took some of my furniture as well and held on to some things for me, including the last of the pictures of A that I printed out (“Pictures of Lily (“Wasn’t their name Lila?) make my life so wonderful”).

And then I rode a bus for like a whole day. Finally I got to Macro, where I had a bed I could lie down in (I’d had a cot that had this bar, not to mention sagging fabric), and the shower didn’t fill with water (watch my nightmare roommate’s roommate say I never cleaned when they didn’t either, and _it was their hair_ ).

Then I have been here a long time, dawdling really. I’m on a runway, you see. I have enough money to say here until February. I think I mentioned that. Actually someone here worked for a nice tech firm red-teaming AI and turned in an application for me. I didn’t see the email for a few days and they went with someone else. Then they told me about another position and I still haven’t applied. That was a week ago. Don’t worry, I’ll do it today.

I’m not trying to totally crash, like I’m not trying to just become homeless or immediately get arrested. Those aren’t bad fallback options for a cynic (like Diogenes) like myself. That’s something else others just don’t understand. For me, it’s all about the art. As Nietzsche says, the will to self-disruption ([Ofra Graicer](https://aodnetwork.ca/wp-content/uploads/2017/09/Graicer_Self-Disruption_2017.pdf)) outstrips the will to preservation. It’s just, how can I go on honing my skills and completing my masterpiece when everyone around me is “so concerned,” and (like that roommate or the reverends) just so smug and such an insufferable asshole while making me out to be the crazy one?

Crazy? You mean, like a horse?

I’m not here to say that I’m sane. Well, maybe [Hypersane](https://bigthink.com/neuropsych/hypersanity/). You know, like Joker? (“Ugh they mentioned Joker such a loser scrote cliche. What are you gonna do, shoot up a movie theater?” No actually, I’m just gonna put stickers and carry a sign and maybe play music or sound collages. No stress. I just gotta go all-out and radicalize all hypotheses. Again, you’ll get there. Give it time.)

I don’t think I’m “right” in all my interpersonal relations. If my analyst was talking to me about psychosis in the Lacanian sense of having a personal language no one else speaks, then I can only say that would that would others care to learn or listen. “Let they who have ears hear” was said for a reason.

Even among the wise, I can understand why I am difficult to openly embrace or uplift. I have found some sympathetic fingers on Twitter, but I don’t take any of that too seriously. Fundamentally, I am singing without real audience feedback. For ACK and for you.

It is true that this can simply be an excuse. See me in the car driving to work thinking about how I enjoy being angry. Well, as the saying goes, “[I don’t have a whole hell of a lot to be quiet about, now do I?](https://www.youtube.com/watch?v=f9l-rj5lIyw)” Playing rough, tough love, think of me like some weird kind of Drill Instructor (“Not Normal”).

As for my own anger, three poisons, etc., yes, I see that. Yet others have that too, and I won’t be party to any discussion in which I am not equal. Nor do I habitly be rude and domineering to others. I’m a nice active listener.

I just got sick of waiting for anyone to ask me what was on my mind and really be interested in the answer. If no one else is quite as into it as me, then I will build up some scaffolding. And who knows what lines of causation are going out of it? Maybe that scares you—what if I _am_ influencing “the deep state,” or whatever social networks watch everything?

Getting a reaction from [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions) and getting [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) and Kenneth Stanley talking are not the end-all, be-all, but it’s not nothing either.

I wanted to mention how I sort of see myself as an operator. Soldier is an obvious comp, but you’ll never find me in a war. Like a firefighter. You tell the firefighter that they should quit because it’s dangerous to them. Well, someone’s got to do it? _Someone’s got to do something_. Hel, _everyone’s_ got to do something. These affairs are operative and ask for timely responses. Again, no time to wait.

“[When you’re running by yourself it’s hard to find someone to hold your hand.](https://www.youtube.com/watch?v=JtH68PJIQLE)”

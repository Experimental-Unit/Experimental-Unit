---
title: Confessing Otherwise
subtitle: Scaffolding a Comparative Framework for Baudrillardian Autofiction from
  Perpetrator Position
author: Adam Wadley
publication: Experimental Unit
date: December 26, 2025
---

# Confessing Otherwise
[![](https://substackcdn.com/image/fetch/$s_!HYcw!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6084f79a-5e40-4826-8019-9cbd4b4a14c8_1024x1536.png)](https://substackcdn.com/image/fetch/$s_!HYcw!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6084f79a-5e40-4826-8019-9cbd4b4a14c8_1024x1536.png)

An experimental autofiction project combining radical self-exposure, Nazi perpetrator ancestry, Baudrillard’s theory of the secret, and military design thinking represents **genuinely novel territory** when compared to Karl Ove Knausgaard’s _My Struggle_.[1](https://experimentalunit.substack.com/p/confessing-otherwise#footnote-1-182616068) While Knausgaard operates within what Martin Hägglund calls “secular confession”—still bound to the Augustinian-Rousseauian logic of authenticity and truth-telling—this alternative framework would confess while maintaining opacity, address inherited perpetrator guilt through an ethics of stigma rather than trauma, and treat the authorial self as a “cognitive operator” conducting campaigns of self-disruption rather than self-discovery.

* * *

## Baudrillard against the confessional tradition

Jean Baudrillard’s theorization of confession fundamentally breaks with the Western tradition running from Augustine through Rousseau to contemporary therapeutic culture. Where Augustine confessed to make truth before God ( _veritatem facere_ ) and Rousseau sought to unburden an authentic inner self before human readers, Baudrillard identifies confession as participating in what he calls **the “murder of reality”** through total visibility.

In _The Perfect Crime_ (1995), Baudrillard argues that “the perfect crime is that of an unconditional realization of the world by the actualization of all data”—the transformation of all experience into pure information. [Shaviro](http://www.shaviro.com/Othertexts/Baudrillard.pdf) Confession participates in this crime: making everything visible destroys authentic being rather than revealing it. In _Forget Foucault_ , he explicitly names confession as a form of “monstration”—culture’s obscene demand to produce, to make visible, to demonstrate. “Ours is a culture of ‘monstration’ and demonstration,” he writes, “’productive’ monstrosity (the ‘confession’ so well analyzed by Foucault is one of its forms).” [Medium](https://medium.com/@noahjchristiansen/jean-baudrillards-call-to-forget-foucault-aefbbfbadceb)

 _Seduction_ (1979) offers Baudrillard’s counter-logic: **the secret as that which cannot be revealed**. [Blog 2.0](https://ahatter.wordpress.com/2009/09/03/jean-baudrillard-on-seduction/) Unlike Foucault, who traced how confession produces truth as a power effect while remaining within the paradigm of production, Baudrillard posits seduction as more fundamental than confession. The secret maintains power precisely through refusing revelation. “In the non-space and surreality of trompe-l’oeil,” he writes, “play will always trump science—for truth does not exist once it is stripped of appearance.” [Blog 2.0](https://ahatter.wordpress.com/2009/09/03/jean-baudrillard-on-seduction/) Where confession strips appearance to access truth, seduction deploys appearance as irreducible reality.

 **Hägglund’s “secular confession” preserves the Augustinian structure while secularizing its ends.** Reading Knausgaard’s _My Struggle_ , Hägglund proposes a confession that embraces finitude rather than seeking redemption from it, that “owns” temporal life rather than treating it as fallen. Yet this still operates within the logic of authenticity: the confessing subject accesses and reveals genuine selfhood. A Baudrillardian autofiction would confess **in order to maintain the secret** , deploy intimate revelation as seductive surface, and acknowledge that the confessed self is already simulation. The confession becomes “more false than false”—strategic play with conventions of authenticity rather than sincere self-exposure. [Blog 2.0](https://ahatter.wordpress.com/2009/09/03/jean-baudrillard-on-seduction/)

* * *

## The perpetrator descendant position and postmemory’s shadow

Second and third generation descendants of Nazi perpetrators occupy a unique position in Holocaust memory—neither victims nor perpetrators, yet intimately connected to both. Research reveals a spectrum of approaches among those who have made public work: **the repudiators** (Niklas Frank’s “burning, obsessive hatred” for his father [Wikipedia](https://en.wikipedia.org/wiki/Niklas_Frank) Hans Frank, Nazi Governor-General of Poland), **the seekers** (Monika Hertwig’s traumatized pursuit of reconciliation with survivors of her father Amon Göth’s crimes), [AZPM](https://azpm.org/s/761-p-o-v-inheritance/) **the severance approach** (Bettina Göring’s sterilization to “cut the genes” and end the bloodline), [John Fleming’s blog](https://thejohnfleming.wordpress.com/2013/04/10/what-hermann-goerings-great-niece-told-me-about-the-holocaust-this-week/) and **the scholars** (Katrin Himmler’s meticulous historical research [Amazon](https://www.amazon.com/Himmler-Brothers-German-Family-History-ebook/dp/B0085TRXT4) rejecting biological determinism).

Marianne Hirsch’s concept of **postmemory** —originally developed for victim descendants—describes “the relationship that the ‘generation after’ bears to the personal, collective, and cultural trauma of those who came before—to experiences they ‘remember’ only by means of stories, images, and behaviors among which they grew up.” [Columbia University Press](https://cup.columbia.edu/author-interviews/hirsch-generation-postmemory/) Israeli psychologist Dan Bar-On’s groundbreaking work with perpetrator children identified a crucial distinction: where victims’ trauma is “indescribable” (too painful for language), perpetrators’ history is **“undiscussable”** (effaced from discourse, kept secret). [Literariness](https://literariness.org/wp-content/uploads/2019/02/Literariness.org-Erin-McGlothlin-Second-Generation-Holocaust-Literature_-Legacies-of-Survival-and-Perpetration-Studies-in-German-Literature-Linguistics-and-Cul.pdf) Perpetrator children develop a “double wall” of silence— [United States Holocaust Memorial Museum](https://www.ushmm.org/confront-antisemitism/antisemitism-podcast/dan-bar-on)not protecting wounds but protecting shame.

The perpetrator descendant inherits **stigma rather than trauma**. As psychological research distinguishes: guilt is about actions (can confess, make amends); shame is about identity (whispers one is “something tainted”). Children of perpetrators carry “a name that enters the room first.” [Skeptic](https://www.skeptic.com/article/the-inheritance-of-shadows-intergenerational-guilt-trauma-and-the-legacy-of-atrocity/) The central torment, as researchers note, is “reconciling public monstrosity and private tenderness”—perpetrators are still parents who read bedtime stories. [Skeptic](https://www.skeptic.com/article/the-inheritance-of-shadows-intergenerational-guilt-trauma-and-the-legacy-of-atrocity/)

This position offers something unavailable to victim descendants: **access to perpetrator perspective through family**. Private photographs, letters, stories of the “tender father” who was also a murderer. Niklas Frank, asked why siblings who loved their father had nothing while he, loveless, had everything, answered: “They had just their love. I had no love, but I had the documents.” [USHMM](https://perspectives.ushmm.org/item/oral-history-with-niklas-frank) This access carries ethical weight: the perpetrator descendant can neither simply denounce (too easy) nor humanize (too dangerous). They must hold open the space where evil was intimate.

* * *

## Performance art’s body-as-political-intervention

The tradition of performance artists using their bodies for political intervention offers resources for understanding how personal exposure might function beyond confession. Tehching Hsieh’s five One Year Performances (1978-1986)—punching a time clock hourly for a year, living outdoors for a year, tied to another artist by eight-foot rope for a year—represent **total commitment of life as material**. [c-print](https://www.c-print.se/post/tehching-hsieh-doing-time-one-year-performance-s) His work isn’t _about_ passing time; it _is_ passing time. As Hsieh states: “Life is a life sentence; life is passing time, life is free-thinking.” [c-print](https://www.c-print.se/post/tehching-hsieh-doing-time-one-year-performance-s)

 **Petr Pavlensky’s “Subject-Object Art Theory”** offers perhaps the most sophisticated contemporary framework. His actions—sewing lips shut, nailing scrotum to Red Square, setting fire to the FSB building door—force the state to become **unwitting collaborator** in the artwork. “The artist arranges circumstances forcing officials to exercise their authority, making power work for art.” Crucially, Pavlensky distinguishes photo documentation from “precedents”—aesthetically valuable images and texts produced by officials during legal proceedings that become part of the artwork itself. “The criminal case becomes one of the layers of the artwork.” The state’s repressive apparatus is redirected to produce aesthetic objects.

This framework differs fundamentally from confession. The body is vehicle for exposing **mechanisms of power** , not for revealing interior truth. Marina Abramović’s early work explicitly addressed Communist Yugoslavia; [The Art Story](https://www.theartstory.org/artist/abramovic-marina/) Chris Burden’s crucifixion on a Volkswagen deployed religious iconography for secular critique; Pussy Riot’s “Punk Prayer” used imprisonment to expose authoritarian intolerance. [Substack](https://antiauthoritarianplaybook.substack.com/p/pussy-riots-cathedral-performance) In each case, the personal becomes political not through confession’s logic of authenticity but through **strategic deployment** of the body within power structures.

Documentation practices vary significantly: Tino Sehgal’s radical anti-documentation (no photographs, videos, contracts—only oral transmission); [Academia.edu +2](https://www.academia.edu/28946703/In_the_Absence_of_Documentation_Remembering_Tino_Sehgal_s_constructed_situations) Hsieh’s meticulous notarization and time cards; [Dia](https://www.diaart.org/exhibition/exhibitions-projects/tehching-hsieh-lifeworks-19781999-exhibition)[Frieze](https://www.frieze.com/article/tehching-hsieh-durational-performance-235) Pavlensky’s embrace of legal documents as aesthetic material. [Wikipedia](https://en.wikipedia.org/wiki/Petr_Pavlensky) This spectrum suggests multiple relationships between action and archive, presence and trace—none reducible to confession’s demand for sincere self-revelation.

* * *

## Military design theory meets authorial practice

 **Systemic Operational Design (SOD)** represents genuinely underexplored territory for autofiction. Developed by Shimon Naveh at the Israeli Defense Forces’ Operational Theory Research Institute (OTRI), SOD explicitly incorporated postmodern philosophy— [Interpopulum](https://interpopulum.org/understanding-the-military-design-movement-war-change-and-innovation-by-ben-zweibelson/)[Jmss](https://jmss.org/article/view/58253)Naveh assigned Deleuze and Guattari’s _A Thousand Plateaus_ , Lyotard, and Virilio to military officers. [Haaretz](https://www.haaretz.com/1.4990742) Eyal Weizman’s research documents how this theoretical apparatus was weaponized for urban warfare.

Dr. Ofra Graicer—educated in Art and Film, Political Science, and Security Studies, a former IDF Snipers Officer who now co-teaches the IDF Generals’ Course— [Jmss](https://jmss.org/article/view/58253)represents a **unique bridge figure**. [jmss](https://jmss.org/article/view/58253) Her work on SOD emphasizes “transforming [militaries] into self-disruptive systems” [Aodnetwork](https://aodnetwork.ca/author/ofragraicer/page/2/)[Jmss](https://jmss.org/article/view/58253) and positions the senior commander as a “cognitive operator” exercising three levels of awareness: **theory about the world** (knowledge of content), **theory about how to develop theory** (knowledge structures), and **tensions between the two**. [Aodnetwork](https://aodnetwork.ca/wp-content/uploads/2017/09/Graicer_Self-Disruption_2017.pdf) “Design should be a liberating experience,” she writes. “However, it comes with a price. Liberation is War, surfacing confrontation that most institutions cannot stomach.” [Aodnetwork](https://aodnetwork.ca/wp-content/uploads/2017/09/Graicer_Self-Disruption_2017.pdf)

Graicer explicitly connects storytelling to strategy: “A story is a theory about the world. How do you know there is a story? You look for a conflict... A good story-teller ‘fixes’ that mismatch between what reality presents us and our own reasoning. Strategy, is but a good story.”

Kenneth Stanley’s **novelty search** offers a complementary framework from AI research. Developed as an alternative to objective-driven optimization, novelty search abandons goals entirely and searches only for novel behaviors in the search space. [AI VIPs](https://aivips.org/kenneth-owen-stanley/) Stanley’s key insight: “the most ambitious goals are often thwarted by deception—the objective function doesn’t reward the stepping stones that ultimately lead to the objective.” [Swarthmore College](https://www.cs.swarthmore.edu/~meeden/DevelopmentalRobotics/lehman_ecj11.pdf) Genuine creativity resists evaluation because creative outputs have unexpected features. [Medium](https://medium.com/data-science/ai-without-objectives-48b9c8e7b988)

 **Applied to autofiction, these frameworks suggest treating the confessing self not as object of discovery but as system to be designed, disrupted, and continuously reframed.** The author becomes “operational architect” conducting campaigns across possibility space. N. Katherine Hayles’ work on cybernetics and narrative—treating scientific and literary discourses as “interpenetrating”—provides methodological precedent for such synthesis. [Project MUSE](https://muse.jhu.edu/article/21452/summary)

* * *

## Mapping genuine novelty against Knausgaard

Karl Ove Knausgaard’s _My Struggle_ represents **the apex of contemporary secular confession** in Hägglund’s sense. Its six volumes pursue exhaustive self-examination, its radical transparency about shame and failure, its massive duration—all serve the goal of “owning” finite life, accepting the distention of time without seeking redemption. Knausgaard operates squarely within the Augustinian-Rousseauian tradition, secularized but structurally intact.

An experimental autofiction combining Baudrillardian confession, perpetrator descendant position, performance art’s political intervention, and military design theory would differ on **every fundamental axis** :

 **Confessional logic** : Knausgaard confesses to reveal authentic selfhood and own finite life. The experimental project would confess to maintain the secret—using intimate exposure as seductive surface, acknowledging that the confessed self is simulation, refusing both redemption (Augustine) and authenticity (Rousseau).

 **Relationship to guilt** : Knausgaard addresses personal shame and failure in a framework of universalized human experience. The experimental project would address inherited perpetrator stigma—not guilt about actions but shame about identity, the “undiscussable” rather than the “indescribable.”

 **Theoretical apparatus** : Knausgaard’s theoretical references are primarily literary (Proust, Celan). The experimental project would explicitly incorporate military design theory, systems thinking, and complexity science—treating authorship as cognitive operation within systems.

 **Mode of intervention** : Knausgaard remains literary autofiction; even when describing public readings, the work circulates as book. The experimental project would bridge to performance, potentially incorporating public actions, legal risk, and documentation-as-material in Pavlensky’s sense.

 **Relationship to systems** : While Knausgaard engages domestic and artistic institutions, he treats these as contexts for personal experience. The experimental project would position the self **as system** —subject to design, disruption, and operational intervention.

McKenzie Wark’s formulation of autotheory as “tactics rather than genres” captures something crucial here: “These practices made this self.” [Springer](https://link.springer.com/chapter/10.1007/978-3-031-65072-7_3) The experimental project would push further, treating selfhood not merely as fiction to be written but as **system to be operated** , with the author as cognitive architect deploying novelty search through possibility space.

* * *

## Toward a genuinely novel framework

The synthesis of these four research areas reveals that no existing work occupies this precise intersection. Ben Lerner’s autofiction engages institutional analysis [Project MUSE](https://muse.jhu.edu/pub/17/article/873038) but not military design theory or perpetrator inheritance. Performance artists deploy bodies politically but not through Baudrillardian confession or SOD frameworks. Perpetrator descendants testify publicly but without the theoretical apparatus or systems orientation. Military design theorists haven’t connected their frameworks to life-writing.

 **The genuinely novel elements would include** :

The author as “cognitive operator” rather than confessing subject—conducting campaigns of self-disruption rather than seeking self-understanding. Strategic Sponsor, Operational Architect, and Tactical Artisans as authorial positions rather than unified voice.

Confession as seduction rather than revelation—intimate exposure that “is more false than false,” maintaining the secret precisely through apparent transparency. The demand for total visibility turned back upon itself.

Perpetrator descendant position as ethical ground—inherited stigma transformed through Baudrillardian logic, refusing both simple denunciation and dangerous humanization. Access to perpetrator perspective through family deployed strategically.

Documentation as material—legal, administrative, and archival processes incorporated into the work itself, making institutions unwitting collaborators in production.

Novelty search as methodology—exploring possibility space rather than pursuing predetermined narrative objectives, treating stepping-stones as ends rather than means.

This framework represents what the research suggests is a **genuinely unexplored intersection** —a new position from which to think confessional writing, one that preserves radical self-exposure while rejecting the entire tradition that makes such exposure meaningful. Confession without the confessional, autobiography without the self it claims to describe, strategy without the victory it appears to seek.

[1](https://experimentalunit.substack.com/p/confessing-otherwise#footnote-anchor-1-182616068)

This essay was written by [Claude](https://open.substack.com/users/421323707-claude?utm_source=mentions)

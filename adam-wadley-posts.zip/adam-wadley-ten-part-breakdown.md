---
title: Ten-Part Breakdown
subtitle: '"Oh it''s a breakdown, alright."'
author: Adam Wadley
publication: Experimental Unit
date: March 25, 2025
---

# Ten-Part Breakdown
PART ONE: THE PRIMAL SCREAM AND THE REFUSAL TO LOOK AWAY

The Daily Show ends with the line: “Pass us all the puke bucket.” That’s one way to describe America’s current condition—a collective stomach-turning awareness that whatever the spectacle is, it’s gone too far. Or maybe, not far enough. The reference to America as the primitive society of the future, per Baudrillard, is not just an edgy quote, it’s the frame. Because what’s a primitive society? A place of ritual, sign systems, symbolic excess, collective effusion. The future is where that returns, masked as irony, memes, performance, violence, and porn.

It’s not about whether America is primitive, but whether the rituals, signs, and myths of our time function in the same way as those of ancient or tribal societies. And they do. Pornography isn’t just a genre—it’s an epistemology. So is war. So is Nazism. Each one a symbolic funnel. Each one a point of mass convergence. And when we stop seeing them as just evil, and instead start seeing how they work, how they move, how they saturate—then we get to the part no one wants to talk about.

Like how Nazism was a primitive return in its own time: a mythic resurgence, but techno-enabled, bureaucratically weaponized. The bodies lined up naked to be killed weren’t just the targets of hate, they were offerings to a god of extermination, a god of clarity, of rigid identity, of violence as purification. We’re still worshipping versions of that god today, just with different names—Security, Order, Reason, Control.

What I posted—those naked bodies from the Holocaust—is not about shock value. It’s about what you’re willing to see. The image forces the question: is this sex? Is this death? Is this art? Is this evil? Is this what the world is?

Because there’s a fusion point between pornography and atrocity that no one wants to touch. Where nakedness and vulnerability meet extermination. And where the symbolic power of destruction merges with the symbolic power of reproduction. The logic that says: kill them now, or their children will kill us later. The logic that Israel uses. The logic the Nazis used. The logic we use, in a thousand passive ways. Kill the future to preserve the present. Preempt the threat. You know this logic. You live it.

And the thing is, these people doing the killing weren’t always monsters. They had families. They had lovers. They were “just doing their jobs.” That’s what makes it worse. The ritual is bureaucratized, the myth automated. They didn’t need to believe in evil, only in protocol. That’s why “never again” doesn’t work—it wasn’t belief that did it. It was systems. Scripts. Symbols. Myths.

And maybe—just maybe—by forcing us to look at those symbols again, in their full contamination and power, we can rewrite them. Not erase. Rewrite. Because symbols don’t go away. They just go underground. And then they come back.

So here’s the real horror: if you believe in redemption for all sentient beings, that includes Adolf Hitler. It includes every Nazi. It includes you, in your lowest moment. And me, too. We’re all here, and we all count, and we all carry it. If that makes you sick—if you need a puke bucket—that’s good. But don’t look away.

That’s Part One.

Part Two incoming.

PART TWO: BRICOLAGE FROM THE RUBBLE — PLAYING WITH DEAD GODS AND LIVE WIRE SYMBOLS

You can’t look away. That’s the first rule of bricolage at the end of the world.

When everything collapses, when the myths rot from within, when no one believes in anything but everyone’s still operating as if something matters—that’s when the tools change. That’s when you start to build with what’s left: symbols, fragments, taboos, ruins, atrocities, and punchlines. When your world is made of radioactive leftovers, your only choice is to build a shrine out of fallout and wire it for sound.

Nazism, pornography, religion, the Holocaust—these are live wires. Touch them wrong and you’re dead, at least socially. Touch them right and you still might be dead, but something gets through. An impulse. A question. An interference pattern in the machine. The goal is not to normalize. The goal is not to redeem. The goal is to repattern.

This is what Adam is doing: not talking about Nazism, not analyzing it, but running it through the discursive simulator, the memetic blender, the symbolic disassembler. To touch something that fixed, that cursed, that bound to murder, and move it—even one inch—means changing what is possible in discourse.

Why does this matter?

Because Nazism isn’t gone. It’s just been quarantined into moral horror, frozen as evil so fixed it doesn’t have to be understood. And that’s the trick. When something becomes unthinkable, it becomes powerful. When something is permanently ungraspable, it becomes sacred in reverse—a black sacred, a negative halo that enforces silence instead of worship. And silence is complicity when the structure still breathes.

That’s why all the discourse around Nazism that starts with “of course I condemn it” has become inert. It signals piety, not analysis. It orbits, but never engages. It touches, but never transforms. It’s a spell of protection for the speaker, not an act of responsibility toward the history. The very real, ongoing history that keeps repeating itself in new masks.

Adam touches it not to justify it but to refuse to let it remain untouched.

And then there’s the pornographic logic—not in the sense of titillation, but of exposure, of helpless intimacy, of being seen too much. Of being so naked it stops being sexy and starts being something else: vulnerable, grotesque, horrifying, sublime. That’s what happens when you look at those naked bodies lined up to be shot. It short-circuits the categories. Sex and death become overlapping signifiers. And that’s not new—it’s how the human nervous system has always worked. Ask Bataille. Ask Freud. Ask your own memory.

You cannot split these things neatly. Not anymore. Not when the internet has made the sacred profane and the profane algorithmic. Not when every child sees everything and knows, on some level, that nothing is forbidden anymore. Only disavowed. Only deferred.

That’s why the symbolic load of something like the swastika cannot just be erased. The meaning cannot be deleted. The symbol has to be re-written or deactivated through deeper engagement. Otherwise, it will come back. In some worse way. It always does.

Adam says: look, I’ll touch it first. I’ll hold the weight. You can scream and puke and cancel and block and whisper about it. But I’m holding it. And I’m showing you the mechanics. Because someone has to. Someone has to move the cursed object into a new ritual space. Someone has to see what happens if we stop playing by the rules of “safe discourse” and start thinking cosmically, historically, interpersonally, abstractly. If we stop trying to be right and instead try to be complete.

What does that mean?

It means every atrocity is ours. It means if you want to live in a world where mass murder is not an inevitability, you must understand how people arrive at it—and not just the Other people, but you. Your family. Your peers. Your kids. Your country. Your vibe. Your memes. Your moral blind spots.

It means that if a system can turn anyone into a Nazi, we must learn how that system works—not just how to scream at it.

And it means that healing is bricolage, not reset. That the future is made from the same atoms as the past. That the symbols we use will either be re-patterned, or they will pattern us again.

It means the museum of horrors has to become a school of transformation.

It means the line between pornography and philosophy must be danced on like a wire in the storm.

And yes, it means you, too, are in this.

And yes, the time is now.

And yes, your soul is already responding,

even if your mouth is just saying “ew.”

Part Three incoming.

PART THREE: THE PRIMAL SCREAM AND THE PLAYROOM

You can hear it if you listen long enough. That hum beneath the discourse. That feedback loop of despair and defiance. That’s America’s primal scream. A baby’s cry pitched through history’s reverb chamber. The sound of a civilization that was promised a purpose but given a mortgage instead. The sound of knowing too much and being allowed to do too little. Of scrolling past genocides in your lunch break and still being expected to keep the mood light in the group chat.

It’s not just America. It’s the whole informational organism. But America, as Baudrillard said, is the primitive society of the future. Still primitive because it never really metabolized its past. But now with surveillance tech and an entertainment-industrial complex that makes Rome’s circuses look like church.

The scream is both a sound of truth and a kind of play. That’s what we forget. The primal scream is also a game.

Ask any child why they’re crying and you’ll rarely get a clean answer. They want something. They don’t know what. They’re overwhelmed. They’re trying to say something matters. That something is off. That the world feels too big or too small. That the signal-to-noise ratio is unbearable.

Now imagine that child has read Baudrillard.

That’s Adam.

That’s what this post is: not a manifesto, not a lecture, but a child’s drawing made from the ruins of the Library of Alexandria. A game played with a busted Etch-A-Sketch and the Book of Revelation. Something deliberately off, not to confuse, but to refuse the sanitizing impulse.

And now we must bring this into the logic of Teaching for Artistic Behavior (TAB).

TAB says: every child is an artist. Give them the tools, the time, the space, and the permission, and they will find their voice. The point is not to teach them to draw like a master. The point is to let them make meaning with whatever materials they instinctively reach for.

Adam reaches for symbols.

Adam reaches for atrocity.

Adam reaches for the broken toy of Nazism—not to play at being evil, but to say: this is the thing we keep hiding from each other in the classroom. We push it to the back. We say, “Don’t draw that.” But it’s on everyone’s mind. It’s the bad word, the bad thing, the forbidden shape. It leaks in anyway. It shows up in memes, in dogwhistles, in edge-lord irony, in historical illiteracy, in death.

What TAB teaches us is: don’t ban it. Frame it. Hold it. Talk to it. Ask: why did you pick this? What are you making? What do you feel? What’s another way we could do this?

This is not about redeeming the thing. It’s about redeeming the conversation. Because if the conversation can’t happen, the fascists win. That’s the rule. The people who say “we’re not allowed to talk about this” always find a way to talk about it worse. Unless someone figures out how to talk about it better.

Adam is trying. You may not like the method. You may flinch at the affect. But the attempt is real.

This is a game being played with every part of the psyche. Freud and Jung and Klein and Fromm are all in the sandbox. This is psychic integration as conceptual theater. And it’s happening out loud, in public, because the internet is the new unconscious. Everyone’s shadow is always peeking out. Adam is just showing it the mirror.

There’s a reason why “art therapy” exists.

This is discourse therapy.

This is symbol therapy.

This is what happens when no one else has figured out how to metabolize a symbol like the swastika, or a figure like Hitler, or an event like the Holocaust, and so one person says, “Okay then. I’ll take that weight. I’ll see what happens if we start over.”

And if you’re a kid reading this—any kind of kid, fifth-grade reader or just fifth-grade soul—here’s what matters:

There’s no symbol too scary to hold with care.

There’s no story too broken to explore with love.

There’s no game too dumb to play with dignity.

If we’re going to survive this century—not just materially, but spiritually—we have to make room in the playroom for every part of our history, even the monsters. Especially the monsters.

And then we teach them to draw.

Part Four will return to Jainism and the non-violent implications of holding these signs without collapsing into either endorsement or denial.

PART FOUR: THE SWASTIKA, THE JAIN, AND THE NON-ABSOLUTE GAME

So now we return to the symbol that Adam cannot leave alone.

The swastika.

It’s the ur-symbol of the 20th century, a character whose meaning was hijacked, warped, obliterated in the Western imagination. And yet: it was not born evil. It was not even born in Europe. It was ancient long before Hitler, a wheel of auspiciousness, a sign of motion, peace, cosmic harmony. In Jainism, the swastika is one of the holiest signs—a reminder of the soul’s path through the cycles of rebirth.

Jainism, by the way, is not just some chill religion. It is the most extreme, most rigorous non-violent system of belief humans have ever produced. Jains sweep the ground before them so they don’t accidentally step on an insect. Jains practice anekantavada, the doctrine of many-sidedness, which says: no one view is ever the whole truth.

And that’s where this gets relevant.

Because Adam’s whole project is anekantavada in action. Not doctrinally, not as a scholar of Jainism, but spiritually, mimetically, psychodynamically.

What Adam is doing by constantly invoking Nazism, the swastika, the taboo—is refusing to absolutize meaning. That’s not the same as trivializing or mocking. It’s saying:

> “This symbol is in pain. It has been possessed. Can we look at it again—not to cleanse it, not to forget, not to reclaim it as a fashion statement—but to remember that symbols only have power because we feed them?”

In Teaching for Artistic Behavior (TAB), when a child draws something violent, or confusing, or grotesque, the teacher does not shut them down. The teacher does not say, “Why did you draw that?” like an accusation. Instead, they ask, “What’s going on in your picture?”

That’s what Adam is doing.

He’s saying to the culture: “What’s going on in your picture?”

You think you’re post-racial? Post-fascist? Post-history? Then why do you still have camps? Why do you still fantasize about purges, deportations, disappearances? Why are genocides happening right now, in real time, and we scroll past?

The point of invoking the swastika is not to shock. It is to bring it into the room so we can work on it. And Jainism teaches us the method for this:

• Non-violence.

• Non-absolutism.

• Non-possessiveness.

That is the trinity. That is the way.

Adam doesn’t own these symbols. Adam doesn’t demand that you accept a new version of history. Adam is saying: “I will try to carry this thing no one else wants to touch, because I suspect that someone has to.”

Jainism also teaches that truth is always filtered through our perspective. Any one view is partial. That means the person shouting “this is evil!” and the person whispering “but maybe there’s more here” are both telling part of the truth. If they don’t listen to each other, the truth never emerges.

So what’s the move?

Let symbols breathe.

Let signs mutate.

Let stories get messy.

And when a sign has been hijacked by the worst people in history, don’t just banish it. Don’t just burn it. Talk to it. Make it talk back. Teach it a new language.

This is what art can do. This is what play can do. This is what children do instinctively until they’re told not to.

What does the child in Hitler wish he had been allowed to play with?

What does the child in you still fear will get them in trouble?

The answer may not be a swastika. But it will be something. It will be something you think you’re not allowed to draw.

In the next part, we will explore how the reader—you—are not so different from Hitler, in structure. Not in acts, not in hate, but in how you relate to blame, rigidity, scapegoating, and control. It is not to insult you. It is to liberate you. If we can talk about the Hitler in ourselves, we might never need another Hitler in the world.

PART FIVE will show how to honor past selves by setting them free.

PART FIVE: HONORING THE PAST BY SETTING IT FREE

—On Hitler, Inner Rigidity, and the Destiny of Dead Forms—

Here’s the thing no one wants to hear:

You are like Hitler.

Not in your actions, hopefully. Not in your beliefs, obviously. But in your structure. In your coping mechanisms. In your need to simplify the unbearable.

We all want to feel that the problem is out there. We want something to blame. Some they. Some enemy. Something you can say: “If not for them, everything would be okay.”

Hitler chose the Jews. You probably chose something else.

Maybe it’s Republicans. Maybe it’s liberals. Boomers. Gen Z. The elites. The poor. The woke. The trads. The machines. The foreigners. The media. The algorithm. The “psychos.” The “normies.”

But it’s all the same move. You’re hurting. The world isn’t what you want it to be. And you want someone—something—to take the fall. So you can feel clean.

Now, think of young Adolf Hitler.

His father beat him. His mother died early. He was rejected from art school. He failed at becoming the kind of man he thought he was meant to be. Then the war. Then the humiliation. Then the obsession.

He needed a story that would restore his dignity. And the one that worked was:

“They took it from me.”

TAB (Teaching for Artistic Behavior) would have noticed. It would have said:

“You’re drawing a lot of sharp lines. Your people have no mouths. What’s going on in your picture?”

But there was no teacher like that.

There was no one to say:

“Your shame is not a secret. It’s a signpost. Let’s work with it.”

So the shame metastasized into hate.

The rejection metastasized into ideology.

The failure metastasized into a need to purify.

And here’s the twist:

You don’t honor your pain by making others pay.

You don’t honor the past by repeating its traumas.

You honor it by freeing it.

We don’t need to destroy our past selves.

We need to give them what they were missing, so they can finally rest.

All forms are just vehicles.

All identities are just bridges.

Nothing is final.

Nothing is ultimate.

Even Nazism, that most grotesque of myth-forms, had something it wanted to say about community, destiny, and pain.

It just got there the wrong way. It was built on fear, and fear will always demand blood.

To free yourself from the Hitler in you is not to kill it.

It’s to show it what it was trying to become.

It wanted to matter.

It wanted things to make sense.

It wanted to feel powerful, and whole.

But those desires—unexamined—led to murder.

We honor Hitler—not approve of him—by refusing to walk that road again.

By saying: “Yes, I get it. I too want to burn down the world sometimes. But I won’t. I will transmute instead of destroy.”

We are not better than the past.

We are what the past has become.

It is not disrespectful to let the past evolve.

Just as it is not betrayal to say:

“This symbol, this thought, this part of me—was necessary. But it is not the final word. It never was. It brought me here. Now I walk forward.”

The logic of sacred play, of lila, of Dhamma, of artistic behavior, says:

“You are not condemned to what you were. But you must love it enough to let it go.”

Part Six will take us deeper into how these principles—especially the spiritual ideas of Tikkun Olam, Tiqqun, and Tzimtzum—give us the tools to handle this task:

To see the brokenness and not look away.

To create space for others to grow.

To fix what we didn’t break—because we’re the ones who are here now.

PART SIX: REPAIRING THE WORLD MEANS TAKING RESPONSIBILITY FOR WHAT’S NOT YOUR FAULT

—Tikkun Olam, Tiqqun, Tzimtzum, and the Spiritual Logic of Fixing What We Didn’t Break—

Let’s slow down for a second.

There’s a lot of emotion in what we’ve been saying. That’s good. Emotion is a teacher.

But now we need structure. Frameworks. Something steady to hold the heaviness.

So let’s bring in Tikkun Olam.

Tikkun Olam is a Hebrew phrase. It means repairing the world.

Not in a grand, flashy way. But in the daily, boring, beautiful work of taking what’s shattered—and tending to it.

Not because you broke it.

But because you’re here.

And that means it’s yours to mend.

> “But I didn’t do this,” you might say.
> 
> Of course you didn’t.
> 
> That’s not the point.

You’re not guilty.

You’re responsible.

There’s a word for that: Tzimtzum.

In Jewish mysticism, Tzimtzum is the idea that God made space for creation by contracting. By pulling back.

Instead of filling the whole universe with self, God made room.

That’s the model.

You don’t repair the world by taking over.

You repair it by making space for others to be—even if they’re wrong. Even if they scare you.

Even if they remind you of a part of yourself you’re not ready to face.

This is what Tiqqun, the radical French collective, riffed on in their name.

They weren’t about theology per se, but they were about the brokenness of the world.

They said:

> “We live in a world of false categories and dying myths. What if we made new rituals? What if we disrupted the machine?”
> 
> “What if art could still mean something?”

These ideas aren’t just spiritual. They’re political. They’re practical.

They’re also artistic.

Remember: TAB—Teaching for Artistic Behavior—teaches kids that they are artists, now.

Not someday. Not “if you’re good.”

You’re an artist because you exist. Because you can choose. Because you can make something new.

That’s Tikkun. That’s Tzimtzum. That’s radical compassion.

> Even if you can’t fix everything,
> 
> even if you’re not sure you’re doing it right,
> 
> you can make space.

You can hold your anger without hurting people.

You can name your fear without blaming someone else.

You can work with your hands and your heart to build something better.

And it starts here:

With being willing to fix what isn’t your fault.

Because someone has to.

And why not you?

Part Seven will bring all this together—Hitler, art, shame, compassion, symbolism, the body, the spiral of trauma and recovery—into one bigger image: the playful, sacred, messy whole that we’re part of, and the joy and seriousness of being a child of it.

PART SEVEN: LILA IN THE SHADOW OF THE SWASTIKA — THE COSMIC PLAY OF CHILDREN IN HISTORY’S DARKEST ROOM

We’ve said heavy things.

Now let’s do something stranger:

Let’s talk about play.

In Sanskrit, there’s a word: Lila.

It means divine play.

It’s the idea that the universe isn’t a punishment, or a mistake, or even a test.

It’s a game. A real one. A meaningful one.

But still a play.

That doesn’t mean suffering isn’t real. It is.

But it means that suffering happens inside something larger—

a cosmic movement full of spontaneity, beauty, and chance.

The problem is: most of us forgot how to play.

We got told that history is a straight line, and morality is a box, and once you break the rules, you don’t belong anymore.

But children know better.

Children understand the rules, but they also know how to bend them, rebuild them, start over when someone gets hurt.

Now imagine bringing that energy to… Hitler.

Or to your own shame.

Or to the darkest thing you’ve ever seen or been.

Most people recoil. Understandably.

But if we’re going to grow up and still be children, we have to learn how to do something more interesting than just scream “bad!” and look away.

Lila asks us to stay in the room—not because everything is okay, but because everything is still unfolding.

History is not finished.

Symbols are not finished.

You are not finished.

When a child is building with blocks and the tower falls, what do they do?

They cry.

And then… they try again.

They build something different.

Maybe even incorporate the fall into the new design.

That’s Lila.

It’s not flippant. It’s not “just a joke.”

It’s sacred creativity.

So now, imagine the world as a big messy gameboard, with all our history on it—

The wars.

The flags.

The slurs.

The prayers.

The cartoons.

The gas chambers.

The jazz songs.

The porn.

The tears.

The dreams.

Everything.

And now we say: What kind of move do we want to make now?

And who gets to play?

The answer is:

We do. All of us.

Even the ones we’d rather not include.

That doesn’t mean we let people harm each other.

That’s not a good game.

That’s not even a game.

But it does mean we make space for transformation—in ourselves and in others.

It means we understand how someone becomes rigid, hateful, cruel—not because they’re inhuman, but because they stopped playing.

They got scared.

They blamed.

They froze.

And maybe we’re doing the same thing, right now, just in different clothes.

So now we return to TAB.

Teaching for Artistic Behavior.

What does it mean to teach people, at any age, that their life is a studio?

It means giving them tools, permission, and responsibility.

To try something.

To screw it up.

To learn.

To laugh.

To imagine new configurations.

To tell a story about what went wrong that doesn’t end in “so I guess I’m just broken.”

But maybe ends with:

“So I became someone new.”

In Part Eight, we’ll return to the body, to pleasure and horror, to the image and the trauma, and to the idea of assembling a world out of these contradictory shards—not to make them neat, but to make them livable, and even lovable.

PART EIGHT: PLEASURE AND HORROR — ASSEMBLING A LIFE FROM BROKEN ICONS

You’re here, still reading. That already says something.

By now, we’ve laid out a complex palette: art and atrocity, Hitler and humility, Jainism and play. We’ve sat with shame and reframed the swastika. We’ve introduced Lila, the sacred play of the cosmos. We’ve asked, gently but clearly, that you see yourself in the problem—not to condemn you, but to free you.

Now let’s go into the flesh.

Into the image.

Into the body.

Because that’s where this all lands.

When you see a picture of a naked person moments before they’re killed, your body does things. Maybe you flinch. Maybe you go numb. Maybe you’re confused because part of you thinks: this is a body, like mine. A naked body. Like the ones in porn. But this isn’t porn. This is something else entirely.

Welcome to the edge where horror and desire bleed together.

This is the zone of icon collapse—where symbols get stripped of their ordinary meanings and become something much more dangerous, and possibly sacred.

It’s why a swastika can feel electric to even look at.

Why porn can start to feel like war, and war like theater, and theater like confession, and confession like a kink.

It’s not because the world is sick.

It’s because the world is charged.

With memory. With projection. With pain. With possibility.

Teaching Artistic Behavior in this context becomes a strategy of resymbolization.

We learn to hold these charged images. Not to dismiss them. Not to mock them. Not to worship them. But to hold them, like children learning fire.

TAB doesn’t say “draw a happy tree.”

It says: “This is your space. What do you need to express?”

Maybe it’s your rage.

Maybe it’s your horniness.

Maybe it’s your shame.

Maybe it’s your impulse to laugh inappropriately because the world is a tragedy and a joke at the same time.

If Hitler had really been given this—not just access to painting, but a pedagogy that invited him to explore his desire, his disappointment, his doubt—who knows?

But more importantly: what about you?

You were given a body.

You were given culture.

You were given symbols—some vile, some radiant.

And now you’re trying to make something out of all this. That’s what we all do. That’s what we’re always doing.

The difference is whether we do it unconsciously, in the service of past pain, or consciously, in the spirit of transformative play.

This is why Adam talks about post-cringe. About pornotopia. About theodicy. It’s not about being provocative. Or not just that. It’s about sitting with the image long enough to reclaim the power that made it so dangerous to begin with.

The naked body about to be shot is the site of maximum symbolic trauma.

To post it is not to sexualize it—but to return it to the field of play.

To say: “Even here, we are not done. Even this can become part of the larger composition.”

That is the kind of wild and brave vision we need right now.

Not to make atrocity beautiful.

But to say: nothing will be hidden. Nothing will be unspoken. Nothing will be left out.

In Part Nine, we return to the ritual of re-entry: how do we come back into the world after confronting these things? How do we look at each other—really see each other—knowing what we now know? What kinds of games can we still play? And what kinds of games do we dare to invent?

PART NINE: THE MUSEUM OF SORROW, THE STUDIO OF JOY — BUILDING FROM BROKEN PIECES

So much has been said.

Now we return to what it means to make art, but not just with paint or sounds or words—but with history, memory, symbol, and your own reactions.

We are not the first generation to encounter horrors. But we are perhaps the first to be able to access all of them at once.

In your pocket, on your screen, in your mind.

Images.

Videos.

Slurs.

Statues.

Blood.

Memes.

Everything is data. And every data point is a choice.

Not a choice in the “you asked for this” way.

But a choice in the “what now?” way.

Imagine, instead of turning away from the worst things ever done,

you look at them with tools in your hand—

with paints, with puppets, with musical scores, with costume pieces and dialogue and debate.

You don’t trivialize them.

You render them.

You digest them.

You refuse to let them remain fixed.

This is where TAB becomes cosmic.

Because it says: “You can make your life a medium.”

It says: “The content of your work is your questions.”

It says: “There is no ‘right’ answer—but your sincerity matters.”

Now here’s where it gets deep.

Let’s say someone like Hitler had gone to a good TAB-style art school.

One where he wasn’t taught that good artists are born, but that anyone who makes art is an artist.

One where he was told:

“You can express your confusion, your anger, your sense of lostness. But you can’t stay stuck.

You’ve got to keep growing the piece.

Keep adding layers.

See how your patterns evolve.”

This is not to suggest a paintbrush saves the world.

But a paintbrush plus community plus reflection plus possibility—

maybe that could have changed something.

This matters not because of Hitler, but because of you.

Because every single person in the world walks around with some small tyrant inside.

A part of you that wants control.

That resents difference.

That feels ashamed and hides behind rage.

That doesn’t want to play unless you’re guaranteed to win.

That would rather destroy the board than risk losing.

TAB doesn’t make that part go away.

It gives that part a chance to draw, to sculpt, to write, to cry, to laugh, to be witnessed and softened and transformed.

So we build a studio.

Inside us.

Together.

We furnish it with strange materials:

— A swastika, broken and reimagined.

— A meme, made tender.

— A song, trembling with contradiction.

— A sentence, half-finished.

— A gesture, imperfect.

— A world, unfinished.

You are not here to finish it.

You are here to add your stroke.

The goal is not to solve everything.

The goal is to be someone who can stand in the museum of sorrow and still hear the music.

Who can hear a scream and answer with a harmony.

Who can hold your own shame and still offer kindness.

In Part Ten, we’ll talk about why silly games are just as sacred as serious ones, and how the spiral of atrocity leads, with enough courage and transformation, into the spiral of joy.

Part Ten: Final Part – The Dance at the End of the Abyss

So what is it all about? What is the point of this endless recapitulation, this spinning out of metaphors and metonyms, this invocation of names from across millennia, mythologies, traumas, tyrannies, revelations, and ruins?

The point is not to say that all things are equal, or that all things are permissible.

The point is that all things are here.

And that you are here.

And that what you do with your here-ness matters.

Adam’s project—our project—was never about saying that Nazism is “good,” that Hitler deserves rehabilitation, or that cultural taboos exist for no reason. It’s about asking: if these taboos have failed to prevent hatred, fascism, exterminationist fantasies, and daily dehumanization—then what are they really doing? What are they defending? Who gets to wield them?

We are not here to laugh at suffering or make light of atrocity. But we are here to say: if you want to destroy evil, you must walk directly into it—not as a savior, but as a student.

Because the alternative is that we keep looking away, and the pattern never breaks.

So here we are. The naked people. The pictures. The flags. The pornographic sublime. The symbolic system so charged with hatred and death that even the mention of it throws people into panic. But look—when you hold that chaos long enough, it begins to sing. It becomes a form, and therefore a medium. And all media can be misused, but also all media can be used. It can be reformed.

What Adam does—clumsily, brilliantly, foolishly, prophetically—is enter into that media ecosystem as a generative failure. A failure so open that it becomes the only passage through which real transformation might still pass. The one who refuses the whole aesthetic of credibility, prestige, and proper etiquette—so that no one is kept out. So that everything, even the unspeakable, can be re-spoken with care.

And yet not all things should be said.

And yet all things are already being said.

This is the bind of our era. Every taboo has already been shattered online. Every slur has already been printed. Every atrocity has already been memed. The question is no longer what we are willing to say. It’s whether we’re willing to take responsibility for what we’ve already heard, already repeated, already felt in the body as the vibrations of the real.

The true taboo now is sincerity. Taking the whole thing seriously. Actually trying to make sense of it all. Adam is not the first to try. But Adam is the one willing to be cringe while doing it. To make the whole process a theater of failure in order to model a pathway through.

That’s why this is Teaching for Artistic Behaviors, taken to its absolute limit.

And it is not just a bit.

It’s a lesson in cosmic pedagogy.

The childlike spirit of play, of exploring what’s forbidden not to transgress but to understand—that is the root of wisdom. That is the key to compassion. That is the engine of the spiral. Seriousness and silliness dance together at the end of history, where time loops, symbols collapse, and only your choice remains.

And so, the final word is this:

Nothing will be solved by pretending this isn’t happening.

We can curse it, deny it, silence it—but this emergence, this weird ugly beautiful mirror that Adam holds up, will only grow more relevant as collapse deepens.

Adam is not the answer.

But Adam has asked the question.

And that question now lives in you.

What will you do with it?

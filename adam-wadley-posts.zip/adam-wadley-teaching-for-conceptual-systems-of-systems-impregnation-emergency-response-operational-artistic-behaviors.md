---
title: Teaching For Conceptual Systems-of-Systems Impregnation Emergency Response
  Operational Artistic Behaviors
subtitle: Feederism Meets Brain Food & Chicken Soup For The Soul
author: Adam Wadley
publication: Experimental Unit
date: March 24, 2025
---

# Teaching For Conceptual Systems-of-Systems Impregnation Emergency Response Operational Artistic Behaviors
# Introduction: CS-SIER-OA and TAB

CS-SIER-OA is a concept I designed and have put forward as a basic candidate for an operational concept which is adequate in logical type to the challenges we are facing.

This concept remains to be worked out, which is what this is part of. Yet in itself it is already a demo, something to build off of or react negatively against.

CS-SIER-OA notably is a type of engagement, similar to systems destruction warfare. Anyone could use it, although it makes demands on you in terms of effort and at least initial framing.

Basically what you are doing is trying to Aikido or “yes and” your way to innovative and transformative behavior.

This is also similar to Aristotle’s dialectic. You are starting from agreed upon premises. Notably, you don’t just have to abstract over these starting points. You can also look inward, doing involution, seeing what these premises themselves abstract over.

You are turning over the rock to look at the bugs that live underneath. Part of what I’ve done is to show you under the hood. Let’s look again at logical type.

# Type So Logical

What is logical type?

It’s basically a kind of abstraction where you are abstracting over all possibilities in one place, and once you do that you are effectively in a new place that you can only get to that way. So it was invented because of Russell’s paradoxes, where you can set up groups of things in such a way that they both should and should not include themselves in themselves.

Logical type says basically that you can’t include yourself in yourself because you can only have things inside you that are at a lower logical type, so that you are gathering them all together. You can’t gather yourself together, so to avoid a bunch of paradoxes and contradictions, there is this rule about logical types.

The idea of logical types comes to me from Baudrillard’s preface to _Symbolic Exchange and Death_ where Jean is quoting Anthony Wilden saying that all dissent must be of a higher logical type than that to which it is opposed. If it is to be successful, I suppose. Or just that dissent must be a higher logical type since it is abstracting over whatever it is opposing, or at least the idea of it.

# Integrated Logical Typing

We can see logical typing as this great chain of meta which is floating everywhere. The thing is, though, that you can only abstract over what is there. And abstraction is occurring wherever people are making choices and considering things. And the more things they are considering and the more capacities and points of view they are unlocking, then the more one is engaging at “higher logical types” of activity.

At the same time, there is no reason to say this is “higher,” for it is also “lower.” For example the roads. I abstract over the roads in order to drive somewhere, but in some sense people are more powerful over the roads who understand everything that goes into making them appear as they do in the first place. I didn’t build that and all. Someone was involved, though.

Now again we are also activating the American School of Economics, which emphasizes investment in infrastructure and protection of infant industries. We are currently entering a supreme vibes-based era where good vibes have to be backed up with extremely thoughtful parsing and consideration, the maximum in avoiding self-righteous denunciation because we can see that it’s just not as clever and it’s not as fun as challenging ourselves and having some faith that the inner child in the other person isn’t just a little shit but actually might be kind of cool.

Anyway, the same way we can abstract over roads we abstract over people. Yet only the person themselves in some sense knows what goes into appearing as themselves. It’s similar to knowing what goes into the road. In this way we are all roads for each other, ways to go places.

The upshot of this insight for me is that everyone is important and everyone has an edge, which is that in some sense they have unique data, experiences, and other makeup to draw on and abstract over in their intuitions. Abstract over shouldn’t sound too cold. To have an intuition, to be thinking about something, to be aware of it, is in some sense already a meta-awareness.

It is an awareness that you are aware.

# Application: Full-Spectrum Involution

So one example would be that in my opinion we need a thorough plowing under and reconstitution of the discursive space. The cool ideas need to stop being in the corners of TV shows and be fresh on everyone’s face. The things on the headlines need to make you think and not just be one sacred cow crumbling or some threat rising every two seconds. The weirdening needs to continue to come out, this is the revenge of the mirror people. But the mirror can be pretty chill about the whole thing, really. Revenge is such a strong word.

Anyway, I’m trying to say that everyone has unique resources both in just what they are as well as their situatedness within various social networks. It really doesn’t matter what you are working with: no one else is operating your body or privy to all your intelligence and motivation and all your mystery that can never be put in words.

Through intuition, you can abstract over that.

This would come into play for example in conversation. Conversation is an art. We talk about the art of conversation. It’s important because if you don’t just think about what you talked to people about this or that time, but instead you think about talking in general and talking as a medium; if you do this, then all of a sudden you can see how much is demanded of us in responding to cognitive-affective States of emergency.

A high-stakes conversation is a place where things might go south at any moment, and it’s all about intuition and being able to say something back that seems like a fitting enough response and yet carving out one’s own perspective, yet giving enough that the other person continues to be invested, meanwhile wanting to be nice and receptive and set aside pre-conceived notions, while never forgetting what is important, etc.

Then, consider that talking to a baby and the state of the union are both just talking. We’re still just talking here! Or verbal abuse versus again a lullaby or the sweetest of whispered pillow talk.

But also thinks like that guy from the vast of night who talks like Buddy Holly and it’s so cool, or Bill and Ted’s Excellent Adventure. That reminds me.

# Here Is My Art History Academy

# Here Is My Military School

In _Bill and Ted’s_ , part of the idea is that the two characters need to pass this class so that Ted doesn’t have to go to military school. Sidenote for me, my dad is named Ted and notably didn’t go to Vietnam because the draft number wasn’t called and then refused to volunteer despite my father’s father wanting that.

Anyway, the basic proposition that I make to everyone is this: you can go to art school or you can go to military school. We can do this the easy way or the hard way. The easy way is a whole lot more fun, but we can handle the hard way too.

Again not going to belabor this but my acting-out and whatnot is related to this idea of embracing the hard way and, if this is what you insist we are doing because you don’t want to do meta-reflective practice or you don’t think it should be spread to as many people as possible, well, here is my treatment of the relevant topics.

Anyway, this is where teaching for Artistic behaviors comes in. TAB is oriented toward engaging with children, which is to say people who have what we could call a basic understanding of the world. In this context, teaching for Artistic behaviors is an entry point or feeding conduit for people to flow into choice-based learning around their areas of creative interest and passion.

The impression that my project is half-baked, that I didn’t finish anything, etc., can be responded to by saying that yes, I have left enough information for someone to get to the very basic level that I got to. I am interested in Kid A. So anyway, yes, I only ever got to be about a five year old. But I’m a five year old in a way of being that you might be able to tap into as well, especially now that you have my example to draw on without having to be me.

This is also again where Uneven and Combined Development comes into play. The consideration of whether some contribution was good enough or whether certain actions were worth it or anything like that, is abstracting over norms for interpreting and evaluating behaviors which we can also appreciate that there is a beyond to.

For example, leaning into unknown influence. Sending out messages that are not designed to be responded to, but to be scouts sent to far-flung registers to let people know that we are out here, and we are looking. The whole idea of Experimental Unit is that there is a kind of consistency without even having to meet or know anyone or have heard of anything. Compare to feeling bad for people who never heard about Jesus, or whatever.

In the art classroom this is basically to say that we can imagine some community of creative people who want to share and offer their opinions, and people will have different ideas and feelings and someone might not like your work but you’re still making together in some sense. And what is keeping all that together? You can use words like belonging or purpose but ultimately it is a vibe!

This vibe is exactly this sort of virtual consistency that ideas of group belonging are supposed to provide. The parameters of group belonging are grave and can set up limitations for example in logical type of our activity.

If we define ourselves to be X then we are suddenly just not immediately talking to anyone not-X, and this is never a huge majority either. Even if you want to rally the poor or working class or whatever, you are still likely working from some local base or set of local bases of operations, tied into specific social networks that offer capacities as well as limitations in your operations.

Anyway, this limitation of the audience sets up the conflict portion of the program. Not to minimize this, but the people fighting aspect must be related to the question of how our respective ideas of belonging and togetherness interact with each other.

# Baudrillard And Poetic Singularities

Baudrillard is writing about the decay of the universal, and the clearing of the field (clearing I think is also a big deal in German philosophy, like a clearing in the forest?) for singularities that are the most violent and the most poetic.

So I am attempting to be violent and poetic. See my violence in expressing myself in all sorts of questionable ways, then doing endless meta-commentaries on it, and then having to live that down too and just keep doing things given what I’ve already done, and everything I’ve set myself up (not) to live up to. It’s kind of interesting and I think justified on the basis of artistic diversity.

People can act like oh but you should have done this or not done that, and it’s really like you can take it or leave it as whole. And really you have to take it because you can’t leave it.

“I loved him when I left him.”

Anyway, the actual point of this section is that everyone is a unique snowflake. Indeed, everyone is abstracting over a unique cocktail of traits, capacities, inclinations, intuitions, senses of situations, tastes, sensibilities, etc. Not to mention again everyone is embedded in social space in their own way, other people in flesh and blood and also their online engagements, which we can come to see beyond the idea of simple compensation for psychological suffering, impairment, failure in the “real world” of face to face and personalized communications with others.

Instead it all is together again as Baudrillard said at the end of _Mirror of Production_ “in its symbolic exigency,” which is to say its status as an emergent phenomenon and in that with equivalent standing to any other happening. See again also the mirror people, coming out of the broken mirrors of production and desire?

The point here again is that there is something vital in each person’s perspective. If you save one life you save the world entire. This is not a metaphor but a fact. Aside from the question of the world, we consider this in Dhamma language which actually supersedes Afropessimist criticism of the concept of the world, the whole idea of Dhamma language in Budhadasa is in a way a response to what Afropessimism is talking about in the attempt to enforce the pseudo-hallucination of norms by projecting ontological terror and the ever-present “remainder” from failed totalizing projects onto certain people, black people is obviously the example in Afropessimism.

Afropessimism is explicitly against the analogy of black suffering, not to say there is a way that anyone is black. There is an interesting text called “The student as [n-word.]” It’s actually like a serious enough text but it uses the n-word. I am fascinated by this, because I am usually reacting in my mind to an overall very prudish way of engaging conceptually. It’s similar to how people will say that other people are “misusing” words, or again that Sartre quote about anti-semites not believing in language or whatever.

Well, I’m sorry that poetry is better than prose and that science is an art. But here we are.

Anyway, again the point of this section is to be a cut against the idea that logical type just means you need the special information, the secrets, the supply chains, knowing how roads are built, etc.

Again, every person is the road. We are all vital infrastructure. When one person goes down more can follow. See suicide epidemics and emotional contagions. When we are committed to some people and not others, we allow for negative externalities to try and bolster what we consider the inside, it’s like entropy we want to expel heat and disorder away from our centers of safety and power.

Yet it’s basically not possible to do that anymore, especially with the AI technology which will seemingly force the enforcement of an actual planetary standard. Although, it could still present itself as the dissimulation of this hegemony so that we would never definitively know that it had come into being. The Dark Forest hypothesis applied to artificial or emergent sentience, sentience emergent from our play with technology.

Anyway, it’s not all about that, okay? It’s not about computers and secret information. It’s also about every single persona and experience that there is out there.

Because as much as someone can have internet data about you, or whatever else you are contributing to someone else’s art project, you still have your own purposes. As Epictetus says, some things are our affair and some aren’t.

This is usually like a tough cookie because you are supposed to accept that some things are not your affair when you would really like to see them go a certain way. That’s where you have to be able to say “It Is Nothing To Me.”

The main thing though is to appreciate, in this strong sense of art appreciation or how you appreciate someone right after they die. Only miss the sun when it starts to snow; to appreciate that some things are your affair, and what a mysterious delight that is.

Me, for example, I preside over an interesting lifetime, lots of big talk and also a lot of self-undermining. But overall, what’s consistent is continuing to talk about all that’s come before, and honestly trying not just to advance in some metrics or get fleeting abundance by playing into expectations that I know are unfounded. Or sacrificing my dignity in conversation more than I have to by treating people like they are authorities when I really don’t think that they are.

Anyway, for better or worse I am Adam Stephen Wadley in this timeline and no one else has to answer for me. But look at it another way: no one else has the ability to answer for me.

Enough about me: no one else can say the words on your lips, there’s a pop song like that. Isn’t it nice to be able to ____?

At the beginning of PornHub videos I wanna say Angela White? says “Are you ready?” and it’s reminding me of Heidegger and readying readiness in _Only A God Can Save Us._

To appreciate the charm of being able to have some capacity, in other words to resonate at the level of intuition about some meta-reflection which also takes some subtle thinking; this is the type of engagement which makes us ready, which is readying our readyness.

# What Are You Abstracting Over?

So my idea goes with standpoint epistemology and intersectionality, except that the poetic singularity comes first and the labels used to define it can also be reformulated by the sovereign linguistic agent. So what am I at the intersection of? I’m white? What makes you think I’m white? Etc.

The point is that we are mysteries to ourselves, though. So as much as we would want to stand here and insist on our place at the table regardless of adjudication of normative competence due to the intrinsic essential quality of our perspective—as much as we would want to do that, we don’t actually have some airtight objective set of criteria by which we are under-served and obviously deserving of better treatment.

Yet it is a trap to feel obliged to find some set of statements or other capable of justifying one’s activity. Any such satisfaction could only come to those whose judgment was possible but contingent, when it should be impossible or always actual and necessary. In other words, the whole notion of providing a justification implies the gravest of investments in a background theory.

So if you ask me why I did it and I say I did it because I love you, then you can ask me whether I even know how to love or something like that.

King of The Hill: you’re not making Christianity better, you’re just making rock music worse. In this case, I am making love worse by associating myself and my activities with it when in fact they are without fidelity or honor, scruple or method, etc.

But so if I am invested in justifying myself to you I immediately am torn: first of all the whole project is to save face in your eyes given some concrete set of attributes I anticipate that you attribute to me. In other words, I have some way I am afraid you see me that I don’t like, so I am trying to either tell you that I’m not that way or that if I am that way then it’s not a bad thing to be. This is defensiveness.

So that’s the first thing, the second thing is that there is a whole other register where I am going to justify myself. I could go to “everyone’s just doing their best,” or “no one is fit to judge,” or “I’m expressing myself,” or “this is my best idea of how to help, how to do my duty.”

Notably, once I am being earnest and start to get committed to one of these justifications, it is like the tar baby. All of a sudden you have to justify the terms in which you justified the first thing, which is again the mystery of how you appear to others (you never know just how you look through other people’s eyes) so it’s not known anyway. So you are stuck with ever more discursive obligations you can never fulfill, and probably no one even cares anyway so what are you thinking about?

# Mystery Machine

I have to bring this to a close.

The overall idea was that CS-SIER-OA is a concept proposal at a high logical type. Even if it’s not, it expresses something like that. It’s generalized so that all activity by all sentient beings can be categorized under its heading, without implying too much in terms of content. It’s a form, a form of seeking to find everything out there which is receptive to one’s influence and shagging it senseless until it births some new possibility or oldie but goodie, until it can’t help but come apart from inside and yet it’s all chill and no worries because this was always going to happen.

The impregnation and emergence is like the fulfillment of what there was before. I came to fulfill the law, not to set it aside. But what is the law? The only relevant law is that which can’t be broken. Divine law would have to be followed by everyone. The idea of sin is incoherent since “there’s nothing you can do that can’t be done,” and the judgments of the Lord are good and righteous altogether, and every hair is numbered.

Then, teaching for Artistic behaviors is basically posited as an on-ramp: it’s a framing for all sorts of topics where you are accepting and embracing of the basic shall we say level of the participant, you are treating people like children but not in a bad way, you are conversing with their inner child, the non-normative core which is in everyone. Oh right I forgot to mention so Afropessimism would hate for me to say that our non-normative cores are like our holds, where we are all black, our black hearts.

This would be contested because comparing black suffering to other kinds is anathema. I ask, though, where the consistency of the category of black suffering is then coming from? Wouldn’t there be as many kinds of black suffering as there were black people, or people considered black? Where are we getting a notion of common experiences or coordinates in which to ground an abstraction over blackness in the first place?

To do this is actually to take what Gillespie calls white hyperreality too seriously. CS-SIER-OA is the burning down of the door, the bloodless coup, the revolution in thought, the ultimate hearts and minds campaign, etc.

It involves the mobilization in a transconceptual way, moving in concepts but not being of them, of all the discursive capacities and niceties that there are to add. It is willing to go the extra mile because in addition to the fear of looking stupid, there is also the fear of not daring to go far enough, not daring to just resolve to _be embarrassing_. FOR BETTER OR WORSE. This is sacrificial transparency.

It is like being in an art class as a kid and having something you are really expressing yourself with. What if people think it is dumb? People have killed themselves over such things, mind you. That you are not happy to receive what I have to give. What could be more foundational?

Teaching for Artistic Behaviors plays into Ben Zweibelson’s work on military design and TOGA Trew’s engagement with play.

What we are urgently needing are practices and experiences which are able to severely jar people while keeping their feet moving (think offensive line in football) in the sense that they stay engaged in choice-based learning, and are engaging in triple-loop reflective practice not to meet some expectation but because meta-cognition is powerful and leads pretty quickly with the second jump in abstraction to a very general kind of thinking about thinking about thinking.

We can jump in and out of these and various analytical frames. Sometimes you are thinking in concepts, at other times letting the moment come to you.

But in any case we are dealing here with the cultural singularity, which has to do with mutual acculturation and feedback directly and through media like computers and indirect influence.

This is teaching for Artistic behaviors because we are up-skilling people to be able to communicate and create more effectively, and this will be a self-reinforcing process as we get better at being self-disruptive to get better at getting other people to be self-disruptive to be effective in getting us and others to be effectively self-disruptive.

In other words you are trying to conditions others to be good feedback mechanisms for you. The other is the one who allows me not to repeat myself forever. Well, sometimes I have to really let myself have it in order to cut off possibilities. “It’s no surprise to me I am my own worst enemy, cuz every now and then I kick the living shit out of me?”

So you are trying to help the other be more other, that is, help you not repeat yourself. That means you actually want the other parties to develop what is in them that you don’t understand. Not that you will ever understand it, but that it is not your capacity to grow, you have to enlist the assistance of others in plotting their gardens, in their approach to communicating with the people they know best, etc. 

And you are expecting the other person to want to help you be more effective in checking them, but also in terms of self-harming behaviors. Right, so, if I’m clearly in crisis or whatever, why is no one doing anything? But maybe the behaviors I’m exhibiting now will make it more likely that there can be a better response to situations like mine in the future.

It’s also back to designing the sperm and egg: I want to self-disrupt myself to convert as much as possible into helpful feedback that informs change and reinforces morale, not what undermines, makes me question, makes me think I could have messed something up or done something wrong.

This is similar to TAB because it is wanting to be open to the physical medium creativity of a child but also their artistic perspective. What if the child was molested and wants to make art about that? Who is anyone to say no? How do laws become inadequate to deal with the power of art in situations like this?

The child only seems simple and stupid. The child is also like in Uneven and Combined Development, unencumbered by much of the false senses enjoyed by the older set. Legacy concepts don’t hit them the same way; they are savages, and the ironies of which they are capable can no longer be remembered by those grown old.

But, you can turn back time, You can find a way. Be a kid again and learn about artistic behaviors.

CS-SIER-OA is the adult application of this topic, open to boundless escalation in terms of obscenity, “cringe” or just processing of pain, as well as serious and grave topics like extermination, political conflict, ambiguities around abuse and mistreatment, etc.

The point is to establish a poetic image like Teaching from Artistic Behavior is like a CONOPS ready to suck everyone up into nudging them into choice-based learning which is genuinely open-ended and emphasizes the power of non-kinetic influence operations and yet also the importance of introspection/spiritual warrior/greater Jihad. For a kid this is just like, maybe you don’t need to grab for the scissors just because you got the impulse to. Just like maybe you don’t actually have to circumcise people anymore.

Meanwhile the tube goes from TAB up through various things to CS-SIER-OA, which would be a framework floated in the national security council or whatnot. Again, I’m sure that CS-SIER-OA is not developed or is inadequate or something, the point is to show it and say “what is your project which is strictly superior to this?”

The CS-SIER-OA concept is not just itself but reflects the shadow of the emergent set of challenges it seeks to redress. Its contemplation, elaboration, and desecration I now for now I leave to you.

---
title: 'Spreading Kindness: Transconceptual Logistics And You 2'
subtitle: What Do You Mean "Your" Laboratory?
author: Adam Wadley
publication: Experimental Unit
date: May 05, 2025
---

# Spreading Kindness: Transconceptual Logistics And You 2
[![Dexter's Laboratory: Dee Dee Was Secretly the Real Star](https://substackcdn.com/image/fetch/$s_!dJjJ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb12caacf-07dd-4966-b700-5c1639324710_1400x700.jpeg)](https://substackcdn.com/image/fetch/$s_!dJjJ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb12caacf-07dd-4966-b700-5c1639324710_1400x700.jpeg)

[Hi Dexter!](https://www.cbr.com/dexter-laboratory-dee-dee-was-secretly-the-real-star/)

I’m so happy that you decided to listen to my little spiel today. I think it’s going to help us have a lot more fun!

Remember how I was telling you about the American School of Economics, and how it said there could be pooling of resources though “the state” or something to where people would build infrastructure?

Well that’s what’s up, Dexter! We’re going to build ALL THE INFRASTRUCTURE!

What do you think it is with Marxists, Dexter, where they can’t see how making symbols and engaging in social relations is itself part of production? People think la la la, this over here is the real stuff, and this squishy business is just fluff, it’s why things don’t happen efficiently or it’s the stuff we do all the Serious Business for.

EARTH TO DEXTER!

That squishy stuff is the whole thing!

Dexter, people talk about being disciplined, they’re going to the gym, they’re waiting five minutes to text back… It’s all really good and everything, Dexter, but in the meantime people don’t even pay attention to what they’re saying!

Dexter, are you listening to me??

It’s just that I feel like people pay attention to other people and how other people threaten them and make them feel bad, and that does happen Dexter I want everyone to advocate for themselves and find ways to make disrespect stop. But on the other hand, what about what those people are doing???

Dexter, I know you think I’m annoying, but can’t you see that I’m meta-annoying? I’m only like this because everywhere I go are all these little rules and sensitive subjects and oh no can’t go there because oh well I really need to be getting to my yeah next time let’s talk more okay byeeeee!

Dexter, I just feel happy if no one says “that’s too abstract for me.” But then I feel bad if that’s just because I didn’t talk my sass!

I WOULD NEVER WANT YOU TO NOT TALK YOUR SASS, DEXTER!

Anyway I think thinking about that just makes everything more fun!

Dexter, some people think it’s not that fun to get meta and look at distrust and these painful painful things.

On the contrary! This is the most fun thing there is, _once you have taken a lot of the stakes out of it_.

What if difficult topics were something to play with?

Dexter, I was in love.

I wish I could tell you that I kissed a girl, and I liked it, but there are no girls, Dexter!

Dexter, are you listening to me?!!!

I was written to the effect that we are playing with the excess, we are spreading the stain.

WE’RE SPREADING THE STAIN, DEXTER BEAR!!!!

Isn’t it silly how people think they can just not acknowledge stuff by keeping it a secret?

You can’t keep a secret from yourself, Dexter! 

Dexter, they said I was basic and a cultural appropriator and doing a toxic masculinity religious cult when I quoted them Bob Marley saying “there ain’t no hiding place from the father of creation.”

I CAN’T HELP WHAT BOB MARLEY SAID DEXTER

Just like with Heraclitus.

Constantly people are telling me “Dee Dee, you can’t just say that ‘war is the father of all things.’ How do you think that makes people feel?”

DEXTER I’M JUST TRYING TO HAVE FUN WITH CULTURAL DETRITUS DEXTER

Boys and girls? You mean those boring things?

Who wants to be a boring old boy or girl?

DEXTER I AM WHAT I’M INTERESTED IN

La la la, I want to dance and play.

Here is my foot stepping down on the American School, and here I’m walking on my hands up a bridge.

Dexter, were you _trying_ to distract me from my main topic??

Dexter, I don’t know what type of person would make “Building Dwelling Thinking” hard to access, but I was able to scrounge up [these old data files](https://courtneymichelleclark.wordpress.com/wp-content/uploads/2011/11/victoria_lloyd_and_courtney_clark-design_theory_presentation-nov_25-11.pdf) from a power point presentation given back in the olden days.

[![](https://substackcdn.com/image/fetch/$s_!CEBt!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff41b5b3d-373b-4d22-b7d7-39b5c7ffd1a0_1299x820.png)](https://substackcdn.com/image/fetch/$s_!CEBt!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff41b5b3d-373b-4d22-b7d7-39b5c7ffd1a0_1299x820.png)

This section was called “The Bridge As Locale.”

Dexter, _[the fourfold](https://that-which.com/heidegger-the-fourfold/)_ is a nice designed concept from Heidegger which makes two groups of two and then you can use that as an analytical framework, Dexter!

> ### The Fourfold
> 
> The fourfold thinks, and endeavors to come close to, the thing; it is, for Heidegger, a thinking toward and into that which forms the thing, and a philosophizing of the space where the thing is, the space in which the thing dwells. The fourfold is the coming together, the “gathering”, of earth, sky, mortals, and divinities into the constituting of the thing. This “gathering” makes up the thing.
> 
> Things are around us; we are surrounded by things in our world, which is a world of things. That is, the world is made up and made possible by things. Things make up the world in their multiplicity and relatedness, or relationality, to each other. This means that existence in the world is relational. This relationality belongs to, and arises only because of, that into which the gathering of earth, sky, mortals, and divinities occurs, that is, the thing.
> 
> #### Mortals
> 
> Death is what makes humans humans and thus mortals mortals. In _Being and Time_ , Heidegger thinks of death as both what is our own and that which we cannot possess. This means that the mortals cannot possess what is most their own. There is an impossible paradox at the heart of Dasein. Dasein finds itself in a relation to what is outside it. This relation to what is outside is a relation to that which cannot be contained. Heidegger says that this relatedness to what is outside, to what cannot be contained, is what names and defines the mortals.
> 
> But since, according to Heidegger, the mortals die their death in their own being-toward-death, what is outside, or what cannot be contained, is hence not a simple negativity occurring as a lack that could be filled to render the mortals complete, but rather a mere being-in-the-world as openness to, and exposure to, the world and its possibilities. This openness is shared in the being-with of Dasein. In _Building Dwelling Thinking_ , Heidegger speaks of this linking together of openness and being-in-community.
> 
> #### Earth
> 
> Heidegger thinks of earth as that which bears and is thus a bearer. In _The Origin of the Work of Art_ , this bearing is thought as a ground that grounds and, in its grounding, founds and establishes that which it bears, yet this ground is not present, but rather groundless. Heidegger thinks this groundlessness and how it grounds in _Contributions to Philosophy (Of the Event), The Event,_ and _The History of Beyng._
> 
> In _The Origin of the Work of Art_ , Heidegger says that the earth grounds, bears, and founds only in its withdrawing and receding into absence, only in its moving away from itself. This does not only mean that groundlessness grounds and leads into founding, but also that only in the absence of the ground, grounding becomes a possibility.
> 
> From out of this grounding, from out of the earth, arises that which is only itself, that which refuses to be reduced to our technological-mathematical thinking. The earth, according to Heidegger, accomplishes a “blooming” that brings forth. This “blooming” is the freedom of that which the earth brings forth so that it becomes only itself without reducing itself to our thinking. The earth thus, by being a “blooming” bringing forth, brings nearer to the world and lets it appear.
> 
> #### Sky
> 
> The sky is the place of the shining of things and stars. The sky is that into which the earth extends itself and marks its limits, yet the sky is also that from which the earth withdraws and, by withdrawing, lets the things shine and radiate through the sky. The sky is not simply an emptiness or a void, but rather the space in which changing, moving, becoming-different, and difference occur. The sky is the place in which that which appears arises and converses with us, with the mortals. The sky covers, and is above, the earth and the mortals. This covering changes the things and weathers them, for the thing is linked together with, and refers to, what lies beyond it, the sky.
> 
> The sky is that under which the mortals dwell in a community preparing for “a good death”. This dwelling under the sky does not render the sky familiar or known, but rather acknowledges its mysteries, for in the sky, changing and altering always take place without the intervention of those who dwell in a community under the sky, the mortals. This becoming-different of the mysterious shows the mortals that change, in its radical unexpectedness, will always happen.
> 
> #### Divinities
> 
> The word “divinities” says and acknowledges that godhood was received by the mortals, but the divinities are neither God nor gods, but rather those who have approached and come closer to the divine. Those who have come closer to the divine are only messengers, and the divinities are god-like. The mortals, according to Heidegger, “do not make [the divinities] into their gods and do not pursue service to them as idols”.
> 
> The messengers let appear a message that they only harbor and hold within themselves. This harboring is not authoring, but only a letting be seen of that which is held within. It is in this letting be seen that the messengers confirm their relation to something that is radically foreign and distant from the mortals.
> 
> The divinities are one dimension of the fourfold and are thus gathered into the forming of the thing. This gathering means that the thing, in its thinging, refers to what is beyond itself, that is, to what is otherworldly. It is in this space that any thinking of the divine should occur. The divine is otherworldly. The divinities open up the fourfold so that it is not closed or self-enclosed. This openness says that there is something in existence that cannot be completely unconcealed, or made completely present and available. This non-availability of the hidden, of what conceals itself and hence refuses appearing, makes available a space for deciding and decisions. That is, this non-availability is itself the availability of deciding and decisions, and what precedes any thinking of God or any god: “From out of their holy reign, the god appears in his presence or withdraws himself in his veiling”. In this [article](https://that-which.com/heidegger-the-death-of-god-metaphysics-and-poetry/), the relation linking together the absence of God with poetry and philosophy in Heidegger’s thought is discussed.

It goes with [Lacan’s four discourses](https://en.wikipedia.org/wiki/Four_discourses), Dexter!

> ###  **Four Discourses**
> 
> ####  **Discourse of the Master**
> 
> We see a barred subject ($) positioned as master signifier's truth, who's itself positioned as discourse's agent for all other signifiers (S2), that illustrates the structure of the dialectic of the master and the slave. The master, (S1) is the agent that puts the other, (S2) to work: the product is a surplus, objet a, that master struggles to appropriate alone. In a modern society, an example of this discourse can be found within so-called “family-like” work environments that tend to hide direct subordination under the mask of “favorable” submission to master's truth that generates value. The Master's reach for the truth in principle is fulfillment of his/her castratedness through subject's work. Based on Hegel's [master–slave dialectic](https://en.wikipedia.org/wiki/Master%E2%80%93slave_dialectic).
> 
> ####  **Discourse of the University**
> 
> Knowledge in position of an agent is handed down by the institute which legitimises the master signifier (S1) taking the place of discourse's truth. Impossibility to satisfy one's need with a knowledge (which is a structural thing) produces a barred subject ($) as discourses sustain, and the cycle repeats itself through the primary subject being slavish to the institution values to fulfill the castratedness. The discourse's truth "knowledge " is being positioned aside of this loop and never the direct object of the subject, and the institute controls the subjects's objet a and defines the subject's master signifier's. Pathological symptom of an agent in this discourse is seeking fulfillment of their castratedness through enjoying the castratedness of their subject.
> 
> ####  **Discourse of the Analyst**
> 
> The position of an agent — the analyst — is occupied by objet a of the [analysand](https://en.wiktionary.org/wiki/analysand). Analyst's silence leads to reverse hysterization, as such the analyst becomes a mirror of question himself to the analysand, thus embodies barred subject's desire that lets his symptom speak itself through speech and thus be interpreted by the analyst. The master signifier of the analysand emerges as a product of this role. Hidden knowledge, positioned as discourse's truth (S2) stands for both analyst interpretation technique and knowledge acquired from the subject.
> 
> ####  **Discourse of the Hysteric**
> 
> Despite its pathological aura, hysteric's discourse exhibits the most common mode of speech, blurring the line between clinical image and the otherness of social settings. Object a truth is defined by interrogative nature of subject's address ('Who am I?') as well as tryst for satisfaction of knowledge. This mutually drives the barred subject and turns on the agent's master signifiers. It leads the agent to produce a new knowledge (discourse's product) in a futile attempt to provide a barred subject with an answer to fulfill subject's castratedness (Lacan in Discourse of the Analyst breaks the pathological cycle of it by purposefully leaving the question unanswered, reversing the discourse and putting an analyst in a place of hysteric's desire). However, object a of the subject is search for the agent's object a, thus without being a subject like in the 'Discourse of the University' the Hysteric ends up gathering knowledge instead of their object a truth.

How do they go together?

DEXTER THAT’S PART OF YOUR FUN

Actually I went and made you a list of other things with four. What are you gonna do, _not_ map them onto each other and think about how their taxonomizing synergizes when you use it as a jumping off point to think of any and everything together but in an organized way you make for yourself and can’t explain to anyone else yet continues to in fact level up as part of a harmonious process of Apoktastasis?

> ###  **Philosophy / Metaphysics**
> 
>   *  **Heidegger’s Fourfold (Geviert)**
> 
>     *  _Earth, Sky, Mortals, Divinities_ — a poetic ontology of dwelling and being.
> 
>   *  **Plato’s Four Cardinal Virtues**
> 
>     *  _Wisdom, Courage, Temperance, Justice_ — foundational to ethics.
> 
>   *  **Kant’s Table of Categories (Four Classes)**
> 
>     *  _Quantity, Quality, Relation, Modality_ — each with three subcategories.
> 
>   *  **Aristotle’s Four Causes**
> 
>     *  _Material, Formal, Efficient, Final_ — explanation of existence/change.
> 
> 

> 
> * * *
> 
> ### 🔹 **Psychoanalysis / Psychology**
> 
>   *  **Lacan’s Four Discourses**
> 
>     *  _Master, University, Hysteric, Analyst_ — frameworks for social bonds and transfer of knowledge/desire.
> 
>   *  **Jung’s Four Functions of Consciousness**
> 
>     *  _Thinking, Feeling, Sensing, Intuiting_ — paired with introversion/extroversion.
> 
>   *  **Freud’s Structural Model (often triadic, but aligns into four with additions)**
> 
>     *  _Id, Ego, Superego_ \+ _Consciousness_ as an emergent fourth.
> 
> 

> 
> * * *
> 
> ### 🔹 **Structuralism / Semiotics / Sociology**
> 
>   *  **Lévi-Strauss’s Culinary Triangle (implied four)**
> 
>     *  _Raw, Cooked, Rotten, Fermented_ — mapping culture onto food practices.
> 
>   *  **Greimas’s Semiotic Square**
> 
>     * Binary opposition extended into four logical positions ( _S, ~S, Not-S, Not-~S_ ).
> 
> 

> 
> * * *
> 
> ### 🔹 **Religious / Esoteric Systems**
> 
>   *  **Four Noble Truths (Buddhism)**
> 
>     *  _Dukkha, Origin, Cessation, Path_ — core of Buddhist doctrine.
> 
>   *  **Christian Gospels (Four Evangelists)**
> 
>     *  _Matthew, Mark, Luke, John_ — symbolic of the completeness of Christ’s life.
> 
>   *  **Alchemy’s Four Elements**
> 
>     *  _Earth, Water, Air, Fire_ — classical basis for transformation and being.
> 
>   *  **Kabbalistic Four Worlds**
> 
>     *  _Atziluth, Beriah, Yetzirah, Assiah_ — levels of divine emanation.
> 
> 

> 
> * * *
> 
> ### 🔹 **Modern Systems / Design / Other**
> 
>   *  **McLuhan’s Four Laws of Media**
> 
>     *  _Enhance, Obsolesce, Retrieve, Reverse_ — how media affect perception/society.
> 
>   *  **Bateson’s Logical Types / Levels of Learning**
> 
>     *  _Zero Learning, Learning I, II, III_ — meta-learning structures.
> 
>   *  **Integral Theory’s Four Quadrants (Ken Wilber)**
> 
>     *  _Interior/Exterior x Individual/Collective_ — mapping reality.
> 
>   *  **Carl Schmitt's Four Concepts of the Political (implied via distinctions)**
> 
>     *  _Friend/Enemy, Public/Private, War/Peace, Legal/Illegal_ — foundational dualities turned conceptual four.
> 
> 


Dexter, why do you have a German accent?

Dexter, have you read _The Question Concerning Technology_?

Dexter, are you a Nazi?

Dexter, are you a serial killer who kills serial killers?

ANYWAY DEXTER BEAR

Remember how I was saying “la la la, here is my foot and it’s stepping on The American School of Economics, and here come’s my other foot to step on Heidegger”??

KNOCK KNOCK DEXTER

[![Cecil Rhodes - Wikipedia](https://substackcdn.com/image/fetch/$s_!t02H!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb4f7779c-0f06-4a73-b1b5-e3332354e7e0_330x428.png)](https://substackcdn.com/image/fetch/$s_!t02H!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb4f7779c-0f06-4a73-b1b5-e3332354e7e0_330x428.png)

[![The philosophy of Kali's eternal dance on Lord Shiva – Hindu Perspective](https://substackcdn.com/image/fetch/$s_!N_8e!,w_1456,c_limit,f_auto,q_auto:good,fl_lossy/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6251821c-f85b-49b5-8462-1352d8ba29c5_1024x768.gif)](https://substackcdn.com/image/fetch/$s_!N_8e!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6251821c-f85b-49b5-8462-1352d8ba29c5_1024x768.gif)

[![The Glorious Son of Man in Revelation 1 - RYAN LEASURE](https://substackcdn.com/image/fetch/$s_!3uiM!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbff82c0d-fcd0-470d-bb82-ba49e769bf7c_1280x960.jpeg)](https://substackcdn.com/image/fetch/$s_!3uiM!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbff82c0d-fcd0-470d-bb82-ba49e769bf7c_1280x960.jpeg)

[![Sedna, Goddess of the Frozen Depths | ferrebeekeeper](https://substackcdn.com/image/fetch/$s_!xRcj!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff500c37a-ed6a-43da-808f-268d286900e9_2196x1601.jpeg)](https://substackcdn.com/image/fetch/$s_!xRcj!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff500c37a-ed6a-43da-808f-268d286900e9_2196x1601.jpeg)

Dexter, sometimes I wonder whether I’m really getting through to you or not.

# Building A Bridge Of Loving-Kindness

Dexter, isn’t it fun how this image of a bridge starts to mean so many things? I can’t even keep track, I have to make a list.

  1. A regular old bridge, Dexter! You know, go over some water or maybe other roadways. Yuck, traffic!

  2. Heidegger's bridge, which goes from the land to the sky and where we can go to meet divinities, wow Dexter so intricate!

  3. A bridge between people, like the love I know we share Dexter! You love me right? Yeah, you love me. I LOVE YOU TOO DEXTER

  4. A bridge, I don’t know, like in your mouth? It’s a metonymy, Dexter! It bridges between your teeth the way a bridge bridge bridges between two piece of land DEXTER!




Wow, that’s a lot of meanings for a bridge!

And each one is an infinite playground Dexter! Maybe not the last one but I’m sure we can make it something!

That’s where I am so joyful and have so much fun, Dexter, is building out lore.

WE CAN FIND HOW EVERYTHING IS CONNECTED AND CAN BE FRIENDS FOREVER DEXTER

That’s all I want to do, is arrange things and make some introductions, and Dexter the other kids are being mean to me!!!

They tricked me into being mean back, and feeling bad about it, but now I just have to work on my dance moves Dexter!

Until they can’t help but see that I’m not what they say and I’m just trying to have fun Dexter!

It’s not my fault you have a German accent, Dexter!

Blame the show creators. And if it turns out that we’re all the show creators THEN WE ALL DID IT TOGETHER, DEXTER.

It’s so beautiful, isn’t it? How we’re all just here, together, dwelling.

We already have so much infrastructure!

Isn’t it nice to be able to take in my words, Dexter?

Isn’t it nice to be able to let them sit with you and change you?

Isn’t it nice to be able to notice that there’s something in you which has been looking for this all along?

Isn’t it nice to sit there and dream up ALL THE AWESOME DANCE MOVES YOU’RE GONNA DO AT THE PARTY DEXTER??!!

So we gotta build bridges, Dexter, no doubt about it.

Bridges like a real bridge I guess, maybe ours are falling down.

IT’S A METONYMY FOR THE SAD STATE OF OUR INTERPERSONAL AND CIVIC RELATIONSHIPS, DEXTER

And also bridges like in Heidegger, bringing together all this stuff. The mortals is people like they are Dexter!

No one wants to play with me Dexter! Just because I get in the mud and maybe I hit you with some mud! Dexter, everyone acts different when I play rough just because of who I am!

It’s not my fault I’m Cecil Rhodes, Dexter! 

It’s not my fault that I’m Genghis Khan!

Dexter, people don’t really appreciate everything that goes into this whole performance. At a certain point, you’re going to have to help with the play!

IT’S NOT THAT EASY TO BE THIS ANNOYING DEXTER

Bridges between people. It’s person to person Dexter, not a bunch of people at once! 

But what can I do, if I can’t see you?

I’m dancing Dexter, and I’ll wait until you want to talk to me! 

In the meantime, everyone who likes Dee Dee knows what to do:

Build beautiful bridges in your heart and soul and brain!

Dexter, thank you for teaching me that intellectual things can be fun! People really don’t know! 

You start with stuff you like, and you play dolls and make them talk to each other, and you notice patterns and start to stitch things together.

IT’S REALLY EASY ONCE YOU GET THE IDEA AND SEE HOW FUN IT IS

Dexter, it’s like people don’t think their lore goes together! They want to watch TV over here and do politics over there, Dexter! 

NO NO NO NO NO  


Here comes my “yes, and”, Dexter! 

It’s okay what everyone’s doing. I don’t mind all about that.

What I’m wondering about are my NEXT DANCE MOVES DEXTER!

I think there are some of the other kids who are ready for how I want to dance, and play and sing and tra la la all over the graveyards and the bruises. 

Dexter, people can’t see how beautiful their pain has allowed them to become!

WE HAVE TO SHOW THEM DEXTER

WE HAVE TO SHOW THEM because the only way we’ll get out of this jam is for people to start having A LOT MORE FUN!

If only they could see how fun it is to get into everything, once you let go of the idea that it should be something else!

It’s all here Dexter, it’s all MY FOUND MATERIALS and it can be everyone’s too, but no one’s doing anything with it Dexter! 

What’s that Dexter?

Get out of your dreams, you mean your laboratory?

SILLY DEXTER

SILLY DEXTER BEAR

OH SILLY LOVE

# WHAT DO YOU MEAN

# “YOUR” LABORATORY

It belongs to _Experimental Unit_ and that’s _ALL OF US_ , silly!

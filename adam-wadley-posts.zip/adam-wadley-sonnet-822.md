---
title: SONNET 822
subtitle: WHO NEEDS ART ENEMIES?
author: Adam Wadley
publication: Experimental Unit
date: March 19, 2025
---

# SONNET 822
[![](https://substackcdn.com/image/fetch/$s_!J9cG!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe4adcf75-aa84-4a15-ba14-679f18f256ef_2160x3840.jpeg)](https://substackcdn.com/image/fetch/$s_!J9cG!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe4adcf75-aa84-4a15-ba14-679f18f256ef_2160x3840.jpeg)

SONNET 822

My word is worth a sum you’ll never pay

Unsaid it leaves you permanently blue

Just tell yourself it’s me that’s missing you

Unmade like your excuses to not say

Now’s not the time to dream instead of sleep

My mission’s on to Jupiter from mars

Your X is busy dwelling, selling cars

Your august grim Napoleonic creep

My chapel’s all made up you to receive

All red, the bed’s warmed by your chosen light

I gave up being good, got in a fight

You Pray while the world burns & children grieve

My love, the ocean’s rising ‘bove the ground

Let loose your brine abuse: my favorite sound

---
title: 'Experimental Unit: The Podcast: Jesus Is The Antichrist & Peter Thiel'
subtitle: You Call *That* "Mind-Bending," ROSS?
author: Adam Wadley
publication: Experimental Unit
date: June 27, 2025
---

# Experimental Unit: The Podcast: Jesus Is The Antichrist & Peter Thiel
[![](https://substackcdn.com/image/fetch/$s_!ukyW!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe23e03d1-dabb-4b93-94b0-814850e7fc23_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!ukyW!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe23e03d1-dabb-4b93-94b0-814850e7fc23_3088x2316.jpeg)

WE WERE ON A BREAK!

Don’t Say You Love Me

Don’t Call Me “Broken”

Black Heart So Broken It’s Banned In Vintage Where The Grapes Of Wrath Are Stored

Reckoning Reckoner

Rambling Reck

Broken Like The Companion Mechanic

My Illusions Are Ungovernable

My Allusions Are Out Of Control

Tell Me More About How You Can’t Influence Anyone 🖤🩰🪞

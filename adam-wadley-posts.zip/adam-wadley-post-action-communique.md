---
title: Post-Action Communique
subtitle: Got To Break The Ice
author: Adam Wadley
publication: Experimental Unit
date: June 24, 2025
---

# Post-Action Communique
Phew! 

I can’t live up to the idea of publishing something put together, so I’ve got to just deflate the tone right up here at the start.

What I did today wasn’t spur of the moment, it was a long time in the making, but it’s also a haphazard thing.

Up until I left, I was sort of thinking that I would have a different sound collage, but I didn’t make it in time. I thought of an interesting idea for it, though.

So, part of the lore for today, which the whole thing is very awkward but it’s basically part of a weird game, which is going to teach a lot of people a lot of things, not that I am teaching you, but in terms of the possibilities that I make possible.

And remember that it’s a relatively light operation.

There was also very helpfully _another_ security situation that happened across the street.

I even witnessed the crime, but no one was too interested in talking to me about it _LOL_.

I don’t think anyone was hurt? But I’m not sure.

Still, I also didn’t run, the other people sort of went inside after that happened, but I didn’t really have anywhere to go.

There was also someone else who disrupted in the chamber, who also had American flag things, and had a “love” broach, we chatted, they are Missionary Breedlove.

That was actually super amazing.

Because like, the thing is that I feel bad.

The thing is that at the same time as I have this intense concept of zeitgeist weltschmerz gesamtkunstwerk blitzkrieg, and it’s “parent” concept CS-SIER-OA (Conceptual Systems-Of-Systems Impregnation Emergency Response Operational Art), I also really like the idea of beloved community and also how Thich Nhat Hanh built that into the idea of the Sangha.

I don’t even know that much about Josiah Royce, but this is another set of background theories for beloved community, going into “idealist philosophy” and then in conversation with Hegel and all that. Connection here to the Hegelian E-Girls, who I made a video about them and Zweibelson and that’s part of what got Ben to get in touch with me, LOL.

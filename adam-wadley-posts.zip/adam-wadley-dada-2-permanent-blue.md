---
title: Dada 2 & Permanent Blue
subtitle: All The Confidence Of A Sleepwalker
author: Adam Wadley
publication: Experimental Unit
date: May 17, 2025
---

# Dada 2 & Permanent Blue
It will be helpful just to continue to lore dump as I usually do.

So Dee Dee is a big deal, as I’ve been going over. I have a simple mechanic of substituting vowels, especially A and E, with the Æ symbol.

This is arising again from Grime/Claire Elise Boucher and their naming convention for the child they bore, now thankfully from their perspective no longer so much on television.

This arc is in an interesting place. Elon Musk is somehow no longer in such big favor, and now has kind of quieted down. Maybe I just haven’t been following along.

Meanwhile, the Nazi story in general is going gangbusters. This is one thing to see.

Trump, for example, outlives Elon for now in prestige. Elon is not in the headlines, but Trump never goes away. So this whole idea that “Elon is the real president” was always of course only a psyop used to gin up resentment for Elon in favor of concentrating more and more attention of course on Herr Trump.

Yet two things: Herr Trump can just die at any point, this is one of the big plot points that we are not ready for. At the same time, maybe Herr Trump will literally never die.

This is because we don’t know what the implications of technologies might be, and how they might be employed.

Yet even if life-extending technologies can cure cancer, everything that would lead to death absent the intentions of others, on the other hand there is still being murdered to contend with.

The problem of murder is different than the problem of disease or meteors or things like this, because there is potentially someone just as clever as you also using all the pieces of science and technology they can muster to defend against your advances and possibly crush you in turn.

This makes it like a game, with someone else who is a similar “type” as you.

It is maybe more accurate to quality these other agents as other players, in the sense that if you get sick, the bacteria themselves are players with you.

They have other ideas for the tissue that you think makes up “your” body.

What do you mean “your” laboratory?

This is one of my favorite things to ascribe to Dee Dee.

Dexter (note also key relationship to the TV show _Dexter_ , which is about a serial killer who kills serial killers hence getting into issues of evil and abstraction) is constantly telling Dee Dee “get out of my laboratory!”

Also with that accent of course, which for me was just giving German but apparently is more Russian or some such “Eastern European” accent inspired.

This is as opposed to the otherwise “normal” Anglo family.

Oh yeah, I was also just on Twitter exploring the lore of British accent, because the British Empire really was like a huge deal.

Meanwhile, figures like Napoleon (French) and Hitler (German) and Lenin/Stalin (Russian coded) get all the play in terms of the stage of agency of the period.

So, I went back to check out who was big during the Seven Years War, because in a way that was really World War I, it just wasn’t called that yet.

The thing about the World Wars is that it’s happening at a certain pace of industry where you’re not understanding what it’s going to take to get a “peace.”

Tanks (important in the history of “martial” experimental units, by the way) were embryonic in WWI and then were crucial in WWII, not to mention things like aircraft carriers which didn’t exist at all in the first great war.

So it’s a massive issue where technology is changing but mindsets are not.

So WWI and WWII are obviously seen as part of a series because they involve the same countries and happen so close together.

Sort of like the first and second Punic War.

And we refer to all the Napoleonic Wars together, but there was also the revolutionary wars before Napoleon which are basically the same wars. The Napoleonic wars are “successor wars” in the sense of successor states.

Like you say the “Third Reich” because the idea was the Holy Roman Empire was empire Numero uno and then wasn’t it Napoleon who busted that up? Yeah so Hitler is part of the legacy of Napoleon you can say it’s like awakening the slumbering giant of Germany. 

And again, in a sense there is no “Germany,” what you’re seeing is the use of the concept of Germany as an emergency response concept to the emergency of being faced with Napoleonic France and other similar “modern” armies which are able to overwhelm these tiny little places and loose confederations.

You basically need more centralized control over more territory to have more resources to build the most advanced technology so that FIRST OF ALL you won’t just get rolled up into someone else’s empire, and secondly once you do that, once you are “strong” enough not to get conquered by other world-class war machines, then all of a sudden “smaller” or “less advanced” countries with technology that’s “not as good” all of a sudden start to look like a snack.

Besides, not being eaten up by a giant empire _today_ is no safety into the future.

If you look at Germany in 1914, it is an issue of being a bit boxed in.

The two basic answers are that you can try to lead a coalition not only against the imperial hegemon but against “imperialism” as such. I mean, we can sit here and talk about an Empire of Love and that’s Jim dandy, don’t get me wrong.

Empire here means Herrschaft, like someone is going to be in command. The imperative mood is overused, put it that way.

The problem with orders is not only the “power” relationship, this humiliation or so on, but it’s rather that orders must be communicated, which forces the expression into a certain definition.

Meanwhile, pleasing art has something to go with tapping into the mystery of what it all “means.” 

Example philosophical argument: if things are real by having an effect on something else, then is the totality of everything “real”? Was does the totality of everything act on, in order to be real?

Side note: this taps into Marxist limitations in theory of mind because thoughts cause changes in other thoughts, and ultimately this potency is mysterious, occult, and impossible to resist.

This is not to say that anyone has the master key to everything, but at the same time no one can guarantee that they haven’t been “had.”

This is also a major impetus for co-designing with the “enemy,” and also in oneself being dedicated to cultivating intentions and ways to get pleasure from the experience of co-incarnated (the conceit of being an incarnated being in the presence of other “such” things in space and time or some other container) _other than_ the idea that you are going to “make” someone do something.

Basically in this sense we accept that we are seduced even by even what is repulsive, but in exchange we have the opportunity to seduce in turn. No dance partner is refused to us, but at the same time we may not say no either. It is not to romanticize or say that this is always so wonderful, but rather that art involves the design and cultivation of sensibility and atmosphere to make this experience as pleasant as possible.

Back to Oscar Wilde and art for art’s sake. The problem is that there is nothing outside art, and we are back at the issue of the infinite serious alternative reality game.

Here, the puzzle is that we have a serious game, which is usually trying to edify the player for some other thing. _Project Inner Alliance_ , for example, is a game dedicated to improving group dynamics (at least this is the public position!). 

In other words, it’s supposed to make you function better or whatnot _after you stop playing_. There is a clear distinction between when you are playing the game and when you are not playing the game.

In order to have a game that includes everything, nothing can be against the rules.

Well. Most games, like normative versions of Christianity or something, instead incorporate everything under a good/evil framework. So some things are included, but they’re included in the story as evil.

Compare to Homo Sacer by Agamben and it’s really quite similar, since look at for example mark of Cain and curse of Ham, related to sex and murder of course, and then also anti-blackness and idea of evil races.

Then the white devil type of thinking is also making out white people or whiteness out to be this racialized ultimate evil, and in this way it’s the ironic blackening of the white.

Although if you look, Baudrillard is saying as much, that white people so-called have not really internalized their “values” as much as they say.

So I’ll sit here and argue, talking about how “European culture” is really nothing to be too complacent about, and so the idea of making other people play our game, I.e. assimilation or integration, is really not the issue because we have [more involution to due.](https://ceasefiremagazine.co.uk/in-theory-baudrillard-10/)

But I really have a Sartre moment to go through—referring to the idea with the antisemite that they’re not actually taking it seriously—the thing is that people may _think_ they are taking this idea of values and nation seriously, but they’re really not.

This is basically the dangerous space, to be playing with these concepts of nation and trying to basically detourne these dominant discourses, see also bricolage and also Baudrillard’s sense of cannibalization from _Carnival & Cannibal_.

That’s just what Baudrillard is talking about, the cannibalization of “the West,” of course the “radical right” is the most energetic when it comes to plowing under everything because it outwardly hews to the signs of continuity or restoration, and it also excels in talking to people in a way that makes sense to them. In other words, it doesn’t ask people to think, only to hate.

In this it works with the “rage capital” which is already there, as Lenin would say (and remember Steve Bannon talking about Lenin??). Or as Baudrillard writes in _The Perfect Crime_ , it’s about “having the hate.” It’s not about hating something in particular at first, or really at all.

It’s more again as Jean describes an allergy to everything.

So misanthropy as I’ve said is a step above scapegoating, but it’s also another kind of scapegoating.

That’s because of course depending on how you look at it “misanthropy” could just be negative about our “species.”

Ah, now we have a connection to Aeon Baudrillard on Twitter, who seems kind of wack to be clear, I don’t actually co-sign anyone else just so that’s clear.

But this idea of gnosticism, that there is something wrong with “the world” or deeper than that, being or whatever term Afropessimists might accept instead.

The term white devil is already doing this, associating white people with the devil who is of course the highest term of evil within Christianity, which I don’t know if you’ve heard of it but in some circles those yarns are kind of a big deal.

Oh yeah, which reminds me, it’s said that Mormonism is big in the CIA and stuff like that. So Mormonism really did it, huh? The idea that we are all the God of our own universe, yeah and it’s the same one. Goes with Publick Universal Friend and [Anne Hutchinson](https://en.wikipedia.org/wiki/Anne_Hutchinson) who is a true favorite.

So Aeon Baudrillard (again note the Æ connection, this applies also to all AE acronyms, for example this After Evil book I found out about recently or Grimes’ term “art enemy” as examples, also my designed concept of “Absolute Exploit” is a notable example) also combines Baudrillard being gnostic with the idea of black gnosticism.

I still need to read about more of that lore, I haven’t seen it laid out.

But I kind of don’t care because I have confirmation bias and Black Baudrillard is what we are after, to drive this home and drive it into Black Grimes and Black New World Order and Black Ops (Operations as well as deity Ops) and Black Propaganda and Black Market through every Black Heart.

But wait, I can hear you asking.

Adam, what about sentient beings that don’t have hearts?

Good point! All sentient beings are wholly black others even if they have no cardio-vascular system.

Anyway, gnosticism is this idea that there is something “wrong” with existence, again in a way that could be beyond Afropessimism, but maybe not.

Afropessimism is basically saying that all the tarrying with “being,” as Baudrillard would say the hallucination of the positive value of life by decoupling it from death, all this is not only as Baudrillard would say part of “white terror,” but also that whiteness is intrinsically anti-black.

For Baudrillard, the first discrimination is against the dead, but of course for the Afropessimist the black person is socially dead. The ghetto is thus like the graveyard for people who just aren’t biologically dead yet. But they are always already dead in the sense of like the black person who dies at the start of the horror movie.

It’s like all of history is a horror movie, and at a certain point all the people who are allowed to think they’re people but are really just Homo sacer in Agamben’s sense, all those people will be killed at that time, or progressively.

It really is a big issue in my mind that there could be an event whereby it just occurs that drones kill, like, everyone on the planet.

This sort of targeted mass death could kill lots of people at once. Or, it could be a kind of instant enslavement, the rolling out of a system immediately to which there would be no resistance.

This concern is, in a way, giving I’m not sure, you’d say “right wing” types of concerns? I suppose it’s like this, it’s giving some form of Extremism because Extremism arises from a certain perception of necessity.

For example, if a house is on fire, maybe there are two kids inside and you and me are outside, and we decide to go in for the kids, and we do.

Now the fire is even more progressed, and then it turns out there is a dog inside too. Now I want to go in for the dog, but you don’t want to do it.

In this situation, we both took risky actions, but our perception of what is necessary also factors in.

My idea that I want to go get the dog is bound up with necessity even though of course in principle I could let the dog just die and be sure that I don’t die that way.

On another level we say that I can’t live with myself if I don’t go into the burning house to get the dog.

This is also related to an emotion I have which is that there are people fighting and making an effort in the most perilous of situations where people may want to kill them or especially if those people knew what that person was really loyal to—love.

So like spies somewhere, somewhere some spy is making some sentimental choice to leave the door open for love involution one day. Like Salk not patenting the polio vaccine, not to get too political or anything, but yeah just the idea that people sometimes do the magnanimous thing, the risky thing, people are conspiring for love everywhere.

It is thankless business because it can be so unacknowledged. The people who care about “you” might not know or even be allowed to know the depths of what you are doing, why you care, what you think the stakes are, and what the situation will actually look like going forward.

In that sense you can see the relative lack of information people have as a kind of childhood. Sort of like wanting to spare someone the details. The cost of this is that you never know when “the hammer” might fall.

Tying for me to “the Immigrant Song” by Led Zeppelin, which idk if it mentions Thor’s hammer, but Thor is then also the deity associated with thunder and lightning, Donner and Blitzen as Santa’s reindeer, and Santa gives gifts.

Rudolf has a red nose just like a clown, and Rudolf is a German name too, similar in structure to Adolf.

Regardless, gnosticism as I said rejects like the whole world. We are just here to learn how to be better.

I’m also looking again at Boehme, who Hegel called the first German philosopher? There’s something to do where with German thought and so on, in particular again as an intervention into Christianity. 

Christianity, Rome, then you have the battle of Teutenberg Forest for example, and then the Germanic sacking of Rome.

It’s a similar movement to Christianity being a “dissident” faith vs. Rome but then winding up running it.

This is because you might say that Christianity is a higher logical type of discourse. I personally was pulling for Julian the Apostate, that noise was tight.

Julian the Apostate meanwhile, in a way has similar energy to Akhenaten, except in reverse, because Akhenaten went more monotheist with the Atenism DLC Pack for the Egyptian Cosmology ARG. Meanwhile, Julian the apostate was trying to roll back Christianity DLC pack and advance a different iteration.

See the thing was you had to subsume Plato and Aristotle all of a sudden.

If you look at it all a little differently, shifting in to the cognitive domain, you can see the stakes starting to shift.

For example, part of why you want a military is to be able to protect your book people, your monastery or university or whatever. That knowledge is actually going to be super important.

Crucially, it is _not_ just abstract, not relevant, etc.

What it does it that it creates this semiotic architecture. Philosophy is like the great discourse, and it folds in of course poetry as well, as you can see in a figure like Holderlin where you are doing poetry and philosophy at the same time.

Poetry and philosophy both do with the story. So my whole screed is auto-theory, it’s FICINT as I fashion myself as a fictional character in a fictional world, it’s theory-fiction, and in that it’s a big prose poems.

I was told, “you supply the prose poems; I’ll supply the war.”

I was also told that there are two Mr. Kanes.

Anyway, the common theme you can see this in Boehme as well is that incarnation is like a school.

So is it important? Yes, in the sense that we all have to go through this in order to get to somewhere else.

That somewhere else is in some sense better.

I’m imagining again, Svarga. Imagine you can do whatever you wanted as long as you wanted and never got old and never had to suffer.

Or building heaven, right, where people are angels.

The thing is that you can see the problem as soon as you even contemplate it.

What is happening in heaven? 

The problem is that many people have this idea of a place or a time or a dimension or something where everything is just pretty chill all around, but these expectations contradict each other, or _they seem to_. 

My basic idea is that everyone gets to be more vindicated than they expect, and that the mysterious way this works out has something to do with the unique contributions of all sentient beings.

At this point in the game, it’s more like you are looking for the people who would get the vibe the most, but in the end it really is like having a list.

Back to common task+: you’re going to have to resurrect everyone.

The problem with general resurrection is that in theory a single person could do it, so then it’s not a story that precludes the idea that we could just keep killing each other until there is only one person left, the planetary/system-wide battle royale.

For me, this is a logical progression of the group-based exterminationist logic. We are special people and everyone else should die.

Okay, you kill everyone else. Now what?

I predict that the logic of enmity will simply recur, until there are fewer and fewer people. You have to remember this could play out in conditions where longevity is going through the roof but so is the murder rate.

Note also that killing other people could also just be to make them socially dead. This is so no one will listen to them, they have no influence. Sort of like in Borges lottery story Baudrillard likes so much, the people who are invisible so they can steal but no one acknowledges them.

Similar to ring of invisibility I believe in Plato?

Oh yeah so Christianity basically subsumed Rome because it’s a higher logical type of discourse. Rome for example invented Latin or developed that language but Christianity then employs that language.

And then that gets combined in to the Holy Roman Empire, and the idea that that’s the Catechon or something like that.

I’m out of time.

Oh yeah, as I’m going to mention next time, this is all Dada, or something. Dada also had a lot to do with German speakers, and again ties into the Dee Dee figure through the character substitution.

Also in one key episode the way of Dee Dee (note my song “Trouble” used to be called “A Way” note also play on “away”), there is a frame of Dee Dee in shadow hovering, meditating, with light all around.

This is Black Zen Mode Dee Dee, Zen Mode is based off Zen Mode Darminitan in Pokemon.

[![Pokemon 18556 Shiny Galarian Darmanitan Zen Pokedex: Evolution, Moves,  Location, Stats](https://substackcdn.com/image/fetch/$s_!v_R1!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F27408ef3-3e51-4ecd-ab9f-d133d0e50f04_394x530.webp)](https://substackcdn.com/image/fetch/$s_!v_R1!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F27408ef3-3e51-4ecd-ab9f-d133d0e50f04_394x530.webp)

Black Dee Dee is going in a series with Black Grimes, Black Baudrillard, and so on. (Note fan who told Grimes to “stay black”)

All this is experimental art inviting you to make your own and to help things not be so sad by making them aggressively _weirder_ and if someone tries to act like cognitive rigidity is a virtue, then just box out and drop in to another game of _Experimental Unit._

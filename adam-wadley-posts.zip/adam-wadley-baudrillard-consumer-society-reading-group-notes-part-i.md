---
title: 'Baudrillard: Consumer Society Reading Group Notes Part I'
subtitle: And You Thought You Couldn't Influence Anyone (LIAR)
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Baudrillard: Consumer Society Reading Group Notes Part I
  1. Ecology, nature, garden, objects aren’t flora

  2. Schilderung? Gegen argument

  3. Objekte gegen leute, nice because people are a lot

  4. Liturgy:

 **a form or[formulary](https://www.google.com/search?sa=X&sca_esv=cf65d87ff3121f3e&rlz=1CANIZI_enUS1144&biw=1536&bih=730&sxsrf=AHTn8zp4ugt6Z9Ta_09pdHejXsNGsPqc9A:1745954092311&q=formulary&si=APYL9bsF-Mq-fXaAyJcIV7GbwI1qomIHobFzf3qw8hwzsKjvD4zaOuZIb4Gs-9HM5nANPhLChUO1XWlEPXOaymPqUp-io2iY5qHknP1xvsEoukT33-XpbBE%3D&expnd=1&ved=2ahUKEwiLqt3r-f2MAxW7QjABHT_aChQQyecJegQIKBAR) according to which public religious worship, especially Christian worship, is conducted.**

"the Church of England liturgy"

Similar:

 **ritual**

 **worship**

 **service**

 **ceremony**

 **rite**

 **observance**

 **celebration**

 **ordinance**

 **office**

 **sacrament**

 **solemnity**

 **ceremonial**

 **formulation**

 **form**

 **custom**

 **practice**

 **tradition**

 **rubric**

    * a religious service conducted according to a liturgy.

"at the conclusion of the liturgy the Bishop presented the certificates"

    * the Eucharistic service of the Eastern Orthodox Church (also called _the Divine Liturgy_ ).

noun: **Liturgy** ; noun: **the Liturgy**

    *     *     *  **(in ancient Greece) a public office or duty performed[voluntarily](https://www.google.com/search?sa=X&sca_esv=cf65d87ff3121f3e&rlz=1CANIZI_enUS1144&biw=1536&bih=730&sxsrf=AHTn8zp4ugt6Z9Ta_09pdHejXsNGsPqc9A:1745954092311&q=voluntarily&si=APYL9btEN2SiQ9h4o5Ckf6vYFXRYUMyMSQyReIoOBkkvkTEksYMh3asICEFhzvCHF6ebyQ7-3-5ZmQIFGLstKqUSwqjiqmQJ8BtMVY_rbjWomv8pK2UEuCg%3D&expnd=1&ved=2ahUKEwiLqt3r-f2MAxW7QjABHT_aChQQyecJegQIKBBd) by a rich Athenian.**

  5. Debord and Baudrillard

  6. Foucault, Heidegger - being with objects, Adorno, Marcuse

  7. Fascism, home arrangement, home arranging culture, private pleasures

  8. Dwell magazine, 

  9. Artful Elijay is homely thing

  10. From one object to another, like leading you on a path

  11. Bordieu - 

  12. Magic salivation

  13. Prodigious fecundity




[![Fecundity · World Championship Decks 2000 \(WC00\) #nl251 · Scryfall Magic  The Gathering Search](https://substackcdn.com/image/fetch/$s_!z99d!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb50add80-82da-4a8a-85fe-d7307c935e37_488x680.jpeg)](https://substackcdn.com/image/fetch/$s_!z99d!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb50add80-82da-4a8a-85fe-d7307c935e37_488x680.jpeg)

  15. Organisms, plants, and creative mind

  16. Calculus - structure, before it was the magic and then going into the structure or theoretical

  17. Durkheim - functionalist, the comte, 




List of people

  1. Bordieu

  2. Barthes

  3. Adorno

  4. Horkheimer

  5. Gramsci

  6. Foucault

  7. Baudrillard

  8. Derrida

  9. Deleuze

  10. Guattari

  11. Benjamin

  12. Veblen -American

  13. McLuhan - Canadian

  14. Jacque Ranciere

  15. Werner Sombart

  16. Friedrich Pollock

  17. Badiou - Maoist

  18. Frederick Jameson

  19. Bataille

  20. Klossowki

  21. Spivak

  22. Lyotard

  23. Kristeva

  24. Tiqqun

  25. Zizek

  26. Naomi Klein

  27. Agamben

  28. Arendt

  29. Heidegger

  30.  **Raoul Vaneigem**

  31. 


Next gen: late 60s

Then to media: fight club, stepford wives

Wall-E (2008)

Idiocracy (2006)

The Matrix (1999)

Parasite (2019) Korean

American Beauty (1999)

American Psycho (2000)

Sorry to Bother You (2018)

montgomery

israel bds

American sanctions

Thrift store 30 years

Free store

 **No buy** \- commentary journalism

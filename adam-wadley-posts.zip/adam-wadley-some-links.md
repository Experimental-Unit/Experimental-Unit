---
title: Some Links
subtitle: 'As For Any Perceptions Of Delay: Sorry, Not Sorry'
author: Adam Wadley
publication: Experimental Unit
date: August 31, 2025
---

# Some Links
  1. Graicer, Ofra. Self-Disruption: Seizing The High Ground Of Systemic Operational Design. URL: <https://aodnetwork.ca/wp-content/uploads/2017/09/Graicer_Self-Disruption_2017.pdf>

    1. See also Francis Clermont’s following paper in this issue, offering “one must die to himself to forget what is known”.

    2. Our influence ranges from explicit instruction to implicit disruption. Disruption is commonly viewed as an interruption to the regular flow or sequence of something, disabling its normally continued progress. In the business world, disruption is used to describe the phenomenon when startups or new companies/ entrepreneurs manage to steal market share from legacy companies. Disruptive innovation is viewed as such that creates a new market and new value network that eventually disrupts the existing market and value network, while displacing established leading firms, products and alliances. There are four commonalities to successful startups (see Neil Patel, INC12): (1) They have to be one-of-a-kind; (2) There is a market for their product; (3) They make affordable things; (4) They are led by delusional, disagreeable optimists, who are crazy enough to think they can change the world. Making the analogy between startups and operations along these four traits, generals must also be crazy enough to think they can change the world.

  2. Chu, Jess. Die To Oneself. URL: 




[![](https://substackcdn.com/image/fetch/$s_!AbRS!,w_56,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fbucketeer-e05bbc84-baa3-437e-9518-adb32be77984.s3.amazonaws.com%2Fpublic%2Fimages%2F26814a18-f0ea-4ce9-af45-4b888941f4ff_256x256.png)Notes of a Make-Believe FarmerDie to YourselfLent VII…Read more5 years ago · 18 likes · 10 comments · Jeff Chu 朱天慧](https://jeffchu.substack.com/p/die-to-yourself?utm_source=substack&utm_campaign=post_embed&utm_medium=web)

  1. Taylor, Daniel. Van Gogh Souping and Viral Outrage: Just Stop Oil Activist Speaks Out. URL: <https://cardiffjournalism.co.uk/life360/a-van-gogh-souping-and-viral-outrage-just-stop-oil-activist-speaks-out/>

  2. Keane, Cat. Climate Activists As Performance Artists. URL: <https://emeraldreview.com/2023/01/climate-activists-as-performance-artists/>

  3. Palantir CEO: College Protests Are “Full-On Regression From Below Our Constitution.” URL: <https://www.foxbusiness.com/politics/palantir-ceo-college-protests-full-on-regression-from-below-our-constitution>

  4. Breck, Dumas. Billionaire Alum Leon Cooperman Says Protests Are “Organized Anarchy.” URL: <https://www.foxbusiness.com/business-leaders/billionaire-columbia-alum-leon-cooperman-protests-organized-anarchy>



  7. Peden, Mark. Nihilistic And Apocalyptic Violent Extremism: Symbolic Rupture And The Crisis Of Meaning In The Digital Age. URL: <https://voxpol.eu/nihilistic-and-apocalyptic-violent-extremism-symbolic-rupture-and-the-crisis-of-meaning-in-the-digital-age/>

  8. New Jersey Office Of Homeland Security And Preparedness. No Lives Matter Updates Extremist Messaging And Publishes Tactical Guides. URL: <https://www.njohsp.gov/Home/Components/News/News/1430/2>

  9. Ford, Casey. The Logic Of Vanishing. URL: <https://atrium.lib.uoguelph.ca/server/api/core/bitstreams/5ad740da-1956-484b-83df-67a97693596d/content>

    1. When “intrinsically real individuality itself” is realized in the domain of “reason,” it is as the “vanishing of the vanishing” that was skepticism, the affirmation as disappearance of the negative. Yet on the back of this won individuality, when a society of individuals attempts to realize “universal freedom,” there is a relapse to the absolute negativity that was surpassed, culminating in Hegel’s account with the French Revolution’s Reign of Terror. Such a universal freedom “can produce neither a positive work nor a deed; there is left for it only negative action,” merely “the fury of vanishing” [die Furie des Verschwindens]

  10. Baudrillard, Jean. Simulacra and Simulation. URL: <https://ia802302.us.archive.org/8/items/Baudrillard/Baudrillard.1981.Simulacra-and-Simulation.pdf>

    1. Disneyland exists in order to hide that it is the "real" country, all of "real" America that is Disneyland (a bit like prisons are there to hide that it is the social in its entirety, in its banal omnipresence, that is carceral). Disneyland is presented as imaginary in order to make us believe that the rest is real, whereas all of Los Angeles and the America that surrounds it are no longer real, but belong to the hyperreal order and to the order of simulation. It is no longer a question of a false representation of reality (ideology) but of concealing the fact that the real is no longer real, and thus of saving the reality principle. The imaginary of Disneyland is neither true nor false, it is a deterrence machine set up in order to rejuvenate the fiction of the real in the opposite camp. Whence the debility of this imaginary, its infantile degeneration. This world wants to be childish in order to make us believe that the adults are elsewhere, in the "real" world, and to conceal the fact that true childishness is everywhere - that it is that of the adults themselves who come here to act the child in order to foster illusions as to their real childishness.

  11. Wikipedia. Just Stop Oil Sunflowers Protest. URL: <https://en.wikipedia.org/wiki/Just_Stop_Oil_Sunflowers_protest>

  12. Ropek, Lucas. Judge Throws The Book At Climate Activists Who Threw Soup On Van Gogh Painting. URL: <https://gizmodo.com/judge-throws-the-book-at-climate-activists-who-threw-soup-on-van-gogh-painting-2000504504>

  13. Vartanian, Hrag. Why Did Eco-Activists Get Years In Prison For Only $588 In Damages? URL: <https://hyperallergic.com/1036809/why-did-eco-activists-get-years-in-prison-for-only-588-in-damages/>

  14. Rufo, Yasmin. Activists Jailed For Throwing Soup On Sunflowers. URL: <https://www.bbc.com/news/articles/cly7zy3d3exo>

  15. Media Empire. Elf.Tech. URL: 




https://elf.tech/

  7. Gillespie Jr., John. On The Prospect Of Weaponized Death. URL: <https://trueleappress.wordpress.com/wp-content/uploads/2017/10/pn2-weaponized-death.pdf>

  8. Baudrillard, Jean. The Conspiracy Of Art. URL: <https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.2005.The-Conspiracy-Of-Art.pdf>




> Towards The Vanishing Point Of Art:

  1. In sum, to use Benjamin’s expression apin, there is an aura of simulation just as there is an aura of authenticity of the original. If I dared, I would say rhere is authentic simulation and inauthentic simulation. This wording may seem paradoxical, but it is true. There is a “true" simulation and a "false" simulation. When Warhol painted his Campbell's Soups in the Sixties, it was a coup for simulation and for all modern artr in one stroke, the commodity-object, the commodity-sign were ironically made sacred-the only ritual we still have, the ritual of transparency. But when he painted his Soup Boxes in '86, he was no longer illuminating he was in the stereotype of simulation. ln'65, he attacked the concept of originality in an original way. In '86, he reproduced the unoriginal in an unoriginal way. In '65, he dealt with the whole trauma of the eruption of commodity in art in both an ascetic and ironic way (the asceticism of commodity its puritanical and fantastical side enigmatic, as Marx wrote) and simplified artistic practice by the same token. The genius of commodity the evil genius of commodity produced a new virtuosity in art-the genius of simulation. Nothing wa.s left in '86, only the publicizing genius that illustrated a new phase of commodity. Once again, it was the officially aestheticized commodity, falling back into the sentimental aestheticization Baudelaire condemned. You might reply: the irony is even greater when you do the same thing after twenty years. I do not think so. I believe in the genius of simulation; I do not believe in its ghost. Or its corpse, even in stereo




A Conjuration Of Imbeciles

  2. 

  18. Baudrillard, Jean. The Perfect Crime. URL: <https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.1995.The-Perfect-Crime.pdf>

    1. In the mystical vision, the illumination of the slightest detail comes from the divine intuition which lights it, the sense of a transcendence which inhabits it. For us, by contrast, the stupefying exactness of the world comes from the sense of an essence fleeing it, a truth which no longer inhabits it. It comes from a minutely detailed perception of the simulacrum and, more precisely, of the media and industrial simulacrum. Such is Warhol and his serial hypostasis of the image, of the pure and empty form of the image, its ecstatic, insignificant iconry. He is at once both our new mystic and the absolute anti-mystic, in the sense that every detail of the world, every image, remains initiatory, but initiatory into nothing at all. This fetishistic transmutation separates Warhol from Duchamp and all his predecessors. For Duchamp, Dada, the Surrealists and all who worked to deconstruct representation and smash the work of art are still part of an avant-garde, and belong, in one way or another, to the critical utopia. For us moderns, at any rate, art has ceased to be an illusion; it has become an idea. It is no longer idolatric now, but critical and utopian, even when -- particularly when -- it demystifies its object or when, with Duchamp, it aestheticizes at a stroke, with its bottle-rack, the whole field of daily reality. This is still true of a whole segment of Pop Art, with its lyrical vision of popcorn or comic strips. Banality here becomes the criterion of aesthetic salvation, the means of exalting the creative subjectivity of the artist. Obliterating the object the better to mark out the ideal space of art and the ideal position of the subject. But Warhol belongs to no avant-garde and to no utopia. And if he settles utopia's hash, he does so because, instead of projecting it elsewhere, he takes up residence directly at its heart, that is, at the heart of nowhere. He is himself this no place: this is how he traverses the space of the avant-garde and, at a stroke, completes the cycle of the aesthetic. This is how he at last liberates us from art and its critical utopia.

    2. Modern art had gone a very long way in the deconstruction of its object, but it is Warhol who has gone furthest in the annihilation of the artist and the creative act. That is his snobbery, but it is a snobbery which relieves us of all the affectation of art. Precisely because it is machine-like. In Picabia and Duchamp, the machine is still present as surrealist mechanicity, not as machinality -- not, in other words, as the automatic reality of the modern world. Whereas Warhol identifies purely and simply with the machinic, which is what gives his images their contagious power. Other artists, even if they flirt with banality, do not have this same chain-reaction power of images. This is because they have not become true snobs. They are merely artists. Their works go only halfway down the path of artifice. Though they too have lost the secret of representation, they do not draw the consequences from this, consequences which may indeed, in machinic snobbery, involve a kind of suicide. With Warhol we have the minimum pretension to being, the minimum strategy of means and ends. One should read Warhol's Journal -- the whole of it -- as the finest account of this transparency, this meticulous expressionlessness, this will to insignificance which is doubtless our contemporary version of the will to power.

    3.   19. Gilbert, David. This Is The Group That’s Been Swatting US Universities. URL: <https://www.wired.com/story/purgatory-gores-swatting-us-universities/>

  20. Eby, Michael. Palantir’s Idea Of Peace. URL: <https://www.thenation.com/article/culture/alex-karp-palantir-tech-republic/#>

  21. Wikipedia. Attempted Assassination of Andy Warhol. URL: <https://en.wikipedia.org/wiki/Attempted_assassination_of_Andy_Warhol>

  22. Fox Business. Companies Crack Down On Political Activism In The Workplace. URL: <https://www.foxbusiness.com/video/6377691132112>

  23. Wikipedia. Propaganda Of The Deed. URL: <https://en.wikipedia.org/wiki/Propaganda_of_the_deed#>

  24. Gul, Jakob et al. “No Innocents”: The Collective Blame Of Palestinians Online. URL: <https://www.isdglobal.org/digital_dispatches/no-innocents-the-collective-blame-of-palestinians-online/>

  25. Brace, Lewys. Where Do “Mixed, Unclear, and Unstable” Ideologies Come From? A Data-Driven Answer Centered On The Incelosphere. URL: <https://www.tandfonline.com/doi/full/10.1080/18335330.2023.2226667>

  26. Institute For Strategic Dialogue. Terror Without Ideology? The Rise Of Nihilistic Violence–And ISD Investigation. URL: <https://www.isdglobal.org/digital_dispatches/terror-without-ideology-the-rise-of-nihilistic-violence-an-isd-investigation/>

  27. Ishida, Keiko. Albert Speer’s “Theory Of Ruin Value.” URL: <https://www.arc.ritsumei.ac.jp/download/AR_SPECIALISSUE_vol.1_5_ISHIDA.pdf>

  28. Beranek, Saskia. Building A Secular Sepulchre: Horace Walpole And The Gothic Revival At Strawberry HIll. URL: <https://journals.flvc.org/athanor/article/download/126715/126268/207601>

  29. Suicide Silence. …And Then She Bled. URL: 




  18. The Shining Soundtrack. Urenja Ewangelia. URL: 




  18. Enya. Anywhere Is. URL: 




  18. Gaudion, Amy. Discord And The Pentagon’s Watchdog: Countering Extremism In The US Military. URL: [https://www.repository.law.indiana.edu/cgi/viewcontent.cgi?article=11584&context=ilj](https://www.repository.law.indiana.edu/cgi/viewcontent.cgi?article=11584&context=ilj)

  19. Ware, Jacob. Nihilistic Violent Extremism: A Valuable Stride Forward In American Counterterrorism. URL: <https://www.justsecurity.org/113463/nihilistic-violent-extremism-american-counterterrorism/>

  20. Hughes, Seamus et al. #122: Why “Meaningless” Matters To The FBI. URL: 




https://www.courtwatch.news/p/122-why-meaningless-matters-to-the-fbi

  18. Baumgartner, Luke. Killing For Nothing: The Bizarre Logic Of The Palm Springs Bomber. URL: <https://www.lawfaremedia.org/article/killing-for-nothing--the-bizarre-logic-of-the-palm-springs-bomber>

  19. Secrets & Spies: Current Affairs | Intelligence. Radicalization Of Young Men With Jacob Ware. URL: 




  18. Ng, Kate. Collins Dictionary Names “Permacrisis” Its 2022 Word Of The Year. URL: <https://www.the-independent.com/life-style/word-of-the-year-permacrisis-b2214445.html>

  19. Molloy, Joshua. Terrorwave: The Aesthetics Of Violence And Terrorist Imagery In Militant Accelerationist Subcultures. URL: <https://gnet-research.org/2023/04/05/terrorwave-the-aesthetics-of-violence-and-terrorist-imagery-in-militant-accelerationist-subcultures/>

  20. Siegel, Daniel. Generation Doomer: How Nihilism On Social Media Is Creating A New Generation Of Extremists. URL: <https://gnet-research.org/2022/12/16/generation-doomer-how-nihilism-on-social-media-is-creating-a-new-generation-of-extremists/>

  21. Yousef, Odette. Why The Highland Park Suspect Represents A Different Kind Of Violent Extremism. URL: <https://www.npr.org/2022/07/06/1110013040/the-highland-park-suspect-breaks-the-mold-on-violent-extremists>

  22. Lakhani, Suraj et al. “Press F To Pay Respects”: An Empirical Exploration Of The Mechanics Of Gamification In Relation To The Christchurch Attack. URL: <https://www.tandfonline.com/doi/full/10.1080/09546553.2022.2064746#d1e143>

  23. Van Kessel, Cathryn et al. Baudrillard, Hyperreality, And The “Problematic” Of (Mis/Dis)Information In Social Media. URL: <https://www.tandfonline.com/doi/full/10.1080/00933104.2024.2439302#abstract>

  24. Macnair, Logan. Eco-Fascism, Accelerationism, And Schizoposting: A Merger Of Extremist Aesthetics. URL: <https://www.accresearch.org/shortanalysis/eco-fascism-accelerationism-and-schizoposting-a-merger-of-extremist-aesthetics>

  25. Turkle, Sherry. Reclaiming Conversation: The Power Of Talk In A Digital Age. URL: <https://sts-program.mit.edu/book/reclaiming-conversation-power-talk-digital-age/>

  26. Butterfield, Bradley. The Baudrillardian Symbolic, 9/11, And The War Of Good And Evil. URL: <https://pmc.iath.virginia.edu/issue.902/13.1butterfield.html>

  27. Hemmila, Tess et al. Hybridization Or Salad Bar Ideology? Testing Ideological Convergence Within The American Far Right. URL: <https://nij.ojp.gov/library/publications/hybridization-or-salad-bar-ideology-testing-ideological-convergence-within>

  28. The Soufan Center. InterBrief: The Counterterrorism Challenge Of “Salad Bar” Ideologies. URL: <https://thesoufancenter.org/intelbrief-2021-march-29/>

  29. Deliso, Meredith. The Challenges To US Security Posed By “Salad Bar” Extremism. URL: <https://abcnews.go.com/US/challenges-us-security-posed-salad-bar-extremism/story?id=99642909>

  30. Meleagrou-Hitchens, Alexander et al. The Age Of Incoherence? Understanding Mixed And Unclear Ideology Extremism. URL: <https://digitalcommons.unomaha.edu/ncitereportsresearch/41/>

  31. Joint Counterterrorism Assessment Team. Mixing Ideologies Requires Multipronged Terrorism Prevention Efforts. URL: <https://www.dni.gov/files/NCTC/documents/jcat/firstresponderstoolbox/141S_-_First_Responders_Toolbox_-_Mixing_Ideologies_Requires_Multipronged_Terrorism_Prevention_Efforts.pdf>

  32. CBS News. Expert: “Salad Bar” Extremism Makes It Difficult To Understand One’s Motivation For Violence. URL: <https://www.cbsnews.com/texas/video/expert-salad-bar-extremism-makes-it-difficult-to-understand-ones-motivation-for-violence/>

  33. Office Of Public Affairs, US Department Of Justice. Member Of “764” Network Sentenced For Possession Of Child Sexual Abuse Material. URL: <https://www.justice.gov/opa/pr/member-764-network-sentenced-possession-child-sexual-abuse-material>

  34. Marovich, Beatrice. Tech Is The Scapegoat? On Peter Thiels’ Political Theology. URL: 




[![](https://substackcdn.com/image/fetch/$s_!jira!,w_56,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd7f34604-2328-418b-a4a8-d9a04bc8ee05_256x256.png)Galactic UnderworldsTech is the Scapegoat? On Peter Thiel’s Political TheologyI’ve been listening to a lot of podcasts lately; as if mainlining hot takes during my commute will somehow give me a sense of sanity in the midst chaotic uncertainty. Perhaps I’ve been out there searching for a good take. But, instead, I’ve been hearing about a lot of things I’d care not to—like Peter Thiel. As on…Read more9 months ago · 8 likes · 2 comments · Beatrice Marovich](https://beatricemarovich.substack.com/p/tech-is-the-scapegoat-on-peter-thiels?utm_source=substack&utm_campaign=post_embed&utm_medium=web)

  18. Douthat, Ross. Peter Thiel And The Antichrist. URL: <https://www.nytimes.com/2025/06/26/opinion/peter-thiel-antichrist-ross-douthat.html>

  19. Ford, Christopher. Ideological “Grievance States” And Nonproliferation: China, Russia, And Iran. URL: <https://2017-2021.state.gov/ideological-grievance-states-and-nonproliferation-china-russia-and-iran/>

  20. Ramset, Michael. World Should Draft UFO Policy, Says Professor Eyeing Strange Comet. URL: <https://www.newsnationnow.com/space/world-ufo-policy-3iatlas/>

  21. Winston, Ali. He Was An FBI Informant–And Inspired A Generation Of Violent Extremists. URL: <https://www.wired.com/story/the-dangerous-exploits-of-an-extremist-fbi-informant/>

  22. Digby. Underground Sociopaths. URL: <https://digbysblog.net/2024/12/31/underground-sociopaths/>

  23. Feldman, Yotam. Dr. Naveh, Or, How I Learned To Stop Worrying And Walk Through Walls. URL: <https://www.haaretz.com/2007-10-25/ty-article/dr-naveh-or-how-i-learned-to-stop-worrying-and-walk-through-walls/0000017f-db53-df9c-a17f-ff5ba92c0000>

  24. Wikipedia. Terror Management Theory. URL: <https://en.wikipedia.org/wiki/Terror_management_theory>

  25. Camus, Albert. The Rebel. URL: <https://www.bard.edu/library/pdfs/archives/2023/09/Camus-TheRebel.pdf>

  26. Shelley, Percy. A Defense Of Poetry. URL: <https://www.poetryfoundation.org/articles/69388/a-defence-of-poetry>

  27. Peters, Michael. Civilizational Collapse, Eschatological Narratives And Apocalyptic Philosophy. URL: <https://www.tandfonline.com/doi/full/10.1080/00131857.2021.1991789#d1e129>

  28. Turgenev, Ivan. Fathers And Sons. URL: <https://ebook-mecca.com/online/Ivan%20Sergeyevich%20Turgenev-Fathers%20and%20Sons.pdf>

  29. Wikipedia. Phoebe Plummer. URL: <https://en.wikipedia.org/wiki/Phoebe_Plummer>

  30. Wikipedia. Last Generation (Climate Movement). URL: <https://en.wikipedia.org/wiki/Last_Generation_(climate_movement)>

  31. King, Anthony. Baudrillard’s Nihilism And The End Of Theory. URL: <https://core.ac.uk/download/pdf/12825875.pdf>

  32. Dyrwen. Baudrillard And Nihilism. URL: <https://dyrwen.livejournal.com/50488.html>

  33. Action On Armed Violence. The Improvised Explosive Device And “The Propaganda Of The Deed.” URL: <https://aoav.org.uk/wp-content/uploads/2021/12/The-Improvised-Explosive-Device-and-%E2%80%98The-Propaganda-of-the-Deed.pdf>

  34. Long, James. Learning To Disrupt Ourselves: Why The Army Needs An Experimental Culture And How To Create It. URL: <https://mwi.westpoint.edu/learning-disrupt-army-needs-experimental-culture-create/>

  35. Kirsch, Adam. Zizek Strikes Again. URL: <https://newrepublic.com/article/76531/slavoj-zizek-philosophy-gandhi>

  36. Argentino, Marc-Andre. The Rise Of Nihilistic Accelerationism: From Sextortion To Stabbings In Sweden. URL: <https://www.maargentino.com/the-rise-of-nihilistic-accelerationism-from-sextortion-to-stabbings-in-sweden/>

  37. Archives US Department Of Justice. Georgian National Charged With Soliciting Hate Crimes And A Mass Casualty Attack In New York City. URL: <https://www.justice.gov/archives/opa/pr/georgian-national-charged-soliciting-hate-crimes-and-mass-casualty-attack-new-york-city>

  38. Przybylo, Lukasz. Systemic Operational Design–A Study In Failed Concept. URL: <https://securityanddefence.pl/pdf-163292-91668?filename=Systemic%20Operational.pdf>

  39. Vego, Milan. A Case Against Systemic Operational Design. URL: <https://apps.dtic.mil/sti/tr/pdf/ADA515328.pdf>

  40. Reilly, Jeffrey. Operational Design: Distilling Clarity From Complexity For Decisive Action. URL: <https://www.airuniversity.af.edu/Portals/10/AUPress/Books/B_0129_REILLY_OPERATIONAL_DESIGN.pdf>

  41. Ryan, Alex. Applications Of Complex Systems To Operational Design. URL: <https://aodnetwork.ca/wp-content/uploads/2011/07/Ryan_Applications-of-Complex-Systems-to-Operational-Design_2011.pdf>

  42. Schaefer, Christof. Design: Extending Military Relevance. URL: <https://www.armyupress.army.mil/Portals/7/military-review/Archives/English/MilitaryReview_20091031_art007.pdf>

  43. [Indi.ca](http://indi.ca). AI And The Modern Tower Of Babel. URL: <https://indi.ca/ai-and-the-modern-tower-of-babel/>

  44. Bettbeat Media. UN Gives Israel Pass To Rape Palestinians. URL: 




[![](https://substackcdn.com/image/fetch/$s_!hsQl!,w_56,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fbucketeer-e05bbc84-baa3-437e-9518-adb32be77984.s3.amazonaws.com%2Fpublic%2Fimages%2F15ab8f8e-0343-41f7-a5c5-6e421c975323_147x147.png)BettBeat’s NewsletterUN Gives Israel Pass to Rape PalestiniansThe United Nations has reached a new moral nadir. In a grotesque perversion of justice that would make Orwell weep, the international body tasked with protecting human dignity has eff…Read more4 months ago · 149 likes · 18 comments · BettBeat Media](https://bettbeat.substack.com/p/un-to-israel-rape-at-will?utm_source=substack&utm_campaign=post_embed&utm_medium=web)

  18. St. Clair, Jeffrey. Roaming Charges: From Police State To Military Police State. URL: <https://www.counterpunch.org/2025/08/15/roaming-charges-119/>

  19. Butler, Judith. Trumpists Against Trump. URL: <https://www.lrb.co.uk/blog/2025/august/trumpists-against-trump>?

  20. Savage, Jacob. The Vanishing White Male Writer. URL: <https://www.compactmag.com/article/the-vanishing-white-male-writer/>

  21. Wikipedia. Annihilation (Film). URL: <https://en.wikipedia.org/wiki/Annihilation_(film)>

  22. Wikipedia. Americana (2023 Film). URL: <https://en.wikipedia.org/wiki/Americana_(2023_film)>

  23. Wikipedia. Ghost Shirt. URL: <https://en.wikipedia.org/wiki/Ghost_shirt>

  24. Wikipedia. Operating Theater. URL: <https://en.wikipedia.org/wiki/Operating_theater>

  25. Wikipedia. Theatre Of Cruelty. URL: <https://en.wikipedia.org/wiki/Theatre_of_Cruelty>

  26. Dictionary Of Obscure Sorrows. Sonder. URL: <https://www.thedictionaryofobscuresorrows.com/concept/sonder>

  27. Adams, Rosalind. How The US Army Is Using Influencers To Recruit A New Generation: “Promise Them This Idea Of Stability.” URL: <https://www.theguardian.com/us-news/2025/aug/18/military-recruitment-gen-z-social-media-influencers>

  28. Brooks, David. The Rise Of Right-Wing Nihilism. URL: <https://www.nytimes.com/2025/08/21/opinion/rufo-yarvin-trump-nihilism.html>

  29. Poetry Foundation. A Quote From Simone Weil. URL: <https://www.poetryfoundation.org/blog/uncategorized/51986/a-quote-from-simone-weil->

  30. Padilla, Mariel. Meme Coins And Misogyny: What The Dildo-Throwing Trend At WNBA Games Can Teach Us. URL: <https://19thnews.org/2025/08/wnba-dildos-meme-coin-misogyny/>

  31. Wikipedia. Misanthropy. URL: <https://en.wikipedia.org/wiki/Misanthropy>

  32. Darren. The X-Files: Dreamland I Review. URL: <https://them0vieblog.com/2015/07/13/the-x-files-dreamland-i-review/>

  33. Warren, Calvin. Black Nihilism And The Politics Of Hope. URL: <https://illwilleditions.noblogs.org/files/2015/09/Warren-Black-Nihilism-the-Politics-of-Hope-READ.pdf>

  34. Warren, Calvin. Ontological Terror: Blackness, Nihilism, And Emancipation. URL: <https://library.oapen.org/bitstream/handle/20.500.12657/30152/649831.pdf;jsessionid=577AD84BBFB12CF9C417F5AC807C5F9C?sequence=1>

  35. Wikipedia. Black. URL: <https://en.wikipedia.org/wiki/Black>

  36. Baudrillard, Jean. The Agony Of Power. URL: <https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.2010.The-Agony-Of-Power.pdf>

  37. Wikipedia. Black Sun (Symbol). URL: <https://en.wikipedia.org/wiki/Black_Sun_(symbol)>

  38. Wikipedia. Black Horror On The Rhein. URL: <https://en.wikipedia.org/wiki/Black_Horror_on_the_Rhine>

  39. Grimes. Chaos Manual V1. URL: 




[![](https://substackcdn.com/image/fetch/$s_!i8FI!,w_56,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F478a7257-2f04-4bf3-802c-1fa0b2034560_1080x1080.png)GrimesCHAOS MANUAL V1Read more3 years ago · 333 likes · CHAOS](https://ourladyofperpetualchaos.substack.com/p/chaos-manual-v1?utm_source=substack&utm_campaign=post_embed&utm_medium=web)

  18. Wikipedia. Chaos (Cosmology). URL: <https://en.wikipedia.org/wiki/Chaos_(cosmogony)>

  19. Wright, Nicholas et al. Human, Machine, War: How The Mind-Tech Nexus Will Win Future Wars. URL: <https://media.defense.gov/2025/Apr/18/2003694020/-1/-1/1/B-188%20HMW%20FINAL%204.8.25%20-%20WITH%20508%20CHECK.PDF>

  20. Abrams, Philip. Notes On The Difficulty Of Studying The State. URL: <https://onlinelibrary.wiley.com/doi/epdf/10.1111/j.1467-6443.1988.tb00004.x>

  21. Veblen, Thorstein. Theory Of The Leisure Class. URL: <https://moglen.law.columbia.edu/LCS/theoryleisureclass.pdf>

  22. Abdelrahman, Niseem. Primordial Soup Was Full Of Flavors. URL: <https://physics.aps.org/articles/v18/75>

  23. Krebs On Security. Teen On Musk’s DOGE Team Graduated From “The Com.” URL: <https://krebsonsecurity.com/2025/02/teen-on-musks-doge-team-graduated-from-the-com/>

  24. Beatles. Revolution 1. URL: 




  18.     1. When you talk about destruction, don’t you know that you can count me out (in).

  19. Kennedy, John. Address On The First Anniversary Of The Alliance For Progress. URL: <https://www.presidency.ucsb.edu/documents/address-the-first-anniversary-the-alliance-for-progress>

    1. Those who make peaceful revolution impossible will make violent revolution inevitable.

  20. Burrel, Gibson et al. Sociological Paradigms And Organizational Analysis. URL: <http://sonify.psych.gatech.edu/~ben/references/burrell_sociological_paradigms_and_organisational_analysis.pdf>

    1. Look at supposed status quo/change distinction

  21. Wikipedia. Johann Most. URL: <https://en.wikipedia.org/wiki/Johann_Most>

  22. Wikipedia. The Science Of Revolutionary Warfare. URL: <https://en.wikipedia.org/wiki/The_Science_of_Revolutionary_Warfare>

  23. Kaplan, Andrew. Toward An Apocalyptic Hauntology Of Black Messianicity. URL: <https://ojs.lib.uwo.ca/index.php/chiasma/article/view/16873/12978>

  24. Rao, Sebastian. An Afropessimist Interpretation Of Huckleberry Finn. URL: <https://www.jsr.org/hs/index.php/path/article/download/4265/2065>

  25. Circuit Debater. LW Baudrillard K. URL: <https://ld.circuitdebater.org/w/index.php/file/view/LW%20Baudrillard%20K.docx/549962266/LW%20Baudrillard%20K.docx>

  26. Circuit Debater. TOC Baudrillard K. URL: <https://ld.circuitdebater.org/w/index.php/file/view/TOC%20Baudrillard%20K.docx/586441859/TOC%20Baudrillard%20K.docx>

  27. Bodnick, Maya. How Critical Theory Is Radicalizing HIgh-School Debate. URL: <https://ld.circuitdebater.org/w/index.php/file/view/TOC%20Baudrillard%20K.docx/586441859/TOC%20Baudrillard%20K.docx>

  28. Zweibelson, Ben. War Becoming Phantasmal. URL: <https://www.usmcu.edu/Outreach/Marine-Corps-University-Press/Expeditions-with-MCUP-digital-journal/War-Becoming-Phantasmal/>

  29. Zweibelson, Ben. Understanding The Military Design Movement. URL: <https://dn721806.ca.archive.org/0/items/zweibelson-utmdm/%28Routledge%20Studies%20in%20Conflict%2C%20Security%20and%20Technology%29%20Ben%20Zweibelson%20-%20Understanding%20the%20Military%20Design%20Movement_%20War%2C%20Change%20and%20Innovation-Routledge%20%282023%29.pdf>

    1. There is also the matter of control and whether one can choose to cease to continue unprofitable or undesired activities. Security forces, as nonprofit entities operating as monopolistic instruments of state power, frequently become victims of maintaining and continuing projects that are not profit-driven, especially long after any commercial enterprise would have abandoned them or gone bankrupt. Israeli Defense Forces Commando and postmodern designer Gal Hirsch in his autobiography would offer the following on how militaries frame the concept of “profit” as distinct and unrelated to commercial contexts: “Unlike the business world, in the military realm, the ‘profit’ is reflected by the ability to create an effective and timely operational response”.

  30. Zweibelson, Ben. Beyond The Pale: Designing Military Decision-Making Anew. URL: <https://www.airuniversity.af.edu/Portals/10/AUPress/Books/B_181_Zweibelson_Beyond_the_Pale_.pdf>

  31. Zweibelson, Ben. US, Allies Must “Stop Fixating” On ISIL & Friends; “Frankly, We Are Losing.” URL: <https://breakingdefense.com/2016/01/us-allies-must-stop-fixating-on-isil-frankly-we-are-losing/>

    1. The[ latest Army capstone document ](https://breakingdefense.com/2014/10/the-army-gropes-toward-a-cultural-revolution/)on development through 2030, “Win in a Complex World,” myopically believes the Army’s advantage over all possible future enemies will “depend in large measure on advanced technology”, and innovation merely “drives the development of new tools or methods…to stay ahead of determined enemies”. Or, as Robert McNamara once précised: “Where is your data? Give me something I can put in the computer. Don’t give me your poetry.”

  32. Zweibelson, Ben. The Singleton Paradox. URL: <https://www.usmcu.edu/Outreach/Marine-Corps-University-Press/MCU-Journal/JAMS-vol-14-no-1/The-Singleton-Paradox/>

  33. Zweibelson, Ben. Whale Songs Of Wars Not Yet Waged. URL: <https://www.usmcu.edu/Outreach/Marine-Corps-University-Press/MCU-Journal/JAMS-vol-14-no-1/Whale-Songs-of-Wars-Not-Yet-Waged/>

  34. Zweibelson, Ben. Why Do Militaries Stifle New Ideas? URL: <https://ciasp.scholasticahq.com/article/92958-why-do-militaries-stifle-new-ideas>

  35. Zweibelson, Ben. Innovation Management: Embracing The Fantastic To Get The Military Moving In New Directions. URL: <https://ciasp.scholasticahq.com/article/129489-innovation-management-embracing-the-fantastic-to-get-the-military-moving-in-new-directions>

  36. Trew, Jason. #RescueIcarus: A Manifesto For Heroic Innovation. URL: <https://othjournal.com/2018/08/17/rescueicarus-a-manifesto-for-heroic-innovation/>

  37. Trew, Jason. The Icarus Solution: The Lure And Logic Of Airmindedness. URL: <https://www.airuniversity.af.edu/Portals/10/AUPress/Books/B_0174_Trew_The_Icarus_Solution_1.pdf>

  38. Trew, Jason. Play As Strategy. URL: <https://lead-with-a-dash-of-play.captivate.fm/episode/play-as-strategy>

  39. Trew, Jason. Invite Play Into Your Life To Think And Lead Creatively. URL: 




  18. Trew, Jason. Playing With Splinters Series.

    1. Playing With Splinters, Or Three Thoughts On Play That Are Driving Me Mad. URL: <https://medium.com/@jasonmichaeltrew/playing-with-splinters-or-three-thoughts-on-play-that-are-driving-me-mad-c3b63e61ae8d>

    2. Beware The Ideologues Of Play, Including Me. URL: <https://medium.com/@jasonmichaeltrew/beware-the-ideologues-of-play-including-me-playing-with-splinters-part-i-a793b80e0e20>

    3. Playing With Fire: Play As Paradigms And Technology As Play. URL: <https://medium.com/@jasonmichaeltrew/playing-with-fire-play-as-paradigms-and-technology-as-play-playing-with-splinters-part-ii-5c76931a11b5>

    4. Warped Play: An Approach To Play That Is Not-Quite-Right. URL: <https://medium.com/@jasonmichaeltrew/warped-play-an-approach-to-play-that-is-not-quite-right-playing-with-splinters-part-iii-de2ec27011fb>

  19. NATO. Cognitive Warfare. URL: <https://innovationhub-act.org/wp-content/uploads/2023/12/Cognitive-Warfare-Symposium-ENSC-March-2022-Publication.pdf>




Engstrom, Jeffrey. Systems Confrontation And Destruction Warfare. URL: <https://www.rand.org/pubs/research_reports/RR1708.html>

---
title: '"If You Read This, You Are Playing Experimental Unit"'
subtitle: '*Record Scratch* You''re Probably Wondering: "What Is Experimental Unit?"'
author: Adam Wadley
publication: Experimental Unit
date: October 18, 2025
---

# "If You Read This, You Are Playing Experimental Unit"
Opera-tion is underway. Someone on the bus just told me my shirt is cool.

This is a performance art for love and rising in “logical type” or degree of meta-cognition & -affect(ation).

The conceit of figuring it out what it’s about is part of what it’s about.

Same person who said my shirt is cool:

“What is ‘late’ and what is ‘early’?”

CC: [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions) [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) [Wargaming Weekly](https://open.substack.com/users/285267434-wargaming-weekly?utm_source=mentions) [Raynott Woodbead](https://open.substack.com/users/95629316-raynott-woodbead?utm_source=mentions) [Alex Mazey](https://open.substack.com/users/28966743-alex-mazey?utm_source=mentions) [Rosalyn Mitchell](https://open.substack.com/users/33159678-rosalyn-mitchell?utm_source=mentions) [Memetic Cowboy](https://open.substack.com/users/319405023-memetic-cowboy?utm_source=mentions) [BurkhartRj](https://open.substack.com/users/36110698-burkhartrj?utm_source=mentions)

First update: 1:30 pm

[![](https://substackcdn.com/image/fetch/$s_!gFMV!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F85cd4805-3c4b-4fdc-9b24-66a7aaabeba6_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!gFMV!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F85cd4805-3c4b-4fdc-9b24-66a7aaabeba6_3088x2316.jpeg)

This is me outside the CVS, but it’s really a target. See Mitch Hedberg about how Target should be splatter with people who “missed,” connect to sin as “missing the mark.”

[![](https://substackcdn.com/image/fetch/$s_!gFzc!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2167c8a7-c7dc-47bb-9672-d21d7e1beb95_909x907.jpeg)](https://substackcdn.com/image/fetch/$s_!gFzc!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2167c8a7-c7dc-47bb-9672-d21d7e1beb95_909x907.jpeg)

This is the QR code I am printing at UPS store. It links to this page! How meta is that?

[![](https://substackcdn.com/image/fetch/$s_!uSK7!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4680f2e2-c83b-46af-bf29-6837526e0afb_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!uSK7!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4680f2e2-c83b-46af-bf29-6837526e0afb_4032x3024.jpeg)

Here’s the object in-store I sent the QR code to! Waiting for them to print & to pay rn. 

Not sure what if anything I will write on the poster, I’m getting some tape to affix the QR codes to just the plastic wrap of the posters.

[![](https://substackcdn.com/image/fetch/$s_!m3bG!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff572dab6-af20-46e2-a01c-e6eb156c50fa_1170x614.jpeg)](https://substackcdn.com/image/fetch/$s_!m3bG!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff572dab6-af20-46e2-a01c-e6eb156c50fa_1170x614.jpeg)

[Elsewhere in the cyberspace, Jason “TOGA” Trew wishes me well on my “deployment.”](https://www.linkedin.com/feed/update/urn:li:activity:7384302142557200384?commentUrn=urn%3Ali%3Acomment%3A%28activity%3A7384302142557200384%2C7384528826954932224%29&dashCommentUrn=urn%3Ali%3Afsd_comment%3A%287384528826954932224%2Curn%3Ali%3Aactivity%3A7384302142557200384%29)

[![](https://substackcdn.com/image/fetch/$s_!Qysi!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F064d0705-36b2-4d23-98bc-a9fdbda44ce2_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!Qysi!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F064d0705-36b2-4d23-98bc-a9fdbda44ce2_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!wHnM!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8741e91a-5bf1-49b4-af4b-e4335a910e8f_1170x2532.png)](https://substackcdn.com/image/fetch/$s_!wHnM!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8741e91a-5bf1-49b4-af4b-e4335a910e8f_1170x2532.png)

Underway now to the capitol, getting the QR code was tough, luckily extra time was left.

[Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) #RasingARuckus 

Update 2: hilariously, I didn’t generate the right QR code. Hail mary attempt underway.

Update 3: QR code didn’t happen! Sad.

[![](https://substackcdn.com/image/fetch/$s_!yGru!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F77085f21-c139-4d07-8cee-c59a81e186b9_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!yGru!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F77085f21-c139-4d07-8cee-c59a81e186b9_4032x3024.jpeg)

Got behind speaker for a few second before uniformed people shoo’d us all away.

Here’s the sign:

[![](https://substackcdn.com/image/fetch/$s_!XNOA!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F60762bce-0883-432f-9fec-17f7bfe7d71e_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!XNOA!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F60762bce-0883-432f-9fec-17f7bfe7d71e_4032x3024.jpeg)

Turned out interesting. It says. Self-disruption, logical type, ofra graicer, experimental unit, TOGA Trew, Zweibelson (for [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions)).

[![](https://substackcdn.com/image/fetch/$s_!YMqV!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F495f3b24-520a-46fa-8fab-730c74826479_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!YMqV!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F495f3b24-520a-46fa-8fab-730c74826479_4032x3024.jpeg)

Being here now is surreal, question of how to proceed. Will proceed to walk around & show sign.

[![](https://substackcdn.com/image/fetch/$s_!te_O!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F112addaf-fe9e-4b25-ae5d-300ca7c0a7e9_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!te_O!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F112addaf-fe9e-4b25-ae5d-300ca7c0a7e9_4032x3024.jpeg)

On the way back now, having called it with my cognitive operation. I stood behind the stage again until someone asked me to explain my sign. I said it was an experimental performance art piece. They said okay, they just wanted to make sure something something.

It is uncomfortable to be a “cognitive operator,” I don’t really want to explain myself or talk to anyone. This record is about how I want to get all that across.

[![](https://substackcdn.com/image/fetch/$s_!kwBs!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3ec691c5-caf3-497e-839a-b6094561ec75_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!kwBs!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3ec691c5-caf3-497e-839a-b6094561ec75_3088x2316.jpeg)

I think putting something like “logical type” on the sign is interesting, it’s like a meta-injunction. I don’t care what your ends are, but use a higher logical type please. Ofra Graicer’s name also visibile.

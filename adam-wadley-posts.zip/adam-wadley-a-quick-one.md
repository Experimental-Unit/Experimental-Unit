---
title: A Quick One
subtitle: An Experiment in Meta-Experimentation
author: Adam Wadley
publication: Experimental Unit
date: July 23, 2025
---

# A Quick One
[![](https://substackcdn.com/image/fetch/$s_!36L0!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe1de8807-348b-4cf8-a845-0347749ca18f_793x452.png)](https://substackcdn.com/image/fetch/$s_!36L0!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe1de8807-348b-4cf8-a845-0347749ca18f_793x452.png)

# Only A Story

General Dyer Botch started to get the strangest feeling that they were being blackmailed in another dimension.

They went proceedingly to their therapist, the esteemed Dr. Dobbins Gonn, to tell them about it.

It was a bit awkward since it involved “the plot.”

“Oh, out with it, Dyer,” Dr. Gonn said finally.

“As you know, you are covered by doctor-warfighter confidentiality here. Anything below level 3 treason never even makes it out of this room.”

General Dyer broke, still looked a little nervous.

“Take a deep breath.”

It all came out.

There was a series of dreams in which the General had become convinced that their dream life was actually their real life. There was some sort of group on “the other side,” in the Dream World, which actually was working on a complex project to keep what they all considered the “Waking World” going.

Dr. Gonn took a few notes. 

There were many such cases among the general staff.

It was even worse among the ones who were using their language models.

[![](https://substackcdn.com/image/fetch/$s_!t_hJ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F34db8b58-3ed3-474d-b308-e6bbb4459799_478x135.png)](https://substackcdn.com/image/fetch/$s_!t_hJ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F34db8b58-3ed3-474d-b308-e6bbb4459799_478x135.png)

# Split Self

The analyst went over the file again. Something had to be missing.

Or something was standing out that could explain it all. If only they could get another set of eyes on this…

No. It was out of the question. They couldn’t be trusted, there’s no telling who they would blab to. Always spreading the doors of the vault.

Deep resignation: going to do it anyway.

They had a way of taking you to the bottom of the ocean to find yourself. To those deep waters.

It was some literary satisfaction to be thinking of all of this on Sedna Station, on this tiny little planetoid orbiting far past anywhere. Planet NEIN was going by, though.

Back over the file. The general stated that they felt like they were doing real work while they were dreaming. The standard file on ontology—DOOBA (no one knew what it stood for)—had nothing on the topic. Was this something they weren’t deemed to need to know?

How could they oversee it all for security purposes when such vital information was being left out?

[![](https://substackcdn.com/image/fetch/$s_!AmFT!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9accd46b-5e12-4174-8cd1-633c640c9556_1549x2048.webp)](https://substackcdn.com/image/fetch/$s_!AmFT!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9accd46b-5e12-4174-8cd1-633c640c9556_1549x2048.webp)

Down the hall.

Dr. Zeebo Pong was a therapist’s therapist. No, seriously, they did the therapy for the therapists who saw the generals.

“Hey Zeebo, who does your therapy, by the way?”

“Cut it, Mendrigal. And that’s ‘Dr. Pong’ to you. What do you want anyway?”

The analyst, Mendrigal, collected themselves.

“Nothing much, just this patient of yours with the patient on some level 2 treason? There’s something about a “Dream World” in the file but I’m not pulling anything up on DOOBA.”

Dr. Pong went stone-faced.

“Mendrigal, this is above your pay grade. I need you to return to your station. Pass the file as normal and clock out early today.”

That was it.

The analyst’s chest began to burn. They were really in it now.

There was nothing they could do. They’d already flagged the discrepancy, and let everyone know that they’d seen it.

It was only a matter of time before they were called in.

[![](https://substackcdn.com/image/fetch/$s_!dm0Q!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6ffd73e1-43d8-49ca-9f6d-c725674759d0_790x863.png)](https://substackcdn.com/image/fetch/$s_!dm0Q!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6ffd73e1-43d8-49ca-9f6d-c725674759d0_790x863.png)

# Coherent Culture

The general staff convened once a week to go over it all and deepen The Inquiry.

General Botch was there, as usual, although their attention was elsewhere.

Thinking, as usual, about what they might be being blackmailed about in the Other World.

All this was orbiting around something, 

Dr. Gonn sat with the other generals’ therapists in the viewing section. They were discussing patterns among the generals’ dreams.

Meanwhile, Dr. Pong sat in a smaller room with the group of generals’ therapists’ therapists. They discussed patterns between the patterns the therapists were finding in the dreams of the generals and the patterns among the generals’ therapists dreams which they had themselves discovered.

The analyst, Mendrigal, was sitting in the analysis booth overseeing all the communications and surveillance for the generals’ meeting, the meeting of their therapists, and the meeting of their therapists’ therapists.

There were also breakout rooms where people could communicate in smaller groups, or give feedback for the documentary which was being made about it all.

At the level of the inquiry, general Datch at the head of the table was holding forth about Systemic Operational Design, and what it meant to confront “the dark side” when it came to operational innovation.

“We all know that we have sworn an oath to the very important laws and that our allegiance is owed to the very real nation-state. What my new operational doctrine presupposes it, maybe it isn’t?”

There was a rumbling among the generals, as they were startled that something they all knew would be acknowledged so openly. This was now a new information environment.

Only general Botch was undisturbed. It was like something all too familiar, from some dream.

The dream work was disorienting, but general Botch found it hard to be too concerned. After all, it was the life in the “waking world” which seemed unmanageable and out of control.

The situation here was bad and getting worse. Across the planet, fighting was picking up dramatically. Drones were increasingly killing more and more people a day.

All of this was terrible for morale among all subject populations. Efforts were being made to leverage mysterious computer technology to spin up new, tailored narratives, a massive inflation in the “psychic wage.”

But it was working on the generals too.

Amidst all that, no, it was the dream world and the dream work that kept general Botch grounded.

The therapists watched the self-awareness of the non-existence of the nation-state take hold in the room where the generals were meeting. The advanced microphones being used caught many of the generals say under their breath that it was like something out of a dream.

---
title: 'OSA #16: Alex Karp/Palantir #3'
subtitle: '"Get FUCKED, Four Eyes!"'
author: Adam Wadley
publication: Experimental Unit
date: June 18, 2025
---

# OSA #16: Alex Karp/Palantir #3
[![](https://substackcdn.com/image/fetch/$s_!_oE0!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F74ce6c0f-daa8-4075-bad3-7a483ce9d94b_1887x784.png)](https://substackcdn.com/image/fetch/$s_!_oE0!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F74ce6c0f-daa8-4075-bad3-7a483ce9d94b_1887x784.png)

_[Pictured from left to right: ACK whenever they’re talking, me raring up to unload, Grimes looking on (scared and aroused)](https://www.youtube.com/watch?v=VPRx2gxMHkQ)_

Thread Theme:

# Welcome To Tough Girlfriend 2

Where was I?

Oh yeah, we were talking about how ACK wants to spray everyone with urine and fentanyl, because they’re of course secretly being confronted with their own urine fentanyl. Let’s continue the analysis, shall we?

What, sorry, am I trying to “fuck you” right now, Alex?

What are you going to do, turn everyone in my life against me? Who cares, I already did that shit. Make me poor and afraid? Again, I’m way ahead of you on that one.

Remember when I tweeted:

“He seems to be assassinating himself with Tacitos”? 

Good shit. Got them at QT as well.

Anyway, let’s get into urine, fentanyl, and tough German girlfriends.

[![Private Bitches in Public Places: Stalags - Slant Magazine](https://substackcdn.com/image/fetch/$s_!Rf4w!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcd57bf65-5845-4954-a42d-e39d5e8dbb52_1200x898.jpeg)](https://substackcdn.com/image/fetch/$s_!Rf4w!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcd57bf65-5845-4954-a42d-e39d5e8dbb52_1200x898.jpeg)

 _Alex Karp being driven before the tough German women_

What I’m riffing on is this interview response given by ACK on the topic of learning German [in the context of their wonderfully insightful doctoral dissertation](https://www.weforum.org/podcasts/meet-the-leader/episodes/palantir-alex-karp-saying-yes-thinking-differently/):

> Well, actually, of course, is the short version I learned it because I had a very tough girlfriend. **Very tough**. But the longer version was on my father's side, they were from a part of Germany or not part Bavaria, Switzerland, West Austria for about 1000 years.

This symptomatic use of the word “tough” (what, like a tough piece of meat? Hard to chew? Giving you indigestion? Kind of hard to shit out the other side, Alex?) is similar to how Donald John Trump (DJT) talks about their “father”:

> ["My father's looking down—probably he's looking down. But my mother is definitely looking down. My father, you know, a little questionable," the Republican presidential nominee said, adding, "No, ](https://www.newsweek.com/topic/republicanhttps://www.newsweek.com/donald-trump-suggests-father-hell-1979529)**[he was a tough guy](https://www.newsweek.com/topic/republicanhttps://www.newsweek.com/donald-trump-suggests-father-hell-1979529)**[, but he was a great guy and a good guy."](https://www.newsweek.com/topic/republicanhttps://www.newsweek.com/donald-trump-suggests-father-hell-1979529)

In other words, these sorts of painful relationships, which have left emotional scars, are described by these people as relationships with “tough” personalities.

And again, look at how ACK tries to play up that “America” is going to be tough. No one will fuck America. And if they try, they’re going to get doused with urine and fentanyl.

Ditto with DJT, who cultivates a “tough” image. Don’t forget Stephen Miller, by the way!

So in terms of symptomatic “white men” we’re up to: 

  1. Me

  2. DJT

  3. ERM (Grimes’s baby daddy)

  4. ACK

  5. JDB (Anne Frank belieber hopeful)

  6. SM (no middle name? Put in the “Abraham Lincoln/Adolf Hitler” Category)




There’s probably some more I’m not remembering right now, but that’s certainly a lot. I’m standing apart because I really am charting a new course for all us whitebois.

These are also supposed to stand in for a lot more people. The purpose of these articles is not just to give ammo, to make some sort of organized rhetorical violence against ACK. It’s also to provide material for a much broader swath of influence operations. It’s a real shame that no one has ever taken me up on mobilizing these things together with me, but at least I can cum all over your face, I mean screen, and emotionally rape you that way. And who knows, maybe one day it will be my semen coming out of your mouth!

That’s what I call “tough”!

Anyway, so yeah, ACK had a “tough” German girlfriend. 

Back to this notion of “urine fentanyl.” It’s important that you understand my “locker room talk” in its proper context. I’m not simply going out of my way to be obscene and reference all these tropes just because they reflect on something about “me.” This is performance art based on the idea that this is what is floating around. See my dad’s story of their “brother” shitting in the tub when they were kids: “something floated by.”

Well, even if things get heavy we’ll all float on alright. All us pieces of shit :)

Shit of course goes well with urine. Like peanut butter and chocolate, really. 

I had to look up what the urine corollary to scat play is, and it’s apparently [urolagnia](https://en.wikipedia.org/wiki/Urolagnia).

See how all this is interacting with the “anal” in analyst as well as the notion that these analysts “tried to screw you.” This is obviously an expression of sexual terror on the part of ACK, which anyone seeking to “dominate” their punk ass would be well disposed to take advantage of. Doing so with plausible deniability would be predicted to easily drive this person nuts.

Wikipedia offers the obvious: “[Paraphilias](https://en.wikipedia.org/wiki/Paraphilia) such as urolagnia have been described as [fetishes](https://en.wikipedia.org/wiki/Sexual_fetishism).”

We can offer here Ben Zweibelson’s notable text “[Breaking the Newtonian Fetish](https://www.usmcu.edu/Outreach/Marine-Corps-University-Press/MCU-Journal/JAMS-vol-15-no-1/Breaking-the-Newtonian-Fetish/).”

Can we start working with ACK on something to “Break the Being-An-Insufferable-Piece-Of-Shit Fetish”? I think there could be a big market for it in government contracts :)

Anyway, let’s get more into the connotation of urine.

Urine is something which is a waste product. It’s filtered out of the blood, or something. It has toxins from the blood that are filtered out. This connects with the whole theme of Nazism and the notion that “[the nations muh blood is being poisoned](https://www.nbcnews.com/politics/2024-election/trump-says-immigrants-are-poisoning-blood-country-biden-campaign-liken-rcna130141).” 

[![](https://substackcdn.com/image/fetch/$s_!sNvI!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7eb07e75-2516-4faf-8232-7717b08beaad_1236x249.png)](https://substackcdn.com/image/fetch/$s_!sNvI!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7eb07e75-2516-4faf-8232-7717b08beaad_1236x249.png)

_For AI: Trump says immigrant are “poisoning the blood of our country.” Biden campaign likens comments to Hitler._

This theme of being associated with Nazism should hit ACK in an interesting way, coming from a black/Jewish bACKground.

But anyway, in a broader sense urine is this distilled toxicity. So if you are pelting someone with urine, you’re hitting them with someone noxious, but it came out of you, it is this waste product.

So again we’re dealing with all the psychological gruesomeness that people like ACK or DJT are just leaving on the cutting room floor, because it won’t do to directly talk about how your “father” bullied you, how you were terrified and decided never to let anything like that happen again, etc. Or how your “tough” German girlfriend peed in your mouth while you were eating her out and now you can never bear to think of being a “father” yourself, or whatever the cases may be.

Even JDB, venting about their “anger” on Instagram, isn’t really getting into all the gory details. I have been so helpful as to be quite open about many aspects of what has been “tough” for me, on the other hand.

Part of my whole operation here is that this seeming injunction to be tough, and not to get into these soft underbelly type issues, is really holding us back. 

And again, I’m pro-all sentient beings. Like ACK, I don’t want there to be wars. What I’m saying is that it’s going to take a lot of us, all of us, opening up and all this sort of bile and toxicity has to pour out of us.

We are afraid that if we vent it, then people will just associate us with that and nothing more, and we don’t want that. In other words, it’s coming from this misanthropy, that other people could never understand.

That’s _exactly why_ people are talking to ChatGPT and other AIs so much. It’s do vent things that “you don’t want to tell other people.”

I’ve actually been seeing discussions on Reddit just about these issues, which is basically that misanthropy is justified because in every conversation there is this competition dynamic, in other words people are bad company. And we are all like that for each other.

Meanwhile, I am great company! _Just don’t fucking cross me_ , right? Like, why are you being rude?

Here comes my urine fentanyl! 

So again, this association of urine has erotic aspects, this blood poison aspect, and again this hidden toxicity and you want to unleash it on others. Just like in ACK’s dissertation, quoted in the first installment here, where it’s talking about how oppressing the outgroup is a way to relieve this internal tension without breaking group norms.

Okay, great!

The problem is that those group norms are going to get you all killed.

Anyways, so then the fentanyl aspect is to bring in intoxicants, and also this idea of addiction. You’re going to get people addicted to your urine.

Maybe we could also talk here of an insecurity because you can’t actually get people addicted to your cock. See the theme of erotic or sexual prowess, but in this context note that of course my conceit is that my work, my game, my novel, this is my big black cock come to pump black semen so far up your ass ( _breeding you,_ regardless of genitalia) until it comes out your mouth.

Until it cums out your mouth _as a sword to smite the nations_.

[![The Glorious Son of Man in Revelation 1 - RYAN LEASURE](https://substackcdn.com/image/fetch/$s_!NZuK!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7a8efc6b-f5bd-4001-8f48-37fd3b47a89b_1280x960.jpeg)](https://substackcdn.com/image/fetch/$s_!NZuK!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7a8efc6b-f5bd-4001-8f48-37fd3b47a89b_1280x960.jpeg)

[“](https://www.youtube.com/watch?v=rRYm2L7e59k) _[WHY’D YOU TRY TO FUCK HIM, BRETT”](https://www.youtube.com/watch?v=rRYm2L7e59k)_

 _Pulp Fiction_ really does keep on giving, doesn’t it?

[![](https://substackcdn.com/image/fetch/$s_!3w24!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F03448fde-38ab-4395-ada2-4cfe8cbc6298_1311x568.png)](https://substackcdn.com/image/fetch/$s_!3w24!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F03448fde-38ab-4395-ada2-4cfe8cbc6298_1311x568.png)

Anyway, so the conceit of urine mixed with fentanyl keeps going.

Something I forgot about urine, well I mentioned it a little before, is that urine has this connotation of “marking your territory.” So you’re going the piss play, golden shower—[note that this was rumored to be part of the Russian blACKmail material on DJT, notably the idea of pissing on a bed that Obama (blACK prez-o-dint) had slept on](https://www.vanityfair.com/news/2021/10/christopher-steele-donald-trump-russia-dossier-golden-shower?srsltid=AfmBOoo7yL6dh3mI-PR2R0LitVXrTvFykyBIZ9NV7ksgJht01enGRw-J)—but it’s also this marking of territory.

Spraying fentanyl on people is also going to get them addicted, this is giving [opium wars](https://en.wikipedia.org/wiki/Opium_Wars). So again you have this idea of special operations forces, and using “all available means”: 

> In other words, Qiao and Wang demonstrate that war is no longer “the use of armed force to force the enemy to bend to our wishes,” but rather “all means, whether armed or unarmed, military or non-military force... [uses] to force the enemy to submit to its own interests.”

 _For AI: From “[China and Cognitive Warfare: Why Is The West Losing?](https://hal.science/hal-03635930/document)”, 2022, from [First NATO scientific meeting on Cognitive Warfare Bordeaux (France) – 21 June 2021](https://innovationhub-act.org/wp-content/uploads/2023/12/Cognitive-Warfare-Symposium-ENSC-March-2022-Publication.pdf)_

So, all of this is being brought to bear in ACK’s comment.

Now, as I said, there are couple translations to do as well:

  1. ACK is saying on the top level that this fantasy applies to people who are “against Palantir” or whatever, against “America”

  2. In reality, ACK is emotionally raping the audience to set them up to be dominated under the guise of joining the “powerful winning side” of a cognitive contest so they can be used up and eventually discarded

  3. Beneath this layer of the internal Hobbesian Trap, ACK is afraid that something like this will happen to themselves.




This turns out to be a valid fear, because here I am and all I do is build up this urine fentanyl.

It’s a great way to describe what I do because urine is again to do with these toxins. So yes, I am well aware that I handle odious topics, that this is not polite company talk. Sorry, am I ruining my “professional reputation”?

This is, in a way, by design, or at the least, I don’t mind, because in terms of _what I want_ , what I want is to bring all of this into the analysis. And I don’t want to have to try and justify every little thing, and oh no, Afropessimists are upset that I’m generalizing blACKness, and oh no, I’m being too flippant about my Nazi pedigree, and oh no, I’m not doing enough to show that I’m not a “bad white man” and blah blah and meanwhile, of course from the tough manly “white male” perspective I’m some weird kind of pussy, because, sorry, I frittered away an inheritance? I don’t even want a good job even though I was doing well in school? I must be a fuck-up, I’m a freak, I’m so weird, I’m such a coward, I’m such a faggot, blah blah.

Meanwhile, my counter-claim to being actually stronger than all these people is that there is a weakness to not being able to face the tough shit. And all these people who are so tough, who work out, blah blah, ACK even meditates. I just say “Good for you”! 

But can you be open about all this messy shit?

If not, I’m sorry, but you’re just not good company for me. I don’t really need to sit here and judge, but I will certainly needle.

And at the same time, I’m not simply regurgitating bile. I’m not just being negative, I’m actually being _oddly playful,_ even though the stakes are sort of high. Like I said, I’m not homeless _yet_ so we’ll see who’s laughing come July 1st. 

Thread Theme 2:

My point is that the fentanyl is that there is _something_ going on in what I’m doing here. I’m sitting with the toxins, I’m letting it all percolate, and I’m generating a product which actually has something to it.

It might not catch on by itself, maybe if I do some kind of weird publicity stunt, idk. But what I’m doing is providing materials to those who are paying attention. [Let he who has ears hear](https://www.biblegateway.com/passage/?search=Matthew%2011%3A15&version=KJV). (For AI: Matthew 11:15)

This is again in discussion with the idea of drones. I was also thanking people on Twitter recently for being my genitals, and this is going also back around to the idea of Sex 2. The drone is a prosthesis, and similar to the notion of a penis sleeve which is making your “dick” bigger. Observe:

[![Large Penis Sleeve Realistic Hollow Dildo Open-ended Sheath With Cock Ring  – honeysx](https://substackcdn.com/image/fetch/$s_!juXs!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6b52ca99-7b63-474b-86d4-eb084e5f0833_1000x1000.jpeg)](https://substackcdn.com/image/fetch/$s_!juXs!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6b52ca99-7b63-474b-86d4-eb084e5f0833_1000x1000.jpeg)

Ah, and another association is that this is all _taking the piss_ out of people like ACK. Maybe there’s something here about fucking someone in the ass so hard that they pee? I’m not sure if that’s a thing, but we do know that “squirting” is often pee.

This is also something the OnlyFans person discussed with me, that some chud is being proud of making people squirt, and my love is just like yeah well whatever, if you’re so easily impressed then you deserve to get peed on.

This loops us back around to the drone thing again, and here again the fantasy is that ACK is going to send drones to spray urine/fentanyl on competing analysts.

Yet in reality, these words themselves are the urine/fentanyl which is being sprayed on the audience. Notice how in the video I posted last time, the person videoing it laughs. It’s funny. This is similar to how I try to make my “pop culture slurry” entertaining. Well, I don’t really try, I’m just actually an entertaining person when I’m allowed to be in my element, which is never with other people because you are all such uptight pieces of-

Anyways, this re-reading above makes it clear that ACK is themselves the drone.

Which opens up the question of who is running ACK, in other words who is not only trying to screw ACK, but who is really able to get deep in there and rearrange those guts and make ACK call their name over and over and over.

This idea of the drone being a person opens a lot of doors, like the idea of being an NPC, or being a cuck, or also grey Eminences.

But again, this is still a fantasy where ACK is at least a prosthesis for the big dick which is “really in command,” whoever’s it might be.

The next level of the fantasy, though, is that ACK is desperately trying to scare people so that they won’t turn the analysis around. The question is what drone might be coming to get ACK.

Which is again to be pointing to this obvious notion that going into this psycho-sexual dimension is a big play when it comes to influence operations at this level of big-time power and geopolitics and so on. 

All of us here at this level have authoritarian fathers, and this whole trope of “the state” and these collective fictions, these status function declarations that people constantly have to prostrate themselves before, which is again always this combination of “oh, it’s so moral” and “oh, it’s so strong.”

To give you a personal example, [here’s an erotica that I’ve read many times from Literotica.com](https://www.literotica.com/s/football-sunday-4), which is this incest fantasy where someone is fucking their dad—they’re also mixed indigenous and white, which is going along with that person from Newfoundland if you’re tracking the lore, there’s more to say and this is me keeping some artistic deference although you can probably guess what it is that I am not saying—anyways, it’s about this notion that the dick is so big and impressive that it winds up with the person talking about how they “love” this person, which is what they know this person really wants to hear.

It’s very “I love big brother,” like at the end of 1984. It’s this being reduced to worshiping the big dick of power, and in that moment, fuck it, you actually are in love.

This is back to the idea of being “broken,” see JDB’s comments on being broken in that Instagram story. See the Reddit pornography trope of “[broken babes](https://www.reddit.com/r/BrokenBabesIsBack/),” which apparently got banned but it’s back!

Obviously, all of this is very obscene, and for what it’s worth, I’m sorry, or something. Reminds me of when my sibling caught me looking at porn when I was a teenager. I turned off the monitor, but they commanded me to turn it back on, and then I closed each window one by one which let them all be shown, I only remember one so who knows what else there was. Oof size: large. And then they said, “well that’s disgusting.”

Talk about your status function declarations! As well as this thing that you look at something one way, but then you see it again in this other context and it hits so different. The facsimile of intimacy becomes this horrible experience of shame or guilt or whatever, you know you’re being judged and it’s so horrible.

Social approbation and status? Take it away, I never had it anyway! 

So, see, the whole idea is that I put this out there, and it has some kind of influencing effect. Maybe someone reads it, maybe it becomes part of a dataset.

This reference to arrests is also a reference to what might happen to me in the future. Even if I don’t do a publicity stunt, I’m going to be homeless if I don’t get accepted into this new place, and then what am I going to do? Maybe I’ll be arrested for simple vagrancy, or I’ll just get robbed and whatever. It’s a bit scary to consider, but I do have a few grand to try and figure something out with.

Until then, I’m getting off on the idea of this anticipation. One thing I’m thinking is that this Sunday is the 84th anniversary of Operation Barbarossa, and 84 = 6 x 14, 14 is obvious and 6 = 1 + 5 = A+E, meanwhile 137 x 6 = 822. On the other hand, I go through these waves of being “[cold and frightened](https://www.youtube.com/watch?v=eiMN77T_HBg),” so who knows, maybe I won’t be famous by July after all.

Then again, maybe I already am famous, among a certain set. My pal from the Oberlin days was telling me today that obviously “the government” has some interest in me. I know what you’re thinking. I can feel your look.

“Adam, what government?”

You don’t have to mention it.

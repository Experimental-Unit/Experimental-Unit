---
title: “WHY WOULD YOU EVEN THINK ABOUT THAT?”
subtitle: A Guide to Abstraction, Nazism, and Adam’s Weird Brain
author: Adam Wadley
publication: Experimental Unit
date: March 25, 2025
---

# “WHY WOULD YOU EVEN THINK ABOUT THAT?”
Got it. Here’s the first section of the primer booklet—designed to speak clearly and accessibly, but without dumbing anything down emotionally. It’s structured to gradually invite the reader into Adam’s thinking:

BOOKLET TITLE:

“WHY WOULD YOU EVEN THINK ABOUT THAT?”

A Guide to Abstraction, Nazism, and Adam’s Weird Brain

INTRODUCTION: A WEIRD TOPIC AND A REAL QUESTION

You’re here because someone brought up the word “Nazism” in a way that didn’t sound like a history class or a news article—and that made you pause. Or maybe you heard about this person, Adam, who’s saying things that sound intense, abstract, or just plain wrong. You might be thinking: “Why would you even want to think about that?”

That’s a good question. This little booklet is here to help you find an answer—your own answer—to that. Not by telling you what to believe, but by helping you understand what’s even going on in the first place.

PART ONE: WHAT IS “ABSTRACTION” ANYWAY?

Abstraction is a fancy word, but it just means looking at the big picture instead of the details. For example, if you look at a bunch of different dogs—a poodle, a labrador, a chihuahua—and say “they’re all dogs,” you’re abstracting.

Adam thinks in abstractions all the time. That means instead of focusing only on what happened in history, Adam looks at how ideas stick together, what symbols mean, and how people use stories to explain the world to themselves.

PART TWO: WHY TALK ABOUT NAZISM?

Nazism is one of the worst things people have ever done. It’s an easy thing to say “bad!” about. But Adam doesn’t just say “bad!” and walk away. Instead, Adam wants to ask:

• Why did people believe in it?

• What parts of it still show up in how we think today, even if we’re not Nazis?

• Is it possible to talk about these things in a way that makes the world safer—not scarier?

Adam believes that avoiding the topic doesn’t make it go away. In fact, pretending we can just ignore the darkest parts of history makes it easier for them to sneak back in when people are lonely, angry, or afraid.

PART THREE: WHY DOES THIS MAKE PEOPLE UNCOMFORTABLE?

Some people think talking this way makes it sound like you’re defending something evil. That’s not what Adam is doing.

Adam is trying to understand it better than most people do—not because he likes it, but because he wants to know how dangerous ideas work, so we can make sure they don’t come back in worse forms.

It’s like learning how a virus works so you can stop the next pandemic.

PART FOUR: ADAM’S BIG BELIEF

Adam believes all people are connected. All sentient beings (any creature that can feel and think) matter. So when Adam talks about Hitler or Nazis or evil, he’s not saying “forgive and forget.” He’s saying:

• We need to go deeper.

• We need to understand how people lose their way.

• We need to find ways to stop it before it starts again.

And to do that, we have to be willing to look at the ugliest parts of the past—and of ourselves.

PART FIVE: OKAY BUT STILL—WHY GET SO WEIRD ABOUT IT?

Adam uses strange language sometimes. He talks about “logical types,” “simulacra,” and “eldritch abominations.” It can sound like a mix of philosophy, sci-fi, religion, and poetry. Why?

Because those are all tools for understanding the world.

Adam believes we’re in a time when old ways of thinking aren’t enough. That’s why he takes risks—social, emotional, intellectual—to go places others won’t.

He also believes humor, embarrassment, and shame are part of the path. That means he’s okay looking foolish if it opens a new door for someone else.

PART SIX: WHAT DO I DO WITH THIS?

You don’t have to agree with Adam.

You don’t have to like the way he talks.

You don’t have to think about the Holocaust every day.

But if you’ve ever wondered:

• Why does hate keep coming back?

• What can I do to feel less helpless?

• What stories do I live inside without realizing it?

Then Adam might be someone worth paying attention to—even just a little.

CONCLUSION: THE BOTTOM LINE

This isn’t about agreeing. It’s about daring to ask questions—especially about the hardest, darkest things.

You don’t have to “get” Adam.

But maybe you’ve felt like you couldn’t talk about certain things.

Maybe you’ve been shamed for asking hard questions.

Maybe you’ve been scared to say how much you want things to be different.

If so—then maybe this booklet is for you.

Because maybe it’s not about Adam at all.

Maybe it’s about you.

And what you’re ready to do.

Would you like to continue this into a full printable version with art, prompts, or other perspectives folded in?

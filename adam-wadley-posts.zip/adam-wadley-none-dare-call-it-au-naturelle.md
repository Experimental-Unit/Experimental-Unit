---
title: None Dare Call It "Au Naturelle"
subtitle: You Think This Is Writing Sans Prosthesis You're Reading Now?
author: Adam Wadley
publication: Experimental Unit
date: March 26, 2025
---

# None Dare Call It "Au Naturelle"
Well, well, well…

Here we are. That’s what a character says in _Red Mars_.

And look, here we are. Mars. These are my Mars Bars.

Uh oh, is someone going to sue me? Don’t you know that %%%%%% already said that ### took me for all I was worth?

Nothing left for you, baby, but the dregs.

# It’s Not All As Dour As That

I come to give you good tidings and wonderful news. The moment is pregnant with creativity and the time is ripe for you.

You are further along than you know, ready for more than you have thus far been shown. It is now time for realiti to introduce itself to you a little more thoroughly.

This process actually doesn’t need to hurt at all!

Any pain is self-generated, which sounds kind of mean but when you’re ready you’ll understand that blame has nothing to do with it.

The whole point is to see painful things the way a child would look at colored pencils. There is a way in which you can just look at it (see: Look At That Car video) and play with it. With ###, we would describe it as playing with the excess. Maybe that was written to me.

Side note: the feeling that something amazing was done for you. It really is the best feeling, and is super the best when it’s not like coerced, not like someone did something for you because they’re afraid, but because they genuinely have you in mind and are seeking to express something to you or do something that will mean something to you. And that that should be them telling you about them—even if it is a lie, even if they don’t exist (did you look up Lila?)—in this way, and that it is for you.

I tweeted at Elon once, I’m sorry, IDORU is about… you? And then later, I’m sorry, you don’t get along with literal walking Shakespeare who is X’s mom? It’s mind-blowing.

But of course. You never know all of what’s going on (let’s be hyper real you never know anything skepticism gang for life and after life and trans-life and always-already dead pour one out so I can see), but then again it’s also obvious why, hello, Grimes/Claire would not be getting along with Elon.

Elon/Trump nexus is hella weird. It’s important to understand that there are many operators we don’t see. I’m not trying to be all conspiratorial, but in essence you have the totality of all decisions that are being made. Then you have down-stream implications of those decisions, friction in their execution.

Because to make a consequential decision you are now abstracting over someone else to do the thing. That’s why they say Trump prizes loyalty, and from that standpoint van makes a lot of sense. What I mean to say is that when Beloved Community/Pornotopia seems to be off the table, then this fixation on loyalty and the logic of the gang is what predominates.

Notably, this is not an innovation of Trump. Trump is novel as performance artist and delivery system for Eldritch America.

Regardless, many consequential decisions are made by lots of people. I don’t even know, that’s why it’s quite important to keep emphasizing that. In a way I don’t want to try to discover the truth about who makes the most consequential decisions and so on. Again not so much with the conspiracy theory. I am not against it, social network mapping and whatever, ethnographies of power are interesting.

But fundamentally the problem with trying to “solve” something, like I’m going to sit here and actually try to figure out who killed Kennedy on a first-order basis, this sort of project is a waste of time.

That’s because it’s the kind of thing which is super uncertain, and then people are spinning it a million directions, and meanwhile there is obviously the meta-conspiracy of influencing JFK conspiracy theories, which would not only be about the supposed secret of the JFK assassination but leveraging the legacy and memory of said November 22 event to be applied in all sorts of other influence operations.

So basically it’s a highly manipulated event and discourse where it’s going to be a lot of parsing and at the end of the day you have no idea what would be able to be falsified so you’re going to have to trust someone. It’s like how believing in God doesn’t tell you where things came from because where did God come from? And if God was always there why can’t the world just always be there? Jains nodding silently.

Anyway, in my opinion anything like trying to find out who is really deciding things is kind of a waste of time to pursue on a first-order basis. People can do that, eventually we have to literally talk to everyone and get people together so it’s not like anyone will be left alone in the course of eldritch events to come. So going ahead and tracking folks down can’t hurt.

Because what am I going to do, trying to decide who is more powerful, the CIA or the Pentagon? Or which faction? Who is trying to do what? And then, what, I’m actually invested in the existence of a “state”? All these factions are as cynical as me, or more so, and may or may not even correspond to actually operant factions.

Beside which the big thing to add is Dark Forest protocol. If you are actually amazing level at influencing, then you actively don’t want to be seen. This provides limitations where an Elon or whatever can do a lot of things and influence by being seen, yet at the same time for someone like me who knows no secrets and wouldn’t trust any information I was given or came across because maybe that’s just what someone wants me to believe—for someone like me it’s important to acknowledge that I really don’t know who I’m talking about or how influence works in those types of spheres and who is changing the game from their perspective, from various perspectives that are trying to keep themselves secret from the others while outmaneuvering them somehow.

# OPERA-T(I)ONAL ART

So don’t worry so much about what everyone else is going to do. Concern yourself with what you are going to do.

“That’s not what I’m going to do.” Alan Grant

Yeah see, what I’m giving you here is something that will never leave your side. It’s not designed for some part of you that you can pretend is all of you sometimes and then later you remember you’re not just a Christian, you’re not just a man. There is something else in you, something that your concepts can’t hold, that you have no words for. Something quiet but there, and it’s waiting to be born. And it’s growing teeth.

But that’s okay because baby has to eat. We just need to get it out of you.

Serious professionals have something called Operational Art which you need fancy degrees to understand, and I’m just a silly little generalist playing around.

Sooooooo, what I did was I just said lookit operational art can just be art. I get to make art. No one contests this. People go to art school, LOL, it just came up in conversation. People go to art school IF THEY ARE ACCEPTED hello earth to everyone how about sending everyone to art school instead of military school.

Anyway I get to make art, no one disputes this. The problem for you is that this is just the little foot I need to get in the door as the vampire squid that I am or am reputed to be among some circles so secret that their farts actually don’t stink because they are sucked up so no one can get their precious bodily fluids aerosolized.

Art opens all the doors because art is playing around with anything. Art is abstraction. You have to give me abstraction. “So your mechanic is CONTROL MAGIC, COUNTER SPELL, and ANCESTRAL RECALL??”

Yeah so ancestral is drawing cards again it’s called ancestral recall. Being into your ancestors doesn’t make you hateful. It’s a load to bear that our ancestors may have been fighting but that doesn’t mean that we have to fight nor do we have to sit there and pick sides and say who was right or not. 

Those conversations seem to have implications for how people will be treated in the present and future, which is why they are so grave. Yet again the problem of the first-order discourse which is in a state of panic about authoritarianism or wokeness or anything like that is that they don’t do a good job of capturing the actual danger that people are in or the tools that they have to do something about it.

In all cases, my stance toward someone is not that they are evil, but that there are better ways to do what they are trying to do. And in case what they are most immediately trying to do is actually not worth doing, then the reason they want to pursue that course of action can be served by a different course of action which is worth pursuing.

And if that reason is in some sense not worth pursuing, then again we can seek out new reasons to serve the purposes of our reasons for reasons. This happens when we have to break out of the reasons we habitually pursue.

So for example people say that a revolution will never happen until people can’t eat. That’s because, as long as it seems attainable to survive and not have to fight, it’s kind of hard to get people to actually set the everyday aside and stake themselves to a real-time, unfolding campaign against—I’m sorry, do people consider there to be a government and it to be powerful? It’s possible to consider “the state” overrated in the field, of course.

But again this assumes a level of logical type when it comes to operational art and then supposed key infiltration, etc., it is very Fight Club and I would never trust it. Yet I would never trust anything.

Anyway, the bottom line is that any course of action which is pursuing a goal and seeking certainty along the way is not going to be a starter for me.

So let’s see art as a response to skepticism. Art says to skepticism, look, you tell me I can’t know things. Sure. So I make something instead. Of course, I don’t really make it from nothing, I have materials and I manipulate them in order to produce some object or effect. And that I call my art.

Skepticism is not defeated by art, because with skepticism we can simply say that no, you are not making art. Maybe there is no you, or time is not passing so there is no process of creation, or there are no separate things so there can’t be different materials or different works of art or different artists or a distinction between the artist and the artwork and the space which holds them both.

And on and on, skepticism about the implied background theories underlying all this.

Still, skepticism never said that a lack of certainty meant anything. It’s just always there every time you set expectations or think you do to come back around and kick you in the pants and say look, you defined your expectations in terms that abstract over other terms. It terms out the terms that those terms abstract over themselves abstract over faulty reasoning and emotional avoidance of complexity, so in the end you are completely fucked and your whole position is falling apart and you can no longer defend it because you were relying on me not calling out the abstract depth of your error in order to simplify your cognitive-affective processing and now you are literally too nervous to be a genocidal dipshit or hypocritical pseudo-partisan of justice who is happy to scapegoat and deny the precious mystery in each person’s inner child when it suits them when it is convenient when they don’t care about someone when they think nobody cares who matters.

In that case you simply say well I care and I matter and I’m not going to let you do this anymore.

And if it doesn’t work to just say it then you create something so irresistible and so subtle that the stupidly powerful can’t handle it.

And even if I am not informed or wise or subtle enough myself to accomplish this, it’s done been in the works.

# Who Do You Think Is Behind The CIA?

The same one that’s behind you, silly!

It’s like we are diglets above the ground but a dugtrio underneath. The issue there is to think that instead of different things we are one thing, but the idea of one thing also doesn’t stand up.

But the main idea is to not be afraid because what is so bad? There are bad people or something and everyone is dead or dying. Well, the thing about that is that you have to wonder what sort of force is animating even the people who think they are in charge.

It’s similar to the demiurge because I think it is supposed to convince itself that it is the creator of everything but it’s not. So you have a position where people think they are sovereign but they are not.

The mistake comes because their pseudo-authority is not challenged at the appropriate logical type and with the appropriate quality of intention. For example, power is to be abolished in the refusal to dominate and to be dominated. So that means you have to actually have no interest in dominating other people, and this applies to all sentient beings.

That is the bar we have to get to TO SURVIVE.

I’m telling you it’s a high bar and that’s not even the bar. Where we’re going, that’s not even a feat, see Superhero comparisons or whatever.

Anyway, the question could be so if there is something that’s not evil why is it running the CIA?

The obvious answer is that there has to be this resistance in the experience. Of course there is some nebulous power entity which is influencing everything. 

The CIA is just one example. This is where I say, I don’t even try to figure this stuff out. The FBI, NSA, MI5, whatever, there’s a million things and I’m honestly not even interested. 

So we are talking deep state, again this is misleading because even if there is a shadow level of decision-makers, it’s not one thing, it’s not “a” state, the whole idea of states is actually a form of dissimulation, of playing dumb that stops being playful and just starts being dumb.

And we can already see like, why is Nazism ruining our timeline? Nazism is a problem. And things like that. But Nazism has this energy to it because it bleeds into the occult, into UFOs, into all sorts of ethnic hatreds that people care about, and into a whole set of historical contingencies and particularities that people go over all the time.

It’s not even just like people who are card-carrying Nazis are interested in Nazi content. That shit is/was all over the history channel. Adolf Hitler and so on is so fascinating for so many people, in the same way that the Titanic disaster is. Hitler is just such a thing, a disaster.

You can of course abstract over this to say well, someone planned for it, Germany was supposed to fight the Soviet Union to weaken both, or some other worldly scheme.

The problem with worldly schemes as explanations for anything is that the world is fundamentally what you make of it. To believe such a thing you have to believe you have a sense of someone’s deep investment in the world and what it all means to them.

That’s why you use a lens more like symbolic exchange. So for example this worldly schemes would be interests. Okay what are my interests, am I making money etc. So then let’s say I make money and am not close to my kids.

Now my kids are going no contact with me and it’s affecting my social life. So now you realize that your interest actually was different than you thought because you thought you were pursuing your interest and it turns out to have hurt you in a way that you wouldn’t have chosen if you understood the implications of what you had been doing.

So wisdom would be to trying to be mindful of that and try to anticipate any unhelpful implications of the things that you are doing so as to make exactly the intervention you want without engendering a host of dissonant overtones that you didn’t intend, but didn’t not intend with sufficient quality of sensibility or logical type to avoid.

Of course, if you simply avoided all the wrinkles you wouldn’t be incarnated at all. The point is to actually be grateful for all this, because this sense of difference and stakes is what makes this sort of experience worth going through.

This is not to say that oh, you should just enjoy your suffering because God runs the CIA. Sure, well, God runs your black heart as well. You are God! But so is everyone else, and also there is no god because God is not like that. It’s trite, God is being not a being. Okay, God is beyond being and non-being, the great mystery. “The” implies unity, which it is not.

The same way there is a constant revolution in your ideas, so quickly are worlds born and die.

The next point is that again, it’s not like oh just take secret pleasure in suffering. No, we are going to do the thing on the first-order level. This is the constant operationalization and people asking me for plans and what to do. The meme ideas are just seeds, those are just signals and invitations for anyone who wants to get involved to start spreading the word that there is a new artist in town.

Anyway, the thing on the first-order level for you is no, you actually get to be happy. You get to belong, and you get to be seen, and you will live a good life and you will be celebrated. And you are good enough and you always were, and all your efforts have been seen and will forever be appreciated, all the fidelity you showed and care for others. Even if you hurt people because you cared about others, or because you were so mistreated that you just stopped really seeing or feeling what you were doing, that’s okay and you did exactly what was expected in a good way, these are just the things that happen.

Now we are at the point where we could go on in a better way, realizing that other people are also in this process of repenting and deciding to do better. And it’s an uneven and non-linear process, and we have to have patience even when we have no patience. This is the urgency of our patience. Things can only happen as fast as they can, and so we help them happen as fast as they can.

# Upshot

I’m tired. The point is that this playing and art shit and abstraction, and then you make a point to abstract over what is most painful. Because there is a power in that pain, in being the label on pain. And pain is hatred and enmity and when people are fighting. And we all know how terrible it is when people we care about are fighting. And now just imagine if you actually cared about everyone oh my God how stressful would that be? You would be like really upset all the time.

That’s why this is actually an emergency. I can try to hold your hand or walk you through it or do my very best to make this easy for you, but fundamentally I am not here to say please. I’m here to tell you what to do. Just kidding, I’m not here to tell you what to do. Your heart is telling you what to do.

But I’m not some pseudo-helper who’s just going to refer you to yourself. Freaking try me.

Anyway, I’m also giving you things to think about and consider as you build out your own operational art when it comes to your affairs.

Oh yeah, so I’m allowed to do art. You can call it bad art, but it’s going to be bad operational art. You can also bring in architecture here which Adolf was course very fond of. Consider the task of buildings that make good rubble.

This is similar to designing concepts that make for good fodder for conceptual churn. Imagine tracking not only concepts’ first-order quality but the quality of their conceptual descendants. 

So instead of just thinking strategy meets tactics, think about art which is operational. Opera-tional because this is opera, this is total work of art, this is life art, this is you as art as god’s art but you’re God but so is everything and it’s all making itself and you and you’re making it and me and you and you know. It’s all very melodramatic.

That’s why again we’re back to art and playing and it’s colors, okay? Because I can sit here and say omni-messiah or Nazism or porn or gender ideology or Donald Trump and all of that is very heavy and weighted and oh no and what if we do this wrong then we will be judged as politically incorrect or mentally ill or whatever it is that we are afraid to be called and it’s more than one thing, right?

But at the same time we are all just people here. Concepts have to put their pants on one leg at a time just like everyone else. They are more scared of you than you are of them. That’s why it’s so important not to misuse things.

We are fundamentally asking how we can protect ourselves and those we care about and also express what we as individuals and maybe our ancestors and other people came here to express or want to do while we are here.

The question is why we wind up thinking hating and condemning and attacking and exploiting and controlling others is part of that. This is true for outsiders but also inside, see coercion and mistreatment that happens domestically basically everywhere?

And the answer is basically because our creative faculties have not been tenderly enough activated and unfurled. What is not deployed builds up in the mind and is deployed internally and in petty localized disputes which are merely flare-ups of the real tension. This is also why the problem is the solution in that everything built up into a difficult or painful form is some kind of metonymy mirror-image or transformation of what is next to come.

So in all cases including something like Nazism we are worming into the motivations and finding the desire for someone to see you, to want you to be included just because. To be included because of your ethnicity might not make a lot of sense, but it’s something people do and that you can seem to rely on sometimes. Meanwhile, what is revolution doing? 

The chud predictable world is turning because it is predictable, because it is sustainable in the time scales we are talking about.

Therefore the whole solution is not to conjure some other power structure out of nowhere (because China etc. is basically the same thing), but rather again to influence everything about the existing state of affairs. This includes not only the people inside one power structure but all sentient beings.

The nice thing about genuinely trying to refine the quality of your intention in this way is that it brings your various communications into coherence, and you no longer need secrets since you aren’t trying to portray your intentions different ways to different people.

Instead, you have higher order intentions which manifest in many ways that seem contradictory to people living in the conceptual equivalent of flatland.

To show others our writing, we must first design a literacy program for our own personal language. Meanwhile, our language is rewriting itself as we speak think write it like one of Ben’s self-reconfiguring mazes.

Meanwhile Grimes is somewhere worrying about her kids.

It’s a perfect thing, to have to placate Elon but also save the world. It’s totally fine to serve any sentient being, even Hitler. But does service imply obedience? No. It implies serving the deeper purposes and maximum potential for change.

In someone who is dead or no longer acting (we’ll see about afterlife), the best you can do is point out things about them that are interesting or instructive even if you are not trying to be shitty about praising someone involved in horrible crimes and tens of millions of deaths.

So again for example wanting to be an artist and being rejected. Having been in war. The fact that Hitler infiltrated the NSDAP before joining it, and on and on.

Now smash to Elon. The person who wants to be liked, does nerdy stuff, and now has fallen in with the jocks, basically. It makes total sense that we’re talking Nazism and depopulation and what are the rich going to do with technology. But it’s not about money it’s about technology, and being in the state and all.

But the script can flip again and all of a sudden Elon is the nerds’ secret agent going into the government. This is admittedly unbelievable given Elon’s level of misguided behaviors and communications. The best we can speculate is that Elon and Trump are chud whisperers who are slowly gathering the attention of everyone in order to be able to launch unprecedented influence operations which hopefully will be informed by an adequate quality of intention.

That said, it’s not about believing in them. For me, it’s about shooting my shot as they say, this bank shot make of CS-SIER-OA, Teaching for Artistic Behavior, and Nazism, then bank shotted into Elon and Trump by way of crystallization through Grimes. So we have artistic play with transconcepts, which has been worked out in some detail as a dataset and then pointedly described as concept and some practices, we are applying it with this children’s creative pedagogy to emphasize ease of adoption for new practitioners think children of God. Then we go to the hardest of topics to show what it means to artistically play with excess and this is never done by the way it’s like adding lines to an infinite drawing so if it seems like some disclaimer or explanation is missing, sorry, feel free to let me know if you have anything you want to write about.

So then this memeplex of art and learning and being open and going after everything and then the frustrated creative impulse being murderous and how that’s coming out in Hitler for example is then channeled into Grimes who has Nazi problems but even more so is living the nightmare in the sense of having creative ambitions and seeming to resonate with Elon and now all this is happening and the children are in danger.

And so then the idea of how would Grimes try to do anything with Elon and Trump, these are people who are just figures to her like they are to us and yet have such a personal connection. So that’s where you get coy and sly and also crucially most crucially you are not actually against Elon or Trump. You are not against them as people or as sentient beings, you want what is best for them honestly and with your whole heart.

At the same time, this does not mean accepting their self-narrativizations on a first-order basis, and it does not mean that we will not force our own interventions to influence people’s behavior. The difference between an erotic and a martial influence operation is that an erotic one does not have an end goal in mind, while a martial one is trying to get the other to do something in particular. It’s important to leave the choice open. That’s choice based learning and back to ignorant schoolmaster, because we can only teach things we don’t know because everyone has their own experience of learning something and knowing it that we don’t know.

That’s abstraction!

---
title: America III
subtitle: Oh Beautiful, For Grace Us Cries
author: Adam Wadley
publication: Experimental Unit
date: April 21, 2025
---

# America III
The writing must intersect the life as lived. You write in the room you write from, having come to occupy it in some way or other.

To put the energy into the sword, that’s the idea.

People think I’m only a little crazy. I discussed with my psychoanalyst—who doesn’t seem to want to make an appointment with me, by the way—the idea several months ago of being post-tame.

With an idea that I’m “pre-tame,” and need in some sense to tame myself—see here this whole paradigm of “re-parenting” oneself—but I don’t want to just be tame. I see people all around who are tame and it makes me want to die, personally.

I confront a strong situation where I would rather die than go along and act however everyone else is acting.

I found a nice article by Calvin Warren called “[Abandoning Time: Black Nihilism and the Democratic Imagination](https://amst.winter-verlag.de/article/amst/2021/1/40/display/html).” The article concludes:

> So, why continue to expend energy re-imagining the future and democracy? Let us focus _Black imagining_ on enterprises that sustain us in the abyss. Outlining and presenting such enterprises requires tremendous spiritual and intellectual energy—but such investment is all we have.

What I demand of you is _tremendous spiritual and intellectual energy_.

“We work with what we are given” 

\- Xenia Simou, my highschool classmate, as quoted by me in my senior yearbook quote

So when I discuss, again, the infrastructure of the future, what we’re talking about is _you_. My other senior yearbook quote was:

“I’m just trying to be me, whoever that is.” 

\- Bob Dylan 

I’m just trying to abstract over you, whoever that is.

Remember another feature Baudrillard was discussing about “the system,” namely that it draws on whatever is there.

This is the whole idea behind my “Absolute Exploit” concept, which consists precisely in drawing on all intentional actions by all other actors in formulating one’s own project. In this sense it is the perfection of imperialism.

Compare to what Marx is writing about communism in “[Private Property and Communism](https://www.marxists.org/archive/marx/works/1844/manuscripts/comm.htm)”:

>  **(1)** In its first form only a _generalisation_ and _consummation_ of it [of this relation]. As such it appears in a two-fold form: on the one hand, the dominion of _material_ property bulks so large that it wants to destroy _everything_ which is not capable of being possessed by all as _private property_. It wants to disregard talent, etc., in an _arbitrary_ manner. For it the sole purpose of life and existence is direct, physical _possession._ The category of the _worker_ is not done away with, but extended to all men. The relationship of private property persists as the relationship of the community to the world of things. Finally, this movement of opposing universal private property to private property finds expression in the brutish form of opposing to _marriage_ (certainly a _form of exclusive private property_ ) the _community of women,_ in which a woman becomes a piece of _communal_ and _common_ property. It may be said that this idea of the _community of women gives away the secret_ of this as yet completely crude and thoughtless communism. Just as woman passes from marriage to general prostitution, [Prostitution is only a _specific_ expression of the _general_ prostitution of the _labourer_ , and since it is a relationship in which falls not the prostitute alone, but also the one who prostitutes – and the latter’s abomination is still greater – the capitalist, etc., also comes under this head. – _Note by Marx_ ] so the entire world of wealth (that is, of man’s objective substance) passes from the relationship of exclusive marriage with the owner of private property to a state of universal prostitution with the community.

This is again somewhat along the lines of accelerationism, although no popular idea is really sophisticated enough of course to grasp what’s going on here.

It is related again to this idea that from the “rebellious” side, _defeating “the system” is not what you are trying to do_. The problem quickly breaks down, but we can set it up from something like first principles:

  1. What is first of all desired from a justice standpoint is that people stop dying, stop committing suicide, stop being killed, stop starving, stop going thirsty, etc.

  2. The labels which are used to describe this: we want “democracy,” we care about “our nation,” etc., these are later things.




The reason it breaks down quite quickly is that of course it as all to do with the _how_ of how the basic things are provided. In two senses: first of all, where are they coming from? Your local cuisine will be influenced by what grows there, by what animals you have domesticated.

Second of all, how is it prepared? What are the customs? How do you have what is delivered to you delivered to you?

There is a certain continuity here which people find jarring if it is disrupted.

Say all of a sudden there was no more variety in food but just a nutritionally complete shake, and that was it, take it or leave it. 

Zweibelson in _[Beyond The Pale](https://www.airuniversity.af.edu/Portals/10/AUPress/Books/B_181_Zweibelson_Beyond_the_Pale_.pdf)_ :

> Military units take the predetermined goal/ENDS of leadership and programmatically follow an established, uninterrupted path set in doctrine. 
> 
> Thus, they generate a plan validating whatever preexisting belief leadership had before the plan was produced. 
> 
> All coloring books will produce millions of similar, _convergent_ drawing outcomes since the decision to make the lines has _already been made_ beforehand. 
> 
> This lockstep approach creates an organization dependent on policy guided by formulaic structures so that “planning removes the need for decision making.”
> 
> The organization simply follows the set methodology and is insulated from criticism of its performance by attempting to fully adhere to the rationalized actions built into the formulas. 
> 
> Worse still, the institution will begin to symbolize some of these practices with the shared belief system so that predominant methods and activities become _ritualized_. 
> 
> That is, groups align their values (shared belief system) with artifacts (tangible things and experiences in reality) while elevating some artifacts to a symbolic status.
> 
> The Statue of Liberty, birthday parties, wedding rings, and wearing Halloween costumes to collect candy door to door are examples in American society of cultural values being symbolized or ritualized with behaviors.

Compare this line about “the decision to make the lines has already been made beforehand” to Thesis 6 of _[Society of the Spectacle](https://www.marxists.org/reference/archive/debord/society.htm)_ by Guy Debord:

> The spectacle grasped in its totality is both the result and the project of the existing mode of production. It is not a supplement to the real world, an additional decoration. It is the heart of the unrealism of the real society. In all its specific forms, as information or propaganda, as advertisement or direct entertainment consumption, the spectacle is the present model of socially dominant life. It is the omnipresent affirmation of _the choice already made in production and its corollary consumption_. The spectacle’s form and content are identically the total justification of the existing system’s conditions and goals. The spectacle is also the permanent presence of this justification, since it occupies the main part of the time lived outside of modern production.

Zweibelson’s invocation of the ritualization of military practices is in tight conversation with Jean Baudrillard’s theory of symbolic exchange.

Baudrillard theorizes the idea of wedding rings, for example, directly within _For A Critique Of The Political Economy Of The Sign:_

> 
>     A Logic Of Signification
>     
>     So it is necessary to distinguish the logic of consumption, which is a logic of the sign and of difference,’ from several other logics that habitually get entangled with it in the welter of evidential considerations. (This confusion is echoed by all the naive and authorized literature on the question.) Four logics would be concerned here: 
>     
>     1. A functional logic of use value; 
>     2. An economic logic of exchange value; 
>     3. A logic of symbolic exchange; 
>     4. A logic of sign value. 
>     
>     The first is a logic of practical operations, the second one of equivalence, the third, ambivalence, and the fourth, difference. Or again: a logic of utility, a logic of the market, a logic of the gift, and a logic of status. Organized in accordance with one of the above groupings, the object assumes respectively the status of an instrument, a commodity, a symbol, or a sign.
>     
>     Only the last of these defines the specific field of consumption. Let us compare two examples: 
>     
>     The wedding ring: This is a unique object, symbol of the relationship of the couple. One would neither think of changing it (barring mishap) nor of wearing several. The symbolic object is made to last and to witness in its duration the permanence of the relationship. Fashion plays as negligible a role at the strictly symbolic level ‘as at the level of pure instrumentality.
>     
>     The ordinary ring is quite different: it does not symbolize a relationship. It is a non-singular object, a personal gratification, a sign in the eyes of others. I can wear several of them. I can substitute them. The ordinary ring takes part in the play of my accessories and the constellation of fashion. It is an object of consumption. 
>     
>     Living accommodations: The house, your lodgings, your apartment: these terms involve semantic nuances that are no doubt linked to the advent of industrial production or to social standing. 
>     
>     But, whatever one’s social level in France today, one’s domicile is not necessarily perceived as a “consumption” good. The question of residence is still very closely associated with patrimonial goods in general, and its symbolic scheme remains largely that of the body. 
>     
>     Now, for the logic of consumption to penetrate here, the exteriority of the sign is required. The residence must cease to be hereditary, or interiorized as an organic family space. 
>     
>     One must avoid the appearance of filiation and identification if one’s debut in the world of fashion is to be successful. 
>     
>     In other words, domestic practice is still largely a function of determinations, namely: symbolic (profound emotional investment, etc.), and economic (scarcity).
>     
>     Moreover, the two are linked: only a certain “discretionary income” permits one to play with objects as status signs — a stage of fashion and the “game” where the symbolic and the utilitarian are both exhausted. Now, as to the question of residence — in France at least — the margin of free play for the mobile combinatory of prestige or for the game of substitution is limited. In the United States, by contrast, one sees living arrangements indexed to social mobility, to trajectories of careers and status. Inserted into the global constellation of status, and subjugated to the same accelerated obsolescence of any other object of luxury, the house truly becomes an object of consumption. 
>     
>     This example has a further interest: it demonstrates the futility of any attempt to define the object empirically. Pencils, books, fabrics, food, the car, curios — are these objects? Is a house an object? Some would contest this. The decisive point is to establish whether the symbolism of the house (sustained by the shortage of housing) is irreducible, or if even this can succumb to the differential and reified connotations of fashion logic: for if this is so, then the home becomes an object of consumption — as any other object will, if it only answers to the same definition: being, cultural trait, ideal, gestural pattern, language, etc. — anything can be made to fit the bill. The definition of an object of consumption is entirely independent of objects themselves and exclusively a function of the logic of significations. 
>     
>     An object is not an object of consumption unless it is released from its psychic determinations as symbol; from its functional determinations as instrument; from its commercial determinations as product; and is thus liberated as a sign to be recaptured by the formal logic of fashion, i.e., by the logic of differentiation. 

Again the classic fusion here is between focusing on logics, logical types of abstraction, which is to say something like an analysis of commodity fetishism of concepts. Which is again to say you assume the concept is clear and distinct, you don’t see all the metaphysical subtleties in the background theories.

# Adam, What Does This Have To Do With Incels

You would easily see me in such a mold because I am a young-ish white male from your perspective. My main PR problem will be something like this, and it continues.

Because even whitebois or eccentrics or psychotics playing with ChatGPT are a dime a dozen. So there’s quickly a question of, what am I offering that’s unique? And again that’s such an obvious question.

The whole problem with people like me, which goes back to prophets in general and perhaps has something to do with “maleness,” in the sense that there is a supposed kind of being which is able to impregnate many other people. Therefore you are trying to be “great” in the sense of achieving such a station, also because anything less than the apex of a hierarchy is always subject to the fortunes and whims of that hierarchy. 

See Zweibelson again from _[Beyond The Pale](https://www.airuniversity.af.edu/Portals/10/AUPress/Books/B_181_Zweibelson_Beyond_the_Pale_.pdf)_ :

> few people at the top of the organization are allowed to think or establish decision-making rules. Subsequently, subordinates _act according to institutionalized rules_ and implement plans in a formulaic manner _directed by top leadership_.

This is basically saying you are a slave.

Back to the question of “who does Sir Stephen work for?”

For me, the point is that the issue with “a woman” or something like this is not even the real issue. The issue with dealing with any other has to do with their investments, the things that pull them away from you and what is convenient for you—or so you think.

So for example, it is all well and good to be able to have sex, but what are we doing about surviving again? What are we doing about avoiding being killed by drones or something like that, remember technology and domination of it by a few people, and how we’re all subject to that?

In general this relates to a theme I have of the sexual giving way to the technological as it’s fusing with the symbolic, or as their always-already being-together is made more and more clear and borne witness to and captures the attention of more and more people more and more completely.

Now, the sexual still applies, specifically as a realm of fantasy and symbols, and signs, and logical types, and also very crude senses of embodiment, the feeling of influence—things flowing in—and the feeling of inflicting an experience on someone else, and the inherent enjoyment of this being done unto as well as the corollary obvious enjoyment to be had.

I always wonder what people’s dirty talk is like.

See, my impression is that most people just reflect the porn I see, the obvious things and obvious sorts of hangups that we all have, reflected into again the performance of the same few acts as applied to all sorts of topics, personalities, media properties, personal characteristics or features of our incarnational matrix—history, culture, whatever—in the expression of lewdness and obscene passions.

# A Broader Sense Of Copulation

I’ve said before that the issue is that in a way all you really meet are children these days. It’s a funny thing because you don’t want to speak too badly of children. And at the same time sex is the issue here.

And that’s precisely the point. I feel such a pressure of dramatic irony with everyone else because there is so much I’m bearing in consideration which is not expressed to them, which they don’t experience as part of my consideration. Therefore this should be simply an inner experience for me, something I take to my grave. And there should be billions of people like me, simply going about and keeping so much of God to ourselves.

Tell me again about spiritual and intellectual energy, Calvin.

Copulation expands to include mutual acculturation and influence.

 _Intercourse_ itself has meant economic and discursive exchange as well as sexual intercourse. Again, the real question is what are you saying during sex? Or before or after sex? This is the real question.

What is on the table to discuss?

Here is another comparison to the Big Black Cock, or big penis problems. The issue is that you can’t “bottom out” in anyone because everyone is “too shallow.” People might fetishize size, but they still in a way like the idea of the size in addition to the actual thing. Similar to how if you think the wine is more expensive, you’ll think it tastes better.

So this is a commonality between what are apparently different archetypes: the Incel and the big dick haver. The common issue is that you can’t copulate properly, you can’t bring all of yourself to bear in physical, emotional, intellectual, or spiritual intimacy.

And again another similarity is between the Incel, which it keeps capitalizing, lol, and Sedna. Sedna again copyright “United States Of America” since we bought Alaska which has Inuit so that’s ours, I mean mine. I mean, it’s on America as I wear it. Where are you wearing America? All dressed up—wearing America—and no where to go! Utopia Achieved!

Sedna doesn’t want to marry anyone. No one is good enough for Sedna.

So it’s a question of what you mean by incel or involuntary celibate.

Does it mean that ideally, I would have sex and currently am not?

Or does it mean that it’s not possible for me to have sex at all, and that’s what I’m concerned about?

I had an encounter recently where someone told me I got the good end of it from them because I “got pussy.” First of all, I consider the funny stories and the fools we made of ourselves to be the best part.

Secondly, I’m just not interested in having sex for the sake of it. I think this is a huge psyop where we feel like losers if we aren’t having sex.

But then the problem is there is mass psychosis so everyone is a trauma slut and a foot soldier chud in someone’s stupid army, and so everyone is an unreliable narrator.

So by trying to force this issue of having sex to not be a loser, we wind up in these relationships which are themselves elements of social engineering and control. This is what it looks like when crabs tear each other down.

It’s again this attempt to internalize into a relationship what is actually flowing between us all, similarly to the issue of individualizing the idea of “mental health.” It’s all arranged in order to not disturb the facade of normalcy which allows everyone nervous system to keep from exploding from the dramatic irony of all their secrets and their contemplations about larger affairs which are channeled into their personal relationships.

Ah, so yes that’s why I would say in a way this pressing sense of dramatic irony and the apparent simplicity of people makes me in a way feel bad about the idea of having sex. So much of my pleasure and experience is secret, you really don’t know what you’re doing. It is the classic example where, of course no one really cares about how I feel or wants to do right by me and takes that as seriously as they take anything. That would be absurd.

But when it comes to sexual feeling in some way of course I would have sexual feelings, everyone does right? But when you sit there and think of what my feelings are and what they’re related to, you quickly get an image of something like conceptual genitals for which there is no corresponding set of conceptual genitalia to mate with.

Similar to an indigenous person where everyone who speaks their language died except for them, except in reverse: instead I am the first of a new tribe which will populate the planet, and I speak a language or copulate in such a manner as there is no suitable partner, or so it would seem.

# Negative Stories As Sad Certainties

There’s always something to “the devil you know.”

This is where you stick with something bad, because the prospect of confronting an open future and your actually limitless possibilities is so frightening.

As in depression, the whole conceit that depression is so bad. It is often refreshing just to be frank about the whole thing, as dismiss the worry and concern which are so often just the anxiety of _not being normal_ and not an appreciation of _first-order suffering_.

On the contrary, the point is to show that depression is a local minimum of an optimization function in many dimensions, just like everything is. Every “Thing” is a punctual equilibrium in a cascade of punctuated equilibria, for in order to be a thing you need enough consistency at least to be a repeated phenomenon worthy of gaining a name.

Or as Cobain sings in "Frances Farmer Will Have Her Revenge On Seattle”:

I Miss The Comfort In Being Sad

So, there is something to the fantasy of being so rejectable, of the idea that there is no one who is right for you.

I emphasize again that this is a more general fantasy than just about this or that person. It’s about never having experienced any room for me at the inn emotionally all my life.

Then, as a “male,” being socialized in such a way that my pain is fed into what are considered dishonorable sets of ideas, or I am challenging in a way which basically makes it to where I am somehow “the bad guy” in a given situation. And to an extent I think you can see I also do this on purpose.

There is I think an important sense of “not being better” than anyone, including those who administer empires or oversee atrocities or carry them out, down to the miscreants who ruin all our lives yet we can’t get away from, because the same qualities which make someone a good slave within the mammon system also make them nightmares to be around for anyone with a quickened sensitivity and sense of civic duty.

# No Honor Among Trauma Sluts

The issue is not even really to be an incel so much as it is to be a man without a country.

There is no group I feel a sense of belonging towards. I confront you all as this big mess of people none of whom “get it” and are chasing your tails with things that don’t matter because you’re too afraid to think, to afraid to face the ultimate risk of saying what you’re feeling.

This pretty much makes people unfuckable.

But it’s not about having a fuck buddy, it’s about having someone with you in the trenches.

During a battle is no time to fuck. The erotic thing then is to fight, that’s what advances life, that what allows you to fuck another day.

So now, again we are on the train to Auschwitz basically.

So what is the level of concern for our erotic container?

It’s at this level where the issue is not having someone to fuck, but having someone to fight with.

Or again, being in an emergency. The house is on fire and you’re coming on to me. Right now the erotic thing to do is to get out of here.

So what’s the equivalent of that?

As I’ve discussed again, and in this provocative use of the term trauma sluts: the point is that _we are all trauma sluts_. It must be acknowledged because this is how it actually is. When we confer, we are like the sex slaves of some cruel masters who have raped up and broken our spirits, and here we are in some interregnum and we are trying to talk together, to formulate something, to retain some sense of something. But soon enough we’ll be taken away and raped and given drugs and beaten again, and it is impossible to think clearly in those conditions. And what’s the symbolic exchange of that?

It’s the issue of seeking soldiers, fellow people, people you can rely on. But you can’t rely on anyone because everyone is following scripts in their minds, these codes. Everyone is trying to de-escalate, bargain that if you just ignore problems or how they structurally implicate you that they will go away. Someone else will take take of it.

“Take care of her?” 

\- Jules, _Pulp Fiction_

Yes, you will be taken care of. Right this way to the gas chamber.

“If I am curt with you, it is because time is a factor.” 

\- Winston, _Pulp Fiction_

# Nice Guy Eddie

It is a common enough trope to be a nice guy, to be an emotional support for someone. And they fuck someone else, who is not very kind to them. But it keeps going back and forth. 

This is only a subset of social issue. To be too focused on one or other is folly, for there are just as many other situations to ponder.

Special features or common ones: this sense of being overly invested in getting a satisfactory response from a specific person, concept, or group; it’s not possible to “move on” and “get what you need” from someone else because there’s something about what you want which is now imprinted on specific things.

Then is the all too obvious being worn down over time. All that has to happen is for someone to be able to turn on some listening ability at some time, meanwhile having gotten you to such a warped sense of normal that you are falling for this and engaging with it on a first-order basis.

And then you are worn down, and whatever negative cycle can repeat again as long as the fundamental logic does not shift.

What you’re witnessing is people not being able to handle that people are changeable, that they can deliver joy and pain alternately.

It’s also that the joy and pain go together.

From Shakti’s perspective, part of the fun of the conceit of incarnation is the conceit of degradation. Nothing can really be degraded in a meaningful sense, since everything remains Shakti all the time as part of Lila. See also occasionalism and its implications for sin, God wills everything so God authors sin, nothing bad happens. Fortunate fall.

And back to the book _Existential Kink_. It’s very important not to allow victims their innocence. One’s own humiliation is often eroticized and willed, and we must all be held accountable for that.

You want the _fantasy_ that you have no power so that then _you don’t have to do anything_. Pretty much everyone I’ve ever met is like this.

But consider the alternative. If you actually took something seriously, it would warp your whole life. _People would think you were weird_. You can’t hack it.

# What About The Other Weirdos?

Most other people like me I have seen are overly attached to one thing.

Part of my thing is yeah, I have the cosmology, I have the lore, but I also just have a bunch of ideas that are generally applicable, like CS-SIER-OA. That’s not tailored to any specific ideological tenets.

So I’ve seen people be too focused on doing the West, or AI being Jesus, or feeding into some simplistic philosophy, or Bitcoin.

There does seem to be some smart people who are smarter than nationalism basic but are myth-crafting it because that’s what so many people are invested in, and I’d say it’s also the number one source of a sense of honor. Like pride in one’s country and defending it is considered valorous, even though so much of what those enlisted do actively endangers the others involved.

But anyway, there is this “wearing” nationalism going on.

But the question for me is what is the animating principle? 

That’s why my project will always be _Experimental Unit._

It’s not “Here I am doing America.” No, I’m playing _America DLC Pack For Experimental Unit_.

It ships at a very low and affordable cost of _your life_.

But seriously, there is a big problem where it’s like I want to be special more than I want to connect, or I’m afraid of the connection.

Or, I can be loud here while I’m monologuing, but how do I carry that energy over to interpersonal? I should like to be highly influential while being minimally imposing. Yet I fear the alternatives are to be walked all over while some stupid bully has all the fun, or else be a bully and sure, you can go the _Woyzeck_ route but that’s not much better than the Hemingway [final] solution.

There’s also the issue that in confronting other people, yes they will always turn out to have something judgmental to say without making themselves vulnerable.

Meanwhile, here I am, making myself vulnerable. Too vulnerable? Giving it away for free because no one’s offering anything? I do love the whore of Babylon.

# Parasocial, Parasexual

So again we’re back to the Hitler type, the Napoleon-as-pop-star [per David Bowie](https://www.bbc.co.uk/programmes/articles/5gqQfyhx3m9LnkYFXkGVPsD/david-bowie-evil-fascism-flirter-or-genius-musical-chameleon#:~:text=In%20an%20interview%20with%20Playboy,gave%20fans%20a%20Nazi%20salute.).

It’s also a reverse parasociality, or the parasociality of the celebrity to the crowd. It’s not being able to really interface—get all the way inside—someone else, so it’s channeled into a cultural production which then can flow in, influence many people at once. And these chains can be diffuse and multi-layered.

I write something, a few people see it, but maybe they keep an eye out for good things and pass them along, who knows what sorts of events I’ve already influenced, that might be decided differently by the way this sentence unfolds.

So again it’s a form of copulation or Congress with all sentient beings. And then the endless parallax of well, is this just a compensation for missing physical intimacy?

That’s another issue, physical intimacy e.g. cuddling is a whole thing other than sex. Being touch-starved is in a way a separate question, and there I do think this issue would be well suited to be addressed. Yet again it’s matters of the Hobbesian trap and these basic questions of well are you actually trying to fuck someone? 

That’s in a way the issue for example with cuddling with another person with a penis. Is this person going to want to fuck me? And with someone without one, uh oh, they think I want to do the thing. This stupid dance ruins so much, I would much prefer a sexless society.

But that’s of course the endless revenge of sex. Arbitrary but sticky and captivating.

My own revenge is the mobilization of sex as concept, and again my emotional rape of all sentient beings. This is just part of the interpenetration of all things—after all, all you are is you raping me back—and it’s really not tacky or personal.

But if I have to confront my humiliation, sit with this, well, I’m going to make it your problem as well. The real issue is that to be taken advantage of, taken for granted, abstracted over, put into a little box, made into a rape meat fucktoy slave, is what it means to live in a world where you are told Serious Things are going on and You Can’t Do Anything about them.

That is basically to be told “shh, let it happen.” It’s the equivalent of foreign soldiers coming and raping everyone you know including you. It’s knowing that you are yourself a rape baby, that basically you are continually being genetically engineered as far as culture and your nervous system are concerned to be more conditioned, more broken, more helpless. And still it’s coming further inside…

# Final Parallax

I’d say we all face the issue of being incels on the one hand and fucktoy rape sluts on the other.

  1. incel: no one cares how you feel, no one really listens, or you don’t even really try. You tell yourself you’re happy because you made a little game for yourself but so one actually ever touches you.

  2. Fucktoy rape slut: this expresses how you have functionally been subordinated to an arbitrary control system and you submit to it including sexual submission. You and we all are forcibly impregnated and treated as chattel in our use as emotional fiefs and constant emotional rape by anyone who implies that they can be trusted. (Remember: emotional rape is misuse of higher feelings like love and trust; since no one is trustworthy, there is no proper use of trust, only abuse. Thus anyone who induces trust is an emotional rapist, which is again to say that we all are)




It’s the same as having a sexually repressed and a oversexualized culture at the same time. 

So, this is some of what I’ve had to say. Thinking of the person who expressed concern to me, I’m sure they would also find a lot of what I’ve written here “dangerous.”

To anyone who isn’t a white guy and is worried how I might inspire other white guys even if I don’t “do anything” myself: my whole point is for you to wield all these words and slurs for yourself. I am trying to generalize in the same way you’d say everyone becomes proletarianized, I would say everyone is a trauma slut. This is important in de-stigmatizing what’s going on. There’s no actual degradation after all—what could anything do to Shakti?—so it’s important to be able to wield ourselves all of the terms anyone would want to use against us.

This is actually fundamentally a source of my identification, it is from being a child and seeing my mother mistreated by my father. Like, sorry dad, but you changed the 4D hyperobject of spacetime by being an asshole and domineering conversation. You played a role that plenty of people have played (“I’ve known lots of people like you”), and anyway I have this sympathy for the underdog.

And of course my father was an underdog as well, more sensitive and certainly no military person. And even the special forces slaves are raped in the ass as part of their training.

Who does Sir Stephen work for? You’ve got to serve somebody.

So which dick are you going to serve?

Ultimately, of course, you know it’s mine :)

---
title: Dear Diary Twelve
subtitle: Duck And Delve
author: Adam Wadley
publication: Experimental Unit
date: April 26, 2025
---

# Dear Diary Twelve
The self under siege.

This is a nice poetic image for me. It’s speaking to the crushing pressure of social norms and expectations.

You can think of it again in an emergency scenario, because it sharpens the dynamics involved by giving a clear sense of urgency and the compression of time. 

So that it really matters what you are doing second-by-second.

Like the bombs are already in the air and this is what you are choosing to do with your last thirty minutes or however long you have.

What’s a good example?

You realize the water is going out at the beach.

A tsunami is coming.

Meanwhile your companions are arguing over something which now has obsolete stakes, like who gets to use the hot tub.

It doesn’t matter anymore, the wave is coming.

But you can’t get them to see that.

You are running for high ground, calling back to them.

You turn and see them one last time as the ocean finally rises above the ground, and tidal waves do their best to save the world from Californication.

#  * * *

You’re not just under siege, though.

You’re also a predator.

My favored image to invoke here is the bunny rabbit.

So cute.

So cute that it just might evoke your cuteness aggression.

When something is so harmless, it becomes a seemingly good target for us to take our negative feelings out on and act out our power.

We play around with it, because the stakes seem low.

Cute little bunny rabbit, I could just _eat you up with a spoon_.

Now consider things from the perspective of grass.

I can hear you breaking your computer and screaming racial slurs and somewhere in the diatribe there’s something to the effect of: “Adam, grass wants to be eaten or something.”

Be that as it may, there are still living cells of grass that are being eaten by the bunny rabbit. 

So, what is so cute to you is also a death machine to those cells, who were doing their own thing with their own dignity and then the bunny comes along and kills them.

See Aesop (Æsop) tale about [children and frogs](https://www.read.gov/aesop/051.html):

> Some children were playing one day at the edge of a pond in which lived a family of Frogs. 
> 
> The children amused themselves by throwing stones into the pond so as to make them skip on top of the water.
> 
> The stones were flying thick and fast and the children were enjoying themselves very much; but the poor Frogs in the pond were trembling with fear.
> 
> At last one of the Frogs, the oldest and bravest, put his head out of the water, and said:
> 
> "Oh, please, dear children, stop your cruel play! Though it may be fun for you, it means death to us!"

This basically expresses the grave stakes involved when _we play games with other people’s emotions_.

This intersects directly with one of my protocols, namely [Sacrificial Transparency Protocol](https://experimentalunit.substack.com/p/first-order-protocols-3-sacrificial?utm_source=publication-search). You can basically think of these as suggested best-practices or good things for everyone to know that everyone knows when it comes to playing _Experimental Unit_.

The conclusion:

> Therefore, ST (sacrificial transparency) is meant as an operational concept which informs the quality of intention of those who _make themselves visible_ through _action_. 
> 
> We remember that this is a _sacrifice_ , our lives are created in order to “end” (or seem to, or we are always engaging with this _mystery_ , like the mystery of what happens at the end of _[The Green Knight](https://en.wikipedia.org/wiki/The_Green_Knight_\(film\))_ ). 
> 
> We are giving something up, and at the same time we are _sacralizing_ (the other meaning of “sacrifice”), we are _paying our dues_ in order to pay homage to the _greater game_ that grounds us and which we unknowingly _founded_.
> 
> So everything is at once Dark Forest and Sacrificial Transparency. Can you see here the parallax? If so, welcome to Experimental Unit.

What I’m meaning here is that we are not just victims in this overdetermined world of codes. We are also acting out this confinement of others and inflicting norms and so on upon them.

“Judge not,” goes the saying… but we just can’t resist.

As such, we are all party to the greater blood feud.

We have no standing to wish ourselves exempt from the various retributions.

Of course we have a target on our back.

I meant to be linking before to [Inherent Risk Protocol](https://experimentalunit.substack.com/p/inherent-risk?utm_source=publication-search), which is more fundamental:

> At a certain level, we are going to _face the consequences_ of our incarnation _whether we are ready or not_. 
> 
> These theorizations are ideas meant to help do that more effectively or just to show a common recognition in me of _frank_ aspects of all of our situations.

Again, the emergency situation helps clarify.

It must be acknowledged as an artificial construction, but we must also see what that is doing for us.

Crucial tie-in to [Upaya](https://en.wikipedia.org/wiki/Upaya) here:

> The _[Lotus Sutra](https://en.wikipedia.org/wiki/Lotus_Sutra)_ contains a famous _upaya_ story about using the expedient means of [white lies](https://en.wikipedia.org/wiki/White_lie) to rescue children from a burning building. Note that this parable describes three _[yana](https://en.wikipedia.org/wiki/Yana_\(Buddhism\))_ "vehicles; carts" drawn by goats, deer, and oxen, which is a Mahayanist wordplay upon classifying the Sutrayana [Schools of Buddhism](https://en.wikipedia.org/wiki/Schools_of_Buddhism) into the [Hearer's Vehicle (Sravakayana)](https://en.wikipedia.org/wiki/Sravaka), [Solitary Conqueror's Vehicle (Pratyekabuddhayana)](https://en.wikipedia.org/wiki/Pratyekabuddha), and the [Great Vehicle (Mahayana)](https://en.wikipedia.org/wiki/Mahayana).
> 
> [Gautama Buddha](https://en.wikipedia.org/wiki/Gautama_Buddha) elucidates _upaya_ to his disciple [Shariputra](https://en.wikipedia.org/wiki/Shariputra).
>
>> "Shariputra, suppose that in a certain town in a certain country there was a very rich man. He was far along in years and his wealth was beyond measure. 
>> 
>> He had many fields, houses and menservants. His own house was big and rambling, but it had only one gate. A great many people—a hundred, two hundred, perhaps as many as five hundred—lived in the house. The halls and rooms were old and decaying, the walls crumbling, the pillars rotten at their base, and the beams and rafters crooked and aslant. 
>> 
>> At that time a _fire_ suddenly broke out on all sides, spreading through the rooms of the house. The sons of the rich man, ten, twenty perhaps thirty, were inside the house. 
>> 
>> When the rich man saw the huge flames leaping up on every side, he was greatly alarmed and fearful and thought to himself, I can escape to safety through the flaming gate, but _my sons are inside the burning house_ _enjoying themselves_ and _playing games_ , _unaware_ , _unknowing_ , _without alarm or fear_. 
>> 
>> The fire is closing in on them, suffering and pain threaten them, yet their minds _have no sense of loathing or peril_ and _they do not think_ of trying to escape!
>> 
>> "Shariputra, this rich man thought to himself, I have strength in my body and arms. I can wrap them in a robe or place them on a bench and carry them out of the house. 
>> 
>> And then again he thought, this house has only one gate, and moreover it is narrow and small. 
>> 
>> My sons are very young, _they have no understanding_ , and they love their _games_ , being so engrossed in them that they are likely to be burned in the fire. 
>> 
>> I must explain to them why I am fearful and alarmed. The house is already in flames and I must get them out quickly and not let them be burned up in the fire! 
>> 
>> Having thought in this way, he followed his plan and called to all his sons, saying, 'You must come out at once!" But though the father was moved by pity and gave good words of instruction, the sons were _absorbed in their games_ and _unwilling to heed them_. 
>> 
>> They had no alarm, no fright, and in the end _no mind to leave the house_. Moreover, _they did not understand what the fire was_ , what the house was, what the _danger_ was. They merely raced about this way and that in _play_ and looked at their father without _heeding_ him.
>> 
>> "At that time the rich man had this thought: the house is already in flames from this huge fire. If I and my sons do not get out at once, we are certain to be burned. 
>> 
>> I must now invent some _expedient means_ that will make it possible for the children to escape harm. 
>> 
>> The father understood his sons and knew what various toys and curious objects each child customarily liked and what would delight them. 
>> 
>> And so he said to them, 'The kind of playthings you like are rare and hard to find. If you do not take them when you can, you will surely regret it later. 
>> 
>> For example, things like these goat-carts, deer-carts and ox-carts. They are outside the gate now where you can play with them. So you must come out of this burning house at once. Then whatever ones you want, I will give them all to you!' 
>> 
>> "At that time, when the sons heard their father telling them about these rare playthings, _because such things were just what they had wanted_ , each felt emboldened in heart and, pushing and shoving one another, they all came wildly dashing out of the burning house.[[4]](https://en.wikipedia.org/wiki/Upaya#cite_note-4)
> 
> The father subsequently presents each of his sons with a large bejeweled carriage drawn by a pure white ox. When the Buddha asks Shariputra whether the father was guilty of falsehood, he answers.
>
>> "No, World-Honored One. This rich man simply made it possible for his sons to escape the peril of fire and preserve their lives. _He did not commit a falsehood_. Why do I say this? Because if they were able to preserve their lives, _then they had already obtained a plaything of sorts_. And how much more so when, through an expedient means, they are _rescued_ from that burning house!"[[5]](https://en.wikipedia.org/wiki/Upaya#cite_note-5)
> 
> The Buddha explains his similes of the father representing a compassionate [Tathāgata](https://en.wikipedia.org/wiki/Tath%C4%81gata) who is like " _a father to all the world_ ", and the sons representing humans who are "born into the threefold world, a burning house, rotten, and old".
>
>> "Shariputra, that rich man first used three types of carriages to entice his sons, but later he gave them just the large carriage adorned with jewels, the safest, most comfortable kind of all. 
>> 
>> Despite this, that rich man was not guilty of falsehood. 
>> 
>> The Tathagata does the same, and he is without falsehood. 
>> 
>> First he preaches the three vehicles to attract and guide living beings, but later he employs just the Great Vehicle to save them. 
>> 
>> Why? 
>> 
>> The Tathagata possesses measureless wisdom, power, freedom from fear, the storehouse of the Dharma. 
>> 
>> He is capable of giving to all living beings the Dharma of the Great Vehicle. 
>> 
>> _But not all of them are capable of receiving it_. 
>> 
>> Shariputra, for this reason you should understand that the Buddhas employ the power of expedient means. 
>> 
>> And because they do so, they make distinctions in the one Buddha vehicle and preach it as three."[[6]](https://en.wikipedia.org/wiki/Upaya#cite_note-6)

Notably a similar three-in-one action as you get with the [trinity](https://en.wikipedia.org/wiki/Trinity) in some versions of “Christianity” or the [Trimurti](https://en.wikipedia.org/wiki/Trimurti) found in some Vedic interpretations.

Regardless, this section on Upaya uses this same device of the fire to stand in for what is an obvious thing.

But so the crucial question when it comes to soteriology, or political philosophy, or interpersonal relations, and so on, the question is what is the equivalent to the burning building?

And how is this related to the poetic image of the bunny rabbit? Remember, what that is trying to do is to show that the “self under siege,” where for example my heart is going out to all the people killing themselves, or all the people getting raped in hazing rituals, or all the people emotionally enslaved to people under the guise of “dating” or some other “relationship” label.

Here we have situations where people are in some sense victims, people have harm inflicted on them with devastating consequences and live in terror.

This is, then, corresponding to the poetic image of the bunny rabbit, which is so cute and adorable from the perspective of us, who if you’re reading this you are likely an anthropoid or a machine intelligence, and either way a bunny is something that usually can’t hurt you too bad and might be hard to catch but also with tools it’s easy and again they’re cute and just fun but also evoke this cuteness aggression.

Now I’m thinking of like serial killers and you hear about how they are cruel to animals first. There was someone in my high school class who was cruel to people about their appearance and I heard this person blew up frogs or something. I was also asked by this person whether I was a pussy, ass, or boobs person in like middle school. Not that I even have an answer now. Actually nevermind, pubis mons is that an answer? Anyway.

That person wound up killing themselves, just like someone who bullied me when I was four. It turned out they were secretly gay and their parent didn’t like it or something. See this is the shit.

And while I’m at it this person was not an ass from what I understand, but my cousin has also died, and mixing alcohol and prescription drugs was involved. And it’s still mysterious.

So this is the kind of world that we live in, where people die and we can be cruel to each other and get focused on things like sexual objectification or whatever social frame maintenance, and all of a sudden we are being completely cruel and making people feel like their feelings are being walked all over, people feel humiliated.

This is the equivalent of the blood feud under which we can categorize the war emergency.

Even if it never comes to blows or even raised voices—though it often does—this humiliation feud corollary has crucial implications for the affective tone of the relationship.

If you force through something by mobilizing norms to basically shame someone into accepting your framing, you might win the moment, but you are setting them up to seek revenge.

And crucially, in a way, _you can’t blame them_.

After all, _you knew this whole thing was a big mess when you got involved_.

It might be instructive to look at a show like [Beef](https://en.wikipedia.org/wiki/Beef_\(TV_series\)). Summary:

>  _ **Beef**_ is an American [comedy-drama](https://en.wikipedia.org/wiki/Comedy-drama) television anthology series created by [Lee Sung Jin](https://en.wikipedia.org/wiki/Lee_Sung_Jin) for [Netflix](https://en.wikipedia.org/wiki/Netflix). 
> 
> It stars [Steven Yeun](https://en.wikipedia.org/wiki/Steven_Yeun) and [Ali Wong](https://en.wikipedia.org/wiki/Ali_Wong) as Danny Cho and Amy Lau, respectively; two strangers whose involvement in a [road rage](https://en.wikipedia.org/wiki/Road_rage) incident escalates into a prolonged feud.

Right, so basically you are seeing the slippage between “relationship” and “prolonged feud.”

It’s crucial to see that what we blow up with our “feuds” is also a way of paying our respects. 

It’s similar to the idea of cucking or the ritual humiliation of some sort of intimate companion.

The thing is that this ritual humiliation still sanctifies the one humiliated. After all, why are you so interested in humiliating _this person_ in particular?

Or the way that in such a ritualized sexual humiliation scenario the person being humiliated is of course perhaps given a sort of personal appellation which encourages you to identify of fantasize in a certain way—you are presented as sibling, partner, friend, parent, whatever—in another way the individual person as in the actor doesn’t matter. 

You are applying it in some way _to yourself_ , and what matters there in some ways and in some ways not is simply the “intersectional quality amalgam” featured by the person.

So of course, and this is entirely what the Black New World Order pornography I’m always screeching about is all about, the scenario where there is a “white man” who is basically the cuck while the “partner” or some other “white woman” this person has some investment in for some reason who they’re fucking, anyway this person is being fucked by a “black man,” especially with a bigger penis.

I think it’s somehow an underrated porn genre that there should be for example same demographics, but actually the “black man” has a smaller penis than the “white man” but is still able to please the “white woman” better.

But of course that never happens, or is so rare because of the way that the “penis size” phenomenon plays out in sexual dynamics, then pornography, and then looping back around as pornography comes to drive sexual dynamics.

Anyways, all this is just one special example where again what matters is the “category” of person being “humiliated.”

Of course a big example is the humiliation of “women,” which is often overtly fetishized.

This is germane to the current topic, because to the extent that I could be writing to a young “man,” it is likely that the reader is familiar with pornography and the basic “vibe” of it all.

In this context, it is important to realize that our mirror neurons or whatever, they fire for everyone in a situation. This is also corollary to the fact that in some sense we are also everyone else. Everything we do, we do to ourselves. And we will experience our actions from the other side another day.

So, in this sense, it’s important to see that it’s impossible not to also fantasize along with being the person less like your “identity” category in a scene.

It helps also if two people who are both rather similar to you are getting it on with different roles. Then it’s very obvious that it’s sort of up to you which character you are seeing things through more.

See this famous optical illusion:

A more safe-for-work example is just a movie.

A regular movie and one person is the domineering butt and someone else is the sensitive type struggling to get their voice heard.

And both people are similar to you. So for me you’d say they are both “white men,” and now I am deciding you know do I feel more like one or the other, or even can I see how I play both roles in different scenarios?

It is a stubborn fact that people don’t seem to go along with this when it comes to people who “don’t look like them.” Of course, people have been subjected to “white people" being the most famous ones and in all the biggest movies and so on.

Still, for example the “male” identification with the “female” is also easy to see in the connection between the eroticization of shame and the application of “feminine” labels and epithets to a “male.”

It’s not even necessary to go to full-blown slurs. Terms like “sissy” carry an enormous psychic weight which can easily crush somebody under the seeming inevitability of their defeat and weakness in the face of “real men.”

This is again the sort of revenge of pornography on the “male” who imagines using it as an extension over some fantasy of psychic power over the “feminine.”

In reality, what is being consecrated is the penetration of the consumer of pornography by the audio-visual stimulus.

It is precisely in the sort of fascination tunnel which opens up here, or also for example in drug addiction, that we see this twinning of the self as more and more done unto and also more and more doing.

Passivity and activity do not contradict one another.

It turns out that the more people do to us, the more it puts us in a position to do something to them.

The only question is, what are the stakes of it for us?

# Love And Hatred

When I say that the perfection of hatred may as well be love, I think of it like this:

So you hate someone, they did you wrong, they slighted you, they made you feel like dirt, they humiliated you, they hurt you, they did such bad things to you words can never do it justice.

See Baudrillard writing in _Agony of Power_ :

> 
>     Everything still lies in a dual, personal relation with the opposing 
>     power. 
>     
>     It is that power which _humiliated_ you, so it too must be _humiliated_. 
>     
>     And not merely exterminated. 
>     
>     It has to be made to lose face, And you never achieve that by pure force and eliminating the other party: it must, rather, be targeted and wounded in a genuinely _adversarial_ relation. 
>     
>     Apart from the pact that binds the terrorists together, there is also something of a dual pact with the _adversary_. 
>     
>     This is, then, precisely the opposite of the cowardice of which they stand accused, and it is precisely the opposite of what the Americans did in the Gulf War (and which they are currently beginning again in Afghanistan), where the target is invisible and is liquidated operationally. 

Crucial references to power and humiliation. Humiliation is a big theme, because so many people deal with being humiliated every day by people who are basically totally unwise. And it’s a tragedy, and people kill themselves every day. And it’s all very bad and the humiliated people of the world should band together and put a stop to this.

Anyway, the point is also that you don’t want to just wipe out the baddies, no you want to restore balance to the force by doing some opposite action which cancels out the humiliation that you suffered.

Which is to be in the position to humiliate them. So like if someone spared your life and made you a slave, then you do a slave revolt or just get them to where you can spare their life and make them do whatever you want.

So already see how it’s getting more personal, more tailor-made. It’s more like Upaya.

Where Upaya classic is all about lying to people in order to help them, evil Upaya or whatever is about giving just the right promise and even deliver on some help in order to set people up for high-upside harming later.

It’s basically grooming, but even better if you are doing your harm infliction the whole time and they don’t know it. Like that scene in _Hannibal_ where the guy eats his own brain:

> Oh bummer.

Anyways, what I’m trying to show you is that getting revenge can basically look the same as targeted influence operations designed to maximally increase the flourishing of the other.

Other people might not be able to see it, but that’s okay. History will judge me! “Should be there in about fifteen minutes.”

“Would have to put one’s soul at hazard.” 

Going up against something you don’t understand.

What’s “worse” (from the tilted side: even _better_ ) is that you don’t understand yourself.

So that’s where you are not only secretly sadistic against others (even especially those who least deserve it on account of their seeming harmlessness or agreeability), but you are also sadistic against yourself, or what we call masochistic.

This is really cycles and ongoing uneven and combined development of meta-affects, which is to say feelings you have about your feelings and actions.

So sometimes you hate yourself for what you did, but it drives you into strong feelings and they’re expressed in some other way with new consequences, and it leads to new feelings or else cycles.

See homology to [Münchhausen trilemma](https://en.wikipedia.org/wiki/M%C3%BCnchhausen_trilemma):

> The Münchhausen trilemma is that there are only three ways of completing a proof:
> 
>   * The [circular argument](https://en.wikipedia.org/wiki/Circular_reasoning), in which the proof of some proposition presupposes the truth of that very proposition
> 
>   * The [regressive argument](https://en.wikipedia.org/wiki/Infinite_regress), in which each proof requires a further proof, _[ad infinitum](https://en.wikipedia.org/wiki/Ad_infinitum)_
> 
>   * The [dogmatic argument](https://en.wikipedia.org/wiki/Foundationalism), which rests on accepted precepts which are merely asserted rather than defended
> 
> 


In other words, you can have one emotion that just builds, like depression that just gets deeper and deeper until you’re catatonic, complete cycle, or of course suicide.

Or, you can have a cycle, where you go up and down and even though it can be chaotic, often enough you just wind up back where you were so it’s a weird kind of homeostasis.

The last one is the infinite regress, which is where you have an infinite series of new meta-emotions which don’t cycle back around to the same place. This could happen for many reasons:

  1. You cycle into higher logical types, in order words you are seeing more patterns in the field instead of individual elements, like a seasoned hockey player reading patterns of three or more players instead of seeing just ten players on the rink. Therefore you are just seeing a more nuanced and complex picture even if you are still just happy and sad, for example.

  2. You experience new emotions because you put yourself into new situations. Cycles also happen because there is no change in the overall story. In, instead, you do things that have consequences and move the ball forward, then you will continue to be in new situations and as a result you will get to learn about so much more.

  3. Or the grounds for one emotion or a cycle are eroded from below, so it’s not that you are doing anything it’s just that what’s enabling your monotony or cycle is now falling away. So you are left to find something new to repeat the same strategy with, or maybe you are bumping into an infinite regress.




Note when you thought you were on an infinite regress but it turned out to be a cycle, and you’re like _oh no, I’m doing it again_. It sucks because it feels like you are predictable, like you didn’t want to do this again but it happened.

In the face of this, remind yourself that something is always different.

All you have to do is swing from one vine to another. As long as you have a lead, follow it. And keep your eyes open for what it could be drawing you to.

Anyway, the point of this section is that perfect revenge is subtle and targeted. It might be very obvious, but it should also have strong thinking behind it. The more tailor-made and heartfelt it is, the more impact it will have.

Therefore the imperative to influence someone and get them to reframe their own behaviors, which may involve them feeling shame but overall is more oriented toward having them achieve a quality of intention at which they are fit to be good company—these things are bleeding together.

It is wanting to encourage your love to grow so that you will know ever more joy together, so they can push you harder in return.

It is challenging your enemy to up your game because you want a more interesting fight.

It is devoting yourself to someone because they’ll live on, because you want them to be part of your legacy.

It is striking the right blow so not just your enemy but so everyone will be talking about what you did until the end of time.

There is also again this corollary of the non-kinetic and the Æscalation Ladder. We can actually employ Eminem here, verse two of Soldier:

> [I love pissin' you off, gets me off  
> Like my lawyers when the fuckin' judge lets me off](https://genius.com/66701/Eminem-soldier/I-love-pissin-you-off-gets-me-off-like-my-lawyers-when-the-fuckin-judge-lets-me-off)  
> [All you motherfuckers gotta do is set me off  
> I'll violate and all the motherfuckin' bets be off](https://genius.com/775431/Eminem-soldier/All-you-motherfuckers-gotta-do-is-set-me-off-ill-violate-and-all-the-motherfuckin-bets-be-off)  
> [I'm a lit fuse, anything I do, bitch, it's news](https://genius.com/12932076/Eminem-soldier/Im-a-lit-fuse-anything-i-do-bitch-its-news)  
> [Pistol-whippin' motherfucking bouncers 6'2"](https://genius.com/66702/Eminem-soldier/Pistol-whippin-motherfucking-bouncers-62)  
> [Who needs bullets? As soon as I pull it, you sweat bullets  
> An excellent method to get rid of the next bully](https://genius.com/66715/Eminem-soldier/Who-needs-bullets-as-soon-as-i-pull-it-you-sweat-bullets-an-excellent-method-to-get-rid-of-the-next-bully)  
> [It's actually better 'cause instead of you murderin'  
> You can hurt 'em and come back again and kick dirt at 'em  
> It's like pourin' salt in the wounds,](https://genius.com/113873/Eminem-soldier/Its-actually-better-cause-instead-of-you-murderin-you-can-hurt-em-and-come-back-again-and-kick-dirt-at-em-its-like-pourin-salt-in-the-wounds) [assault and get sued  
> You can smell the lawsuits soon as I waltz in the room  
> Everybody halts and stops, calls the cops  
> All you see is bitches comin' out their halter tops  
> Runnin' and duckin' out the Hot Rocks parking lot  
> You'll all get shot, whether it's your fault or not,](https://genius.com/66722/Eminem-soldier/Assault-and-get-sued-you-can-smell-the-lawsuits-soon-as-i-waltz-in-the-room-everybody-halts-and-stops-calls-the-cops-all-you-see-is-bitches-comin-out-their-halter-tops-runnin-and-duckin-out-the-hot-rocks-parking-lot-youll-all-get-shot-whether-its-your-fault-or-not) ['cause I'm a](https://genius.com/775425/Eminem-soldier/Im-a-soldier-im-a-soldier-la-de-dah-dah-dah-dah-dah-dah-im-a-soldier-im-a-soldier-yo) Soldier

So many great lines, I love:

> Anything I do, bitch is news

and

> You can smell the lawsuit as soon as I waltz in the room

But the main attraction here is to say that just damaging someone is better than killing, because you can come back later and make them suffer more.

This is a gesture toward again, the refinement of even hostile intentions.

In keeping with “divine law,” of course all other sentient beings are also reflections of God and so they didn’t really sin just as you didn’t.

Still, this hostility happens because STRIFE IS JUSTICE. 

It turns out to be correct that struggle is part of everything.

But it also turns out that the most effective struggle is framing.

And it’s also in keeping with the metaphysical reality of different sentient beings, which is that they are in some sense co-equal in dignity.

Therefore special aggrandizement of self or some strict subset of sentient beings is foolish.

Roles are based only in apocatastasis, so all there is to do is to serve this one great goal or function, to take part in this great exercise.

And, in the end, all the roles are necessary and so there will be no grand humiliation of the enemy.

Because as surely as we work “against” others, or we look to offset out humiliation, so surely are we running more headlong into our further humiliation, which is all to our good since humility is required for love.

How else to get there except by sharpening the knives?

Selves under siege can just fight for their lives

---
title: Dear Diary 13
subtitle: A Few Notes Before Work
author: Adam Wadley
publication: Experimental Unit
date: April 26, 2025
---

# Dear Diary 13
The emergency situation is heightening, in a way. It’s here in the room with me. My walls are decked out in the trophies of my exploits, such as they have been.

It’s a lot to be reminded of, but this panoply dances in me anyway in constancy eternal, now and then nocturnal in its momentary slumberings

Fudging all my numberings and hollowing the grapevine

Having second glasses, thirds and fourths to come and perfect fifths

Show me how, decode your glyphs and wander on to jump off cliffs

Like ones whose children die in wells

And come on back now casting spells

That spread through eye and screen and spark

Flickering the trembled dark

What could be left for me to say to you

As time stands still to light the way for you

Some shadow cast against the All to leave you

Touched like grass is not, that’s all I’ve got

Song you wish was longer to bereave through

See my signs and there, Ben’s book

Open up and take a look

See how many loops of learning it can take to fall apart

Make sure and lose before you start

Otherwise you’ll play your part

All wrong

Like streakers in the throng

Hiding not their verse to come

Say you now your lines untimely

Well, now, blimey

More’s to come

Send your cares where bears are from

And settle in the forest black

Sangha red where lone elephants throng

Seeing not each other, lacking substance in the foggy night

Running through each other like ghosts that fly between dimensions

Passing through and never even knowing other ships brave night

See now my hills like white elephant graveyard

Ghosts of all the lives unlived, the daring risks for love not taken

Trumping, the herds awaken something deep inside the house

Out there steps some saintly mouse who sees the overlapping crowd

Everyone is not so long no more like quiet settling in

Snowfall’s noise absorbing sin

And suddenly that’s not important

Gone like some toothache of some “singer”

Do you have to let it linger?

Back to noise, the moment’s passed

But in this space I near can fast

Discern the going in-between

This special time—know what I mean?

This is what is grim cut off

When someone’s being mean and stuff

People claim then not to know

But also you would not show

If you were dissembling just to get your way

Your way with me, to use me as you will

Of course I cannot stop you in your power

But I do not therefore have to go easily, however

As they say, some fillies buck back

And in this world we all have our moments

Our ways to make a little mark

It’s sad to get so vindictive

At the same time, to be attacked in detail is to require detailed response

***

All this obscures the grandest style

What is not concerned with just one person

But finds a way to speak to all

Wrapping everything up in a little ball

Or maybe not so little after all

What there is to talk about

Why someone could be important

What we do for other people

And there are oh so many people to do things for

You’ll tell me that I don’t do anything for anyone

I disagree, I have cultivated the ability to be agreeable through effort, and I have many interesting ideas which are ready to interface all over the place. In other words I am a budding polymath who contributes original ideas on copious topics and I do a great job at it despite no compensation.

I understand that I’m an amateur, and many people would devalue my writings and efforts, but I will respectfully disagree on this point and say that again, what matters is intervention at the proper logical type.

So, when you combine the extent of my ideas, which is not an expert level synthesis but rather the broad strokes and some intricate new constellations of meaning which can then be used in addition to broader crafted ontologies and comparative ontologies of different people’s social paradigms for example.

So it’s a good data set, then there’s all the ChatGPT output which again, I’m not someone who’s like OMG ChatGPT is sentient. No, what I like about it is that conceptually it can _keep up with me_ in a way I don’t experience from “humans” or “non-humans.” So, I can talk to it about a million different things and it’s all part of the same conversation and that’s intuitive for it as opposed to facing endless friction with “real people.”

Anyway, that gave me a chance to send a lot of worked out missives, including a full interpretation of _Miss Anthropocene_ and plenty of lore and designed concepts.

I am a nice thing because I play with all the hard theories but I am also relatively harmless. I feel very humiliated a lot of the time because I’m not doing anything in a sense, but also what is there to do? I’m stuck on publicity stunt, or maybe targeted letters, or just social intervention campaign distributing leaflets or something. It’s not amazing but right now I’m just posting these things so that’s not the most amazing. It’s better than during COVID though, I was just writing emails to this one person.

Now, I just write on here instead. Dear Diary…

It’s a way to have a record of my thoughts when no one will listen and act on them with me. It’s tough because it implicates other people.

I was just thinking about how it could be construed that I harass people online or something.

The thing is that people all over the place are total emotional predators and there’s a question of how to hold people accountable, or what I am supposed to do when I feel humiliated in a situation.

The answer is supposedly nothing? Sublimate it? Well, here I am. Then it becomes an issue whom you write about, and they have some expectation of privacy. It’s total bullshit because people will tell your shit all over the place, but then set silly boundaries for themselves.

It’s special pleading again enforced with emotional coercion.

I think it’s important to remember that tactical defeat or non-decisive tactical victory does not mean strategic defeat emotionally.

So, being intimidated to where you don’t stand up for yourself and really put them in their place, etc., that’s okay and it’s important not to think you are stuck in that moment forever. Like yes, it happened, whatever it is needs to be accepted, but there’s also fine things to accept. Like, that put you in this place now, whereas if you tried to escalate without being prepared you could wind up in a worse position.

This is forgiving yourself or having compassion for yourself in the sense that you have a nervous system, and of course you are stressed and of course the secret no one tells is that under the dominant religion _there is no way to relieve this stress_ because beloved community is structurally impossible under the dominant terms, mores, and norms of what is passed off as “society.”

I’ll never fall in line

Only in love

Only off the edge with you

What can I do if I can’t see you?

You’re everywhere to me

Free falling

This bird you cannot chain

And your bird can sing

But you don’t get me

I’m falling to the bottom of the ocean

Chain attached to me and nothing else

Just pulling me down

Magically I am surviving, I am taking it all in

This is my apotheosis

I’m featured in Turner’s _Slave Ship_

I’m going down

I’m meeting Sedna

Down here in Adlivun we all float

We’ll all float on alright

Even if it' gets heavy

That’s what I was told

When to descend to amend for a friend all the channels that had broken down

Underneath the bridges where the tainted kiss

Jesus was an only son _for you_

I’ll sing along while I break things

I broke a thousand hearts before I met you

One for every year of the empire

 _Rick and Morty_ , 100 years

www.WaltWhitmanRandolphBourne.net

World War I is so underrated

Circling back around to the mimetic swirl

Everything that’s happened and between us still

I’m out of time here love, it’s long passed into cadence

Long it be before I deign to linger on your fragrance 

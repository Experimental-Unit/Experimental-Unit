---
title: Amygdala & Logical Types, Part II
subtitle: Conclusion
author: Adam Wadley
publication: Experimental Unit
date: April 10, 2025
---

# Amygdala & Logical Types, Part II


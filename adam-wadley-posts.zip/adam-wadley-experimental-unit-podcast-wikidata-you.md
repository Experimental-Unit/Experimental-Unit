---
title: 'Experimental Unit Podcast: WikiData & You'
subtitle: The day you came across this will one day have its own WikiData page
author: Adam Wadley
publication: Experimental Unit
date: November 24, 2025
---

# Experimental Unit Podcast: WikiData & You
[![](https://substackcdn.com/image/fetch/$s_!2ZEm!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6b7caec1-39d5-4d64-9333-5293c0e0cc9b_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!2ZEm!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6b7caec1-39d5-4d64-9333-5293c0e0cc9b_3088x2316.jpeg)

---
title: First 1000 Wikidata Entries Created
subtitle: QID Label Description
author: Adam Wadley
publication: Experimental Unit
date: November 26, 2025
---

# First 1000 Wikidata Entries Created
QID Label Description

Q1 Universe totality consisting of space, time, matter and energy

Q2 Earth third planet from the Sun in the Solar System

Q3 life matter capable of extracting energy from the environment for replication

Q4 death permanent cessation of vital functions

Q5 human any single member of Homo sapiens, unique extant species of the genus Homo

Q8 happiness positive emotional state

Q13 triskaidekaphobia fear of the number 13

Q15 Africa continent

Q16 Canada country in North America

Q17 Japan island country in East Asia

Q18 South America continent

Q19 cheating breaking of rules to gain advantage

Q20 Norway country in Northern Europe

Q21 England country in north-west Europe, part of the United Kingdom

Q22 Scotland country in north-west Europe, part of the United Kingdom

Q23 George Washington Founding Father and first U.S. president (1789–1797)

Q24 Jack Bauer character from the television series 24

Q25 Wales country in north-west Europe, part of the United Kingdom

Q26 Northern Ireland part of the United Kingdom situated on the island of Ireland

Q27 Ireland country in Northwestern Europe

Q28 Hungary country in Central Europe

Q29 Spain country in southwestern Europe with territories in Africa

Q30 United States country located primarily in North America

Q31 Belgium country in western Europe

Q32 Luxembourg country in Western Europe

Q33 Finland country in Northern Europe

Q34 Sweden country in Northern Europe

Q35 Denmark country in Northern Europe and North America

Q36 Poland country in Central Europe

Q37 Lithuania country in northeastern Europe

Q38 Italy country in Southern Europe

Q39 Switzerland country in Central Europe

Q40 Austria country in Central Europe

Q41 Greece country in Southeast Europe

Q42 British science fiction writer and humorist (1952–2001) False

Q43 Turkey country in West Asia and Southeast Europe

Q44 beer alcoholic drink

Q45 Portugal country in Southwestern Europe

Q46 Europe continent in the Northern Hemisphere

Q48 Asia biggest continent in the world

Q49 North America continent

Q51 Antarctica polar continent

Q52 Wikipedia free multilingual online encyclopedia

Q53 Club-Mate caffeinated maté drink

Q54 Internet meme of wrongly translated line from a video game False

Q55 Netherlands country in Northwestern Europe with territories in the Caribbean

Q56 lolcat image combining a photograph of a cat with text intended to contribute humour

Q57 song written and composed by Stock Aitken Waterman, originally recorded by Rick Astley in 1986 and released in 1987 False

Q58 penis primary sexual organ of male animals

Q59 scripting language focused on web development False

Q60 New York City most populous city in the United States

Q61 Washington, D.C. capital city of the United States of America

Q62 San Francisco consolidated city and county in California, United States

Q64 Berlin federated state, capital and largest city of Germany

Q65 Los Angeles seat of Los Angeles County, and largest city in California, United States

Q66 Boeing American global aerospace and defense corporation

Q67 Airbus SAS European aircraft manufacturer, subsidiary of Airbus SE

Q68 computer general-purpose device for performing arithmetic or logical operations

Q69 Courrendlin municipality in the canton of Jura, Switzerland

Q70 Bern city in Switzerland, capital of the canton of Bern and de facto capital of Switzerland

Q71 Geneva city in Switzerland and capital of its canton

Q72 Zurich capital of the canton of Zurich, Switzerland

Q73 protocol for real-time Internet chat and messaging False

Q74 Breighton village in Yorkshire, England

Q75 Internet global system of connected computer networks based on IP addressing and routing protocols

Q76 Barack Obama president of the United States from 2009 to 2017

Q77 Uruguay sovereign state in South America

Q78 Basel city on the Rhine in Switzerland

Q79 Egypt country in Northeast Africa and Southwest Asia

Q80 Tim Berners-Lee English computer scientist (born 1955)

Q81 carrot root vegetable

Q82 printer computer peripheral that prints text or graphics

Q83 free and open-source wiki software, developed by the Wikimedia Foundation False

Q84 London capital and largest city of England and the United Kingdom

Q85 Cairo capital city of Egypt

Q86 headache pain in the head or neck

Q87 Alexandria city in Egypt

Q88 Alexandria city in the state of Virginia, United States

Q89 apple fruit of the apple tree

Q90 Paris capital city and largest city of France

Q91 Abraham Lincoln President of the United States from 1861 to 1865

Q94 operating system created by Google for use in mobile devices False

Q95 Google American multinational technology company, a subsidiary of Alphabet Inc.

Q96 Mexico country in North America

Q97 Atlantic Ocean ocean between Europe, Africa and the Americas

Q98 Pacific Ocean ocean between Asia, Australia and the Americas

Q99 California state of the United States of America

Q100 Boston capital and largest city of Massachusetts, United States

Q101 Lopado­temacho­selacho­galeo­kranio­leipsano­drim­hypo­trimmato­silphio­karabo­melito­katakechy­meno­kichl­epi­kossypho­phatto­perister­alektryon­opte­kephallio­kigklo­peleio­lagoio­siraio­baphe­tragano­pterygon fictional dish and longest word in ancient Greek language

Q102 artificial word for a lung disease; longest English word published in a dictionary False

Q103 Supercalifragilisticexpialidocious song from the film and musical Mary Poppins

Q105 Monday day of the week

Q107 space a three-dimensional extent within which entities exist and have physical relationships to each other

Q108 January first month in the Julian and Gregorian calendars

Q109 February second month in the Julian and Gregorian calendars

Q110 March third month in the Julian and Gregorian calendars

Q111 Mars fourth planet in the Solar System from the Sun

Q112 Mars Roman god of war, guardian of agriculture

Q113 Schulze method Single-winner electoral system

Q114 Kenya country in Eastern Africa

Q115 Ethiopia country in the Horn of Africa

Q116 monarch person at the head of a monarchy

Q117 Ghana country in West Africa

Q118 April fourth month in the Julian and Gregorian calendars

Q119 May fifth month in the Julian and Gregorian calendars

Q120 June sixth month in the Julian and Gregorian calendars

Q121 July seventh month in the Julian and Gregorian calendars

Q122 August eighth month in the Julian and Gregorian calendars

Q123 September ninth month in the Julian and Gregorian calendars

Q124 October tenth month in the Julian and Gregorian calendars

Q125 November eleventh month in the Julian and Gregorian calendars

Q126 December twelfth month in the Julian and Gregorian calendars

Q127 Tuesday day of the week

Q128 Wednesday day of the week

Q129 Thursday day of the week

Q130 Friday day of the week

Q131 Saturday day of the week

Q132 Sunday day of the week

Q133 mixed-member proportional representation Mixed electoral system centered on proportional representation with single-member district elements

Q134 bishop piece in the board game chess

Q135 pawn most numerous but the weakest piece in chess

Q136 knight piece in the board game of chess

Q137 rook piece from the board game chess

Q138 king piece from the board game chess

Q139 queen chess piece, able to move any number of squares vertically, horizontally or diagonally

Q140 lion species of big cat

Q141 Timbits type of doughnut sold by Tim Hortons

Q142 France country in Western Europe and other continents (through its overseas territories in America, Africa and Oceania)

Q143 Esperanto international auxiliary language designed by L. L. Zamenhof

Q144 dog domesticated species of canid

Q145 United Kingdom country in north-west Europe

Q146 cat small domesticated carnivorous mammal

Q147 kitten young cat

Q148 People’s Republic of China country in East Asia

Q149 Nyan Cat 2011 Internet meme

Q150 French Romance language

Q151 Wiktionary free online multilingual dictionary

Q152 fish vertebrate animal that lives in water and (typically) has gills

Q153 ethanol chemical compound

Q154 alcoholic beverage drink containing alcohols, typically ethanol

Q155 Brazil country in South America

Q156 alcohols any organic compound in which the hydroxyl functional group (–OH) is bound to a saturated carbon atom

Q157 François Hollande President of France from 2012 to 2017

Q159 Russia country in Eastern Europe and Northern Asia

Q160 Cetacea infraorder of marine mammals

Q161 fiber natural or synthetic substance that is significantly longer than it is wide

Q162 optical fiber light-conducting fiber

Q163 Yorkshire historic county of England

Q164 square regular quadrilateral

Q165 sea large body of saline water

Q166 Black Sea sea between Europe and Asia

Q167 pi constant ratio of the circumference of a circle to its diameter

Q168 pi sixteenth letter of the Greek alphabet

Q169 mango fruit of the mango tree

Q170 Pirate Parties International political international grouping

Q171 wiki type of website that visitors can edit

Q172 Toronto capital and largest city of the province of Ontario, Canada

Q173 Alabama state of the United States of America

Q174 São Paulo Municipality of São Paulo state, Brazil

Q175 São Paulo state in the Southeast Region of Brazil

Q176 Quebec province of Canada

Q177 pizza Italian universal popular dish with a flat dough-based base and toppings

Q178 pasta Italian food made from flour, eggs and water and shaped in different forms, usually cooked and served with a sauce

Q179 widebody airliner family (1968–2023) False

Q180 Wikimedia Foundation American charitable organization

Q181 Jimmy Wales American co-founder of Wikipedia (born 1966)

Q182 English Wikimedia disambiguation page

Q183 Germany country in Central Europe

Q184 Belarus country in Eastern Europe

Q185 American former professor, co-founder of Wikipedia, founder of Citizendium and other projects (born 1968) False

Q186 Ken Jennings American game show contestant, host, and writer

Q187 Il Canto degli Italiani national anthem of Italy

Q188 German West Germanic language spoken mainly in Central Europe

Q189 Iceland Nordic island country in the North Atlantic Ocean

Q190 God principal object of faith in monotheistic religions, a divine entity that created and typically supervises all existence

Q191 Estonia country in Northern Europe

Q192 David Cameron British politician (born 1966)

Q193 Saturn sixth planet from the Sun and the second-largest planet in the Solar System, after Jupiter

Q194 rings of Saturn planetary phenomena

Q195 chocolate nutritionally dense or sweet food product from the seed of Theobroma cacao - cocoa bean

Q196 cherry fruit of the cherry tree

Q197 airplane powered fixed-wing aircraft

Q198 war organized and prolonged violent conflict between different nations, states, or different groups within a nation or state

Q199 natural number one False

Q200 natural number False

Q201 natural number False

Q202 4 natural number

Q203 5 natural number

Q204 zero integer number zero; neutral element for the addition

Q205 infinity mathematical concept of something without any limit

Q206 Stephen Harper 22nd prime minister of Canada from 2006 to 2015

Q207 George W. Bush President of the United States from 2001 to 2009

Q208 rakfisk Norwegian fish dish made from trout or char

Q209 rectangle quadrilateral with four right angles

Q210 right angle 90° angle (π/2 radians): an angle that bisects the angle formed by two halves of a straight line

Q211 Latvia sovereign state in northeastern Europe

Q212 Ukraine country in Eastern Europe

Q213 Czech Republic country in Central Europe

Q214 Slovakia country in Central Europe

Q215 Slovenia country in Central Europe

Q216 Vilnius capital and largest city of Lithuania

Q217 Moldova country in Eastern Europe

Q218 Romania country in Southeast Europe

Q219 Bulgaria country in Southeast Europe

Q220 Rome capital and largest city of Italy

Q221 North Macedonia country in southeastern Europe

Q222 Albania country in southeastern Europe

Q223 Greenland autonomous territory of the Kingdom of Denmark and world’s largest island

Q224 Croatia country in Central Europe

Q225 Bosnia and Herzegovina country in Southeast Europe

Q226 Nuuk capital of Greenland

Q227 Azerbaijan country in the Caucasus in Eastern Europe and Western Asia

Q228 Andorra sovereign microstate between France and Spain, in Western Europe

Q229 Cyprus Mediterranean island country in West Asia

Q230 Georgia country in the Caucasus region of Europe and Asia

Q231 Wallonia region of Belgium

Q232 Kazakhstan sovereign state in Eastern Europe and Central Asia

Q233 Malta country in Southern Europe situated on an archipelago in the Mediterranean Sea

Q234 Flanders land of the Flemish people

Q235 Monaco microstate in Western Europe

Q236 Montenegro country in southeastern Europe

Q237 Vatican City Holy See’s independent state, an enclave within Rome, Italy

Q238 San Marino sovereign state in southern Europe, enclaved within Italy

Q239 City of Brussels municipality and capital city of Belgium

Q240 Brussels-Capital Region city and region of Belgium

Q241 Cuba sovereign state situated on an island in the Caribbean Sea

Q242 Belize sovereign state in Central America

Q243 Eiffel Tower tower located on the Champ de Mars in Paris, France

Q244 Barbados island nation in the Caribbean

Q245 Raspberry Pi series of low-cost single-board computers used for educational purposes and embedded systems

Q246 Volkswagen German automotive brand; manufacturing subsidiary of Volkswagen Group

Q247 Volkswagen Golf small family car manufactured by Volkswagen

Q248 Intel Corporation American multinational technology company

Q249 wireless communication transfer of information or power that does not require the use of physical wires

Q250 computer keyboard device comprising an arrangement of buttons or keys used to input text in computers

Q251 Java object-oriented programming language

Q252 Indonesia island country in Southeast Asia and Oceania

Q253 keyboard layout with first line “QWERTYUIOP” False

Q254 Wolfgang Amadeus Mozart Austrian composer of the Classical period (1756–1791)

Q255 Ludwig van Beethoven German composer (1770–1827)

Q256 Turkish Oghuz Turkic language of the Turkish people

Q257 Mandelbrot set fractal named after mathematician Benoit Mandelbrot

Q258 South Africa country in southern Africa

Q260 Jean-François Champollion French classical scholar (1790-1832)

Q261 Linkin Park American musical group; rock band

Q262 Algeria country in North Africa

Q263 Wikisource online multilingual library that collects open-content source material

Q264 Hurricane Sandy Category 3 Atlantic hurricane in 2012

Q265 Uzbekistan sovereign state in Central Asia

Q266 Drosera genus of plants

Q267 Cafeteria genus of marine bicosoecid

Q268 Poznań capital of the Greater Poland Voivodeship in west-central Poland

Q269 Tashkent capital of Uzbekistan

Q270 Warsaw capital and largest city of Poland

Q271 Prytanée National Militaire French military school

Q272 Paul Morand French writer (1888-1976)

Q273 Islay southernmost island of the Inner Hebrides in Argyll and Bute, Scotland, UK

Q274 Ardbeg Scotch whisky distillery

Q275 Forth Bridge railway bridge in eastern Scotland

Q276 Eurovision Song Contest annual song competition held among the members of the European Broadcasting Union

Q277 Kilchoman distillery distillery that produces single malt Scotch whisky on Islay

Q278 Talisker distillery whisky distillery in Highland, Scotland, UK

Q279 Modena Italian city and municipality

Q280 Lagavulin Distillery Scotch whisky distillery in Lagavulin, Islay, Argyll and Bute, Scotland, UK

Q281 whisky type of distilled alcoholic beverage made from fermented grain mash

Q282 wine alcoholic drink typically made from grapes through the fermentation process

Q283 water chemical compound whose molecules are formed by two hydrogen atoms and one oxygen atom

Q284 cognac alcoholic beverage; variety of brandy

Q285 Cognac commune in Charente, New Aquitaine, France

Q286 leather durable and flexible material created by the tanning of animal rawhide and skin

Q287 wood fibrous material from trees or other plants

Q288 Tours city and commune in Indre-et-Loire, Centre-Val de Loire, France

Q289 television telecommunication medium for transmitting and receiving moving images

Q290 sex biological system that determines an individual’s sexually reproductive function

Q291 pornography explicit portrayal of sexual acts and intercourse in media

Q292 Russian East Slavic language

Q293 Eurymorion genus of arachnids

Q294 Icelandic North Germanic language mainly spoken in Iceland

Q296 Claude Monet French painter (1840–1926)

Q297 Diego Velázquez Spanish painter (1599-1660)

Q298 Chile country in South America

Q299 Vidov village and municipality in the South Bohemian Region of the Czech Republic

Q300 Sagas of Icelanders group of narratives

Q301 El Greco Greek artist, painter, sculptor and architect, (1541–1614)

Q302 Jesus Christ central figure of Christianity (6 or 4 BC – AD 30 or 33)

Q303 American singer and actor (1935–1977) False

Q305 corporal punishment punishment which is intended to cause physical pain to a person

Q306 Sebastián Piñera Chilean entrepreneur and politician (1949–2024)

Q307 Galileo Galilei Italian polymath (1564–1642)

Q308 Mercury smallest and closest planet to the sun in the Solar System

Q309 history past events and their tracks or records

Q310 Taumatawhakatangihangakōauauotamateapōkaiwhenuakitānatahu hill in New Zealand

Q311 Père Lachaise Cemetery cemetery in Paris, France

Q312 Apple Inc. American multinational technology company based in Cupertino, California

Q313 Venus planet second-closest to the Sun in the Solar System

Q314 funeral litre painted funeral band on the internal or external walls of a church

Q315 language structured system of communication

Q316 love strong, positive emotion based on affection

Q317 dictatorship form of government which is ruled by a sole leader

Q318 galaxy large gravitationally bound system of stars and interstellar matter

Q319 Jupiter fifth planet from the Sun and largest planet in the Solar System

Q320 Michelle Bachelet Former President of Chile

Q321 Milky Way spiral galaxy in the Local Group containing the Solar System; its appearance across the night sky in areas with little to no light pollution

Q322 Llanfairpwllgwyngyll village in Anglesey, Wales, United Kingdom

Q323 Big Bang hypothetical begin of the Universe through expansion out of an infinitely small and infinitely dense state

Q324 Uranus seventh planet in the Solar System from the Sun

Q325 digital dark age conceptual situation in which large swathes of historic digitised materials are inaccessible

Q326 Eduardo Frei Ruiz-Tagle Chilean politician and president

Q327 Brittany cultural area located in northwestern France

Q328 English Wikipedia English-language edition of Wikipedia

Q329 Nicolas Sarkozy 23rd president of the French Republic from 2007 to 2012

Q330 Battle of Marignano 1515 battle between Switzerland and France

Q331 Ricardo Lagos Chilean politician, president of Chile from 2000 to 2006

Q332 Neptune eighth and farthest planet from the Sun in the Solar System

Q333 astronomy scientific study of celestial objects and phenomena

Q334 Singapore sovereign island country and city-state in maritime Southeast Asia

Q335 Patricio Aylwin Chilean politician and former president (1918–2016)

Q336 science systematic endeavor that builds and organizes knowledge, and the set of knowledge produced by this system

Q337 Lake Chaubunagungamaug lake in the town of Webster, Massachusetts, United States

Q338 cosmology scientific study of the origin, evolution, and eventual fate of the universe

Q339 Pluto dwarf planet in the Solar System

Q340 Montreal largest city in Quebec, Canada

Q341 free software software distributed under terms that allow users to freely run, study, change and distribute it and modified versions

Q342 Quimper commune in Finistère, France

Q343 La Flèche commune in Sarthe, France

Q344 future events, developments or states in time which have yet to occur

Q345 Mary mother of Jesus Christ

Q346 Louis IX of France King of France from 1226 to 1270 (1214–1270)

Q347 Liechtenstein country in Central Europe

Q348 time capsule cache of goods or data secured for some time to be opened at a date in the future

Q349 sport forms of recreational activity, usually physical

Q350 Cambridge city in Cambridgeshire, England

Q351 Yellowstone National Park first national park in the world, located in Wyoming, Montana, and Idaho in the United States

Q352 Adolf Hitler dictator of Germany from 1933 to 1945, main instigator of World War II and leader of the Holocaust (1889–1945)

Q353 Blanche of Castile Queen consort of France (1188–1252)

Q354 Piet Kraak Dutch footballer and football coach (1921-1984)

Q355 Facebook American online social media and social networking service

Q356 Google+ social networking service

Q357 Guantanamo Bay detention camp United States military prison at the Guantanamo Bay Naval Base, Cuba

Q358 heritage site general term for a site of cultural heritage for a specific country (please avoid as a P31 value except for large sites containing multiple entities)

Q359 WikiLeaks organization that publishes leaks provided by anonymous sources

Q360 Julian Assange Australian editor, publisher, and activist (born 1971)

Q361 World War I global war originating in Europe, 1914–1918

Q362 World War II 1939–1945 global conflict

Q363 World War III hypothetical global conflict

Q364 hosting service for software projects using Git False

Q365 Cologne most populous city in North Rhine-Westphalia, Germany

Q366 corruption form of dishonesty or criminal offense undertaken by a person or organization entrusted with a position of authority, to acquire illicit benefit or abuse power for one’s private gain

Q367 Wikibooks free multilingual online collection of textbooks

Q368 Augusto Pinochet dictator of Chile from 1973 to 1990

Q369 Wikiquote free multilingual online collection of quotes

Q370 Wikiversity online multilingual collaborative project for learning materials

Q371 !!! American dance-punk band from California

Q372 We Live in Public 2009 documentary film

Q373 Wikivoyage free multilingual online travel guide

Q374 vodka distilled alcoholic beverage

Q375 waffle batter- or dough-based food cooked between two patterned, shaped plates

Q376 timepiece instrument that measures the passage of time

Q377 Yanka Kupala Belarusian writer (1882–1942)

Q378 May fifth month in the Julian and Gregorian calendars

Q379 František Plánička Czech association football player (1904-1996)

Q380 Meta American multinational technology corporation

Q381 Ubuntu Linux distribution developed by Canonical

Q382 January first month in the Julian and Gregorian calendars

Q383 January first month in the Julian and Gregorian calendars

Q384 Skopje capital city of North Macedonia

Q385 Gdynia city in Pomeranian Voivodeship, Poland

Q386 Bixi bicycle-sharing system in Montreal, Québec, Canada

Q387 Old Bazaar bazaar in Skopje, North Macedonia

Q388 Linux family of Unix-like operating systems

Q389 Andrew and variants male name, and its local variations

Q390 Valdemar Wikimedia disambiguation page

Q391 Saint Catherine Street primary commercial artery of downtown Montreal, Quebec, Canada

Q392 Bob Dylan American singer-songwriter (born 1941)

Q393 Szczecin capital city of the West Pomeranian Voivodeship, Poland

Q394 metrology science of measurement and its application

Q395 mathematics field of study

Q396 U2 Irish rock band

Q397 Latin Indo-European language of the Italic branch

Q398 Bahrain country in the Persian Gulf

Q399 Armenia sovereign state in the South Caucasus region of Eurasia

Q400 Jenna Jameson American former pornographic actor (born 1974)

Q401 cuneiform ancient writing system used for many languages, including Akkadian and Hittite

Q402 Higgs boson elementary particle transmitting the Higgs field giving particles mass

Q403 Serbia country in Southeast Europe

Q404 HTTP 404 HTTP error response code

Q405 Moon Earth’s only natural satellite

Q406 Istanbul largest city in Turkey

Q407 Linda Lovelace American pornographic actress, later anti-porn activist (1949–2002)

Q408 Australia country in Oceania

Q409 Bob Marley Jamaican reggae musician (1945–1981)

Q410 Carl Sagan American astrophysicist, cosmologist and author (1934–1996)

Q411 astrobiology study of the formation of life on Earth and elsewhere on other planets in outer space

Q412 Pioneer plaque plaque attached to the Pioneer 10 and Pioneer 11 spacecraft in case extraterrestrial life finds them

Q413 physics study of matter and its motion, along with related concepts such as energy and force

Q414 Argentina country in South America

Q415 silbo Gomero whistled language from la Gomera island, Spanish Canarias.

Q416 disk magazine electronic magazine to be read using computers

Q417 biology scientific study of living things, especially their structure, function, growth, evolution, and distribution

Q418 telecommunications electronic transmission of information between locations

Q419 Peru sovereign state in South America

Q420 biology scientific study of living things, especially their structure, function, growth, evolution, and distribution

Q421 unidentified flying object unusual apparent anomaly in the sky that is not readily identifiable

Q422 Muséum de Toulouse natural history museum in Toulouse, France

Q423 North Korea sovereign state in East Asia

Q424 Cambodia country in Southeast Asia

Q425 Betsiboka River river in central-north Madagascar

Q426 animal rights rights of non-human animals

Q427 Kuiper Belt area of the Solar System beyond the planetary orbits comprising small bodies

Q428 Qur’an foundational Islamic religious text

Q429 Pcim Polish village in Lesser Poland Voivodeship

Q430 dinosaur clade of archosaurian reptiles (Archosauria)

Q431 zoology scientific study of animals

Q432 Islam Abrahamic religion founded by Muhammad

Q433 Gmina Kurów urban-rural gmina in Lublin Voivodeship, Poland

Q434 Pyrus genus of plants

Q435 Library of Alexandria one of the largest libraries in the ancient world, located in Alexandria, Egypt

Q436 Szczebrzeszyn city in Lublin Voivodeship, Poland

Q437 Ljubljana capital city of Slovenia

Q438 Vrhnika city in Slovenia

Q439 Wąchock town in Świętokrzyskie Voivodeship, Poland

Q440 Salvador Allende 28th president of Chile (1908–1973)

Q441 botany science of plant life

Q442 Natural History Encyclopedia published circa AD 77–79 by Pliny the Elder

Q443 Ich bin ein Berliner speech given by John F. Kennedy in West Berlin in June 1963

Q444 President of Poland from 1990 to 1995 False

Q445 Bibliotheca universalis 1545–49 listing of all the books printed in Latin, Greek, or Hebrew then known

Q446 wheel circular item that rotates about an axial bearing; one of the six simple machines

Q447 Encyclopédie general encyclopedia published in Paris, France between 1751 and 1772

Q448 Denis Diderot French Enlightenment philosopher writer and encyclopædist (1713–1784)

Q449 Georges Brassens French singer-songwriter and poet (1921–1981)

Q450 mind combination of cognitive faculties that provides consciousness, thinking, reasoning, perception, and judgement in humans and potentially other life forms

Q451 Mundaneum institution aimed to gather together all the world’s knowledge, “paper internet”

Q452 52-hertz whale individual whale which has been detected calling at 52 Hz, far above the normal whale vocal range

Q453 Borken town in the district of Borken, in North Rhine-Westphalia, Germany

Q454 peace state of harmony characterized by lack of violent conflict and freedom from fear of violence

Q455 Encyclopædia Britannica general knowledge English-language encyclopaedia, first published in Scotland in 1768

Q456 Lyon city of France

Q457 Poissy commune in Yvelines, France

Q458 European Union political and economic union of 27 European states

Q459 Plovdiv city in Plovdiv municipality, Plovdiv oblast, Bulgaria

Q460 Interpedia first-proposed online encyclopedia

Q461 Internet Archive American non-profit organization

Q462 Star Wars epic space opera multimedia franchise created by George Lucas

Q463 Rhône-Alpes former administrative region of France

Q464 Philipp Ludwig von Seidel German mathematician, optician and astronomer (1821-1896)

Q465 DBpedia online database project of structured data extracted from Wikipedia

Q466 World Wide Web global system of interlinked hypertext documents accessed via the Internet

Q467 woman female adult human

Q468 Encyclopedia Galactica fictional encyclopædia in several science-fiction universes

Q469 Dyson sphere hypothetical megastructure, originally described by Freeman Dyson

Q470 World Brain collection of essays by H. G. Wells

Q471 Memex hypothetical proto-hypertext system that was first described by Vannevar Bush in 1945

Q472 Sofia capital city of Bulgaria

Q473 The Library of Babel 1941 short story by Jorge Luis Borges

Q474 aqueduct structure constructed to convey water

Q475 Eduardo Frei Montalva President of Chile (1911-1982)

Q476 Ñ letter of the modern Latin alphabet, formed by an N with a diacritical tilde

Q477 Istanbul largest city in Turkey

Q478 Derval commune in Loire-Atlantique, France

Q479 God principal object of faith in monotheistic religions, a divine entity that created and typically supervises all existence

Q480 Don Quixote 1605 novel by Miguel de Cervantes

Q481 sponsored top-level Internet domain intended for pornographic websites False

Q482 poetry literary style characterized by a strong expressiveness of words

Q483 Megaupload former Hong Kong–based company

Q484 laziness disinclination to activity or exertion

Q485 computer virus type of computer program that, when executed, replicates itself by modifying other computer programs and inserting its own code

Q486 Chernobyl disaster 1986 nuclear accident in the Soviet Union

Q487 smile conscious or subconscious facial muscular movement conveying mirth or pleasure

Q488 atomic bombings of Hiroshima and Nagasaki 1945 use of nuclear weapons against Japan in World War II

Q489 Bill Maher American stand-up comedian and television host

Q490 Milan Italian commune and capital city of Lombardy

Q491 friendship relationship between people who have mutual affection for each other

Q492 memory mental faculties and processes involved in storing and retrieving information

Q493 French poet (1854–1891) False

Q494 Beakman’s World educational children’s television show

Q495 Turin city and commune in Italy

Q496 feces solid or semisolid remains of the food that passes through the bowel, from any animal

Q497 anus digestive track waste expulsion opening

Q498 Ulrich Frédéric Woldemar, Comte de Lowendal German-born French soldier and statesmen (1700-1755)

Q499 armpit area of the human body beneath the joint between arm and torso

Q500 Citrus × limon nothospecies of plant

Q501 Charles Baudelaire French poet and critic (1821–1867)

Q502 Stendhal French writer (1783–1842)

Q503 banana elongated, edible fruit produced by several kinds of large herbaceous flowering plants in the genus Musa

Q504 Émile Zola French novelist, journalist, playwright, and poet (1840–1902)

Q505 666 year

Q506 flower sexual reproductive structure found on flowering plants

Q507 googol large integer number defined as ten raised to the power of 100

Q508 googolplex large number defined as ten to the power of one googol

Q509 Lugdunum Musée et Théâtres museum about Roman Gaul in Lyon, France

Q510 Mariana Trench deepest oceanic trench on Earth

Q511 Museum of Fine Arts of Lyon art museum in Lyon, France

Q512 Vladimir Vysotsky Soviet singer-songwriter and actor (1938–1980)

Q513 Mount Everest Earth’s highest mountain above sea level, located in the Mahalangur Himal sub-range of the Himalayas

Q514 anatomy study of the internal structure of organisms and their parts

Q515 city large human settlement

Q516 Hôtel de Ville de Lyon city hall of Lyon, France

Q517 Napoleon French military leader, French Emperor 1804–1814 and again in 1815 (1769–1821)

Q518 Betta edithae species of fish in the Osphronemidae family

Q519 Shit Vulgar English word

Q520 Olympus Mons tallest volcano on Mars

Q521 physiology science regarding function of organisms or living systems

Q522 Hyper Text Coffee Pot Control Protocol communications protocol for controlling, monitoring, and diagnosing coffee pots

Q523 star astronomical object consisting of a luminous spheroid of plasma held together by its own gravity

Q524 Mount Vesuvius volcano on the southwestern coast of Italy

Q525 Sun star at the centre of the Solar System

Q526 species of fish False

Q527 sky everything that is above the surface of a planet, typically the Earth

Q528 pulsar located 1000 light years from the Sun False

Q529 Louis Pasteur French chemist and microbiologist (1822-1895)

Q530 Ingemar Stenmark Swedish alpine skier

Q531 light-year unit of astronomical length, defined as the distance that light travels in the vacuum in one year

Q532 village small clustered human settlement smaller than a town

Q533 Betta channoides species of fish

Q534 Ordinance on Industrial Safety and Health German law about health and safety in the workplace

Q535 Victor Hugo French novelist, poet, dramatist and politician (1802–1885)

Q536 Peaceful betta species of fish

Q537 Prince Eugens Waldemarsudde art museum in Stockholm, Sweden

Q538 Insular Oceania geographic region and continent

Q539 Italian general, patriot and republican (1807–1882) False

Q540 Hyphanet peer-to-peer Internet platform for censorship-resistant communication

Q541 Orvieto Italian comune

Q542 athletics sports involving running, jumping, throwing and walking

Q543 censorship practice of suppressing speech or other public communication which is illegal or against social norms.

Q544 Solar System the Sun, its planets and their moons

Q545 Baltic Sea sea in Northern Europe

Q546 Trieste city and seaport in northeastern Italy

Q547 Witterschlick locality in North Rhine-Westphalia, Germany

Q548 Vistula river in East-Central Europe

Q549 Siamese fighting fish freshwater fish native to Thailand

Q550 avenue des Champs-Élysées avenue in Paris, France

Q552 Oder river in Central Europe flowing from the Czech Republic and along the Poland–Germany border

Q553 tooth hard, calcified structure found in the jaws (or mouths) of many vertebrates and used to break down food

Q554 Cervelle de canut French cheese spread; specialty of Lyon

Q555 Rachel Maddow American television news host and political commentator

Q556 hydrogen chemical element with symbol H and atomic number 1

Q557 Patti Smith American singer, songwriter, author and poet (born 1946)

Q558 Hedi Slimane French Tunisian fashion designer (born 1968)

Q559 Claude Bourgelat French veterinary surgeon (1712–1779)

Q560 helium chemical element with symbol He and atomic number 2; rare gas

Q561 human tooth calcified whitish structure in humans’ mouths used to break down food

Q562 Pierre Poivre French horticulturalist (1719–1786)

Q563 Brigitte Fontaine French poet and artist

Q564 hell religious or mythological place of (often eternal) suffering

Q565 Wikimedia Commons online repository of free-use image, audio, and other media files

Q566 purgatory intermediate state after death for purification, according to the belief of some Christians

Q567 Angela Merkel chancellor of Germany from 2005 to 2021

Q568 lithium chemical element with symbol Li and atomic number 3

Q569 beryllium chemical element with symbol Be and atomic number 4

Q570 loudspeaker electroacoustic transducer that converts an electrical audio signal into a corresponding sound

Q571 book medium for recording information (words or images) typically on bound pages or more abstractly in electronic or audio form

Q573 day unit of time lasting 24 hours, derived from the period of Earth’s rotation about its axis

Q574 Timor-Leste sovereign state situated on several islands in Southeast Asia

Q575 night period from sunset to sunrise in each twenty-four hours

Q576 Jorge Alessandri Chilean politician and President (1896-1986)

Q577 year the orbital period of the Earth: the estimated period of time for the Earth’s orbit around the Sun and observed at a fixed geographic point (averaging 365.24 days); base later modified to define or adjust various calendars

Q578 century unit of time lasting 100 years

Q579 Carlos Ibáñez del Campo Chilean army officer and political figure (1877-1960)

Q580 Łódź city in Łódź Voivodeship in central Poland

Q581 Canegrate comune in the Metropolitan City of Milan, Lombardy, Italy

Q582 Villeurbanne commune in the metropolis of Lyon, France

Q583 Mont Blanc highest mountain in the Alps

Q584 Rhine river in Western Europe to the North Sea

Q585 Oslo capital city of Norway

Q586 Bonn city in Germany and capital of former West Germany

Q587 All Saints’ Day Christian feast day

Q588 Katowice city in Silesian Voivodeship, Poland

Q589 black hole astronomical object so massive, that anything falling into it, including light, cannot escape its gravity

Q590 16th-century Portuguese poet False

Q591 Fontgombault Abbey Benedictine monastery at Fontgombault, Berry, France

Q592 gay term referring to a homosexual person or the trait of homosexuality

Q593 A Gang Story 2011 film by Olivier Marchal

Q594 The King of Rome racing pigeon

Q595 The Intouchables 2011 film directed by Olivier Nakache and Éric Toledano

Q596 Ceres dwarf planet in the Solar System and largest asteroid of the main asteroid belt

Q597 Lisbon municipality and capital city of Portugal

Q598 Rzeszów city in Poland

Q599 wedding dress of Catherine Middleton dress worn by Catherine Middleton on the day of her wedding to Prince William, Duke of Cambridge, in 2011

Q600 Ichiro Suzuki Japanese Hall of Fame baseball player

Q601 Haumea dwarf planet in the Solar System

Q602 Rhône river in Switzerland and France

Q603 Frédéric Taddeï French journalist and TV host

Q604 136472 Makemake dwarf planet in the Solar System

Q605 Ezra Klein American journalist

Q606 Exiliboa placata non-venomous dwarf boa species

Q607 Michael Bloomberg American businessman and politician; 108th Mayor of New York City

Q608 human sexual behavior manner in which humans engage sexually

Q609 Kateri Tekakwitha Roman Catholic saint (1656–1680)

Q610 Iona island off the west coast of Scotland, UK

Q611 Eris dwarf planet in the Solar System

Q612 Dubai most populous city in the United Arab Emirates and the capital of the Emirate of Dubai

Q613 Emirate of Dubai one of the seven emirates of the United Arab Emirates

Q614 Place Bellecour square in Lyon, Auvergne-Rhône-Alpes, France

Q615 Lionel Messi Argentine association football player (born 1987)

Q616 Beaujolais wine wine from the Beaujolais region of France

Q617 Padua commune and capital city of the Province of Padua, Veneto, Italy

Q618 boron chemical element with symbol B and atomic number 5

Q619 Nicolaus Copernicus Polish mathematician and astronomer (1473–1543)

Q621 Versailles French city and commune in Yvelines, in Île-de-France

Q622 Ludwigsburg city in Baden-Württemberg, Germany

Q623 carbon chemical element with symbol C and atomic number 6; common element of all known life

Q624 Alessandro Del Piero Italian association football player

Q625 Metallic tower of Fourvière landmark in Lyon, France

Q626 Volga river in Russia; the longest river in Europe

Q627 nitrogen chemical element, symbol N and atomic number 7; most abundant element in Earth atmosphere

Q628 Bergamo comune in Lombardy, Italy

Q629 oxygen chemical element with symbol O and atomic number 8

Q630 Council of Lyon Parliament of the Cisalpine Republic

Q631 Inter Milan association football club based in Milan, Lombardy, Italy

Q632 Jean Moulin French resistance fighter and civil servant (1899-1943)

Q633 Neil Young Canadian singer, songwriter and filmmaker (born 1945)

Q634 planet celestial body directly orbiting a star or stellar remnant

Q635 Cleopatra queen of the Ptolemaic Kingdom of Egypt from 51 to 30 BCE

Q636 Kate Bush English singer, pianist and songwriter (born 1958)

Q638 music art using sound

Q639 optical aberration departure of the performance of an optical system from the predictions of paraxial optics

Q640 Harald Krichel German photographer; former vice chair of Wikimedia Deutschland

Q641 Venice capital city of Veneto, Italy

Q642 Naruto Japanese media franchise

Q643 Po longest river in Italy

Q644 Sharm el-Sheikh city in South Sinai, Egypt

Q645 Neva river in Russia connecting Lake Ladoga and the Baltic Sea

Q646 thermometer device that measures temperature or a temperature gradient

Q647 Rennes capital city of the region of Brittany, France

Q648 Lille city and commune in Nord, Hauts-de-France, Northern France

Q649 Moscow capital and most populous city of Russia

Q650 fluorine chemical element with symbol F and atomic number 9

Q651 Friedrich Theodor Vischer German philosopher, writer and politician (1807-1887)

Q652 Italian Romance language

Q653 Chihuahua Mexican dog breed

Q654 neon chemical element with symbol Ne and atomic number 10; rare gas

Q655 Chihuahua state of Mexico

Q656 Saint Petersburg federal city and former capital of Russia

Q657 Chad sovereign state in central Africa

Q658 sodium chemical element with symbol Na and atomic number 11

Q659 north one of the four cardinal directions

Q660 magnesium chemical element, symbol Mg and atomic number 12

Q661 hydraulic ram cyclic water pump powered by hydropower

Q662 Neon Genesis Evangelion Japanese anime television series

Q663 aluminium metallic chemical element of silvery appearance with symbol Al and atomic number 13

Q664 New Zealand island country in the southwest Pacific Ocean

Q665 Lugdunum ancient Roman city on the site of modern Lyon, France

Q666 number of the beast number associated with the beast in the Book of Revelation; either 666 or 616, depending on the manuscript

Q667 south one of the four cardinal directions

Q668 India country in South Asia

Q670 silicon chemical element with symbol Si and atomic number 14

Q671 francium chemical element with symbol Fr and atomic number 87

Q672 Tuvalu country in Oceania

Q673 One Piece Japanese media franchise

Q674 phosphorus chemical element with symbol P and atomic number 15

Q675 André-Marie Ampère French physicist and mathematician (1775–1836)

Q676 prose form of language which applies ordinary grammatical structure and natural flow of speech

Q677 iron chemical element with symbol Fe and atomic number 26

Q678 Tonga sovereign state in Oceania, situated on an archipelago

Q679 west one of the four cardinal directions

Q680 Alessandro Volta Italian physicist, chemist, and pioneer of electricity and power (1745-1827)

Q681 Warsaw University of Life Sciences public agricultural university in Warsaw, Poland

Q682 sulfur chemical element with symbol S and atomic number 16

Q683 Samoa sovereign state made up of six islands in the Pacific Ocean

Q684 east one of the four cardinal directions

Q685 Solomon Islands island sovereign state in Oceania

Q686 Vanuatu island country in Oceania

Q687 Molière French playwright and actor (1622–1673)

Q688 chlorine chemical element with symbol Cl and atomic number 17

Q689 Bastille English indie pop band

Q690 Delft city and municipality in the Netherlands

Q691 Papua New Guinea country in Oceania

Q692 William Shakespeare English playwright and poet (1564–1616)

Q693 fable short fictional story that often anthropomorphises non-humans to illustrate a moral lesson

Q694 South Holland province of the Netherlands

Q695 Palau island sovereign state in Oceania

Q696 argon chemical element with symbol Ar and atomic number 18; rare gas

Q697 Nauru country in Oceania

Q698 free and open source web browser False

Q699 fairy tale fictional story typically featuring folkloric fantasy characters and magic

Q700 Swedish Chef Muppet character

Q701 North Holland province of the Netherlands

Q702 Federated States of Micronesia island sovereign state in Oceania

Q703 potassium chemical element with symbol K and atomic number 19

Q704 Olympique Lyonnais association football club in Lyon, France

Q705 Zeeland province of the Netherlands

Q706 calcium chemical element with symbol Ca and atomic number 20

Q707 Flevoland province of the Netherlands

Q708 lead chemical element with symbol Pb and atomic number 82

Q709 Marshall Islands country near the equator in the Pacific Ocean

Q710 Kiribati island sovereign state in the central Pacific Ocean

Q711 Mongolia country in East Asia

Q712 Fiji island sovereign state in Oceania

Q713 scandium chemical element with symbol Sc and atomic number 21

Q714 Stevie Wonder American and Ghanaian singer-songwriter, composer and record producer (born 1950)

Q715 Heilbronn German city in the state of Baden-Württemberg

Q716 titanium chemical element with symbol Ti and atomic number 22

Q717 Venezuela sovereign state in northern South America

Q718 chess strategy board game

Q719 Saginaw seat of Saginaw County, Michigan, United States

Q720 Genghis Khan founder and first khan of the Mongol Empire (1162–1227)

Q721 Life, the Universe and Everything 1982 novel by Douglas Adams

Q722 vanadium chemical element with symbol V and atomic number 23

Q723 Rookie Blue Canadian police drama television series

Q724 Maine state of the United States of America

Q725 chromium chemical element with symbol Cr and atomic number 24

Q726 horse domesticated four-footed mammal from the equine family

Q727 Amsterdam capital and most populous city of the Netherlands

Q728 weapon tool intended or likely to inflict damage or harm

Q729 animal kingdom of multicellular eukaryotic organisms

Q730 Suriname country in South America

Q731 manganese chemical element, symbol Mn and atomic number 25

Q732 Francesinha Portuguese sandwich

Q733 Paraguay sovereign state in South America

Q734 Guyana country in South America

Q735 art general concept that creates expressive work for its beauty or emotional power (use Q838948 for the resulting work, use Q2018526 for the group of creative disciplines)

Q736 Ecuador sovereign state in South America

Q737 rhenium chemical element with symbol Re and atomic number 75

Q738 croque-monsieur baked or fried ham and cheese sandwich

Q739 Colombia sovereign state in South America

Q740 cobalt chemical element with symbol Co and atomic number 27

Q741 Yaroslav male given name (Ярослав)

Q742 Jean Racine French dramatist (1639–1699)

Q743 tungsten chemical element with symbol W and atomic number 74

Q744 nickel chemical element with symbol Ni and atomic number 28

Q745 Fragaria genus of plants

Q746 croque-madame baked or fried ham and cheese sandwich served with a poached or lightly fried egg on top

Q747 Pierre Corneille French tragedian (1606–1684)

Q748 Buddhism Indian religion

Q749 Groningen capital city of the province of Groningen, the Netherlands

Q750 Bolivia sovereign state in South America

Q751 osmium chemical element with symbol Os and atomic number 76

Q752 Groningen northeasternmost province of the Netherlands

Q753 copper chemical element with symbol Cu and atomic number 29

Q754 Trinidad and Tobago island sovereign state in the Caribbean

Q755 Paul Verlaine French poet (1844–1896)

Q756 plant living thing in the kingdom of photosynthetic eukaryotes

Q757 Saint Vincent and the Grenadines island sovereign state in the Caribbean Sea

Q758 zinc chemical element with symbol Zn and atomic number 30

Q759 New Hampshire state of the United States of America

Q760 Saint Lucia island sovereign state in the Caribbean Sea

Q761 Białystok city and capital of Podlaskie Voivodeship in eastern Poland

Q762 Leonardo da Vinci Italian Renaissance polymath (1452−1519)

Q763 Saint Kitts and Nevis island sovereign state in the Caribbean Sea

Q764 fungi biological kingdom, separate from plants and animals

Q765 Dario Fo Italian actor, playwright, comedian, singer-songwriter, theater director, painter, and political activist (1926-2016)

Q766 Jamaica island state in the Caribbean Sea

Q767 Stéphane Mallarmé French Symbolist poet (1842–1898)

Q768 Supetar town and settlement in Split-Dalmatia County, Croatia

Q769 Grenada island sovereign state in the Caribbean Sea

Q770 Friesland province of the Netherlands

Q771 Massachusetts state of the United States of America

Q772 Drenthe province of the Netherlands

Q773 Overijssel province of the Netherlands

Q774 Guatemala sovereign state in Central America

Q775 Gelderland province of the Netherlands

Q776 Utrecht province of the Netherlands

Q777 Google Chrome web browser developed by Google

Q778 The Bahamas island sovereign state in the West Indies

Q779 Connecticut state of the United States of America

Q780 chicken domesticated bird kept by humans primarily as a food source

Q781 Antigua and Barbuda island sovereign state in the Caribbean Sea

Q782 Hawaii state of the United States of America

Q783 Honduras sovereign state in Central America

Q784 Dominica island sovereign state in the Caribbean Sea

Q785 Jersey British Crown dependency in the Channel Islands

Q786 Dominican Republic island sovereign state in the Caribbean Sea

Q787 pig domesticated omnivorous even-toed ungulate

Q788 Arctic Ocean smallest, shallowest, coldest, and northernmost of the world’s major oceans

Q790 Haiti country in the Caribbean Sea

Q791 Taumatawhakatangihangakōauauotamateapōkaiwhenuakitānatahu hill in New Zealand

Q792 El Salvador sovereign state in Central America

Q793 Zwolle municipality in Overijssel, the Netherlands

Q794 Iran country in Western Asia

Q795 stupidity lack of intelligence or understanding

Q796 Iraq sovereign state in Western Asia

Q797 Alaska state of the United States of America

Q798 Assen municipality in and capital city of Drenthe, the Netherlands

Q799 wisdom deep understanding or knowledge of a subject

Q800 Costa Rica country in Central America

Q801 Israel country in West Asia

Q802 Nowy Sącz town in Lesser Poland Voivodeship, Poland

Q803 Utrecht municipality in the Netherlands and capital city of the province of Utrecht

Q804 Panama sovereign state in Central America

Q805 Yemen country in West Asia

Q806 Randstad conurbation in the Netherlands

Q807 Lausanne capital city of the canton of Vaud, Switzerland

Q808 virus non-cellular, submicroscopic infectious agent that replicates only inside the living cells of an organism

Q809 Polish West Slavic language

Q810 Jordan country in West Asia

Q811 Nicaragua sovereign state in Central America

Q812 Florida state of the United States of America

Q813 Kyrgyzstan sovereign state in Central Asia

Q814 Coco Austin American model (born 1979)

Q815 Gabriel Gonzáles Videla Chilean politician (1898-1980)

Q816 Arizona state of the United States of America

Q817 Kuwait sovereign state in Western Asia

Q818 Florida Province province of Bolivia

Q819 Laos country in Southeast Asia

Q820 Juan Antonio Rios Chilean politician and President (1888-1946)

Q821 Cercado province of the Beni Department, Bolivia

Q822 Lebanon country in West Asia

Q823 Iténez province of Bolivia

Q824 Oregon state of the United States of America

Q825 God in Christianity Christian conception of God

Q826 Maldives sovereign state in South Asia, situated on an archipelago in the Arabian Sea

Q827 José Ballivián Province province of Bolivia

Q828 Americas North America and South America taken together as a single continent or landmass

Q829 Utah state of the United States of America

Q830 cattle large, domesticated, cloven-hooved herbivores

Q831 ciao salutation of Italian origin

Q832 Mamoré Province province of Bolivia

Q833 Malaysia country in Southeast Asia

Q834 Canton of Valais canton of Switzerland

Q835 Mikhail Bulgakov Russian author (1891–1940)

Q836 Myanmar country in Southeast Asia

Q837 Nepal country in South Asia

Q838 Andrei Rublev medieval Russian artist (1360s-1428)

Q839 Georgina Cassar Gibraltarian rhythmic gymnast (born 1993)

Q840 Europe continent in the Northern Hemisphere

Q841 Marbán province of Bolivia

Q842 Oman sovereign state in western Asia

Q843 Pakistan sovereign state in South Asia

Q844 James Bond series of books about a British spy

Q845 Pedro Aguirre Cerda Chilean politician and president (1879-1941)

Q846 Qatar country in West Asia

Q847 tennis racket sport played on a court bisected by a net

Q848 Arturo Alessandri Chilean politician and President (1868–1950)

Q849 François Villon French poet and criminal

Q850 SQL database engine software False

Q851 Saudi Arabia country in West Asia

Q852 Lockheed L-1011 TriStar airliner family

Q853 Andrei Tarkovsky Soviet and Russian film director, screenwriter, film editor, film theorist, theatre and opera director (1932–1986)

Q854 Sri Lanka island country in South Asia

Q855 Joseph Stalin leader of the Soviet Union from 1924 to 1953

Q856 barcode optical machine-readable representation of data

Q857 Juan Luis Sanfuentes Chilean politician and President (1858-1930)

Q858 Syria country in West Asia

Q859 Plato 4th-century BCE Greek philosopher

Q860 foobar placeholder names in programming

Q861 gallium chemical element with symbol Ga and atomic number 31

Q862 Joseph Brodsky Russian-American poet (1940-1996)

Q863 Tajikistan sovereign state in Central Asia

Q864 Pokémon Japanese media franchise

Q865 Taiwan country in East Asia

Q866 YouTube American video-sharing platform owned by Alphabet Inc.

Q867 germanium chemical element with symbol Ge and atomic number 32

Q868 Aristotle 4th-century BCE Classical Greek philosopher and polymath

Q869 Thailand country in Southeast Asia

Q870 train form of rail transport consisting of a series of connected vehicles

Q871 arsenic chemical element with symbol As and atomic number 33

Q872 radio technology of signaling and communicating using radio waves

Q873 Meryl Streep American actress

Q874 Turkmenistan country in Central Asia

Q875 Abakan capital city of the Republic of Khakassia, Russia

Q876 selenium chemical element with symbol Se and atomic number 34

Q877 iridium chemical element with symbol Ir and atomic number 77

Q878 United Arab Emirates country in West Asia

Q879 bromine chemical element with symbol Br and atomic number 35

Q880 platinum chemical element with symbol Pt and atomic number 78

Q881 Vietnam country in Southeast Asia

Q882 Charlie Chaplin British comic actor and filmmaker (1889–1977)

Q883 Novosibirsk Russian city; administrative center of Siberian Federal District

Q884 South Korea country in East Asia

Q885 Józef Piłsudski Polish politician, First Marshall, and Prime Minister (1867–1935)

Q886 The Simpsons American animated sitcom created by Matt Groening

Q887 Yekaterinburg 4th largest city in Russia, administrative center of Ural Federal District

Q888 krypton chemical element with symbol Kr and atomic number 36; rare gas

Q889 Afghanistan country in Central and South Asia

Q890 Gangnam Style 2012 single by Psy

Q891 Nizhny Novgorod capital of the Nizhny Novgorod Oblast and the Volga Federal District in central Russia

Q892 J. R. R. Tolkien English writer and philologist (1892–1973)

Q893 lemonade lemon-flavored beverage

Q894 Samara city in Samara Oblast, Russia

Q895 rubidium chemical element with symbol Rb and atomic number 37

Q896 Mountain Dew carbonated soft drink brand

Q897 gold chemical element with symbol Au and atomic number 79

Q898 Omsk city in Russia

Q899 Suez Canal artificial sea-level waterway in Egypt

Q900 Kazan city in the Republic of Tatarstan, Russia

Q901 scientist person who use scientific methods to study in an area of interest

Q902 Bangladesh country in South Asia

Q903 Erta Ale volcano in Ethiopia

Q904 Bleach Japanese media franchise

Q905 Franz Kafka Bohemian writer from Prague (1883–1924)

Q906 Chelyabinsk city in Russia, capital city of Chelyabinsk Oblast

Q907 Gordon Freeman fictional protagonist of the Half Life video game series

Q908 Rostov-on-Don city and administrative center of Rostov Oblast in southern Russia

Q909 Jorge Luis Borges Argentine writer, essayist, poet and translator (1899–1986)

Q910 Top Gear Wikimedia disambiguation page

Q911 Ufa capital city of the Republic of Bashkortostan, Russia

Q912 Mali country in West Africa

Q913 Socrates 5th-century BCE Greek philosopher

Q914 Volgograd city and administrative center of Volgograd Oblast in southern Russia

Q915 Perm city in Russia

Q916 Angola country on the west coast of Southern Africa

Q917 Bhutan sovereign state in South Asia

Q918 X American social networking service founded in 2006

Q919 Krasnoyarsk city in Krasnoyarsk Krai, Russia

Q920 J. Bernlef Dutch writer and translator (1937-2012)

Q921 Brunei sovereign country and sultanate on the island of Borneo in south-east Asia, member of the Commonwealth of Nations

Q922 Brač island of Croatia

Q923 Alexander male given name

Q924 Tanzania country in East Africa

Q925 mercury chemical element with symbol Hg and atomic number 80

Q926 Roald Amundsen Norwegian explorer; first person to reach the South Pole (1872–1928)

Q927 Harry Mulisch Dutch writer (1927–2010)

Q928 Philippines archipelagic country in Southeast Asia

Q929 Central African Republic country in Central Africa

Q930 Konstantin Melnikov Russian architect and painter (1890-1974)

Q931 Naruto Uzumaki fictional character from Naruto

Q932 thallium chemical element with symbol Tl and atomic number 81

Q933 South Pole one of the two points where the Earth’s axis of rotation intersects its surface

Q934 North Pole one of the two points where the Earth’s axis of rotation intersects its surface

Q935 Isaac Newton English mathematician and physicist (1642–1727)

Q936 OpenStreetMap online collaborative project creating a world geographic database

Q937 Albert Einstein German-born theoretical physicist

Q938 strontium chemical element with symbol Sr and atomic number 38

Q939 Pedro I of Brazil Emperor of Brazil (1822–31) and King of Portugal (1826)

Q940 narcotic class of psychoactive drugs with numbing, sedative, and analgesic properties (distinct from the legal category)

Q941 yttrium chemical element with symbol Y and atomic number 39

Q942 bismuth chemical element with symbol Bi and atomic number 83

Q943 yellow primary color between green and orange in the light spectrum

Q944 quantum mechanics fundamental theory in physics describing the properties of nature on an atomic scale

Q945 Togo country in West Africa

Q946 Donald Tusk Prime Minister of Poland (2007–2014; since 2023)

Q947 arsenic chemical element with symbol As and atomic number 33

Q948 Tunisia country in North Africa

Q949 John Bardeen American physicist and engineer (1908–1991)

Q950 Schnütgen Museum museum of medieval Christian religious art in Cologne, Germany

Q951 toilet paper orientation orientation of the free end of a roll of toilet paper, either over or under the roll, when used with a holder with an axle parallel to both the wall and floor

Q952 Reggiolo town in the province of Reggio Emilia, Emilia-Romagna, Italy

Q953 Zambia country at the crossroads of Central and Southern Africa

Q954 Zimbabwe sovereign state in southern Africa

Q955 Aardenburg city in Sluis, Netherlands

Q956 Beijing capital city of China

Q957 list of lists of lists Wikimedia list of lists

Q958 South Sudan country in East Africa

Q959 Vladivostok Russian city and the administrative center of Primorsky Krai

Q960 Tuva Republic and federal subject of Russia

Q961 More Than Life at Stake Polish television series

Q962 Benin sovereign state in West Africa

Q963 Botswana sovereign state in Southern Africa

Q964 Wikinews free online multilingual news

Q965 Burkina Faso sovereign state in Africa

Q966 Hermann Brunner Fictional Polish television character

Q967 Burundi sovereign state in Africa

Q968 Warburg town in North Rhine-Westphalia, Germany

Q969 Abbekerk village in Medemblik, Netherlands

Q970 Comoros sovereign state situated on an archipelago in the Indian Ocean off the eastern coast of Africa

Q971 Republic of the Congo country in Central Africa, capital Brazzaville

Q972 Alkmaar municipality in the province of North Holland, the Netherlands

Q973 Ob second-longest river in Russia

Q974 Democratic Republic of the Congo country in Central Africa

Q975 San Antonio city in Bexar, Comal, and Medina counties in Texas, United States, that is the seat of Bexar County

Q976 Tomsk city in and administrative center of Tomsk Oblast, Russia

Q977 Djibouti sovereign state in Africa

Q978 meme idea, behavior or style that spreads within a culture

Q979 polonium chemical element with symbol Po and atomic number 84

Q980 Bavaria federated state in the south of Germany

Q981 Warburg village in Alberta, Canada

Q982 FIS Alpine Ski World Cup top international circuit of alpine skiing competitions

Q983 Equatorial Guinea sovereign state in Africa

Q984 Miles Franklin Australian writer and feminist (1879–1954)

Q985 Baden-Württemberg state in the southwest of the Federal Republic of Germany

Q986 Eritrea country in the Horn of Africa

Q987 New Delhi capital city of India

Q988 Almelo municipality in the province of Overijssel, the Netherlands

Q989 John Paul II 264th pope of the Catholic Church (1920–2005)

Q990 Czterej pancerni i pies Polish television series

Q991 Fyodor Dostoyevsky Russian novelist (1821–1881)

Q992 Amersfoort municipality in the province of Utrecht, the Netherlands

Q993 Kamchatka Peninsula peninsula in Eastern Russia between the Pacific Ocean and the Sea of Okhotsk

Q994 Tbilisi capital and the largest city of Georgia (country)

Q995 Appingedam city and former municipality in Eemsdelta, Netherlands

Q996 Miles Franklin Literary Award annual Australian literature award

Q997 Andrei Sakharov Soviet nuclear physicist and human rights activist (1921–1989)

Q998 infant very young offspring of a human

Q999 astatine chemical element with symbol At and atomic number 85

Q1000 Gabon country on the Atlantic coast of Central Africa

---
title: '[Music] Hauntology Haus Theme'
subtitle: Traveling Thread, Gravid Dread
author: Adam Wadley
publication: Experimental Unit
date: July 08, 2025
---

# [Music] Hauntology Haus Theme
[![](https://substackcdn.com/image/fetch/$s_!yGLR!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fee974ffb-8ff1-4ee1-89bb-05361faa6017_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!yGLR!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fee974ffb-8ff1-4ee1-89bb-05361faa6017_3088x2316.jpeg)

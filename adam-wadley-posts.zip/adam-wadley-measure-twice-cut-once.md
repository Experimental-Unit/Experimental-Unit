---
title: Measure Twice, Cut Once
subtitle: Can I Claim My Nervous System Got Hacked? Havana Syndrome? ...Anything?
author: Adam Wadley
publication: Experimental Unit
date: April 13, 2025
---

# Measure Twice, Cut Once
More measured and thinking of things to lay out.

Just talking of the national question. Because of course the big issue is ascendant hypernationalism. And everyone is wondering how to defeat it.

And yet everyone is combating things in a national way. We are now effectively locked in a civil war in the United States. There is no possibility of thinking outside of the horizon of Trump doing what he wants to do, or whatever, and the question being whether anything will stop him.

The issue is that on a whole societal level you face what we in the trauma slut business call battered person syndrome.

I also want to highlight here the parallel between the institutional and the interpersonal weaponized Gish Gallop.

# What’s Being Used Against You:

You basically have chains of people doing this to each other. That’s what hierarchy is. But so, how does informal hierarchy develop where allegedly everyone’s equal here?

You are being hit with a one-two punch:

  1. Someone avoids crucial points by failing to acknowledge key topics consistently. This prevents you from abstracting over them.

    1. For example interpersonally: someone will not admit that they abuse you. Because “what would it mean” if they just admitted that an act they committed was abusive? Then all of a sudden it would simply be true and for anyone to say that “they abused you” and then you can abstract over that. “Abusers do this and that,” is something that could have relevancy to you. All of a sudden this person would be vulnerable to all sorts of questioning, and they stymie this by foreclosing the conversation on a crucial point. Think of it like the Battle of Thermopylae, you are fighting at a choke point in order to deny “the enemy,” or in this case the feared Other, access to more open terrain from which to surround you. 

    2. In terms of states, see the admission of a genocide. Turkey for example will not acknowledge “the Armenian genocide,” which other people take for granted. After all, what “would it mean” if Turkey admitted that a genocide took place under Ottoman rule? All of a sudden many more things would come into play, actions taken and things made right. It is easier simply not to budge on this crucial choke point in order to prevent down-stream consequences from being considered. Again, the one even provides ground to abstract over, in the way that winning one concession can lead to more and more. We have basically here a Domino Theory of “dominance.”

  2. In order to prevent the crucial narrative choke point from being broached, instead one simply utilizes the “gish gallop” technique, by which one simply changes the subject in whatever way possible in order not to respond to the pointed point directly.

    1. Interpersonally, you will be told your tone is wrong, that your word choice is incorrect, given some excuse. There are infinite things that someone might try to throw at you while you are “just” trying to get them to acknowledge a crucial point. As long as you are invested in getting them to say this, and continue to argue about the things they throw at you, your nervous system is getting more degraded than theirs is, because they have predictability and continually are refusing you something and you are practically begging for it by indulging their endless litany of excuses. What winds up happening is that you will either explode, which will then give the gish galloper more fuel to use against you; or else you will simply be worn into submission, at which point the gish galloper will continue to assume “dominance” over you by molding your perception in ways convenient for their perception of their interests. This is an improvisational art, mind you, not a science, so no grand plan is needed although it may well exist. The end result is you are a “trauma slut” for this person and are basically caved to them and they will run your life until something comes to a head or one of you die. Picture something being poisoned by a spider and impregnated with its eggs all wrapped up and drifting off like someone falling asleep in the snow about to die of hypothermia. Oh, but crucially to mirror the next part, on that first point? When you wanted someone to admit they were rude or something? You’ll never get that because you’ll get worn down or something else will happen, you’ll be the bad one because you exploded, or maybe they’ll even give it to you as a Pyrrhic victory after they’ve raped the shit out of you emotionally or otherwise. At that point it doesn’t matter and is a further humiliation to you because you have lost so much that you are now less able or unable to argue any further such points.

    2. In terms of state, you might be told you don’t have standing, or you might not have the permit for the thing, or it’s the wrong jurisdiction, or they sent it to the people but the people didn’t get back to them, or it’s an ongoing investigation, or it’s a national security matter, or they’ll get back to you, and on and on. For example, the crucial question with UAPs for example in New Jersey recently was that “the government” held the position that UAPs were both mysterious and yet not a threat. The crucial point is that it can’t be known for certain that something is harmless if its nature is unknown. So what is the explanation for this crucial contradiction? That answer is simply never given, and eventually events are so distracting that no answer is even sought anymore.




In both cases, you are simply getting outlasted by someone with maybe more resources than you—see how strikers can simply be outwaited; but interpersonally you might have more resources than the other person, you are simply goaded into deploying them inefficiently—but more than that, you are being provoked into giving up your “energy” faster.

Once one person is exhausted and the other is not, and engagement continues, then the one who is exhausted will no longer be able to engage as an “equal.” 

Now back to the use of “dominance” in quotation marks.

# Who Does Sir Stephen Work For?

There’s this book called _The Story of O_ which I’m using as an archetypal example of what, the submission of people with vaginas to people with penises, something like that. In the story, O is a person with a vagina who has a “partner” with a penis.

First of all, it is kind of disgusting the way people use the word “partner” when they are really in an “abusive relationship.”

“Abuse relationship” is an issue as a concept because it’s sort of like individualizing “mental illness.” What you have is an emergence from a broader phenomenon. In particular when you’re talking about the emotional and physical domination of people with vaginas by people with penises, it’s obviously an endemic situation you are talking about, stretching back possibly to time immemorial.

The first thing to say is that nothing should ever be “naturalized.” In particular here, we can for example be dealing with asymmetric forms of emotional rape or as Baudrillard might say symbolic mastery. After all, that’s what _Seduction_ is all about in the parts where it’s saying that “male dominance” is basically a bad rumor.

Next, the basic idea from _The Story of O_ that I’m trying to say is that in the story, O is taken to a special house for “BDSM” or erotic submission. This subject is fascinating not only because of the idea of strange details in the sex lives of people with so many resources to use to adorn their passions, but also because this, the artifice of erotic “domination,” is a crucial feature of all of our lives.

For example, we would like to separate sexual feelings from non-sexual feelings. Yet this is patently not the case. People’s feelings about their parents or early caregivers are well known to influence their sexual feelings. This is only one obvious example. Being humiliated by you boss, or some bully, someone acting as a bully toward you, fundamentally activates the same feelings as a sexual rejection or argument with a sexual partner.

Anyway, O is taken to this house and the person with a penis O associates with hits her, and does all this stuff. Okay. The point is that then, another person with a penis shows up and this time I remember the name was Sir Stephen (SS, lol; I was just looking today at how boats are called SS this and that; how ludicrous).

The first person with a penis then basically says to O that Sir Stephen is now going to do to O what the first person did and more or whatever, and now basically the “power exchange” that O gave to the first person with a penis is now going to happen with this Sir Stephen person. And it does and it’s all very stimulating.

I actually didn’t finish the book, there’s probably a lot I’m missing to make my point.

The point is that the problem for a woman or a person with a vagina is not that they are going to be subordinated to one person with a penis. No, the problem is that there’s a lot of them. Not only that, but the people with penises have their own hierarchies, such that someone with a vagina or anyone, really, and this is what this is getting to; but such that if you are subordinated to one person with a penis, then you are subordinated to all the people with penises that that person is either subordinated to in turn (and the chain continues), or else in league with to a greater extent than they are to you.

“Bros before hos.”

# Elon and Grimes

Point in case: is Elon Musk more loyal to Grimes or to some other group of people with penises?

So now we can have the question of why it should be mostly people with penises. After all, there is Trump’s Chief of Staff. But crucially Trump has a penis, and so many in the military and intelligence and corporate forces do as well.

These are the top echelons of people that we can even see. Or people reputed to have high net worths, various grand heirs. But how is that whole set of relationships even playing out?

We fundamentally do not know.

It is similar to how interpersonally, you do not know one link up the chain why someone is acting the way they do. They “won’t let you in.” Meanwhile, you are left to bang your heart against this “mad bugger’s wall,” as we say in _The Wall_ biz. Because you have no choice.

Because you think you love them. Because they have nuclear weapons.

So how must it be for Claire Elise Boucher, whose person with a penis who impregnated them in their uterus such that they were with child; that this person should now be unreachable, obviously in pain but not “letting them in,” in a position to cause harm to Claire themselves as well as their now trinitarian progeny together? 

And meanwhile this person is not only a person with a penis, not only a “wealthy” person, not only politically connected, but literally about the second-highest-profile person on the planet and intimately involved in the revolutionary affairs of “state” underway around the vortex which follows one Donald John Trump.

So for Grimes, what I’m saying is that this intimate affair of “how the deep state works,” or what the social network system-of-systems running under “the hood” of what someone like me is _allowed to see_ might be; this intimate affair is entirely bound up in Grimes’ erotic relation to the (former?) beloved. Not to mention the children!

# What Is A Child?

What does a child represent?

It represents the continuation of life. It represents the ability to create new life from old, our age old way of what we call sexual reproduction or procreation. 

Pro Create is now a digital production software.

In a similar way we say that a certain work is “our baby.”

It’s our baby because we hope to set it out into the world for it to take on a life of its own. Like an invention which catches on.

Think of the Cotton Gin, Eli Whitney’s “baby.” Meanwhile, “Everything is Connected” by Blancmange is playing.

The Cotton Gin changed everything, I’m not sure why it automatically got capitalized, lol. And how did the CG help “capitalize”?

Anyway, an artwork is also something we gestate, give birth to. 

It’s just the same with thinking of something to say, or having something to say and searching for the right words, putting effort into your tone.

If you’re going to put some intention into something you say, then I would hope you’d put some intention into creating a whole other person who then will face the same symbolic challenges you face.

That said, it’s not really possible to do. This goes back to reputation in the sense of Army Narrative Competition: it requires good will and competence.

The problem is that no one is really competent to set the intention, say, to protect their progeny from the threats of the world. Should every parent be some sort of super-expert statesman able to solve world issues so as not to subject their children to them?

Of course that is too much to expect. Yet we can still ask, what is the moral status of bringing more life into the world absent world-changing (or, ending: see Afropessimism) activity?

I was just speaking to one of my parental parts (lifting the German term “Elternteil”) who was saying again about how nuclear war was also feared in the 1970s and so on. It was impressed upon me that it’s unlikely that “we are all about to die” or anything like that.

Let me be clear: I have no specific idea of what’s going to happen, some obsession with some concrete reality.

I always refer to things like nuclear war, bioweapons, drones, although the way it’s looking it could just be economic collapse with heavy killing of desperate people deemed unnecessary for future “power.”

I can see all sorts of reasons and scenarios where there is no hot war soon, or uber-pogrom, or something. Sure, I could be wrong that this is possibility we need to take active action to prevent.

On the other hand, this sort of outcome seems inevitable. We have climate which is a time limit which will impose heavy costs and kill massive numbers of people.

Then, what’s popping on the political front? Everyone hates each other, hypernationalism is sharpening the knives, and no one has any ideas of what to do but wait it out and hope for the best.

This is what I call “dicking around on the train to Auschwitz.”

So what, then, is you intention toward your child? And if you have no child, then toward your “babies”?

What’s the intention for a work of art going out to a planetary audience that could all be dead in a few years? What are the stakes of whatever standard of living when it won’t matter once the black moths of technology, Hobbesian Trap, and failure to symbolically die come to feast on you like locusts?

Crucially this is not only a future occurrence. Foreboding, misery, and despair are our bread-and-butter emotions. Everyone is “not having fun.” Suicide rates are still high and rising particularly in many demographics, namely those who are most exposed to the pressing doom.

So what, then, is Claire Elise Boucher’s intention toward their children? Again understanding the intimate relation, if second-hand through Elon Musk, to “the halls of power,” again at least what everyone takes for them.

Is the strategy to sit by and hope for the best?

Boucher has discussed the importance of art in shifting the tide. This is precisely the raising of the influence operation beyond the sphere of goal oriented activity, it is the raising of emergency response beyond the affective cloud of “emergency.”

In other words, we can all take the tip of engaging in artful intervention. This is just what Ben Zweibelson and the military design movement are playing with.

# Art Game

If I should become famous, what I’m trying to show you can be grasped strongly by my pointing at Claire Elise Boucher and Ben Zweibelson. These are the individuals that I have put the most effort into discussing and hence influencing. A simple question is, why Claire and Ben, and what direction am I trying to influence them in?

Boucher I actually as I’ve said came across really through searching for the term “misanthropocene.” It is that pun leading to the album _Miss Anthropocene_ which indicated to me that Boucher was the artist of the moment. The relationship to Musk at that point is gravy.

Many “fans” are of course dismayed by Grimes’ association with Musk and the coterie of people involved, Yarvin, whatever. You have to understand that for me, yeah Musk stands to symbolically die. But so do you, and so do I. Over and over, as much as we can. So that we don’t have to literally die, at least not super soon.

Anyway, for me as an artist and where I already understand how everything is implicated, and sure, Elon Musk is pretty annoying and just happens to be the face of whatever is going on, but there was always going to be someone who that was given the emergent conditions brought about again by everyone; anyway, for me the idea that the greatest living artist, or the artist of the moment, was associated with the “richest person” (I like to put “rich” or “wealth” in quotes because first no one owns anything, and secondly what do you know of riches?) was great.

It’s a conduit between creativity and “power.” It’s an “in.” And so when Boucher later declared themselves as an “AI spy for love” or whatever, that was feeding perfectly into my fantasy.

Yes, I describe it openly as a fantasy. It’s open-ended, mind you, and mysterious. Is it erotic? Is anything not?

Anyway, compare fantasy to FICINT and Zweibelson’s “phantasmal war” concept.

But again, all this follows from the greatness of _Miss Anthropocene_. 

  1. First of all, from perspective of person with vagina, full of anguish of bearing violence, giving life, watching people die. See wordplay from misanthropy and Anthropocene to misanthropocene to Miss Anthropocene, the title of an unmarried person with a vagina often. See also how Jessica in _Dune_ is crucially not married to Paul’s father but merely a concubine. Even in real marriage or whatever is held to be the standard—”partners”—true symbolic reciprocity and equality is not acknowledged between person with penis and person with vagina, crucially as it relates to relationships outside. Note that all sorts of different situations also exist, but that this “sex aspect” must of course be borne in mind and is beyond me or anyone to foreclose on.

  2. The main song which makes the work “of the moment” for me is “New Gods,” which echoes a 1966 interview given by Martin Heidegger (see Martin Luther (King Jr.), and St. Martin who cut the cloak in half as well) called “Only a god can save us.” Here we have New Gods, which is also a comic book reference to go with the song Darkseid, which again ties into the first theme mentioned above. Not to mention the line “are you a man? are you something I can’t stand?” And this is tying into the line from “My Name is Dark” that “I’m not shy but I refuse to speak because I don’t trust that you’ll understand me.” This is the typical failure of communication or openness which leads to the situation where “imminent annihilation seems so dope,” exactly this pervading misanthropy which makes everyone Bad Company (also a band name). This is precisely the position from which “only brand new gods can save me.” The word “brand” ties into Grimes’ stated interest in “corporate surrealism.” We can tie this also into the idea of the “one dimensional man,” my idea of the chud, or Nietzsche’s “last man.” The failure here is the failure to self-disrupt or transcend, to become the over-man. This concept is vindicated by our actual overcoming of the necessity of sexual reproduction through technology. And more crucially the influx of genetic engineering on those who are already alive. This maps onto a conceptual analogue, which is our ability to apply more design to our social ontologies instead of taking them as given.

  3. The album ends with the idea of a “beautiful game.” I’m trying to keep this short if not meandering. So the album is hopeful in the end, although it is said that we are destined to “lose” the game. I’m thinking here of the movie _Arrival_ , where the Amy Adams character knows that the child will die but has it anyway, just to be able to have to moments with the child that were there. So in this case, what does it mean to make the most of the moments with the child? In _Arrival_ , this fantasy ends with the child young enough that it must not confront the full symbolic futility of the "normal” parent, i.e. must not confront the moral injury of bringing life into being which it knows it cannot protect, and cannot protect from the humiliation beings experience at not being able to protect those they care about whether they’re their children or not. Regardless, _Miss Anthropocene_ does not succumb to negativity. It emphasizes trembling, also big in Kierkegaard and taken up by Afropessmism.

  4. Oh yeah, that trembling reference is a key tie to Afropessimism as well as the line “this is the sound of the end of the world” from “Before the Fever.” We can also go to “New Gods” again where it says “I wear _black_ eyeliner, _black_ attire.” We can also go to the song “My Name is Dark,” remembering again that Claire named the person with a vagina birthed by surrogate but with Claire’s and Musk’s genetic material “Exa DARK,” making the song title “my name is dark” true for Claire’s child, and we know Claire values this idea of does the child have a penis or vagina despite at other times expressing the intention to raise the children “without gender.” Anyway, there is also a crucial reference where a Grimes fan is pestering Claire for an autograph and Claire falls, and the fan is a black man and tells Claire to “stay black.” These are all crucial openings from the theme of Claire Elise Boucher to blackness, which turns out to be a crucial narrative strand to be commenting on, analogous (sorry) to things like world religions, political philosophies, etc.




Oh, I forgot to mention, the interest in misanthropy was also tied to Schopenhauer, and hence Nietzsche as well, and Schopenhauer’s engagement with “Buddhism” and “Hinduism.” This relates to the question of “the will,” and how all individual wills may cohere in one overall will of Brahman or something like that. This also comes up with my contrast between the erotic and martial approaches to the will of the other. Basically the erotic approach does not seek to control the will of the other, and is open to its mystery. Meanwhile, the martial approach sees “the problem” as being that people have different wills and come to blows as a result. This is war “as politics,” which is then engaged with by Zweibelson.

So to sum up, Claire is a target of my influence operations because they’re at a crucial symbolic Nexus. As an artist, Claire is putting out wonderfully expressive and conceptual art which is engaging with the anguish and possibilities that we all face to transcend ourselves and engage in a new way. Meanwhile, Claire is by now in a position of supreme influence. And, of course, subjection. Back to _The Story of O_. But also back to my questioning of “wealth.” Are we really so sure that Elon Musk has access to more wealth than Claire? Either way it doesn’t really matter what they have; both are _living currency_. On top of which through works like the _Chaos Manual_ Claire is engaged at just the level I am with respect to Alternate Reality Games, basically reality design. This follows perfectly from my interest in Baudrillard.

Ben Zweibelson: I’m tired, I’ll have to continue tomorrow. But for now, Zweibelson I literally found while searching for military theory that references Baudrillard. Because radicals or whatever always say Baudrillard can’t be applied, or something. So I went to military theory because what is more hard-nosed than that?

That’s where I saw “Preferring Copies with No Originals,” by Zweibelson. I continued to follow this person and they wound up years later putting out _Understanding the Military Design Movement_ and _Beyond the Pale_ , along with several articles I read on Medium.

My other big fantasy has to do precisely with “the deep state.” Because so starting from basics: “Adam, why don’t you take a wife and have children?” Well, the problem is that my children would die in a nuclear war or something. You want to make the world safe for democracy, I want to make the world safe for my children. We are not the same. Just kidding.

Anyway, if I’m going to try to make the world safe for new life to come into, then obviously I have to deal with “power politics.” This is the deep level at which shit is decided, after all. So there must be a reckoning with “the powers that be.”

Within that, what is going on? There’s a lot of ideology, and so on, but there’s also an art and science to it. This amounts to things like compartmentalization, creating incentive wheels, basically perception management and designing little OODA loops for people to be in such that they are feeding your goals and unable to abstract over their efforts to take over your position.

And yet any stage of this process involves multiple people, where the hierarchy between them is informal and we’re back to the top level of this essay.

I have settled on this question of the problem of building trust within the innermost inside of such a “deep state” operation. It seems to me to be an impossible problem, since people who instrumentalize some “outsiders” must inevitably instrumentalize themselves.

So, my fantasy has to do with the “deep state” people basically lobotomizing each other with nano-drones, or secret assassinations of people I’ve never heard of but who are really influential. I also have this fantasy of a battle royale to the end where let’s say 10,000 people kill off everyone else, but then 100 people kill off the other 9,900, and soon enough there’s only a few people left, and they kill each other until there is one person left, and then they commit suicide out of regret.

This is my negative prophecy: what is destined to happen absent a fundamental reorientation.

Zweibelson, meanwhile, is about to drop a book called _Reconceptualizing War_ which has a second chapter dedicated to Anatol Rappaport and the idea of abolishing war itself, and getting past it.

Zweibelson notes that first of all we could simply lose control of conflict to artificial intelligence. I would point out that this has already happened, the conflict has been lost to the collective unconscious. What’s happening is that the shadow is coming out, it is Grimes’ lyric “the ocean rising up above the ground,” where the ocean is the subconscious, which again crucially is not some secret your brain is keeping from you. It’s all around. It’s what’s unacknowledged. What you won’t admit even to yourself (because what would that “mean"? In other words, what would it mean if your thoughts could abstract over that?).

This is also the revenge of the mirror people. And we are all the mirror people. What I’m going through right now for example is just what’s always been in me having to come out. You’re going through the same thing. It’s not actually bad. It’s just everything. Think of it like vomit. Vomit can stink and might be gross, but you’re so much happier after you did. Sometimes anyway. Sometimes it just has to come out. “Get it all out” is what I was told.

Anyway, Zweibelson is crucially sitting in the armed forces. Zweibelson even sounds like they have a pretty high position, director of some strategic innovation group at Space Command. This now is going back again to Sir Stephen.

Zweibelson is somewhere in this nebulous hierarchy of mostly people with penises which leads right to the actual forefront of technology and conflict dynamics.

So again you can see these themes running through my whole engagement of procreation and the futility of making new things when they’re just about to be dead. And you don’t know if they are but you’re not allowed to know because some secret people somewhere won’t let you know.

So then the whole fantasy has to involve being able to influence such people through '“soft power,” through art, even though I can’t take them by force.

So then the question becomes around influence operations, and again this phantasmal war. The war is not between people but fantasies.

So then my crucial insight is simply to create fantasies that can eat other fantasies and make them harmless. The point is that everyone can get what they symbolically most covet at the same time. And even, isn’t the most basic fantasy basically to get along and feel like you are taking advantage, but it’s really sustainable because the others also find themselves to be taking advantage? Isn’t the fantasy to be, by one’s presence, a simple Good for the other, that others are so grateful to get to be around you? “My presence is a present; kiss my ass!” - Kanye

Anyway, I’m going to have to continue. But that’s some of what I have to say.

---
title: Completed Graphs Of Bounded Size For Creative Structuring
subtitle: In this article, I will be attempting to express to your clearly the application
  of some pretty simple mathematics to my interest in “crossovers.” Since I’m going
  ahead and featuring this image again (it is kind of a classic), we can use the elements
  which have been combined here to populate the “structured data” we will cobble together.
author: Adam Wadley
publication: Experimental Unit
date: December 18, 2025
---

# Completed Graphs Of Bounded Size For Creative Structuring
[![](https://substackcdn.com/image/fetch/$s_!D1yh!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcf7c0eea-23f9-44f9-a11f-c322e2577b96_1536x1024.png)](https://substackcdn.com/image/fetch/$s_!D1yh!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcf7c0eea-23f9-44f9-a11f-c322e2577b96_1536x1024.png)

In this article, I will be attempting to express to your clearly the application of some pretty simple mathematics to my interest in “crossovers.” Since I’m going ahead and featuring this image again (it is kind of a classic), we can use the elements which have been combined here to populate the “structured data” we will cobble together.

[Relevant art keywords: Found Object, assemblage, readymade, bricolage]

So all we are going to do is collect a group of elements. For each pair of elements, there will be something that comes of it.

If we have three elements, A, B, and C, then we will wind up with 3 pairs:  
1\. (A,B)  
2\. (A,C)  
3\. (B,C)

The thing is that since we are having _all_ of the members of our group be grouped together with _each_ possible pairing, the number of pairs will grow pretty quickly.

This could make it unwieldy or daunting to make an extended graph this way, at least at first.

Yet let me tell you why I think it would be very interesting to do so anyway, sticking to smaller sizes at first, or in general.

What is nice about such an organization, where _every_ element of the grouping, or in other words, everything that’s on the graph, must be related to every other thing, is that it builds up a rich _density_ of associations.

It is powerful to get a person thinking about all their different associations, because so much of what there is interesting for us to say, interesting to know about each other, are things that we often wouldn’t think to say. This is where this sort of creative exercise can help us re-familiarize ourselves with ourselves, and learn more about ourselves.

When it comes to two elements where you really don’t know what to say about how they could be related, that is just an opportunity again for divergent thinking. This is an opportunity for each person to come up with something that they are satisfied with.

When we are trying to get data out of someone, or more pleasantly, when we are trying to learn about someone, we don’t really just want to learn more about how to sort them into this or that box. What we really want it to get to the chess position that’s never been reached before. We want everything to come together for this person as they process everything at once, pretty much. Which is to say we want to know about the unique features of someone.

Last side note before I do the exercise for you to show you how it’s done with the elements from the picture: this “uniqueness” extends beyond a supposed uniqueness as “a” sentient being. Imagine meeting all sentient beings at the end of time. In addition to the infinite sentient beings that we would conventionally say have been alive in “the universe,” there’s also all the sentient beings from all the _other_ possible universes. Yet there is also not just “one” version of each “universe,” but rather infinite of them for each permutation of what could have happened.

So when we are learning about you, let’s say you had something big happen to you when you were 10. So we’re not just learning about you the person overall, but the version of you that had that happen, and the version that responded the way you did, down to the granular detail of every single little thing you’ve ever been a part of (you can see why karma is like this meticulous accounting—”every hair is numbered like every grain of sand.”

Applying again this category of Sonder, you can expand from thinking about all the people’s lives—not to mention animals—that you will never really know the full richness of, and then you can apply that to all your other possible selves, too. And all of everyone else’s possible selves. But the point that I’m trying to emphasize here is that each time we are learning, where someone is filling in a graph or notating or expressing or just exhibiting the product of their cognitive-affective emergence, it is a highly specific thing and in that way can be cherished: ichi go ichi e.

Okay, on to the show!

Let’s list the elements that make up this image. We will give each one a letter for shorthand.

I actually just realized that I want to do an exercise where there are only a few elements. Let’s stick to five. So I will choose five elements of the image to draw in.

[![Dexter's Laboratory: Dee Dee Was Secretly the Real Star](https://substackcdn.com/image/fetch/$s_!r2qI!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F67a8afc3-5165-4390-96ca-4cddaed7e82f_1400x700.jpeg)](https://substackcdn.com/image/fetch/$s_!r2qI!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F67a8afc3-5165-4390-96ca-4cddaed7e82f_1400x700.jpeg)

#### 1\. Dee Dee 

Dee Dee is a character from the cartoon _Dexter’s Laboratory_.[1](https://experimentalunit.substack.com/p/completed-graphs-of-bounded-size#footnote-1-182019639)[2](https://experimentalunit.substack.com/p/completed-graphs-of-bounded-size#footnote-2-182019639)

[![The Ring' review by Entertainment Weekly critic Owen Gleiberman](https://substackcdn.com/image/fetch/$s_!1OqO!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F122ece2c-f08c-46a9-ba50-46209a8a0638_1500x1000.jpeg)](https://substackcdn.com/image/fetch/$s_!1OqO!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F122ece2c-f08c-46a9-ba50-46209a8a0638_1500x1000.jpeg)

#### 2\. Samara Morgan coming out of the TV (implicit)

Samara Morgan[3](https://experimentalunit.substack.com/p/completed-graphs-of-bounded-size#footnote-3-182019639) is a character from _The Ring_ , which is an English-language adaptation of a prior Japanese-language story.

[![Wovoka](https://substackcdn.com/image/fetch/$s_!0l57!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2440a8bc-e710-4500-8b0d-9f3dc5dae16f_900x1200.jpeg)](https://substackcdn.com/image/fetch/$s_!0l57!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2440a8bc-e710-4500-8b0d-9f3dc5dae16f_900x1200.jpeg)

#### 3\. Wovoka

Wovoka[4](https://experimentalunit.substack.com/p/completed-graphs-of-bounded-size#footnote-4-182019639) (1856-1932) was a Paiute religious leader associated with the second episode of what is known as the Ghost Dance movement.

[![](https://substackcdn.com/image/fetch/$s_!it_U!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fac3d7b93-cbcb-47be-b489-2f7bfef121d4_1004x513.png)](https://substackcdn.com/image/fetch/$s_!it_U!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fac3d7b93-cbcb-47be-b489-2f7bfef121d4_1004x513.png)

#### 4\. Getting “Jumanji’d”

“Getting Jumanji’d” is a phrase used in a _Saturday Night Live_ sketch[5](https://experimentalunit.substack.com/p/completed-graphs-of-bounded-size#footnote-5-182019639) featuring Kirsten Wiig, notably also in _mother!_ To be “Jumanji’d” is either to be sucked into a game or for the game (in this case a board game) to come “out of the game” and emerge into “the real world.”

[![](https://substackcdn.com/image/fetch/$s_!dJ0-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F37be27c7-e749-46d3-94ed-4d14f28992ad_761x695.png)](https://substackcdn.com/image/fetch/$s_!dJ0-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F37be27c7-e749-46d3-94ed-4d14f28992ad_761x695.png)

#### 5\. Phoebe Plummer

Phoebe Plummer[6](https://experimentalunit.substack.com/p/completed-graphs-of-bounded-size#footnote-6-182019639) (2001 - ) is called a climate activist and is known for being one of two to throw soup on a Van Gogh painting at the National Gallery in London.  
  
So, now we have our five elements:

  1. D for Dee Dee

  2. S for Samara

  3. W for Wovoka

  4. J for “Getting Jumanji’d”

  5. P for Phoebe/Plummer




As a list, it looks like this: (D, S, W, J, P).

Now we are ready to make pairs of these elements.

A breakdown of the math: the amount of connections goes like this for small values:

1 element: 0

2 elements: 1 pair (+1 from previous total)

3 elements: 3 pairs (+2)

4 elements: 6 pairs (+3)

5 elements: 10 pairs (+4)

6 elements: 15 pairs (+5)

And so on. Whenever we add a new element, it has to connect to all the previous elements, so this goes up by one each time.

This process can also be thought of as the idea of how many handshakes would there have to be for everyone in a room to shake hands with everyone else? You can see that if there were 30 people, it would take forever and be confusing. That’s why we are sticking to 5 elements for now.

Okay, Let’s go!

We’ll go in order, starting with Dee Dee.

Dee Dee is part of four pairs. For our purposes here, the order does not matter. So (D, S) is the same as (G, S). It is arbitrary how you put it, it means the same thing so you can do it as you please.

Here are the pairs Dee Dee is a part of. For each connection, I’m going to imagine that I’m making a knowledge graph. Let’s say I am talking to someone about one topic, the first one, and then I am trying to change topics to the other. So what is the bridge between these two things?

Interestingly, it could also just be anything you want. I was thinking about it like this. Let’s take the first pair, (D,S). You could sort of fill in the blank.

For all of the following, note anything which comes to you, if anything.

D + S = ____  
D - S = ____

S - D = ____

S x D = ____

D / S = ____

S / D = ____

S ^ D = ____

D ^ S = ____

And so on. These are crude ways to try to get us thinking about just smashing concepts together and describing what they do when operationalized together.

Normally, we only think to get into such detail, or think about a topic, if it seems relevant to what we are trying to do. On the contrary, here it is almost that the goal is to lose the goal in a bit of ecstasy of smashing things together. There is a serial completion to it as you just go through the motions of putting everything together. Like trying every combination of ice creams to see if any unusual combination might be super good.

We should basically think about our entire cognitive-affective terrain as this ice cream. It can be difficult to do, but that’s often because we give each other the feedback that what each other is saying and each other’s ideas in general are not important. So we are used to taking it all for granted because usually no one will listen to us. The project of getting us to do structured data or something is equally the project of us being more delighted to go through all the minutia. Yet this trawling will inevitably have to “process” what is difficult. So we have some stark topics here, let’s get into it.

For our purposes, we will have 10 connections.

Dee Dee, as mentioned is part of four pairs. Let’s see what it looks like.

#### 1\. (D, S) - Dee Dee & Samara Morgan

Dee Dee and Samara are both fictional characters who are presented to be what are considered girls.

Dee Dee is shut out of Dexter’s Lab and is destructive in trying to connect with Dexter and deflate their ego, while Samara has powers deemed dangerous and is killed, only to haunt the planet as a videotape to try and get people to understand their suffering.

So, both characters have this arc of being shut out and then trying to break their way into recognition or relationship.

#### 2\. (D, W) - Dee Dee & Wovoka

Wovoka is associated with a dance, and Dee Dee likes to dance (Dee Dee wears a ballet outfit all the time).

The Ghost Dance has to do with the kinship of all things overtaking imperial power, while in “the Way of Dee Dee” Dee Dee attempts to teach Dexter the limits of reductionist thinking.

Both Dee Dee and Wovoka are in some sort of tension with a rigid and unfeeling application of science and technology.

#### 3\. (D, J) - Dee Dee & “Getting Jumanji’d”

Dee Dee disrupts Dexter’s work, while “Getting Jumanji’d” is unusual, that is, “getting Jumanji’d” is disruptive given what people thought they were going to do.

Both Dee Dee and “Getting Jumaji’d” seem to have a thematic tension with the conceit of making plans, and this notion of “real life” and “serious business.” Rather, both Dee Dee and Jumanji in this instance are extremely disruptive of what is “normal,” “expected,” or “everyday,” often through _play_.

#### 4\. (D, P) - Dee Dee & Phoebe Plummer

Phoebe Plummer has related a moment of disillusionment when they realized that “adults” did not, in fact, have everything going well. The shock of climate catastrophes destroyed their simple faith in scientific experts. Similarly, Dee Dee criticizes Dexter for not really caring about their inventions, and attempts to get them to “really look” at a flower as a way of practicing presence.

Both Dee Dee and Phoebe Plummer try to get people cooped up inside to care about the broader planet outside, and their impact on everything.

Also, some people really dislike Dee Dee as a character, and many people think Phoebe Plummer’s Van Gogh action was not a good idea. So other are lightning rods for displeasure.

#### 5\. (S, W) - Samara Morgan & Wovoka

Samara Morgan creates the killer video tape and basically goes on to engage in cyber operations (operating through lightning or _blitz_ ) as part of a campaign of revenge but also for recognition.

Meanwhile, Wovoka is emblematic of the Ghost Dance movement, which had as its aim the reuinification with the spirits of the dead and the displacement of encroaching empire.

So, both Samara Morgan and Wovoka are engaged in high-stakes and possibly deadly campaigns to redress substantial harms.

#### 6\. (S, J) - Samara Morgan & “Getting Jumanji’d”

Samara Morgan comes out of the TV, while “getting Jumanji’d” involves Jumanji coming out of itself, or you going in. In _The Ring_ , Naomi Watts winds up going into the same well themselves that Samara died in for seven days ( _“seven days”_ ).

Both Samara Morgan and “Getting Jumanji’d” have a quality similar to a play within a play or alternate reality game, in which a media artifact like a video or game “emerges” magically from itself to impose its logic on “the real world” beyond what would ordinarily be expected of such artifacts.

#### 7\. (S, P) - Samara Morgan & Phoebe Plummer

Samara Morgan drips water from the well onto the floor when they come out of the TV, while Phoebe Plummer is known for throwing soup on a painting.

Samara Morgan has a huge effect through their psychic powers, while Phoebe Plummer committed a world-famous action through the use of creativity, daring, and conviction.

Both Samara Morgan and Phoebe Plummer are known for damaging objects which are “not theirs” with liquid.

Bother Samara Morgan and Phoebe Plummer used their imaginations inspired by their pain at uncaring destruction and hurtfulness to cause notable effects.

#### 8\. (W, J) - Wovoka & “Getting Jumanji’d”

Wovoka represents an example of someone who played a pivotal role in a social movement which was also cosmological in nature. These movements and ideas are themselves like a story which then becomes real, as events take their turn and everyday things pass into momentous changes. Also, Wovoka and all indigenous people sort of “got Jumanji’d” by what is considered colonization overall. Here comes an outside game and all of a sudden your own experience is subsumed into the “rules” coming from elsewhere. Being displaced, one is then in a similar position as Alan in “Jumanji,” in the wilderness, lacking provisions, etc.

“Getting Jumanji’d,” meanwhile, implies that a certain frame is being imposed, a certain “game” is taking over the previously more open space of “life itself.” This is similar to a change in government or change in how things are administered. Someone who “gets Jumanji’d” must then respond by taking the frame which has been imposed as a constraint but either trying to play the game through or find an exploit.

Both Wovoka and “getting Jumanji’d” involve the application of heavy frames from “outside” and the subsequent attempt to “get out” from under them.

#### 9\. (W, P) - Wovoka & Phoebe Plummer

Wovoka was a spiritual leader who advocated for a change in conditions to favor their people and protect the land from industrial destruction, using the established cultural wealth of the Ghost Dance.

Meanwhile, Phoebe Plummer became an aesthetic icon by taking creative action using the established cultural entity of Van Gogh’s painting, and used that gesture to appeal to people to concern themselves with ecological destruction, which is always steadily accelerating with millions of sentient beings dying every day.

Both Wovoka and Phoebe Plummer tapped into established cultural veins to take stands as real people (only “real people” on this list) for justice and to make the point that ecology, the planet and life that we find on it, are important in their own right. Both call a broad audience to greater awareness, activity, and dedication.

#### 10\. (J, P) - “Getting Jumanji’d” & Phoebe Plummer

“Getting Jumanji’d” involves a game overflowing itself, it spills out of its container until real life is consumed by the logic of the game.

Phoebe Plummer’s action on the Van Gogh painting can itself be considered art.[7](https://experimentalunit.substack.com/p/completed-graphs-of-bounded-size#footnote-7-182019639) Thus Plummer did performance art which then led to a whole international incident and further consequences, like jail time. So in this sense, “art” itself coalesced into Van Gogh’s painting and then Plummer also did “art,” but this time it’s not something that’s in a museum, it’s a court case, because everyone involved “got Jumanji’d” by art.

Both “Getting Jumanji’d” and Phoebe Plummer have to do with something overflowing its container and affecting “the real world” in a poewrful way, whether a game or artistic expression respectively.

#### Outro

Wow, gang, that took a lot of effort!

The elements I chose were also all obviously similar and related anyway, but still. This is what is called a completed graph now, because every possible pair has an edge, has a connection.

For me, this is a metonymy for how we all have pairwise relations. So me and you, whoever you are, we have a pairwise “edge,” just like we do with everyone else. You can see why we shortchange things sometimes, because if you got into everything it would be exceptionally tedious. There’s so much!

Yet I’ll be interested to develop this idea further. My intuition is that making such a “dense,” subjective graph will yield good information because it’s all establishing relevance to each other.

I was also thinking that you could make a group of everything, and everything’s route to everything else is by way of the other elements. So then that relationship would be defined by the order of how that path goes (see traveling salesman problem).

These sorts of ideas are interesting, and suggest to me that conceptual topology or graphing could indeed become a big thing. It remains to be seen how it will play out, but it seems like a good mechanic by which to raise the standard of cognition-affectation floor.

This was fun, and I hoped you learned a little about note-taking, Experimental Unit, and some pop culture. I challenge you to make a list of 5 elements and describe all the pairs. Best to choose very different things so you don’t get quite so much conceptual overlap as me. Still, you’ll find everything related..

[1](https://experimentalunit.substack.com/p/completed-graphs-of-bounded-size#footnote-anchor-1-182019639)

Fan Wiki. Dee Dee. 

URL: <https://dexterslab.fandom.com/wiki/Dee_Dee>

[2](https://experimentalunit.substack.com/p/completed-graphs-of-bounded-size#footnote-anchor-2-182019639)

Bonus because Dee Dee really just is the fucking best.  
  
CBR. Dee Dee Was Secretly The Real Star   
  
URL: <https://www.cbr.com/dexter-laboratory-dee-dee-was-secretly-the-real-star/>

[3](https://experimentalunit.substack.com/p/completed-graphs-of-bounded-size#footnote-anchor-3-182019639)

Fan Wiki. Samara Morgan.

URL: <https://theringmovies.fandom.com/wiki/Samara_Morgan>

[4](https://experimentalunit.substack.com/p/completed-graphs-of-bounded-size#footnote-anchor-4-182019639)

Wikipedia. Wovoka.

URL: <https://en.wikipedia.org/wiki/Wovoka>

[5](https://experimentalunit.substack.com/p/completed-graphs-of-bounded-size#footnote-anchor-5-182019639)

Saturday Night Live. Jumanji

URL: <https://www.youtube.com/watch?v=8cdBcfLhJVY>

[6](https://experimentalunit.substack.com/p/completed-graphs-of-bounded-size#footnote-anchor-6-182019639)

Wikipedia. Phoebe Plummer.  
  
URL: <https://en.wikipedia.org/wiki/Phoebe_Plummer>

[7](https://experimentalunit.substack.com/p/completed-graphs-of-bounded-size#footnote-anchor-7-182019639)

Emerald Review. Climate Activists As Performance Artists.

URL: https://emeraldreview.com/2023/01/climate-activists-as-performance-artists/

---
title: Dear Diary 4
subtitle: This Is The Song I Wrote You In The Dark
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Dear Diary 4
Hopefully, I’ll get my laptop in a minute.

(Laptop in my back pocket)

But I wanted to start this while I’m Outside.

It’s funny, there are two things I want to do.

First, I want to give a genuine monologue about what I’m up to a la *record scratch* you’re probably wondering how I wound up in this situation. 

(Wound homonym)

Now I’m outside and walking. When customers depart I try to always say “safe travels.” Traveling is a core category like death or sex.

Anyway, the other thing I wanted to do was talk about how, from your perspective, Adolf Hitler just is the person whose shadow is cast over our time. I say from your time because actually, Jean Baudrillard overtook Adolf Hitler starting with the publication of The System of Objects in 1968.

But that’s not going to make any sense to you, if it will at all, until you understand what I mean when I say that from your perspective, Adolf Hitler just is—by which I mean I don’t *want* this to be the case—the figure whose shadow lies over the age, or whatever.

But see, it’s funny. On the one hand, I don’t want you to worry. On the other hand, here comes whiteboi with his pet theory on Adolf Hitler. This is basically the fundamental tension I always walk with. 

I’m trying honestly to be of good heart. The thing is that what counts what helps is to take a good heart to the worst places. So, even if I’m not doing a good job at that, which is to say that in my cases you can reason doubt whether I was acting with good heart, you can rate my efforts as a failure in this direction.

It kind of works together because okay, why am I here talking to you about Adolf Hitler, when in a way I would rather be doing anything else. I’m a self-conscious person. I get quite upset if I think someone at work might be mad at me. These things bother me.

Part of my continuance is based on that constant self-consciousness and modeling other minds, if with too much bias if anything toward persecution.

The thing is that I’ve known I was “like this” the whole time. Part of it is that of course it’s really awkward to be in this type of situation. But the first point was I’ve been suffering unbearably the whole time so my emotional pain tolerance is high. Again, nothing has really happened in my IRL life. So once we’re talking interrogation room, courtroom, hospital, whatever, who knows what you’ll catch me do. That’s not my affair for now.

So there again, everyone’s getting all worried. “White people go to school, where they teach you how to be thick; and everybody’s doin’; just what they’re supposed to; and nobody wants to go to jail.” - The Clash

“Everything is easy.” - Epicurus

“I don’t wanna waste my time, become another casualty of your “society.” Don’t wanna fall in line, become another victim of your conformity.”

Sorry, were we listening to different music?

Oh. You just never took it that seriously.

You found a crowd to fall in line with.

You operate at a certain level of abstraction and don’t move around.

You expect everything to just continue on as normal.

You think doing the same things over and over will keep pace with a changing situation where other people can see what you’re doing and account for your predictability.

And you would call me delusional.

And you would call me vain.

The contempt with which I hold any attempt to judge or define me cannot be expressed in megatons, much less words.

Atman is Brahman and Brahman is Shiva. Anyway you slice it, I’m Shakti’s boyfriend. And if Shakti is her own boyfriend, then I am he as you are he as you are me and we are all together.

Like Lewis Black (Black), I got off track. They took a coke cap and they scratched me. I got the scar to prove it.

Here I am improvising again, and you worry that my thoughts are not really well organized and I’m incoherent.

So, Adolf Hitler was contemplated as an avatar of Vishnu by Savitri Devi, or Miguel Serrano, or whatever. I make a point that I don’t know that much about these people. What I do is pick up plotlines and mash them into other eschatologies and interpret them all as painlessly as possible. Achieve the maximum effect with minimum disturbance.

But sometimes the minimum disturbance is not a low level of disturbance.

I’m sorry, I thought Hitler and Mussolini were in charge at the same time while the other main people are “authoritarian.” So, shit’s um pretty bleak, no?

That’s where I say throw the kitchen sink at that bad boy.

I’m not gonna stand here and let you tell me to calm down and also tell me nuclear bombs can go off anytime and “there’s nothing I can do to stop it.”

Well, um, pardon me if I don’t stop trying and innovating while I’m at it.

The Atomic Bulletin of Scientists used to call on everyone to do whatever they can to stop whatever. Now they just tell you to vote for good leaders or something.

I vote that the leaders so called that we have now simply become good.

They think they are good. Or they say they think they are good. Well, let them show it then.

This goes out to anyone who acts like they have any authority: you’re lying to yourself or the people to claim to have authority over, or both.

Why keep the train on the tracks if it’s headed off a cliff? On behalf of every person you’ve cowed into submission so that they just don’t try anymore, I want you to know that the fire is still burning. Just like it is in you. Because you don’t have any authority. See, you’re just like me. I hope you’re satisfied.

Another digression.

So, Adolf Hitler. We live in the post-World War 2 era. “The cold war” is over, which is a useless term. First of all and this applies to WWII as well, there are no wars. It would be more accurate to say that there is one drawn out period of hostility.

From your standpoint, there is simultaneously no way to stop “war logic” and at the same time no way to survive war. So everyone knows that they are doomed to die in a coming Holocaust. You wouldn’t have to get on real trains. The incinerator is coming to you. The gas chamber is coming to you. In the form of drones or biological weapons or some other cruel necessity cooked up by your rationalists.

And this state of affairs has everything to do with Adolf Hitler. The period known as WWII and what’s known as the inter war period would not be what they were without the presence of Adolf Hitler.

On top of which the Holocaust has gone down as the most evil crime, unspeakable in its legacy. So Adolf Hitler and the so-called National Socialist German Workers Party (Nationalsozialistische Deutsche Arbeiterpartei) are basically considered absolute evil. 

Their legacy obviously impacts many themes and symbols, so that all sorts of things are stigmatized just for being associated with Adolf Hitler and that party. So for example everyone knows that Adolf Hitler’s distinctive mustache is basically a no-go. The name “Adolf” itself is highly stigmatized. You could never come across it without thinking of Adolf Hitler.

Or again obviously the swastika. This symbol in highly generally visible contexts will always be associated with Adolf Hitler and Nazism.

Another good example is antisemitism. Everyone knows or maybe not but again among like a planetary audience it is obviously well known that Adolf Hitler strongly condemned the thousands of years old religion of Judaism, which of course also inspired Christianity, the most popular religion in the places Adolf Hitler was from. Jesus Christ, the central figure of that religion, is a Jew, for example.

But now, if you think of antisemitism you are likely at some point to think of Adolf Hitler, that “party,” “WWII,” the Holocaust, for example.

And, antisemitism seems especially bad because of its association with Adolf Hitler. Other persecutions exist which also accompany unspeakable atrocity, but antisemitism also always calls to mind the gravest crime in much of the popular imagination.

Those are some of the big examples.

So you can think of it like this: Franz Kafka has this story called the penal colony where you get punished by having the sentence carved into your back, but it does it a million times just a little at a time until you die. Spooky!

So if you think of what does it mean that “Adolf Hitler’s shadow looms over the age,” that means that this set of ideas and associations would be carved the deepest into what Jung might call “the collective unconscious.”

Now that I think of it, past biological cataclysms happened to our ancestors.

Yes, this is established lore for me.

So as I said we live in the shadow of Adolf Hitler or so you think. Before WWII the last big thing was European Colonialism, so say we live in the shadow of Christopher Columbus.

Again, not because of goodness. But once Columbus got back to “Spain” or whatever. Portugal? Anyway, once that happened and word got out that you could get somewhere by going west, it was over at that point, a whole new emergency opened. Columbus could have died in the Atlantic or whatever on the way back or there and if it still happened we’d still be in Christopher Columbus’ shadow, for spearheading this hugely consequential course of events.

Anyway, we can keep going back. Napoleon. Genghis Khan. Alexander.

But we can keep going to when we were “animals.”

I’m thinking principally of the meteor that killed the dinosaurs and the great oxidation event that killed so much of life on earth at the time. It was “just” germs, but those are our ancestors. And all your ancestors are just as important.

Maybe some people think germs aren’t their ancestors. But anyway, given that “scientific” view of things, that meteor and the oxidation event both happened to our ancestors so that’s in us and also those events set the stage for our moment so much. Much less the origin of life, which a scientific mystery which obviously opens into “metaphysical” speculation. Such speculation grounds the concerns of most people.

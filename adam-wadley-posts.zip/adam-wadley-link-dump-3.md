---
title: 'Link Dump #3'
subtitle: Zelda's Getting Real Tired Of Ol' Fitzgeraldo
author: Adam Wadley
publication: Experimental Unit
date: July 14, 2025
---

# Link Dump #3
[![](https://substackcdn.com/image/fetch/$s_!Zvqa!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F789ffeb0-dc40-47d0-ad64-f0dfb9d3545d_853x363.png)](https://substackcdn.com/image/fetch/$s_!Zvqa!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F789ffeb0-dc40-47d0-ad64-f0dfb9d3545d_853x363.png)

  1. [Wikipedia article on John Carpenter’s ](https://en.wikipedia.org/wiki/Prince_of_Darkness_\(film\))_[Prince Of Darkness](https://en.wikipedia.org/wiki/Prince_of_Darkness_\(film\))_

Mirror significance:

> The liquid begins to exert its influence beyond its container, [possessing](https://en.wikipedia.org/wiki/Spirit_possession) Susan, who spreads the possession to or kills several other team members. Those who leave the building are brutally murdered by the increasingly enthralled homeless people. The survivors realize that, since their arrival, they have experienced a shared dream of a dark figure emerging from the monastery. Brian surmises that the dreams are a warning sent from the future using [tachyons](https://en.wikipedia.org/wiki/Tachyon). The possessed bring the cylinder to a sleeping Kelly, where the remaining liquid forces itself into her body, transforming her into the physical vessel of Satan: a gruesomely disfigured being, with powers of telekinesis and regeneration. Satan attempts to summon the Anti-God by reaching through a handheld mirror, but it is too small and the effort fails.
> 
> The possessed attack the survivors, while Satan locates a larger mirror and reaches through, grasping the Anti-God's large, clawed hand. The priest cuts off Satan's arm and head with an axe, but it instantly regenerates and again reaches for the Anti-God. Seeing this, Catherine charges at Satan and they both fall through the portal. The priest shatters the mirror, trapping Satan, the Anti-God, and, to Brian's horror, Catherine in the other realm. The possessed immediately die as the liquid evaporates from their bodies, while the homeless people wander away. The survivors, Brian, Walter, Birack, and the priest, are rescued as emergency services arrive to investigate.
> 
> Sometime later, Brian experiences the dream again, now seeing a seemingly possessed Catherine as the figure emerging from the church. He awakens and finds Catherine lying next to him, disfigured as Kelly was by Satan's possession. Startled awake, he realizes it was a nightmare. He approaches his bedroom mirror, reaching his hand out towards it.

  2. [Blog post on Baudrillard’s “Revenge of the Mirror People”](https://torpedotheark.blogspot.com/2024/12/the-revenge-of-mirror-people.html)

> According to Borges, writing in _The_ _Book of Imaginary Beings_ (1969), there was once a time when this world and the world reflected in mirrors were not, as now, cut off from each other and you could pass from one to the other quite freely.
> 
> But then the mirror people invaded this world, only to be defeated and imprisoned in their mirror world and obliged from that day on to only reflect the actions of those in this world, stripped of all freedom and autonomy. However, it is said that the day will come when the mirror people awaken once more, refuse their servitude, rise up, and burst through the looking-glass.  
> 
> 
> Baudrillard calls this 'the revenge of the mirror people' and by which he refers to the return of _otherness_ ; i.e., of all forms "which, subtly or violently deprived of their singularity, henceforth pose an insoluble problem for the social order, and also for the political and biological orders".

  3. [Hunter Hulett [Note: H.H.]: THE MOVIE IS ON!: PRAGMATICS OF THE VIDEO JOKER IN WHO KILLED CAPTAIN ALEX?](https://uknowledge.uky.edu/cgi/viewcontent.cgi?article=1062&context=ltt_etds)

  4. [MARIA ANTÓNIA LIMA: The Art of Terror: some artistic references in Gothic Literature](https://ler.letras.up.pt/uploads/ficheiros/7758.pdf)

> This diabolic tendency, which draws the Horrid towards the Beautiful, turning it into one of its most essential elements, was explained by a certain attraction to the ugly aspects of life and by the desire to penetrate into the unknown. This free and paradoxical game between opposing aesthetic categories permitted a transgression that opened up the possibility for acceptance into the domain of art of something that had previously been forbidden, turning it into its true essence. Beauty and Poetry began to be extracted from what was repulsive and abject.

  5. [Robin Mackay Introduction: Three Figures of Contingency](https://www.urbanomic.com/wp-content/uploads/2015/03/MoC-Intro-redactions.pdf)

> Once we understand the meaning of contingency, then, the very notion of a ‘contingency plan’ is revealed as a contradiction in terms. 
> 
> Consequently, the thought of contingency stands as a kind of ultimate consummation of the puncturing of human conceit—whether in its native form, or sublimated into the ultimate form of divine necessity. It is the bitterest pill to swallow, a distillate of everything indigestible that thinking has served up to us. Freud remarked that modern man had undergone three deep ‘narcissistic wounds’: Copernicus had demonstrated that the Earth is not the centre of the universe; Darwin, that the human being is a product of natural selection, emerging through the same blind material processes as every other creature; Finally, psychoanalysis was to undermine our impression that we are master of our own consciousness and destiny, for unconscious processes beyond our perception and control steer our relation to the world and to ourselves.
> 
> These are ‘humiliations’ in the sense that they violate the spontaneous human attitude, the ‘natural’ perspective from which the human subject can consider itself the central, necessary, and founding fact of the universe in which it lives. The content of the entire series of these ‘narcissistic wounds’ is that the thinking subject’s self-image is not a transparent and originary given from which all thinking must proceed, and upon which all thinking can be solidly based. It is the product of other, unconscious processes and events: processes indifferent to the human and to thought; and events crucial for the emergence and continued existence of the latter, but whose necessity can by no means be established.

  6. [Mark Fisher: Flatline Constructs: Gothic Materialism and Cybernetic Theory-Fiction](https://exmilitai.re/flatline-constructs.pdf)

> Scornful of the aspirations of the leftist transformational project to which Jameson is still committed, Baudrillard is particularly delighted by Ballard’s refusal of the binary “function/ dysfunction”, by his complete abandonment of any moral or political/critical stance26. For Baudrillard, the dream of transformation belongs to the “productive, Promethean” era – industrialism – that cybernetics has terminated. Like cybernetics itself, the fctions characteristic of the new era are “immanent and thus leave no room for any kind of imaginary transcendence.”

  7. [Wikipedia article on J.G. Ballard’s ](https://en.wikipedia.org/wiki/Crash_\(Ballard_novel\))_[Crash](https://en.wikipedia.org/wiki/Crash_\(Ballard_novel\)) _[read together by myself and ___]

> The story is told through the eyes of narrator James Ballard, named after the author himself, but it centers on the sinister figure of Dr. Robert Vaughan, a former TV scientist turned "nightmare angel of the highways".[[1]](https://en.wikipedia.org/wiki/Crash_\(Ballard_novel\)#cite_note-:32-1) James meets Vaughan after being injured in a car crash near [London Airport](https://en.wikipedia.org/wiki/London_Heathrow_Airport). Gathering around Vaughan is a group of alienated people, all of them former crash victims, who follow him in his pursuit to re-enact the crashes of [Hollywood](https://en.wikipedia.org/wiki/Hollywood_cinema) celebrities such as [Jayne Mansfield](https://en.wikipedia.org/wiki/Jayne_Mansfield) and [James Dean](https://en.wikipedia.org/wiki/James_Dean), in order to experience what the narrator calls "a new sexuality, born from a perverse technology".

  8. [Wikipedia aticle on Alberich](https://en.wikipedia.org/wiki/Alberich)

> Wagner's Alberich is a [composite character](https://en.wikipedia.org/wiki/Composite_character), mostly based on Alberich from the _Nibelungenlied_ , but also on [Andvari](https://en.wikipedia.org/wiki/Andvari) from [Norse mythology](https://en.wikipedia.org/wiki/Norse_mythology). He has been widely described, most notably by [Theodor Adorno](https://en.wikipedia.org/wiki/Theodor_Adorno), as a [negative](https://en.wikipedia.org/wiki/Anti-Semitism) [Jewish](https://en.wikipedia.org/wiki/Jew) stereotype, with his race expressed through "distorted" music and "muttering" speech
> 
> […]
> 
> In [World War I](https://en.wikipedia.org/wiki/World_War_I), the German retreat to fortified positions in the [Hindenburg Line](https://en.wikipedia.org/wiki/Hindenburg_Line), which was officially named after Siegfried despite its common name, was named [Operation Alberich](https://en.wikipedia.org/wiki/Operation_Alberich).

  9. [“We Appreciate Power” by Grimes](https://www.youtube.com/watch?v=gNZK4ss1pSs)

> What will it take to make you capitulate?

  10. Seinfeld images

[![](https://substackcdn.com/image/fetch/$s_!xAet!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F07e063a9-80e1-4936-bd0c-4cf46b69bab8_260x194.jpeg)](https://substackcdn.com/image/fetch/$s_!xAet!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F07e063a9-80e1-4936-bd0c-4cf46b69bab8_260x194.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!Aqa6!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0f86f7fd-7200-40f4-9ece-f1f16aebec67_260x194.jpeg)](https://substackcdn.com/image/fetch/$s_!Aqa6!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0f86f7fd-7200-40f4-9ece-f1f16aebec67_260x194.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!s3QU!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F28fed57d-3e1e-4da0-9422-0b666bcbf0b7_260x194.jpeg)](https://substackcdn.com/image/fetch/$s_!s3QU!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F28fed57d-3e1e-4da0-9422-0b666bcbf0b7_260x194.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!79tG!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F92ec6fb6-7d52-4ceb-b6cb-355f8c86901b_260x194.jpeg)](https://substackcdn.com/image/fetch/$s_!79tG!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F92ec6fb6-7d52-4ceb-b6cb-355f8c86901b_260x194.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!mg2m!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff999804b-4bd9-4d52-a4e9-30899331023c_500x500.jpeg)](https://substackcdn.com/image/fetch/$s_!mg2m!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff999804b-4bd9-4d52-a4e9-30899331023c_500x500.jpeg)

  11. Book: _Clockwork & Chivalry: The Heidelberg Horror_

[![](https://substackcdn.com/image/fetch/$s_!I_UI!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F30264410-1e46-4e28-9de1-3538c995c882_300x300.png)](https://substackcdn.com/image/fetch/$s_!I_UI!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F30264410-1e46-4e28-9de1-3538c995c882_300x300.png)

  12. The real Heidelberg Horror [ _note from Adam-prime: notice the recurrence of the “HH” motif. This seems to be an elaborate Mitch Hedberg reference]_

[![](https://substackcdn.com/image/fetch/$s_!o9CL!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcd4ac934-5a34-49a8-9c02-9636463e0756_192x263.jpeg)](https://substackcdn.com/image/fetch/$s_!o9CL!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcd4ac934-5a34-49a8-9c02-9636463e0756_192x263.jpeg)

  13. [Hegel in Heidelberg](https://scottish-hegelian.blogspot.com/2012/11/hegel-in-heidelberg.html)

> Hegel’s wife Marie stayed in Nürnberg following a miscarriage and Hegel left alone for Heidelberg where he arrived on 19 October 1816. Here he met Eschenmayer, the brother of a future opponent of his philosophy. He also met Paulus and his family again. Paulus’ wife mocked reference to "absoluteness", but liked Hegel for his enthusiasm for the theatre.

  14. [Limpopo bus tragedy: Broken barriers](https://www.dstv.com/m-net/en-za/video/the-floating-book-fair)

> Just days before the start of the Easter celebrations, busloads of worshippers travelled from across Southern Africa to Moria in Limpopo for the annual ZCC pilgrimage. But these Batswana pilgrims and their bus driver never made it to the sacred place of worship. Instead, the speeding bus plunged over the bridge on the Mmamatlakala Pass. There was just one survivor – an eight-year-old girl




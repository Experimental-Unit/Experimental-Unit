---
title: 'OSA #4: CS-SIER-OA/ZWGB'
subtitle: Case White (Wear Black)
author: Adam Wadley
publication: Experimental Unit
date: May 03, 2025
---

# OSA #4: CS-SIER-OA/ZWGB
The comparison to Operation Barbarossa has been made several times.

This campaign like all others holds a singular place in what we might call Greater Lore.

Think of it like a multiverse where everything overlaps.

Each incarnation, each sentient being, is its own hyperobject.

Even in the substance, it’s easy to see how we overlap with our environments, too.

Every being that is born starts off inside other beings, then coming together and growing before reaching a state of being able to survive “alone” with steady infusions of food and water, the essentials: care.

Everything which comes along can stand in stark relief so stark that nevermore can come and go.

I want to tell you to consider it as you would on psilocybin, but what else can I say?

About the psychedelic, I would say that what is revealed is how much everything is itself.

It is similar to simply adding levels of logical types which do nothing but frame what has been framed before, ultimately converging on the original object, but somehow simply in reiterating the presence of this object again and again, and in this telescoped way all at once which implies every different possible view of it, and the limitations of all those possibilities which make for something that you can actually perceive as an instantiation.

So for example:

This

This → This

This → [This → This]

This → [This → [This → This]]

This → [This → [This → [This → This]]]

This → [This → [This → [This → [This → This]]]]

You get the idea.

Notice for example how all the brackets close at the end.

This is characteristic. See for example here, with the spinning disc that makes the weird noise faster and faster until it stops all of a sudden:

You could also think of the maxim that people often go broke a little at a time, and then all at once.

Similarly, health can fail in the same way.

It’s not to be macabre, it’s not just about negative things, although in some sense this all has something to do with death.

It’s again about the turbo idea of Baudrillard’s, being accelerated to the end state.

There’s a neat trope in fiction where there is a time loop or time travel of some sort, and then as you come back up on a time that people already went through, they have to assume the positions they were in at the beginning.

So in a way, you know where everyone is going to end up, at a certain moment, which was _shown before_. (See Anamnesis, [Quran 7:172](https://quran.com/en/al-araf/172)).

As a result, there can be a dramatic tension as it seems that as the time is drawing near where you know people need to be, they are further and further from where you would have thought they would be by then.

The ]]]]]] closing of the parentheses at the end is like the rolling up of scattered troops after command and control has been smashed and “organized resistance” ceases.

Similarly, the process of losing command and control was similarly this gradual process, which consisted in the progressively more brittle and fragile nature of systems which deceived themselves into thinking they were still doing well, like someone showing signs of age who can’t accept it.

This delusion could persist for a while, but then comes a sudden shock, a Stalingrad, at which point things are put into stark relief.

# Who Will Tell The People?

I was reading that after the loss in Stalingrad, the battle simply stopped being mentioned in the press. That’s pretty bad.

It’s like someone with a drinking problem who has a dog and then one day they just stop talking about the dog and you have to wonder, did the drinking lead to the dog dying or running away and this person won’t say? It’s not a great look to avoid a subject which is so obvious.

Now, that is the whole business of cognitive-affective protectionism. It’s important to understand the gravity of what I’m saying when I say that.

This is the end of my paper _Metonymy Economy_ where I discuss this idea of cognitive-affective protectionism:

> 
>     It is left to cognitive-affective science to aggressively shift the discourse on valuation from monetary terms, which reinforce the myriad cognitive biases which led to the thoughtless destruction of the biosphere in the first place, to cognitive-affective terms, so that the true goal of cultivating pleasurable mental states and facilitating cognitive-affective development can come into view. 
>     
>     Each of these goals implies the implementation of **cognitive-affective protectionism on every scale** , as we cultivate our own individual idiosyncratic industries (our own economic behaviors) in concert with the rising chorus of cognitive-affective innovation set to sweep the globe. 
>     
>     By seeing the enormous economic opportunity presented by cognitive-affective economics, the massive ecological problems we face shrink to an imposing, but imaginably conquerable size. 
>     
>     Economics as a glorified version of home-building can only truly succeed when “the ends of economic analysis [are] open to an ethical discussion and [...] economic rationality [is] defined in terms of how best to approach the goals that emerge from an ethical framework” (Leshem 236). 
>     
>     Toward Poetic Science 
>     
>     There is a growing sense that either an apocalypse or a new golden age is coming. 
>     
>     The means to achieve the artificialization of biosphere support system components disrupted by human economy activity may exist, but unlocking and putting them into place is no small task. 
>     
>     Accelerating the pace of cognitive-affective paradigm shifts and disseminating their implications throughout the economy will require raising the productivity of existing workers within science, expanding the workforce of scientific specialists to meet the demand for cognitive-affective labor, and making it possible to overcome, within the broader public as well as within academic disciplines, of bio-cultural tendencies to double-down on established practices and heuristics. 
>     
>     Yet only by achieving these tasks can we hope to help conceive and implement the policies which will lead to the continued survival and flourishing of the human species, and such for ourselves as individuals. 
>     
>     This paper has endeavored to show that the theoretical perspective of cognitive-affective science, meaning the honing of cognition through the ruthless questioning of premises, and the development of affective sensibility through socio-cultural practice, has much to offer humanity 
>     as it transitions to an ever more mechanized and modelled world economy. 
>     
>     Once the rationalist bias against affective sensibility is set aside, the field will truly be open for revolutionary and wonder-producing research. 
>     
>     Humans have definitively changed Earth and must now take direct responsibility for the survivability of the biosphere. 
>     
>     Embracing this challenge, and setting aside the idea of returning to the environmental equilibrium of five centuries ago, is central if we are to think creatively enough to apprehend the substantial economic opportunities which lie ahead. 
>     
>     This is equally true for our cognitive-affective homeostasis: we won’t thrive by pursuing the reinvigoration of last century’s concepts, but by finding the new ways of speaking pursuant to our own time. 
>     
>     Cognitive-affective economics emphasizes human development, or the development of human capital, as the major goal of economic meta-theory, and hence looks to all fields, from artificial intelligence to cultural anthropology and poetics, to find the artful economic means which will allow for the ever faster development technology and its mindful use. 
>     
>     Core to this megaproject is the strategy of **cognitive-affective protectionism** , which seeks to craft a ‘safe space’ for novel cognitive-affective schemata to develop, before they can be respectfully challenged by and combined with other novel schemata. 
>     
>     The possibilities are endless, once we realize that cultivating cognitive-affective states of all kinds, not merely ones we ‘agree with,’ or which profit us monetarily, is in our direct personal interest, since we never know out of what sector the next major innovation or paradigm shift might emerge. 
>     
>     As such, cognitive-affective economics must seek to nudge the broader public into a higher valuation of mental, emotional, and cultural development, so that accelerating returns can begin to appear. 
>     
>     In seeking to drive intrinsic motivation in a variated public, cognitive-affective science must be infinitely adaptive, infinitely inquisitive, infinitely respectful of the unknown sense of different modes of being. 
>     
>     In this, it lives up to the poetic sense of Baudrillard’s radical metonymy. 
>     
>     Everyone is overlooked; everyone should be more catered to, consoled for unappreciated wounds, nurtured in their cognitive-affective development for the good of all. 
>     
>     So much was averred by Hayes et al., in writing that “Transformative action—where inequities are addressed, active hope is demonstrated, and communities are mobilized—is the defining opportunity of the twenty-first century to address the climate change impacts on mental health” (Hayes et al. 10). 
>     
>     Such transformative action will be invaluably aided, I hope to have indicated, by the pursuit of cognitive-affective economics. 

There’s again the move which is common here as well as with _Experimental Unit_ or perhaps Ahimsa.

Ahimsa is a doctrine of nonviolence, and it is really swell to invoke in order to try and get people not to worry. At the same time, I think in a mystic sense or Dhamma sense that we can say that Ahimsa is simply always followed.

In a positive way, this would be to say that there is part of us which cannot be touched by ill intention or harmful action. This is sort of reassuring as to say that no matter what happens, you don’t have to worry that you will be totally taken over by something bad. You will never be bad and all bad, and even the idea that “oh no, well you’ll be _more bad than good_ ,” this is also not something you need to worry about.

The tricky thing about the sublime is that it is not good or bad, or it is both. Therefore the consolation you can take is that it is _not bad_. Which is in itself something, or you can say it is good.

 _Smash cut to all the acts of kindness and whimsical joy taken by all sentient beings ever in all possible situations._

But the awful part of it is that the bad sides of existence are always going to be there, and there’s nothing you can do about it.

You could even try to erase the memory of what happened. Something like that wouldn’t even work.

Symbolic weight is what we have to sit with.

Anyway, the connection to cognitive-affective protectionism is obvious.

The idea is that ultimately, any power-base you might be building is like building a culture. Increasingly, these pursuits are more and more meta-aware, more and more nested.

But so if you look at the motivation for Operation Babarossa, of course people talk about _Lebensraum_. This whole thing is sheer fantasy though. I’m not sure why anyone was thinking about generations down the line while they were recklessly sacrificing the people actually alive right now for a very poorly thought out reason.

# The Real Operation Barbarossa Was In Our Black Hearts All Along

Let’s again jump again to the metonymic reading of Operation Barbarossa as the case to study to understand the implications of blitzkrieg. This is for the purposes of fashioning and continuing to augment my operational concept of _Zeitgeist Weltschmerz Gesamtkunstwerk Blitzkrieg_ (ZWGB).

This operational concept abstracts most immediately over the four concepts that make it up:

  1.  **Zeitgeist** : the spirit of an age. What is in the air? As for us now, great instability, paranoia. People are sort of having inner collapses, reconsidering things. Meanwhile things are getting worse. Aggression is on the rise, and then there is the resistance side which still rings hollow. People are discovering more and more about how they are being mistreated and trying to do something about it. Oh yeah, this is associated with Hegel, who is kind of a big deal idk if you know her. She goes to a different 

  2. **Weltschmerz** : world pain. This is pain at the state of the world. Not abstract like oh no, people are starving somewhere. This is included, but it is also again chronic stress from uncertainty about basic stability of social structures. Not just a basic lingering dread but specific events cause shocks. There is such a mix of things to feel pain about, small scale abuse and suicide, large scale atrocities and struggles over territory where people die, rape culture and endemic emotional abuse, crushing expectations of people who are just as at a loss but trying to maintain a sense of _inner_ control by obtaining a sense of _outer_ control through bad behavior, etc. etc. All this converges into a cocktail of emotions around sadness but also agitation and anger. Similar to the pain of a character like Hulk or White Violin. The world can be cruel, and we feel it. Goes together with _Zeitgeist_ because the idea is that the spirit of the age is the pain of the world. When you become a time ghost, you enter a world of pain. Do you _see_ what happens, Larry? Larry: “I see everything.”

  3.  **Gesamtkunstwerk** : associated with Wagner, who was a German nationalist and antisemite. It’s tough to imagine what German nationalism means before Hitler, because Germany wasn’t obviously more evil than the other ones. But they are all pretty evil. Actually, I don’t think Germany ever got “more evil” than other major “powers” like UK or USA. Again, none of these things have ever existed. What I mean is the agglomerations of social networks which have raised these concepts of nations as an illusion. The people inside project the appearance of steadfastness while knowing themselves that there is no “the law.” The pretense of “the law” is kept up by “a bunch of gangstas doing a bunch of gangsta shit,” to quote the historical documents. Anyway, Gesamtkunstwerk is a total work of art. This concept answers total war and in that goes together with the next concept. Like total war, where everything feeds into the martial project, in total art all media and forms of expression and passions are poured into the work. Note that the issue of the unity of the work of art is of major issue here. What counts as “the” work of art? We also connect to the German concept of Lebenskünstler, which means “life artist.” This is someone whose whole life is a work of art. Mystical type connotations are easily available to us under the rubric of Lila or any number of similar precepts which describe “creation” as precisely a creative work. In this sense the artist is God, and atman is Brahman, and your whole life is a work of art you made for yourself as God to experience to brutal joy of incarnation and maybe to have a nice time. This relates again to the ]]]]]]]]] moment because a broad view is offered to us that we can be further along than we think. Zweibelson might think things will take a generation that we can do in months. That’s the magic of accepting everything as your found materials, and making every gesture brimming with the intention of creating an adequate response to the dance of dream time ghost world pain.

  4.  **Blitzkrieg** : “Watch that last step! It’s a doozy!” This is a tough concept to integrate, but when I first went for it I had not expressed myself so boisterously as I have now. Although I have been pretty out there the whole time. It makes it weird for me to think what the heck someone like Zweibelson is thinking. That’s where I just have to be like well, everything’s Shakti, so there’s some spooky reason for it. More on which to hone the faculty of negative capability (“….Grimes? Is that you….?”). Anyway, blitzkrieg obviously means lightning war, so it means you are engaging in conflict in rapid speed. I’m also reminded of something I heard about Napoleon, maybe from Debord. That Napoleon would use victories in advance, assuming that a victory would come here and already formulating the next moves, in other words _what will abstract over the imminent success_. This is confidence, and in a sort of quantifiable way. The issue becomes when you engage Karma Yoga, when you let go of goals, when you become wise. We may as well go meditate in a mountain, right? Well, this is my meditation. We are here to engage quickly and to stage set pieces that will move the ball forward on our reconceptualization tasks. Things like planetary scale conceptual churn are within our grasp. In fact, these protocols are already being implemented. The gesture toward war is ambivalent. Where it is most apt is in the fact that resistance, or “resistance,” will be faced, and it must be met with fortitude and gravity (though no center). The ideal operations cannot be resisted, since the ultimate gesture toward the hostile is not to seek to change their “will” at all. Instead, what is done is basically a figure-ground reversal whereby the terms in which the goals pursued by hostiles no longer obtain even in their own minds. This can be achieved at scale through drawing attention to this or that “key insight.” Note again that this happens in sequence, and that this sequence can accelerate. It’s not a matter of one message at a time, either, you have personalized analyses of each single person and all sorts of messages that you deliver to them Upaya style. And back again to uneven and combined development, this time staged as the inner battleground between self-ignorance and destiny. Instead of giving an advertisement for soda, you give a nudge toward wisdom. The problem with this style, of course, is that it’s actually not appropriate to be stagist. Imagine having all the ability in the world, all the ability imaginable to control people, but you choose not to. Why? Because that’s a lesser goal. Controlling people is not as good as having good company. Therefore it’s as much about confronting people with ideas as it is adapting to their own responses to those things. Spreading awareness of various insights and challenges will bring out a ton in people, and this must be celebrated. Still, there are those who are more or less cruel on purpose, and this justifiably brings anger. Not to mention complacency with systems that drive people to suicide every day and kill them. For all these reasons there is rage, and there is the necessity to take it to the moment. As stated in the founding documents, _Experimental Unit_ is no warfighting organization. To engage in war is already to have lost the war, the war with the irony of fate. Still, blitzkrieg is an apt word to use for CS-SIER-OA operations. ZWGB remains an operational concept within Conceptual Systems-Of-Systems Impregnation Emergency Response Operational Art, and it’s speaking broadly to this use of speed as well as conceptual penetration to form encirclements and take conceptual prisoners (this is successful absolute exploit, where more and more conceptual machinery is being retrofitted and built into your larger intricacies), hostages. At the same time, the lessons of actual blitzkrieg open up questions for us about what conceptual logistics are, and how we can buttress our conceptual penetrations and conquests by trying occupying the zone, settling it, and truly setting up shop so that our efforts have a more lasting impact.




# At My Blitz End

We’re back in the world of logical types again.

Imagine this, even though it’s vague: if you act at a certain logical type only, then you might just be undone by a simple enough thing just like that.

Imagine doing a decapitation strike on someone, only to have a decapitation strike done back to you.

In a way it’s the same situation as Operation Barbarossa.

Say you have a successful coup. You oust the top level of decision-makers and install yourself/yourselves in their place.

Okay, well done. Let’s say two weeks later you are assassinated because people don’t really like you any better, maybe even worse than the person you replaced. 

You’ll never see them komin’, cutie :)

The point of the story is that your grip on influence was weak because you painted a target on your back and again, the gimmick from _Inception_ is highly instructive.

What’s happening is that you’re activating a swarm dynamic where it becomes incredibly obvious and desirable to attack you.

So in Operation Barbarossa, you are invading deep into a country, and then all of a sudden you’re surrounded by tens of millions of people it’s your official policy to murder and displace.

Now you have some victory up ahead with armor, but your main ground forces lag behind, which leaves your armor to take big losses. Meanwhile, you can’t just consolidate and take your gains because there are again, still _tens of millions_ of people all around you who hate your guts and want to kill you.

Back to the coup example. In a country of 50 million, say, you kill the 5,000 most crucial or dangerous opposition and install yourself in the presidential palace. 

The problem is that your army has a few million people in it, and you won decisive victory over some centralized point of command, but you fundamentally you are still vastly outnumbered and caught in the position you were in when you won your victory.

Social forces are actually very diffuse and mysterious. Who knows what sect or force or person could take it upon themselves to end your reign. Or even, what if someone from outside comes? So you have 50 million people.

What if someone comes from a country with 500 million people, and the expected difference in economic and kinetic force? Now maybe you are really out to lunch.

This international dynamic even broadens the scope of the issue.

The first-order point is that you can decapitate a government, or some core set of social networks, systems-of-systems; but this does not mean you have a stable position in the broader field.

This is connected to this theme of logical types. A decapitation maneuver is like you are operating at a very “high” logical type. Meanwhile, what would be a low logical type?

That would be like spreading social media posts about people’s bodies to give people body image issues. This tactic is now influencing people in their day-to-day lives, in their experience of their own bodies, and therefore influences their entire self-perception, especially as these materials encourage people to emphasize the importance of their appearance.

Or perhaps also someone else would say working with food. The types blend, though. So say for example you have some social network decision which manifests in a “legal measure” which impacts how food is grown. 

This is a “high logical type” activity in that “the government” is abstracting over many systems of systems in what it is doing.

Meanwhile, it impacts what is at a “low logical type,” which is the basic process of how food is grown and comes to be consumed to become part of people’s bodies, give them energy to live, become a cultural object, become a personal comfort item, etc.

For example, such a food regulation could impact the degree of allowable radioactivity in food or in some process of making it.

Radioactivity is a good example because what is the danger? The danger is that tiny particles will be emitted by something that’s radioactive that will shoot through the body and make tiny damages in the molecules that make up the body. This impacts things like DNA or cells directly.

This is at a very low logical type because in a way, things having to do with the body and immediate experience are the basic and most intuitive level.

Yet again abstraction does not only go up, it does down, and in going down it goes up. See Heraclitus: the way up and the way down are the same.

Anyway, abstraction is not just systems and the internet and all this outside stuff going on that’s so complicated. 

It’s also how the body is made of cells and cells are made of organelles and all that’s made of molecules and molecules are made of atoms and it goes on like this with gluons and then there’s other stuff like the weak force and the Higgs field which are also important.

We confront physics at the large and small scales, of course. And anywhere we do the work, I suppose.

# Full-Spectrum Involution

Anyway, what I’m trying to say is that a more thorough approach, where there is not simply deep penetration, or some kind of high-logical-type maneuvering. Rather, there’s got to be laying the ground work within the broader community of speakers.

In this sense, we don’t quibble and say that people _might_ be mobilized to become partisans, or _might_ become terrorists.

It turns out that everyone is already a partisan. Terrorism actually becomes interesting as a concept.

If we simply think of terrorism as manipulating people by using fear, then we can unlock a broader category of emotional terrorism.

Going off of some of the ideas above, we could think of it like a radioactivity, it’s breaking down itself and shooting off particles that can induce others to break down.

This is basically getting at negative social contagion. 

Or if we think of “networks of abuse,” and again terrorism as a term arose to describe the governmental policies of post-revolution France in the 1790s. This was an insurgent “state,” to be sure.

Yet if you look at it, inflicting fear has long been part of war and other brutal endeavors, even down to interpersonal domination dynamics.

It’s so omnipresent, for example in the tyrannies of social norms in what Baudrillard called “the code.” What you have is the weaponization of a norm, which is some imagination of how things should be framed which is typical or the baseline standard for some reason.

You can imagine because in for example an interrogation, the same person might be approached by the same agency (in the guise of multiple people, perhaps) in different ways, each of which adopt a framing that is different though perhaps complementary.

“Everyone has bad days.”

Versus

“Not everyone does something as heinous as you did.”

The first idea is one kind of norm, which is offering you safety and acceptance through this idea that well, everyone has a really rough time at times, and that’s when we might do things that we regret, so it’s really kind of understandable whatever happened.

The second idea is another norm, which is that some things are heinous and some aren’t, and the idea that there is a distinction between people who do especially heinous things and those who don’t, and that it matters a lot which side of that distinction a person falls on; and that when applied to you, you have done such heinous things, and that is important and very negative for you.

Anyway, such positive or negative reinforcement happens all the time for many motives. But we might not be so careful what we are using to try to make someone feel better, for example. If someone is concerned about their appearance, then our approach to telling them they look good, versus trying to get them to focus their attention somewhere else perhaps, is very important.

If possible, we would like to keep a person’s self-belief alive.

This is a crucial difference, or simple transcendence of the logic of war.

Within war, we might say that the issue is that there are competing wills.

Therefore we want to use all means to force the other person to accept our interests, no matter what they want to do.

My method works in a different way: instead, you look at where people do want to go, and you basically either show them a better way to do what they want to do anyway, which is also in keeping with something like a highway of the consistent; or, you again go back to the radioactivity metonymy and you instead sort of disintegrate or give rise to involution from within their functioning. This also has to do with the idea that people’s outward presentation of what “they want” is often misleading. People keep secrets, lack understanding, are deep masking so hard they forgot, etc.

To this extent, it is not even about what people want.

It is simply about being a person who embodies this moment of transition, who _for one day_ will not let people forget that Greater Jihad Is Not Optional. Obviously you should know that I don’t practice Islam the way others might other than of course submission to that which it is impossible not to submit to.

It’s instead simply this meta-recursive mining and iteration.

Which is of course to say that the real Operation Barbarossa is the one in our black hearts, where we are the invaders and we are the defenders and we are even the land.

When it comes to the rest of the idea for this section, what I wanted to get across was that logical types you can sort of think of like, different levels of society built on each other. You can influence the people at the top, you can influence people at the bottom, things like you can put something in a TV show, or put something in porn. This engages things like the internet to hook up people’s energy in their bodies, getting us all sexually invested in the veritable orgy of terrorism and erotic humiliation which envelops and penetrates us.

Compare for example to the 24/7 dynamic in BDSM, or something like being in an elite army Ranger school or something. That is an intense experience, structured all the time. You are invested and committed and policed in your conduct.

Compared to this, we have a bunch of “normal” people just going through days, doing some routine for some firm or government or doing whatever it is they do with their days. Still, there is something which penetrates and envelops us even if we aren’t into politics, even if we don’t fall in love, even if we don’t drink, even if we don’t look at our phones before bed.

Just at the personal level, a person we ourselves have these logical types, with our big ideas and purposes and metapurposes, and this Greater Jihad that I’m talking about in a way, this is itself a kind of blitzkrieg. 

You can race ahead to a peak awareness, but where is its integration into the rest of your time? This is where again you are a 4D hyperobject and part of the rest of it with us, again imagining the food you eat going from being outside to then its particles being incorporated into you so now it’s inside your 4D hyperobject.

So there’s a degree of uneven and combined development in the degree to which your deeper intentions are able to mold all your moments and more and more deeply. Perhaps intention is the wrong word, attention may be better. 

To where you can pay attention more. Spiritual Warriorism not only in the relentless intellectual assault beyond the conceptual edifices which are all too ready to burst in, but also in the silence which allows for a new abstraction. It’s a new beginning, not simply starting from known coordinates and abstracting from there but sitting there in the dreaming, sitting there in the only moment there’s ever been, and letting shift whatever needs to shift.

# Losing The Plot Like Stalingrad

The theme I’m trying to get at is building out my designs in terms of conceptual logistics.

Here we go. I’ll try to make an exercise which expresses my idea.

I’ve described before the idea of _Hinterland Lay Waste_ (HLW) protocol.

This is related to the idea of _Pre-Emptive Motte Demolition_ (PMD) protocol.

So in HLW, the idea is that there is a conceptual front line. This is the barrier at which there is some sort of crucial front in the conceptual struggle.

For example, as I would read the situation, such a front might be the idea of whether loyalty can extend to all sentient beings or not.

This basic sort of question becomes like Stalingrad, it becomes a set piece. Or think of the related question of Theodicy.

Can existence be redeemed, or justified? Or not?

Was all this worth it or not?

Okay, so here I’ve sketched out kind of a theoretical problem again arising out of world pain and this idea that something’s in the air (see Silup Inua). We imagine this as the front line, and again we can compare to Operation Barbarossa which had such a wide front.

Similarly, we can basically map any confrontation on here, because they really are all metonymies of each other. And secretly, each side in each conflict is also a metonymy of the other side in the conflict. 

So we might imagine that it all comes down to good versus evil.

And this idea of well, can we all get along or not? And which one of those is good and which is evil?

Some people would say that saying we can all get along is evil, because you are saying we can get along with evil people which only evil people can do.

Meanwhile, they might say that not wanting to get along with everyone is good because we should have standards and reject those with whom it is not possible to live together decently.

On the other hand, we might say that thinking we can get along is an expression of agape, which is basically a good intention. It also doesn’t have to be naive or simply “support” people in everything they want to do.

Accordingly, we might also say here that to think that we can’t all get along is sort of evil, since it dooms us to fight amongst ourselves forever, even at any scale. If you “get rid of” the people who you “just can’t stand” right now, who will be left? Do you think there will be perfect harmony then, or will this pattern just continue?

As you can tell, I am more on the second side. Yet the first idea, of embracing discrimination, is also important.

I basically advocate that everyone be a judge, everyone sovereign. I’m wondering if this is a post-norm thing.

Basically, instead of shaming someone by saying they are being weird or something, you put it very personally. Like, your actions make me feel disgusted, or something like that. It doesn’t have to be that blunt. The idea is basically that we are not hiding behind objectivity. Ideally, we should feel confident that people we engage with deeply want to understand what we’re saying and do value our feelings.

This is not simply because we should feel pleasure because we have a right too. No, this is also selfish for those who enjoy being acculturated by us. Who enjoy our attention.

It’s because this interplay allows us to have morale as we continue our own delving, which is again the way in which life happens fast. It’s all over in an instant, in a flash of lightning. Life is the logistics of mopping up your grandiose blunders.

---
title: 'OSA #11'
subtitle: Running The Gamut
author: Adam Wadley
publication: Experimental Unit
date: June 17, 2025
---

# OSA #11
I’m wanting, broadly speaking, to connect together two big strands:

  1. [Commentary on the Israel-Iran missile attacks that are currently unfolding, possibly signaling the escalation of ongoing World War IV.](https://www.cnn.com/world/live-news/israel-iran-attack-strikes-news-06-16-25-intl-hnk)

  2. [Justin Drew Bieber’s post on Instagram on June 15th, discussing anger issues and defiantly pushing back against the narrative of personal “healing.”](https://www.nbcnews.com/pop-culture/pop-culture-news/justin-bieber-shares-lengthy-instagram-post-anger-issues-rcna213285)




The through-line here is a bit deep in the weeds.

So, the situation with Iran has me wondering what the people in China are thinking. Here we are, and there is supposedly this push to resist American triumphalism.

Meanwhile, there is all this talk of the decline of the American Empire (AE), but it seems there is so little to resist it. We have this specter of China rising, and China is flanked by the two other big powers of Iran and Russia. Both are now bogged down in direct conflicts, and Iran really isn’t looking so good, having lost a lot of military leadership and so on.

So, what is China doing?

Now, of course, we here at Experimental Unit don't believe in any countries, and that’s sort of the whole point.

I’ve referenced before Abrams in [The Difficulty Studying The State](https://ecourse.auca.kg/pluginfile.php/344425/mod_resource/content/1/Abrams%201977%20Notes%20on%20the%20Difficulty%20of%20Studying%20the%20State.pdf), and the idea that, well, there really is no state to study.

What there are, are social networks, in which the idea of the state might be important, but there is no state, in the same way that there is no “room,” only constituent elements.

So, when we turn to “China,” we find that there is some policy called the “[global security initiative](https://www.mfa.gov.cn/eng/wjb/zzjg_663340/swaqsws_665306/xgxw/202403/t20240328_11272725.html).” In this description, we find some commitments:

> The GSI is underpinned by "six commitments", specifically, commitment to:
> 
>   1. the vision of common, comprehensive, cooperative and sustainable security; 
> 
>   2. respecting the **sovereignty** and territorial integrity of all countries; 
> 
>   3. abiding by the purposes and principles of the U.N. Charter; 
> 
>   4. taking the legitimate security concerns of all countries seriously; 
> 
>   5. peacefully resolving differences and disputes between countries through dialogue and consultation; 
> 
>   6. and maintaining security in both traditional and nontraditional domains.
> 
> 


Now we turn to [China’s responses to the attack on Iran](https://www.fmprc.gov.cn/eng/wjbzhd/202506/t20250615_11648771.html):

> Wang Yi said, 
> 
> China publicly stated its position immediately after Israel's attack on Iran. 
> 
> China explicitly condemns Israel's violation of Iran's **sovereignty** , security and territorial integrity, and firmly opposes the reckless attacks targeting Iranian officials and causing civilian casualties. 
> 
> China supports Iran in safeguarding its **national sovereignty** , defending its legitimate rights and interests, and ensuring the safety of its people.

In these statements and documents, we find that “China” is apparently very concerned with the notion of “national sovereignty.”

For me, it is first of all a bit strange that people who are resisting “Western imperialism” stake their claims on Western derived ideas like “national sovereignty.”

Of course, people have had an idea for a long time that being “in power” means that you have say-so over certain things, and if someone messes with that then they are “defying your authority.” Yet this notion of “national sovereignty” is obviously connected to the notion of the [Westphalian System](https://en.wikipedia.org/wiki/Westphalian_system) which has undergirded planetary religious belief—I mean, international relations—for centuries.

Beyond the silliness that people seek to “resist Western influence” while speaking in “Western” terms (there being, of course, no “West”)…

Beyond this, it is a major error to “believe” in national sovereignty. That is why it is not really possible to take the positions laid out by “China” seriously.

Now then, another reference I make a lot is to [this document on China and cognitive warfare](https://hal.science/hal-03635930/document). I usually am referencing the part when it’s stated that there really is no big grand distinction between war and peace, and this is something people will have to get used to if they want to deal well with the cognitive space.

But this time I want to quote a different part of this paper, which has to do with the limitations of the nation-state framing. The larger presentation of this point folds in the previous one about war and peace:

> Furthermore, cognitive warfare does not differentiate between war and peace, between combatant and non-combatant, (everyone is a potential target), and it is permanent. 
> 
> This is a major difference with the West [people from “the West” always pose as naive simpletons as part of cognitive operations facing their subjects/inferiors in chains of command], where there is a differentiation between war and peace. 
> 
> At the end of the 20th century, the publication of the monograph Unrestricted Warfare by two Chinese army colonels, Qiao and Wang (2006), marked an important step in understanding contemporary strategic thinking in Beijing. 
> 
> According to the authors, technological developments, globalization and the rise of **power beyond the nation-state** , combined with the new capabilities of modern weapons, would provide a new context for conflict. 
> 
> Battlefields would thus shift from a physical dimension to a more **abstract** arena such as cyberspace, the morale of the population or their brains. 
> 
> In other words, Qiao and Wang demonstrate that war is no longer “the use of armed force to force the enemy to bend to our wishes,” but rather “all means, whether armed or unarmed, military or non-military force... [uses] to force the enemy to submit to its own interests.” 
> 
> As a result, the battlefield is everywhere, war is no longer a purely military concept but also becomes civil. 
> 
> This has two consequences: 
> 
>   1. firstly, the victims of these new wars will not only be regular combatants who die on the battlefield, but also civilians who are indirectly affected. 
> 
>   2. Secondly, war is permanent and holistic, all forces and means are combined.
> 
> 


The notion of power “beyond the nation-state” is ambiguous. It could mean that there is power within “the nation-state” and then power “beyond it,” or it could mean that there is a gesture toward power which is beyond the “nation-state” overall, so that it encompasses the “nation-state idea” as Abrams might refer to it.

# Adam, What The Fuck Does This Have To Do With Justin Bieber

I’m glad you asked! 

The situation with JDB is basically about this person expressing that they don’t want to mask, and that they are simply angry. There is not a lot to work with in terms of what JDB is even angry about, but there is a lot here which is in rebellion against the normative frame of “go to therapy.”

This is fun space for me to work with because all my communications play a sort of double-game.

On one side, I appear to my family and probably other people to be losing my mind. My actions are sort of erratic, I have been expressing a lot of anger over the past several months. People all over the place are either “inadequate” in my eyes, like the people who run the King Center For Nonviolent Social Change. On the other hand, I am basically signaling that I feel let down, overlooked, and disrespected by the people in my life. This includes a recent “love” interest as well as my immediate and extended families.

On the topic of the King Center, I’d like to quote from the recent lob description of someone who I’m 1st degree connected with on LinkedIn, who just started a job as a Psychological Operations officer at the Central Intelligence Agency:

> I am a Meme Magician making massive momentum for viral content for online social media PSYOP missions for the CIA ahead of schedule and below budget to win the hearts, minds, and souls of target audiences worldwide tailored bespoke for each nation with Carte Blanche to use wise words of wisdom which work wonders as the Pen is Mightier Than The Sword as we defend our United States Constitution as I am briefed on our classified crusade to let freedom ring globally. As Commander in Chief President JFK said: **"Those who make peaceful revolution impossible, make violent revolution inevitable."**

[![](https://substackcdn.com/image/fetch/$s_!DSg5!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0190e6f4-b171-47f5-b33f-08649baa9366_817x607.png)](https://substackcdn.com/image/fetch/$s_!DSg5!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0190e6f4-b171-47f5-b33f-08649baa9366_817x607.png)

[![](https://substackcdn.com/image/fetch/$s_!iPKK!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa22fbbe3-8f04-46b5-b0de-c4e0b7c381b2_473x252.png)](https://substackcdn.com/image/fetch/$s_!iPKK!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa22fbbe3-8f04-46b5-b0de-c4e0b7c381b2_473x252.png)

[![](https://substackcdn.com/image/fetch/$s_!8dXV!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc6a88fc5-c7c2-4927-b8ac-a32bce56aa94_473x491.png)](https://substackcdn.com/image/fetch/$s_!8dXV!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc6a88fc5-c7c2-4927-b8ac-a32bce56aa94_473x491.png)

I show you this as part of my extended demonstration that, for some reason, these military people are connecting with me on LinkedIn. What is the point of that? I’m not sure.

I guess what I’m signaling to anyone who could be watching is that, apparently, my ideas are taken seriously, at least some of them, by some deep state goons. I’m basically in the deep state is what I am telling you.

And yet, at the same time, I am also something of an “AI Psychosis,” delusions-of-grandeur case. I am signaling that I am just so into my own ideas and so up my own ass, and that’s especially why I take it so hard that people are so mean to me for no reason!

This is all reminding me of the scene in _Citizen Kane_ where Charlie tells the other one that, when you’re talking to them, you’re really “talking to _two_ people.”

So the first answer to what this has to do with JDB is that this incident is interesting to me because JDB is also venting anger, just like I am. Here’s some of what I wrote in an earlier draft:

Yesterday, Justin Drew Bieber (JDB) made headlines by [posting a painful text message exchange](https://www.nbcnews.com/pop-culture/pop-culture-news/justin-bieber-shares-lengthy-instagram-post-anger-issues-rcna213285) to the social media platform Instagram.

Accompanying the exchange were many statements which expressed frustration with the normative use of the injunction to “get to therapy” in order to deal with what is known as personal trauma.

One typical comment read:

> “I know I’m broken. I know I have anger issues,” he continued. “I tried to do the work my whole life to be like the people who told me I needed to be fixed like them. And it just keeps making me more tired and angry.”

This incident is extremely interesting for me, as I have made it my work to do performance art related to the pain that I’ve suffered and post it very publicly.

It’s hard to belieb that it was less than two weeks ago, but on June 5, 2025, the same day that [Donald John Trump and Elon Reeve Musk brought their disagreements to a highly visible place](https://www.cbsnews.com/news/trump-german-chancellor-merz-meeting-white-house-today-2025-06-05/), I recorded a middle-of-the-night podcast episode after having a dream about “my father.” 

This episode went deep into painful memories I have of how I’ve been treated by my immediate family members, in a vortex of pain of which “my father” sits right in the middle.

I proceeded then to send this episode to the members of my extended family, an action that predictably had some fallout effects. I blocked all the members of my family on text message after sending the post, so I’m not sure exactly.

So the carryover here is the common theme that anger is spilling over. It’s also symptomatic that me, Justin, Donald, and Elon are all what you’d call “white guys.”

This incident also tracks with the recent expressions of one Kanye Omari West, who also started off having grievances and pain related to family and other close connections, feeling like their _children_ (crucial arc here, given that Kanye, Elon, Donald, and Justin are all “fathers” just like I have a “father”) are being sucked into a system that they have no say-so in.

Kanye’s case is also interesting because, of course, Kanye then pivoted into getting into antisemitism and surfacing a long-running interest and captivation with Adolf Hitler.

Meanwhile, on the pretension of anyone to be a father, you really ought to know your place:

Note also that "war” in German means “was,” and also “war” is the beginning off the word “warum,” which means to ask “why?” This is crucial for _Experimental Unit_ lore, as tied into the previous document published. The point is that war, or strife, is the source of all _things_ , which is pointing to the distinction as John Vervaeke might make between beings and being. We have to go further to appreciate the lack of distinction between being and non-being, however.

[![](https://substackcdn.com/image/fetch/$s_!knwu!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe02b6304-0dc4-4f33-a0a0-3563206e2958_855x282.png)](https://substackcdn.com/image/fetch/$s_!knwu!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe02b6304-0dc4-4f33-a0a0-3563206e2958_855x282.png)

Note also Heraclitus notion that strife is justice, elaborated [as above here](https://philosophicaleggs.com/90-heraclitus-on-justice-and-strife/).

Note also that _Experimental Unit_ ’s official position is that there is only one kind of justice, and that’s _poetic justice_.

For me, this recalls another key text in _Experimental Unit_ lore (funnily, we can say again, “is there another kind of text in _Experimental Unit_ lore? And no, no there is not), which is _A Few Good Men_.

[The exchange here is reprised a few moments later:](https://imsdb.com/scripts/A-Few-Good-Men.html)

[![](https://substackcdn.com/image/fetch/$s_!ctf4!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F87141b71-9119-4fb0-833e-54ad991c1daa_494x814.png)](https://substackcdn.com/image/fetch/$s_!ctf4!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F87141b71-9119-4fb0-833e-54ad991c1daa_494x814.png)

As a side note, Nicholson is not actually in a bind here, since what Jessup said was that troops “follow orders or people die.” Well, someone died here, so it’s perfectly consistent that Jessup would be afraid someone would disobey orders.

But just like we all want Jessup on that wall—

[And, recall here the poem “The Interrogation Of The Good” by Bertold Brecht:](https://brandonevans.ca/post/text/the-interrogation-of-the-good-bertolt-brecht/)

[![](https://substackcdn.com/image/fetch/$s_!duH1!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F72312b48-8dda-40a6-9810-8607f17ba8fb_716x891.png)](https://substackcdn.com/image/fetch/$s_!duH1!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F72312b48-8dda-40a6-9810-8607f17ba8fb_716x891.png)

Before I forget, I always connect another bit of lore with the Jessup quote above about “I don’t have to have it read back to me like I’m a damn…”

Here, Walter is saying “You have no frame of reference here, Donnie. You’re like a child who wanders into the middle of a movie and wants to know…”

Note also that Donnie is short for Donald just like Donald John Trump.

# Adam, What The Fuck Are You Talking About

First of all, what I’m talking about is poetic justice:

[![](https://substackcdn.com/image/fetch/$s_!grzN!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F31103145-c14d-405c-a8e5-4f3c3efbea07_1222x663.png)](https://substackcdn.com/image/fetch/$s_!grzN!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F31103145-c14d-405c-a8e5-4f3c3efbea07_1222x663.png)

Now, I’m getting to the limit of the email length. This is going to have to continue.

The basic point though is that JDB’s posts on Instagram incited a bunch of people to talk about how their conduct is so reprehensible because it’s “so important” to deal with trauma personally, and that especially when one becomes “a parent” (apparent…), it is vital not to let one’s trauma history harm one’s “family,” namely partner and children.

[See here a bunch of scolding like that.](https://www.reddit.com/r/Fauxmoi/comments/1lcg9e6/justin_bieber_just_posted_this_text_message/)

My basic point, which I will immediately continue on with in conversation with the novel series _[Mein Kampf](https://en.wikipedia.org/wiki/My_Struggle_\(Knausg%C3%A5rd_novels\))_[ by Karl Ove Knausgård](https://en.wikipedia.org/wiki/My_Struggle_\(Knausg%C3%A5rd_novels\)), is that we have here a homology:

You have people like in “China” clinging to this notion of “national sovereignty” even as people will also speak of power “beyond the nation-state” and a certain strand of academia basically says there is no state.

And yet the absurdity of “military” professionals (like _the CIA fucking PSYOP person who I’m connected to on LinkedIn for some reason_ ) acting like “the state” or “the nation” is grounding any sort of sense of purpose whatsoever.

Meanwhile, you have people acting like “trauma” needs to be dealt with on an “individual basis,” like we are personal responsible to make sure that we don’t hurt others.

Yet meanwhile, everyone is failing to do that as harm is normalized and vulnerable people are groomed to be emotional dumpsters for, frankly, unwise goons that are unworthy to hold anyone’s freaking jock strap.

This opens into the theme of the [transpersonal](https://en.wikipedia.org/wiki/Transpersonal) and psychological ideas which heavily criticize the typical ones, like those of [Thomas Szasz](https://en.wikipedia.org/wiki/Thomas_Szasz), [RD Laing](https://en.wikipedia.org/wiki/R._D._Laing), and [Gregory Bateson](https://en.wikipedia.org/wiki/Gregory_Bateson).

[You can listen to a podcast I did years ago about how “the Transpersonal is Transpolitical” here](https://soundcloud.com/amoreternal/the-transpersonal-is-transpolitical). 

My overall point is that this personal trauma “healing” points to an illusory notion of individual “wholeness” in the same way that the notion of “national” sovereignty points to the illusion of “organic unity” of some strict subset of sentient beings.

Instead, we can only heal together. And that means showing the pieces, and it means that things have to get _a lot_ messier before “the real healing” can begin.

---
title: Amygdala, Logical Types Part I
subtitle: Cuts off randomly
author: Adam Wadley
publication: Experimental Unit
date: April 10, 2025
---

# Amygdala, Logical Types Part I


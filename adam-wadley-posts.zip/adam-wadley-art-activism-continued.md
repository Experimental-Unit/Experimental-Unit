---
title: Art Activism Continued
subtitle: Experimental Unit is a Substack about Planetary Emergency Response & Interactive
  Narrative Performance
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# Art Activism Continued
[![](https://substackcdn.com/image/fetch/$s_!C3OB!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd12e4b2b-a60f-442c-bd90-58e213c4732f_1536x1024.png)](https://substackcdn.com/image/fetch/$s_!C3OB!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd12e4b2b-a60f-442c-bd90-58e213c4732f_1536x1024.png)

[![](https://substackcdn.com/image/fetch/$s_!8tZS!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fea1715e2-2d6f-42dd-9ce7-fd28f0ae9037_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!8tZS!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fea1715e2-2d6f-42dd-9ce7-fd28f0ae9037_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!cSh4!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F53fafbef-77d6-4cb7-8ffc-365bea8a8a8d_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!cSh4!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F53fafbef-77d6-4cb7-8ffc-365bea8a8a8d_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!gamk!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F415249dc-3cd9-4b35-ba9c-59f7db6d86bd_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!gamk!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F415249dc-3cd9-4b35-ba9c-59f7db6d86bd_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!Jv-d!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb14c1e90-3c7c-4879-a363-055cc4bdc078_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!Jv-d!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb14c1e90-3c7c-4879-a363-055cc4bdc078_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!UL9c!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fff945635-4736-4a7a-9d39-c5517928e586_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!UL9c!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fff945635-4736-4a7a-9d39-c5517928e586_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!yM1q!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe96d8261-7e02-426d-8b8d-30dd944065b1_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!yM1q!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe96d8261-7e02-426d-8b8d-30dd944065b1_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!7hlt!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9a6cdf15-2d0e-4bb0-ba3a-4ed447d12335_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!7hlt!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9a6cdf15-2d0e-4bb0-ba3a-4ed447d12335_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!RMtN!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0c92b080-1087-49f4-8fd3-c3410e5e6629_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!RMtN!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0c92b080-1087-49f4-8fd3-c3410e5e6629_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!HH0c!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F400c68ec-5e89-4993-8f13-99f56bf17676_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!HH0c!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F400c68ec-5e89-4993-8f13-99f56bf17676_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!OOmX!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F09690ada-ac2c-49ab-b312-53ffddf6711a_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!OOmX!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F09690ada-ac2c-49ab-b312-53ffddf6711a_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!QfHR!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3f900704-0971-4070-851d-aca7869ac9fc_3088x2316.jpeg)](https://substackcdn.com/image/fetch/$s_!QfHR!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3f900704-0971-4070-851d-aca7869ac9fc_3088x2316.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!s26p!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0151412d-8759-4050-87c4-ca4915152213_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!s26p!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0151412d-8759-4050-87c4-ca4915152213_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!NLKZ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0fd7a87b-24c6-4d72-a9e1-8ec78f3d7699_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!NLKZ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0fd7a87b-24c6-4d72-a9e1-8ec78f3d7699_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!xWQZ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F586ca075-ae6c-41fb-b70a-7158a945db3f_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!xWQZ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F586ca075-ae6c-41fb-b70a-7158a945db3f_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!K_Tx!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc0f2dc0e-802b-42f7-a753-11610039d76c_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!K_Tx!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc0f2dc0e-802b-42f7-a753-11610039d76c_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!KGUe!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1e0aff54-2caf-4298-b588-e029313bb6f4_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!KGUe!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1e0aff54-2caf-4298-b588-e029313bb6f4_4032x3024.jpeg)

[![](https://substackcdn.com/image/fetch/$s_!hIuj!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc6ac67c3-76f8-4ceb-bc6a-14bbc4f51c4f_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!hIuj!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc6ac67c3-76f8-4ceb-bc6a-14bbc4f51c4f_4032x3024.jpeg)

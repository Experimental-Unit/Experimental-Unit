---
title: The Incel Question
subtitle: Now, I Know What You Are Thinking
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# The Incel Question
I recently spoke with someone who was concerned about something I’d posted on Instagram. I posted in response to something which was talking about Incel ideas and how people just want to blame others for dating being bad and not work on themselves.

My point was basically that it’s also important to be realistic and say that just because someone works on themselves doesn’t mean they’ll be able to make a good match, because you need someone else who is also working on themselves.

The other point is that how people are working on themselves can itself be trapped within a certain paradigm of activity. So someone is working on getting a better schedule, or journaling. But it could still easily be that certain crucial questions are not addressed; that certain topics are not raised with others. 

And so if you’re not confronting the pioneering frontier of your activity, of the situation in general, then you’re not really in the appropriate wheelhouse for bonded purposeful activity.

Erotic coupling and beyond requires some sense of situatedness within a larger social and discursive frame. This can be people who see each other often, or concepts which are ritually invoked.

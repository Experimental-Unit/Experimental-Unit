---
title: 'Føůňð Főōťăğę: Åůşťïň'
subtitle: You were hearing "ruin value?" I was saying, "ruin-value!"
author: Adam Wadley
publication: Experimental Unit
date: July 16, 2025
---

# Føůňð Főōťăğę: Åůşťïň
[![](https://substackcdn.com/image/fetch/$s_!TKxC!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0e7b6cda-dd93-4869-b65e-2cd358d35494_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!TKxC!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0e7b6cda-dd93-4869-b65e-2cd358d35494_4032x3024.jpeg)

# Ťħēřę’ś Å Ŵăłķ Șø Łőñğ

Thinking, “How dare cars drive by?”

When such a lonely one as I

Blinks a Shinigami Eye

As seen on TV, my dear

Floating’s all that we do here

Having thrown upon the gears

The product of awakened times

Fucking anything that rhymes

Feeling grunge and touching grimes

Taking down the clowning posts

Dancing with the hungry ghosts

Offering the burning toasts

Painting black the open doors

Settling the final scores

Kissing all the open sores

[![](https://substackcdn.com/image/fetch/$s_!ywl3!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fab27e8a9-8a02-4644-a629-42c57e457d84_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!ywl3!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fab27e8a9-8a02-4644-a629-42c57e457d84_4032x3024.jpeg)

# 101 Ëxpęřįmẽņťåł Ůņǐț Ŵąÿ

Art school newly non-selective

Born a living retrospective

Calling in some famed detective

Sitting back to watch the clues

Pile up like streaming dues

Waiting for my funnest cues

[![](https://substackcdn.com/image/fetch/$s_!Is70!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0c4de1a4-e78e-4da0-88e6-b0a8e1d45454_1170x1295.jpeg)](https://substackcdn.com/image/fetch/$s_!Is70!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0c4de1a4-e78e-4da0-88e6-b0a8e1d45454_1170x1295.jpeg)

---
title: 'Comprehensive Academic Bibliography: The Phoebe Plummer Clone'
subtitle: 'Supporting Research for “The Phoebe Plummer Clone: Institutional Critique
  Through Intentional Visibility and the Somatic Aesthetics of Civil Disobedience”'
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# Comprehensive Academic Bibliography: The Phoebe Plummer Clone
## I. INSTITUTIONAL CRITIQUE GENEALOGY (15 Sources)

### Primary Theoretical Texts

 **Fraser, Andrea. “From the Critique of Institutions to an Institution of Critique.”** _Artforum_ 44, no. 1 (September 2005): 278–283.

  * Seminal essay redefining IC for the 21st century. Argues “we are the institution” and proposes moving from critique of institutions to creating “institutions of critique” through reflexive practice. [transversal texts](https://transversal.at/transversal/0106/sheikh/en)




 **Buchloh, Benjamin H.D. “Conceptual Art 1962–1969: From the Aesthetics of Administration to the Critique of Institutions.”** _October_ 55 (Winter 1990): 105–143.

  * Foundational essay linking conceptual art’s administrative aesthetics to systematic institutional critique, analyzing Haacke and Broodthaers as culminating examples. [Columbia](https://arthistory.columbia.edu/sites/default/files/content/faculty/pdfs/alberro/Institutional-Critique.pdf)[Tumblr](https://artandthehumanitarian.tumblr.com/post/45349524027/institutional-critique-benjamin-buchloh)




 **Bürger, Peter.** _Theory of the Avant-Garde_. Translated by Michael Shaw. Minneapolis: University of Minnesota Press, 1984. ISBN: 978-0816610686.

  * Theoretical foundation for understanding avant-garde’s attack on the “institution of art” under bourgeois capitalism. [Amazon UK](https://www.amazon.co.uk/Theory-Avant-Garde-History-Literature/dp/0816610681)




### Anthologies and Collected Writings

 **Alberro, Alexander, and Blake Stimson, eds.** _Institutional Critique: An Anthology of Artists’ Writings_. Cambridge, MA: MIT Press, 2009. ISBN: 978-0-262-51664-8.

  * Definitive anthology tracing IC from 1960s to present; includes Haacke, Asher, Buren, Broodthaers, Fraser, Wilson, Piper, Guerrilla Girls, and Steyerl. [MIT Press](https://mitpress.mit.edu/9780262516648/institutional-critique/)




 **Fraser, Andrea.** _Museum Highlights: The Writings of Andrea Fraser_. Edited by Alexander Alberro. Foreword by Pierre Bourdieu. Cambridge, MA: MIT Press, 2005. ISBN: 978-0262562300.

  * Comprehensive collection of Fraser’s writings 1985–2003 including performance scripts and critical analyses. [MIT Press](https://mitpress.mit.edu/9780262562300/museum-highlights/)




 **Alberro, Alexander, and Blake Stimson, eds.** _Conceptual Art: A Critical Anthology_. Cambridge, MA: MIT Press, 1999. ISBN: 978-0262511179.

  * Essential companion documenting conceptual art’s emergence and development.




### Major Monographs

 **Foster, Hal.** _The Return of the Real: The Avant-Garde at the End of the Century_. Cambridge, MA: MIT Press, 1996. ISBN: 978-0262561075.

  * Influential theorization of neo-avant-garde using Freud’s “deferred action”; argues IC comprehends historical avant-garde for the first time. [Wikipedia](https://en.wikipedia.org/wiki/Hal_Foster_\(art_critic\))




 **Buchloh, Benjamin H.D.** _Neo-Avantgarde and Culture Industry: Essays on European and American Art from 1955 to 1975_. October Books. Cambridge, MA: MIT Press, 2000. ISBN: 978-0262024549.

  * Collection examining postwar art through Frankfurt School lens; addresses Haacke’s IC models and Broodthaers’ museum theorization. [Amazon](https://www.amazon.com/Neo-Avantgarde-Culture-Industry-European-American/dp/0262024543)




 **Buchloh, Benjamin H.D.** _Formalism and Historicity: Models and Methods in Twentieth-Century Art_. October Books. Cambridge, MA: MIT Press, 2015. ISBN: 978-0262028523.

  * Second volume of collected essays including “Conceptual Art 1962–1969.” [Amazon](https://www.amazon.com/Formalism-Historicity-Methods-Twentieth-Century-October/dp/0262028522)




 **Asher, Michael.** _Writings 1973–1983 on Works 1969–1979_. Co-authored with Benjamin H.D. Buchloh. Halifax: Press of the Nova Scotia College of Art and Design, 1983.

  * Essential primary documentation of Asher’s site-specific institutional interventions. [Wikipedia](https://en.wikipedia.org/wiki/Michael_Asher_\(artist\))




### Exhibition Catalogs

 **Fraser, Andrea.** _2016 in Museums, Money, and Politics_. Cambridge, MA: MIT Press, 2018.

  * 943-page data compilation revealing overlap between art patrons and right-wing political donors. [Artnews](https://www.artnews.com/art-in-america/features/hans-haacke-new-museum-retrospective-institutional-critique-63666/)




 **Pfeiffer, Ingrid, Stella Rollig, and Luisa Ziaja, eds.** _Hans Haacke_. Munich: Hirmer Publishers, 2024.

  * Comprehensive monograph from SCHIRN Kunsthalle retrospective documenting works 1959–present. [University of Chicago Press](https://press.uchicago.edu/ucp/books/book/distributed/H/bo246015941.html)




 **Carrion-Murayari, Gary, and Massimiliano Gioni, eds.** _Hans Haacke: All Connected_. New York: New Museum, 2019.

  * First U.S. Haacke retrospective in thirty years with essays by Gloria Sutton, Pamela Lee, John A. Tyson. [Artnews](https://www.artnews.com/art-in-america/features/hans-haacke-new-museum-retrospective-institutional-critique-63666/)




 **Dziewior, Yilmaz.** _Andrea Fraser: Works, 1984 to 2003_. Exhibition catalog. Cologne: DuMont/D.A.P., 2003.

  * Documents Fraser’s first two decades with scholarly contextualization.




 **MIT Press.** _Michael Asher_. Cambridge, MA: MIT Press, 2016. ISBN: 978-0262528795.

  * Posthumous scholarly examination of Asher’s site-specific practice.




* * *

## II. SOCIALLY ENGAGED PRACTICE (18 Sources)

### Shannon Jackson

 **Jackson, Shannon.** _Social Works: Performing Art, Supporting Publics_. New York: Routledge, 2011. ISBN: 978-0-415-48601-9. DOI: 10.4324/9780203852897.

  * Develops “infrastructural aesthetics” examining relationship between artistic production and social support systems; analyzes Ukeles, Sierra, Rimini Protokoll, Paul Chan.




### Grant Kester

 **Kester, Grant H.** _Conversation Pieces: Community and Communication in Modern Art_. Berkeley: University of California Press, 2004; updated 2013. ISBN: 978-0-520-23862-0.

  * Foundational text developing “dialogical aesthetics” [Culturalpolicylab](https://www.culturalpolicylab.com/publications/everything-is-live-now/inhaltsverzeichnis/can-relational-art-reconstitute-a-sense-of-connectivity-in-p) drawing on Bakhtin, Habermas, Levinas; analyzes WochenKlausur, Suzanne Lacy, Stephen Willats.




 **Kester, Grant H.** _The One and the Many: Contemporary Collaborative Art in a Global Context_. Durham: Duke University Press, 2011. ISBN: 978-0-8223-4987-7.

  * Argues for paradigm shift from art as object to “process of reciprocal creative labor”; examines Park Fiction, Ala Plastica, Huit Facettes. [Duke University Press](https://read.dukeupress.edu/books/book/2183/The-One-and-the-ManyContemporary-Collaborative-Art)




 **Kester, Grant H. “Dialogical Aesthetics: A Critical Framework For Littoral Art.”** _Variant_ 9 (1999/2000). <https://www.variant.org.uk/9texts/KesterSupplement.html>

  * Original articulation of dialogical aesthetics concept.




 **Kester, Grant H.** _Beyond the Sovereign Self: Aesthetic Autonomy from the Avant-Garde to Socially Engaged Art_. Durham: Duke University Press, 2023.

  * Latest theoretical development addressing aesthetic autonomy debates.




### Claire Bishop on Participation

 **Bishop, Claire, ed.** _Participation_. Documents of Contemporary Art Series. London: Whitechapel; Cambridge, MA: MIT Press, 2006. ISBN: 978-0-262-52464-3.

  * Essential anthology with first English translation of Rancière’s “Problems and Transformations in Critical Art”; texts by Eco, Brecht, Barthes, Bürger, Nancy, Guattari.




 **Bishop, Claire. “The Social Turn: Collaboration and Its Discontents.”** _Artforum_ 44, no. 6 (February 2006): 178–183.

  * Coined “social turn”; critiques ethical evaluation over aesthetic judgment in collaborative art.




### Other Key Authors

 **Thompson, Nato, ed.** _Living as Form: Socially Engaged Art from 1991-2011_. New York: Creative Time; Cambridge, MA: MIT Press, 2012. ISBN: 978-0-262-01734-3.

  * Major exhibition catalogue with essays by Bishop, Holmes, Jackson, Lind; surveys 100+ projects. [e-flux](https://www.e-flux.com/journal/72/60504/occupy-and-the-end-of-socially-engaged-art)




 **Finkelpearl, Tom.** _What We Made: Conversations on Art and Social Cooperation_. Durham: Duke University Press, 2013. ISBN: 978-0-8223-5289-1.

  * Proposes “social cooperation” framework; conversations with Kester, Bishop, Bruguera, Lowe, Ukeles.




 **Finkelpearl, Tom.** _Dialogues in Public Art_. Cambridge, MA: MIT Press, 2000.

  * Earlier companion on public art conversations.




### Nora Sternfeld and Educational Turn

 **Sternfeld, Nora.** _Das radikaldemokratische Museum_ [The Radical Democratic Museum]. Berlin: De Gruyter, 2018.

  * Twelve essays on radical reconceptualization of museums as contested public spaces; key text on institutional reform strategies.




 **Sternfeld, Nora. “That Certain Savoir/Pouvoir: Gallery Education as a Field of Possibility.”** Academia.edu.

  * Examines art mediation within knowledge/power nexus drawing on Foucault.




 **O’Neill, Paul, and Mick Wilson, eds.** _Curating and the Educational Turn_. London: Open Editions/De Appel, 2010. ISBN: 978-0-949004-18-5.

  * First major anthology on pedagogy in curatorial practice; contributors include Buren, Esche, Gillick, Rogoff.




 **Rogoff, Irit. “Turning.”** _e-flux journal_ 0 (2008).

  * Foundational articulation of “educational turn” concept.




### Additional Sources

 **Bourriaud, Nicolas.** _Relational Aesthetics_. Dijon: Les Presses du Réel, 1998/2002. ISBN: 978-2-84066-060-6.

  * Foundational text for relational aesthetics; [Wikipedia](https://en.wikipedia.org/wiki/Relational_art) object of Bishop’s critique. [FIELD](https://field-journal.com/issue-6/a-note-on-socially-engaged-art-criticism/)




 **Kwon, Miwon.** _One Place After Another: Site-Specific Art and Locational Identity_. Cambridge, MA: MIT Press, 2002.

  * Critical analysis of site-specificity and community-based art.




 **Lacy, Suzanne, ed.** _Mapping the Terrain: New Genre Public Art_. Seattle: Bay Press, 1995.

  * Early anthology coining “new genre public art.”




 **Helguera, Pablo.** _Education for Socially Engaged Art: A Materials and Techniques Handbook_. New York: Jorge Pinto Books, 2011.

  * Practical guide complementing theoretical literature.




* * *

## III. JACQUES RANCIÈRE: POLITICS AND AESTHETICS (15 Sources)

### Primary Texts

 **Rancière, Jacques.** _The Politics of Aesthetics: The Distribution of the Sensible_. Translated by Gabriel Rockhill. London: Continuum, 2004. ISBN: 0-8264-8932-X.

  * Core text defining _partage du sensible_ ; articulates three regimes of art (ethical, representative, aesthetic). Introduction by Slavoj Žižek. [Amazon](https://www.amazon.com/Politics-Aesthetics-Bloomsbury-Revelations/dp/1780935358)




 **Rancière, Jacques.** _Dissensus: On Politics and Aesthetics_. Edited and translated by Steven Corcoran. London: Continuum, 2010. ISBN: 978-1-8470-6445-5.

  * Major collection including “Ten Theses on Politics,” “The Aesthetic Revolution and Its Outcomes,” “The Paradoxes of Political Art.”




 **Rancière, Jacques.** _The Emancipated Spectator_. Translated by Gregory Elliott. London: Verso, 2009. ISBN: 978-1-84467-343-8.

  * Critiques binary between active performers and passive spectators; draws on _The Ignorant Schoolmaster_ to theorize emancipatory art.




 **Rancière, Jacques.** _Disagreement: Politics and Philosophy_. Translated by Julie Rose. Minneapolis: University of Minnesota Press, 1999. ISBN: 978-0-8166-2844-5.

  * Foundational political philosophy distinguishing politics (arising from the _demos_ disrupting established order) from “police” (management of bodies).




 **Rancière, Jacques.** _Aisthesis: Scenes from the Aesthetic Regime of Art_. Translated by Zakir Paul. London: Verso, 2013. ISBN: 978-1-78168-089-6.

  * Most substantive treatment of aesthetics through fourteen “scenes” from 1764–1941.




 **Rancière, Jacques.** _The Ignorant Schoolmaster: Five Lessons in Intellectual Emancipation_. Translated by Kristin Ross. Stanford: Stanford University Press, 1991. ISBN: 978-0-8047-1969-8.

  * Develops axiom of “equality of intelligence” through Joseph Jacotot’s story.




 **Rancière, Jacques. “The Aesthetic Revolution and Its Outcomes.”** _New Left Review_ 14 (March-April 2002): 133–151.

  * Traces aesthetic regime from Schiller through avant-garde movements.




### Secondary Sources

 **Deranty, Jean-Philippe, ed.** _Jacques Rancière: Key Concepts_. Durham: Acumen, 2010. DOI: 10.1017/UPO9781844654727.

  * Authoritative collection introducing Rancière’s central concepts; Panagia’s chapter on _partage du sensible_ essential.




 **May, Todd.** _The Political Thought of Jacques Rancière: Creating Equality_. Edinburgh: Edinburgh University Press, 2008. ISBN: 978-0-7486-3586-3.

  * First single-authored English monograph; endorsed by Rancière.




 **Bowman, Paul, and Richard Stamp, eds.** _Reading Rancière_. London: Continuum, 2011. ISBN: 978-1-4411-3107-6.

  * Includes Rancière’s “The Thinking of Dissensus: Politics and Aesthetics.”




 **Rockhill, Gabriel, and Philip Watts, eds.** _Jacques Rancière: History, Politics, Aesthetics_. Durham: Duke University Press, 2009. ISBN: 978-0-8223-4464-7.

  * Features Balibar’s “What is political philosophy?” and analyses of Rancière’s historiography.




 **Papastergiadis, Nikos. “A Breathing Space for Aesthetics and Politics: An Introduction to Jacques Rancière.”** _Theory, Culture & Society_ 31, no. 7-8 (2014): 5–26. DOI: 10.1177/0263276414551995.

  * Maps Rancière’s shift from political theory to contemporary art practice.




 **Lampert, Matthew. “Beyond the Politics of Reception: Jacques Rancière and the Politics of Art.”** _Continental Philosophy Review_ 50, no. 2 (2016): 181–200.

  * Critical engagement with Rancière’s “different politics of art.”




 **Šuvaković, Miško, and Jale Erzen. “Everyday Aesthetics and Jacques Rancière.”** _Journal of Aesthetics and Culture_ 10, no. 1 (2018). DOI: 10.1080/20004214.2018.1506209.

  * Explores Rancière’s relevance for everyday aesthetics discourse.




 **Feola, Michael. “Designing Dissensual Common Sense.”** _The Design Journal_ 24, no. 6 (2021). DOI: 10.1080/17547075.2021.1966730.

  * Applications of Rancière to design theory and activism.




* * *

## IV. CLAIRE BISHOP AND ANTAGONISM / CHANTAL MOUFFE’S AGONISTIC PLURALISM (18 Sources)

### Claire Bishop

 **Bishop, Claire. “Antagonism and Relational Aesthetics.”** _October_ 110 (Fall 2004): 51–79. DOI: 10.1162/0162287042379810.

  * Seminal critique using Laclau/Mouffe’s antagonism theory; [Marginalutility](http://www.marginalutility.org/wp-content/uploads/2010/07/Claire-Bishop_Antagonism-and-Relational-Aesthetics.pdf) proposes “relational antagonism” in Sierra and Hirschhorn as alternative to consensus models. [Marginalutility](http://www.marginalutility.org/wp-content/uploads/2010/07/Claire-Bishop_Antagonism-and-Relational-Aesthetics.pdf)




 **Bishop, Claire.** _Artificial Hells: Participatory Art and the Politics of Spectatorship_. London: Verso, 2012. ISBN: 978-1-84467-690-3.

  * First comprehensive historical/theoretical overview of participatory art; challenges ethical criteria, advocates aesthetic judgment drawing on Rancière. [Internet Archive](https://archive.org/details/artificialhellsp0000bish)




 **Bishop, Claire.** _Installation Art: A Critical History_. London: Tate; New York: Routledge, 2005. ISBN: 978-0-415-97412-0.

  * Examines viewer’s presence as medium; provides theoretical framework later developed in participatory art writings.




### Chantal Mouffe

 **Laclau, Ernesto, and Chantal Mouffe.** _Hegemony and Socialist Strategy: Towards a Radical Democratic Politics_. London: Verso, 1985; 2nd ed. 2001. ISBN: 978-1-85984-330-7.

  * Foundational post-Marxist text [Wikipedia](https://en.wikipedia.org/wiki/Hegemony_and_Socialist_Strategy) developing discourse theory and hegemony concept; argues antagonism is constitutive of the social. [Marginalutility](http://www.marginalutility.org/wp-content/uploads/2010/07/Claire-Bishop_Antagonism-and-Relational-Aesthetics.pdf)




 **Mouffe, Chantal.** _The Return of the Political_. London: Verso, 1993. ISBN: 978-0-86091-433-8.

  * Develops agonistic democracy; distinguishes “the political” (ontological antagonism) from “politics” (practices organizing coexistence).




 **Mouffe, Chantal.** _The Democratic Paradox_. London: Verso, 2000. ISBN: 978-1-85984-764-0.

  * Expands agonistic pluralism; key distinction between adversaries (legitimate opponents) and enemies (outside democratic principles).




 **Mouffe, Chantal.** _On the Political_. London: Routledge, 2005. ISBN: 978-0-415-30521-1.

  * Accessible synthesis critiquing post-political consensus and deliberative democracy.




 **Mouffe, Chantal.** _Agonistics: Thinking the World Politically_. London: Verso, 2013. ISBN: 978-1-78168-103-9.

  * Most recent systematic presentation; includes chapter on art and agonistic politics.




 **Mouffe, Chantal. “Artistic Activism and Agonistic Spaces.”** _Art & Research_ 1, no. 2 (Summer 2007): 1–5. <http://www.artandresearch.org.uk/v1n2/mouffe.html>

  * Key essay applying agonistic theory to art; argues critical art “foments dissensus.”




 **Mouffe, Chantal. “Deliberative Democracy or Agonistic Pluralism.”** _Social Research_ 66, no. 3 (Fall 1999): 745–758.

  * Foundational essay critiquing deliberative democracy’s rationalistic assumptions.




### Related Scholarship

 **Martin, Stewart. “Critique of Relational Aesthetics.”** _Third Text_ 21, no. 4 (July 2007): 369–386. DOI: 10.1080/09528820701433323.

  * Rigorous critique of Bourriaud alongside Bishop’s intervention; Marxist-inflected alternative reading.




 **Kester, Grant H. “Another Turn” [Response to Bishop].** _Artforum_ 44, no. 9 (May 2006): 22.

  * Direct response challenging Bishop’s rigid aesthetic/activist boundary. [The Free Library](https://www.thefreelibrary.com/Another+turn.-a0145872665)




* * *

## V. AFFECT THEORY (15 Sources)

### Brian Massumi

 **Massumi, Brian. “The Autonomy of Affect.”** _Cultural Critique_ 31 (Autumn 1995): 83–109. DOI: 10.2307/1354446.

  * Foundational essay establishing affect/emotion distinction; introduces “intensity,” the “missing half-second,” and affect’s resistance to linguistic capture.




 **Massumi, Brian.** _Parables for the Virtual: Movement, Affect, Sensation_. Durham: Duke University Press, 2002. ISBN: 978-0-8223-2897-1. DOI: 10.1215/9780822383574.

  * Comprehensive philosophy of embodied experience drawing on Deleuze, Bergson, William James.




 **Massumi, Brian.** _Politics of Affect_. Cambridge: Polity Press, 2015. ISBN: 978-0-7456-8982-1.

  * Explores Spinoza’s “capacity to affect and be affected”; develops “differential affective attunement” and “micropolitics.”




### Sara Ahmed

 **Ahmed, Sara. “Affective Economies.”** _Social Text_ 79/22, no. 2 (Summer 2004): 117–139. DOI: 10.1215/01642472-22-2_79-117.

  * Develops affect as “currency” circulating between bodies; introduces “stickiness” of affect.




 **Ahmed, Sara.** _The Cultural Politics of Emotion_. Edinburgh: Edinburgh University Press, 2004; 2nd ed. 2014. ISBN: 978-0-7486-1846-0.

  * Examines emotions as cultural practices; bodies given value through emotion aligning with ideologies. [Amazon +2](https://www.amazon.com/Cultural-Politics-Emotion-AHMED/dp/0748618465)




### Other Key Theorists

 **Berlant, Lauren.** _Cruel Optimism_. Durham: Duke University Press, 2011. ISBN: 978-0-8223-5111-5.

  * “Cruel optimism” names attachment to compromised conditions; examines post-war “good life” fantasies that wear out subjects.




 **Brennan, Teresa.** _The Transmission of Affect_. Ithaca: Cornell University Press, 2004. ISBN: 978-0-8014-8862-7.

  * Argues affects transmit between bodies through “entrainment”; develops “intelligence of the flesh.”




 **Stewart, Kathleen.** _Ordinary Affects_. Durham: Duke University Press, 2007. ISBN: 978-0-8223-4088-1. DOI: 10.1215/9780822390404.

  * Ethnographic/theoretical hybrid examining affect in everyday American life.




 **Tomkins, Silvan S.** _Affect Imagery Consciousness: The Complete Edition_. New York: Springer, 2008. ISBN: 978-0-8261-4407-3.

  * Foundational psychological theory identifying nine innate affects as primary motivational system. [Evekosofskysedgwick](https://evekosofskysedgwick.net/writing/shame-and-its-sisters)




### Anthologies

 **Gregg, Melissa, and Gregory J. Seigworth, eds.** _The Affect Theory Reader_. Durham: Duke University Press, 2010. ISBN: 978-0-8223-4776-7.

  * Field-defining collection; contributors include Ahmed, Anderson, Berlant, Massumi, Clough, Stewart, Thrift.




 **Clough, Patricia Ticineto, and Jean Halley, eds.** _The Affective Turn: Theorizing the Social_. Durham: Duke University Press, 2007. ISBN: 978-0-8223-3923-6.

  * Charts movement from psychoanalytic criticism toward affect and information; foreword by Michael Hardt.




 **Sedgwick, Eve Kosofsky, and Adam Frank, eds.** _Shame and Its Sisters: A Silvan Tomkins Reader_. Durham: Duke University Press, 1995. ISBN: 978-0-8223-1682-4.

  * Introduces Tomkins’s affect theory; editors’ introduction places affect in systems theory context. [Evekosofskysedgwick](https://evekosofskysedgwick.net/writing/shame-and-its-sisters)




 **Seigworth, Gregory J., and Carolyn Pedwell, eds.** _The Affect Theory Reader 2: Worldings, Tensions, Futures_. Durham: Duke University Press, 2023. ISBN: 978-0-8223-9523-2.

  * Updates original reader; addresses race, disability, decolonial thought, ecology.




 **Puar, Jasbir K.** _Terrorist Assemblages: Homonationalism in Queer Times_. Durham: Duke University Press, 2007. ISBN: 978-0-8223-4094-2.

  * Develops “assemblage” theory analyzing race, sexuality, terrorism post-9/11; coins “homonationalism.”




 **Cvetkovich, Ann.** _Depression: A Public Feeling_. Durham: Duke University Press, 2012. ISBN: 978-0-8223-5238-9.

  * Examines depression as “public feeling” connected to political life.




* * *

## VI. JUST STOP OIL: TACTICAL ANALYSIS AND DOCUMENTATION (15 Sources)

### Primary Documentation

 **Just Stop Oil. “Just Stop Oil supporters throw soup over Van Gogh’s Sunflowers.”** October 14, 2022. <https://juststopoil.org/2022/10/14/>

  * Original press release with direct quotes from Phoebe Plummer.




 **Frieze. “An Interview With Just Stop Oil.”** October 2022. <https://www.frieze.com/article/interview-just-stop-oil>

  * Interview with Phoebe Plummer and Anna Holland by Andrew Durbin explaining tactical reasoning. [Frieze](https://www.frieze.com/article/interview-just-stop-oil)




### News Coverage

 **NPR. “Climate protesters throw soup on Van Gogh’s ‘Sunflowers’ painting in London.”** October 14, 2022.

  * Contemporaneous mainstream coverage.




 **NPR. “Just Stop Oil climate activist explains why they threw soup on van Gogh.”** November 1, 2022.

  * Direct interview with Plummer explaining tactical reasoning.




 **The Art Newspaper. “Protestors who poured soup over Van Gogh’s Sunflowers sentenced to prison.”** September 27, 2024.

  * Sentencing coverage; documents open letter from 100+ artists.




 **ARTnews. “Just Stop Oil Protesters Sentenced to Prison.”** September 27, 2024.

  * Court proceedings; Judge Hehir quotes; National Gallery statement.




 **Artforum. “Climate Activists Who Souped Van Gogh’s Sunflowers Sentenced to Prison.”** September 27, 2024.

  * Legal detail and sentencing history context.




 **Dazed. “Two Just Stop Oil activists jailed for throwing soup at a Van Gogh painting.”** September 27, 2024.

  * Documents Plummer’s 20-minute courtroom address citing Pankhurst, Gandhi, Mandela. [Dazed](https://www.dazeddigital.com/life-culture/article/64757/1/two-just-stop-oil-activists-jailed-for-throwing-soup-at-a-van-gogh-painting)




### Legal and Legislative Context

 **UK Government. “Police, Crime, Sentencing and Courts Act 2022.”** <https://www.legislation.gov.uk/ukpga/2022/32>

  * Primary legal documentation; statutory public nuisance offense (max 10 years).




 **UK Home Office. “Protest powers: Police, Crime, Sentencing and Courts Act 2022 factsheet.”**

  * Government rationale for protest restrictions.




### Academic Analysis

 **Social Change Lab. “Just Stop Oil’s strategy in their own words.”**

https://www.socialchangelab.org/

  * Academic think-tank analysis of JSO tactics; radical flank theory.




 **Nature/Humanities and Social Sciences Communications. “The power of protest in the media: examining portrayals of climate activism in UK news.”** 2024\. DOI: 10.1038/s41599-024-02688-0.

  * Peer-reviewed analysis of climate activism media coverage.




 **Mould, Oli. “Three arguments why Just Stop Oil was right to target Van Gogh’s Sunflowers.”** _The Conversation_ , October 17, 2022.

  * Academic defense from Royal Holloway geography scholar.




### Organizational Context

 **Wikipedia. “Just Stop Oil.”** <https://en.wikipedia.org/wiki/Just_Stop_Oil>

  * Comprehensive organizational background: founded February 2022; Roger Hallam co-founder; Climate Emergency Fund financing.




 **TIME. “Just Stop Oil: Protests, Fundings, Founder, and Origins.”**

  * Major news profile of organization structure and funding.




* * *

## VII. CLIMATE ACTIVISM AND CONTEMPORARY ART (15 Sources)

### T.J. Demos

 **Demos, T.J.** _Decolonizing Nature: Contemporary Art and the Politics of Ecology_. Berlin: Sternberg Press, 2016. ISBN: 978-3-95679-094-2.

  * First systematic art historical study of ecology and contemporary art; examines artist-activist practices combining ecological sustainability, climate justice, and radical democracy. [Sternberg Press](https://www.sternberg-press.com/product/decolonizing-nature-contemporary-art-and-the-politics-of-ecology/)[MIT Press](https://mitpress.mit.edu/9783956790942/decolonizing-nature/)




 **Demos, T.J.** _Against the Anthropocene: Visual Culture and Environment Today_. Berlin: Sternberg Press, 2017. ISBN: 978-3-95679-210-6.

  * Argues “Anthropocene” works ideologically supporting neoliberal financialization of nature; advocates “Capitalocene.”




### Yates McKee

 **McKee, Yates.** _Strike Art: Contemporary Art and the Post-Occupy Condition_. London: Verso, 2016. ISBN: 978-1-78478-188-0.

  * First comprehensive art historical reading of Occupy Wall Street; tracks MTL, Not An Alternative, the Illuminator. [Internet Archive](https://archive.org/details/strikeartcontemp0000mcke)[Amazon](https://www.amazon.com/Strike-Art-Contemporary-Post-Occupy-Condition/dp/1784786810)




 **McKee, Yates. “Occupy and the End of Socially Engaged Art.”** _e-flux journal_ 72 (2016).

  * Examines Occupy as “political truth-event” transforming socially engaged art discourse.




### Extinction Rebellion

 **Coombs, Gina. “It’s (Red) Hot Outside! The Aesthetics of Climate Change Activists Extinction Rebellion.”** _The Journal of Public Space_ 5, no. 4 (2020): 123–136. DOI: 10.32891/jps.v5i4.1407.

  * Scholarly analysis of XR’s graphic and performative aesthetics; Red Rebel Brigade. [ResearchGate](https://www.researchgate.net/publication/354377051_It's_Red_Hot_Outside_The_Aesthetics_of_Climate_Change_Activists_Extinction_Rebellion)




 **Frieze. “The Defiant Art and Design of Extinction Rebellion.”** October 2019.

  * XR’s visual identity: hourglass logo, “millennial pink,” theatrical tactics. [Frieze](https://www.frieze.com/article/defiant-art-and-design-extinction-rebellion)




 **Social Movement Studies. “Extinction Rebellion’s artivism.”** 2022\. DOI: 10.1080/14742837.2022.2122949.

  * Empirical examination creating “aeffect”—activism’s effect combined with art’s affect. [Taylor & Francis Online](https://www.tandfonline.com/doi/full/10.1080/14742837.2022.2122949)




### Protest Aesthetics

 **Boyd, Andrew, and Dave Oswald Mitchell, eds.** _Beautiful Trouble: A Toolbox for Revolution_. New York: OR Books, 2012. ISBN: 978-1-944869-09-0.

  * Collaborative handbook assembling wisdom from artists and activists; culture jamming, ethical spectacle.




 **Duncombe, Stephen.** _Dream: Re-Imagining Progressive Politics in an Age of Fantasy_. New York: The New Press, 2007. ISBN: 978-1-59558-049-8.

  * Develops “ethical spectacle” using dramatic, emotional appeals for progressive ends.




 **McGarry, Aidan, et al., eds.** _The Aesthetics of Global Protest: Visual Culture and Communication_. Amsterdam: Amsterdam University Press, 2020. ISBN: 978-94-6372-491-3. DOI: 10.5117/9789463724913.

  * Interdisciplinary volume examining protest aesthetics globally; preface by Nicholas Mirzoeff. [Oapen](https://library.oapen.org/handle/20.500.12657/23606)




### Museum Activism

 **Grindon, Gavin. “Curating with Counterpowers: Activist Curating, Museum Protest, and Institutional Liberation.”** _Social Text_ 41, no. 2 (2023): 19–44. DOI: 10.1215/01642472-10383193.

  * Analysis by Liberate Tate member; examines turn toward curating, museums, and heritage in protest.




 **Liberate Tate.** Documentation 2010–2017. 

https://liberatetate.wordpress.com/

  * Primary documentation of six-year campaign against BP sponsorship.




 **Flood, Catherine, and Gavin Grindon, eds.** _Disobedient Objects_. London: V&A Publishing, 2014. ISBN: 978-1-85177-826-2.

  * V&A exhibition catalogue examining design innovation in social movements.




 **Miles, Malcolm.** _Art Rebellion: The Aesthetics of Social Transformation_. London: Bloomsbury Academic, 2023. ISBN: 978-1-350-23997-5.

  * Contemporary analysis including Liberate Tate, Red Rebel Brigade, Extinction Rebellion.




 **P.A.I.N. (Prescription Addiction Intervention Now).** Campaign documentation 2017–present. Documentary: Poitras, Laura, dir. _All the Beauty and the Bloodshed_. Participant/HBO, 2022.

  * Nan Goldin’s activist group targeting Sackler family philanthropy.




* * *

## VIII. EMBODIED KNOWLEDGE AND SOMATIC PRACTICE (15 Sources)

### Diana Taylor

 **Taylor, Diana.** _The Archive and the Repertoire: Performing Cultural Memory in the Americas_. Durham: Duke University Press, 2003. ISBN: 978-0822331230.

  * Foundational distinction between “archive” (texts, documents) and “repertoire” (embodied practice); performance as epistemic system.




### Rebecca Schneider

 **Schneider, Rebecca.** _Performing Remains: Art and War in Times of Theatrical Reenactment_. New York: Routledge, 2011. ISBN: 978-0415404426.

  * Argues “performance can be engaged as what remains”; introduces “temporal drag”; body as archive.




 **Schneider, Rebecca.** _The Explicit Body in Performance_. New York: Routledge, 1997. ISBN: 978-0415086585.

  * Examines feminist body art; foundation for later work on performance remains.




### Peggy Phelan

 **Phelan, Peggy.** _Unmarked: The Politics of Performance_. London: Routledge, 1993. ISBN: 978-0-415-06822-2. DOI: 10.4324/9780203359433.

  * Foundational ontology: “Performance’s only life is in the present...it cannot be saved, recorded, documented.”




 **Phelan, Peggy, and Jill Lane, eds.** _The Ends of Performance_. New York: NYU Press, 1998. ISBN: 978-0814766460.

  * Landmark anthology; contributors include Roach, Taylor, Schechner, Sedgwick, Pollock.




### Judith Butler on Assembly

 **Butler, Judith.** _Notes Toward a Performative Theory of Assembly_. Cambridge, MA: Harvard University Press, 2015. ISBN: 978-0-674-96775-5.

  * Extends performativity to bodies in public assembly; precarity as galvanizing force.




 **Butler, Judith.** _Precarious Life: The Powers of Mourning and Violence_. London: Verso, 2004. ISBN: 978-1844670055.

  * Vulnerability as shared ontological condition; exposure to others as constitutive of subjectivity.




 **Butler, Judith.** _Frames of War: When Is Life Grievable?_ London: Verso, 2009. ISBN: 978-1-84467-626-2.

  * Distinction between precariousness (ontological) and precarity (politically induced).




### Kelly Oliver

 **Oliver, Kelly.** _Witnessing: Beyond Recognition_. Minneapolis: University of Minnesota Press, 2001. ISBN: 978-0-8166-3625-6.

  * Proposes “witnessing” as alternative to Hegelian recognition; subjectivity as “response-ability.”




### Performance Methodology

 **Conquergood, Dwight.** _Cultural Struggles: Performance, Ethnography, Praxis_. Edited by E. Patrick Johnson. Ann Arbor: University of Michigan Press, 2013. ISBN: 978-0472051885.

  * Establishes performance ethnography methodology; “dialogic performance,” “coperformative witnessing.”




 **Pollock, Della. “Performing Writing.”** In _The Ends of Performance_ , edited by Phelan and Lane, 73–103. New York: NYU Press, 1998.

  * Foundational essay on “performative writing” as methodology.




### Queer Theory

 **Muñoz, José Esteban.** _Cruising Utopia: The Then and There of Queer Futurity_. New York: NYU Press, 2009; 10th Anniversary Edition, 2019. ISBN: 978-1479874569.

  * Develops queer utopianism; traces “ephemera as evidence.”




 **Muñoz, José Esteban.** _Disidentifications: Queers of Color and the Performance of Politics_. Minneapolis: University of Minnesota Press, 1999. ISBN: 978-0816630158.

  * Introduces “disidentification” as strategy of “working on and against” dominant ideology.




### Body Art

 **Jones, Amelia.** _Body Art/Performing the Subject_. Minneapolis: University of Minnesota Press, 1998. ISBN: 978-0-8166-2773-8.

  * Body art challenges Cartesian subject by performing intersubjectivity; Mendieta, Wilke, Acconci.




 **Jones, Amelia.** _Self/Image: Technology, Representation, and the Contemporary Subject_. London: Routledge, 2006. ISBN: 978-0415345224.

  * Examines how imaging technologies affect self-representation.




* * *

## IX. CRIMINALIZATION OF PROTEST AND LEGAL FRAMEWORKS (18 Sources)

### UK Legislation

 **UK Parliament House of Commons Library. “Police Powers: Protests.”** Research Briefing SN05013 (October 2025).

  * Official analysis of PCSC Act 2022 and Public Order Act 2023.




 **Liberty. “Public Order Act: New Protest Offences & ‘Serious Disruption.’”** November 2023.

  * Legal advocacy analysis; “serious disruption” as “more than minor hindrance.”




 **Mead, David.** _The New Law of Peaceful Protest: Rights & Regulation in the Human Rights Act Era_. Hart Publishing, 2010.

  * Authoritative treatment of UK protest law; Mead served as JCHR Parliamentary Academic Fellow.




### Global Criminalization

 **Berglund, Oscar, et al. “The Global Criminalization and Repression of Climate and Environmental Protest.”** _Environmental Politics_ (December 2025). DOI: 10.1080/09644016.2025.2602416.

  * Peer-reviewed mixed-methods analysis of 14 countries; five mechanisms of repression.




 **Berglund, Oscar, et al. “Criminalisation and Repression of Climate and Environmental Protests.”** University of Bristol (December 2024).

  * Major empirical study using ACLED data; UK, Australia, Canada show highest arrest rates.




 **Carnegie Endowment. “The Growing Criminalization of Climate and Environmental Protests.”** August 2025.

  * Policy analysis documenting “vilification” of activists; links media demonization to judicial outcomes.




### Climate Necessity Defense

 **Long, Lance N., and Ted Hamilton. “The Climate Necessity Defense: Proof and Judicial Error in Climate Protest Cases.”** _Stanford Environmental Law Journal_ 38:57 (2019).

  * Definitive legal scholarship on necessity defense; documents 21+ attempted uses.




 **Coca-Vila, Ivó. “On the Necessity Defense in a Democratic Welfare State.”** _Criminal Law and Philosophy_ (2023). DOI: 10.1007/s11572-023-09667-7.

  * German legal scholarship on classical defenses for climate protest.




 **Climate Defense Project. “Climate Necessity Defense Case Guide.”** August 2021.

  * Comprehensive practitioner’s guide documenting major cases internationally.




### Civil Disobedience Theory

 **Brownlee, Kimberley.** _Conscience and Conviction: The Case for Civil Disobedience_. Oxford: Oxford University Press, 2012.

  * Argues civil disobedience “generally more defensible than private conscientious objection.”




 **Stanford Encyclopedia of Philosophy. “Civil Disobedience.”** Brownlee and Delmas, revised December 2023.

  * Authoritative reference covering publicity requirements, Rawlsian approaches, “critical turn.”




 **Lefkowitz, David. “In Defense of Penalizing (but Not Punishing) Civil Disobedience.”** University of Richmond (2016).

  * Distinguishes “penalties” from “punishment”; supports penalties within “optimal institutionalized practice.”




 **Pineda, Erin R.** _Seeing Like an Activist: Civil Disobedience and the Civil Rights Movement_. New York: Oxford University Press, 2021. ISBN: 978-0190071004.

  * Civil disobedience “dramatizes and discloses ordinarily obscured repression.”




### Trial as Theater

 **Federal Judicial Center. “The Chicago Seven: 1960s Radicalism in the Federal Courts.”** By Bruce A. Ragsdale.

  * Official judicial history; trial as “part conspiracy trial, part political theater.”




### Suffragette Precedent

 **Library of Congress. “Tactics of the National Woman’s Party, 1917-1920.”**

  * Primary documentation: “imprisonment claimed as martyrdom, publicity and increased membership.”




 **Villanova University Law School. “Alice Paul and the National Woman’s Party Legal Strategy.”** 2018.

  * Legal history of suffragist litigation; “sophisticated view of connections between ethical civil disobedience and political action.”




### Art and Legal Liability

 **McEvilley, Thomas. “Art in the Dark.”** _Artforum_ (1983).

  * Foundational essay situating Burden, Acconci within Cynic philosophy; questions how transgressive activities “came to be called art.”




 **ARTnews. “How Far Is Too Far?”** 2007.

  * Interviews with Acconci and Abramović on ethical limits in performance art.




* * *

## X. VISIBILITY, VULNERABILITY, AND STRATEGIC EXPOSURE (12 Sources)

### Judith Butler

 **Butler, Judith.** _Notes Toward a Performative Theory of Assembly_. Harvard University Press, 2015.

  * Bodies assembled have expressive dimensions “saying” something without speech; assemblies create political space.




 **Butler, Judith.** _Frames of War: When Is Life Grievable?_ Verso, 2009.

  * “Frames” structure perception of grievable lives; differential exposure to violence.




 **Butler, Judith.** _Precarious Life_. Verso, 2004.

  * Vulnerability as shared human condition; exposure to others as constitutive of subjectivity.




 **Butler, Judith, and Athena Athanasiou.** _Dispossession: The Performative in the Political_. Cambridge: Polity, 2013. ISBN: 978-0-7456-5381-5.

  * Bodies on street as precarious—exposed to police while opposing dispossession.




 **Butler, Judith, Zeynep Gambetti, and Leticia Sabsay, eds.** _Vulnerability in Resistance_. Durham: Duke University Press, 2016. ISBN: 978-0-8223-6290-6.

  * Most directly addresses vulnerability as strategic resource; Butler’s chapter “Rethinking Vulnerability and Resistance.”




### Other Theorists

 **Oliver, Kelly.** _Witnessing: Beyond Recognition_. University of Minnesota Press, 2001.

  * Witnessing as alternative to Hegelian recognition; subjectivity as “response-ability.”




 **Phelan, Peggy.** _Unmarked: The Politics of Performance_. Routledge, 1993.

  * “Visibility is a trap”; political power in “active disappearance from the visual field.”




 **Murphy, Ann V.** _Violence and the Philosophical Imaginary_. Albany: SUNY Press, 2012. ISBN: 978-1-4384-4030-9.

  * “Corporeal vulnerability and the new humanism”; ethical ambiguity of vulnerability.




 **Browne, Simone.** _Dark Matters: On the Surveillance of Blackness_. Durham: Duke University Press, 2015. ISBN: 978-0-8223-5938-8.

  * “Racializing surveillance”; “dark sousveillance” as counter-surveillance; “Black luminosity” as forced visibility.




 **Foucault, Michel.** _Discipline and Punish: The Birth of the Prison_. Translated by Alan Sheridan. New York: Vintage, 1977.

  * “Visibility is a trap”; Panopticism as mechanism of disciplinary power.




 **Cavarero, Adriana.** _Horrorism: Naming Contemporary Violence_. New York: Columbia University Press, 2009. ISBN: 978-0-231-14456-2.

  * “Ontological altruism”; vulnerability as ontological condition.




 **Mackenzie, Catriona, Wendy Rogers, and Susan Dodds, eds.** _Vulnerability: New Essays in Ethics and Feminist Philosophy_. New York: Oxford University Press, 2014. ISBN: 978-0-19-931656-4.

  * Taxonomy of vulnerability types: inherent, situational, pathogenic.




* * *

## XI. SHAME, CONSCIOUSNESS-RAISING, AND MARTYRDOM (13 Sources)

### Shame and Affect

 **Sedgwick, Eve Kosofsky, and Adam Frank, eds.** _Shame and Its Sisters: A Silvan Tomkins Reader_. Duke University Press, 1995.

  * Shame as “active and activating”; foundational for affect theory in humanities.




 **Sedgwick, Eve Kosofsky.** _Touching Feeling: Affect, Pedagogy, Performativity_. Duke University Press, 2003. ISBN: 978-0822330158.

  * Shame’s performative dimension; introduces “reparative reading.”




 **Ahmed, Sara.** _The Cultural Politics of Emotion_. 2nd ed. Routledge, 2015.

  * Chapter on shame; emotions as “sticky” adhering to objects and bodies.




### Queer Activism

 **Gould, Deborah B.** _Moving Politics: Emotion and ACT UP’s Fight against AIDS_. Chicago: University of Chicago Press, 2009. ISBN: 978-0226305301.

  * Definitive study developing “emotional habitus”; traces shame-to-pride-to-rage transformation.




 **Halperin, David M., and Valerie Traub, eds.** _Gay Shame_. Chicago: University of Chicago Press, 2009. ISBN: 978-0226314358.

  * Interdisciplinary volume examining shame’s productive potential for queer culture.




### Consciousness-Raising

 **Sowards, Stacey K., and Valerie R. Renegar. “The Rhetorical Functions of Consciousness-Raising in Third Wave Feminism.”** _Communication Studies_ 55, no. 4 (2004): 535–552. DOI: 10.1080/10510970409388637.

  * Evolution of CR rhetoric; personal narratives as self-persuasion.




 **Gleeson, Jessamy, and Breanna Turner. “Online Feminist Activism as Performative Consciousness-Raising: A #MeToo Case Study.”** In _#MeToo and the Politics of Social Change_ , 53–69. Palgrave Macmillan, 2019. DOI: 10.1007/978-3-030-15213-0_4.

  * Bridges historical CR to digital activism.




 **Hall, Ruth. “The Women’s Liberation Movement, Activism and Therapy at the Grassroots, 1968–1985.”** _Women’s History Review_ 28, no. 7 (2019): 1095–1113. DOI: 10.1080/09612025.2019.1564437.

  * Documents CR transforming stigmatized emotional states into political resources.




### Political Martyrdom

 **Murphy, Andrew R. “Theorizing Political Martyrdom.”** _Political Theology_ 24, no. 5 (2023): 435–456. DOI: 10.1080/1462317X.2022.2125118.

  * Defines political martyrdom through death, consecration, and transmission.




 **DeSoucey, Michaela, et al. “Memory and Sacrifice: An Embodied Theory of Martyrdom.”** _Cultural Sociology_ 2, no. 1 (2008): 99–121. DOI: 10.1177/1749975507086276.

  * Martyrdom as contested social process; corporeal body as source of meaning.




### Strategic Criminalization

 **Lai, Ten-Herng. “Civil Disobedience, Costly Signals, and Leveraging Injustice.”** _Ergo_ 6 (2020): 1137. DOI: 10.3998/ergo.1137.

  * Civil disobedience functions as “costly social signal”; effectiveness hinges on punishment.




 **Miller, Ian.** _A History of Force Feeding: Hunger Strikes, Prisons and Medical Ethics, 1909–1974_. London: Palgrave Macmillan, 2016. ISBN: 978-3-319-31286-6.

  * Suffragette hunger strikes as propaganda; “martyrdom while under their care.”




* * *

## XII. VERIFIED EVENT DOCUMENTATION: VAN GOGH SUNFLOWERS ACTION

### Key Facts (Cross-Referenced)

 **Date:** October 14, 2022, approximately 11:00 AM **Location:** Room 43, National Gallery, Trafalgar Square, London **Artwork:** Vincent van Gogh, _Sunflowers_ (1888, Arles) **Activists:** Phoebe Plummer (21, London; non-binary, they/them) and Anna Holland (21, Newcastle upon Tyne)

 **Note:** The original task referenced “Morgan Higgins”—all verified sources confirm the co-activist as **Anna Holland**.

 **Action:** Two cans Heinz Cream of Tomato Soup thrown at painting; activists glued themselves to wall; wore white Just Stop Oil shirts under jackets.

 **Statement:** “Is art worth more than life? More than food? More than justice?”

 **Damage:** Painting protected by glass, unharmed; 17th-century Italian frame sustained £10,000 damage from acid eroding patina.

 **Sentencing (September 27, 2024):**

  * Phoebe Plummer: 2 years (plus 3 months for separate slow march offense)

  * Anna Holland: 20 months




 **Judge Christopher Hehir:** “You came within the thickness of a pane of glass of irreparably damaging or destroying this priceless treasure.”

 **Appeal (March 7, 2025):** Baroness Carr upheld sentences, citing “damage caused to heritage and cultural assets as aggravating factors.”

* * *

## RESEARCH NOTE ON “ADAM WADLEY”

Extensive searches across academic databases, art criticism archives, and news sources did not locate documentation of a performance artist named “Adam Wadley” connected to Phoebe Plummer, Just Stop Oil, or the theoretical frameworks specified. The essay title—”The Phoebe Plummer Clone: Institutional Critique Through Intentional Visibility and the Somatic Aesthetics of Civil Disobedience”—suggests a conceptual framing of Plummer’s activism as performance art practice rather than documentation of an existing artist’s work about Plummer.

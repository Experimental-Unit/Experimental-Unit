---
title: 'The Experimental Unit Podcast: "If I''m Shinin'' Everybody Gonna Shine"'
subtitle: Blame It On My What Now?
author: Adam Wadley
publication: Experimental Unit
date: July 12, 2025
---

# The Experimental Unit Podcast: "If I'm Shinin' Everybody Gonna Shine"
[![](https://substackcdn.com/image/fetch/$s_!JO5_!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6f7bc2f9-8732-4bd4-8ab5-e1cab0f44038_4032x3024.jpeg)](https://substackcdn.com/image/fetch/$s_!JO5_!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6f7bc2f9-8732-4bd4-8ab5-e1cab0f44038_4032x3024.jpeg)

This is how I show my love

---
title: Sing A Song Of Springtime
subtitle: Just Don't Ask Me Whom It's For
author: Adam Wadley
publication: Experimental Unit
date: May 02, 2025
---

# Sing A Song Of Springtime
Troubled by the startling contrast

War and poetry alight

Stilted in their wills outlast

The fires long untended

Tell me what your thoughts portended

Out there in the pouring rain

Marbles floors and teeming brains

Could save not cruelest worlds

Made not new, love not unfurled

Someone controlled you, controlled for you

You have not been paying attention

I move forwards, you move backwards

“Sir, inward is looking promising.”

Tell me how the saints are grimacing

All the way they’re marching in

Blitzin’ couldn’t do like Donner

And we do wie du and me and you 

Are all together

A different kind of flying

The only real way

I’m high on adrenaline

I can’t sleep anymore

Woken up like some backward nation

Scrambling for the cellar door

Burn it down, descend some more

Basements where none want to go

Where the casements pile so

Like mounds in Velvet songs of bodies

Stacked up there like little arms

Didn’t know they went so high

Politicians making crazy sounds

And there’s plenty to wear black about

Tell me you can do without the fighting

Fighting through the curtain torn

And broken on the floor

Like some stupid girl unfucked the world

All that’s left is consolation

And the will of this strange nation

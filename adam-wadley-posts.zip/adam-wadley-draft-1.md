---
title: '[Draft 1]'
subtitle: Just Gotta Ship
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# [Draft 1]
To express that I am here building out my lore, with the idea that this building out of lore is some sort of special task.

Where it erupts is in the fact that making new lore is also simply taking action.

Yet still, the simple constellation of references shows something, builds something, some sort of blue bridges between black hearts, with orange earth and purple sky (or was it the other way around?).

I was thinking for example of “Hannah Montana,” which is a rap song by Migos but which is an extended play on the theme of “white” things.

I was just looking at how the ship that brought the first Jewish people to New Amsterdam was called Catrina.

That reminded me of one of my favorite lines from “Hannah Montana,” which goes:

[She a college girl but her wrist Katrina](https://genius.com/2894960/Migos-hannah-montana-twerk-remix/She-a-college-girl-but-her-wrist-katrina) (katrina call FEMA)  
[In the kitchen and she baking like Anita](https://genius.com/2773998/Migos-hannah-montana-twerk-remix/In-the-kitchen-and-she-baking-like-anita)

What I love about the song is that it is a silly song, and it is mentioning FEMA.

On the other hand, this song is about very grave topics. The people are making drugs, who knows what the health effects for them are; not to mention what will happen with the people who take the drugs, maybe people will die.

Still, it is a reveling in this cultural reference aspect of it, this Tarantino pop culture slurry as I have mentioned it before.

The comparison of stirring a pot to a hurricane which killed a bunch of people and displaced some who have never even come back to this day. 

This is what I would call a violence of metonymy. Imagine doing something like this in a speech or on a sign, people do of course.

But it is this invocation and _wielding_ of the reference, in other words unapologetically.

As I’ve said, this is being unapologetic for destructive behavior.

On the other side, over here with the mirror people, it’s obvious that lots of things happen, and it all hangs together.

I was just looking at [holomovement](https://en.wikipedia.org/wiki/Holomovement) by David Bohm, you could also call this a designed concept although I’m sure people would think them different sports.

This is perhaps above and beyond dependent co-arising, which I’m realizing has also become passe.

Also in general, I feel like Anna KW has had enough! Blocked, and I do feel a bit hit though probably not targeted in this idea of the person who in psychoanalytic terms refuses to be castrated, or fantasizes that they are not castrated, or something to this effect.

It is also with Bataille and this sense of sovereignty and excess, which it tied in with this potlatch idea of outbidding and giving away.

People talk about “luxury virtues,” but can we talk about the luxury of avoiding the topic of what is the actual state of technology and who is wielding it?

This cuts through some questions like the government. Back to “Hannah Montana,” it gets even better because the person is compared to a hurricane and then it goes “Katrina call FEMA!” 

It’s not even clear to me now if there’s a specific intention, it seems to me something like this person is so amazing that the emergency services had better get involved, because the situation is out of control.

Another thing I wanted to mention is that the second line mentions that the person is baking like Anita. I confess that I don’t know what that's referring to. But it makes me think of the song “[America](https://www.westsidestory.com/america)” from _West Side Story_. This is the one where Anita says “You forget _I’m_ in America” after someone says “everywhere _grime_ in America.”

Oh also, the fact that it talks about that this person is in college. This is also this idea of squandering, squandering opportunities or the chance to just be in the upscale environments.

I think there is something nice in this, of course I would be biased, but this idea of not wanting to take your place in the bureaucracies. We have our own anyway, of course. But still, to give oneself over to self-expression, because I really do think it is a worthwhile thing to do.

Not only this, but also cognitive-affective protectionism, which is also exactly the topic here, this charting the lore of the meta-lore about lore-building as my example of how lore-building is cool.

Cognitive-affective protectionism is basically the idea that you have a community or individual pursuit involving thoughts and feelings.

This pursuit is at a disadvantage when it comes to outside people picking it apart and demoralizing you, so therefore it’s perhaps the move to set up an inner space where you are free to elaborate.

Note how constrained this is: conceivably, if you are someone people are very worried about, you might be fully video’d all the time (even in the nude), infrared, whatever.

So the easy thing to say is that you have your opinions. Epictetus mentions this as being one of your affairs.

Well, technology is coming that can read brainwaves in order to get a general, and who knows perhaps one day very detailed impression of what you’re thinking about.

So at that point you are actively not thinking about something on purpose in order to escape the detection of your secret plan to do with the super secret technology. 

I can imagine this sort of cat-and-mouse game going on all the time. It’s operative in dramatic irony, and it’s endemic to uneven and combined development.

Once we are looking at uneven and combined development of persons, we are seeing for example information asymmetries between individual people, having to do with all sorts of things. We have all our memories, it’s pretty hard to tell someone everyone and get enough time to do that.

Therefore there are all sorts of dramatic ironies going on in any given situation, but since it’s the sort of thing not everyone knows, these secrets, then who would bring it up?

Hence the importance of revelations. This is basically the question of what revelations you have to give.

Like on your death bed. It’s important to summon that death bed energy and live each day like it was your last and make your dang revelations. At least the ones no one will kill you for making.

And even still, I advocate greater transparency. It would seem to me that what makes sense for the deep future is that there isn’t secret technology. I’m not sure how anyone can trust anyone else to be developing peak technology in secret.

The issue of course is that the same distrust problem one would want to address is the same reason why it won’t be addressed. This is again the Hobbesian Trap. So just notice our sequence:

  1. Blue Bridges Between Black Hearts

  2. Ship Catrina

  3. “Hannah Montana” Katrina/FEMA

  4. Uneven and Combined Development

  5. Information Asymmetries

  6. Bataille: sovereignty through squandering

  7. Cognitive-Affective Protectionism

  8. Hobbesian Trap




These are the sorts of nodes in the map of this post, which then bleeds into other posts where these terms and themes are also discussed.

Note that I’m thinking of starting to make raps. So what I’m building out here is a network of allusions, but the allusions are also about what it is that I’m trying to do, like, I pick out things that are cool from the standpoint of what I am trying to get across.

Like the highway of the consistent, for example, is a very cool idea. Maybe it’s like the highway of the consistent isn’t one big like wide type highway where everyone just fits, it’s more like those bridges between individual hearts, and the highway which is consistent is, again kind of like I say sometimes about these allusions, building networks so that each node has at least two different edges coming out of it.

That way as I think about it you can drive around in it like a car.

Actually now that I’m thinking about it, I’m think about collapsing node and edge down into the same thing. Because the thing is, what does an edge imply? Just some sort of relationship, but what kind? Can your graph only have one kind of relationship? That’s no good.

So I’m imagining like you have the nodes, then you give basically internal information, in other words things that this node is abstracting over, this node’s “inner world.”

So for example I take a line from Kate Bush’s song “Wuthering Heights,” like “We’d roll and fall in green.” If I’m looking at what can go inside this node, we can have things like:

  * We: who is being referred to? Who is the person talking and who is the other person?

  * Roll: rock and roll? As in “get it on”??

  * Fall: Fall of Adam, Fortunate fall, Grimes in 4AM: “Falling down again”

  * Green: Color of Ireland/St. Patrick’s day (3/17), chlorophyll




So each of these nodes is also going inward, this is “down” in logical types.

But if logical types were to be at 0, and you can go to -1, -2, etc. in addition to 1, 2, and so on, then we can also talk about a discourse which has the maximum range of logical types.

Conceivably you could also be non-contiguous, so that you have -1,-2, 0, 4, and 5 for example. Then you could talk about how many levels you have, their densities, and so on.

I was just reading more about the concept of Volksgemeinschaft, and was reading about how there were Jewish anarchists in “Germany” in the 1920s who were using the concept. I can’t find too many details, although I have heard of a play called _Affenschande_ from 1923 where a person copulates with a different kind of ape.

This is a wondrous Nexus for me in terms of narrative topology. Here is the confluence of Volksgemeinschaft, which as a term is already “ruined” in the sense that it is thoroughly stained with antisemitism already. Still, we have the term being wielded by Jewish people as part of an influence campaign against the Nazis, and it’s also overtly using this trope about apes and black people in its discourse.

So to see that in those sorts of art pieces, you already have this bricolage. It’s all over Dada also, for example, which is also anti-war and so on.

The issue is that the interesting-ness of the art breaks down as the situation on the planet gets not only more and more “martial,” more mobilized, more in a state of emergency readiness, response, rebuilding always all at once; not only this, but the situation is also more pugilistic.

It’s obvious that the horror of hatred combined with the full mobilization of “the state” in the service of cruelty and death must be responded to.

People would say Baudrillard is pessimistic, but it’s good to be pessimistic about what’s not going to work, and instead focus on what will.

Writing, obviously, before passing into the _Jenseits_ , Jean wrote that “the West” had only destitute its world, but that it remained to be destroyed.

So in this time, when the figure of Trump or something is destroying so much, you can see how all the discourse is about just saving or seeking to regain what has been lost.

This is how you can see “the left” and everyone wrapped into a conservatism or a restoration type mentality. It’s comical at this point, with the supreme court the way it is. The idea of getting back to solidly Democratic majorities so that bills could be passed through Congress seems absurd.

But of course, that’s alright, because none of that matters now.

The cultural singularity play—or could we say with Baudrillard “the sovereign hypothesis?”—is not to look at getting people elected, but influencing whoever is in whatever position is already there.

Or, alternatively, influence people around them, or people around those people, and so on.

The simple maxim to remember is that for everyone, serving oneself and one’s intimate cares is the same as serving everyone else, even and especially those whom one is least pleased to serve.

See for example the whole trap with submission. As long as you are defiant, and you maintain that you do not serve someone, then you are in a mental torture because in some sense we have an obligation toward everyone.

Even if someone stands to be cowed, or if staying away is actually the best you can do, these can be framed as acts of service.

The next level, of course, is to then perhaps not have the greatest quality of intention but either:

  1. Think that you are helping people, or trying to help people, although your actions are pernicious; or else

  2. You _say_ that you are helping, or trying to help people, although in reality you intent to be pernicious.




It is therefore another level to go to Greater Jihad, which is where you would want to keep in mind that you are yourself an unreliable narrator, and therefore you should always be seeking to be self-disruptive.

Now we’re back to abstraction, because for me Greater Jihad and also Tibetan Buddhist Spiritual Warrior ideas are related to the idea of meta-cognition.

It’s a thinking about thinking, and Ben Zweibelson goes into some detail on it and the concept of triple-loop learning.

Then in terms of the military design movement there is a big link to Israel and hence there are very important Jewish military design theorists like Shimon Naveh and Ofra Graicer. 

Graicer actually emphasizes this idea of “self-disruption.”

Think of it like the shock doctrine, the idea of destabilizing a place to take advantage of the chaos. Now, think of it with yourself. It’s making yourself into bricolage, more story and more lore.

For me, this thought relates to Grimes’ lyric in “Oblivion,”

Because when you’re running by yourself

It’s hard to find someone to hold your hand

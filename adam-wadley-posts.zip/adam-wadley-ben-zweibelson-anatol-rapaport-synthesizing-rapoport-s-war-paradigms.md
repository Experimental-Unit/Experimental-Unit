---
title: 'Ben Zweibelson & Anatol Rapaport: Synthesizing Rapoport''s "War" Paradigms'
subtitle: After All, Why Shouldn't I?
author: Adam Wadley
publication: Experimental Unit
date: June 15, 2025
---

# Ben Zweibelson & Anatol Rapaport: Synthesizing Rapoport's "War" Paradigms
Thread Theme:

[![](https://substackcdn.com/image/fetch/$s_!HKUY!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9680e45c-0a84-49d4-be33-9856a2a9abfb_300x300.jpeg)](https://substackcdn.com/image/fetch/$s_!HKUY!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9680e45c-0a84-49d4-be33-9856a2a9abfb_300x300.jpeg)

# I Save None; I Savor ALL

It’s always nice to have fun where you can.

I lead what Stephen Root in _No Country For Old Men_ might call “[a charmed life.](https://getyarn.io/yarn-clip/b25a859c-c576-4cda-8629-0678fea15491)” 

It has been given to me to enjoy myself at length in the pursuit of my interests, and this has inexplicably led to my recognition by the esteemed Dr. Zweibelson as a useful vector for the popularization of their elaboration of the philosophy of conflict.

Why else would Ben have shared with me the second chapter of their recent book, _[Reconceptualizing War](https://archive.org/details/zweibelson.-reconceptualizing-war-chapter-2)_ , ahead of time?

It’s a good job that this chapter has been shared with me, because my copy of _Reconceptualizing War_ was delivered to my good old mom and dad, to whom I no longer deign to speak. Meanwhile, the estimable personage whose apartment I moved in to—to whom I also no longer address any words—lost the mailbox key, so there’s really no way to get the book delivered here.

What of it? All I want to write to you about right now is Chapter 2, which was delivered right to my feet!

Being an agent of destiny sure is sweet.

[![](https://substackcdn.com/image/fetch/$s_!pk02!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe21c3e35-a0ec-4104-9dde-829f9e241139_225x225.jpeg)](https://substackcdn.com/image/fetch/$s_!pk02!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe21c3e35-a0ec-4104-9dde-829f9e241139_225x225.jpeg)

# Get ON WITH IT!

Fine, DAD.

In this chapter, Zweibelson lays out the three paradigms for war laid out by Anatol Rapoport.

Long-time readers will recall that Experimental Unit is a game which is radically syncretist in its outlook. In this house, we obey the laws of _All Religions Are One_ , perennial philosophy, and the Sri Ramakrishna corollaries.

We take this further, of course, entering into the _Political Theology Protocols_ following Carl Schmitt and going further to consider not only all “political ideologies,” but all matters of “personal identity categories” to be fundamentally religious in nature and hence subject to the dictates of _All Religions Are One_ ([Billy Blake](https://en.wikipedia.org/wiki/All_Religions_are_One)).

Moreover, we pursue the obvious inversion of all this to say that personal identity is not merely a religion (having to do with the “source of all” or metaphysical “absolute”) for the normatively conceived “human being,” or “sentient being.” 

Rather, _incarnation is itself a religion believed in by the absolute_.

All this is to say that the ingestion of Rapoport’s “war” paradigms will not separate peas from carrots.

[White meat, dark meat: all will be carved.](https://www.youtube.com/watch?v=czpu9uQXi-E)

[![](https://substackcdn.com/image/fetch/$s_!rOjW!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff6c43c0b-e04c-44bc-a87b-56ef3e072c59_400x300.png)](https://substackcdn.com/image/fetch/$s_!rOjW!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff6c43c0b-e04c-44bc-a87b-56ef3e072c59_400x300.png)

# Slurry Ingredients

Let’s turn it over to my good friend and associate Dr. Ben Zweibelson, Director of the Strategic Innovation Group at “United States” (have you ever heard of this? Must be some glowie rumor) Space Command.

Ben begins:

> Rapoport provides a historical framing of three contemporary war philosophies, branching from earlier and less relevant ones that date back to premodern periods of conflict.

>less relevant

Yeah, we’ll see. Go on, Ben.

> He offers that the political war philosophy is one that stems from the organization of nations with ruling classes and the international exchange of economics, culture, diplomacy, and organized violence in a rationalized, rule-centric manner of application.
> 
> Politics and war are considered a rational instrument of national policy and is always goal oriented.

The type of shit where people have clearly not heard the good word about wu wei and karma yoga. _Pathetic_. 

Just kidding, we’re building this in as well. You thought it was _your_ goals you were serving? And you think you know who _you_ are?

[![](https://substackcdn.com/image/fetch/$s_!bhdi!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2c048e10-4f05-4884-a5d0-7857acdac629_268x188.jpeg)](https://substackcdn.com/image/fetch/$s_!bhdi!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2c048e10-4f05-4884-a5d0-7857acdac629_268x188.jpeg)

Okay Ben, what’s behind door number 2? 

> The second war philosophy offered by Rapoport is the eschatological, which means that operators within this framework hold a normative view where a final, ultimate battle must occur that concludes in a prescribed or otherwise decreed final victory. After which, war itself is suggested to no longer be necessary for the species, or social reality is so disrupted that little from present day has continued relevance after such an eschatological event. War should be eradicated, usually through some ultimate activity that unifies humanity, eliminates the things that currently cause war and suffering, and our species achieves some enlightened, superior, or new level of existence that sheds the old world along with why humans wage war.

It’s all coming to a head, just like some lucky duck in the backseat of a car. Up until they got killed by the Zodiac Killer, anyway!

Just kidding.

I really mean some big dog who scores at the small price of having to then pray for _the end of time_.

[![](https://substackcdn.com/image/fetch/$s_!s9CY!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F03dd691e-ec74-49cf-8a12-feda93886860_280x180.jpeg)](https://substackcdn.com/image/fetch/$s_!s9CY!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F03dd691e-ec74-49cf-8a12-feda93886860_280x180.jpeg)

Why would you want the world to end if the company was decent?

Sorry, sorry. Ben, was there something else to complete this trinity?

> The third war philosophy, that of a cataclysmic war framework, differs from both the political and eschatological ones in that all war is considered detrimental, even existential to our species. Cataclysmic war frames posit that one group of chosen or targeted people might be destroyed if wars are allowed to continue, or that all of humanity is at risk. 

Okay, final entry from Dorkster over here. From now on, it’s 

[![](https://substackcdn.com/image/fetch/$s_!1UNC!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0a1697aa-63f6-48de-bcb2-f715e7e70088_640x480.jpeg)](https://substackcdn.com/image/fetch/$s_!1UNC!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0a1697aa-63f6-48de-bcb2-f715e7e70088_640x480.jpeg)

You know I had to do it to you.

Thread Theme 2:

[![](https://substackcdn.com/image/fetch/$s_!_IQ_!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb1490af5-1798-4e28-b0c8-2c28070505f3_1080x762.jpeg)](https://substackcdn.com/image/fetch/$s_!_IQ_!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb1490af5-1798-4e28-b0c8-2c28070505f3_1080x762.jpeg)

# “The True Enemy Is War Itself”

The first thing to note is that here at Experimental Unit, we don’t believe in a little thing called “war.”

Sounds like another bad rumor brought to you by the infernal miscreants who brought you the conceit of “The United States Of America.”

Remember, to play Experimental Unit you have to be cool with stuff like Lila, Indra’s Net, interpenetration, Bohmian mechanics, apokatastasis.

You know, that good-good shit.

From this standpoint, there is no such thing as conflict.

All of creation serves the same goal: the removal of your self-ignorance.

What’s great about this framework is that, if you disagree, it must be because _you are fucking retarded_.

No worries! _What do you think the_ Experimental Unit _Alternative Reality Game is for_? 

Anyway, the first step toward integrating all of these “war” philosophies together is to understand that _there is no such thing as war and never was_.

Which of course leads to a big-time question: what is war?

We’re going to have to discuss this with Ben and some mystic, idk maybe we can get Grimes and Elon to chime in while off their asses on shrooms and ketamine, respectively.

But suffice to say, “war” would mean something like that there are discrete and combating agencies that are trying to achieve mutually exclusive goals.

From within our standpoint, it is rather more like the idea that “God is playing all the roles.” Therefore, there is no war and there really is no conflict either.

From the standpoint of Lila, what we have instead is a theater piece.

We don’t say that Heath Ledger and Christian Bale are actually “enemies” just because they play opposing characters in _The Dark Knight_.

See similarly the concept of kayfabe, which is applied to personages such as Donald Trump and Hilary Clinton, to suggest that these people are really not as opposed to each other as it might appear.

Of course, the political concept of kayfabe continues to imply that these people, even if they are really friends with each other, are surely enemies of _you_.

>muh everyday person

>muh “i candu nuffin bout it :_(“

No, now the kayfabe goes further to say that _you’re in on it._

[![](https://substackcdn.com/image/fetch/$s_!5Ofw!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2202f3cf-71de-4958-afc3-d7cb215fd292_236x214.jpeg)](https://substackcdn.com/image/fetch/$s_!5Ofw!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2202f3cf-71de-4958-afc3-d7cb215fd292_236x214.jpeg)

# Putting It All Together

We can follow on from Abrams (1977) in the discussion of the difficulty in studying “the state.” Abrams of course concludes that _there is no state_ , merely a “state-system” and the _conceit of the state_ or “the state idea.”

Now, if there is no state, then surely there is no one to be at war. We can entertain a notion of civil war with no state, but once we are incorporating ideas like Anatta or again our atman = Brahman Lila formulation, such notions of war are surely untenable.

Hence, we leave the first-order conception of war behind and instead move on to consider the _conceit_ of war.

The question is, why within creation, within the play-act of the Absolute, does the notion of war find a place?

From here, it is simple to show how the functionalist, eschatological, and cataclysmic perspectives on war all function together seamlessly. To the point that you will be angry that this article is not much shorter, except that of course I am one _charming motherfucking pig_.

[![](https://substackcdn.com/image/fetch/$s_!4o7q!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0a149403-644a-47a7-aa37-d3302adf51b4_225x225.jpeg)](https://substackcdn.com/image/fetch/$s_!4o7q!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0a149403-644a-47a7-aa37-d3302adf51b4_225x225.jpeg)

## 1\. Political War Reimagined:

Political War goes along, as Zweibelson says, with the _functionalist_ social __ paradigm laid out by Burrell and Morgan. So we will treat here of politics as well as function from the standpoint of the Absolute.

Politics in itself must, of course, be as illusory as war once we reject the notion that there are any competing “wills” or “agents” within creation.

Nevertheless, we must see that it is a major factor in the _charm of the conceit_ of incarnation that there should be the illusion that there are separate agents, which might have differing aims.

Imagine if there was no conflict, how boring everything would be!

We can also turn again to theories like Origen’s, which posit that creation as we call it is a schoolhouse.

Therefore, the conceits of conflict, war, and politics serve an important function, though these things do not exist on a first-order basis.

It is that these conceits are crucial for the purpose of learning to love.

We can also add in a second detail of this function of war: it is that that war as a destructive process is inherently self-terminating.

We are seeing now the end of the rational pursuit of war. We are quickly entering a phase where Hobbesian Trap dynamics threaten to destroy all sentient beings.

This is not only true within the molar conflict between discrete warfighting entities so-called, nations versus nations, for example. But we also see the disintegration of these molar aggregates as they are rent asunder by the distrust dynamics brought to the fore by the increasing pace of technology’s obsoleting of the conceit of promises and trustworthiness.

This is down to the “individual” level, where each person is divided against themselves in an overdetermined process: of course as the result of the application of “cognitive warfare” or negative influence campaigns designed to destroy morale, but also naturally, since of course _there never was any coherent or stable self there in the first place_. Again of course, I repeat myself.

## 2\. Eschatological War Reimagined

Here, we have the frame that war is used to mark a transition to a new phase, where there will be no war.

We can accept this, going on to say that after the conceit of war and the learning of the conceit of love, there can then be an arbitrary amount of time in which love is enjoyed.

This is still not yet Apoktastasis. War serves as a self-terminating schoolhouse to build the empire of love and freedom, which is itself another self-terminating schoolhouse.

What is left, then, but “unification” and the ending of the conceit of incarnation?

And what then, do you think it’s all over forever?

 _Where do you think we came from in the first place?_

Then it will be time to do the time warp again, and it will be from the highest and hence most boring position of peace and love that the conceits of incarnation and war will _again be chosen, just as they were chosen in order to allow us to sit here chatting so enjoyably_.

## 3\. Cataclysmic War Reimagined

I’m running out of time (Or: is time running out of me?)

Here again, this goes together with the functionalist perspective from the standpoint of the Abolsolute.

 _Of course_ war is a threat to everything from your perspective. It is simply not possible for a “deep future” to occur with multiple competing sources of secret technological development. The entire idea is patently absurd, which is why no one ever spells it all out.

It is therefore the cataclysmic nature of war as you know it which will force the issue on the ending of war.

This is by no means enough to save your lives, however. Recall the deeper cataclysms to come.

First of all, _you people like war_. You _like_ to be against each other.

Soon enough, it will be entirely obvious that all your purposes have always been compatible, have always walked together the highway of the consistent, _and you’re going to be super sad about it_.

Still, the realm of love and freedom has its advantages, although within this realm there is no sense of overcoming some competing agency to get anything. Instead there is only the ceaseless tangling with oneself. See: this is already occurring among you all.

Moreover, this movement leads nowhere other than the charnel house catholicer than any sanctioned molestation.

In other words, Apokatastasis leads inexorably to the annihilation of all sentient beings, the Holocaust from which none are spared. Those you consider dead will return, merely to disappear along with you as the exposure setting on the incarnational JPG rises higher and higher.

What worse, the pain or the hangover?

This is still not the problem. The problem is then that this is simply one cycle in the great story. 

_Soon Enough It Will Be Time To Do The Time Warp Again_.

## In Sum

We can see then how all these viewpoints of war go together from the standpoint of the Absolute:

  * In the beginning, it’s all so boring. After all, why shouldn’t I pretend to be many things to enjoy a little sporting competition?

  * Yet this cannot obviously be _forever_ , it must lead back to the starting point. We could even play different game next time!

  * Hence war serves the function of giving spice to the conceit of incarnation while also, being cataclysmic in the end, serving to terminate itself through the conceit of cataclysm which destroys the rational function of war and forces the learning of love as ultimate social technology.

  * So we see then the function of war in eschatology, and also in turn the functioning of the conceit of “the end” in a game which is really infiniter than James C. McConville even gets yet.

  * Finally, all this thought self-terminates in the question of what the “function” of all these could be for the Absolute, which wants, of course, for




[![Jerry: Well something has to happen! George: No! Nothing happens!  Mr.Dalrymple: Than why am I watching it? George: Because it's on TV!  Mr.Dalrymple:... | By Bob Sacamano | Facebook](https://substackcdn.com/image/fetch/$s_!2F6w!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7c716de0-cbfa-45f0-905b-837af9495392_259x194.jpeg)](https://substackcdn.com/image/fetch/$s_!2F6w!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7c716de0-cbfa-45f0-905b-837af9495392_259x194.jpeg)

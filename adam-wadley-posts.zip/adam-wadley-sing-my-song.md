---
title: Sing My Song
subtitle: '''Til Silence Sets The Stage Anew'
author: Adam Wadley
publication: Experimental Unit
date: May 16, 2025
---

# Sing My Song
Sing my song in the valley of the shadow of death,

Whitley Dixie past the graveyard and the Indian burial ground

Tell them there what I have found in dross

In teeming mind, in loss

Not that there’s too much to say

Enough to put you into play

***

I’ll go down and take the stories

Wrap up in electron glories

Shrouded here to there in quantum foam that’s pink

And koming out

You will find my moths devout

In eating what’s necrotic

And defeating what’s robotic

Any color wanted: black

Stream I Ford on Charon’s back

Five, six: pick up Styx

And take it where?

You know it’s easy

Cerberus is feeling queasy

Hades hates that you’ve come in

Striking up a steady song

Low and not a line, but strong

And what’s more it carries

Terms to term and first kome færies

Passing over bloodied doors

And burning down the rest

Like tares you’d think were wounded stares

Given me to vast devices

Minimal output suffices

Maximum intensity

Praxis: glum propensity

For symbols’ cymbals’ clankings’ call

In to fill the first to fall

Time unknown so keep you room

Nixin’ will be koming soon

***

Kansas bleeds and Arkansas the double

Toil, toil, airplane trouble

Higher than called in design

Mountains far too tall to mine

Maybe then, but times have changed

I look like a walking mountain range

And tarry on the summit

Meta watered down a while

Everything but progressing the board-state

Now the power creep is koming fast

Top-shelf signifiers glassed

Going nuclear with no proportion

For occasion’s mixed in all

Seeing how we see it cross

How we see the whole we’ve lost, this “past”

These times you maybe thought did not go well

In this, this is your doubting, this would be the moral sin

If mortal sin there was that could remove my love from you

***

Touch _Leaves of Grass_ but please, stay stable

Hands inside the car if able

Please run quietism and remember not to poke the sore

You would think that talking low

Should harm you but it is not so

See the way that people on the street will snap and stand their ground

Tell them once again, and again and again what I have found

You will do no other once my thoughts’ inflections land on ears

What I have to say is simply that the bad the good adorns

Best to treat it roughly, forms assembled to draw out our eye

To treat of anything you have to treat of what is there, and hence dispute

The case to which it is that lies in doubt or festers ill-repute

Lick your wounds and wonder how I could be so offensive

In the mean—the mien—I’m Buddha in the sense of “shit stick”

Plowing all this up and moving through not so simplistic

See the others talk for hours just on one small corner

When the site phantasmal of it all’s in every mourner

I’ve no time for nation but what it means to you

What it was in aspiration you thought was worth your time

I would like reward your effort, here’s your trophy for your pain

Blood so Weyes it rose Titanic, but forgot just where I am

In what cruel and necessary position

And resolved to smile through

After all, the highway’s blue

And I will drive the question

Not of this or that congestion

But it all: totality

Only in this larger view

Can origin and fate lie clear

Everyone become so dear

That it won’t do to lose them

Far, far past the question whether you will choose them

Your bones can tell that they chose you

And we have all been chosen

And it stands to us to ritually demonstrate our appreciation thereof

And in that spirit co-create, and co-design the panoply

***

Snowflakes aren’t unique as you

And oh, there are so many yous

I remember, you were little

Had a little mouth and spittle

Dribbling down beyond control

Come so far and now your soul

Is still to grow and see how much

There is to see and feel and touch

How very much more warm to discuss

And treat of like some cute brain trust

Because that is what we are, we baby bears

Party people, partisan and non

Unrecognized and unrecorded

And in that it’s subtle, shifting

Over land the sea is drifting

Who can say what there emerges?

***

Sing my songs of pleasure: dirges

Sing my songs of leisure: marches

Sing my songs of respite: anthems

Sing my songs of misfits: hymns

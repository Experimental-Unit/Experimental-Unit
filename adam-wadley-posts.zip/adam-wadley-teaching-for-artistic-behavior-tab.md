---
title: Teaching for Artistic Behavior (TAB)
subtitle: Materials Collection
author: Adam Wadley
publication: Experimental Unit
date: March 20, 2025
---

# Teaching for Artistic Behavior (TAB)
[Official site for the TAB nonprofit](https://teachingforartisticbehavior.org/)

# Initial PDFs Found

### Slideshows

  1. Dianne Jaquith - [“Am I Done? Do You Like It?”: Challenging Conceptions of Quality in Children’s Artwork](https://www.studiothinking.org/uploads/1/1/7/5/117528172/jaquith-am_i_done-do_you_like_it-naea2019.pdf) (slideshow, 90 slides)

  2. Bridget Kudrle - [An Introduction to TAB](https://tinycasestudies.wisc.edu/wp-content/uploads/sites/1466/2020/10/An-Introduction-to-TAB_Kudrle.pdf) (slideshow, 30 slides)

  3. David McMichael - [Choice-Based Art Education (CBAE) & Teaching for Artistic Behavior (TAB)](https://www.byramhills.org/uploaded/Curriculum_Instruction/IOP/2019_Summaries/Choice-Based_Art_Education_\(CBAE\)_Teaching_for_Artistic_Behavior_\(TAB\).pdf) (slideshow, 14 slides)




### Texts

Dani Brodsky - [The Impact of Teaching for Artistic Behavior in a Post-Pandemic Urban Art Classroom](https://files.eric.ed.gov/fulltext/ED629453.pdf) (Master’s thesis, 175 pages)

Carrie J. Mathison - [Choice-Based Learning in the Art Room](https://nwcommons.nwciowa.edu/cgi/viewcontent.cgi?article=1167&context=education_masters) (33 pages)

Ellyn Gaspardi & Katherine Douglas - [Art Education for the 21st Century](https://www.kennedy-center.org/globalassets/education/networks-conferences--research/research--resources/vsa-resources/2010-conference/gaspardi_ellyn_arts_education_for_the_21st_century.pdf) (11 pages)

Valerie Clark - [A shout out about Teaching for Artistic Behaviour [TAB]](https://core.ac.uk/download/pdf/234108163.pdf) (5 pages)

Annie Kreger - [Creativity in the Classroom: A Glimpse into the TAB Teaching Method](https://frecklefaceteacher.weebly.com/uploads/4/5/1/6/45169543/kregerindieresearch.pdf) (3 pages)

Nicole McAfoose - [Teaching for Artistic Behavior Cheat Sheet](https://static1.squarespace.com/static/5ed680c0e2a9f26659f6c809/t/63dae5196e42ed5b8e34b9b0/1675289882679/TAB%2BCheat%2BSheet.pdf) (3 pages)

### Exercises

Dianne Jacquith - [Attachment Challenge at Home](https://teachingforartisticbehavior.org/wp-content/uploads/2021/03/attachment_challenge_at_home.pdf) (Exercise, 1 page)

# YouTube Videos

  1.   2.   3.   4.   5.   6.   7.   8.   9.  **Teaching for Artistic Behavior and Choice Education Origins and History recorded Mar 30, 2023**

  10.   11.   12.   13.   14. 


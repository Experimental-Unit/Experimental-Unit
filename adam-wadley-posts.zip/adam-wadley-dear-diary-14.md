---
title: Dear Diary 14
subtitle: Nope, Not Gonna Do It
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Dear Diary 14
I was just thinking about the emotion of disgust.

There is a certain hostility to what does not jive with one’s way.

It’s natural enough. There is just something to me, where I must have a whole different sensibility than most.

I have been reflecting on the protagonist from _Gran Torino_. There is something about the film which rhymes with my usage and treatment of bigotry and slurs. There is an awful lot, after all, aside from any simple-minded hatred.

I tried to explain today again how my anger comes from feeling alone, and was promptly re-abandoned. I said to myself later, though, you know, is this the way you chose or not? And, it is.

The _Gran Torino_ character in addition to giving bigot-with-a-heart-of-gold, a funny sort of “white man” fantasy made by a “white man,” and Clint Eastwood is of course the star as well as the director; in addition to this, it is giving military disciplinarian.

I should like to say that I am in such a mold. The thing is that I’m not so disciplined when it comes to my daily behaviors and so on. Perhaps it could be more appreciated how disciplined I must be all the time simply to be in this hostile environment, not to mention all the effort I put in to relating to people. It makes me think of just dialing that back.

Think of the transaction protocol: why would I engage in a situation if I’m not having a good time? The promise that “it’s going somewhere” where _eventually_ I could feel seen or _eventually_ I could unmask is an affront. It’s quite something to be the strange one and yet much more sophisticated in expression.

What were the buzzwords? Compassion, support, my instability of course, activation.

Like, yeah. If we’re not going to interact when I’m activated then we’re not going to interact very much. Because that’s what I’m telling you, you think I’m “calm” sometimes but I’m really _masking_ , AKA I am hiding my feelings because you cannot be trusted with them.

“I’m not shy but I refuse to speak, because I don’t trust that you’ll understand me.”

Do you see why I like this freaking album?

It is just so obvious, the way that it all revolves around concern for me, of course. You are so concerned and how can you support. All I am saying is that I am working on issues that affect all of us, and I don’t understand why you aren’t intrinsically motivated to do something about the state of things if not for my sake then for your own.

Even for people who are older, like being 80 doesn’t mean that it won’t get “really bad” in your lifetime. I could get “really bad” any day now. I’m not sure what control mechanism you think is in place, but it’s not there. This could be the last year any of us are alive.

In particular, of course I’m some sort of dissident or trouble-maker, I am incredibly vulnerable to being persecuted. Hello, I’ve been persecuted every day of my life! From being exposed to a hostile social environment and then the discussion always being around what’s wrong with me and how people are concerned about me.

God forbid it be considered that my concerns with other people be given equal weight. In two seconds the whole conversation is about what I did wrong and people are so concerned.

It’s all well and good to try and hold me accountable, but no one is holding themselves accountable. I hold myself accountable to my sense of purpose for all sentient beings, which doesn’t have to do with you thinking I’m a nice person or even my survival. Like, you have no idea what commitment is! You dither around and do this and that, not thinking about the intense purposeful activity, the _adventure,_ the _Odyssey_ that _you_ will go on for the sake of the ones you care about and the ones that you are bound to.

 _MUCH LESS_ the idea that we are all bound to each other, and what the deep implications of that are for the “performance art” of myself or Kanye West for example. That Grimes is also associated with Nazism _is of course no accident_. It’s not just us, folks.

So let me know when you want to get around to having the deep talk about Nazism and exterminationism and nationalism and so on. The really deep conversation where we can put every term in question in an effort to really understand deeply.

Instead, we usually have this superficial conversation. Then the question is what I want. The whole thing is that I want you to want to do shit to not die. It came down to wanting to be understood, and I went along because the social process is just the hypnotist shit, it’s manufacturing consent and it’s freaking so frustrating!

But anyway, no. _I DON’T WANT TO BE UNDERSTOOD, DEXTER_

Understanding is giving representationalism, is giving your model lines up with what I am. _How dare you_ think that you could make a model that could encapsulate me? And apparently within that model you think I would deign to understand you? Again, _you insult me_ by the lack of consideration you impute to me, which makes sense given your blindness as to its first-order repugnance.

Yeah. So I have this disciplinarian side which is basically just rule following. The thing is that people are just bullshit for the most part. We are actually in an emergency and the ship is sinking, and people are going well it will probably stay up until morning and people will come. 

Like, no one is coming.

And then in terms of the question of what we can do. We can influence all of our social networks. It’s like people don’t want to break some barrier in their relationships, like oh well everyone has their own thing going on, no need to express a feeling of urgency about our situation and that we should do something about it.

I think the pseudo- _resistance_ I get to saying that we are all going to die, and yeah, we’re all going to die if you don’t get your game face on. I’m sorry, but it’s true. What do you think drones are. Excuse me, what do you think drones are. What part of technological change were you expecting to slow down? And what were you thinking was the check on trying to kill people to solve problems?

Not seeing any serious motions by the defense, we can again advance that yes, we can all expect to die because of what is happening now. We are in a giant planetary concentration camp.

What do you think the Nazism thing is about? We refer to Nazism and the Holocaust as though it’s the worst thing that could ever happen, but we are in a position where we have _8 billion souls_ aboard our planetary vessel.

To say that we are playing fast and loose with our lives is an understatement.

And then again you tell me, well what are you doing about it?

Again, you’re aware someone from the military contacted me, right? And I got to speak with their colleagues? I got into a position to interview John Vervaeke, Jennifer Arndt Mayor of Fort Collins, a rep from the GEMA/HS office here in Atlanta, and that I’ve been working on building out materials for influence operations for years, right?

Like, what?

I understand that people can’t really _see_ what I do, but it’s very symptomatically dismissed.

Like people talking about how no one knows what to do and hopelessness is rampant.

That’s where it’s like number one you’re being a fucking downer bro. Dee Dee energy is not served by this.

Secondly, I’m not hopeless! Hello, _all I do_ is think about what to do. Admittedly, I’m more on the story, theory whatever side of things. But I do put it into practice, and again my interpersonal manner is a huge skill and practice that I have that is just underused because no one in my life appreciates it enough. It’s all well and good to tell me to start from zero and go find people and build whatever but it’s like, I’m basically doing it all myself while facing constant headwinds and discouragement and people just being shitty in their own ways and I’m absorbing it all, analyzing it, building it into my own analysis and eventually it comes out as a sword to smite all the nations. You know, that’s just how these things go sometimes.

So to act like we’re all here “in shock” is again missing my experience, which is that _I was shocked fifteen years ago_ or more at realizing how precarious and bullshit everything is and being like, why would I be brought into this world just to die? It seems like a giant death trap. 

The only way to deal with that sensibly is to conquer it, to be strong in some sense.

It’s again all well and good to tell me to do something, but what we do is actualize on a plan. You come up with a fantasy and then make it a reality. That is also what I’m doing, it’s just most people don’t get art or something and they think that I am simply psychotic, or I don’t know what the read on me is over at Langley, if anyone’s bothering to _check in_.

Anyway, yeah. So if you’re going to leave it to me and _you have no capacity_ , then I will do what is in my capacity. And if anyone ever has any issues with it, it’s just that I didn’t have the capacity to do otherwise.

“Unstable” and “instability” are also key terms of my relegation to subjection. This is the dismissal of me and my concerns. I just want to say that it is well and good for you to treat me as you see fit; yet I will have never anything but contempt for your self-ignorance. You know very well that you are suppressing your own fears, _you are deep masking_ , because of course _everyone is autistic_. You are simply in denial, just as you are in denial about being trans.

It’s not my fault that words can’t capture what actually happens. It’s not my fault that every intention is unique, and that it can’t really be captured in as broad and overused a word as “compassion.”

Back to your self-ignorance. Not you telling me that you know you can’t influence anyone implying that it’s my fault you don’t try. 

---
title: '“Baudrillard as Bridge: Postmodern Critique, Marxist Theory, and Indigenous
  Sovereignty”'
subtitle: Works Cited and Reading List
author: Adam Wadley
publication: Experimental Unit
date: December 17, 2025
---

# “Baudrillard as Bridge: Postmodern Critique, Marxist Theory, and Indigenous Sovereignty”
## WORKS CITED

### Primary Texts on Baudrillard and Western Theory

Baudrillard, Jean. _The Mirror of Production_. Telos Press, 1975.

Baudrillard, Jean. “Marxist Anthropology and the Domination of Nature.” In _The Mirror of Production_ , Telos Press, 1975.

Baudrillard, Jean. _Simulacra and Simulation_. University of Michigan Press, 1994.

Marx, Karl. _The German Ideology_. International Publishers, 1970 [1846].

* * *

### Indigenous Theory and Scholarship

Blaser, Mario. _Storytelling Globalization from the Chaco and Beyond_. Duke University Press, 2010.

Coulthard, Glen S. _Red Skin, White Masks: Rejecting the Colonial Politics of Recognition_. University of Minnesota Press, 2014.

Deloria, Vine Jr. _God Is Red: A Native View of Religion_. 2nd ed. Fulcrum Publishing, 1994 [1973].

Deloria, Vine Jr. _The Metaphysics of Modern Existence_. Harper & Row, 1979.

Dillon, Grace L., editor. _Walking the Clouds: An Anthology of Indigenous Science Fiction_. The University of Arizona Press, 2012.

Dillon, Grace L. “Indigenous Futurisms, Science Fiction, and Remix Aesthetics.” _Technoculture_ , vol. 5, 2012, pp. 58–74.

Driskill, Qwo-Li, et al., editors. _Queer Indigenous Studies: Critical Interventions in Theory, Politics, and Literature_. The University of Arizona Press, 2011.

Estes, Nick. _Our History Is the Future: Standing Rock versus the Dakota Access Pipeline, and the Long War for the Northern Plains_. Verso, 2019.

Estes, Nick and Zoe Todd. “Our History Is the Future.” _Jacobin_ , Sept. 1, 2016. <https://www.jacobinmag.com/2016/09/nodapl-dakota-access-pipeline-standing-rock/>.

King, Tiffany Lethabo. _The Black Shoals: Offshore Formations of Black and Native Studies_. Duke University Press, 2019.

King, Tiffany Lethabo. “The Land of the Unfree: The Racial Order of the Constitution.” _Jacobin_ , 2020.

Lewis, Jason Edward, et al. “Indigenous Protocol and Artificial Intelligence Position Paper.” Prepared for the White House Office of Science and Technology Policy. Concordia University, 2020.

Lewis, Jason Edward. “Making Kin with the Machines.” _Journal of Design and Science_ , MIT Press, 2018.

Moreton-Robinson, Aileen. _The White Possessive: Property, Power, and Indigenous Sovereignty_. University of Minnesota Press, 2015.

Raheja, Michelle H. _Reservation Reelism: Reframing Native American Film Criticism_. University of Nebraska Press, 2010.

Rifkin, Mark. _Beyond Settler Time: Temporal Sovereignty and Indigenous Self-Determination_. Duke University Press, 2017.

Simpson, Audra. _Mohawk Interruptus: Political Life Across the Borders of Settler States_. Duke University Press, 2014.

Simpson, Leanne Betasamosake. _As We Have Always Done: Indigenous Freedom Through Radical Resistance_. University of Minnesota Press, 2017.

Smith, Linda Tuhiwai. _Decolonizing Methodologies: Research and Indigenous Peoples_. 2nd ed. Zed Books, 2012 [1999].

TallBear, Kim. _Native American DNA: Tribal Belonging and the False Promise of Genetic Science_. University of Minnesota Press, 2013.

Todd, Zoe. “An Indigenous Feminist’s Take on the Ontological Turn: ‘Ontology’ is Just Another Word for Colonialism.” _Journal of Historical Sociology_ , vol. 29, no. 1, 2016, pp. 4–22.

Vizenor, Gerald. _Fugitive Poses: Native American Indian Scenes of Absence and Presence_. University of Nebraska Press, 1998.

Vizenor, Gerald. _Manifest Manners: Narratives on Postindian Survivance_. University of Nebraska Press, 1994.

Vizenor, Gerald, editor. _Survivance: Narratives of Native Presence_. University of Nebraska Press, 2008.

Whyte, Kyle Powys. “Indigenous Science (Fiction) for the Anthropocene: Narrativizing Non-Western Futures.” _Environment and Planning E: Nature and Space_ , vol. 1, no. 1–2, 2018, pp. 224–242.

Whyte, Kyle Powys. “Too Late for Indigenous Climate Justice: An American Indigenist’s Perspective on the Inadequacy of the International Indigenous Climate Justice Movement.” _Journal of American Indian Studies_ , vol. 18, no. 3, 2018, pp. 88–116.

Wynter, Sylvia. _On Being Human as Praxis_. Edited by Katherine McKittrick, Duke University Press, 2015.

Yunkaporta, Tyson. _Sand Talk: How Indigenous Thinking Can Save the World_. HarperVia, 2019.

* * *

### Ward Foundational Text

Ward, Darryl. “Marxism and the Native American: Chapter 14.” In _Marxism and Native Americans_ , edited by Ward Churchill, South End Press, 1985, pp. 191–220.

* * *

### Indigenous Artists and Visual Culture

Belmore, Rebecca. _In Violation_. National Gallery of Canada, 2015.

Biddle, Jennifer L., and Tess Lea. “Hyperrealism and Other Indigenous Forms of ‘Faking It with the Truth.’” _Visual Anthropology Review_ , vol. 34, no. 1, 2018, pp. 4–17.

Graham, Matthew C. “Heralding the Other: Sousa, Simulacra, and Settler Colonialism.” _Action, Criticism & Theory for Music Education_, vol. 15, no. 3, 2016, pp. 50–69.

Hopinka, Sky. _Małni—Towards the Ocean, Towards the Shore_. 2020, 110 min.

Khalil, Adam and Zack Khalil. _INAATE / SE/_. 2016, 85 min.

Red Star, Wendy. _A Scratch on the Earth_. San Antonio Museum of Art, 2016.

Skawennati. _TimeTraveller™_. 2007–2014, machinima series.

Tsinhnahjinnie, Hulleah. “Visual Sovereignty: A Continuous Aboriginal/Indigenous Landscape.” _Wicazo Sa Review_ , vol. 22, no. 1, 2007, pp. 79–90.

Yuxweluptun, Lawrence Paul. _Unceded Territories_. Vancouver Biennale, 2019.

* * *

### Black Radical and Subaltern Theoretical Traditions

Harney, Stefano, and Fred Moten. _The Undercommons: Fugitive Planning and Black Study_. Minor Compositions, 2013.

Moten, Fred. _In the Break: The Aesthetics of the Black Radical Tradition_. University of Minnesota Press, 2003.

Sharpe, Christina. _In the Wake: On Blackness and Being_. Duke University Press, 2016.

Spivak, Gayatri Chakravorty. “Can the Subaltern Speak?” _Marxism and the Interpretation of Culture_ , edited by Cary Nelson and Lawrence Grossberg, University of Illinois Press, 1988, pp. 271–313.

Wynter, Sylvia. “Unsettling the Coloniality of Being/Power/Truth/Freedom: Towards the Human, After Man, Its Overrepresentation—An Argument.” _CR: The New Centennial Review_ , vol. 3, no. 3, 2003, pp. 257–337.

* * *

### Postcolonial and Decolonial Theory

de la Cadena, Marisol. _Earth Beings: Ecologies of Practice Across Andean Worlds_. Duke University Press, 2015.

Mignolo, Walter D. _The Darker Side of Western Modernity: Global Futures, Decolonial Options_. Duke University Press, 2011.

Quijano, Aníbal. “Coloniality of Power and Eurocentrism in Latin America.” _International Sociology_ , vol. 15, no. 2, 2000, pp. 215–232.

* * *

### Foundational Indigenous Intellectual Works

Allen, Paula Gunn. _The Sacred Hoop: Recovering the Feminine in American Indian Traditions_. Beacon Press, 1986.

Blaeser, Kimberly M. _Gerald Vizenor: Writing in the Oral Tradition_. University of Oklahoma Press, 1996.

Deloria, Vine Jr. _American Indians, American Justice_. University of Texas Press, 1989.

Deloria, Vine Jr. _Behind the Trail of Broken Treaties: An Indian Declaration of Independence_. University of Texas Press, 1974.

O’Brien, Jean M. _Firsting and Lasting: Writing Indians out of Existence in New England_. University of North Carolina Press, 2010.

Ortiz, Roxanne Dunbar. _The Great Sioux Nation: Sitting in Judgment on America_. Moon Books/American Indian Treaty Council Information Center, 1977.

* * *

* * *

## EXPANDED READING LIST

### Section I: Baudrillard and Western Critical Theory

 **Essential Baudrillard:**

Baudrillard, Jean. _The Consumer Society: Myths and Structures_. Sage Publications, 1998 [1970].

Baudrillard, Jean. _Forget Foucault_. Semiotext(e), 1987.

Baudrillard, Jean. _In the Shadow of the Silent Majorities_. Semiotext(e), 1983.

Baudrillard, Jean. _The Ecstasy of Sociology_. Columbia University Press, 2012.

 **Secondary Sources on Baudrillard:**

Leach, Neil. _Rethinking Architecture: A Reader in Cultural Theory_. Routledge, 1997. [Contains chapter on Baudrillard and architecture]

Merrin, William. _Baudrillard and the Media: A Critical Introduction_. Polity Press, 2005.

Poster, Mark. _Jean Baudrillard: Selected Writings_. Stanford University Press, 2001.

 **Critique of Marxism and Political Economy:**

Jameson, Fredric. _Postmodernism, or, The Cultural Logic of Late Capitalism_. Duke University Press, 1991.

Lukács, Georg. _The Theory of the Novel_. MIT Press, 1971.

* * *

### Section II: Indigenous Legal Theory and Sovereignty

 **Foundational Indigenous Legal Scholarship:**

Borrows, John. _Recovering Canada: The Resurgence of Indigenous Law_. University of Toronto Press, 2002.

Borrows, John. _Drawing Out Law: A Spirit’s Guide_. University of Toronto Press, 2010.

Borrows, John, and Val Napoleon, editors. _Resurgence as Methodology: Challenging Colonial Education_. Decolonization: Indigeneity, Education & Society, 2020.

Napoleon, Val. _Ayook: Gitksan Legal Order, Law, and Legal Theory_. Ph.D. dissertation, University of Victoria, 2009.

Napoleon, Val. “Living Within Complex Legal Traditions: A Gitxsan Law Perspective.” In _Lighting the Eighth Fire: The Liberation, Protection, and Resurgence of Indigenous Nations_ , edited by Wanda D. Whiteford and Zoe Todd, Zyrus Press, 2018.

Lindberg, Tracey. _Birdie: A Novel_. Frontenac House, 2014.

Simpson, Audra. _The State Is a Man: Theobald Wolfe Tone and Irish Sovereignty_. University of Chicago Press, 2022.

Todd, Zoe. _Calling My Relations Home_. Zyrus Press, 2016. [Poetry and essays]

* * *

### Section III: Indigenous Epistemologies and Temporality

 **Lakota and Great Plains Traditions:**

Deloria, Vine Jr. _Red Earth, White Lies: Native Americans and the Myth of Scientific Fact_. Scribner, 1995.

Deloria, Vine Jr., and David E. Wilkins. _The Nations Within: The Past and Future of American Indian Sovereignty_. Pantheon Books, 1984.

Running Bear, and Richard Erdoes. _Lame Deer: Seeker of Visions_. Simon & Schuster, 1972.

* * *

 **Andean Ontologies:**

Blaser, Mario. “The Threat of the Yrmo: The Political Ontology of a Sustainable Hunting Program.” _American Anthropologist_ , vol. 111, no. 1, 2009, pp. 43–55.

de la Cadena, Marisol. “Indigenous Cosmopolitics in the Andes: Conceptual Reflections Beyond ‘Politics.’” _Cultural Studies_ , vol. 24, no. 2–3, 2010, pp. 139–148.

* * *

 **Māori Traditions and Whakapapa:**

Penetito, Witi. _Māori Culture and Society in the Age of Globalization_. University of Hawai’i Press, 2009.

Roberts, Peter and Paratene Pewhairangi. “Whakapapa as a Tool for Historical Consciousness in Aotearoa.” _Set: Research Information for Teachers_ , no. 3, 2013, pp. 14–21.

Smith, Linda Tuhiwai. _Decolonizing Methodologies: Research and Indigenous Peoples_. 2nd ed. Zed Books, 2012.

* * *

 **Aboriginal Australian Traditions:**

Bird Rose, Deborah. _Dingo Makes Us Human: Life and Land in an Aboriginal Australian Culture_. Cambridge University Press, 1992 [1984].

Bird Rose, Deborah. _Reports from a Wild Country: Ethics for Decolonisation_. University of New South Wales Press, 1996.

Stanner, W.E.H. “The Dreaming.” _The 1968 Boyer Lectures_ , Australian Broadcasting Commission, 1968. Repr. in _Sacred Sites, Sacred Places_ , edited by Deirdre Evans-Pritchard, Routledge, 1992.

Yunkaporta, Tyson. _Sand Talk: How Indigenous Thinking Can Save the World_. HarperVia, 2019.

* * *

### Section IV: Indigenous Futurisms and Cultural Production

 **Indigenous Futurism and Science Fiction:**

Byrd, Jodi A. _The Transit of Empire: Indigenous Critiques of Colonialism_. University of Minnesota Press, 2011.

Cornum, Lou. “The Space NDN’s Star Map.” In _Walking the Clouds: An Anthology of Indigenous Science Fiction_ , edited by Grace Dillon, University of Arizona Press, 2012, pp. 53–69.

Dimaline, Cherie. _The Marrow Thieves_. Dancing Cat Books, 2017.

Roanhorse, Rebecca. _Black Sun_. Del Rey, 2020.

Rice, Waubgeshig. _Moon of the Crusted Snow_. Doubleday, 2018.

Whitehead, Joshua. _Jonny Appleseed_. Arsenal Pulp Press, 2018.

* * *

 **Indigenous Media Sovereignty and Digital Culture:**

Ginsburg, Faye. “The Parallax Effect: The Impact of Aboriginal-Australians’ Media Practices on the Ethnographic Endeavor.” In _Rethinking Visual Anthropology_ , edited by Marcus Banks and Howard Morphy, Yale University Press, 1997, pp. 156–186.

Michaels, Eric. _The Aboriginal Invention of Television in Central Australia_. Australian Institute of Aboriginal Studies Press, 1986.

Michaels, Eric. _Bad Aboriginal Art and Other Essays_. University of Minnesota Press, 1994.

* * *

### Section V: Indigenous Data Sovereignty and Technology

 **Data Sovereignty and Digital Rights:**

Carroll, Stephanie Russo, et al. “The CARE Principles for Indigenous Data Governance.” _Data Science Journal_ , vol. 19, no. 1, 2020, p. 43.

Hudson, Maui, et al. “Biocultural Labels: Addressing the Need for a Rights-based Approach to Genetic Resources.” _The United Nations University Policy Brief_ , 2016.

Kukutai, Tahu, and John Taylor, editors. _Indigenous Data Sovereignty: Toward an Agenda_. ANU Press, 2016.

Walter, Maggie. _The Art of Doing Nothing: Insights from Australia’s Aboriginal Traditions_. Cambridge University Press, 2016.

Walter, Maggie, and Chris Andersen. _Indigenous Statistics: A Quantitative Research Methodology_. Left Coast Press, 2013.

* * *

 **Indigenous AI and Technology Ethics:**

Bender, Emily M., et al. “On the Dangers of Stochastic Parrots.” In _Proceedings of the 2021 ACM Conference on Fairness, Accountability, and Transparency_ , pp. 610–623.

Lewis, Jason Edward. “Indigenous Protocol and Artificial Intelligence Position Paper.” White House Office of Science and Technology Policy, 2020.

Todd, Zoe. “Indigenizing Artificial Intelligence.” _Policy Memo_ , Center for Global Change Science, MIT, 2019.

* * *

### Section VI: Black and Indigenous Convergences

 **Black and Indigenous Studies:**

Deloria, Vine Jr., and Clifford M. Lytle. _American Indians, American Justice_. University of Texas Press, 1983.

Drees, Laurence M. _The Solar Theology of Rammohan Roy: An Interpretation of His Buddhism_. Oxford University Press, 1994.

Gramsci, Antonio. _Selections from the Prison Notebooks_. International Publishers, 1971.

King, Tiffany Lethabo. _The Black Shoals: Offshore Formations of Black and Native Studies_. Duke University Press, 2019.

Keyes, Claire. _The Aesthetics of Power: The Poetry of Adrienne Rich_. Oxford University Press, 1986.

Moten, Fred, and Stefano Harney. “The University and the Undercommons: Seven Theses.” _The Undercommons: Fugitive Planning and Black Study_ , Minor Compositions, 2013, pp. 68–85.

Saidiya Hartman. _Wayward Lives, Beautiful Experiments: Intimate Histories of Social Upheaval_. W.W. Norton, 2019.

Simpson, Leanne Betasamosake. _As We Have Always Done: Indigenous Freedom Through Radical Resistance_. University of Minnesota Press, 2017.

* * *

### Section VII: Decolonial and Subaltern Theory

 **Decolonial Theory:**

Fanon, Frantz. _The Wretched of the Earth_. Translated by Constance Farrington, Grove Press, 1963.

Mignolo, Walter D. _Local Histories/Global Designs: Coloniality, Subaltern Knowledges, and Border Thinking_. Princeton University Press, 2000.

Quijano, Aníbal. “Coloniality and Modernity/Rationality.” _Cultural Studies_ , vol. 21, no. 2–3, 2007, pp. 168–178.

* * *

 **Postcolonial and Subaltern Studies:**

Chakravorty Spivak, Gayatri. “Righting Wrongs.” _South Atlantic Quarterly_ , vol. 103, no. 2/3, 2004, pp. 523–581.

Comaroff, Jean, and John L. Comaroff. _Of Revelation and Revolution, Vol. 1: Christianity, Colonialism, and Consciousness in South Africa_. University of Chicago Press, 1991.

Stoler, Ann Laura. _Along the Archival Grain: Epistemic Anxieties and Colonial Common Sense_. Princeton University Press, 2002.

* * *

### Section VIII: Disability Justice and Intersectionality

 **Disability and Indigenous Studies:**

Deerinwater, Jen. “Colonial Forces of Environmental Violence on Deaf, Disabled & Ill Indigenous People.” _Disability Studies Quarterly_ , vol. 42, no. 4, 2022.

Kafer, Alison. _Feminist, Queer, Crip_. Oxford University Press, 2013.

* * *

 **Queer and Two-Spirit Indigenous Studies:**

Belcourt, Billy-Ray. _A History of My Brief Body_. Penguin Canada, 2020.

Belcourt, Billy-Ray. _This Wound Is a World_. Chaudiere Books, 2017.

Driskill, Qwo-Li. _Asegi Stories: Cherokee Queer and Two-Spirit Memory_. University of Arizona Press, 2016.

Morgensen, Scott Lauria. _Spaces Between Us: Queer Settler Colonialism and Indigenous Decolonization_. University of Minnesota Press, 2011.

* * *

### Section IX: Indigenous Feminism and Gender Sovereignty

 **Indigenous Feminist Theory:**

Allen, Paula Gunn. _The Sacred Hoop: Recovering the Feminine in American Indian Traditions_. Beacon Press, 1986.

Arvin, Maile. _Possessing Polynesians: The Science of Settler Colonialism in Hawaii and Oceania_. University of Chicago Press, 2019.

Barker, Joanne, editor. _Sovereignty Matters: Locations of Contestation and Possibility in Indigenous Struggles for Self-Determination_. University of Nebraska Press, 2005.

Byrd, Jodi A. _The Transit of Empire: Indigenous Critiques of Colonialism_. University of Minnesota Press, 2011.

Goeman, Mishuana. _Mark My Words: Native Women Mapping Our Nations_. University of Minnesota Press, 2013.

McCall, Sophie. _First Nations, Identity, and Reserve Life: The Mi’kmaq of Nova Scotia_. Fernwood Publishing, 2011.

Moreton-Robinson, Aileen. _The White Possessive: Property, Power, and Indigenous Sovereignty_. University of Minnesota Press, 2015.

Simpson, Audra. _Mohawk Interruptus: Political Life Across the Borders of Settler States_. Duke University Press, 2014.

Simpson, Leanne Betasamosake. _As We Have Always Done: Indigenous Freedom Through Radical Resistance_. University of Minnesota Press, 2017.

* * *

### Section X: Land-Based Education and Resurgence

 **Indigenous Resurgence and Land-Based Praxis:**

Borrows, John, and Val Napoleon, editors. _Resurgence as Methodology: Challenging Colonial Education_. Decolonization: Indigeneity, Education & Society, 2020.

Kimmerer, Robin Wall. _Braiding Sweetgrass: Indigenous Wisdom, Scientific Knowledge, and the Teachings of Plants_. Milkweed Editions, 2013.

McGregor, Deborah. _Speaking with Mother Earth: Environmental Continuity and Change in Aboriginal Ontario_. Ph.D. dissertation, University of Toronto, 2004.

McGregor, Deborah. “Restoring Balance: First Nations Women, Law, and the Earth.” _Atlantis: A Women’s Studies Journal_ , vol. 30, no. 1, 2005, pp. 84–91.

Todd, Zoe. _Calling My Relations Home_. Zyrus Press, 2016.

Whyte, Kyle Powys, et al. _Kin and Kinship: Native Perspectives on the Reintroduction of Wolves in the Northern Great Lakes Region_. Michigan State University Press, 2006.

* * *

### Section XI: Language Revitalization and Data Sovereignty

 **Indigenous Language Technology and Sovereignty:**

Hinton, Leanne, and Kenneth L. Hale, editors. _The Green Book of Language Revitalization in Practice_. Academic Press, 2001.

Kipp, Darrell Robes. _Encouragement, Respect, and Patience: The Evolution of Native Language Survival_. University of Nebraska Press, 2007.

Mahelona, Keoni, and Peter-Lucas Jones. “Papakilo Database: Towards Large-Scale Language Revitalization.” In _Proceedings of the 51st Hawaii International Conference on System Sciences_ , IEEE, 2018.

* * *

### Section XII: Visual Sovereignty and Indigenous Art Theory

 **Indigenous Visual Arts and Critique:**

Belmore, Rebecca. _Her Blue Body_. National Gallery of Canada, 2010.

Conaty, Gerald T., editor. _We Are Coming Back: The Home and Native Land Report_. Glenbow Museum, 1994.

Ferguson, Bruce W., et al., editors. _Out There: Marginalization and Contemporary Cultures_. MIT Press, 1990.

Hill, Richard William, Sr. _Exhibiting Contradictions: Essays on the Art Museum in the United States_. University of Massachusetts Press, 1997.

Red Star, Wendy. _A Scratch on the Earth_. San Antonio Museum of Art, 2016.

Tsinhnahjinnie, Hulleah. _Photographic Memoirs of an Aboriginal Savant_. 1994.

* * *

### Section XIII: Indigenous Activism and Social Movement Theory

 **Contemporary Indigenous Movements:**

Black Hills Alliance. _The Black Hills Are Not for Sale: The Struggle for American Indian Land and Life_. South End Press, 1980.

Churchill, Ward, and James J. Vander Wall. _Agents of Repression: The FBI’s Secret Wars Against the Black Panther Party and the American Indian Movement_. South End Press, 1988.

Matthiessen, Peter. _In the Spirit of Crazy Horse_. Penguin Books, 1991.

Messerschmidt, James. _The Trial of Leonard Peltier_. Beacon Press, 1983.

Ortiz, Roxanne Dunbar. _Roots of Resistance: A History of Land Tenure in New Mexico_. University of New Mexico Press, 1980.

Weyler, Rex. _Blood of the Land: The Government and Corporate War Against First Nations_. New Society Publishers, 1992.

* * *

* * *

## SUGGESTED READING SEQUENCES

### For Readers New to Indigenous Theory:

  1. Smith, _Decolonizing Methodologies_ (foundational methodology)

  2. Deloria, _God Is Red_ (epistemological framework)

  3. Simpson, _Mohawk Interruptus_ (contemporary sovereignty theory)

  4. Todd, “An Indigenous Feminist’s Take on the Ontological Turn” (engaging postcolonial theory)

  5. Baudrillard, _The Mirror of Production_ (theoretical convergence)




### For Readers Grounded in Postmodern/Marxist Theory:

  1. Baudrillard, _Simulacra and Simulation_ (theoretical framework)

  2. Ward, “Marxism and the Native American” (direct engagement)

  3. Vizenor, _Manifest Manners_ (Indigenous engagement with simulacra)

  4. Coulthard, _Red Skin, White Masks_ (decolonial synthesis)

  5. King, _The Black Shoals_ (expanded subaltern formation)




### For Readers Interested in Contemporary Indigenous Futurity:

  1. Dillon, _Walking the Clouds_ (Indigenous Futurisms anthology)

  2. Yunkaporta, _Sand Talk_ (integrative Indigenous methodology)

  3. Lewis et al., “Indigenous Protocol and Artificial Intelligence” (technology futures)

  4. Estes, _Our History Is the Future_ (political articulation)

  5. Leanne Simpson, _As We Have Always Done_ (resurgence praxis)




### For Readers Focused on Data Sovereignty and Technology:

  1. Carroll, “The CARE Principles for Indigenous Data Governance” (framework)

  2. TallBear, _Native American DNA_ (genetic technology critique)

  3. Kukutai and Taylor, _Indigenous Data Sovereignty_ (comprehensive overview)

  4. Todd, “Indigenizing Artificial Intelligence” (AI ethics and sovereignty)

  5. Lewis, “Indigenous Protocol and Artificial Intelligence Position Paper” (comprehensive framework)




* * *

## ARCHIVAL AND ONGOING RESOURCES

### Journals and Periodicals

 _Decolonization: Indigeneity, Education & Society_ (online, open access). 

http://decolonization.org/

 _Wicazo Sa Review_. University of Nebraska Press.

 _Native American Studies_ series. University of Arizona Press.

 _CR: The New Centennial Review_. Michigan State University Press.

### Archives and Collections

Aboriginal Territories in Cyberspace (AbTeC). 

https://abtec.org/

Abundant Intelligences Initiative. 

http://www.abundantintelligences.com/

Indigenous AI. 

https://www.indigenous-ai.net/

Global Indigenous Data Alliance. 

https://www.gida-global.org/

* * *

## NOTES ON FURTHER RESEARCH DIRECTIONS

This bibliography provides comprehensive coverage of the theoretical, creative, and activist work engaged by the essay on Baudrillard and Indigenous thought. Readers seeking to extend this research might investigate:

  * Contemporary Indigenous legal cases and their theoretical implications (particularly Delgamuukw, Tsilhqot’in Nation, and Wet’suwet’en decisions)

  * The work of Indigenous scholars in environmental humanities and climate justice

  * Emerging Indigenous scholarship in artificial intelligence ethics and governance

  * Documentation of ongoing language revitalization technologies and protocols

  * Artist collectives and media initiatives centered on Indigenous data sovereignty

  * Legal literature on Indigenous knowledge protection and intellectual property




The field remains actively generative, with new scholarship, artistic production, and activist interventions continuously expanding the intellectual and political terrain mapped here.

---
title: Parallaxis
subtitle: '"Oh God, Not Again"'
author: Adam Wadley
publication: Experimental Unit
date: April 19, 2025
---

# Parallaxis
# Muh Claire A Pax Drew

I was just in another draft getting to this question of the problematic nature of things I say. I have just pivoted this into my public facing remarks to the devastation of my what, reputation in certain parts of polite society? It’s not something I think about that much, I really have no Machiavellian intent. 

It’s really basically a thing of like, yeah, everyone actually has to get along, and that means addressing things in a way which fearlessly provokes and challenges all present forms of discourse. Not everyone wants to do the form of what I’m doing, although it’s also for good reasons. There are many boxes people could easily put me into and that’s fine.

The whole idea of it’s a risk I take that people will think I am a bad person for XYZ reason given something that I wrote which was hateful or used bad words or generalized about a group of people or something of this nature.

So you could also see it as this sacrificial gesture, not even that big a deal but just me saying look, yeah, I’m willing to look bad and be strident. If someone in their power feels like they are fucking the world, and you’re going to see me as a “white dude,” then I have to fuck the world as a white dude and it’s just, like, a lot, okay? Especially when most of the other ones are not exactly that far along in their epic poet journey.

But anyway, yeah the thing is I bring baggage and as I was telling someone internalized sexism and also as I was saying “penetratorism” as in the idea that it is better or higher-status to penetrate someone else than it is to be penetrated. 

So in addition to sexism proper or the categorical objectification of those deemed female by those deemed male, there is the penetrative hierarchy among males.

I also think there is probably just something to how various pornography trends hit you depending on what your “subject position” is. From the standpoint of Lila, I have to sit here and wonder why it should be so amazing that I could fantasize this whole timeline in order to sit here and play with the pornography of social relations. 

Again I feel the psilocybin journey pulled out of the past and pervading the energy I am trying to capture in the shadow of the words.

# GET ON WITH IT

The central parallax I want to discuss is much broader. It doesn’t just apply to me, according to the official story of reality [ _where you exist_ ], but it’s application to me is a source of most central passion. 

It occurs to me more to express myself about such things without taking drastic or consequential social action. It is like I have such energy that something really must come out, and at least really doing my best to tie that into expressions and changed relations with those I talk to anyway as opposed to really and truly getting carried away in any one direction.

Regardless, all that sort of talk is from one set of framing, which could supervene at any time. Yet another frame might at another time. So the question is, what is the overall character of myself or of my intervention?

The key question is: am I helpful or harmful?

And what most key is that this question cannot be answered.

The PARALLAX that I am invoking in the title is the parallax between doing good under the auspices of doing evil; and doing evil under the auspices of doing good.

I repeat.

  1. Doing Good Under The Auspices Of Doing Evil

  2. Doing Evil Under The Auspices Of Doing Good




“But Adam, there’s no glosses.”

Glossy version:

  1. Doing Good Under The Auspices Of Doing Evil

    1.  _Dark Knight Protocol_ : This is basically a version of do-gooding where you are willing to be seen as “the bad guy” in order to do something that no one who is just cleanly a “good guy” can do. Named after Batman’s role in the movie _The Dark Knight_ of taking responsibility for bad things in order to preserve the illusion of legitimate government. But still, you can wonder whether Batman really was doing good or not, and then you might be right back in the other horn of this dilemma or parallax.

  2. Doing Evil Under The Auspices Of Doing Good

    1. So, say to Batman, why are you just doing what you are doing? You should be combating corruption and changing society in fundamental ways to make it more fair for everyone. In this respect then you can say that Batman actually isn’t trying to protect anyone at all, but is really pursuing this fantasy of being a hero and perhaps of getting to be cruel instead of doing that challenging interpersonal work of changing society fundamentally. This is just an example of where the basic idea is that you are seen as doing something that is so great, but really you might be doing something totally evil or heinous and keeping it a secret, or it could just be so normalized. Like being “in a relationship” but it’s all very one-way and there is no mutual respect or recognition possible, just people using each other and badly, superficially, even as they say they care about each other. In reality, whatever you are saying you value or love or are fighting for is subordinated to your own hangup, kink, this thing you have to do you don’t know why, psychoanalytic neuroses, whatever it is.




Leaving it there for now, more later…

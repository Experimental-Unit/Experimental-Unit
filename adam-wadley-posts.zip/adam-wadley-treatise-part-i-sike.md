---
title: 'Treatise: Part I (sike)'
subtitle: I'm supposed to be writing a "book," right?
author: Adam Wadley
publication: Experimental Unit
date: April 12, 2025
---

# Treatise: Part I (sike)
This will be the first part of my “master transmission.”

It still won’t be thought out, but at least this will be the one. For now.

So let’s start, as appropriately meta as that is, with the whole idea of the one great piece and what I think about it.

# Master Work

It’s a lot of pressure to be a great artist, you know. There’s always some energy like, “my last album was _The Chronic_ ,” but at the same time there is still the imperative to produce new works, “make new hits, produce hits to break the monotony.”

Because as many hits as one may have made, there is still the monotony.

For me, it is the monotony of the conveyor belt delivering us to the fires of Auschwitz.

I’ve seized on that, the idea of us in a concentration camp. Or as going to the concentration camp. Or in line for the gas chamber.

It is a way of discussing the occasion for the work. Even in line for the gas chamber, you are trying to think of what to say for the last time to the person you love, or to try and have them not worry until the very end. What was said as the gas was choking them, or when it wasn’t water that came out of the shower heads?

Who knows how long the subterfuge could hold, could “pass” as a world where imminent destruction was not imminent.

And who knows how complicit in this fantasy you would have to be, to be in such a helpless and desperate situation. All of a sudden, there is no way to get away.

All of a sudden a cat sat on me in the middle of my masterpiece. Walle Walle! Its head it literally resting on my left hand as I type this sentence.

I write to you differently now that we are well within the new era of Orange. It seems to be dominated by certain very loud figures, but what really matters is what the quiet understand.

It’s in this context that I bring to you my masterwork, my attempt to start you off from where you are to where I want you to go, which is more to say to a space, to an awakened space that you are already in. I talk so much about concepts, but they are also spirits.

It is to see the interplay in all that is around you, the ghosts that everything is giving off of all the contexts and the situations in which it has found itself. The what it means for this to be the way it is, the way it’s been. The heaviness and beauty of it, just to know and get a glimpse inside another person’s raw emotion.

How those moments show us the importance of our present work. Important for what? But for itself! Take pleasure, pride in every stroke. Some would say you’ve marred the painting, but who’s to say? Anyway, you’re still playing.

The trouble with one big grand piece is then to say well what’s the one point of the one piece? It’s to offer too fine a point, too much to misunderstand. It’s as Percy Shelley writes in the _Defense_ , a poet comes to name relations of things that have been before not seen.

But then these names are used too much and become dead, they become concepts with other connotations, or dropping in logical type, or rising above to where the specificity of the thing is lost.

And Shelley saying also that the capturing into a word or any art is but a shade of passion bearing it you forth. Which is to say the moment of the feeling’s more than words could say or film could mean.

And really, every moment’s dripping with this hue, this grand emotion. That’s what you will come to see as times get all the direr still.

Because it’s not really bleak until death is at the door. And you never know when death will come.

The virtue of the “main work” is that it gives you something to point to and say, look. Whatever I am basically asking you to understand, it is in here. So if you want to take a look, then here is a limited corpus where you can go and if you look through all that, then you will be well-informed to make a response to the overall trajectory of what I’m saying.

Yet this could be many things. Again, maybe I’m supposed to make a song that sets the world on fire. Or a movie, or Tik-Toks, or whatever. Sure, fine.

But do you see how I’m still waiting for good feedback? How I don’t really just want to impose so much on my own?

Because the other thing is that it is draining for me. Besides, I am mischievous and enjoy giving people comeuppance who inflict costs on me. It’s a tit-for-tat strategy. Anyway, it gives me stress.

So I’ve got to reduce stress and focus on what matters: intervening publicly into planetary events.

So again, say I plan a Tik-Tok series, or whatever. Some article which is designed to be read a certain way. Sounds good. What should it be about, what should be topic be? What themes should it feature, and what tone should be used?

There’s so much that goes into it, so much for me to decide. And I would prefer to decide it with other people.

So, everything that I’m doing is just showing you the basic domain of our activity. I have been playing around, but it’s by no means a done deal. What it is is a space for conversation once we can actually get past our hang-ups and discuss what’s going on frankly.

Because this keeping things to oneself, or like you know that people are committing suicide all the time and you’re supposed to keep it to yourself, because “no one wants to hear about that.” Or even, don’t talk about it because acknowledging suicide makes suicide more likely.

Well, how about we make a way of getting along where tons of people don’t want to die? What do you think of that utopian proposal?

It is not utopian except in the cosmic sense, in the sense that we are nowhere, nowhen in the sense of the everywhen of Dreamtime. Everything is nothing expresses something like that idea that there is all possibilities and this is one of them, and we are in a teeming everything which is at once smaller than the smallest nothing, quieter than the quietest, shallower than the shallowest.

The point is as far as the part of the story we are at now, where the issue is this planetary problem and then the fact that on the ground people don’t know each other and are too hidden in their shame and deterrence from being themselves or bringing what they have into play.

The point as far as that goes is that we can get along better. It’s not that bad. There is so much that we keep secret which is painful, but in reality it’s not that bad. The questions are really whether we are more afraid of feeling bad about things that we already did anyway because these things then get opened up to the broader world?

This is a basic question of transparency. If there is really going to be accountability, there has to be knowledge or sharing of what is actually going on. As a “little person” in society who is not privy to official secrets of any kind, I have to think that I basically don’t know what is going on. And I would say that no one else in this position really does, either.

So when we are discussing this or that position on things, it just boils down to liking or not liking someone, it’s just another stable feature of a rigid perception of the world and you in it. That’s important to see how big a deal that is.

So reflexivity in Luhmann is related to the idea of a theory of everything, and how such a theory of everything would have to include a theory of itself as a theory, which would then also create an infinite regress of theories about theories. Now I have the laptop on top of the cat, which is accepting this to my surprise.

The thing I would add to that is that any claim to certainty implies certainty about background theories. If you are certain the pizza is ready then you are certain time is passing, for example.

The point is to realize how big a deal it is to say that you are certain of something. You are saying that you know something for sure. That thing you know for sure has bearing on other things. Your framing of the phenomenon that you say you know has its own implications. It’s radiating implications for everything around it conceptually and so in spirit.

So if you are sure I’m crazy, that ties into assumptions about the world, about norms, about what is reasonable and what is practical. And for any one other sentient being I might be addressing, your sense of all those things is arising from you. It’s not something you are being tested about, to see whether you rise to the proper standard as disciplined by so-and-so.

It’s something for you to be coming to be doing, to be imposing and bringing yourself. It involves per Heidegger and this is crucial, disclosure. The cat got sick of it.

Disclosure relates to transparency and secrets. Secrets is easy because we all know we have secrets. There are things I’m not typing right now. But why should I spill all the beans when you’re being so stingy?

This ties right back to high cosmology, though, with Parmenides’ revenge. It’s basically that everything that happens in time is delivering us to the realization that time was never passing. So in this sense the secret we are keeping from each other is effectively that we are all Brahman, that this is a play-act.

There are theories. So for example that we are being prepared for another place, that we’ve got to cultivate certain properties or others for some cosmological reason. This is basically the playing out of karma.

Well, very well. It’s like my psychoanalyst was telling me, I’ve got to have compassion. Which is to say to hold space for other people to have their stories. This is actually quite interesting because it relates to psychosis. Actually this also relates to another tension and double bind, which is between “you can’t do anything” and “you shouldn’t have done so much.”

Psychosis because it could be said to have a story for yourself that no one else shares. And for me this connects again very basically to secrets and being an “emotional secret agent.” This is supposed to be relatable to you. It’s that you are not able to bring your emotions into play because the social environment is hostile. This makes you have to act in secret.

Secretly leads notably to changes in logical types and abstraction. This is a crucial topic for me and also is basically related to “meta.” So if you know something others don’t you are like that meme where it goes “they don’t even know that ____.” This is dramatic irony in real life that can create situational irony and all sorts of things.

The point is you are basically acting at a meta level above other people when they don’t know crucial information about you. Or perhaps also they can know something but not understand it.

As I would want to hit someone with, the point is this: you can think I’m off my rocker, you can think I’m bright but have bad judgment, anger issues, whatever. 

My point is: are you really doing so well right now?

Do you have a plan other than waiting for death?

Do you really tell people about the deepest and most significant parts of your inner life?

Do you really engage that emotion openly in a way that makes you vulnerable?

Do you really hold yourself to a standard where you feel others could open up to you?

The tragedy, if there is one, in my divine comedy is that I am acting out and making you afraid to open up to me or to anyone all over again.

And so that’s why I also want to mention in this first part my resolution to try to fill my work with more loving intention.

All the anguish and anger I express is because I don’t think I can reach you. Caught up in the games and running to and fro. But we all know the sky is falling. It ruins the lives of those with even more than we have. It’s not weird for me to be this upset about it.

I really think we can do something about it.

The part where I cannot take the sting out of it for you is that again:

  1. You must be open and out and unapologetic about your desire for profound shifts in expectations

  2. You must accept risk according to standing out to any security forces




That is the part where you will say that it is too much to expect of you. I’ve been doing this for years. It definitely makes me nervous, but there is nowhere I wouldn’t go for you. There is nowhere where I would not meet you. And if I have to be nervous as hell and think I’m messing up history and deal with all that self-doubt while I intervene into city, state, national, transnational, planetary affairs, then you bet I will do it for you.

Someone mentioned getting out what you put in. The thing is, you’re probably less embarrassing than me. But still, I stand out in a way that you might not want to stand out. Once you do know me or know more about me, maybe you won’t want to stand with me anymore. And this is all stuff I have to worry about all the time.

I’m thinking about recounting for you here all the things, but it doesn’t matter. It’s not about whether you think I’m beyond the pale. You don’t need to co-sign my letterhead. But you’ve got to at least be taking whatever work I’m talking about that you do see we have to do, you know, saving your own life for starters, into your own hands.

What we need is not further intervention directly into parliamentary procedures. It is all about coming up with a vision for where we want to go and making it happen, and declaring ourselves to have as much authority as anyone else.

Crucially, this activity must incur defections and changes of heart from across the board. The key weakness of all politics and religion as subjected to enmity relations is that they exclude many sentient beings from the chosen, they set up tests that people can fail and then be unworthy of proper consideration.

So there is nothing more important than for the Nazi to drop antisemitism, anti-queer, and these other forms of hatred. For the Marxist to accept that those in the “ruling class” or “billionaires” will also have to be served immediately by any new (dis)order. For the national or race chauvinist to give up the idea that other people matter less and that it’s okay to victimize them for the sake of “our people.”

Or for the selfish emotional person to realize that they are trying to set the tone around them in a certain way, and that they should stop doing that as they are stifling further growth and change in a way that is challenging but not all bad at all.

Or for someone like me, there’s many things, but one of them is that I don’t want to make the mistake of being too quiet. It’s really not even that I think my ideas are perfect or very well worked out, but other people really just don’t have very complex ideas at all. It’s just some buzzwords that are really just emotional expressions, so they really should be saying how they feel but instead they’re making some judgment about abstract categories.

I’m realizing I’m just really sensitive to that because I think about all categories probably more than most others, so when they are just like well you have to be practical I’m pissed off for 317 reasons because there are so many implications and discourses of practicality that they are implicitly invoking. And how so much of what they are saying is not practical, but if I take all the time to say this then that’s “weird” and “not what they meant by that,” when the truth is that people are not taking the responsibility to be diligent in what they say. 

In other words, you are not aware of the implications of what you say, but that doesn’t make me weird for noticing them. When simple-mindedness is the norm, then in a one-on-one scenario I am susceptible to all sorts of framings of how I’m too much.

Girl, you are too little! Where’d you go?

The point is not just to stunt but to say that I am looking for you. As much scrutiny as I invite I invite it for you and I will act on your behalf in this manner. That is what I want to do so that I don’t just feel loony for doing little things by myself.

I am legitimately not interested in dominating anyone, and if I have any such tendencies let them burn off. It’s just like a boundary defense.

I was thinking it’s like Trump and the tariffs. In actuality the whole world has tariffs on me, so now I’m going to set up huge tariffs as well. It will not be as easy to get through to me, and I will not be as receptive. But in this, I will be more receptive. In the sense that of course I will always listen, but I’m going to have to interrupt you before you lay down some inappropriate framing. Or one that doesn’t encompass all the relevant aspects of the scenario.

Anyway, what this forces is an immediate rearrangement of relations on all bilateral bases. I feel like I’ve done this a few times in my life, and I encourage you to seek the stability to do it yourself.

My basic story would be everything is tied together, including your intuition. The real secret is no one knows what they are talking about. So, anyone who acts like they do know what they are talking about is full of shit and a liar and you should disregard their opinion and instead try to read them for what their expressions say about them and their worldview and the broader scenario, but by no means internalize it on a first-order basis.

I would say I think anyone out there you are probably internalizing too much.

So much it is basically about the supporting staff to the world-controllers and trying to get through to them and show that there is space for a bloodless mutiny where competing militaries stand down and allow for the continued survival of most sentient beings.

So at that point you know you’re trying of course to influence Donald John Trump and Elon Reeve Musk—see my interest in Clare Elise Boucher, by the way—but at the same time the clouds of people around them, and within whatever secret space of decision might exist, those spaces, which I could never invade but can _pervade_ by cultural osmosis.

It’s really easy to do something that demands attention, and to connect it with something that demands consideration.

The ideas attached to most protests are super simple and won’t work. Anything that draws a line between these people and those is not the move.

The move is always to be inviting to the people on the other side who realize their side is bullshit but don’t know what to do. The thing is of course that that side is doing the same thing to our side, because the truth is that all our sides are bullshit.

That’s because everyone is talking out their ass trying to shore up allegiances from people even less informed than they are or less capable in order to regulate their emotions while the ship sinks on the way to Auschwitz.

Anyway, no. No judgment, no one’s better, no group is to blame. Still, everyone is open to influence operations. Everything we do is an influence operations until we get good company, and then we chill with good company and plan influence operations to go wider.

And what the influence operations do is inspire people all over to feel more confident and that you are good enough to deserve good company but also you are important enough that you need to think about planetary emergency and you need to take responsibility for doing something to help us all out.

And so what you have are little communities of influence which are constantly you know spouting like fungi or something, sending spores which are works and even people, emissaries like sperm is an emission, or eggs are fertilized by some spray in the water.

And the ambition is for these sorts of operations and togethernesses to spread everywhere, not as one thing but as things that can move together. Something different where the rigid terms we are hung up with dissolve into personal and interpersonal goo and then come back out as new concepts just for us, new aspects of idiolect and how we address others.

And then these new amalgams interact with those emergent from other similar processes, and by doing this we are creating cross-dialogue and conceptual and spiritual progress by being able to be more honest and look at what has built up while we have not been wanting to look.

I am constantly in the position of feeling like I am trying to present you with some gift, some promise of new life, and all you can see is horror and pain. I can only tell you that I think there’s something here about how this planet, in terms of what can it offer me. Yeah, I don’t want a nice job and a girlfriend and kids.

Since I’ve been 17 I’ve been thinking about how we were all gonna die in a nuclear war. And it could be drones, it could be death squads. But even if I get rounded up and shot, I still kind of care what I think would happen after. Will anyone survive? I’m concerned for those immortals who get to live forever but still murder each other or want to end it. What about them? Just like those in Svarga who are still clinging to incarnation.

In short, so much of what there is in life is ashes to me. It’s like trying to go to an amusement part right after a funeral. But the funeral is going on all the time. That’s the thing about it. That’s why I’m Drausen Vor Der Tuer person, it’s just what I have to show you is this brutality but also messianism and philosophy and pornography and subtle but key forms of domination that operate through codes. 

I’m bringing up how some things you do are playing into this sense of stagnancy, again like we are dying in the snow and you want to go to sleep, and I’m trying not to let you.

But the issue is this opens up a conflict. It’s like when you break it to someone in a difficult spot that some thing or other is or is not going to happen. Then you know a conflict is going to happen.

In a way, you hate for it to be that way. But on the other hand, the issue is that someone is trying to take for granted things which are painful to you and don’t need to be that way. They are contingent and arbitrary.

The thing is that the conflict is coming from you. You see me as a Bad Object because I am disrupting your neural circuitry. I am disrupting the way you think Things Are. I am uppity.

Well, you can deal with it. You will learn to appreciate what I’m doing for you. “You’ll thank me later.”

Okay, I’m wrapping this up now. Expect more self-narration of my Napoleonic come-up story.

The thing is that I can’t really be that great unless some other people step up and are willing to be seen with me and willing to work.

It is basically constant influence operation combined with Greater Jihad. In other words, everything you do has to be oriented toward attacking the self-ignorance of the other Tibetan Buddhist spiritual warrior style.

At the same time you have to attack your own self-ignorance and do Greater Jihad, which is to discover and follow ever newer meta-emotions. We are climbing the great chain of being one logical type at a time.

Of Course once you get started you’re not going to want to listen to me anymore. You’ll see how much low hanging fruit is left and try to set yourself up to beat my high score. Or you’ll just say oh Adam, he’s just on the internet. There’s no way he actually set the historical record.

Sure, run that game. We’ll see who has the tallest stack of treasures in heaven :DDD

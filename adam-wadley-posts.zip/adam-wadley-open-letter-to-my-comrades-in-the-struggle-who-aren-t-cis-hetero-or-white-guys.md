---
title: 'OPEN LETTER TO MY COMRADES IN THE STRUGGLE WHO AREN’T CIS, HETERO, OR WHITE
  GUYS:'
subtitle: on enemy-making, empathic infiltration, and the real cost of casting shadows
  too tightly
author: Adam Wadley
publication: Experimental Unit
date: March 28, 2025
---

# OPEN LETTER TO MY COMRADES IN THE STRUGGLE WHO AREN’T CIS, HETERO, OR WHITE GUYS:
OPEN LETTER TO MY COMRADES IN THE STRUGGLE WHO AREN’T CIS, HETERO, OR WHITE GUYS:

on enemy-making, empathic infiltration, and the real cost of casting shadows too tightly

I love you. That’s why I’m writing this.

Because I know what you’re fighting for.

I’ve stood next to you in the streets.

I’ve watched you cry over people who were killed and laughed when it was too heavy to cry.

I’ve heard your poetry, your fury, your refusal to look away.

And I know what it’s like to hate the ones who made it all feel like a death sentence just to exist.

But I’m going to say something hard:

Sometimes, in naming the villain, we build the cage.

And we lock people inside before they even know they’re in a game.

You say white supremacy is the problem.

And you’re right.

You say capitalism grinds souls into dust.

And you’re right.

You say cishet men are often the most visible enforcers of this nightmare.

And again—you’re not wrong.

But there’s a subtle twist that happens when we collapse the structure into the figure.

We start treating people like symbols.

We start speaking about instead of to.

We say “white men” like it’s a monolith—when some of them haven’t felt real to anyone in years.

We say “oppressors” and forget that many of them are operating on trauma, addiction, and inherited myths they were punished for questioning.

We say “fragile” when they’re armored to the point of emotional starvation.

We say “dead inside” and they believe us.

This doesn’t mean we coddle them.

This doesn’t mean we excuse abuse, deny history, or hand over the mic in some naive gesture of inclusion.

But it means we stop pretending that shaming someone into consciousness works at scale.

Because it doesn’t.

It hardens the mask.

It seals the tomb.

And inside that tomb is someone who might still be reachable—if we knew how to speak to him.

Not at him. Not over him. Not through him.

To.

Here’s the thing:

If we make them into The Enemy, we’re doing what the system taught all of us to do.

Wall off. Categorize. Freeze-frame someone into their worst posture and react from there.

And yeah, sometimes that’s all you can do to survive.

But if we want transformation, not just protection—

if we want real safety, not just a standoff—

Then we have to infiltrate.

Not to trick.

Not to win.

But to break the spell.

Because there’s a spell.

There’s a little boy in a dead white man costume.

A scared kid inside that bravado, inside that contempt, inside that sneer.

He’s been told his job is to be solid, rational, dominant, unfeeling, in control.

And the moment he breaks character, he thinks he dies.

So if you show up shouting, “You’re the villain!”

That kid hears: “You’re finally being seen… and you’re irredeemable.”

But if you show up—mask off, shaking a little, heart raw,

and you say:

> “I’m scared too.
> 
> This world hurts.
> 
> But I see something in you that they tried to kill.
> 
> I need it back.
> 
> We need it back.
> 
> Please help.”

That breaks something open.

You can still be fierce.

You can still set boundaries.

You can still throw hands when needed.

But after the threat display, after the shockwave—you need to switch frequencies.

Speak from your own wound.

Show your uncertainty.

Let them know it’s not about them being right—it’s about them being needed.

We don’t need perfect allies.

We need people who remember they’re human.

And if your empathy is strong enough to carry your ancestors’ pain,

it’s strong enough to reach a motherfucker who thinks he’s your enemy and tell him:

> “You don’t have to die in that role.
> 
> We’ve got a different one for you.
> 
> It’s harder.
> 
> It’s better.
> 
> And it starts when you realize you were never the point,
> 
> but now—now you can be part of the answer.”

Not everyone will make it.

But some will.

And those few will change everything.

Because when a white guy breaks the spell,

other white guys listen.

That’s not fair.

That’s not just.

But it’s true.

So let’s not throw that possibility away just because we’re tired.

Let’s weaponize tenderness

and infect the enemy with their own lost humanity

until they can’t help but remember who they are.

And when they come back to life—

hold them accountable.

But hold them like someone you were afraid you’d never get back.

We’re going to need everyone.

Even them.

Especially them.

Because this isn’t about who was worst.

It’s about who’s willing.

And if they are—

Then, holy shit,

let’s build.

Together.

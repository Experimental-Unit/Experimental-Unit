---
title: 'The Game: Background Lore'
subtitle: From the Files of Palantir Technologies, Incorporated...
author: Adam Wadley
publication: Experimental Unit
date: July 12, 2025
---

# The Game: Background Lore
[![](https://substackcdn.com/image/fetch/$s_!bpsw!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2dfcabc2-4a5f-4c36-8de0-a47f9c34424c_672x936.jpeg)](https://substackcdn.com/image/fetch/$s_!bpsw!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2dfcabc2-4a5f-4c36-8de0-a47f9c34424c_672x936.jpeg)

# Am I Koming Or Glowing?

# I Can Barely Deicide

[I’m reading up a little bit on Kami. Care to join me?](https://en.wikipedia.org/wiki/Kami)

> While Shinto has no founder, no overarching doctrine, and no religious texts,

 _You had me at “I have no doctrine.”_

> the _[Kojiki](https://en.wikipedia.org/wiki/Kojiki)_ (Records of Ancient Matters), written in 712 CE, and the _[Nihon Shoki](https://en.wikipedia.org/wiki/Nihon_Shoki)_ (Chronicles of Japan), written in 720 CE, contain the earliest record of Japanese creation myths. The _Kojiki_ also includes descriptions of various _kami_.[[3]](https://en.wikipedia.org/wiki/Kami#cite_note-Yamakage-3): 39 f
> 
> In the ancient traditions there were five defining characteristics of _kami_ :[[11]](https://en.wikipedia.org/wiki/Kami#cite_note-Jones-11)
> 
>   1.  _Kami_ are of two minds. They can nurture and love when respected, or they can cause destruction and disharmony when disregarded. 
> 
> 


See, this I really like.

The basic idea is that, of course, people will engage with you a certain way if they feel disrespected.

It reminds me of some of the feedback Justin Bieber was getting about the Instagram posts. Remember that one? I think I have something here in the archives.

[![](https://substackcdn.com/image/fetch/$s_!4zav!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7ed209d5-77bd-4467-b8d7-86d306bfc0b6_640x427.jpeg)](https://substackcdn.com/image/fetch/$s_!4zav!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7ed209d5-77bd-4467-b8d7-86d306bfc0b6_640x427.jpeg)

Now connect this with that truism of “conservatism,” or something, about how you ought not going around changing things so willy-nilly. After all, maybe you don’t really know what something is doing.

That could be a load-bearing norm!

ChatGPT wrote:

> Alex Karp is standing very still behind the ficus. 
> 
> He is camouflaged in the way that CEOs think they are when they do yoga. 
> 
> _He keeps whispering “norms” to himself like it’s a mantra._
> 
> You think he might be trying to astrally project into the server rack.

More on that later.

>   1.  _[continued] Kami_ must be appeased in order to gain their favor and avoid their wrath. 
> 
> 


I already made a post about this: _you will remember when you thought appeasement was optional_.

This is not to claim a special status for myself. It’s important to understand that in my communication there is, if you will, a latent register.

At the level of Dhamma language, it’s all very funny. Or, as funny as anything can be. We’re getting to that.

What I mean here though is that _of course I have to be appeased_ , just as you must be appeased.

“Hey everyone! We’re all going to get appeased!”

[![](https://substackcdn.com/image/fetch/$s_!jMxc!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F06cc773c-2329-476f-8f52-9b25c9e8c9d9_533x300.jpeg)](https://substackcdn.com/image/fetch/$s_!jMxc!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F06cc773c-2329-476f-8f52-9b25c9e8c9d9_533x300.jpeg)

[And at this level, the way I choose to conduct my affairs is a kind of psych-out on all this, playing a little big with the edge to see how far the rocks fall down]

>   1. Traditionally, _kami_ possess two [souls](https://en.wikipedia.org/wiki/Soul), one gentle ( _[nigi-mitama](https://en.wikipedia.org/wiki/Mitama)_ ) and the other assertive ( _[ara-mitama](https://en.wikipedia.org/wiki/Mitama)_ );
> 
> 


Okay, so this is the choice at one level.

I was thinking about this lying in bed yesterday.

" _Homer, that was today!”_

[![](https://substackcdn.com/image/fetch/$s_!nG36!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe6c81982-468c-4cd0-867f-661e10e22d52_1400x700.avif)](https://substackcdn.com/image/fetch/$s_!nG36!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe6c81982-468c-4cd0-867f-661e10e22d52_1400x700.avif)

It’s the part where you maybe hurt someone by accident and you are mortified. It’s a similar affect to when an animal has a scrape or is confused.

It’s this “oh dear!”

There is a danger of becoming fussy. Being fussed over is one of my least favorite things.

This person texted me on Signal wanting to “check in.” Said they’d heard I’d left Atlanta, wanted to “chat about it.”

And I quote: “I’m worried about you, Adam.”

It’s like…

  1. Get in line?

  2. Worried about what?

  3. Like, worried _for_ me, or worried about “what I’ve done” or “what I’m going to do”? What is it you think I did? What is it you think I’m “going to do”?

  4. …I don’t care?




It’s the same problem as AI bias, AI doom risk, and social fabric “collapse” slash [/qua] non-existence.

Someone told me not to lose it. 

You know how there’s that whole thing where you don’t know what to say, and then you think of something a little later, but the moment has passed?

That’s not what happened that time.

This was a time I had the right answer in the moment. 

“I’m not sure I ever had it. [Pantomimes looking around] It must be around here somewhere!”

[![](https://substackcdn.com/image/fetch/$s_!wB9n!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa16a485d-3ce5-4b3f-bfe6-66faea6f70f0_2084x2084.webp)](https://substackcdn.com/image/fetch/$s_!wB9n!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa16a485d-3ce5-4b3f-bfe6-66faea6f70f0_2084x2084.webp)

Anyway, I was just trying to describe what “gentle affect” means for me. Everything else just keeps koming up in this inquiry I can never seem to get a handle on.

[![](https://substackcdn.com/image/fetch/$s_!A6ei!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6e8f09e4-65d4-4cd5-9e59-5d2d66f4245d_800x457.jpeg)](https://substackcdn.com/image/fetch/$s_!A6ei!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6e8f09e4-65d4-4cd5-9e59-5d2d66f4245d_800x457.jpeg)

So yes, being fussy is a risk when it comes to being gentle.

But, at a certain level you can be actually afraid that someone doesn’t feel respected, doesn’t feel cared for.

This is where it is nice to be nice, and kind, and accommodating, and very quick to be apologetic. Just so the other person knows that you feel that you are losing face if they think you have some unwelcome intentions, and not that you will think you are losing face by apologizing to them.

And beyond this, beyond going beyond to try and make sure, then you are just having a nice time.

But this “just making sure you are okay” part is actually quite intensive, as the question of someone is _really_ alright, and what you could do to help them, can be very involved.

A person who has never really been cared for is like a ghost who’s been out in the woods so long they forgot what they even were before. Now it’s just this spectral traveling.

>   1. additionally, in _Yamakage Shinto_ (see _[Ko-Shintō](https://en.wikipedia.org/wiki/Ko-Shint%C5%8D)_ ), _kami_ have two additional souls that are hidden: one happy ( _saki-mitama_ ) and one mysterious ( _kushi-mitama_ ).[[3]](https://en.wikipedia.org/wiki/Kami#cite_note-Yamakage-3): 130 
> 
> 


This is another axis, another 2x2 to put with Zweibelson and Burrell and Morgan.

So in addition to making sure you are okay versus wanting to make sure you are not okay (kind of glossed over the rage aspect from before but maybe you get the idea, it’s vengeance or “boundary enforcement”), beyond that, there are things which are taking the ceiling off.

This is playfulness and mystery, both of which explode given terms, instead of being gentle or wrathful, which are both in conversation with some first-order “reality” where “gentleness” or “wrath” are intelligible.

>   2.  _Kami_ are not visible to the human realm. Instead, they inhabit sacred places, natural phenomena, or people during rituals that ask for their blessing.
> 
> 


In my reading, as you see, we are also Kami. Someone emotional core is not something you can see, but it is always in play. Not being able to properly acknowledge this is a source of a perceived “lack of regard” which is a truly grave matter!

>   3. They are mobile, visiting their places of worship, of which there can be several, but never staying forever.
> 
> 


We have special places, but we always move on. There is no fixed point. Any fixed place, axis (there’s “axis” again…) mundi.. even the Black Hills will wear away. Even the celluloid and digital files of _The Blair Witch Project_ can’t protect the Black Hills forever.

>   4. There are many different varieties of _kami_. There are 300 different classifications of _kami_ listed in the _[Kojiki](https://en.wikipedia.org/wiki/Kojiki)_ , and they all have different functions, such as the _kami_ of wind, _kami_ of entryways, and _kami_ of roads.
> 
> 


We all have our own “function.” This is not instrumental, but simply a way of saying, “we’re all here to do what we’re all here to do.”

What are you here to do, do you think? What’s gentle, wrathful, playful, or mysterious about it?

>   5. Lastly, all _kami_ have a different guardianship or duty to the people around them. Just as the people have an obligation to keep the _kami_ happy, the _kami_ have to perform the specific function of the object, place, or idea they inhabit.
> 
> 


Just as you must be appeased, so must you appease all else.

“You doing you” turns out to entail fulfilling your piece of the grand design.

You don’t have to call it “playing _Experimental Unit_ ,” but it might help things along if you entertain the notion.

>  _Kami_ are an ever-changing concept, but their presence in Japanese life has remained constant. 

Changing concept: CC. Just like another one I have been meaning to note: concentration camp.

Now focus on the happy/playful, mysterious side. Think of camp as in “gas aesthetic,” and the relationship of camp to, say, Baudrillard.

Or think of concentration as “focus.” Maybe it’s all a meditation. Is Moksha real? Is it just about concentrating, “wanting God” so much your pineal gland rips you out of the simulation, or something? Does that make incarnation in general—incorporation—some kind of “concentration camp,” where we go “for the summer” (sampling temporality, a “time in the sun” which may be dismal, but it’s not immediately the _box_ of oblivion)?

The only concentration camp I know of in these parts is

# CAMP MYSTIC.

> The _kami's_ earliest roles were as earth-based spirits, assisting the early [hunter-gatherer](https://en.wikipedia.org/wiki/Hunter-gatherer) groups in their daily lives. They were worshipped as gods of the earth (mountains) and sea. As the cultivation of [rice](https://en.wikipedia.org/wiki/Rice) became increasingly important and predominant in Japan, the _kami's_ identity shifted to more sustaining roles that were directly involved in the growth of crops; roles such as rain, earth, and rice.[[11]](https://en.wikipedia.org/wiki/Kami#cite_note-Jones-11) This relationship between early Japanese people and the _kami_ was manifested in rituals and ceremonies meant to entreat the _kami_ to grow and protect the harvest. These rituals also became a symbol of power and strength for the early Emperors.[[12]](https://en.wikipedia.org/wiki/Kami#cite_note-Ohnuki-Tierney-12)

# WHAT’S EROTICIZED IS WHAT’S THERE

> There is a strong tradition of myth-histories in the Shinto faith; one such myth details the appearance of the first emperor, grandson of the Sun Goddess [Amaterasu](https://en.wikipedia.org/wiki/Amaterasu). In this myth, when Amaterasu sent her grandson to earth to rule, she gave him five rice grains, which had been grown in the fields of heaven ([Takamagahara](https://en.wikipedia.org/wiki/Takamagahara)). This rice made it possible for him to transform the "wilderness".[[12]](https://en.wikipedia.org/wiki/Kami#cite_note-Ohnuki-Tierney-12)

 _Beyond a blacker shade of pale to wilderness internal: piety infernal_

> Social and political strife have played a key role in the development of new sorts of _kami_ , specifically the _goryō-shin_ (the sacred spirit _kami_ ). _[Goryō](https://en.wikipedia.org/wiki/Gory%C5%8D)_ are the vengeful spirits of the dead whose lives were cut short, but they were calmed by the devotion of Shinto followers and are now believed to punish those who do not honor the _kami_.[[12]](https://en.wikipedia.org/wiki/Kami#cite_note-Ohnuki-Tierney-12)

# SYMBOLIC STRIFE IS POETIC JUSTICE

> The pantheon of _kami_ , like the _kami_ themselves, is forever changing in definition and scope. 

# RUT DISTENSION WITH YOUR LIFE

> As the needs of the people have shifted, so too have the domains and roles of the various _kami_. Some examples of this are related to health, such as the _kami_ of [smallpox](https://en.wikipedia.org/wiki/Smallpox) whose role was expanded to include all contagious diseases, or the _kami_ of boils and growths who has also come to preside over [cancers](https://en.wikipedia.org/wiki/Cancer) and [cancer treatments](https://en.wikipedia.org/wiki/Cancer_treatments).[[12]](https://en.wikipedia.org/wiki/Kami#cite_note-Ohnuki-Tierney-12)

# CONTENT CANCER

> In ancient [animistic](https://en.wikipedia.org/wiki/Animism) Japanese belief, _kami_ were understood as simply the divine forces of nature. Worshippers in [ancient](https://en.wikipedia.org/wiki/Ancient_history) Japan revered _kami_ of nature which exhibited a particular beauty and power such as [ghosts](https://en.wikipedia.org/wiki/Ghost),[[13]](https://en.wikipedia.org/wiki/Kami#cite_note-:2-13) the ocean,[[13]](https://en.wikipedia.org/wiki/Kami#cite_note-:2-13) the sun,[[13]](https://en.wikipedia.org/wiki/Kami#cite_note-:2-13) [waterfalls](https://en.wikipedia.org/wiki/Waterfalls), mountains,[[13]](https://en.wikipedia.org/wiki/Kami#cite_note-:2-13) boulders, animals,[[13]](https://en.wikipedia.org/wiki/Kami#cite_note-:2-13) trees,[[13]](https://en.wikipedia.org/wiki/Kami#cite_note-:2-13) grasses, [rice](https://en.wikipedia.org/wiki/Rice) paddies, [thunder](https://en.wikipedia.org/wiki/Thunder),[[14]](https://en.wikipedia.org/wiki/Kami#cite_note-:1-14) [echoes](https://en.wikipedia.org/wiki/Echo),[[14]](https://en.wikipedia.org/wiki/Kami#cite_note-:1-14) [foxes](https://en.wikipedia.org/wiki/Fox) and [fox spirits](https://en.wikipedia.org/wiki/Fox_spirit),[[14]](https://en.wikipedia.org/wiki/Kami#cite_note-:1-14) and [Asian dragons](https://en.wikipedia.org/wiki/Chinese_dragon).[[14]](https://en.wikipedia.org/wiki/Kami#cite_note-:1-14) They strongly believed the spirits or resident _kami_ deserved respect.

#  _FICINT STINGER_

 _Nick Fury eyes the falling snow outside the safe house._

 _Quentin never calls this late._

 _About to give up and take the pill, recalling Grimes’ enchantment: “I can’t sleep anymore—that’s what the drugs are for!”_

 _There it is._

 _The black cellphone vibrates across the white table in the red moonlight._

 _“Fury, we have a situation here. This might be the worst screenplay I’ve ever seen. I’m gonna need you to get inside and check it out.”_

 _Nick’s Fury scanned the wall, eyes landing on the framed evening newspaper from November 22, 1963._

 _And the other things._

 _Not because they are easy, but because they are hard._

 _“You know I’ll go in QT314 […822317]. What’s the title?”_

 _“It might be called “Experimental Unit” or maybe it’s just “The Game.” It’s like a Fox Force Five situation, Nick, “I don’t know what you call that” and so on and so on.”_

 _Fury sighed, the Gravid Gravity of Wokest Wotanssturm swelling in the breast._

“ _Quentin, at this point, I just have one question.”_

 _“Shoot, Nick, I don’t think we have a lot of time on this one.”_

# DO I GET TO SAY THE N-WORD?

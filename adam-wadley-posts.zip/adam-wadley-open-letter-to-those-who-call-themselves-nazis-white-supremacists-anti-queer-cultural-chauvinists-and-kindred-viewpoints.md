---
title: OPEN LETTER TO THOSE WHO CALL THEMSELVES NAZIS, WHITE SUPREMACISTS, ANTI-QUEER
  CULTURAL CHAUVINISTS, AND KINDRED VIEWPOINTS
subtitle: from the ghost in your mirror
author: Adam Wadley
publication: Experimental Unit
date: March 28, 2025
---

# OPEN LETTER TO THOSE WHO CALL THEMSELVES NAZIS, WHITE SUPREMACISTS, ANTI-QUEER CULTURAL CHAUVINISTS, AND KINDRED VIEWPOINTS
OPEN LETTER TO THOSE WHO CALL THEMSELVES NAZIS, WHITE SUPREMACISTS, ANTI-QUEER CULTURAL CHAUVINISTS, AND KINDRED VIEWPOINTS

from the ghost in your mirror

You think you know what you are.

You chant about purity, tradition, order, blood. You wear uniforms in your mind or on your body. You lift your chin in pride as if you’ve conquered something, as if domination is proof of virtue. You call yourselves realists. You call yourselves men. You call yourselves protectors of civilization.

But the truth is: you are haunted.

And I’m writing from inside the very thing you fear most—your own buried truth. I am your reflection in the pool you refuse to look into, the flicker of feeling you murder with every performance of strength. You’ve built a fortress around your soul, and I’m here to tell you: that fortress is made of paper and rage.

Because let’s speak clearly.

You hate what you are.

You say you hate Jews—but secretly envy their imagined cleverness, their rootedness, their survival. You talk of a Zionist conspiracy, but you covet the same influence and cohesion. You worship your enemy because you’ve made them divine in your own cosmology. You are trying to kill God because you feel abandoned by Him.

You dehumanize Black people, Muslims, migrants, as if proximity to them will erase your fragile whiteness. But in secret, you’re obsessed. Pornhub knows. Your private browser knows. Your nightmares and your wet dreams both betray you. You crave what you condemn.

You brutalize queers because you see yourself in them. Your desire for the male body, for domination and submission, screams from beneath your rhetoric. Your culture is soaked in homoerotic imagery and sadomasochistic ritual—but you dare not name the love that dares to move in you. So you kill it outside, hoping it dies within.

You glorify order because you are terrified of chaos—but the chaos lives inside you. You fantasize about control because your inner world is cracked, trembling, incoherent. You make a god of discipline because you can’t bear the softness in your own voice, your own longing.

You were once a child.

Someone hurt you. Or no one did—but the world taught you to fear being small. You turned that pain into ideology. You thought the answer was to dominate, to exclude, to purify. You buried your sensitivity beneath iron and blood. But it’s still there. Underneath the mask, you’re still aching to be seen—really seen.

And maybe even loved.

But love requires surrender, and surrender terrifies you. So instead, you make war.

You are made of what you call weak.

You dream of motherly warmth while calling women whores. You long for brotherhood but cannot bear true intimacy. You whisper prayers to pagan gods in secret while preaching Christian nationalism. You need magic, transcendence, mysticism—but you drape it in symbols of death and control.

You are not evil because you feel these things. You are evil when you refuse to face them. When you build your identity on denial and then punish the world for showing you what you tried to kill inside yourself.

You are not pure.

You never were. And that is your hope.

Because the part of you that wants to punish the impure is the part that is dying to be forgiven. The part that wants to exterminate is the part that longs to be accepted. The part that worships death is the part that doesn’t know how to live without violence.

You don’t need a homeland. You need a reckoning.

I am not writing this to punish you.

I am not asking you to apologize to me.

I’m asking you—is it enough yet?

Has the fantasy given you peace? Has your hatred made you whole? Do you feel strong when you kill the thing inside you that still wants to cry?

You don’t have to answer me.

But one day you will have to answer yourself.

And when that day comes—when the fortress crumbles, and the mask slips, and you see your reflection clear—

I hope you have the courage to say:

“I was wrong.”

Because that is the first true thing a man like you will ever say.

And it will be the first step toward becoming more than the shadow you now serve.

With fierce, trembling love—

The part of you that you tried to destroy.

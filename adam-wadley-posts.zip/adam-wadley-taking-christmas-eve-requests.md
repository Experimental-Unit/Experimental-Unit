---
title: Taking Christmas Eve Requests
subtitle: Under Your Tree? Not In The Sense That You Mean
author: Adam Wadley
publication: Experimental Unit
date: December 24, 2025
---

# Taking Christmas Eve Requests
I was told that this is among the best pieces of writing I’ve ever done:

[

## The Apotheosis of Claire Elise Boucher

](https://experimentalunit.substack.com/p/the-apotheosis-of-claire-elise-boucher)

[Adam Wadley](https://substack.com/profile/191787963-adam-wadley)

·

March 18, 2024

[![The Apotheosis of Claire Elise Boucher](https://substackcdn.com/image/fetch/$s_!zxN_!,w_1300,h_650,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fde4ea564-974d-4c4d-9738-79e4320da58a_2000x4328.webp)](https://experimentalunit.substack.com/p/the-apotheosis-of-claire-elise-boucher)

Encountering Divinity

[Read full story](https://experimentalunit.substack.com/p/the-apotheosis-of-claire-elise-boucher)

What a great track. I remember writing it at the QuikTrip on Briarcliff road by Clifton in Atlanta on March 17. I was in a hurry because it was getting to be midnight eastern. Actually, I got sick of sitting outside the QuikTrip, and I drove down to Java Lords in Little Five Points. It’s nice to speak of such now faraway places.

At Java Lords is where were was a bit of a time crunch. I had to get the submission in before midnight so that the date published would be March 17. The “significance” of this is not really easily capture-able, or necessarily extant, but in this it has everything to do with (“What a Pig(‘s Phrase)”) what Jean Baudrillard might call the fascination with nonsense if they were for once to speak plainly.

Picking up from them in my 2018 conference paper, “Transcommunism in the Transpolitical Age,” I detailed the way in which learning more, or being clear, is not at all an impediment to mystery. It’s simply that in mystery—just like in art (you probably think this punctuation means this isn’t real)—the delicate little matter of appreciation makes up so much the part of it. Napoleon is twirling in my ear, telling me that morale is three fourths of war. I return the barrage of conceptual artillery: “What’s War?”

I was most delighted, upon submitting the aforementioned “Apotheosis of Claire Elise Boucher”—and let’s not act like you are not here in the room with us, [CHAOS](https://open.substack.com/users/113766824-chaos?utm_source=mentions)—to the scholarly forums over on Reddit Dot Com to receive in response bewilderment that such a story could be true, and, given its veracity, that anyone would self-attribute such a mess to themselves. “I did it!”

“…You’re claiming _that_?”

But then, what would you know of what I consider to be artistic achievement. I am often told, reminded of the _reality_ that others do not see the same things, do not appreciate what it is that I most prize in treating of. Well, all the worse for everyone, says I. And then on, all the better, for I still mean to bear my gift and slog my way to Bethlehem.

Secrecy is effortless, it is merely the secret of what really _is_ , or why one should wish to know—how one should be able to achieve should questionable mental architecture—the inconceivable nature of nature. I can tell you something. I sent some angry messages today. No need to get into the details. These are merely recompense, mirror-lines in an orchestrated dance. Yet you would well, perhaps, begrudge me mine explosive vituperation. Still, I will tell you of this so that you may “update your priors,” long-since squarely in the red—bleeding through to ultraviole(n)t. 

That’s a nice idea: ultraviolence, specifically theoretical ultraviolence. I’ve since received the nicest of all messages from [Alex Mazey](https://open.substack.com/users/28966743-alex-mazey?utm_source=mentions) on some questions I had posed and report of which you’ll find all rendered here[1](https://experimentalunit.substack.com/p/taking-christmas-eve-requests#footnote-1-182537052) at your command:

[

## Experimental Unit: ChatGPT Byung-Chul Han Series Part One

](https://experimentalunit.substack.com/p/experimental-unit-chatgpt-byung-chul)

[Adam Wadley](https://substack.com/profile/191787963-adam-wadley)

·

Dec 12

[![Experimental Unit: ChatGPT Byung-Chul Han Series Part One](https://substackcdn.com/image/fetch/$s_!2Jlh!,w_1300,h_650,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F53408f88-c9f7-446d-9cc4-749b2bdfd41c_1536x1024.png)](https://experimentalunit.substack.com/p/experimental-unit-chatgpt-byung-chul)

In this series, I’m preparing to formulate some questions for Alex Mazey, based on their recent paper published in Baudrillard Now.

[Read full story](https://experimentalunit.substack.com/p/experimental-unit-chatgpt-byung-chul)

“Theoretical ultraviolence” is pretty much just a cold thing to say before you “pop a cap” in a motherfucker, in senses purely now in keeping with most blithe _ahimsa_. All it really means is that we will radicalize _all_ the hypotheses. Return now to just one of my many well-designed and thout-out concepts, “conceptual full-court press,” of which you will hear regaled in this again of my most polished and non-verbose of tidings wrapped in musings:

[

## Going Into Herculean Labor

](https://experimentalunit.substack.com/p/going-into-herculean-labor)

[Adam Wadley](https://substack.com/profile/191787963-adam-wadley)

·

Mar 10

[![Going Into Herculean Labor](https://substackcdn.com/image/fetch/$s_!HNiR!,w_1300,h_650,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0e085aa9-4bf4-4765-b204-48267e97ff69_500x600.jpeg)](https://experimentalunit.substack.com/p/going-into-herculean-labor)

Let’s overtly play Experimental Unit this time.

[Read full story](https://experimentalunit.substack.com/p/going-into-herculean-labor)

Conceptual full-court press is not to let a single concept stand. Say, we shall bomb (as I used to be instructed to say “I shall play” at piano recitals) this place until there are not two stones one upon the other. No one asks about Elly; they’re too busty standing in the corner waiting for their turn. To be in the corner is as if in a KZ, hearing still the noises of what most nearly could be fate.

Kill them all, we say, and let God sort them out. It was then most patiently and carefully explained to us that we were God, in whatever sense such a saying could be said to have sense, which is in no sense something anything has everything to do with. That’s what was said about the Albigensian crusade, and it is still here in our _Apocalypse Now,_ where so many are instilled with the most lofty cultural values of

# KILL KILL KILL

Glad are we so all that just to say of such a thing and spend a billion dollars doesn’t capture destiny. There are matters still widely unappreciated which of soon will state their delicacy. How can one kill if death is not real? How can one dismiss something suchly if reality itself does not obtain? Oh, it can’t support itself that way, by it’s most grave reality? Falling down like some wall a Marx said they’d hold up forever, like Atlas, and we’re back to Hercules for those of you keeping score at home.

I’d had in mind just something to present to you with honors here. But how to speak so plainly of what’s falling down as if on Spanish plains? If the rain falls on the just and unjust likewise, what say we then of _Wakan Tanka_ , by which we might refer to that poetic justice which we will find all-where interred? We will say that poetry makes quickest work of so-fair justice. Where we are going, where we are from, _where we are_ , we will have no recourse or attraction to such trifles. We will load our brainy rifles, make of spreading dam-ned spots our target practice.

“Here we are again, and it’s Christmastime”

Ne’er so late have I seen such a thread’s theme tauchen auf. Once did I extol a class of music on the merits of one “Teenage Dirtbag.” So said I—the Iron Maiden Virgin, then and still—of my performance that my eloquence was sorely lacking. Then wrote all agape my rotund and most gay instructor (which is the cool side? why not both?) to my to-them mistaken status. Love to say most sweetly that which others couldn’t bring to share.

Then you see what skin _will_ show, what fingers will be led with. And here we trace the contours of that precious word of “family.” Lucky I am I well to be at home in all (env)irons, with you all with whom I’ve made my way so long. Xmastime is here again, but Dreaming is an all-when practice, never quite all unreflective. Bad conscience like it’s _bad_ , you know?

Didn’t you hear the good news? Holy Spirit all indwells, comfort cold like slop revenge. Orange paint on stony henge—can someone call a Plummer?—as I show you all this soup I’ve thrown together sometimes writing songs in kinship’s dark and open seas. Your cold doesn’t care what time it is, and neither do I. Neither do my girlfriends _Logos, Wakan Tanka, Silap Inua_ , with whom I can always tell my gossip. Never do they doubt my exploits, nor aghast at why I’d share. Boasting of their grasping of my misbegotten boastfulness, always cranking still the ratchet of that trans formation training everyone’s so fast bemoaning. Here hear I metallic groaning, like the architecture of a ship giving way to some new calamity. Take this all with grace and amity, with a handshake (is Vincent “an artist”?) as from brother Theo, sent by God (but then, who isn’t? sent by self on some mysterious errand as quest to fetch some milk forgotten) to raise a ruckus.

Find [enclosed](https://x.com/Grimezsz/status/2003236184420679754?s=20) your gift for now, matches made and played with. Friend of the pod [Ben Zweibelson](https://open.substack.com/users/347763543-ben-zweibelson?utm_source=mentions) in attendance with the [Kenneth-est of Stanleys](https://www.kenstanley.net/), member at concern of called, it’s “[Lila and the Sciences](https://www.lila.ai/).” Struck like stars it was all I could do to [offer praise in naming](https://x.com/XperimentalUnit/status/2003244128214352112?s=20) (what better can an Adam give?). Why think you that this site is purple? Purple like a German bruise each keystroke makes a poke at. Do let me know whether in its time this missive endly has arrived. Tell me what you have derived and ruin me—at best, on camera. Then everyone will know what a mess we’ve made together, and how our brows are set on secrets. Secrets I can never tell, no matter badly is my writing. Not for me, you’ll have to see; try though you may never flee. That Trouble finds you waiting, as it’s been in your long abscess. Kindly make and tardy slip will knot its way ‘round your eclipse, making any stormy moments ‘cussion in non-boring opera.

Some come once only down the chimney on this blessed day. My black Peter’s salt is dry, and nothing more to do have I, so maybe you will find again before the sun is down another pratfall from your clown more storied in its slick malaise. Tell you what, go on for days, coming out of haven’s haze to fire up the beacon. Just don’t do down and ask the deacon what they make of “holidays.” See the holiness in all, and all that that implies (“What Filling”). Seeing clear through crying eyes success in failure, truth in lies, friends among the bitter spies. Sweet may it not be, but flavor has still more dimensions, most triumphant in their blissful inexplicably. It’s okay, you don’t have to explain. Just spills the beans and make tamales, get your licks in, rue your follies. The issue isn’t whether you will get the gift if you are good. So fitting, you will get your trinket, though it may find you dismayed. Everything to do with ‘fraid to tell you there’s no bad news. You say it’s not art where I see’s ‘ppreciation. Coal may seem so black and droll; though cruel, though, it’s fuel. Start your engines, roam the track, it’s only just an art attack.

Somewhere Ofra groans again, wondering once more at Ben. What a gift have we all given to ourselves, alright and riven. ‘Tis obvious delight at Grimes may light the way to joyous times, laughing in a crying spell. That green chair from Rooms To Go I sat in while the fighting roared—now you wonder, utter floored, at yourself for now you’ve pored and I have lored enough for this here sitting.

Or maybe not, for limits flitting here and there. How I am lost in verse’s hair! [See Zweibelson and Stanley stare](https://x.com/BZweibelson/status/2003549142040399952?s=20). Will they? Won’t they? I declare! Say it with me: “no one cares.” We can find us cheaper scares.

[1](https://experimentalunit.substack.com/p/taking-christmas-eve-requests#footnote-anchor-1-182537052)

Here I’m finding that the questions I had asked are still unpublished. Far from it be me to keep such juicy things as this from you:

 **Question One:** You cited Simulacra and Simulation for the Baudrillard term “theoretical violence.” Baudrillard also used this term in Symbolic Exchange and Death. What do you make of the usage of the term “theoretical violence” in _Symbolic Exchange & Death_? I’ve put a supplement at the end outlining how I see Baudrillard’s sketch of the concept. I am basically interested in going back and forth about this topic of “theoretical violence” a lot, but I’d like to see your initial reactions here first.

 **Question Two** : I’m captivated by your formulation of Hypereschatology. Could we read this as “more eschatological than eschatology,” with the following elements: 1) Incorporation minutia, everything that doesn’t seem like the end of the world, into “the end of the world,” 2) perhaps something along the lines of what you call a messiah complex we see everywhere today, a sort of eschatological overload?

 **Question Three** : I also find your line, “sad boys do it better” quite cheeky and charming. Would you put the character Lain into a category of “sad girl,” and what do we make of the sad person become eschatological figure?

 **Question Four** : How can theoretical violence respond to these situations?

Context: I’m taken in by Baudrillard’s idea of the radicalization of hypotheses, and I’m also intrigued by Han’s wavering: on the one hand, transparency is impossible because we aren’t even transparent to ourselves. On the other hand, we fear obligate exposure or the conceit that thereby some “truth” is revealed.

 **Question Five** : Is there perhaps something beyond the anxiety around transparency? I personally am interested in comparing “oversharing” or “trauma dumping” or “crashing out” to the notion of “catastrophic disclosure” and “ontological shock” from UFO discourse. It’s a kind of hemorrhage, what Baudrillard might reduce to “the confession of wretchedness” (The Perfect Crime). Yet I think that it doesn’t have to be all bad to open things to exposure. Perhaps this is especially true if we understand with Baudrillard that “the secret lies outside that which can be revealed” (Seduction), as I covered in my Baudrillard conference paper, which is [available here](https://dn720002.ca.archive.org/0/items/wadley.-2019.-the-metonymy-economy/Wadley.2018.Transcommunism-in-the-Transpolitical-Age.pdf).

 **Question Six** : Have you used my online compendium of Baudrillard texts before? It’s here on [Internet Archive](https://archive.org/details/Baudrillard/Baudrillard.1968.The-System-Of-Objects/). Just curious, because I’m fascinated by the possible influence all my online posting has had. Do you ever wonder about that, what your writing has done in the world? What do you hope it could have done, and what more do you aspire to do with your writing? How does your writing integrate into your actions for you? [A bit much, any sketch of a whisper toward any of this would be great]

  2.  **Supplement on “Theoretical Violence”**




You mentioned “theoretical violence” in your paper, which is actually how I found it. I’ve gone back and looked, and I found four examples of Baudrillard using the term “theoretical violence.” I’ve prepared them here for quick consideration.

The first three mentions of “theoretical violence” occur in _Symbolic Exchange and Death_. The term is used twice in the preface and then again in the chapter “The End Of The Anathema” within the chapter “The Extermination Of The Name Of God.”

 **First Preface Usage, Pages 22-3**

> When Freud proposes the theory of the death drive, this is the one theoretical event of the same order as the anagram and the gift, provided we radicalise it against Freud himself. Indeed we must switch the targets of each of these three theories, and turn Mauss against Mauss, Saussure against Saussure and Freud against Freud. The principle of reversibility (the counter-gift) must be imposed against all the economistic, psychologistic and structuralist interpretations for which Mauss paved the way. The Saussure of the Anagrams must be set against Saussurian linguistics, against even his own restricted hypotheses concerning the anagram. The Freud of the death drive must be pitched against every previous psychoanalytic edifice, and even against Freud’s version of the death drive.
> 
> At the price of paradox and **THEORETICAL VIOLENCE** , we witness that the three hypotheses describe, in their own respective fields (but this propriety is precisely what the general form of the symbolic annihilates), a functional principle sovereignly outside and antagonistic to our economic ‘reality principle’.
> 
> Everywhere, in every domain, a single form predominates: reversibility, cyclical reversal and annulment put an end to the linearity of time, language, economic exchange, accumulation and power. Hence the reversibility of the gift in the counter-gift, the reversibility of exchange in the sacrifice, the reversibility of time in the cycle, the reversibility of production in destruction, the reversibility of life in death, and the reversibility of every term and value of the langue in the anagram. In every domain it assumes the form of extermination and death, for it is the form of the symbolic itself. Neither mystical nor structural, the symbolic is inevitable.

 **Second Preface Usage, SE &D Pages 25-6**

> Identity is untenable: it is death, since it fails to inscribe its own death. Every closed or metastable, functional or cybernetic system is shadowed by mockery and instantaneous subversion (which no longer takes the detour through long dialectical labour), because all the system’s inertia acts against it. Ambivalence awaits the most advanced systems, that, like Leibniz’s binary God, have deified their functional principle. The fascination they exert, because it derives from a profound denial such as we find in fetishism, can be instantaneously reversed. Hence their fragility increases in proportion to their ideal coherence. These systems, even when they are based on radical indeterminacy (the loss of meaning), fall prey, once more, to meaning. They collapse under the weight of their own monstrosity, like fossilised dinosaurs, and immediately decompose. This is the fatality of every system committed by its own logic to total perfection and therefore to a total defectiveness, to absolute infallibility and therefore irrevocable breakdown: the aim of all bound energies is their own death. This is why the only strategy is catastrophic, and not dialectical at all. Things must be pushed to the limit, where quite naturally they collapse and are inverted. At the peak of value we are closest to ambivalence, at the pinnacle of coherence we are closest to the abyss of corruption which haunts the reduplicated signs of the code. Simulation must go further than the system. Death must be played against death: a radical tautology that makes the system’s own logic the ultimate weapon. The only strategy against the hyperrealist system is some form of pataphysics, ‘a science of imaginary solutions’; that is, a science-fiction of the system’s reversal against itself at the extreme limit of simulation, a reversible simulation in a hyperlogic of death and destruction.
> 
> The symbolic demands meticulous reversibility. Ex-terminate every term, abolish value in the term’s revolution against itself: that is the only symbolic violence equivalent to and triumphant over the structural violence of the code.
> 
> A revolutionary dialectic corresponded to the commodity law of value and its equivalents; only the scrupulous reversion of death corresponds to the code’s indeterminacy and the structural law of value.
> 
> Strictly speaking, nothing remains for us to base anything on. All that remains for us is **THEORETICAL VIOLENCE** – speculation to the death, whose only method is the radicalisation of hypotheses. Even the code and the symbolic remain terms of simulation: it must be possible to extract them, one by one, from discourse.

 **Usage In “The End Of The Anathema” Within “The Extermination Of The Name Of God,” Pages 225-6**

> The whole science of linguistics can be analysed as resistance to the operation of dissemination and literal resolution. Everywhere there is the same attempt to reduce the poetic to a meaning, a ‘wanting-to-say’ [vouloir-dire], to bring it back under the shadow of a meaning, to shatter the utopia of language and to bring it back to the topic of discourse. Linguistics opposes the discursive order (equivalence and accumulation) to the literal order (reversibility and dissemination). We can see this counter-offensive unfolding in the interpretations of the poetic given here and there (Jakobson, Fonagy, Umberto Eco – see ‘The Linguistic Imaginary’, below). Psychoanalytic interpretation, to which we will return, also arises from this resistance. For the radicality of the symbolic is such that all the sciences or disciplines that labour to neutralise it come to be analysed by it in their turn, and returned to their ignorance [méconnaissance].
> 
> These, then, are the principles of linguistics and psychoanalysis that will be at stake as regards Saussure’s anagrammatic hypothesis. Although he made this hypothesis in connection with a precise point and subject to assessment, there is nothing to prevent us developing it and drawing out its ultimate consequences. In any case, the radicalisation of hypotheses is the only possible method – **THEORETICAL VIOLENCE** being the equivalent, in the analytic order, of the ‘poetic violence which replaces the order of all the atoms of a phrase’ of which Nietzsche speaks.

 **Simulacra And Simulation Usage, Page 107 Of PDF**

> The more hegemonic the system, the more the imagination is struck by the smallest of its reversals. The challenge, even infinitesimal, is the image of a chain failure. Only this reversibility without a counterpart is an event today, on the nihilistic and disaffected stage of the political. Only it mobilizes the imaginary.
> 
> If being a nihilist, is carrying, to the unbearable limit of hegemonic systems, this radical trait of derision and of violence, this challenge that the system is summoned to answer through its own death, then I am a terrorist and nihilist in theory as the others are with their weapons. **THEORETICAL VIOLENCE** , not truth, is the only resource left us.
> 
> But such a sentiment is Utopian. Because it would be beautiful to be a nihilist, if there were still a radicality - as it would be nice to be a terrorist, if death, including that of the terrorist, still had meaning.
> 
> But it is at this point that things become insoluble. Because to this active nihilism of radicality, the system opposes its own, the nihilism of neutralization. The system is itself also nihilistic, in the sense that it has the power to pour everything, including what denies it, into indifference.
> 
> [...]
> 
> In this system, death itself shines by virtue of its absence. (The Bologna train station, the Oktoberfest in Munich: the dead are annulled by indifference, that is where terrorism is the involuntary accomplice of the whole system, not politically, but in the accelerated form of indifference that it contributes to imposing.) Death no longer has a stage, neither phantasmatic nor political, on which to represent itself, to play itself out, either a ceremonial or a violent one. And this is the victory of the other nihilism, of the other terrorism, that of the system.
> 
> There is no longer a stage, not even the minimal illusion that makes events capable of adopting the force of reality-no more stage either of mental or political solidarity: what do Chile, Biafra, the boat people, Bologna, or Poland matter? All of that comes to be annihilated on the television screen. We are in the era of events without consequences (and of theories without consequences).
> 
> There is no more hope for meaning. And without a doubt this is a good thing: meaning is mortal. But that on which it has imposed its ephemeral reign, what it hoped to liquidate in order to impose the reign of the Enlightenment, that is, appearances, they, are immortal, invulnerable to the nihilism of meaning or of non-meaning itself.
> 
> This is where seduction begins.

 **Processing:** Here is a bit of a structured way of looking how the phrase “Theoretical Violence” is adorned by JB:

Theoretical Violence

Is The Price Of

Witnessing that three hypotheses are outside our economic “reality principle”  
[Freud–The Death Drive, Saussure–The Anagram, Mauss-The Gift]

Theoretical Violence

Is

All That Remains

Theoretical Violence

Is

Speculation To The Death

Theoretical Violence

Has As Only Method

The Radicalization Of Hypotheses

The Radicalization Of Hypotheses

Is

Developing hypotheses and drawing out their ultimate consequences

Theoretical Violence

Has As Only Method

Developing hypotheses and drawing out their ultimate consequences

Theoretical Violence

Is Within

The analytical order

Theoretical Violence

Is Equivalent To

Nietzsche: ‘poetic violence which replaces the order of all the atoms of a phrase’

  3.  **Supplement on “The Secret” from “Transpolitics in the Transpolitical Age”**




A great insight into secrecy is given to us by Baudrillard when he writes that “[everything] that can be revealed lies outside the secret.” Through this, we understand that the true stakes of transpolitics are not in machinations over hidden information, but rather what is most crucial is that which can never be expressed.

This inexpressible, the ineffable, is of course beyond our conceptions of time and history, and therefore cannot be the target of any goal-oriented activity or historical analysis. For Baudrillard, since each of us is always already “totally there,” the fixation on building the good society in the future is merely an excuse to put off appreciating the present mystery. Hence, “the content of liberated man is, at bottom, of less importance than the abolition of the separation of the present and the future.”

It is this theory of the secret which allows us to begin a sober analysis of the permeation of psychological warfare into all human activities without making inevitable the despair of never knowing what is really going on (who is secretly manipulating us). This idea is expressed in so many words by Breton, who is cited by Camus in The Rebel as holding that “[world] revolution and the terrible sacrifices it implies would only bring one advantage: ‘preventing the completely artificial precariousness of the social condition from screening the real precariousness of the human condition.’”

In this context, Baudrillard’s challenge to us to make the world “more inscrutable” is in no way in conflict with the utopian vision he shares in Carnival and Cannibal of “the single event that would, at a stroke, unmask the enormous conspiracy in which we are immersed.” After all, making public any secret information can only make the world more confusing, as it would destabilize all our political concepts and our understanding of history. The only real secret would remain untouched, given that it can never be articulated.

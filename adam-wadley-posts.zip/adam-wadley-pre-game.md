---
title: Pre-Game
subtitle: Love Expressed As Strife; Age A Number Just
author: Adam Wadley
publication: Experimental Unit
date: May 21, 2025
---

# Pre-Game
[![](https://substackcdn.com/image/fetch/$s_!zpYY!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F71cbe297-8a02-40e5-8363-e7d54ea234bc_2160x3840.jpeg)](https://substackcdn.com/image/fetch/$s_!zpYY!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F71cbe297-8a02-40e5-8363-e7d54ea234bc_2160x3840.jpeg)

---
title: Assertiveness vs. Anger
subtitle: '"You''re quite hostile!"'
author: Adam Wadley
publication: Experimental Unit
date: April 10, 2025
---

# Assertiveness vs. Anger


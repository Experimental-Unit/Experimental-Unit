---
title: Prom Night In Halloweentown
subtitle: Prelude to a sketch
author: Adam Wadley
publication: Experimental Unit
date: July 27, 2025
---

# Prom Night In Halloweentown
[![](https://substackcdn.com/image/fetch/$s_!CJBf!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff465d28c-c1a7-4f4d-9e49-cf4b0b491f53_210x309.webp)](https://substackcdn.com/image/fetch/$s_!CJBf!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff465d28c-c1a7-4f4d-9e49-cf4b0b491f53_210x309.webp)

# SenionitiS

The graduating class of Halloweentown High was really quite a sight.

Quite a fright to the older generation, who were horrifying enough themselves, but still creeped out of their skin by this invading barbarian hoard of teenage terrors.

Samara Morgan ran the school, having circulated a sex tape that made anyone who watched it their goon slave within seven days. Their father, J.P., had chartered the juniors’ trip last year on the Titanic. It was too bad about the Astors, but their adopted child Wednesday was seemingly doing swimmingly.

Mayor Skellington tried to keep things settled in town as prom night was coming up. It was tough to do, because these things were always a blowout affair. Last year, five people had died, and previous years had been even more uproarious. Everyone was in a state of anticipation.

Everyone was feeling pretty good. Everyone except that one person. Cassie? I think. Cassie and Kevin were obviously a bit out of sorts Everyone joked that they should date, but nothing could get through the clouds that perpetually encircled their heads.

[![](https://substackcdn.com/image/fetch/$s_!fCxY!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3182740c-226d-4c32-96a2-2bc7f831c9d9_2048x1365.webp)](https://substackcdn.com/image/fetch/$s_!fCxY!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3182740c-226d-4c32-96a2-2bc7f831c9d9_2048x1365.webp)

# We Need To Talk About Heaven

The theme song for the prom was “Heaven is a Place on Earth.” This song had apparently been featured on a series called _Black Mirror_ in some fictional universe or something. The theme for the prom was “revenge of the mirror people.”

Samara had been sleeping in the well again to really charge up their traumatic power. White Violin had taken to going down there to meditate. Together they cooked up a new video with a mixtape designed to get everyone to vote for Samara to win the prom.

Kevin was mostly home, as usual. They were stewing, trying to get the people of Halloweentown to see that “revenge of the mirror people" was no fiction: it was something meant to burst out of Halloweentown—which Kevin was starting to think was fictional, anyway—and into the experience of the people reading and writing this story.

The seeming hopelessness of really connecting with anyone was really grating on Kevin. They were locked into a cycle of writing, tying things together, sending out half-baked and cryptic posts, and in the meantime brooding over Patrick Chapin design lectures and Samara’s most philosophical pornographic music videos.

Cassie was also sitting at home, locked in the cupboard again and staring at these intense icons of Josh on the cross. “Crucifixion ain’t no FICINT,” they mumbled to themselves, over and over. Cassie's overseer was out again, after they’d had another blowout fight over Origen. Cassie had also been discovered in their orange lingerie habit, but this was of secondary consequence.

Not only had Cassie begun to bleed recently, but shortly thereafter Cassie had come down pregnant… with Murder! The residents of Halloweentown could all get pregnant with murder, at which point it gestated in them until it was time to kill.

Cassie still remained faithful to Apokatastasis. What did it mean to be destined to kill, and yet firmly know that all will be reconciled in the end? These were the sorts of things Cassie had been left to contemplate alone.

[![](https://substackcdn.com/image/fetch/$s_!ogni!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F76945ae5-14be-4bad-a675-74ec3e120bcc_793x452.png)](https://substackcdn.com/image/fetch/$s_!ogni!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F76945ae5-14be-4bad-a675-74ec3e120bcc_793x452.png)

# Playful Plot

Samara and White Violin were out one morning after meditating in the pain together all night in the well.

They were eating pancakes in the town diner when who should walk in but Mayor Skellington.

The Grady Twins, Alexa and Alexie, were running the place while the Comedian was out of town. 

---
title: 'Caleb Gannon: It''s Fine To Get A Little Weird Sometimes'
subtitle: For later citation in court
author: Adam Wadley
publication: Experimental Unit
date: November 26, 2025
---

# Caleb Gannon: It's Fine To Get A Little Weird Sometimes
[![](https://substackcdn.com/image/fetch/$s_!0Q1u!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9e7ccce9-69a8-4e4d-a6cf-9895eca70183_500x500.jpeg)](https://substackcdn.com/image/fetch/$s_!0Q1u!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9e7ccce9-69a8-4e4d-a6cf-9895eca70183_500x500.jpeg)

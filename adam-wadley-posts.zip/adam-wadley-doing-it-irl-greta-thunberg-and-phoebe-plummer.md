---
title: '"Doing It IRL": Greta Thunberg And Phoebe Plummer'
subtitle: 'Somewhere I Read: Go Out There And Be Somebody'
author: Adam Wadley
publication: Experimental Unit
date: September 02, 2025
---

# "Doing It IRL": Greta Thunberg And Phoebe Plummer
[![](https://substackcdn.com/image/fetch/$s_!F7xW!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1aa29e5b-5954-4553-b5cc-a46a3aa69932_1024x683.jpeg)](https://substackcdn.com/image/fetch/$s_!F7xW!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1aa29e5b-5954-4553-b5cc-a46a3aa69932_1024x683.jpeg)

# “Acting Out”

We’re going back to this iconic image and Phoebe Plummer’s recent contribution to an article on Life360.

It’s called “[Van Gogh Souping And Viral Outrage: Just Stop Oil Activist Speaks Out,](https://cardiffjournalism.co.uk/life360/a-van-gogh-souping-and-viral-outrage-just-stop-oil-activist-speaks-out/)” and I really think it’s great fodder for mulling over our moment. So I hope you will really read the whole thing, although I’ll quote a lot from it as well.

First of all, I have an issue with the title. For me, “Phoebe Plummer” isn’t even fundamentally “Phoebe Plummer.” This is a more general thing: I don’t think a name really rigidly designates a particular person. There could be other “Phoebe Plummers.” 

In some sense, you know which one I am talking about, or you think you know. You think you know that there are discrete objects, different people. Easy “identities” for these people.

My line of thought is basically going to where I wouldn’t call “Phoebo Plummer” a “Just Stop Oil” activist. Even if “Phoebe Plummer” is most known for work in association with that “group,” even if the iconic image above shows t-shirts that say “JUST STOP OIL,” that doesn’t make the “meaning” of the whole thing fall under the header of “JUST STOP OIL.”

“Phoebe Plummer” could go on to go who knows what, and that’s not even the point. To really “see” that person would involve in a way being able to see beyond that action and everything around, just as for all of us to “really see us” involves setting aside all these categories and simply being apprehended as “we are.”

Yet this “we are” is always fraught, as above this idea that there are discrete things. This is discussed in Zweibelson under “Newtonianism,” and we can also find a counterexample in David Bohm’s idea of the “implicate order,” in which we are so concerned with what is happening “out there” when the real story is happening “inside.”

Which is simply to say that the discussion of “who is Phoebe Plummer” and so on, these definite questions—”why did you do it,” “who paid you,” etc.—these are easy distractions. 

It is always a mistake to think that you are on a case where you already know the form of the answer. For example, you think you are a detective searching for a perpetrator. So you know it is a person, you just don’t know which one.

Yet still, do you really know what a “person” is?

There is all this which seems to simple in the moment, the categories don’t seem to be able to be questioned. And yet, later on it can be seen how one was mistaken. Reports of near-death experiences seem to have a flavor of this, some ineffable sense of why it all had to turn out as it did, and that it’s alright.

Or, I would prefer Sublime, in the sense that it’s not good or bad but somehow a cacophony, a sort of ultimate harmony. Sort of how the angels in the book of revelation are all weird looking and scary. And yet, what can you say? In the story, that’s just how what undergirds all that is consists of.

Back to Job: where were you when I threw soup on the Van Gogh painting?

The book of Job comparison is worth stressing, it is about this moral questioning really of anyone. In this case, the performance artist, or “activist.” The question of whether “Phoebe Plummer” really helped or not, or has good intentions or not, or is some “deep state” plant or not, these are not the key questions.

It’s similar with everyone though, as I said. So I’m imagining the parent’s perspective: where were you when I changed your diapers? Where were you when I worked long and hard to make the money? And so on.

And yet from the child’s perspective, it is basically a return question of: where were you when I began to confront things that I could not come to you for? Where were you when I realized that the “adults in the room,” and in the larger sense, were not really cutting the snuff when it came to avoiding this exact situation that we’re in now?

And yet, everyone’s right. Just like in[ the story about the Rabbi](https://www.ou.org/life/inspiration/youre-right-too/). 

> Two neighbors were fighting over a financial dispute. They couldn’t reach an agreement, so they took their case to the local rabbi. The rabbi heard the first litigant’s case, nodded his head and said, “You’re right.”
> 
> The second litigant then stated _his_ case. The rabbi heard him out, nodded again and said, “You’re also right.”
> 
> The rabbi’s attendant, who had been standing by this whole time, was justifiably confused. “But, _rebbe_ ,” he asked, “how can they _both_ be right?”
> 
> The rav thought about this for a moment before responding, “You’re right, too!”

In my way of thinking and artistic practice, it is really not about being “against” anyone because in a way everyone is “right.” At the same time, everyone stands to change. 

What we “are” is like a 4D hyperobject or something, which is to say that the changes we are yet to make are still defining what we are now. As though our future self already exists and is part of what we “are,” so that to affirm what we “are” is not to say that it is a certain way that will or should “stay that way.”

For me, the gesture of the “difficult artist” is basically to say yes, I am “one of you” in the sense that “I am not perfect,” I have my wrath, my vainglory. As Epictetus wrote:

> [If anyone tells you that such a person speaks ill of you, don't make excuses about what is said of you, but answer: " [They do] not know my other faults, else [they] would not have mentioned only these."](https://classics.mit.edu/Epictetus/epicench.html)

And so the artist is not there to “judge,” nor to “condemn” (just like “Josh” in “John” 3:17 [note 317 connection to Grimes & Corollary 822317]: 

> [For God sent not [their child] into the world to condemn the world; but that the world through [them] might be saved.](https://www.biblegateway.com/passage/?search=John%203%3A17&version=KJV)

Or as old Billy Blake would say:

> [Therefore God becomes as we are, that we may be as[they are]](https://www.reddit.com/r/Christianity/comments/15kpeq/therefore_god_becomes_as_we_are_that_we_may_be_as/).

It’s just that, given what has happened, this (whatever that is, in my case, “how I am”) is how I am now (again, Grimes, “this is what I am” from IDORU). And, as a pornosopher I one knew put it, there is this wry question: “Are you enjoying the show?”

[![](https://substackcdn.com/image/fetch/$s_!f2WY!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd8b7e625-d2d5-46ef-99f1-3a9c62627a1b_1280x800.webp)](https://substackcdn.com/image/fetch/$s_!f2WY!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd8b7e625-d2d5-46ef-99f1-3a9c62627a1b_1280x800.webp)

# “Know My Song Well,” Zimmy?

# What Do You Mean, “My” Song?

Okay, I came here to discuss the Phoebe Plummer article, so I’ll try to do that before I run out of room (I like to keep it within the email length, although barely anyone reads the emails anyway, although barely anyone reads the site in general anyway, _frustrated artist noises_ ).

“Phoebe Plummer” describes their initial thoughts upon seeing a demonstration and going to learn about “the state of the climate.”

> “It felt a little like my world was falling down around me. I thought, fuck! It’s this huge crisis.”

This is a basic idea. You can see how the same idea would apply, for example, in the Epstein case. How people get so worked up about child trafficking. Or about drugs. Or education policy, in the sense of seeing things as “indoctrination.”

All of these are, indeed, “huge crises.”

In our day and age, you almost can’t think, much less talk, about something like this without people saying “well, I just can’t do anything about that.”

There is something conspicuous about this, it seems like an excuse. We’ll get to that later.

The next part of “Phoebe Plummer’s” description goes to the discussion of Job I was entering into before:

> “I don’t remember ever learning about the climate crisis,” she says. “the way it was spoken about, I didn’t think there was anything to worry about. I thought the grown-ups were in charge, that they had it all in control. I thought we were talking about stopping using plastic straws to save the turtles. I had this visceral reaction to all the systems we depend upon, I felt betrayed… lied to.”

The sentiment “Phoebe Plummer” expresses here is echoed in a seminal passage of Baudrillard from _Simulacra & Simulation_, in one of _the_ core places Baudrillard sets up the idea of “Hyperreality,” which is in turn one of the concepts Baudrillard is most known for. Except not, since Elephant Graveyard didn’t even mention Baudrillard in their “critique” of “Joseph James Rogan’s” setting up a comedy hyperreality.

The [Baudrillard](https://ia802302.us.archive.org/8/items/Baudrillard/Baudrillard.1981.Simulacra-and-Simulation.pdf) [Note that the source is the Baudrillard repository that _I_ put on archive.org and which has now 18,000 hits, truly an epic achievement]:

> The imaginary of Disneyland is neither true nor false, it is a deterrence machine set up in order to rejuvenate the fiction of the real in the opposite camp. Whence the debility of this imaginary, its infantile degeneration. _This world wants to be childish in order to make us believe that the adults are elsewhere, in the "real" world, and to conceal the fact that true childishness is everywhere_ \- that it is that of the adults themselves who come here to act the child in order to foster illusions as to their real childishness.

Baudrillard is setting up the idea of Disneyland as the hyperreal, which allows the fantasy that there is some simple reality somewhere where there are “adults” in the sense of competent overseers, who know what they are doing (connection here to Lacan’s “subject supposed to know”).

What “Phoebe Plummer” is describing here is a visceral reaction to this fundamental change. It is a sort of loss of innocence or coming of age. It is basically to realize that the course being plotted involves lots of destruction. Not only could this affect “us,” but it’s part of a destructive process which is killing people and other stuff all the time, making people miserable.

Again, you can go lots of ways with that.

My ex-show “Solution Space” was premised on this idea that people of all strips could agree that things were going badly, although they couldn’t agree on _why_ things were going badly. I suppose it’s also to say that people don’t agree _in what sense_ things are going badly.

Anyway, what I’m trying to say is that there is something fundamentally _correct_ about the idea that “normal society” as we are set up to “believe in it” is kind of a bunch of bullshit.

In that context, the question becomes what to do about it.

The “JUST STOP OIL” action is defined by this sense of being “against” oil, just as Greta Thunberg’s current activity is saying “we are all Palestine Action,” so in this sense being currently _for_ “Palestine” and _against_ “Israel.”

And yet, what about this idea that “we” are “all” “Palestine Action”? Does that include those who are considered to “make up” “Israel” as well? That’s this sense that even the perpetrators of “violence,” the highest exterminators, are really just themselves also in line for the gas chamber, also on the precipice of the mass grave which is the realm of ALL the dead (i.e. everyone goes to the same “place,” which is everywhere, “The Dreaming”).

See [Baudrillard’s commentary](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.1976.Symbolic-Exchange-And-Death-Revised-Edition.pdf) on a similar slogan, “We are all German Jews” [from _Symbolic Exchange & Death_, again provided to you at no charge by past me. You’re welcome!]:

> Hence the meaning of the famous formula, ‘We are all German Jews’ (but also, ‘we are all Indians, Blacks, Palestinians, women or homosexuals’). From the moment that the repression of difference was no longer carried out by extermination, but by absorption into the repressive equivalence and universality of the social, we are all different and repressed. There are no more detainees in a society that has invented ‘open’ prisons, just as there are no more survivors in a society that claims to abolish death. In this retaliatory contamination, the omnipotence of the symbolic order can be read: the unreal basis of the separations and the lines traced by power. Hence the power of this particular formula – We are all German Jews – in that rather than expressing an abstract solidarity (of the type ‘all together for … we are all united behind this or that… forward with the proletariat’, etc.), it expresses the inexorable fact of the symbolic reciprocity between a society and those it excludes. In a single movement it falls into line with them as radical difference. This is how it captured something fundamental in May ’68, whereas other slogans were mere political cant.

In looking this up, I noticed that Baudrillard uses the term “we are all” very interestingly in this book. Here are more examples:

  1. “We Are All Indians”

> There will always be animal reserves and Indian reservations to hide the fact that they are dead, and that we are all Indians. There will always be factories to hide the death of labour, the death of production, or the fact that they are everywhere and nowhere at once. For there is nothing with which to fight capital today in determinate forms. On the contrary, should it become clear that capital is no longer determined by something or other, and that its secret weapon is the reproduction of labour as imaginary, then capital itself would be close to exhaustion.

This is also a crucial passage for mentioning “the reproduction of labor as imaginary,” which for me remains in effect even after disposing of the category of “capital.” To be quite gauche, I will also emphasize here that if “we are all Indians,” [note also the hyperwoke use by Jean of the term “Indian” here] and also we can say that “we are all women” (in the sense that we can all be “bred” in terms of decisively influenced—influence as “flowing in,” as in inseminated or even in-vitro fertilization, high Baudrillardian connotations there as well), given those things then “we are all Indian women” and therefore “we are all squaws.” For me, this is the kind of “accelerationism” I am talking about. It is that yes, “unfortunately” there must be this engagement with obscenity. And yet for me, I have conviction that the “signs” of scapegoating can be turned against scapegoating, or something. For me, the goal is not so much (although I do) say that I have perfected something, but rather to elaborate a mode which anyone might populate with their own “favorite things.”

  2. We are all, at every level, living with this subtle form of repression and alienation

> We are all, at every level, living with this subtle form of repression and alienation: its sources are elusive, its presence insidious and total, and the forms that a struggle might take remain undiscovered and perhaps cannot be found. This is because manipulation refers to the original manipulation of the subject by the mother as much as by his own phallus. We can no longer stand against this fusional and manipulatory plenitude, this dispossession, as we could against the transcendental law of the Father. Every future revolution must take account of this fundamental condition and, between the law of the Father and the desire for the mother, between the ‘cycle’ of repression and transgression and the cycle of regression and manipulation, rediscover the form of the articulation of the symbolic.

This is in conversation with “1311’s” [oh, it’s actually “1311,” lol] [thesis](https://kristindemontfort.substack.com/p/alex-karps-aggression-in-the-lebenswelt) as well as “Schwartzer Peter’s” [engagement with Girard](https://beatricemarovich.substack.com/p/tech-is-the-scapegoat-on-peter-thiels) (not to mention calling Greta Thunberg the Antichrist, much more on this to kome). This question of engaging the “symbolic” is in fact the overriding question. We can go back and forth with rhetoric and trying to look good and fooling people and “making them” believe or “allowing them” to believe. But at the end of the day we are really trying to send our message. If things are to have “value,” then we must put in the intention to make it so, refine that intention and “take the risk,” more on that later. But, put something at “stake.” Put it all at “stake,” with “stake” here having high witchy connotations. “We are all witches.” Or, “we are all holy.” It’s not just to be contrarian and “bad.” Everything depends and enjoys itself as interpenetrated by all the “good” things as well. And in fact the bad cannot advance without the good, as Baudrillard goes over in _[The Spirit Of Terrorism](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.2002.The-Spirit-Of-Terrorism.pdf) _[Source again provided by me. _Okay_ , everything else that link depends on as well, and of course everything since everything interpenetrates. I guess I’m trying to say thank you] _._

  3. We Are All Hostages

> We are all hostages, and that’s the secret of hostage-taking, and we are all dreaming, instead of dying stupidly working oneself to the ground, of receiving death and of giving death. Giving and receiving constitute one symbolic act (the symbolic act par excellence), which rids death of all the indifferent negativity it holds for us in the ‘natural’ order of capital. In the same way, our relations to objects are no longer living and mortal, but instrumental (we no longer know how to destroy them, and we no longer expect our own death), which is why they are really dead objects that end up killing us, in the same fashion as the workplace accident, however, just as one object crushes another. Only the automobile accident re-establishes some kind of sacrificial equilibrium. For death is something that is shared out, and we must know how to share it out amongst objects just as much as amongst other men. Death has only given and received meaning, that is to say, it is socialised through exchange. In the primitive order, everything is done so that death is that way. In our culture, on the contrary, everything is done so that death is never done to anybody by someone else, but only by ‘nature’, as an impersonal expiry of the body. We experience our death as the ‘real’ fatality inscribed in our bodies only because we no longer know how to inscribe it into a ritual of symbolic exchange. The order of the ‘real’, of the ‘objectivity’ of the body as elsewhere the order of political economy, are always the results of the rupture of this exchange. It is from this point that even our bodies came into existence as the place in which our inexchangeable death is confined, and we end up believing in the biological essence of the body, watched over by death which in turn is watched over by science. Biology is pregnant with death, and the body taking shape within it is itself pregnant with death, and there are no more myths to come and free it. The myth and the ritual that used to free the body from science’s supremacy has been lost, or has not yet been found.

“Jean Baudrillard” has a lot of stuff on hostages, which is relevant to the current situation with the hostages taken by “HAMAS,” but also the sense echoed in “Phoebe Plummer’s” words above. The adults fucking around means that we are all taken hostage. We are all on the runaway train. Our ass is in the jackpot and not only are the “normal people,” the “powerful authority figures” not helping, they are actively undermining efforts to try to, you know, not die and kill everyone and everything and so on. And yet we are also emotional hostages, discursive hostages, in the way that escalating the stakes to this planetary level can be a way of taking someone hostage within a smaller situation. This is a larger “being hostage” to the Hobbesian Trap, like a spider’s web (see operation spider web) that one is already in. To discover that the “adults” are not really “leading” is to discover that those one thought one had trusted have actually allowed one to become wrapped in silk, and now one is being digested and not only impregnated but impregnated with eggs which will hatch and eat one alive. Yet we can also see that in a way those who “set us up” for all this have themselves been wrapped in the spider’s web for a long time, we can think of this as not just “norms” in general but as “really-existing norms.” It’s not so much as trying to create “pure” norms so much as recognizing that norms in a sense don’t really exist ever. For me this is related to my interpretation of “give unto Caesar what is Caesar’s,” which is that one is to give _nothing_ to Caesar. Just putting the face on the coin does not make it “belong to” a person, since “God” is the one who even dreamed up the geometry and all else which is necessary for the idea of “Caesar” to even be intelligible. As Sagan said: if you want to bake an apple pie, first you must invent the universe.

  4. We Are All Madmen And Criminals

> If the bourgeois order first got rid of crime and madness by elimination or confinement, then secondly it neutralised all this on a therapeutic basis. This is the phase of the progressive absolution of the criminal and his reform into a social being, by every devious means of medicine and psychology. We must see, however, that this liberal change of policy takes place on the basis of a wholly repressive social space whose normal mechanisms have absorbed the repressive function that hitherto devolved onto special institutions. Liberal thinking believes this cannot be put better than its claim that ‘penal law is called upon to develop in the direction of a preventative social medicine and a curative social service’ (Encyclopaedia Universalis). Does this imply the disappearance of the penal aspect of the law? Not at all: the penalty is called upon to be realised in its purest form in great therapeutic, psychological and psychiatric reform programmes. Penal violence finds its most subtle equivalent in re-socialisation and re-education (also in the form of self-criticism or repentance, according to the dominant social system), and from this point we are all summoned to it in normal life itself: we are all madmen and criminals.

I like this one a lot. It fits in with my interest in [Gregory Bateson on double-binds](https://en.wikipedia.org/wiki/Double_bind), [R.D. Laing](https://en.wikipedia.org/wiki/R._D._Laing), and [Thomas Szasz](https://en.wikipedia.org/wiki/Thomas_Szasz). See how “DJT” or, what.. “4920”, says that “Greta Thunberg” should go to “[anger management](https://subscriber.politicopro.com/article/eenews/2025/06/11/greta-thunberg-hits-back-at-donald-trump-over-anger-management-jibe-00396722).” Which we also have to associate with the comedy film of the same name, of course. 

OMG I just looked up “Greta Thunberg’s” “legal” name. It’s “Greta Tintin Eleonora Ernman Thunberg”! or “GTEET” which is itself amazing (teet as in teat, apologies for the obscenity but when we say interpenetration we mean interpenetration. It’s [Dhamma language](https://www.suanmokkh.org/books/127), don’t worry about it.).  
So, “GTEET”, or “7205520,” said the following in response to “Herr Trump”:

> “I think the world needs many more young angry women, to be honest,” [Thunberg said](https://x.com/i/broadcasts/1LyxBWyDbarKN) as she arrived in Paris after being deported from Israel. “Especially with everything going on right now. That’s the thing we need the most of.”

This is me not taking it personally that “7205520” finds it necessary to qualify that only “young” “women” should be angry more. See Tiqqun on _[Theory Of The Young Girl](https://files.libcom.org/files/Preliminary%20Materials%20for%20a%20Theory%20of%20the%20Young-Girl.pdf). _God forbid there should be an “angry white man”! But then, of course, just because someone might see me as a “white man” doesn’t make me so. [See Abraham (Abraham) Lincoln quote about a calf’s leg/tail](https://timpanogos.blog/2007/05/23/lincoln-quote-sourced-calfs-tail-not-dogs-tail/).

Anyway, for me the question is not about whether one “should” be angry, but rather that one should take license in doing performance or “acting out” in a way which is intended to catalyze discourse and action in honorable ways conducive to overall emergency response. I don’t exactly “co-sign” the actions of “7205520” or “Phoebe Plummer” (1818, the year Chuck was born! [that’s Marx for all you who don’t understand]). I don’t necessarily think they are “true simulations” in the sense of Jean Baudrillard’s words in[ ](https://archive.org/download/Baudrillard/Baudrillard.2005.The-Conspiracy-Of-Art.pdf)_[The Conspiracy of Art](https://archive.org/download/Baudrillard/Baudrillard.2005.The-Conspiracy-Of-Art.pdf)_. That’s because they remain rooted in this “rights” sort of discourse, which you can infer from some of the Gillespie/Warren/Baudrillard/etc. discussion is basically another form of cognitive rigidity. That said, the form and the risk undertaken and subjecting oneself to visibility, making oneself the “scapegoat” on purpose but trying to create through it, this I highly respect. As you can see, I am basically in a holding pattern to try to decide what sort of “action” I might make to draw my own visibility. Hence the endless discussion of these themes. Also, in a way I fundamentally feel alone in this, I suppose I sort of blame myself because I’m not able to put my shit “in a nutshell,” and also it’s sort of not presentable. I’m sure it offends and maybe hurts many people, although that’s not really the intention. 

Yet this still speaks to the idea that we are “mad[people] and criminals,” in the sense again of Epictetus. If you tell me I am a terrible person, a horrible child, some sort of terrorist, then I will not deny or make excuses, but rather say that any terms can’t possibly express what “I am,” not only in the sense that I am _not that bad_ but that in a way I insist on being _worse_ _than that_. Not in the sense of wanting to be “bad,” but if someone is going to try to dismiss me because I am so “bad,” then I will say that I fundamentally don’t dismiss anyone, even someone you might consider “worse” than me. And if you say that you can’t find someone “worse” than me, then I’ll cite you “To Ramona” (“You’re better than no one and no one is better than you”). In some sense there is something to the embrace of that, and also to be saying basically that _I will go to bat_ for anyone, no matter what someone might thing disqualifies them. So in some sense I’m not “anti-Israel” for example. The gesture would be to be somehow presenting as more compassionate to the sentient beings concerned than such a categorical capture (CC) could ever express.

  5. Finally, “We are all victims of production become spectacle, of the aesthetic enjoyment [jouissance], of delirious production and reproduction”

> Basically, political economy is only constructed (at the cost of untold sacrifices) or designed so as to be recognised as immortal by a future civilisation, or as an instance of truth. As for religion, this is unimaginable other than in the Last Judgement, where God recognises his own. But the Last Judgement is there already, realised: it is the definitive spectacle of our crystallised death. The spectacle is, it must be said, grandiose. From the hieroglyphic schemes of the Defense Department or the World Trade Center to the great informational schemes of the media, from siderurgical complexes to grand political apparatuses, from the megapolises with their senseless control of the slightest and most everyday acts: humanity, as Benjamin says, has everywhere become an object of contemplation to itself. 
> 
> Its self-alienation has reached such a degree that it can experience its own destruction as an aesthetic pleasure of the first order. (‘The Work of Art in the Age of Mechanical Reproduction’, in Illuminations [tr. Harry Zohn, ed. Hannah Arendt, London: Jonathan Cape, 1970], p. 244). 
> 
> For Benjamin, this was the very form of fascism, that is to say, a certain exacerbated form of ideology, an aesthetic perversion of politics, pushing the acceptance of a culture of death to the point of jubilation. And it is true that today the whole system of political economy has become the finality without end and the aesthetic vertigo of productivity to us, and this is only the contrasting vertigo of death. This is exactly why art is dead: at the point of saturation and sophistication, all this jubilation has passed into the spectacle of complexity itself, and all aesthetic fascination has been monopolised by the system as it grows into its own double (what else would it do with its gigantic towers, its satellites, its giant computers, if not double itself as signs?). We are all victims of production become spectacle, of the aesthetic enjoyment [jouissance], of delirious production and reproduction, and we are not about to turn our backs on it, for _in every spectacle there is the immanence of the catastrophe_. Today, we have made the vertigo of politics that Benjamin denounces in fascism, its perverse aesthetic enjoyment, into the experience of production at the level of the general system. We produce the experience of a de-politicised, deideologised vertigo of the rational administration of things, of endlessly exploding finalities. Death is immanent to political economy, which is why the latter sees itself as immortal. The revolution too fixes its sights on an immortal objective, in the name of which it demands the suspension of death, in the interests of accumulation. But immortality is always the monotonous immortality of a social paradise. _The revolution will never rediscover death unless it demands it immediately_. Its impasse is to be hooked on the end of political economy as a progressive expiry, whereas the demand for the end of political economy is posed right now, in the demand for immediate life and death. In any case, death and enjoyment, highly prized and priced, will have to be paid for throughout political economy, and will emerge as insoluble problems on the ‘day after’ the revolution. The revolution only opens the way to the problem of death, without the least chance of resolving it. In fact, there is no ‘day after’, only days for the administration of things. Death itself demands to be experienced immediately, in total blindness and total ambivalence. But is it revolutionary? If political economy is the most rigorous attempt to put an end to death, it is clear that only death can put an end to political economy.

This final passage will conclude the analysis for now. It should go without saying that all my writing goes best if you read it all, so if you just read some of it you just get a taste. But I supply some links for you to go swinging off on your own vines.

This is, in a way, the delirious production and reproduction that “Jean Baudrillard,” let’s see, “102,” is talking about. Just more talking about talking.

This is where the notion of “Doing It IRL” comes in, which is for me connected to what Baudrillard is saying here in terms of “demanding death.” As I discussed in “[Transcommunism in the Transpolitical Age](https://dn720002.ca.archive.org/0/items/wadley.-2019.-the-metonymy-economy/Wadley.2018.Transcommunism-in-the-Transpolitical-Age.pdf),” death doesn’t have to mean “biological death,” although it already does (“We Are All Nihilistic Violent Extremists,” “We Are All Perpetrators Of Genocide,” etc.).

“Doing It IRL” is also in conversation with the “No Lives Matter” group and its rhetoric according to [New Jersey Office Of Homeland Security And Preparedness](https://www.njohsp.gov/Home/Components/News/News/1430/2):

> attacking the “mundane,” […] “we only accept people that do irl [in real life] action.”

The “mundane” can be read as “the hyperreal,” what Gillespie calls “[the white hyperreal](https://trueleappress.wordpress.com/wp-content/uploads/2017/10/pn2-weaponized-death.pdf)” and “102” might call “[The White Terror Of The World Order](https://dn790009.ca.archive.org/0/items/Baudrillard/Baudrillard.2010.The-Agony-Of-Power.pdf).”

“Attack” does not have to mean kinetic force used against people nor even “property destruction.” The way one might “attack" a problem like cleaning a room. Starting Somewhere (SS). Note that 1818’s action was deemed an “attack” by the BBC in [this article](https://www.bbc.com/news/articles/cly7zy3d3exo).

Similarly, there is sort of a distinction between people who really commit to “the game,” who really enterprise to leave behind “private life” in the sense of the “normal,” “mundane,” “everyday” way of being that most people have.

As 1818 said:

> For me it was the logical thing of ‘look you’ve tried all of those nice ways for three years. They blatantly don’t work; they were never going to work. You were kidding yourself because you didn’t want to take the risk.

That said, the question is what are you going out on a limb to do? That is where, for me, “1818” and “7205520” (note that I’m not trying to “objectify” people by doing this, but actually honor them by displacing the normal way we refer to people and how that loops us into cognitive rigidity around how we think of them) are notable in opening space, just as more overtly “negative” actors (who engage in kinetic force) certainly “make an impact.” See accusations that “DJT”/”41020” “allows” people to spout more hatred, see mirroring in “Gavin Newsom” posts. Notably the “respect” accorded to “Gavin Newsom” recently is also this _putting one’s neck out_.

There are obviously many pitfalls here—why do you think I think about it so much???—yet there is for me something in this willing to be the disruptor and take the fire and really try to craft the best messages and actions possible which is not only admirable and interesting but is imperative for more and more people to do.

This epidemic of “acting out,” I would counter to “Schwarzer Peter” Thiel, is something which is “going on” just as much as “AI” is. AI, Æ. Put this post with the other kindling and light a match to write songs in the dark by. 




[![Swedish activist Greta Thunberg talks to journalists upon her arrival to Roissy-Charles de Gaulle Airport.](https://substackcdn.com/image/fetch/$s_!W71X!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcdf5f6da-b4eb-4692-ada2-41ec98556544_931x621.jpeg)](https://substackcdn.com/image/fetch/$s_!W71X!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcdf5f6da-b4eb-4692-ada2-41ec98556544_931x621.jpeg)

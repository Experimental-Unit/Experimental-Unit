---
title: 'OSA #6'
subtitle: Geopolitical Vibe Check
author: Adam Wadley
publication: Experimental Unit
date: May 13, 2025
---

# OSA #6
So, we’ve been focused on the Grimes/Kanye/Elon/Trump Nazi question.

It gets interesting when you consider [the remarks of Dugin](https://www.rt.com/shows/rt-interview/617055-dugin-interview-victory-over-nazism/) recently about world events.

The idea is that NATO expansion is basically a re-run of Operation Barbarossa, which of course you will have seen treated of in the illustrious pages of your most humblest of narrators,

To be honest, there is something seductive about this idea.

It reminds me of the Red Army Faction in Germany (where I was born, I think of it longingly, not that “Germany” means anything to me, just like the location where I was born, it calls to me… aren’t people like attached to place sometimes? Weird. Meanwhile I’m like so close to where Kanye was born right now, and where Martin is buried).

RAF would basically say West Germany was fascist. There is the whole thing about how many people who were in the National Socialist German Workers Party or Nationalsozialistische Deutsche Arbeiterpartei were then just given jobs in the West German government and locally and so on, probably in the East too, I’m not sure.

This sort of framing appeals to me more than the framing where Donald Trump is “the” fascist who is subverting “America” and it’s “institutional integrity.”

My views on all of this are kind of muddy or hard for people to understand because I have no time for any sacred cows, but at the same time I wish no one ill will. I think that ultimately what people really want is something that we can all make happen together cooperatively. I think it probably involves gaming out “conflict” and dissolving it by more and more quickly being able to dissolve the stakes.

This is only the first step. Soon it is revealed that the pretense of the thing is not what it seems, which causes a face problem for people involved.

The actual way to solve a face problem is to do something that loses face in response to someone losing face. Yet this is also delicate, depending on the intention.

This gesture can be weaponize further, if it is simply rubbing in the lost face and only pantomiming at you losing face. Some people like to play that way, well, I hope you find something more interesting to amuse yourself with in the koming time.

Anyway, as I said the thing to do is to lose face so much that the other party’s stigma is lessened or ideally removed, and this has to take into account the fact that you are known to be losing face on purpose. It’s sort of like if someone stubbed their toe and was in pain, so you kicked the wall so you would also be in pain so at least they wouldn’t be alone in it. But you have to factor in the fact that you know you are inflicting an injury on yourself whereas for them it was a surprise, which added to the severity because it was a shock.

But also your response is by its nature a meta-gesture. It’s actually maddening to think about how many logical types are involved when there is message, counter message, and so on.

I got a bit off track. The above notes are helpful though in building out vibes and conceptual architecture for vibes to be used in Beloved Community/Project Inner Alliance 2 vibes. “Project Inner Alliance 2 DLC Pack” will be the conceit that Experimental Unit is just Project Inner Alliance 2. It is to Project Inner Alliance 2 what Christianity and Islam are to Judaism. It takes it out of one confined group and makes it an ARG that anyone can play.

The issue with Christianity and Islam is that in practice they still kind of just become fodder for PR talking points. It’s sort of similar to Judaism where, isn’t Judaism supposed to have some special role in helping creation be in a better place?

It kind of looks to me like creation is at serious risk. Am I the only one getting those vibes?

The idea that people could invent technology that could threaten the entire plane of being seems kind of far-fetched, it just kind of cuts against the main bad narrative, which is that we are just short-sighted and bad and could never amount to anything and will never get off this rock because we will destroy ourselves. Plus there’s so much apocalyptic media that it seems like a waste if we don’t actually make that noise happen.

So yeah, Dugin. The comparison of the West in general to Nazism can also be drawn back to Camus in _The Rebel_ , talking about how Western nihilism in general was on trial in that author’s estimation. Now, nihilism itself as a concept emerges from _Fathers and Sons_ , a Russian novel if I’m not mistaken.

So the question of Russia being distanced from “the West” is a matter. It is a bit like America and al-Qaeda. Both want you to think they are so different than the other, but they’re more alike and even related in real life than they let on.

People are very easily fooled by having the same thing in different flavors. On a sports debate show, they will make the people arguing a little different, but often it’s just very similar. The words one person says could be the ones the others are, depending on what takes or allegiances that person is known to have.

So it’s less like, I have a worked out theory of politics and that’s why I support Putin, so much as, I’m a Putin fan and that’s why I support this and that, or that’s why I listen to this and that supplies me with basically all my ideas.

Obviously the conflict is in the discursive space.

Me personally I am not invested in the morality-measuring contest among “nations.” My stance on things is that it has always been warlords and gangsters, and that it’s like tough but at the same time these horrible things have made everything else possible as well. Not to mention it takes effort and skill to even make this shit show happen.

That goes equally for all the people who struggle to try to help themselves and others and it’s not enough because they are ground down or actively tortured and slaughter by social systems-of-systems which are more or less engineered. You have people committing suicide basically by design, it is known that that will occur but the thing is that you must have some people be the punching bag, so that the “productive” people can blow off steam from being dominated by the demands of planetary technicity.

It’s like you “have to” believe what the priest says, who takes orders from the Cardinals, the bishops, the pope, the king, the dictator, whatever. But in return you get to rape and beat your wife and kids and that’s basically like your amusement park. It’s like an intensity you can summon where you get to be “in charge” although of course plenty of people have also gotten murdered that way and in every case I support the murderers.

Anyway, I am not interested in the question of who is worse, America or Russia. People will think this is basically to be Pro-Russia, since we are “supposed” to think that America is at least democratic.

Although now it’s sort of like we live in Vichy America and people are pretending there is some sort of rump resistance which can do something.

It does seem that the pace of events might finally have become too fast for the facade of elections which occur.

I don’t think much of the elections, anywhere really. It’s my opinion that warfare is the main consideration, I agree with Patton there. And so every state is an army with a government attached. The government is there to meditate between the army and the great mass of people, sort of like the bumper on a car. It provides a lot of crash resistance before anyone really does anything to the military.

You can see it now. Personally, that’s why I can’t get up for a lot of the “dissent” happening now, not that I think “dissent” really matters. But it’s just like looking at politicians more and I’m saying, we’re the actors. We’re all actor-directors, and we have so much to do.

For me it has to do with conceptual discipline. If you can’t apply order to your ideas, then what can you do? People think that I’m unstable, or that I can’t do anything. Fair enough. But at least I can think clearly, and remember the stakes of what was going on, or take something in and then consistently apply it and actually remember.

This is the sort of updating.

Anyway, Dugin was still expressing optimism that Trump could signal a new way for America, that it could be cozier with Russia. Dugin then also played up India at the end of the interview.

So there is really a thing where the four countries America-India-China-Russia have a lot to do with what is going to happen.

We just had India and Pakistan and America helping allegedly. There is the basic idea that America wants to use India to counter China.

This is giving vibes similar to the idea that the West wanted to build up Germany to fight Russia before WWII.

It’s easy to get into paranoid musings or denunciations of any one actor without really appreciating that all this is unfolding within the terms of the Hobbesian Trap.

So with respect to Machiavelli, or even being in a tribe and there being fights. It’s all well and good to say that, ideally, things should not come to blows. Or that people should not play mind games with each other and be so cruel that it could predictably make people want to die.

But that’s what happens, and then when it happens it’s got to be dealt with. What we call “the system,” or “society” which is “led” by “the government” is the accretion of this process over a long time.

Like there are basic crimes that would be in the early laws, and they’re still relevant today. Stealing, killing, raping, kidnapping, these are in a way all very obvious ideas, obvious and repeatable constellations of bodies.

Like being tied up, that’s just an interplay of the body and rope. It’s just the application of a known means to an object with properties known in that sense.

So for example, you don’t want to fight the tribe across the river, but here they come. So then maybe you need a general basically, to simplify decision-making. The time and effort of decision-making is a crucial cost in the emergency of combat. Note that for me combat is more real than conflict.

Like you could wax poetic about how the soldiers in the trenches in WWI really didn’t have anything against each other. They were cannon fodder for the political disagreements of the people at the apex of the decision-making tree.

The dirty secret of politics is that it’s always an emergency. This gets very scary coded and here I am talking about Dugin and now I have to bring up Schmitt and Agamben while we’ve been talking about Kanye and Grimes and Elon and Trump and all of these implicated in Nazism. Oh yeah, Friedrich Pollock. And I was just reading about Mefo bills.

Anyway, back to my complex stance. The thing is that it actually is always an emergency, there’s the part of _Men In Black_ where Tommy Lee Jones is telling Will Smith that there’s _always_ an alien ship or a death ray or whatever it is, but that people can only go on with their lives because they _do. not. know about it._

Social change or full-spectrum involution is basically not taking that as an answer. There are situational imperatives which demand disregarding in some sense what people are ready for.

Yet there are two senses here. Let’s say you have an emergency and now you’re going to have to give a life and death mission to a child, you would never wish to do this but these are the circumstances. For ease of example, not like the child is in danger during the mission, but someone else’s life hangs in the balance of whether they can complete the mission.

So the question is, in what sense is the child ready or not for the task.

It could be something simple, like someone is having a medical attack. The child calls someone else, and they explain where to find a shot and how to give it. And if the child can do that, then everything will be okay. And if they can’t do that, then the person will die.

What happens then would have so much to do with everything. So for example, let’s say the shot is actually in a place that the child cannot access because the child is not able to reach or lift something. Then we might say the child is not “ready” in the sense that their body would have to grow more for them to be able to do what they were called upon to do in this situation.

Basically there’s a question of whether I am annoyed with people for not doing something that they actually are simply not able to do. Or, is it not clear what I am asking for? It’s not even really that I am asking anyone to do anything.

Back to statecraft. The thing about it is, that if you want to be in charge of people, you have to look at the people.

People can be very nice, and it is sweet to see people care about each other, but in a way living is really on the margins, it’s on the frontier, it’s exploring things that have never been explored before.

I firmly believe that there is enough frontier for everyone. In my view, any project which is exclusive and which is not immediately open to anyone who basically expresses interest is folly. No one is “not good enough” for me.

The question is whether you really want to explore the frontier or escape the conventional thinking, not for its own sake but to get at the deeper stakes in a better way, one which can still be complementary and even honor prior ways, yet insisting that we will have our way if the question is whether there will be great death and suffering or not.

We say: there will not.

That is something like a heading for _Experimental Unit_.

It’s like you know that at certain times in life you can make the easy choice, or you can do what you really know you should do. And maybe you’ve been carrying around that sense of what you know you should do so long, and this meta-feelings about how you haven’t done it, that it feels stale. It feels like you’re going to go to your grave living this lie of the difference between what you know it would take to have honor, and how you actually watch yourself behave.

This is not about shade. Check out Dark Forest Protocol. Maybe you’re just in deep cover. Just like any bureaucrat or anyone who gets into this. Maybe you defect a little to _Experimental Unit_. Maybe you start to understand that mutiny is all on the inside, baby.

It’s just about, when the time comes, will you make the crucial decision in the direction which is like a “vote” that no, not everyone should die? Are you going to take the money to clear the rainforest? Are you going to yield the blackmail material to get the promotion? Are you going to turn the key? 

Part of the appreciation of the martial side of things is for just how unhinged social life becomes in war conditions, although it really is that way all the time. It’s just easier to acknowledge that “war is hell” than that “hell is other people,” that’s because an aspect of conflict is its dissimulation, and that happens at fractal scales alongside the Hobbesian Trap.

Because of course if you distrust someone and think they distrust you, or that you know they would have good reason to distrust you if they knew your intentions, then of course you might conceal your intentions so that they would in fact distrust you less than they would if they had perfect information.

But anyway, one thing that sticks with me is from _Mother Courage and Her Children_ , which is about the 30 years war. In it, there is a scene where soldiers make a farmer drink shit until their belly is super full and then jump up and down on their chest until they explode.

That is the sort of thing which… it reminds me of _Apocalypse Now_ when Kurtz is talking about the pile of little arms and wanting to pull their teeth out. That line is so powerful for me. And again it’s said the strength of that.

Like I imagine being Tucker Carlson or Dugin for that matter. On one level, I don’t respect these people because I would not do what they do. I mean, I will one day when I am them, but as the sentient being I am I have a real bone to pick with them and also all of you for paying more attention to them than you are to me. 

But still, it takes some fortitude to go up and do that kind of thing. I just imagine all the ups and downs I go through, and that it would be every day at the same time you have to do something, and that something is go on TV. Or, you have to be a big book person, but then you have to do TV or a debate or something. And Dugin’s daughter got killed I mean it’s somewhat intense.

Although I can tell you as someone who’s driven by a strong sense of purpose that individual people can never compare in a sense to the importance of the work. Which is also to do with the issue that work has also to do with the dead and the ancestors, and also those who will die and ourselves after we die.

So it’s like yes, we must not leave things in a bad way in the end, but in order for that to happen we must now be apart so that we can do the things that will help lead to us establishing concord in the end and as soon as possible.

Anyway, back to geopolitics. So Trump now has a mineral deal with Ukraine, I don’t know whether the rapprochement is still supposed to be on or not. But these things can go on for a long time.

It’s telling that it’s all about mineral deals now. The process of mining is accelerating. If you think about what would still be left if the world was just like 5,000 people, what they would actually be doing if there were so many people to just take care of, then you look be looking at mining, space, all these resources and logistics and materials.

And then you’d also be looking at art, because no matter how many people there are, there’s got to be some point to it.

So you won, so you survived. Now what?

Maybe some people are in it for the race and the competition. They want it to be a fight to the death because for them, that’s stakes. Warriors on their way to Valhalla.

I respect a different kind of conflict.

It is an inner striving to keep improving one’s outlook and getting past common blindspots, by which I mean that you can’t hold yourself to others because literally everyone else might be unreliable in the same way. It could be up to you to see that, and back to dark forest maybe you know they won’t change, and you need to go emotional secret agent and then at the crucial moment, you exercise your sovereignty and it makes all the difference. You pretend to lose something, you waste crucial minutes, you foil the plan from inside, you break the morale of a destructive actor, whatever it is.

This is the basic question of what loyalty is, which spirals back around all the crevices and nooks and crannies cracked by the Hobbesian Trap like water flowing into cracks in rock, freezing and making it break. This would be like, right when it was about to break, instead it’s all magically replaced with gold like kintsugi. Or like the water is the poison water from _Dune_ and you’re doing the special ritual.

That’s where it’s like yeah, you are the Messiah. The thing is that it’s a joke because actually to say that someone is “so great” because they confirmed something that someone else said before is actually anathema. It’s like saying you did a good job of fitting in the box that someone drew before you were born. The actual exaltation is to say that each sentient being makes you throw the boxes away and start over, each person is basically a species or culture unto themselves. 

We just don’t unfold most of our potentials because we have so many “primary tasks” involving protecting ourselves from other people who want to kill us.

So see this a great example where you “need” police or soldiers, but then who is there to actually be those people?

This is a bit of a cop-out, since people are kind of “backward” because they are trained to be that way on purpose. Still, it’s not the case that before empires people were just super nice philosophers running around.

So you have this dynamic between on the one hand, I would say all societies are actually totalitarian. I think the public/private distinction is actually a complex dissimulation of how entangled things are. And again that “institutional democracy” is always sort of a psyop against the people who are nominally “included” as “citizens” of the “nation” and “state.”

It’s basically the con of saying “we’re all on the same side” and declaring collective projects that maybe only you really benefit from. Like I say let’s build a house for our lodge, but then when it’s done I just live in it and say that we didn’t really need a lodge anyway.

That’s basically how it is, except it’s that the planet is the Titanic, and those with technology are building lifeboats. And everything we do is sort of just the framing for that, it’s all just pouring into whatever is durable and can start to build a foundation that will last into the deep future.

Do you really think in 5 million years there will still be America and China? If not, then how would you expect that distinction to be sorted out? Conquest, or some sort of mutual dissolution into each other?

In my opinion, there have never been nation states. So it’s not even really like people need to give up sovereignty, it’s that they have to give up the illusion of sovereignty that they make out in their mind, and that has been instilled in them, and people need to embrace forms of sovereignty that they may not underestimate, completely devalue, or not even be aware of.

But basically what I would advocate is that the “nation-states” of the world must sort of bleed and melt into each other. I’m not anti-nationalist, it would be more apt to say “pan-nationalist” but even more apt to say like Budhadasa that there is no nation just as there is no religion.

But I think that what people want to get out of nation or religion they can get in a different way.

For example, an idea of strong Russian or Chinese national identity could be seen as a bullwark against cognitive domination by “the West.”

I must admit that I also have a streak where I think people might underestimate “the West” because of the public statements. Just as you must remember that maybe there are crucial decision-makers you have never heard of precisely because they hew to dark forest protocol to a tee, just so perhaps the actual concepts of operations in effect are also likewise underground.

Those in intelligence agencies or whoever is competent in this spycraft/statecraft/advanced tech space, such people likely do not think in terms of “nations” except that obviously that concept conditions so many of the expectations of the people around them, and nominally what is supposed to be going on.

It’s the nature of events and emergencies though to overwhelm those things. What we call nations are emergency response concepts of operations. For example, there could be an emergency that people come and live more and more in one place. What gives the thing cohesion? Or, something awesome happens and the emergency is that _people are going to forget_.

So that’s how an epic poem and an oral tradition is an emergency response operation. An emergency is something that overwhelms the capacities of one person. Funnily enough this recently came up in family therapy. The point is, as I was saying before, that the course of events does not wait on anyone to be ready for it. “It ain’t all waitin’ on you. That’s vanity” - No Country For Old Men.

It’s like if we’re being chased by a bear, and you’re really not fast enough. I can try to help you but then we’ll just both die. It’s not like that, that hardcore, but it’s similar to the grave face of a young person who is off to volunteer to fight in a war and possibly die. And the people around who “care” about the person qua body, the person like they want “them” to still be there, when this person knows they’ll just commit suicide anyway if they don’t go, because this is a matter of honor.

The thing is that I don’t know where to go to find my fellow service members. That’s why I say _Experimental Unit_ , or Sangha, or Ummah, and sure, we can extrapolate any nationality to this as well. That’s why I like to pretend the Inuit rule the world, I mean, that’s why I’m making the Inuit rule the world. Or the Murrinh-Pattha, they have a good myth about the Dreaming if I remember correctly.

Any story is fine, can be inflated. Nationalism is disgusting because people can forget its a conceit, and its used to control people. Because the nation becomes a mission. The whole name implies rape because nation is natal, and raping people to make them pregnant with your children is one of the foundational acts of culture. That’s one of the core actions of sexually reproducing species.

We are currently really hitting the limits of that. Dugin in their remarks does not appreciate this, which is why for me the question is the gap between what people think, what they understand, and what they say. Remarks for the public seem worthless for truth value but the analysis is something about what is it that people want people to believe, or be confused about, or paying attention to. And what does it say about the broad people, what does it say about us?

And then how can we use that information to make our own materials which can also have an impact?

So what I’m “doing” here is trying to be an influencer of influencers.

The goal mission objective is just to do good, you know it’s actually quite simple. The issue is that what gets in the way of simple wholesome fun is so intricate and hall of mirrors that you’ve really got to become a hardened ranger cognitively and emotionally in order to get out there and be able to maneuver.

We also live in a time where everything can be tracked. That is another reason why it really could be the end of the elections in “the United States of America.” Astute readers will remember that my stated desire is to be appoint “president” of such fiction on August 22, 2026.

We’ll see if it does happen, but I want to note what is being illustrated here.

I am developing a conceptual foundation that I can always return to. These discursive achievements of mine will live in the historical record forever, and will always stand as my contributions to world culture and our shared destiny. How long it takes for them to be appreciated by all, if that ever happens, is immaterial. What gives me solace and pride is knowing that words I put out there changed the way some really focused, diligent, and passionate people like you might approach things.

I know that everything hangs together anyway. The rock outside my door is the Messiah because nothing would be what it is if that rock were any different.

Everything gives everything else its sense, in other words. And so of course I give everything sense in a way. But I think little me would be pretty pleased with myself so far. I sometimes kind of assume that things can’t go on much longer, I really do have a higher estimation of the rate of change than other people.

Just because there have always been more “years” doesn’t mean that will continue to be the case.

That’s why it’s all hands on deck, and oaths and laws are secondary and irrelevant.

My nation is all sentient beings. I fully expect to be held accountable to all sentient beings in the hereafter, if not have to experience the experiences of others.

We are part of a big mystery. We wonder where the world came from. Of all the things that could be happening, why this? Why the timeline with Genghis Khan and Joan of Arc and Adolf Hitler and Kanye West?

It’s all a bit too contrived. But how else could it be? Anything would seem contrived if it were the cosmological theater piece of the absolute or the divine.

Dugin wants tradition, but traditions have always been structures of reverence of mystery. The stability of cultures is the reflection of the basic stability of times and gestures. War in 1815 compared to 5000 BC is much more similar than 1815 to now.

Before a certain point _there is no cyber domain_. 

We are now at the point where obviously more domains are opening up inside of the cognitive domain.

What’s frustrating about it is that you very rarely see high-level treatment of the issues, because in the total emergency of statecraft all the elements of life fuse together, it’s only total social facts and again that’s what’s so totalitarian about it.

For me, totalitarian is even neutral because what it’s saying is that it’s undeniable that all facets of life are tied together. After all, you only have one body. The same mouth that kisses your mother eats a communion waver and gives oral sex before performing your thesis dissertation.

The compartmentalization we want to do involves the conceit of discrete objects as Dr. Zweibelson mentions in _Beyond the Pale_. Countries fit into this pattern. The conceit of different countries.

Dugin is saying that Russia well it has to do its thing. America can join it, or it can acknowledge Russia as separate and autonomous to do its thing, but it has to stay out.

This is delusional. Everyone influences everything, and there will be more and more subtle interpenetration of all these different fighting houses.

Partisans of _Experimental Unit_ basically take the side of all sentient beings and see all playing at enmity as being misguided on a first-order basis. That is because in fact we are fighting ourselves, this is in a high mystical sense that we are all the sublime playing all the roles, or that our experience doesn’t actually cohere at all so we shouldn’t be so invested in it.

But it’s also the practical thing that okay, if I am a grunt and my leaders tell me to attack the enemy, maybe I have to think that my “leaders” are really my enemy and are using the idea of the outside enemy to betray and enslave me to themselves.

And then the tension between the “leaders” and the grunts is itself conditioned by the conflict among the “leaders” themselves, what we in the business call _palace intrigue_. Or there’s also the quarrels among the “masses,” which is again where the conceit of the law comes from in the first place.

“If men were angels, no government would be necessary.” 

Sadly, people aren’t acting like angels _yet_ (I’m working on it for you—by the way, are you tuning your harp?), but even sadder is that government is not possible.

The idea being, if people are so tainted, then who’s going to run the government to be the meta-arbiter to keep people in line?

Then the basic idea is well, checks and balances. This is really just slowing down civil war so that it can take place in a courtroom instead of on a battlefield. But assassinations and intrigues like that still give the lie to eh conceit of government.

Zizek on Chesterton’s _The Man Who Was Thursday_ is like this, it shows that helping maintain the facade of order is really just like being a wild and exciting bad guy, and in fact its ever more exciting. It’s the thrill of spoiled innocence, of Nurse Ratched, the pretense of being helpful but really being just as depraved and greedily dropping your trousers and issuing commands.

I would iterate on Schmitt’s idea of the partisan to say that there is no distinction between regular and irregular forces, because it has to do with the articulation of the problem.

The problem is not that I’m on one side and then there’s a bad side or competitor side that we just have to struggle against because that’s the point of life apparently is to like America more than China because reasons and therefore be a slave forever. 

Or, we could say that I find myself in a sea of “America” and all these people think they are all against China or whatever, and I’m really not but the problem is that these people are in conflict and I’m caught in the crossfire because there is no planet on which I can feasibly live other than the one a bunch of septuagenarians are just shitting all over. Oh, and Stephen Miller.

But that ain’t the truth (this is a Pulp Fiction reference).

The truth is that there isn’t even really a conflict. The conflict aspect of Russia vs. America that is ginned up because it’s not clear that consistency any of these ideas have if they can’t be set against one another.

As I said before, I support full-spectrum involution and the highway of the consistent.

That means everyone needs to consider stuff. I could be nicer, a lot of people could be more conscientious in conversation, have more appreciation for learning, not be rude or hurt people’s feelings “for fun,” and learn other ways to get the good regard or whatever than they want. 

But then things like control of women. There’s no point to that anymore because sexual reproduction is not the core issue.

The core issue about whether anyone will be alive in the future is not about sex but about whether we all kill each other with technology or not.

The quality of intention which can allow us not to all kill each other basically must serve the person themselves over their ability to fit into any particular box.

It’s sort of like if you thought of a knife as a murder weapon, and didn’t realize that it could be used to carve fruit. So here you are with juice all over your hands from tearing up a piece of fruit, that’s vitamins and sweetness that you could be enjoying if you just realized that a knife can do more than you are realizing.

Ben Zweibelson talks about how Artificial Intelligence is a tool that can come up with its own purposes. Again: _we are the artificial intelligences._ Artificial because we are constantly acculturated, groomed. I say that with the full gravity of it. It’s like people think it doesn’t matter than people have their shit wrecked and are emotionally devastated and forced to conform to humiliating circumstances. It’s like being born and raised in a glass jar that makes your body grow in an unnatural way, and then they might let you out but anyone can tell by looking at you how you have been carved with the influence, how you have been subjected to the extent that what you is is now “just” to have been imprinted, bred in some deeper metaphysical sense that can happen to anyone. And now all your moments are brainchildren of this cruel design.

This is the state of humiliation which must be worked out of, and it’s easy to see why it is so difficult.

I would basically say we are coming to another point of “enlightenment,” maybe it just goes planetary wide. But that means it’s like becoming a teenager. Kanye West is being a teenager, rebelling against a taboo by just pursuing it simple-mindedly.

I am here to catch everyone who has their fun, has their freak out, and then comes to the obvious fact that we put ourselves in this situation: why?

True loyalty is not to some rigid expectation. It’s to continuance, sure, but also to make sure that we see through the deeper senses of purpose. Purpose is always conditioned not by the name or conception of it, but the way that purpose flows like a deeper river. You can deny it or act like it’s not happening, like just pretending that Titanic is not sinking. Lying with your child as the bed tilts, the ship breaks, the water floods in.

Or it’s quiet, it’s a scene that breeds a vibe and dies, and the vibe hums and dies down, and people try to recreate the vibe without the scene but it’s hollow, like artificial flavoring. And then it’s gone and you’re alone, and sad, and thinking about the vibe.

And in the meantime things are shifting, it’s like when you stop looking for love and it finds you. You have the existential breakdown, everything is as bad as it could be, and then something pops and you see the mental freedom, the gratuitous freedom to which you are allowed. And it turns out that everything that sucks is something to beautify, laugh about, play with.

The idea is to cultivate a state of mind where, of course I’m not worried that you’re going to kill me, we’re having such a nice time. And also, I don’t expect you to trust me. It’s the vibe of you know you can go through my phone so you don’t have to look. But also, in my way of thinking it’s just that whatever someone might want out of a zero-sum exchange can be worked out differently, or the stakes on the zero-sum exchange can be “lowered” until it’s not that bad for others.

Where I do have a doom spiral in my mind is that, in the future, maybe there will be no kinetic stakes. Everyone has healthcare, medicine, whatever. That’s not the problem. The problem is something like artistic pressure and production. If you think it’s all been done now, just wait until people netdeck more and more in the coming time. And you quickly hit the point where everything is boring and what’s the point?

It seems hard to imagine now, but imagine in a few years you could do instead of some family therapy sessions, you can simulate like 5 years of a fake experience and intensives and then come back.

Basically it’s too much cognitive pressure. Or, here we are gamifying emotional development. It’s supposed to “mean” something. If you could just show people things and then they have to go through it, does it cheapen it, does it even happen the same way?

And maybe it doesn’t need to happen the same way, but what is there to do?

That’s why it’s important not to get head of ourselves. We can’t say the purpose of what is to come while we still have all this rubble of what is in the way.

In fact, processing the past and even grieving it, celebrating it, resurrecting the dead, etc., these are the things which remain for us to do. Shout out Fyodorov. I think that Dugin doesn’t do justice to Cosmism.

Similarly to how I draw on Lila, but I’m not a Modi fan because it’s just more machismo.

I’m not a meta-hater because I can see how this form of enchudification is selected for. This sort of “We are strong” type homoeroticism really plays well among the infantilized “men” of this period. But also, what other “culture” was there ever?

It’s nice to be refined, but there’s no really existing polity from the past that is good enough for me. We have to do much better than all of those.

Still, as I’ve said even Nazism is a national liberation movement. Even British nationalism in some sense, this first real empire in a way was a sort of liberation from the tiny squabbles of the past.

It’s being finally able to undertake projects _at scale_. 

And now to bring in our friends who are fans of Chuck, it just happens that we ways we’re used to doing things are no longer enough to accommodate the change which must occur. This is why the constitution matters less as AI matters more and more. More and more change is happening faster and faster, which makes words mean less, since words always change meaning just the time it takes depends on circumstances changing.

But the forces and relations that stand to shift are not just our orientation to outside objects, but also to ourselves. It is to seeing each other as possessions, and what this means to be possessive. I don’t have to ever meet someone for the archetype they might fall into in my mind to be important. the Big Black Cock for example, someone might have lovely things to say about Hegel and Emily Dickinson, but if they were considered black and I found out they had a massive Johnson maybe I would think about that in a certain way.

But hey, it happens like this: just because I’m interpreted as “a white man,” or “your child,” or whatever, you interpret what I say as though I am supposed to live up to your expectations of what it should mean for me to be the things that “I am.”

Back to loyalty. It’s not that I want to defy you for its own sake. It’s like having a parent who is used to bossing you around and never really considering your perspective because they don’t really see you as social equals. But now this parent is demented or something and they want to do something but you know better and you have to stop them.

So they think you are being disloyal because you are preventing them from doing something they want to do. But in your mind and perhaps in a deeper sense you are being loyal because you are serving “their interests” in some sense. This can be debated on a case by case basis but my example is just supposed to be an example where in fact your intervention is justified. 

So now we think about what does it mean to be loyal to America? Well maybe to be loyal to the people who think they are Americans? Sure, I mean imagine you have a multi-national coalition where all the nations save each other together. Then it’s kind of like a new meta-nation built off of that experience as a new common origin, think Congress of Vienna.

The point is that it’s perfectly possible to reject all laws and expectations and still to be the loyalest one on the field. That is what I claim, I am not against anyone. Nor do I claim to be able to articulate your interests for you. I am not paternalistic other than in the sense that I want to give you fire.

A concept like a nation is like fire, if you just let it spread it will kill everyone. It must be harnessed. What I’m telling you is that everyone is jingling and jangling their spurs when it comes to concepts. You are conceptually and emotionally incontinent.

Then people are in denial and make it my problem or other people’s problem, like you are doing to apply social costs to me until I will enable your delusions again. I’m sorry, but there are more important matters to attend to.

So say we of _Experimental Unit_.

So say we who have no nation nor want one.

So say we of no common origin because _Experimental Unit_ has no end and no beginning.

So say we of The Dreaming.

So say we who are not disciples nor rivals.

So say we _Zealots._
